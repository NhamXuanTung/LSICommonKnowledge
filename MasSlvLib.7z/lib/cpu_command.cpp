//$Id: cpu_command.cpp v2014_09_29 $

#include <iostream>
#include <stdarg.h>
#include <cerrno>
#include <map>
#ifndef WIN32
#include "re_security.h"
#endif
#include "cpu.h"

//handleCommand function
std::string Ccpu::handleCommand(const std::vector<std::string>& args)
{
    std::vector<std::string> _args = args;
    std::string ret = "";

    if (_args[0] == "command") {
        ret = this->own_handle_command(_args);
    } else if (_args[0] == "ini") {
        ret = this->ini_handle_command(_args);
    } else if (_args[0] == "tgt") {
        ret = this->tgt_handle_command(_args);
    } else {// send a command to all targets
        bool cmd_found = false;
        std::string baseid_message;

        _args.insert(_args.begin(), "command");
        baseid_message = this->own_handle_command(_args);
        if (baseid_message.find("Invalid Command", 0) == std::string::npos) {
            cmd_found = true;
            if (baseid_message != "") {
                //ret += "\n\n" + baseid_message;
                if (baseid_message == "NULL") {
                    ret += "OK";
                }
                else {
                    ret += baseid_message;
                }
            }
        }
   
        _args[0] = "ini";
        baseid_message = this->ini_handle_command(_args);
        if (baseid_message.find("is invalid", 0) == std::string::npos) {
            if ((baseid_message != "") && (cmd_found == false)) {
                cmd_found = true;
                ret += "\n\n" + baseid_message;
            }
        }
   
        _args[0] = "tgt";
        baseid_message = this->tgt_handle_command(_args);
        if (baseid_message.find("is invalid", 0) == std::string::npos) {
            if (baseid_message != "") {
                cmd_found = true;
                ret += "\n\n" + baseid_message;
            }
        }
        
        if (cmd_found == false) {
            ret +="Error(" + mInstName + ") :   Invalid Command Designate. Command =  " + args[0] + ".\n";
        }
    }
    
    return ret;
}

//own handle command function
std::string Ccpu::own_handle_command(const std::vector<std::string> &args)
{   
    std::vector<std::string> _args = args;
    std::string ret = "";

    if (_args[1] == "set_cpu") {
        _args.erase(_args.begin());//shift left args
        ret = SetCpuProcess(_args);
        if (ret == "") {
            ret = "Error(" + mInstName + ") :   Invalid Set Cpu Command Designate.\n";;
        }
    } else if (_args[1] == "cpu_command") {
        _args.erase(_args.begin());//shift left args
        ret = CpuCommandProcess(_args);
        if (ret == "") {
            ret = "Error(" + mInstName + ") :   Invalid Cpu Command Designate.\n";;
        }
    } else if (_args[1] == "mem_load") {
        ret = handleMemLoad(_args);
    } else if (_args[1] == "mem_save") {
        ret = handleMemSave(_args);
    } else if (_args[1] == "mem_dump") {
        ret = handleMemDump(_args);
    } else if (_args[1] == "help" || _args[1] == "h" || _args[1] == "?") {
        ret = PrintSscHelp();
    } else {
        ret = SetCpuProcess(_args);
        if (ret == "") { //check sub_command of set_cpu
            ret = CpuCommandProcess(_args);
            if (ret == "") {//check sub_command of cpu_cpu
                ret = CtrlSimCommand(_args);
                if (ret == "") {//check control simulation command
                    ret = "Error(" + mInstName + ") :   Invalid Command Designate. Command =  " + (std::string)_args[1] + ".\n";
                }
            }
        }
    }
    return ret;
}

//check input number valid or not
bool Ccpu::num_check(const std::string input_str, unsigned int *value)
{
    char *endp;
    if (value != NULL) *value = (unsigned int)strtoul(input_str.c_str(), &endp, 0);
    if (endp != NULL && errno != ERANGE && *endp == '\0') {
        return true; 
    } else {
        return false;
    }
}

//check and process set_cpu command
std::string Ccpu::SetCpuProcess(const std::vector<std::string> &args) 
{
    if (args[1] == "INIT") {
        CpuCedarInit ();
        return "NULL";
    } else if (args[1] == "REGSET") {
        unsigned int val;
        bool check_val = num_check(args[3],&val);
        if (check_val == true) {
            reg_write( args[2], val );
            return "NULL"; 
        } else {
            return "Error(" + mInstName + ") :   Invalid Parameter Designate. Parameter = " + args[3] + ".\n";
        }
    } else if (args[1] == "ENDIAN") {
        return handleSetEndian(args[2]);
    } else if (args[1] == "CPUTYPE") {
        return handleSetCpuType(args[2]);
    } else if (args[1] == "ILRAMSIZE") {
        return handleSetILramSize(args[2]);
    } else if ((args[1] == "LRAMSIZE") || (args[1] == "ORAMSIZE") ) {
        return handleSetLramSize(args[2]);
    } else if (args[1] == "URAMSIZE") {
        return handleSetUramSize(args[2]);
    } else if (args[1] == "ICACHESIZE") {
        return handleSetIcacheSize(args[2]);
    } else if (args[1] == "OCACHESIZE") {
        return handleSetOcacheSize(args[2]);
    } else if (args[1] == "DEBUGMODE") {
        if (args[2] == "OFF") {
            CpuSetDebugMode(DBG_OFF);
            CpuSetDebugEnable(DBG_OFF);
            return "NULL";
        } else if (args[2] == "ON") {
            CpuSetDebugMode(DBG_ON);
            CpuSetDebugEnable(DBG_ON);
            return "NULL";
        } else {
            return "Error(" + mInstName + ") :   Invalid Parameter Designate. Parameter =  " + args[2] + ".\n";
        }
    } else if (args[1] == "MessageLevel") { 
        std::string ret = "";
        if (args.size() == 2 ){// read mode
            std::map<std::string, bool>::iterator it;
            for (it = mMessageLevel.begin(); it != mMessageLevel.end(); it++) {
                if ( it->second == true ) {
                    ret += " " + it->first;
                }
            }
        } else if (args.size() == 3) {// write mode
            // clear current setting
            std::map<std::string, bool>::iterator it;
            for (it = mMessageLevel.begin(); it != mMessageLevel.end(); it++) {
                mMessageLevel[(*it).first] = false;
            }

            // update to new setting
            std::vector<std::string> arg_vec = Str2Vec(args[2], '|');
            std::vector<std::string>::iterator _it;
            for (_it = arg_vec.begin(); _it != arg_vec.end(); _it++) {
                mMessageLevel[*_it] = true;
            }
            ret = "NULL";
        } else {
            ret = "Error(" + mInstName + ") :   Invalid Number Of Parameter Input.\n";
        }
        return ret;
    }

    return "";
}

//convert string to vector
std::vector<std::string> Ccpu::Str2Vec(std::string str, const char sep)
{
    std::vector<std::string> buf;
    std::string::size_type index = 0;

    for (unsigned int i=0 ; i<str.size() ; i++) {
        if (str[i] == sep) {
            buf.push_back(str.substr(index, i-index));
            index = i+1;
        }
    }
    buf.push_back(str.substr(index));
    return buf;
}


//check and process commands of cpu
std::string Ccpu::CpuCommandProcess(const std::vector<std::string> &args)
{
    if (args[1] == "status" || args[1] == "st" || args[1] == "DumpProfile") { 
        CpuFsStateDisplay();
        return "NULL";
    } else if (args[1] == "breakpoint" || args[1] == "bp") {
        unsigned int addr ;
        bool check_addr =  num_check(args[2],&addr);
        if (check_addr == true) {
            CpuBreakPointAdd(addr,1);
            return "NULL"; 
        } else {
            return "Error(" + mInstName + ") :   Invalid Parameter Designate. Parameter = " + args[2] + ".\n";
        }
    } else if (args[1] == "breakaddr" || args[1] == "bp-addr") {
        unsigned int saddr ;
        bool check_saddr = num_check(args[2],&saddr);
        unsigned int eaddr;
        bool check_eaddr = num_check(args[3],&eaddr);
        unsigned int acctype = 0;
        if (check_saddr == true && check_eaddr == true) {
            if ( args[4] == "R/W" || args[4] == "r/w") {
                acctype = 0;	// Read Access.
            } else if (args[4] == "R" || args[4] == "r") {
                acctype = 1;      // Read Access.
            } else if (args[4] == "W" || args[4] == "w") {
                acctype = 2;      // Write Access.
            } else {
                return "Error(" + mInstName + ") :   Invalid Parameter Designate. Parameter = " + args[4] + ".\n";
            }
            CpuBreakAccessAdd(saddr, eaddr, (MemRestrictType)acctype);
            return "NULL";
        } else {
            return "Error(" + mInstName + ") :   Invalid Parameter Designate. Parameter = " + args[2] + args[3] + ".\n";
        }
    } else if (args[1] == "register" || args[1] == "r") {
        CpuRegisterDisplay(stdout);
        return "NULL";
    } else if (args[1] == "breakpoint_display" || args[1] == "bpd") {
        CpuBreakPointDisplay();
        return "NULL";
    } else if (args[1] == "breakpoint_enable" || args[1] == "bpe") {
        return CpuSetBpEnable(args);
    } else if (args[1] == "break_access_display") {
        CpuBreakAccessDisplay();
        return "NULL";
    } else if (args[1] == "break_access_enable" ) {
        return CpuSetBpAddrEnable(args);
    } else if (args[1] == "break_exception_display" || args[1] == "bed" ) {
        CpuDisplayExceptionBreak ();
        return "NULL";
    } else if (args[1] == "break_exception" || args[1] == "be" ) {
        if (args.size() == 3) {
            unsigned int evtcode;
            bool check_evtcode = num_check(args[2],&evtcode);
            if (check_evtcode == true) {
                CpuSetExceptionBreak (evtcode, 1);
                return "NULL";
            } else {
                return "Error(" + mInstName + ") :   Invalid Parameter Designate. Parameter =  " + args[2] + ".\n";
            }
        } else if (args.size() == 4) {
            unsigned int evtcode;
            bool check_evtcode = num_check(args[2],&evtcode);
            unsigned int excode;
            bool check_excode  = num_check(args[3],&excode);
            if (check_evtcode == true && check_excode == true) {
                unsigned int flag;
                if (excode == 0xE){
                    flag = 1;
                } else if (excode == 0xD){
                    flag = 0;
                } else {
                    re_printf("error", "Error(%s) :   Invalid Parameter Designate. Usage: break_exception|be [evtcode] {E|D}\n" , this->basename());
                }
                CpuSetExceptionBreak (evtcode, flag);
                return "NULL";
            } else {
                return "Error(" + mInstName + ") :   Invalid Parameter Designate. Parameter =  " + args[2] + args[3] + ".\n";
            } 
        } else {
            return "Error(" + mInstName + ") :   Invalid Number Of Parameter Input.\n";
        }
    } else if (args[1] == "breaksleep" || args[1] == "bslp" ) {
        if (args.size() == 2) {
            CpuBreakSleepSet (1);
            return "NULL";
        } else if (args.size() == 3) {
            unsigned int slptime;
            bool check_slptime = num_check(args[2],&slptime);
            if (check_slptime == true) {
                CpuBreakSleepSet ((unsigned int)slptime);
                return "NULL";
            } else {
                return "Error(" + mInstName + ") :   Invalid Parameter Designate. Parameter =  " + args[2] + ".\n";
            }
        } else {
            return "Error(" + mInstName + ") :   Invalid Number Of Parameter Input.\n";
        }
    }
 
    return "";
}

//check and process control simulation commands
std::string Ccpu::CtrlSimCommand(const std::vector<std::string> &args)
{
#ifndef CWR_SYSTEMC
    if (args[1] == "GO" || args[1] == "go") {
        if (args.size() == 2) {
            if(cmd_handler != NULL)  cmd_handler->setContinue();
            return "NULL";
        } else if (args.size() == 3) {
            unsigned int rtime;
            bool check_rtime = num_check(args[2],&rtime);
            if (check_rtime == true) {
                m_run_time = rtime*1000;
                m_run_time_check = true;
                if(cmd_handler != NULL)  cmd_handler->setContinue();
                return "NULL";
            } else {
                return "Error(" + mInstName + ") :   Invalid Parameter Designate. Parameter =  " + args[2] + ".\n";
            }
        } else {
            return "Error(" + mInstName + ") :   Invalid Number Of Parameter Input.\n";
        }
    } else if (args[1] == "QUIT" || args[1] == "quit") {
        CpuCedarQuit();
        sc_stop();
        return "NULL";
    } else if (args[1] == "reset") { 
        HardReset ();
        return "NULL";
    } else if (args[1] == "cmd_bst") {
        if (args.size() == 3) {
            unsigned int break_time;
            bool check_time = num_check(args[2],&break_time);
            if (check_time == true) {
                BreakSystemTimeSet(break_time*1000);
                BreakSystemTimeEnable(1);
                return "NULL";
            } else {
                return "Error(" + mInstName + ") :   Invalid Parameter Designate. Parameter = " + args[2] + ".\n";
            }
        } 
        return "Error(" + mInstName + ") :   Invalid Number Of Parameter Input.\n";
    } else if (args[1] == "max") {
        if (args.size() == 3) {
            unsigned int maxValue;
            bool check_value = num_check(args[2],&maxValue);
            if (check_value == true) {
                CpuBreakMaxSet(maxValue);
                return "NULL";
            } else {
                return "Error(" + mInstName + ") :   Invalid Parameter Designate. Parameter =  " + args[2] + ".\n";
            }
        } 
        return "Error(" + mInstName + ") :   Invalid Number Of Parameter Input.\n";
    } else if (args[1] == "step" || args[1] == "s") {
        if (args.size() == 2) {
            m_step_run = 1;
            m_step_check = 1;
            if(cmd_handler != NULL) cmd_handler->setContinue();
            return "NULL";
        } else if (args.size() == 3) {
            unsigned int stime;
            bool check_stime = num_check(args[2],&stime);
            if ((check_stime == true) && (stime != 0)) {
                m_step_run = stime;
                m_step_check = 1;
                if(cmd_handler != NULL) cmd_handler->setContinue();
                return "NULL";
            } else {
                return "Error(" + mInstName + ") :   Invalid Parameter Designate. Parameter =  " + args[2] + ".\n";
            }
        } else {
            return "Error(" + mInstName + ") :   Invalid Number Of Parameter Input.\n";
        }
    }
    return "";
#endif
}

//reset cpu
void Ccpu::HardReset()
{
    CpuCsHardReset ();

    CpuSetCpuEnable (CPU_ON);

    m_step_count = 0;
    m_step_run = 0;
    m_step_check = false;
    m_run_time = 0;
    m_run_time_check = false;
    m_break_system_time = 0;
    m_break_system_time_enable = 0;
} 

//set break system time 
void Ccpu::BreakSystemTimeSet(const unsigned int break_time)
{
    m_break_system_time = break_time;
}

//set enable/disable break system time
void Ccpu::BreakSystemTimeEnable(const unsigned int enable)
{
    m_break_system_time_enable = enable;
}

//print usage of cpu's command
std::string Ccpu::PrintSscHelp()
{
    std::string output_msg = "";
    output_msg +=  " ---command---\n";
    output_msg +=  "      INIT                                               Set INIT for cpu\n";
    output_msg +=  "      REGSET{value}                                      Set value for register\n";
    output_msg +=  "      ENDIAN{BIG|LITTLE}                                 Set endian for cpu\n";
    output_msg +=  "      CPUTYPE{SH4A|SH3ADSP}                              Set cpu tpye\n";
    output_msg +=  "      ILRAMSIZE{NONE|4K|8K|16K|32K}                      Set ILRAM size\n";
    output_msg +=  "      LRAMSIZE|ORAMSIZE{NONE|16K|32K|64K|128K}           Set LRAM size\n";
    output_msg +=  "      URAMSIZE{NONE|64K|128K|512K|1024K}                 Set URAM size\n";
    output_msg +=  "      ICACHESIZE{NONE|8K|16K|32K|64K}                    Set ICACHE size\n";
    output_msg +=  "      OCACHESIZE{NONE|8K|16K|32K|64K}                    Set OCACHE size\n";
    output_msg +=  "      DEBUGMODE{ON|OFF}                                  Set debug mode\n";
    output_msg +=  "      MessageLevel{fatal|error}                          Set message output level\n";
    output_msg +=  "      status|st|DumpProfile                              Command to dump status of cpu\n";
    output_msg +=  "      breakpoint|bp{value}                               Set breakpoint\n";
    output_msg +=  "      breakaddr|bp-addr{address}{address}{W/R|R|W}       Set address range for breakpoint\n";
    output_msg +=  "      register|r                                         Display register value\n";
    output_msg +=  "      breakpoint_display|bpd                             Display breakpoint\n";
    output_msg +=  "      breakpoint_enable|bpe{Enable|Disable}{number}{ALL} Enable|Disable breakpoint\n";
    output_msg +=  "      break_access_display                               Display current erea breakpoint\n";
    output_msg +=  "      break_access_enable{Enable|Disable}{number}{ALL}   Enable|Disable erea breakpoint\n";
    output_msg +=  "      break_exception_display|bed                        Display exception breakpoint\n";
    output_msg +=  "      break_exception|be{evtcode}{E|D}                   Set break exception\n";
    output_msg +=  "      breaksleep|bslp{number}                            Set break sleep\n";
    output_msg +=  "      mem_load{file name}{address}                       Load a data to memory from a file\n";
    output_msg +=  "      mem_save{file name}{address}{address}              Save specified memory area to file\n";
    output_msg +=  "      mem_dump{address}{address}{size}{file name}        Dump data in specified memory area to file\n";
#ifndef CWR_SYSTEMC     
    output_msg +=  "      go|GO{number}                                      Start simulation or run until specified breakpoint time\n";
    output_msg +=  "      quit|QUIT                                          Quit simulation\n";
    output_msg +=  "      reset                                              Hard reset cpu\n";
    output_msg +=  "      step|s{number}                                     Step execution\n";
#endif
    output_msg +=  "      help|h|?                                           Dump command's usages\n";
    return output_msg;
}

//get file name and file line number
void Ccpu::get_fileline(std::string filename, int line_number) 
{
    mFileName = filename;
    mLineNum  = line_number;
}

void Ccpu::_re_printf(std::string group, const char *message, ...) 
{
    // message group check
    if (mMessageLevel[group] == false) return;
    if (message == NULL) return;
    
    // print header
#ifdef SYSTEMC_H
    std::string cur_time = sc_time_stamp().to_string();
#else
    std::string cur_time = "";
#endif
    printf("%8s [%20s] (%10s) ", group.c_str(), cur_time.c_str(), mInstName.c_str());

    // print body
    va_list argptr;
    va_start(argptr, message);
    if (argptr != NULL) vprintf(message, argptr);
    
    // print footer
    if (group == "fatal" || group == "error" || group == "warning" ||group == "info") {
        printf(" [%s:%d]\n", mFileName.c_str(), mLineNum);
    } else {
        printf("\n");
    }    
    va_end(argptr);
    fflush(stdout);
    fflush(stderr);
    
    if (group == "fatal") {
        exit(1);
    }
}

//handle setting endian
std::string Ccpu::handleSetEndian(const std::string str)
{
    if (str == "BIG") {
        CpuSetEndian (CPU_ENDIAN_BIG);
        return "NULL";
    } else if (str == "LITTLE") {
        CpuSetEndian (CPU_ENDIAN_LITTLE);
        return "NULL";
    }
    return "Error(" + mInstName + " ) :   Invalid Endian Designate. Endian =  " + str + ".\n";
}

//handle setting cpu type
std::string Ccpu::handleSetCpuType(const std::string str)
{
    if (str == "SH4A") {
        CpuSetCpuType (SH4A);
        return "NULL";
    } else if  (str == "SH3ADSP") {
        CpuSetCpuType (SH3ADSP);
        return "NULL";
    }
    return "Error(" + mInstName + " ) :  Invalid CPU Type Designate. CPU Type = " + str + ".\n";
}

//handle setting size of ILram
std::string Ccpu::handleSetILramSize(const std::string str)
{
    if (str == "NONE") {
        CpuSetILramSize (ILRAM_NONE);
        return "NULL";
    } else if (str == "4K") {
        CpuSetILramSize (ILRAM_4K);
        return "NULL";
    } else if (str == "8K") {
        CpuSetILramSize (ILRAM_8K);
        return "NULL";
    } else if (str == "16K") {
        CpuSetILramSize (ILRAM_16K);
        return "NULL";
    } else if (str == "32K") {
        CpuSetILramSize (ILRAM_32K);
        return "NULL";
    }
      
    return "Error(" + mInstName + ") :  Invalid IL Ram Size Designate. IL Ram Size = " + str + ".\n";
}

//handle setting size of Lram
std::string Ccpu::handleSetLramSize(const std::string str)
{
    if (str == "NONE") {
        CpuSetLramSize (LRAM_NONE);
        return "NULL";
    } else if (str == "16K") {
        CpuSetLramSize (LRAM_16K);
        return "NULL";
    } else if (str == "32K") {
        CpuSetLramSize (LRAM_32K);
        return "NULL";
    } else if (str == "64K") {
        CpuSetLramSize (LRAM_64K);
        return "NULL";
    } else if (str == "128K") {
        CpuSetLramSize (LRAM_128K);
        return "NULL";
    }
       
    return "Error(" + mInstName + ") :  Invalid O Ram Size Designate. O Ram Size =  " + str + ".\n";
}

//handle setting size of Uram
std::string Ccpu::handleSetUramSize(const std::string str)
{
    if (str == "NONE") {
        CpuSetUramSize (URAM_NONE);
        return "NULL";
    } else if (str == "64K") {
        CpuSetUramSize (URAM_64K);
        return "NULL";
    } else if (str == "128K") {
        CpuSetUramSize (URAM_128K);
        return "NULL";
    } else if (str == "256K") {
        CpuSetUramSize (URAM_256K);
        return "NULL";
    } else if (str == "512K") {
        CpuSetUramSize (URAM_512K);
        return "NULL";
    } else if (str == "1024K") {
        CpuSetUramSize (URAM_1024K);
        return "NULL";
    }
       
    return "Error(" + mInstName + ") :  Invalid U Ram Size Designate. U Ram Size =  " + str + ".\n";
}

//handle setting size of Icache
std::string Ccpu::handleSetIcacheSize(const std::string str)
{
    if (str == "NONE") {
        CpuSetIcacheSize (CACHE_NONE);
        return "NULL";
    } else if (str == "8K") {
        CpuSetIcacheSize (CACHE_8K);
        return "NULL";
    } else if (str == "16K") {
        CpuSetIcacheSize (CACHE_16K);
        return "NULL";
    } else if (str == "32K") {
        CpuSetIcacheSize (CACHE_32K);
        return "NULL";
    } else if (str == "64K") {
        CpuSetIcacheSize (CACHE_64K);
        return "NULL";
    }
       
    return "Error(" + mInstName + ") :  Invalid ICACHE Size Designate. CACHE Size =  " + str + ".\n";
}

//handle setting size of Ocache
std::string Ccpu::handleSetOcacheSize(const std::string str)
{
    if (str == "NONE") {
        CpuSetOcacheSize (CACHE_NONE);
        return "NULL";
    } else if (str == "8K") {
        CpuSetOcacheSize (CACHE_8K);
        return "NULL";
    } else if (str == "16K") {
        CpuSetOcacheSize (CACHE_16K);
        return "NULL";
    } else if (str == "32K") {
        CpuSetOcacheSize (CACHE_32K);
        return "NULL";
    } else if (str == "64K") {
        CpuSetOcacheSize (CACHE_64K);
        return "NULL";
    }
       
    return "Error(" + mInstName + ") : Invalid OCACHE Size Designate. CACHE Size =  " + str + ".\n";
}

//handle loading input file
std::string Ccpu::handleMemLoad(const std::vector<std::string>& args)
{
    char         mem_load_fname[1024] = {"\0"};
    unsigned int mem_load_addr = 0x0;
    bool check_load_addr;
    switch( args.size() ) {
        case 2: 
            return "Error(" + mInstName + ") : mem_load No File Name.\n";
        case 3:
            strcpy(mem_load_fname, args[2].c_str());
            mem_load_addr = 0x0;
            break;
        case 4:
            strcpy(mem_load_fname, args[2].c_str());
            check_load_addr = num_check(args[3],&mem_load_addr);
            if (check_load_addr == false) {
                return "Error(" + mInstName + ") : Invalid mem_load address Designate. Address = " + args[3] + ".\n"; 
            }
            break;
        default:
            return "Error(" + mInstName + ") :   Invalid Number Of Parameter Input.\n";
    }
    MemLoad((const char *)mem_load_fname, mem_load_addr);
    return "NULL";
}

//handle memory saving to output file  
std::string Ccpu::handleMemSave(const std::vector<std::string>& args)
{
    char         mem_save_fname[1024] = {"\0"};
    unsigned int mem_save_saddr = 0x0;
    unsigned int mem_save_size = 0x0;
    bool check_addr;
    bool check_saddr;
    bool check_eaddr;
    
    switch( args.size() ) {
        case 2: 
            return "Error(" + mInstName + ") : mem_save No File Name.\n";
        case 3:
            strcpy(mem_save_fname, args[2].c_str());
            re_printf("warning", "Warning(%s) :   mem_save No Save Address.\n" , this->basename() );
            break;
        case 4:
            strcpy(mem_save_fname, args[2].c_str());
            check_addr = num_check(args[3],&mem_save_saddr);
            if (check_addr == false) {
                return "Error(" + mInstName + ") : Invalid mem_save address Designate. Address = " + args[3] + ".\n"; 
            }
            re_printf("warning", "Warning(%s) :   mem_save No Save Size.\n" , this->basename() );
            break;
        case 5: 
            strcpy(mem_save_fname, args[2].c_str());
            check_saddr = num_check(args[3],&mem_save_saddr);
            check_eaddr = num_check(args[4],&mem_save_size);
            if (check_saddr == false || check_eaddr == false) {
                return "Error(" + mInstName + ") : Invalid mem_save address Designate. Address = " + args[3] + args[4] + ".\n"; 
            }
            break;
        default:
            return "Error(" + mInstName + ") :   Invalid Number Of Parameter Input.\n";
    }
    MemSave((const char *)mem_save_fname, mem_save_saddr, mem_save_size);
    return "NULL";
}

//handle memory dumping to output file  
std::string Ccpu::handleMemDump(const std::vector<std::string>& args)
{
    char         mem_dump_fname[1024] = {"\0"};
    unsigned int mem_dump_saddr = 0x0;
    unsigned int mem_dump_eaddr = 0x0;
    unsigned int size = 1;
    FILE *pdump;
    errno_t err;

    if (args.size() == 6) {
        bool check_saddr = num_check(args[2],&mem_dump_saddr);
        bool check_eaddr = num_check(args[3],&mem_dump_eaddr);
        bool check_size = num_check(args[4],&size);
        if (check_saddr == false || check_eaddr == false || check_size == false) {
            return "Error(" + mInstName + ") : Invalid mem_dump Parameter Designate. Parameter = " + args[2] + args[3] + args[4] +".\n"; 
        }
        strcpy(mem_dump_fname, args[5].c_str());
        if (strcmp(mem_dump_fname,"stdout")==0) {
            pdump = stdout;
        } else {
            err  = fopen_s( &pdump, mem_dump_fname, "wb" );
            if((unsigned int)err != 0) {
                re_printf("error", "Error(%s) :   file open to memmory dump error. file =  %s.\n" , this->basename() , mem_dump_fname );
                return "Error(" + mInstName + ") : file open to memory dump error. file = " + args[5] + ".\n";
            }
        }
    } else {
        return "Error(" + mInstName + ") :   Invalid Number Of Parameter Input.\n";
    }

    if (pdump == NULL) {
        return "Error(" + mInstName + ") : Invalid mem_dump file Designate.\n";
    }

    CpuMemoryDisplay( mem_dump_saddr, mem_dump_eaddr, (MemDisplaySize)size, pdump);
    return "NULL";
}


//Set break point enable/disable 
std::string Ccpu::CpuSetBpEnable(const std::vector<std::string>& args)
{
    int enable = 1;
    if ( args[2] == "Enable" ||  args[2] == "enable") {
        enable = 1;
    } else if (args[2] == "Disable" || args[2] == "disable") {
        enable = 0;
    } else {
        return "Error(" + mInstName + ") : Invalid Parameter Designate. Parameter = " + args[2] + ".\n";
    }
    unsigned int index;
    bool check_index = num_check(args[3],&index);
    if (check_index == false) {
        return "Error(" + mInstName + ") : Invalid Parameter Designate. Parameter = " + args[3] + ".\n";
    }
    unsigned int all = 0;
    if (args.size() >= 5){
        if (args[4] == "ALL" || args[4] == "all" ) {
            all = 1;   // Select all break point.
        }
    }
    CpuBreakPointEnable((unsigned int)enable, (unsigned int)index, (unsigned int)all);
    return "NULL";
}

//Set break address enable/disable 
std::string Ccpu::CpuSetBpAddrEnable(const std::vector<std::string>& args)
{
    int enable = 1;
    if ( args[2] == "Enable" || args[2] == "enable") {
        enable = 1;
    } else if (args[2] == "Disable" || args[2] =="disable") {
        enable = 0;
    } else {
        return "Error(" + mInstName + ") : Invalid Parameter Designate. Parameter = " + args[2] + ".\n";
    }
    unsigned int index;
    bool check_index = num_check(args[3],&index);
    if (check_index == false) {
        return "Error(" + mInstName + ") : Invalid Parameter Designate. Parameter = " + args[3] + ".\n";
    }
    unsigned int all = 0;
    if (args.size() >= 5){
        if (args[4] == "ALL" || args[4] == "all") {
            all = 1;   // Select all break point.
        }
    }
    CpuBreakAccessEnable((unsigned int)enable, (unsigned int)index, (unsigned int)all);
    return "NULL";
}

//memload function
void Ccpu::MemLoad(const char *fname, const unsigned int in_addr)
{
    if(fname == NULL){
        re_printf("error", "Error(%s) : function \"MemLoad\" Get NULL Pointer.\n",this->basename());
        sc_stop();
    }
#if 0 // new message
    re_printf("info", "> %s::MemLoad    : fname = \"%s\", addr = 0x%08X\n" , this->basename() , fname, in_addr );
#else // legacy message
    printf("> %s::MemLoad    : fname = \"%s\", addr = 0x%08X\n" , this->basename() , fname, in_addr );
    printf("> %s::MemLoad    : successful.\n" , this->basename() );
#endif
    errno_t err;
    FILE *fin = NULL;
    err  = fopen_s( &fin, fname, "r" );
    if( err !=0 ) {
        re_printf("error", "> %s::MemLoad    : file open error.\n" , this->basename() );
        sc_stop();
    }

    if(FileStypeLoad(fname) != 0){
        if(FileStypeLoad(fname) == 1){
            re_printf("info", "> %s::MemLoad Stype Format   : successful.\n" , this->basename() );
        } else {
            re_printf("error", "> %s::MemLoad Stype Format   : error.\n" , this->basename() );
        }
    } else if (FileElfLoad(fname)){
        re_printf("info", "> %s::MemLoad Elf Format    : successful.\n" , this->basename() );
    } else if (FileBinLoad(fname,in_addr)){
        re_printf("info", "> %s::MemLoad Binary Format   : successful.\n" , this->basename() );
    }
}

//File load Stype
bool Ccpu::FileBinLoad(const char *fname, const unsigned int in_addr) 
{
    unsigned int  wr_addr = in_addr;
    unsigned char wr_buf[1024];
    memset(wr_buf, 0, sizeof(wr_buf));
 
    int rd_size = 0;
    int wr_time = 0;
 
    FILE *fin = NULL;
    if (fname != NULL) fopen_s( &fin, fname, "rb" );
    do {
        if (fin != NULL) rd_size = (int)fread(wr_buf, 1, 1024, fin);
        wr_time = rd_size / MEMACCESS_LONGWORD;
 
        for (int i = 0; i < wr_time; i++) {
            if (wr_addr < RAM_MAX_ADDR) {
                if ( CpuGetEndian() == CPU_ENDIAN_BIG ) {
                    ByteSwap32((unsigned int *) (wr_buf + (MEMACCESS_LONGWORD * i)),MEMACCESS_LONGWORD);
                }
                BusAccWriteDebug(wr_addr, (unsigned long *) (wr_buf + (MEMACCESS_LONGWORD * i)), MEMACCESS_LONGWORD);
            }
            wr_addr += MEMACCESS_LONGWORD;
        }
    } while (rd_size == 1024);
 
    if(fin != NULL) fclose(fin);
    return true;
}

//File load Stype
int Ccpu::FileStypeLoad(const char *filename)
{
    FILE     *p_loadfile;
    if (filename != NULL) p_loadfile = fopen (filename, "r");
    if (p_loadfile == NULL) return 2;

    char record_buff[256];
    int record_type;
    unsigned int ret_value;
    while (1) {
        if ( fgets (record_buff, 255, p_loadfile) == NULL ) {
            if (cedarErrno != E_OK) {
                ret_value = 2;
                return (unsigned int)ret_value;
            } else {
                ret_value = 1;
                return (unsigned int)ret_value;
            }
        }
        if (record_buff[0] == '\n' || (record_buff[0] == '\r' && record_buff[1] == '\n')) {
            continue;
        }
        
        if (record_buff[0] != 'S') {
            ret_value = 0;
            return (unsigned int)ret_value;
        }

        record_type = (int)record_buff[1] - '0';
        switch (record_type) {
            case 0:        
            case 7:        
            case 8:
            case 9:
                break;
            case 1:       
            case 2:
            case 3:
                FileStypeDataLoad (record_buff);
                break;
            default:        /* STYPE Format Error */
                ErrorCodeSet (E_FILE_FORMAT);
                break;
        }
    }

}

//File date load Stype
void Ccpu::FileStypeDataLoad (std::string cur_line)
{
    unsigned int addr_size;

    // pick up data and stock internal memmory
    if( cur_line.substr(0, 2) == "S1" ) {
        addr_size = 4;
    }
    else if( cur_line.substr(0, 2) == "S2" ) {
        addr_size = 6;
    }
    else if( cur_line.substr(0, 2) == "S3" ) {
        addr_size = 8;
    }
    
    char *ptr;
    std::string p = cur_line.substr(4, addr_size);
    unsigned int addr = (unsigned int)strtoul(p.c_str(), &ptr, 16);
    
    unsigned char *data = new unsigned char[(cur_line.size()-3) - (4+addr_size)];
    unsigned int index = 0;
    for( unsigned int i=4+addr_size ; i<cur_line.size()-2 ; i+=2 ) {
        char *_ptr;
        std::string _p = cur_line.substr(i, 2);
        if (data != NULL) data[index++] = (unsigned char)strtoul(_p.c_str(), &_ptr, 16);
    }
    
    unsigned int rd_size = (cur_line.size() - 6 - addr_size)/2;
    unsigned int wr_time = rd_size / MEMACCESS_LONGWORD;
    unsigned int wr_addr = addr;
 
    for (unsigned int i = 0; i < wr_time; i++) {
        if (wr_addr < RAM_MAX_ADDR) {
            if ( CpuGetEndian() == CPU_ENDIAN_BIG ) {
                ByteSwap32((unsigned int *) (&data[MEMACCESS_LONGWORD * i]),MEMACCESS_LONGWORD);
            }
            BusAccWriteDebug(wr_addr, (unsigned long *) (&data[MEMACCESS_LONGWORD * i]), MEMACCESS_LONGWORD);
        }
        wr_addr += MEMACCESS_LONGWORD;
    }
}

//File ELF load
bool Ccpu::FileElfLoad(const char *filename) 
{
    unsigned char *data;
    unsigned int size;
 
    FILE *fp = NULL;
    if (filename != NULL) fopen_s(&fp, filename, "rb");
 
    if (fp != NULL) fseek(fp, 0, SEEK_END);
    size = (unsigned int)ftell(fp);
    fseek(fp, 0, SEEK_SET);
    data = new unsigned char[size];
    if (data != NULL) fread(data, size, sizeof(char), fp);
    if (fp != NULL) fclose(fp);
 
    Elf_Ehdr *Ehdr = (Elf_Ehdr *)data;
    if (Ehdr == NULL) return false;
 
    // Check ELF Header Table
    if (!ChkEhdr(Ehdr)) {
        return false;
    }
 
    // Check Program Header Table
    unsigned int Ehdr_e_phnum = swap_data(Ehdr->e_ident[EI_DATA], sizeof(Ehdr->e_phnum), (unsigned int)Ehdr->e_phnum); 
    for (unsigned int i=0 ; i<Ehdr_e_phnum ; i++) {
        unsigned int Ehdr_e_ehsize = swap_data(Ehdr->e_ident[EI_DATA], sizeof(Ehdr->e_ehsize), (unsigned int)Ehdr->e_ehsize); 
        unsigned int Ehdr_e_phentsize = swap_data(Ehdr->e_ident[EI_DATA], sizeof(Ehdr->e_phentsize), (unsigned int)Ehdr->e_phentsize);
 
        Elf_Phdr *Phdr = (Elf_Phdr *)(&data[Ehdr_e_ehsize + i*Ehdr_e_phentsize]);

        if (!ChkPhdr(Phdr,Ehdr->e_ident[EI_DATA])) {
            return false;
        } else {
            unsigned int rd_size = swap_data(Ehdr->e_ident[EI_DATA], sizeof(Phdr->p_filesz), (unsigned int)Phdr->p_filesz);
            unsigned int wr_time = rd_size / MEMACCESS_LONGWORD;
            unsigned int in_addr = swap_data(Ehdr->e_ident[EI_DATA], sizeof(Phdr->p_vaddr), (unsigned int)Phdr->p_vaddr);
            
            for (unsigned int _i = 0; _i < wr_time; _i++) {
                if (in_addr < RAM_MAX_ADDR) {
                    if ( CpuGetEndian() == CPU_ENDIAN_BIG ) {
                        ByteSwap32((unsigned int *)(&data[swap_data(Ehdr->e_ident[EI_DATA], sizeof(Phdr->p_offset), (unsigned int)Phdr->p_offset)] + (MEMACCESS_LONGWORD * _i)),MEMACCESS_LONGWORD);
                    }
                    BusAccWriteDebug(in_addr, (unsigned long *)(&data[swap_data(Ehdr->e_ident[EI_DATA], sizeof(Phdr->p_offset), (unsigned int)Phdr->p_offset)] + (MEMACCESS_LONGWORD * _i)), MEMACCESS_LONGWORD);
                }
                in_addr += MEMACCESS_LONGWORD;
            }
        }
    }
    return true;
}

unsigned int Ccpu::swap_data(const unsigned char endian, const unsigned int size, unsigned int value) 
{
    unsigned int temp = value;
    if (endian == (unsigned int)ELFDATA2MSB) {
        temp = 0;
        for (unsigned int i=0 ; i<size ; i++) {
            temp |= ((value>>(i*8))&0xFF)<<((size-i-1)*8);
        }
    }
    return temp;
}

// [ELF] Header check
bool Ccpu::ChkEhdr (const Elf_Ehdr *Ehdr) 
{
    if (Ehdr == NULL) return false;
    //
    // e_ident check
    //
    if ( (Ehdr->e_ident[EI_MAG0] != ELFMAG0)
        || (Ehdr->e_ident[EI_MAG1] != ELFMAG1)
        || (Ehdr->e_ident[EI_MAG2] != ELFMAG2)
        || (Ehdr->e_ident[EI_MAG3] != ELFMAG3)) {
        return false;
    }
 
    if ( (Ehdr->e_ident[EI_CLASS] != ELFCLASSNONE)
        && (Ehdr->e_ident[EI_CLASS] != ELFCLASS32)
        && (Ehdr->e_ident[EI_CLASS] != ELFCLASS64)) {
        return false;
    }
 
    if ( (Ehdr->e_ident[EI_DATA] != ELFDATANONE)
        && (Ehdr->e_ident[EI_DATA] != ELFDATA2LSB)
        && (Ehdr->e_ident[EI_DATA] != ELFDATA2MSB)) {
        return false;
    }
 
    if ( (Ehdr->e_ident[EI_VERSION] != EV_NONE)
        && (Ehdr->e_ident[EI_VERSION] != EV_CURRENT)) {
        return false;
    }

    unsigned int Ehdr_e_type = swap_data(Ehdr->e_ident[EI_DATA], sizeof(Ehdr->e_type), (unsigned int)Ehdr->e_type); 
    //
    // e_type check
    //
    if ( (Ehdr_e_type != ET_NONE)
        && (Ehdr_e_type != ET_REL)
        && (Ehdr_e_type != ET_EXEC)
        && (Ehdr_e_type != ET_DYN)
        && (Ehdr_e_type != ET_CORE)) {
        return false;
    }
 
    unsigned int Ehdr_e_machine = swap_data(Ehdr->e_ident[EI_DATA], sizeof(Ehdr->e_machine), (unsigned int)Ehdr->e_machine); 
    //
    // e_machine check
    //
    if ( (Ehdr_e_machine != EM_NONE         )
        && (Ehdr_e_machine != EM_M32        )
        && (Ehdr_e_machine != EM_SPARC      )
        && (Ehdr_e_machine != EM_386        )
        && (Ehdr_e_machine != EM_68K        )
        && (Ehdr_e_machine != EM_88K        )
        && (Ehdr_e_machine != EM_860        )
        && (Ehdr_e_machine != EM_MIPS       )
        && (Ehdr_e_machine != EM_S370       )
        && (Ehdr_e_machine != EM_MIPS_RS3_LE)
        && (Ehdr_e_machine != EM_PARISC     )
        && (Ehdr_e_machine != EM_VPP500     )
        && (Ehdr_e_machine != EM_SPARC32PLUS)
        && (Ehdr_e_machine != EM_960        )
        && (Ehdr_e_machine != EM_PPC        )
        && (Ehdr_e_machine != EM_PPC64      )
        && (Ehdr_e_machine != EM_S390       )
        && (Ehdr_e_machine != EM_V800       )
        && (Ehdr_e_machine != EM_FR20       )
        && (Ehdr_e_machine != EM_RH32       )
        && (Ehdr_e_machine != EM_RCE        )
        && (Ehdr_e_machine != EM_ARM        )
        && (Ehdr_e_machine != EM_FAKE_ALPHA )
        && (Ehdr_e_machine != EM_SH         )
        && (Ehdr_e_machine != EM_SPARCV9    )
        && (Ehdr_e_machine != EM_TRICORE    )
        && (Ehdr_e_machine != EM_ARC        )
        && (Ehdr_e_machine != EM_H8_300     )
        && (Ehdr_e_machine != EM_H8_300H    )
        && (Ehdr_e_machine != EM_H8S        )
        && (Ehdr_e_machine != EM_H8_500     )
        && (Ehdr_e_machine != EM_IA_64      )
        && (Ehdr_e_machine != EM_MIPS_X     )
        && (Ehdr_e_machine != EM_COLDFIRE   )
        && (Ehdr_e_machine != EM_68HC12     )
        && (Ehdr_e_machine != EM_MMA        )
        && (Ehdr_e_machine != EM_PCP        )
        && (Ehdr_e_machine != EM_NCPU       )
        && (Ehdr_e_machine != EM_NDR1       )
        && (Ehdr_e_machine != EM_STARCORE   )
        && (Ehdr_e_machine != EM_ME16       )
        && (Ehdr_e_machine != EM_ST100      )
        && (Ehdr_e_machine != EM_TINYJ      )
        && (Ehdr_e_machine != EM_X86_64     )
        && (Ehdr_e_machine != EM_PDSP       )
        && (Ehdr_e_machine != EM_FX66       )
        && (Ehdr_e_machine != EM_ST9PLUS    )
        && (Ehdr_e_machine != EM_ST7        )
        && (Ehdr_e_machine != EM_68HC16     )
        && (Ehdr_e_machine != EM_68HC11     )
        && (Ehdr_e_machine != EM_68HC08     )
        && (Ehdr_e_machine != EM_68HC05     )
        && (Ehdr_e_machine != EM_SVX        )
        && (Ehdr_e_machine != EM_ST19       )
        && (Ehdr_e_machine != EM_VAX        )
        && (Ehdr_e_machine != EM_CRIS       )
        && (Ehdr_e_machine != EM_JAVELIN    )
        && (Ehdr_e_machine != EM_FIREPATH   )
        && (Ehdr_e_machine != EM_ZSP        )
        && (Ehdr_e_machine != EM_MMIX       )
        && (Ehdr_e_machine != EM_HUANY      )
        && (Ehdr_e_machine != EM_PRISM      )
        && (Ehdr_e_machine != EM_AVR        )
        && (Ehdr_e_machine != EM_FR30       )
        && (Ehdr_e_machine != EM_D10V       )
        && (Ehdr_e_machine != EM_D30V       )
        && (Ehdr_e_machine != EM_V850       )
        && (Ehdr_e_machine != EM_M32R       )
        && (Ehdr_e_machine != EM_MN10300    )
        && (Ehdr_e_machine != EM_MN10200    )
        && (Ehdr_e_machine != EM_PJ         )
        && (Ehdr_e_machine != EM_OPENRISC   )
        && (Ehdr_e_machine != EM_ARC_A5     )
        && (Ehdr_e_machine != EM_XTENSA     )
        && (Ehdr_e_machine != EM_NUM        ) ) {
        return false;
    }
 
    unsigned int Ehdr_e_version = swap_data(Ehdr->e_ident[EI_DATA], sizeof(Ehdr->e_version), (unsigned int)Ehdr->e_version); 
    //
    // e_version check
    //
    if ( (Ehdr_e_version != EV_NONE    )
        && (Ehdr_e_version != EV_CURRENT ) ) {
        return false;
    }
    return true;
}

// [ELF] Program Header check
bool Ccpu::ChkPhdr (const Elf_Phdr *Phdr, const unsigned char endian) 
{
    unsigned int Phdr_p_type = swap_data(endian, sizeof(Phdr->p_type), (unsigned int)Phdr->p_type); 
    //
    // p_type check
    //
    if ( (Phdr_p_type != PT_NULL   )
        && (Phdr_p_type != PT_LOAD   )
        && (Phdr_p_type != PT_DYNAMIC)
        && (Phdr_p_type != PT_INTERP )
        && (Phdr_p_type != PT_NOTE   )
        && (Phdr_p_type != PT_SHLIB  )
        && (Phdr_p_type != PT_PHDR   )
        && (Phdr_p_type != PT_LOPROC )
        && (Phdr_p_type != PT_HIPROC ) ) {
        return false;
        }
    return true;
}

//memsave function
void Ccpu::MemSave(const char *fname, const unsigned int in_addr, const unsigned int size)
{
    unsigned int  rd_addr = in_addr;
    unsigned char rd_buf[1024];
    memset(rd_buf, 0, sizeof(rd_buf));

    int wr_size = 0;
    int rd_time = 0;

    if(fname == NULL){
        re_printf("error", "Error(%s) : function \"MemSave\" Get NULL Pointer.\n",this->basename());
        sc_stop();
    }

    re_printf("info", "> %s::MemSave    : fname = \"%s\", addr = 0x%08X, size = 0x%08X\n",this->basename() , fname, in_addr, size );

    FILE *fout = NULL;
    errno_t err;

    err  = fopen_s( &fout, fname, "wb" );
    if( err !=0 ) {
        re_printf("error", "> %s::MemSave    : file open error.\n" , this->basename() );
        sc_stop();
    }

    if (fout == NULL) {
        re_printf("error", "> %s::MemSave    : file open error.\n" , this->basename() );
        sc_stop();
    }

    do {
        int i;
        for (i = 0; i < 1024 / MEMACCESS_LONGWORD; i++) {
            if (rd_addr >= in_addr + size) {
                break;
            }
            if (rd_addr < RAM_MAX_ADDR) {
                BusAccReadDebug(rd_addr, (unsigned long *) (rd_buf + (MEMACCESS_LONGWORD * i)), MEMACCESS_LONGWORD);
                if ( CpuGetEndian() == CPU_ENDIAN_BIG ) {
                    ByteSwap32((unsigned int *) (rd_buf + (MEMACCESS_LONGWORD * i)),MEMACCESS_LONGWORD);
                }
            }
            rd_addr += MEMACCESS_LONGWORD;
        }
        rd_time = i;

        wr_size = rd_time * MEMACCESS_LONGWORD;
        if (fout != NULL) fwrite(rd_buf, 1, (size_t)wr_size, fout);
    } while (wr_size == 1024);

    if (fout != NULL) fclose(fout);

    re_printf("info", "> %s::MemSave    : successful.\n" , this->basename() );
}

//Swap byte
void Ccpu::ByteSwap32( unsigned int *p_data , const unsigned int size )
{
    unsigned int buf = 0;
    unsigned int i;
    unsigned char swp_buf[4] = {0,0,0,0};
 
    if(p_data == NULL){
        re_printf("error", "Error(%s) : function \"ByteSwap32\" Get NULL Pointer.\n",this->basename());
        sc_stop();
    }
    swp_buf[ 0 ] = (unsigned char)(*p_data & 0x000000FF);
    swp_buf[ 1 ] = (unsigned char)((*p_data & 0x0000FF00) >>  8);
    swp_buf[ 2 ] = (unsigned char)((*p_data & 0x00FF0000) >> 16);
    swp_buf[ 3 ] = (unsigned char)((*p_data & 0xFF000000) >> 24);
 
    for ( i = 0; i < size; i++ ) {     
        buf = buf << 8;
        buf |= (unsigned int)swp_buf[ i ];
    }
    *p_data = buf;
}

//set cpu parameter
void Ccpu::set_cpu_parameter()
{
#ifdef  CWR_SYSTEMC
    if(icache_size == 0) {
        CpuSetIcacheSize (CACHE_NONE);
    } else if(icache_size == 8) {
        CpuSetIcacheSize (CACHE_8K);
    } else if(icache_size == 16) {
        CpuSetIcacheSize (CACHE_16K);
    } else if(icache_size == 32) {
        CpuSetIcacheSize (CACHE_32K);
    } else if(icache_size == 64) {
        CpuSetIcacheSize (CACHE_64K);
    }

    if(ocache_size == 0) {
        CpuSetOcacheSize (CACHE_NONE);
    } else if(ocache_size == 8) {
        CpuSetOcacheSize (CACHE_8K);
    } else if(ocache_size == 16) {
        CpuSetOcacheSize (CACHE_16K);
    } else if(ocache_size == 32) {
        CpuSetOcacheSize (CACHE_32K);
    } else if(ocache_size == 64) {
        CpuSetOcacheSize (CACHE_64K);
    }

// int isize = icache_size;
// int osize = ocache_size;
#else
    CpuSetIcacheSize (CACHE_NONE);
    CpuSetOcacheSize (CACHE_NONE);
// int isize = 0;
// int osize = 0;
#endif // CWR_SYSTEMC

}
