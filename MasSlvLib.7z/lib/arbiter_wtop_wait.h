// $Id: arbiter_wtop_wait.h v2011_05_12 $
#ifndef __ARBITER_WTOP_WAIT_H
#define __ARBITER_WTOP_WAIT_H

#include "systemc.h"
#include <limits.h>
#include <map>
#include "arbiter_dynamic.h"

// arbiter class
class arbiter_wtop_wait_elm : public arbiter_dynamic_elm {
private:
  std::vector<sc_time> m_time_list;

  sc_time      m_start_time;
  unsigned int m_id;
  unsigned int m_round_pri;

  const unsigned int m_scale1;
  const unsigned int m_scale2;

  // extra information
  arbiter_extra   m_extra;
  arbiter_extra * m_prev_extra;
  arbiter_extra * m_prev_prev_extra;

  unsigned int m_time_level;

public:
  // constructor
  arbiter_wtop_wait_elm(unsigned int id, std::vector<sc_time> time_list)
    : arbiter_dynamic_elm(0,0,SC_ZERO_TIME)
    , m_scale1(10000)
    , m_scale2(100000000)
  {
    m_id = id;
    m_round_pri = 0;
    m_time_list = time_list;

    m_prev_extra      = NULL;
    m_prev_prev_extra = NULL;

    m_time_level = 0;
  }

  virtual arbiter_wtop_wait_elm * clone() const {
    return new arbiter_wtop_wait_elm(*this);
  }

  virtual void request(int priority = -1) {
    m_request = 1;
    m_start_time = sc_time_stamp();

    m_extra.clear();
  }

  void set_extra_info(int value, int flag) {
    m_extra.push_back(value, flag);
  }

  void set_extra_info_size(int size) {
    m_extra.m_size = size;
  }

  void get_extra_info(arbiter_extra & extra) {
    extra = m_extra;
  }

  void set_prev_extra(arbiter_extra * prev_extra, arbiter_extra * prev_prev_extra = NULL) {
    m_prev_extra      = prev_extra;
    m_prev_prev_extra = prev_prev_extra;
  }

  int get_priority() {
    if( !m_request ) return -1;  // no request

    sc_time wait_time = sc_time_stamp() - m_start_time;

    unsigned int time_level;
    for(time_level=0; time_level < m_time_list.size(); time_level++) {
      if(m_time_list[time_level] > wait_time) {
        break;
      }
    }

    unsigned int extra_pri = m_extra.get_priority(m_prev_extra, m_prev_prev_extra);

    m_time_level = time_level;
    return time_level*m_scale2 + extra_pri*m_scale1 + m_round_pri;
  }

  virtual int get_pri_level() {
    return m_time_level;
  }

  void set_win_id(unsigned int id) {
    if(id >= m_id) {
      m_round_pri = id - m_id;
    }
    else {
      m_round_pri = m_scale1 - (m_id - id);
    }

/** LRU **
    if(id == m_id) {
      m_round_pri = 0;
    }
    else {
      m_round_pri++;
    }
*/
  }

};

#endif//__ARBITER_WTOP_WAIT_H
