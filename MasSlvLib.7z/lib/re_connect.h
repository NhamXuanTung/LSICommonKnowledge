// $Id: re_connect.h v2013_01_18 $
// ---------------------------------------------------------------------
// $Id: re_connect.h v2013_01_18 $
//
// Copyright(c) 2012 Renesas Electronics Corporation
// RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
// This program must be used solely for the purpose for which
// it was furnished by Renesas Electronics Corporation. No part of this
// program may be reproduced or disclosed to others, in any
// form, without the prior written permission of Renesas Electronics
// Corporation.
// ---------------------------------------------------------------------

#ifndef __CONNECT_H__
#define __CONNECT_H__
#include <cstdio>
#include <sstream>
#include "systemc.h"

//
// Cre_concat class concat some input ports into an output port. The input
// port type is 1 bool and 2 sc_uint.
// i_port1[0] -> o_port[0:0]  // bool
// i_port1[1] -> o_port[1:1]  // bool
// ...
// i_port2[0] -> o_port[X+ N-1:X  ] // sc_uint<N>
// i_port2[1] -> o_port[X+2N-1:X+N] // sc_uint<N>
// ...
// i_port3[0] -> o_port[Y+ M-1:Y  ] // sc_uint<M>
// i_port3[1] -> o_port[Y+2M-1:Y+M] // sc_uint<M>
// ...
//
template<unsigned int I1_NUM=2,
         unsigned int I2_NUM=0, unsigned int I2_SIZE=0,
         unsigned int I3_NUM=0, unsigned int I3_SIZE=0>
class Cre_concat : public sc_module
{
public:
    sc_in <bool>              *i_port1[I1_NUM];
    sc_in <sc_uint<I2_SIZE> > *i_port2[I2_NUM];
    sc_in <sc_uint<I3_SIZE> > *i_port3[I3_NUM];
    sc_out<sc_uint<I1_NUM+I2_NUM*I2_SIZE+I3_NUM*I3_SIZE> > o_port;

    SC_HAS_PROCESS(Cre_concat);
    Cre_concat(sc_module_name name, unsigned int init_val = 0)
    : sc_module(name)
    , o_port("o_port") {
        //
        // Check template argument relationship
        //
        assert(I1_NUM+I2_NUM+I3_NUM > 0);
        assert(I2_SIZE >= 0);
        assert(I3_SIZE >= 0);

        //
        // Set the output value defined by the 2nd argument
        //
        o_port.initialize(init_val);

        //
        // Declare input ports with name definition
        //
        for (unsigned int i=0 ; i<I1_NUM ; i++) {
            std::ostringstream name_w_num;
            name_w_num << "i_port1_" << i;
            i_port1[i] = new sc_in<bool>(name_w_num.str().c_str());
            assert(i_port1[i] != NULL);
        }

        for (unsigned int i=0 ; i<I2_NUM ; i++) {
            std::ostringstream name_w_num;
            name_w_num << "i_port2_" << i;
            i_port2[i] = new sc_in<sc_uint<I2_SIZE> >(name_w_num.str().c_str());
            assert(i_port2[i] != NULL);
        }

        for (unsigned int i=0 ; i<I3_NUM ; i++) {
            std::ostringstream name_w_num;
            name_w_num << "i_port3_" << i;
            i_port3[i] = new sc_in<sc_uint<I3_SIZE> >(name_w_num.str().c_str());
            assert(i_port3[i] != NULL);
        }

        //
        // Update output port whenever some input ports are changed.
        //
        SC_METHOD(merge_method);
        dont_initialize();
        for (unsigned int i=0 ; i<I1_NUM ; i++) {
            sensitive << *i_port1[i];
        }
        for (unsigned int i=0 ; i<I2_NUM ; i++) {
            sensitive << *i_port2[i];
        }
        for (unsigned int i=0 ; i<I3_NUM ; i++) {
            sensitive << *i_port3[i];
        }
    }

    // Merge all the input ports' value into a output port value
    void merge_method() {
        unsigned int o_val = 0;
        for (unsigned int i=0 ; i<I1_NUM ; i++) {
            o_val += (i_port1[i]->read()) << i;
        }

        for (unsigned int i=0 ; i<I2_NUM ; i++) {
            o_val += (i_port2[i]->read()) << (I1_NUM + i*I2_SIZE);
        }

        for (unsigned int i=0 ; i<I3_NUM ; i++) {
            o_val += (i_port3[i]->read()) << (I1_NUM + I2_NUM*I2_SIZE + i*I3_SIZE);
        }

        o_port = o_val;
    }
};

#if 0
//
// Cre_split class splits an input port into some output ports. The output
// port type is bool. 
// i_port[0:0] -> o_port_0
// i_port[1:1] -> o_port_1
// ...
//
template<unsigned int O_NUM=2>
class Cre_split : public sc_module
{
public:
    sc_in <sc_uint<O_NUM> > i_port;
    sc_out<bool> *o_port[O_NUM];

    SC_HAS_PROCESS(Cre_split);
    Cre_split(sc_module_name name, unsigned int init_val = 0)
    : sc_module(name)
    , i_port("i_port") {
        //
        // Check template argument relationship
        //
        assert(O_NUM  != 0 && O_NUM  < 32);

        //
        // Declare output ports with name definition
        //
        for (unsigned int i=0 ; i<O_NUM ; i++) {
            std::ostringstream name_w_num;
            name_w_num << "o_port_" << i;
            o_port[i] = new sc_out<bool>(name_w_num.str().c_str());
            assert(o_port[i] != NULL);
            o_port[i]->initialize(init_val);
        }

        //
        // Update output port whenever an input port is changed.
        //
        SC_METHOD(split_method);
        dont_initialize();
        for (unsigned int i=0 ; i<O_NUM ; i++) {
            sensitive << i_port;
        }
    }

    // Split an input port's value into some output ports
    void split_method() {
        unsigned int i_val = i_port.read();
        for (unsigned int i=0 ; i<O_NUM ; i++) {
            o_port[i]->write((i_val >> i) & 1);
        }
    }
};

//
// Cre_splits class splits an input port into some output ports. The output
// port type is sc_uint. 
// i_port[0: N-1] -> o_port_0
// i_port[N:2N-1] -> o_port_1
// ...
//
template<unsigned int O_NUM=2, unsigned int O_SIZE=2>
class Cre_splits : public sc_module
{
public:
    sc_in <sc_uint<O_NUM*O_SIZE> > i_port;
    sc_out<sc_uint<O_SIZE> > *o_port[O_NUM];

    SC_HAS_PROCESS(Cre_splits);
    Cre_splits(sc_module_name name, unsigned int init_val = 0)
    : sc_module(name)
    , i_port("i_port") {
        //
        // Check template argument relationship
        //
        assert(O_NUM  != 0 && O_NUM  < 32);
        assert(O_SIZE != 0 && O_SIZE < 32);

        //
        // Declare output ports with name definition
        //
        for (unsigned int i=0 ; i<O_NUM ; i++) {
            std::ostringstream name_w_num;
            name_w_num << "o_port_" << i;
            o_port[i] = new sc_out<sc_uint<O_SIZE> >(name_w_num.str().c_str());
            assert(o_port[i] != NULL);
            o_port[i]->initialize(init_val);
        }

        //
        // Update output port whenever an input port is changed.
        //
        SC_METHOD(split_method);
        dont_initialize();
        for (unsigned int i=0 ; i<O_NUM ; i++) {
            sensitive << i_port;
        }
    }

    // Split an input port's value into some output ports
    void split_method() {
        unsigned int i_val = i_port.read();
        for (unsigned int i=0 ; i<O_NUM ; i++) {
            o_port[i]->write((i_val >> i*O_SIZE) & ((1<<(O_SIZE+1))-1));
        }
    }
};
#endif


//
// Cre_split class splits an input port into some output ports. The output
// port type is 1 bool and 2 sc_uint. 
// i_port[0:0] -> o_port1[0] // bool
// i_port[1:1] -> o_port1[1] // bool
// ...
// i_port[X+ N-1:X  ] -> o_port2[0] // sc_uint<N>
// i_port[X+2N-1:X+N] -> o_port2[1] // sc_uint<N>
// ...
// i_port[Y+ M-1:Y  ] -> o_port3[0] // sc_uint<M>
// i_port[Y+2M-1:Y+M] -> o_port3[1] // sc_uint<M>
// ...
//
template<unsigned int O1_NUM=2,
         unsigned int O2_NUM=0, unsigned int O2_SIZE=0,
         unsigned int O3_NUM=0, unsigned int O3_SIZE=0>
class Cre_split : public sc_module
{
public:
    sc_in <sc_uint<O1_NUM+O2_NUM*O2_SIZE+O3_NUM*O3_SIZE> > i_port;
    sc_out<bool>              *o_port1[O1_NUM];
    sc_out<sc_uint<O2_SIZE> > *o_port2[O2_NUM];
    sc_out<sc_uint<O3_SIZE> > *o_port3[O3_NUM];

    SC_HAS_PROCESS(Cre_split);
    Cre_split(sc_module_name name, unsigned int init_val = 0)
    : sc_module(name)
    , i_port("i_port") {
        //
        // Check template argument relationship
        //
        assert(O1_NUM+O2_NUM+O3_NUM > 0);
        assert(O2_SIZE >=0);
        assert(O3_SIZE >=0);

        //
        // Declare output ports with name definition
        //
        for (unsigned int i=0 ; i<O1_NUM ; i++) {
            std::ostringstream name_w_num;
            name_w_num << "o_port1_" << i;
            o_port1[i] = new sc_out<bool>(name_w_num.str().c_str());
            assert(o_port1[i] != NULL);
            o_port1[i]->initialize(init_val);
        }

        for (unsigned int i=0 ; i<O2_NUM ; i++) {
            std::ostringstream name_w_num;
            name_w_num << "o_port2_" << i;
            o_port2[i] = new sc_out<sc_uint<O2_SIZE> >(name_w_num.str().c_str());
            assert(o_port2[i] != NULL);
            o_port2[i]->initialize(init_val);
        }

        for (unsigned int i=0 ; i<O3_NUM ; i++) {
            std::ostringstream name_w_num;
            name_w_num << "o_port3_" << i;
            o_port3[i] = new sc_out<sc_uint<O3_SIZE> >(name_w_num.str().c_str());
            assert(o_port3[i] != NULL);
            o_port3[i]->initialize(init_val);
        }

        //
        // Update output port whenever an input port is changed.
        //
        SC_METHOD(split_method);
        dont_initialize();
        sensitive << i_port;
    }

    // Split an input port's value into some output ports
    void split_method() {
        unsigned int i_val = i_port.read();
        for (unsigned int i=0 ; i<O1_NUM ; i++) {
            o_port1[i]->write((i_val >> i) & 1);
        }
        for (unsigned int i=0 ; i<O2_NUM ; i++) {
            o_port2[i]->write((i_val >> (O1_NUM+i*O2_SIZE)) & ((1<<(O2_SIZE+1))-1));
        }
        for (unsigned int i=0 ; i<O3_NUM ; i++) {
            o_port3[i]->write((i_val >> (O1_NUM+O2_NUM*O2_SIZE+i*O3_SIZE)) & ((1<<(O3_SIZE+1))-1));
        }
    }
};
#endif//__CONNECT_H__
