# ---------------------------------------------------------------------
# $Id: top_gen_class.py v2017_05_08 $
#
# Copyright(c) 2013-2017 Renesas Electronics Corporation
# Copyright(c) 2013-2017 Renesas Design Vietnam Co., Ltd.
# RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
# This program must be used solely for the purpose for which
# it was furnished by Renesas Electronics Corporation. No part of this
# program may be reproduced or disclosed to others, in any form,
# without the prior written permission of Renesas Electronics
# Corporation.
# ---------------------------------------------------------------------

import re
import os
import sys
import shutil
import subprocess
import modelinfo_parser
import code
DbgLevel = ["INFO", "WARNING", "ERROR"]
emKeepClassType = ["sc_uint", "sc_int", "sc_biguint", "sc_bigint"]
# Interface for Generation
class CGenIF:
 # {{{
    def __init__(self):
        self.mDone = False     # Flag indicates whether keyword was defined successfully or not 

    def CheckMandatory(self):
        if (not self.mDone):
            return [DbgLevel[2], "Lack of " + self.GetKeyword() + " information."]
        else:
            return None

    def CheckValidContent(self, SplitLine, MinLen, MaxLen = -1):                 # Function to check the number of argurments of string
        if (MaxLen ==  -1):
            MaxLen = MinLen

        if (len(SplitLine) < MinLen):
            return [DbgLevel[2],"Lack of argurment."]
        elif(len(SplitLine) > MaxLen):
            return [DbgLevel[2],"Too many arguments."]
        else:
            return None

    def CheckValidValue (self, CheckValue, MacroMap, ClassType, CheckZero):      # Function to check whether macro was defined or not
        return modelinfo_parser.CheckValidValue(CheckValue, MacroMap, ClassType, CheckZero)

    def CheckValidInstanceName (self, CheckInstanceName):                       # Function to check the instance name with quotation mark in BUS_INFO part
        InstanceName = (re.findall("\"[a-zA-Z0-9_]*\"",CheckInstanceName))
        QuoteIndex = CheckInstanceName.split("\"")
        if (len(QuoteIndex) == 3 or len(QuoteIndex) == 1):
            if (len(InstanceName) == 1):
                InstanceName[0] = InstanceName[0].replace("\"","")
                return [InstanceName[0]]
            elif (len(InstanceName) == 0 and CheckInstanceName != "" and len(QuoteIndex) == 1) :
                return [DbgLevel[2],"Instance name must be put in quote."]
            else:
                return [DbgLevel[2],"Invalid instance name."]
        else:
            return [DbgLevel[2],"Too many quotation marks."]

    def ExtractValue (self, StringValue, ClassType):                            # Function to extract the value in string
        return modelinfo_parser.ExtractValue(StringValue, ClassType)

    def AddSCISource (self, Lines, LineIndex, EndKeywordIndex, mSciFile, PrintDebugMsg):
        Keyword = self.GetKeyword()
        if (Lines[LineIndex] == Keyword):
            if (not self.mDone):
                HasContent = False
                for Index in range(LineIndex + 1, EndKeywordIndex + 1):
                    if (Lines[Index] != ""):
                        HasContent = True
                        ErrorMsg   = self.ProcessSCILine(Lines[Index])
                        if (ErrorMsg != None):
                            PrintDebugMsg(mSciFile, Index, ErrorMsg[0], ErrorMsg[1])
#                MandatoryKeyword = ("%TOP_MODULE_INI_LIST","%TOP_MODULE_TGT_LIST","%ADDRESS_MAP")
                MandatoryKeyword = ("%TOP_MODULE_TGT_LIST","%ADDRESS_MAP")  #Modified by Trong Truong
                if (Keyword in MandatoryKeyword):
                    if (not HasContent):
                        ErrMsg = "Lack of " + Keyword + " information."
                        PrintDebugMsg(mSciFile, LineIndex, DbgLevel[2], ErrMsg)
                self.mDone = HasContent
                return True
            else:
                PrintDebugMsg(mSciFile, LineIndex, DbgLevel[2], "Keyword " + self.GetKeyword() + " is duplicated.")

        return False
    def GetKeyword(self):
        return None
    def ProcessSCILine(self,Line):
        return None
    def GenTopCode (self,Notation):
        return ""
    def GenTopMainCode (self, Notation):
        return ""
    def GenMakefileCode (self, Notation):
        return ""
# }}}

class CMacro:
    def __init__(self, name, value, pre):
        self.mMacroName  = name            # Store name and value of macros
        self.mMacroValue = value            # Store name and value of macros
        self.mPreprocessor = pre            # Store name and value of macros

# Class used for generating the defined macro
class CDefineMacroGen(CGenIF):
# {{{
    def __init__(self):
        CGenIF.__init__(self)
        self.mMacro = {}            # Store name and value of macros

    def GetKeyword(self):
        return "%DEFINE"

    def ProcessSCILine(self, Line):
        SplitLine = Line.split()
        name = SplitLine[0]
        value = ""
        pre  = ""
        if (len(SplitLine) > 2):      # Check legal of input content 
            # Check define string 
#            if (SplitLine[1].startswith("\"") and SplitLine[-1].endswith("\"") and len(Line.split("\"")) == 3):
            value = SplitLine[1]
            if ('"' in SplitLine[1]):
                value = Line[Line.index('"')+1: Line.rindex('"')]
            elif (len(SplitLine) == 3 and "def:" in SplitLine[2]):
                pre   = SplitLine[2]
            else:
                return [DbgLevel[2],"Invalid " + self.GetKeyword() + " content."]
        elif (len(SplitLine) == 2):
            value = SplitLine[1]
        self.mMacro[name] = CMacro(name, value, pre)

        return None

    def GenTopCode (self, Notation):
        TopLine = ""
        DefineNotation = re.compile("[ ]*%%DEFINE")
        if (DefineNotation.match(Notation)):
            # Generate %%DEFINE part of top.h
            for MacroName in self.mMacro.keys():
                gen_line = "#define " + MacroName + " " + self.mMacro[MacroName].mMacroValue + "\n"
                if (self.mMacro[MacroName].mPreprocessor != ""):
                    gen_line = "#" + re.sub(r":", " ", self.mMacro[MacroName].mPreprocessor) + "\n    " + gen_line
                    gen_line += "#endif\n"
                TopLine += gen_line

        return TopLine

    #---Added by Trong Truong-----------
    def GenTopMainCode (self, Notation): #in class CDefineMacroGen
        TopMainCode = ""
        ConditionNotation = re.compile("[ ]*%%DEFINE")
        Indent = re.sub("%%DEFINE[ ]*\n","", Notation)
        if (ConditionNotation.match(Notation)):
            # Generate %%DEFINE part of top_main.cpp
            for MacroName,MacroValue in self.mMacro.items():
                if MacroValue.mMacroValue == "":
                    TopMainCode += Indent + "printf (\"" + MacroName + "\\n\");\n"
                else:
                    TopMainCode += Indent + "printf (\"" + MacroName + ":" + MacroValue.mMacroValue + "\\n\");\n"
        return TopMainCode
    #-----------------------------------
        
# }}}

# Class used for generating the environment information
class CEnvInfoGen(CGenIF):
# {{{
    def __init__(self):
        CGenIF.__init__(self)
        self.mCodingStyle = ""            # Store coding style of TLM 
        self.mAddSocket   = ""            # Content indicates adding external tlm socket
        self.mIniBuswidth = ""            # Store the buswidth of ini TLM socket
        self.mTgtBuswidth = ""            # Store the buswidth of tgt TLM socket
        self.mMacroRef    = {}

    def GetKeyword(self):
        return "%ENV_INFO"

    def ProcessSCILine(self, Line):
        if (not self.mDone):
            SplitLine = Line.split()
            if ((len(SplitLine) > 1) and (len(SplitLine) < 5)):        # Content indicates adding external tlm socket
                self.mCodingStyle = SplitLine[0]
                if (SplitLine[1] != "ADD_INI_SOCKET" and SplitLine[1] != "ADD_TGT_SOCKET" and SplitLine[1] != "ADD_BOTH_SOCKET"):  # Check Adding external TLM socket
                    return [DbgLevel[2],"Invalid adding external TLM socket."]
                else:
                    if ((len(SplitLine) == 2) or (len(SplitLine) == 3 and SplitLine[1] == "ADD_BOTH_SOCKET")):
                        return [DbgLevel[2],"Lack of bus width argument."]
                    elif(len(SplitLine) == 3):
                        CheckResult = self.CheckValidValue(SplitLine[2], self.mMacroRef, int, True)
                        if (len(CheckResult) == 1):
                            if (SplitLine[1] == "ADD_INI_SOCKET"):
                                self.mIniBuswidth = SplitLine[2]
                            else:
                                self.mTgtBuswidth = SplitLine[2]
                        else:
                            return (CheckResult)
                    else:
                        if (SplitLine[1] == "ADD_BOTH_SOCKET"):
                            CheckResultIni = self.CheckValidValue(SplitLine[2], self.mMacroRef, int, True)
                            CheckResultTgt = self.CheckValidValue(SplitLine[3], self.mMacroRef, int, True)
                            if (len(CheckResultIni) == 1):
                                self.mIniBuswidth = SplitLine[2]
                            else:
                                return CheckResultIni
                            if (len(CheckResultTgt) == 1):
                                self.mTgtBuswidth = SplitLine[3]
                            else:
                                return CheckResultTgt
                        else:
                            return [DbgLevel[2],"Too many bus width arguments."]
                    self.mAddSocket = SplitLine[1]
            elif(len(SplitLine) == 1):
                self.mCodingStyle = SplitLine[0]
            else:
                return [DbgLevel[2],"Invalid " + self.GetKeyword() + " content."]

            if (self.mCodingStyle != "LT") and (self.mCodingStyle != "AT"):     # Check Coding style
                return [DbgLevel[2],"Invalid TLM coding style (LT/AT)."]
            self.mDone = True
            return None
        else:
            return [DbgLevel[2], "Duplicated coding style declaration."]

    def GenTopCode(self,Notation):
        TopLine = ""
        AddTlmSocketNotation = re.compile("[ ]*%%ADD_TLM_SOCKET")
        AddDeclareTlmSocketNotation = re.compile("[ ]*%%ADD_DECLARE_TLM_SOCKET")

        if (AddTlmSocketNotation.match(Notation)):
            Indent = re.sub("%%ADD_TLM_SOCKET[ ]*\n","", Notation)
            if   (self.mAddSocket == "ADD_INI_SOCKET"):
                TopLine = Indent + ",public vpcl::tlm_ini_if<" + self.mIniBuswidth +">\n"
            elif (self.mAddSocket == "ADD_TGT_SOCKET"):
                TopLine = Indent + ",public vpcl::tlm_tgt_if<" + self.mTgtBuswidth +">\n"
            elif (self.mAddSocket == "ADD_BOTH_SOCKET"):
                TopLine = Indent + ",public vpcl::tlm_ini_if<" + self.mIniBuswidth +">\n" + Indent + ",public vpcl::tlm_tgt_if<" + self.mTgtBuswidth +">\n"
        elif (AddDeclareTlmSocketNotation.match(Notation)):
            Indent = re.sub("%%ADD_DECLARE_TLM_SOCKET[ ]*\n","", Notation)
            if   (self.mAddSocket == "ADD_INI_SOCKET"):
                TopLine = Indent + ",vpcl::tlm_ini_if<" + self.mIniBuswidth +">(name)\n"
            elif (self.mAddSocket == "ADD_TGT_SOCKET"):
                TopLine = Indent + ",vpcl::tlm_tgt_if<" + self.mTgtBuswidth +">(name)\n"
            elif (self.mAddSocket == "ADD_BOTH_SOCKET"):
                TopLine = Indent + ",vpcl::tlm_ini_if<" + self.mIniBuswidth +">(name)\n" + Indent + ",vpcl::tlm_tgt_if<" + self.mTgtBuswidth +">(name)\n"

        return TopLine

    #---Added by Trong Truong-------------
    def GenTopMainCode (self, Notation): #in class CEnvInfoGen
        TopMainCode = ""
        ConditionNotation = re.compile("[ ]*%%CODING_STYLE")
        Indent = re.sub("%%CODING_STYLE[ ]*\n","", Notation)
        if (ConditionNotation.match(Notation)):
            # Generate %%CODING_STYLE part of top_main.cpp
            TopMainCode += Indent + "printf (\"CODING STYLE:" + self.mCodingStyle + "\\n\");\n"
        return TopMainCode
    #-------------------------------------

    #----------------------------
    # Added by Loi Huynh
    def GenHandleCommandCode(self):
        HandleCommandCode = "%-20s%-12s%-24s%-24s\n"%("#instance", "keyword", "command", "targ1=arg2")
        HandleCommandCode += "%-20s%-12s%-24s%-24s\n"%("reslx.*", "ini", "set_param", "m_access_mode=TLM_IF_" + self.mCodingStyle +"_ACCESS")
        # -----------------------------
        # Added by Yen Nguyen
        if (self.mCodingStyle == "AT"):
            HandleCommandCode += "%-20s%-12s%-24s%-24s\n"%("reslx.*", "tgt", "set_param", "m_phase_mode=TLM_IF_MULTI_PHASE")
        HandleCommandCode += "%-20s%-12s%-24s%-24s\n"%("reslx.*","command", "MessageLevel", "warning|error|fatal|info")
        HandleCommandCode += "\n"
        # -----------------------------
        return HandleCommandCode
    #----------------------------
# }}} 

# Class used for storing the Clock information
class CClockInfo:
# {{{ 
    def __init__(self):
        self.mClockPeriod    = 0                 # Store clock period value of clock 
        self.mClockDutyCycle = 0                 # Store clock duty cycle of clock (must be < 1)
        self.mStartTime      = 0                 # Store the start time of clock
        self.PositiveFirst   = True              # Indicate first level of clock (false or true)
# }}}

# Class used for generating the clock information
class CClockInfoGen(CGenIF):
 # {{{ 
    def __init__(self):
        CGenIF.__init__(self)
        self.mClockMap              = {}                # Store the clocks information
        self.mMacroRef              = {}                # Store the name and value of macros
        self.mDefaultClockDutyCycle = 0.5               # Store the default value of Clock Duty Cycle
        self.mDefaultStartTime      = 0                 # Store the default value of Start Time
        self.mDefaultPositiveFirst  = "true"            # Store the default value of Positive First

    def GetKeyword(self):
        return "%CLOCK_RATIO"

    def ProcessSCILine(self, Line):
        NameDecl = re.compile("[a-zA-Z_].*")
        SplitLine = Line.split()
        CheckResult = self.CheckValidContent(SplitLine, 2, 5)# Must have at least 2 parameter

        if (CheckResult == None):
            if (SplitLine[0] in self.mClockMap):
                return [DbgLevel[2],"Duplicated name of clock signal."]
            if (NameDecl.match(SplitLine[0]) == None):
                return [DbgLevel[2],"Invalid clock signal name."]

            NewClockInfo = CClockInfo()
            TempValue    = []
            # Calculate the number of element will be check
            if (len(SplitLine) < 5):
                upper_bound = len(SplitLine)
            else:
                upper_bound = 4
            # Check whether value is valid or not
            for Index in range(1, upper_bound):
                if (Index == 1): # This parameter is mandatory
                    CheckResult = self.CheckValidValue(SplitLine[Index], self.mMacroRef, float, True)
                else:
                    if (SplitLine[Index] == "-"): # This parameter is specified as "-" (default)
                        CheckResult = [-1]
                    else:                         # Not default
                        if (Index == 2):
                            CheckResult = self.CheckValidValue(SplitLine[Index], self.mMacroRef, float, True)
                        else:
                            CheckResult = self.CheckValidValue(SplitLine[Index], self.mMacroRef, float, False)
                if (len(CheckResult) == 1):
                    TempValue.append(CheckResult[0])
                else:
                    return CheckResult

            NewClockInfo.mClockPeriod = SplitLine[1]               # Get Clock period
            if (len(SplitLine) > 2):                            # Clock duty cycle EXIST
                if (SplitLine[2] == "-"):
                    NewClockInfo.mClockDutyCycle = self.mDefaultClockDutyCycle
                else:
                    if (TempValue[1] <= 1):                          # Checking value of clock duty cycle setting
                        NewClockInfo.mClockDutyCycle = SplitLine[2]    # Get Clock duty cycle
                    else:
                        return [DbgLevel[2],"Clock duty cycle must less than 1."]
            else:                                               # Clock duty cycle NOT EXIST
                NewClockInfo.mClockDutyCycle = self.mDefaultClockDutyCycle
            if (len(SplitLine) > 3):                            # Start time EXIST
                if (SplitLine[3] == "-"):
                    NewClockInfo.mStartTime = self.mDefaultStartTime
                else:
                    NewClockInfo.mStartTime = SplitLine[3]      # Get Start time
            else:                                               # Start time NOT EXIST
                NewClockInfo.mStartTime = self.mDefaultStartTime
            if (len(SplitLine) > 4):                            # Positive first EXIST
                if (SplitLine[4] == "-"):
                    NewClockInfo.mPositiveFirst = self.mDefaultPositiveFirst
                else:
                    if (SplitLine[4] == "true") or (SplitLine[4] == "false"):
                        NewClockInfo.mPositiveFirst = SplitLine[4]     # Get positive first
                    else:
                        return [DbgLevel[2],"Invalid Positive first setting."]
            else:                                               # Positive first NOT EXIST
                NewClockInfo.mPositiveFirst = self.mDefaultPositiveFirst

            self.mClockMap[SplitLine[0]] = NewClockInfo
            return None
        else:
            return CheckResult

    def GenTopMainCode(self, Notation):
        TopMainCode = ""
        SysSignalDeclNotation = re.compile("[ ]*%%SYSTEM_SIGNAL_DECL")

        if (SysSignalDeclNotation.match(Notation)):
            Indent = re.sub("%%SYSTEM_SIGNAL_DECL[ ]*\n", "", Notation)
            for ClockName in self.mClockMap:
                TopMainCode += Indent + "sc_clock " + ClockName
                TopMainCode += "(\"" + ClockName + "\"," + str(self.mClockMap[ClockName].mClockPeriod) + "," + str(self.mClockMap[ClockName].mClockDutyCycle) + ","
                TopMainCode += str(self.mClockMap[ClockName].mStartTime) + "," + self.mClockMap[ClockName].mPositiveFirst + ");\n"

        return TopMainCode
# }}}

# Class used for storing the clock parameter
class CClockParam:
# {{{ 
    def __init__(self):
        self.mParam    = ""     # Store the parameter of clock
        self.mInstance = ""     # Store the instance name of clock
        self.mPeriod   = ""     # Store the period of clock
 # }}} 

# Class used for generating handleCommand
class CHandleCommandGen(CGenIF):
# {{{ 
    def __init__(self):
        CGenIF.__init__(self)
        self.mParamMap     = []

    def GetKeyword(self):
        return "%HANDLE_COMMAND"

    def ProcessSCILine(self, Line):
        if (re.search (r"\w", Line) != None):
            self.mParamMap.append(Line)


    def GenHandleCommandCode (self):
        HandleCommandCode = ""

        for Cmd in self.mParamMap:
            HandleCommandCode += "%s%s\n"%("reslx.", Cmd)

        return HandleCommandCode
            

# Class used for generating the clock parameter for handleCommand
class CClockParameterGen(CGenIF):
# {{{ 
    def __init__(self):
        CGenIF.__init__(self)
        self.mClockMapRef  = {}
        self.mModuleMapRef = {}
        self.mParamMap     = []

    def GetKeyword(self):
        return "%CLOCK_PARAMETER"

    def ProcessSCILine(self, Line):
        SplitLine   = Line.split()
        CheckResult = self.CheckValidContent(SplitLine, 3)
        NameDecl = re.compile("[a-zA-Z_].*")

        if (CheckResult == None):
            if (SplitLine[0] in self.mModuleMapRef):
                if (SplitLine[2] in self.mClockMapRef):
                    NewClockParam           = CClockParam()
                    if (NameDecl.match(SplitLine[1])):
                        NewClockParam.mParam    = SplitLine[1]
                    else:
                        return [DbgLevel[2],"Invalid clock parameter name."]
                    NewClockParam.mInstance = SplitLine[0]
                    NewClockParam.mPeriod   = self.mClockMapRef[SplitLine[2]].mClockPeriod
                    self.mParamMap.append(NewClockParam)
                    return None
                else:
                    return [DbgLevel[2],"Clock name does not exist."]
            else:
                return [DbgLevel[2],"Instance name does not exist."]
        else:
            return CheckResult

    def GenHandleCommandCode (self):
        CommentFlag = False
        HandleCommandCode = ""

        for Instance in self.mParamMap:
            if not (self.mModuleMapRef[Instance.mInstance].mIsBusModel):   #Added by Loi Huynh
                if not (CommentFlag):
                    HandleCommandCode = "#instance\t\tkeyword\t\tcommand\t\targ1\n"
                    CommentFlag = True

                HandleCommandCode += "reslx." + Instance.mInstance + "\t\t\t\t" + Instance.mParam + "\t\t" + Instance.mPeriod + "\n"     #Modified by Loi Huynh

        if not (HandleCommandCode == ""):
            HandleCommandCode += "\n"

        return HandleCommandCode

# }}}

# Class used for storing the system channels information
class CChannelSys:
# {{{
    def __init__(self):
        self.mBitWidth   = 0     # Store the bitwidth of the signal
        self.mSignalType = ""     # Store the type of the signal
        self.mClassType  = ""     # Store the class type of the signal
        self.mPointer    = ""     # Store the class type of the signal
        self.mArraySize  = ""     # Support port array declaration
        self.mPreprocessor  = ""     # Support port array declaration
        self.mInitValue  = ""     # Support port array declaration
# }}} 

# Class used for generating the system channels
class CChannelSysGen(CGenIF):
# {{{
    def __init__(self):
        CGenIF.__init__(self)
        self.mChannelSysMap = {}
        self.mMacroRef      = {}
        self.mClockMapRef   = {}
        self.emType         = []     # Enumeration of signal's type
        self.emClassType    = []     # Enumeration of signal's class type
        self.mModuleMapRef  = {}
        self.mInitPort      = []     # List of port to be initialized
        self.mInitPortArray = []     # List of port to be initialized

    def GetKeyword(self):
        return "%CHANNEL_SYS"

    def ProcessSCILine(self, Line):
        NameDecl = re.compile("\**[a-zA-Z_].*")
        SplitLine   = Line.split()
        CheckResult = self.CheckValidContent(SplitLine, 4, 6)

        if (CheckResult == None):
            if (SplitLine[0] in self.mChannelSysMap):
                return [DbgLevel[2],"Duplicated name of signal."]

            if (NameDecl.match(SplitLine[0]) == None):
                return [DbgLevel[2],"Invalid signal name."]

            SigList = [SplitLine[0]]
            if (',' in SplitLine[0]):
                SigList = SplitLine[0].split(",")

            for sig in SigList:
                NewChannelSys = CChannelSys()

                CheckResult = self.CheckValidValue(SplitLine[1], self.mMacroRef, int, True)     # Get Bitwidth of signal
                if (len(CheckResult) == 1):
                    BitWidth = CheckResult[0]
                else:
                    return CheckResult

                NewChannelSys.mBitWidth = SplitLine[1]

                if (SplitLine[2] in self.emType):   # Get signal type
                    NewChannelSys.mSignalType = SplitLine[2]
                else:
                    return [DbgLevel[2],"Invalid signal type."]

                NewChannelSys.mClassType = SplitLine[3]
                IsNewClassType = False
                if (SplitLine[3] not in self.emClassType):
                    IsNewClassType = True            
                if (SplitLine[3] == "bool"): 
                    if (BitWidth != 1) :
                        return [DbgLevel[2],"Bitwitdh of bool signal must be equal 1."]

                if ('[' in sig):    # Support array declaration
                    if (re.match(".*\[\s*\].*", sig) != None):
#                        NewChannelSys.mPointer = '*'
                        sig = re.sub(r"\[\s*\]", '', sig)
#                        print("Line: " + SplitLine[0] + "Sig: " + sig + " array size: " + NewChannelSys.mArraySize + "\n" )
                    NewChannelSys.mArraySize = sig[sig.index('[') + 1: sig.index(']')].strip()
                    sig = sig[0:sig.index('[')]
#                    print("Line: " + SplitLine[0] + "Sig: " + sig + " array size: " + NewChannelSys.mArraySize + "\n" )
                if ('*' in sig):
                    NewChannelSys.mPointer   = re.sub(r"\*\w.*$", '*', sig)
                sig = re.sub(r'\*', '', sig)

                if (len(SplitLine) > 4):
                    NewChannelSys.mInitValue = SplitLine[4]
                if (len(SplitLine) > 5):
                    NewChannelSys.mPreprocessor = SplitLine[5]
                self.mChannelSysMap[sig] = NewChannelSys
                if IsNewClassType:            
                    return [DbgLevel[1],"A new class type of port (" + SplitLine[3] + ") is defined"]
            return None
        else:
            return CheckResult

    def GenTopCode(self, Notation):
        TopLine = ""
        DeclarePortNotation = re.compile("[ ]*%%DECLARE_PORTS_AND_SIGNALS")
        InitPortNotation    = re.compile("[ ]*%%INIT_PORTS_AND_SIGNALS")
        InitPortArrayNotation  = re.compile("[ ]*%%INIT_ARRAY_OF_PORTS_AND_SIGNALS")

        if (DeclarePortNotation.match(Notation)):
            Indent = re.sub("%%DECLARE_PORTS_AND_SIGNALS[ ]*\n", "", Notation)
            # Generate normal ports declaration
            for SignalName in self.mChannelSysMap:
                if (self.mChannelSysMap[SignalName].mPreprocessor != ""):
                    TopLine += "#" + re.sub(r":", " ", self.mChannelSysMap[SignalName].mPreprocessor) + "\n"
                TopLine += Indent + "sc_" + self.mChannelSysMap[SignalName].mSignalType + "<" + self.mChannelSysMap[SignalName].mClassType
                SignalNameTemp = SignalName
                if (self.mChannelSysMap[SignalName].mArraySize != ""):
                    SignalNameTemp += "[" + self.mChannelSysMap[SignalName].mArraySize + "]"
                    if (self.mChannelSysMap[SignalName].mPointer != ""): 
                        self.mInitPortArray.append(SignalNameTemp)
                    else:
                        print ("[GenTopCode:%%INIT_ARRAY_OF_PORTS_AND_SIGNALS] "  + DbgLevel[1] + ": "  + "Port array '%s' is initialized only if dynamic allocation ."%SignalNameTemp)
                else:
                    self.mInitPort.append(SignalName)
                if (self.mChannelSysMap[SignalName].mPointer != ""): SignalNameTemp = "*" + SignalNameTemp
                if self.mChannelSysMap[SignalName].mClassType not in emKeepClassType:
                    TopLine += ">\t" + SignalNameTemp + ";\n"
                else:
                    TopLine += "<" + str(self.mChannelSysMap[SignalName].mBitWidth) + "> >\t" + SignalNameTemp + ";\n"
                if (self.mChannelSysMap[SignalName].mPreprocessor != ""):
                    TopLine += "#endif\n"

        # Generate Initilization of Ports and Signals
        if (InitPortNotation.match(Notation)):
            Indent = re.sub("%%INIT_PORTS_AND_SIGNALS[ ]*\n", "", Notation)
            for PortName in self.mInitPort:
                gen_line = Indent + "," + PortName + '("' + PortName + '")' + "\n"
                if (PortName in  self.mChannelSysMap and self.mChannelSysMap[PortName].mPreprocessor != ""):
                    gen_line = Indent + "#" + re.sub(r":", " ", self.mChannelSysMap[PortName].mPreprocessor) + "\n" + gen_line
                    gen_line += Indent + "#endif\n"
                TopLine += gen_line

        # Generate Initilization of Ports and Signals array
        if (InitPortArrayNotation.match(Notation)):
            Indent = re.sub("%%INIT_ARRAY_OF_PORTS_AND_SIGNALS[ ]*\n", "", Notation)
            for PortNameOrg in self.mInitPortArray:
                PortName = re.sub(r'^\**', "", PortNameOrg)
                PortWidth = re.sub(r'.*\[', "", PortName)
                PortWidth = re.sub(r'\].*', "", PortWidth)
                PortName  = PortNameOrg[0:PortName.index('[')]
                if (self.mChannelSysMap[PortName].mPreprocessor != ""):
                    TopLine += Indent + "#" + re.sub(r":", " ", self.mChannelSysMap[PortName].mPreprocessor) + "\n"
                TopLine += Indent + "for (unsigned int index = 0; index < " + PortWidth + "; index++) {\n"
                TopLine += Indent + "    std::ostringstream str_" + PortName + ";\n"
                TopLine += Indent + "    str_" + PortName +  " << \"" + PortName + "\"" + " << index;\n"
                allocate_type = ""
                if (self.mChannelSysMap[PortName].mPointer != ""): allocate_type = "new"
                TopLine += Indent + "    " + PortName + "[index] = " + allocate_type + " sc_" + self.mChannelSysMap[PortName].mSignalType + "<" + self.mChannelSysMap[PortName].mClassType
                if self.mChannelSysMap[PortName].mClassType not in emKeepClassType:
                    TopLine += "> " 
                else:
                    TopLine += "<" + str(self.mChannelSysMap[PortName].mBitWidth) + "> > " 
                TopLine += "(str_" + PortName + ".str().c_str());\n"
                # T.B.D XXX yennguyen => initialize out port value
                TopLine += Indent + "}\n"
                if (self.mChannelSysMap[PortName].mPreprocessor != ""): TopLine += Indent + "#endif\n"

        return TopLine

    def GenTopMainCode (self, Notation):
        TopMainCode = ""
        SysSignalDeclNotation    = re.compile("[ ]*%%SYSTEM_SIGNAL_DECL")
        SysSignalInstantNotation = re.compile("[ ]*%%CONNECT_SYSTEM_SIGNAL")

        emPortDefine = ["in", "out", "inout"]

        if (SysSignalDeclNotation.match(Notation)):
            Indent = re.sub("%%SYSTEM_SIGNAL_DECL[ ]*\n", "", Notation)
            for SignalName in self.mChannelSysMap:
                if (SignalName not in self.mClockMapRef):
                    if (self.mChannelSysMap[SignalName].mSignalType in emPortDefine):
                        TopMainCode += Indent + "sc_signal <" + self.mChannelSysMap[SignalName].mClassType
                        if self.mChannelSysMap[SignalName].mClassType not in emKeepClassType:
                            TopMainCode += ">\t" + SignalName + ";\n"
                        else:
                            TopMainCode += "<"   + self.mChannelSysMap[SignalName].mBitWidth + "> >\t" + SignalName + ";\n"

        if (SysSignalInstantNotation.match(Notation)):
            Indent = re.sub("%%CONNECT_SYSTEM_SIGNAL[ ]*\n", "", Notation)
            for SignalName in self.mChannelSysMap:
                if (self.mChannelSysMap[SignalName].mSignalType in emPortDefine):
                    TopMainCode += Indent + "reslx->" + SignalName + "(" + SignalName + ");\n"

        return TopMainCode
# }}} 

# Class used for storing the clock parameter
class CVcSpecificSys:
# {{{ 
    def __init__(self):
        self.mInstance = ""     # Store the instance name of port
        self.mPort     = ""     # Store the port name
        self.mSignal   = ""     # Store the signal name
        self.mPointer  = ""     # Store the pointer sign
        self.mPreprocessor   = ""     # Store the preprocessor
# }}} 

# Class used for generating the signal connections
class CVcSpecificSysGen(CGenIF):
# {{{ 
    def __init__(self):
        CGenIF.__init__(self)
        self.mVcSpecificSys    = []
        self.mChannelSysMapRef = {}
        self.mClockMapRef      = {}
        self.mModuleMapRef     = {}
        self.mMacroRef         = {}
        self.mInitPort         = []     # List of port to be initialized
        self.mConnectStubGen   = []     # List of generated stub to be connected
        self.emClassType       = []

    def GetKeyword(self):
        return "%VC_SPECIFIC_SYS"

    def ProcessSCILine(self, Line):
        SplitLine   = Line.split()
        CheckResult = self.CheckValidContent(SplitLine, 3, 4)

        if (CheckResult == None):
            module_inst = re.sub(r'\W.*', '', SplitLine[0])
            if (module_inst in self.mModuleMapRef):
                sig_name = SplitLine[2]
                if ('[' in sig_name) : sig_name = SplitLine[2][0:sig_name.index('[')]
                if ('*' in sig_name) : sig_name = re.sub("\*", "", sig_name)
                if (sig_name in self.mChannelSysMapRef):
                    port_name = SplitLine[1]
                    if ('[' in port_name) : port_name = SplitLine[1][0:port_name.index('[')]
                    if (port_name in self.mModuleMapRef[SplitLine[0]].mInfo.mPort):


                        NewVcSpecificSys           = CVcSpecificSys()
                        NewVcSpecificSys.mInstance = SplitLine[0]
                        NewVcSpecificSys.mPort     = SplitLine[1]
                        NewVcSpecificSys.mSignal   = SplitLine[2]
                        if (len(SplitLine) > 3):
                            NewVcSpecificSys.mPreprocessor = SplitLine[3]
                        self.mVcSpecificSys.append(NewVcSpecificSys)
                        PortWidth = self.mModuleMapRef[NewVcSpecificSys.mInstance].mInfo.mPort[port_name].mBitWidth
                        #------------------------------------------------------
                        #Added by Loi Huynh
                        if (PortWidth in self.mModuleMapRef[NewVcSpecificSys.mInstance].mInfo.mTemplate):
                            if (PortWidth in self.mMacroRef):
                                PortWidth = self.ExtractValue(self.mMacroRef[PortWidth].mMacroValue, int)
                        else:
                            PortWidth = self.mModuleMapRef[NewVcSpecificSys.mInstance].mInfo.mPort[port_name].mBitWidth
                        #------------------------------------------------------
                        SignalWidth = self.CheckValidValue(self.mChannelSysMapRef[sig_name].mBitWidth, self.mMacroRef, int, True)[0]
                        PortType = self.mModuleMapRef[NewVcSpecificSys.mInstance].mInfo.mPort[port_name].mClassType
                        SignalType = self.mChannelSysMapRef[sig_name].mClassType
                        if (PortWidth == SignalWidth):
                            if (PortType == SignalType):
                                return None
                            else:
                                return [DbgLevel[2],"Class type of connected port does not match."]
                        else:
                            return [DbgLevel[2],"Bitwidth of connected port does not match."]
                    else:
                        return [DbgLevel[2],"Port name does not exist."]
                else:
                    return [DbgLevel[2],"Signal name does not exist."]
            else:
                return [DbgLevel[2],"Instance name does not exist."]
        else:
            return CheckResult

    def GenTopCode(self,Notation):
        TopLine = ""
        ConnectModuleNotation = re.compile("[ ]*%%CONNECT_MODULES")
        DeclarePortNotation   = re.compile("[ ]*%%DECLARE_PORTS_AND_SIGNALS")
        # Generate Ports and Signals Declaration
        if (DeclarePortNotation.match(Notation)):
            Indent = re.sub("%%DECLARE_PORTS_AND_SIGNALS[ ]*\n", "", Notation)
            # Generate non-connection ports
            for Module in self.mModuleMapRef:
                for PortName in self.mModuleMapRef[Module].mInfo.mPort:
                    # create list of connected port of module
                    ConnectedList = []
                    for VcSpecific in self.mVcSpecificSys:
                        if (Module == VcSpecific.mInstance):
                            ConnectedList.append(re.sub(r"\[.*", "", VcSpecific.mPort) )

                    if (PortName not in ConnectedList):
                        TopLine += Indent + "sc_signal"
                        TopLine += "<" + self.mModuleMapRef[Module].mInfo.mPort[PortName].mClassType
                        if self.mModuleMapRef[Module].mInfo.mPort[PortName].mClassType not in emKeepClassType:
                            TopLine += ">\t" + "stub_" + Module + "_" + PortName + ";\n"
                        else:
                            TopLine += "<" + str(self.mModuleMapRef[Module].mInfo.mPort[PortName].mBitWidth) + "> >\t" + "stub_" + Module + "_" + PortName + ";\n"
                        self.mInitPort.append("stub_" + Module + "_" + PortName)
                        # Get stub port name and value
                        self.mConnectStubGen.append([Module,PortName,self.mModuleMapRef[Module].mInfo.mPort[PortName].mFixedValue])

        # Generate module connection
        if (ConnectModuleNotation.match(Notation)):
            Indent = re.sub("%%CONNECT_MODULES\n", "", Notation)
            for VcSpecificSys in self.mVcSpecificSys:
                #Added by DungNguyen
                PortPatternArray  = re.compile(".*\[\].*")
                bind_str = ""
                PortName = re.sub("\*","",VcSpecificSys.mPort)
                if ('[' in PortName): PortName = PortName[0:PortName.index('[')]
                if (self.mModuleMapRef[VcSpecificSys.mInstance].mInfo.mPort[PortName].mPointer  != ""): 
                    bind_str = "->bind"

                gen_str  = ""
                if (self.mModuleMapRef[VcSpecificSys.mInstance].mInfo.mPort[PortName].mPreprocessor != ""):
                    gen_str = Indent + "#" + re.sub(r":", " ", self.mModuleMapRef[VcSpecificSys.mInstance].mInfo.mPort[PortName].mPreprocessor) + "\n"
                SigName = re.sub(r'\[.*', '', VcSpecificSys.mSignal)
                if (PortPatternArray.match(VcSpecificSys.mPort)):
                    PortWidth = VcSpecificSys.mPort[VcSpecificSys.mPort.rindex('[') + 1:VcSpecificSys.mPort.rindex(']')]
                    gen_str += Indent + "for (unsigned int port_id = 0; port_id < " + PortWidth + " ; port_id ++) {\n"
                    gen_str += Indent + "    " + VcSpecificSys.mInstance + "->"  + PortName + "[port_id]" + bind_str + "(" + SigName + "[port_id]);\n"
                    gen_str += Indent + "}\n"
                else:
                    gen_str += Indent + VcSpecificSys.mInstance + "->" + VcSpecificSys.mPort + bind_str
                    gen_str += '(' + SigName + ')' + ";\n"
                if (self.mModuleMapRef[VcSpecificSys.mInstance].mInfo.mPort[PortName].mPreprocessor != ""): gen_str += Indent + "#endif\n"

                TopLine += gen_str


        # Generate the stub connection
            for StubConnection in self.mConnectStubGen:
                TopLine += Indent + "stub_" + StubConnection[0] + "_" +  StubConnection[1] + " = " + str(StubConnection[2]) + ";\n"
            for StubConnection in self.mConnectStubGen:
                TopLine += Indent + StubConnection[0] + "->" + StubConnection[1] + "(stub_" + StubConnection[0] + "_" + StubConnection[1] + ");\n"

        return TopLine
# }}}

#-------------------------------------------------------------------------
#Added by Loi Huynh
# Class used for combine two TLM sockets
class CBindTLMSocket:
# {{{ 
    def __init__(self):
        self.mIniInstanceName = ""     # Store the ini instance name having socket
        self.mIniSocketName   = ""     # Store the ini socket name
        self.mTgtInstanceName = ""     # Store the tgt instance name having socket
        self.mTgtSocketName   = ""     # Store the tgt socket name
        self.mPointer         = False  # Store the flag of pointer
# }}} 

# Class used for generating the signal connections
class CBindTLMSocketGen(CGenIF):
# {{{ 
    def __init__(self):
        CGenIF.__init__(self)
        self.mBindTLMSocket    = []
        self.mModuleMapRef     = {}

    def GetKeyword(self):
        return "%BIND_TLM_SOCKET"

    def ProcessSCILine(self, Line):
        NameDecl = re.compile("\**[a-zA-Z_].*")
        SplitLine   = Line.split()
        CheckResult = self.CheckValidContent(SplitLine, 4, 5)

        if (CheckResult == None):
            if (NameDecl.match(SplitLine[1]) == None):
                return [DbgLevel[2],"Invalid initiator socket name."]

            if (NameDecl.match(SplitLine[3]) == None):
                return [DbgLevel[2],"Invalid target socket name."]

            if ((SplitLine[0] in self.mModuleMapRef) and (SplitLine[2] in self.mModuleMapRef)):
                NewBindTLMSocket                  = CBindTLMSocket()
                NewBindTLMSocket.mIniInstanceName = SplitLine[0]
                NewBindTLMSocket.mIniSocketName   = SplitLine[1]
                NewBindTLMSocket.mTgtInstanceName = SplitLine[2]
                NewBindTLMSocket.mTgtSocketName   = SplitLine[3]
                if len(SplitLine) == 5:
                    if SplitLine[4] == "pointer":
                        NewBindTLMSocket.mPointer = True
                    else:
                        return [DbgLevel[2],"Invalid pointer name."]
                if ( "*" in SplitLine[3]):
                    NewBindTLMSocket.mPointer = True
                    NewBindTLMSocket.mTgtSocketName = re.sub("\*", "", SplitLine[3])
                self.mBindTLMSocket.append(NewBindTLMSocket)
            else:
                return [DbgLevel[2],"Instance name does not exist."]
        else:
            return CheckResult

    def GenTopCode(self,Notation):
        TopLine = ""
        ConnectModuleNotation = re.compile("[ ]*%%CONNECT_MODULES")

        # Generate module connection
        if (ConnectModuleNotation.match(Notation)):
            Indent = re.sub("%%CONNECT_MODULES\n", "", Notation)
            for BindTLMSocket in self.mBindTLMSocket:
                if BindTLMSocket.mPointer:
                    TopLine += Indent + BindTLMSocket.mIniInstanceName + "->" + BindTLMSocket.mIniSocketName
                    TopLine += "(*" + BindTLMSocket.mTgtInstanceName + "->" + BindTLMSocket.mTgtSocketName + ");\n"
                else:
                    TopLine += Indent + BindTLMSocket.mIniInstanceName + "->" + BindTLMSocket.mIniSocketName
                    TopLine += "(" + BindTLMSocket.mTgtInstanceName + "->" + BindTLMSocket.mTgtSocketName + ");\n"
        return TopLine
# }}} 
#-------------------------------------------------------------------------

# Class used for storing the module information
class CModule:
# {{{ 
    def __init__(self,ClassName,InstanceName):
        self.mClassName    = ClassName
        self.mInstanceName = InstanceName
        self.mInfo         = modelinfo_parser.CModelInfo()
        self.mIsBusModel   = False     #Added by Loi Huynh
# }}}

# Class used for generating the modules' declarations
class CModuleListGen(CGenIF):
# {{{ 
    def __init__(self):
        CGenIF.__init__(self)
        self.mScriptName = os.path.basename(__file__)
        self.mModuleMap  = {}
        self.mInputPath  = ""     #Modified by Loi Huynh
        self.mModelInfoFilePaths = []     #Added by Loi Huynh
        self.mInstModuleList = []    #Added by SonTran
#        self.mHeaderFileAdd = []    #Added by Trong Truong
        self.emType      = []
        self.emClassType = []
        self.mMacroRef   = {}
        self.mImplementationFileNameList = []     #Added by Loi Huynh
        self.mImplementationFilePathList = []     #Added by Loi Huynh

    def GetKeyword(self):
        return "%MODULE_LIST"

    def ProcessSCILine(self, Line):
        LineTemp = Line
        OpenMark  = ["<","("]
        CloseMark = [">",")"]
        for Indx in range(len(OpenMark)):
            OpenMarkIndx  = LineTemp.find(OpenMark[Indx])     # Get position of open mark
            CloseMarkIndx = LineTemp.find(CloseMark[Indx])     # Get position of close mark
            LineTemp = LineTemp[0:OpenMarkIndx] + LineTemp[OpenMarkIndx:CloseMarkIndx].replace(" ","") + LineTemp[CloseMarkIndx:len(LineTemp)]
        SplitLineCheck   = LineTemp.split()
        CheckResult = self.CheckValidContent(SplitLineCheck, 3)
        
        SplitLine   = Line.split()
        for Indx in range(2,len(SplitLine)):
            if Indx < len(SplitLine) - 1:
                SplitLine[1] += " " + SplitLine[Indx]
            else:
                SplitLine[2] = SplitLine[Indx]
        while len(SplitLine) > 3:
            del SplitLine[len(SplitLine) - 1]

        if (CheckResult == None):
            NameDecl = re.compile("[a-zA-Z_].*")
            if (NameDecl.match(SplitLine[1])):
                if (SplitLine[2] not in self.mModuleMap):
                    if (NameDecl.match(SplitLine[2])):
                        NewModule = self.ProcessInfoFile(SplitLine[0]+".txt", SplitLine[1], SplitLine[2])     # Modified by Loi Huynh
                        if (NewModule != None):
                            self.mInstModuleList.append(SplitLine[2]);
                            self.mModuleMap[SplitLine[2]] = NewModule

                            # Check Template declaration
                            TemplateDecl = re.compile(".*<.*>.*")
                            Template     = SplitLine[1]

                            if (TemplateDecl.match(SplitLine[1])):
                                Template = re.sub(".*<","", Template)
                                Template = re.sub(">.*","", Template)
                                Template = Template.split(",")
                            for PortInfo in NewModule.mInfo.mPort:
                                try:
                                    self.ExtractValue(str(NewModule.mInfo.mPort[PortInfo].mBitWidth), int)
                                except ValueError:
                                    if (len(Template) == len(NewModule.mInfo.mTemplate)):
                                        TemplateValue = Template[NewModule.mInfo.mTemplate[NewModule.mInfo.mPort[PortInfo].mBitWidth][1]].strip()
                                        CheckResult = self.CheckValidValue(TemplateValue, self.mMacroRef, int, True)
                                        if (len(CheckResult) == 1):
                                            NewModule.mInfo.mPort[PortInfo].mBitWidth = TemplateValue
                                        else:
                                            return CheckResult
                                    else:
                                        return [DbgLevel[2],"Invalid Template declaration in class name."]

                            self.mModuleMap[SplitLine[2]] = NewModule
                            return None
                        else:
                            return [DbgLevel[2],"Error while processing " + SplitLine[0] + " file."]
                    else:
                        return [DbgLevel[2],"Invalid instance name."]
                else:
                    return [DbgLevel[2],"Duplicate instance name."]
            else:
                return [DbgLevel[2],"Invalid class name."]
        else:
            return CheckResult

    def ProcessInfoFile(self,ModelInfoFile, ClassName, InstanceName):
        Module        = CModule(ClassName, InstanceName)
        #------------------------------------
        # Added by Loi Huynh
        IsFound  = False
        # At first, search the model info file in the additional model info file directory
        for ModelInfoFilePath in self.mModelInfoFilePaths:
            if ModelInfoFile in ModelInfoFilePath:
                ModelInfoFile = ModelInfoFilePath
                IsFound = True
                break
        # If not found, continute to search in current dir as default
        if not (IsFound):
            ModelInfoFileList     = []
            PathNameDecl = re.compile(r'b\'(?P<pathname>[\w\/\.-]+)\'')
            FindResult = subprocess.Popen(['/usr/bin/find', self.mInputPath,'-name',ModelInfoFile],stdout=subprocess.PIPE)
            PathNameList = FindResult.communicate()[0]
            for PathName in PathNameList.splitlines():
                PathName = PathNameDecl.match(str(PathName))
                if PathName:
                    ModelInfoFileList.append(PathName.group('pathname'))
            if (len(ModelInfoFileList) > 1):
                print("[" + self.mScriptName + "] [" + ModelInfoFile + "] ERROR: There are two or more the same model info file names under searching directory.")
            elif (len(ModelInfoFileList) == 0):
                print("[" + self.mScriptName + "] [" + ModelInfoFile + "] ERROR: Model info file does not exist.")
            else:
                ModelInfoFile = ModelInfoFileList[0]
        #------------------------------------
        # Added by Sontran
        try:
            InfoFile = open(ModelInfoFile, 'r')
            InfoLine = InfoFile.readlines()
            Module.mInfo = modelinfo_parser.GetModelInfoContent(ModelInfoFile, InfoLine, self.mMacroRef, self.mImplementationFileNameList, self.mImplementationFilePathList, False)
            if (Module.mInfo == None):
                Module = None
#            else:
#                self.mHeaderFileAdd.extend(Module.mInfo.mHeaderFile)
        except IOError:
            print("[" + self.mScriptName + "] " + "ERROR: Cannot open " + ModelInfoFile + " file.")
            Module = None

        return Module

    def GenTopCode(self,Notation):
        TopLine = ""

        IncludeModuleNotation     = re.compile("[ ]*%%INCLUDE_MODULE_HEADERS" )
        ModulePointerNotation     = re.compile("[ ]*%%DECLARE_MODULE_POINTERS")
        ModuleInstanceNotation    = re.compile("[ ]*%%MODULE_INSTANTIATION"   )
        DeleteModuleNotation      = re.compile("[ ]*%%DELETE_MODULE_POINTERS" )
        HandleCommandNotation     = re.compile("[ ]*%%COMMAND_HANDLER"        )
        CallDumpProfileNotation   = re.compile("[ ]*%%DUMP_PROFILE"           ) # Add to layout the call all profile output functions

        HeaderGen = []
        DumpDict = {"Ctransactor":["DumpProfile()"] , "Csbsc":["DumpProfile(stdout)" , "DumpMemAreaInfo(stdout)" , "DumpMemRegInfo(stdout)"] , "Shwy":["DumpProfile()"]}
        ListModuleDump = ["Ctransactor", "Csbsc", "Shwy"] # List of classes will be called profile output functions

        for Module in self.mInstModuleList:
            # Generate include part
            if IncludeModuleNotation.match(Notation):
                for HeaderFile in self.mModuleMap[Module].mInfo.mHeaderFile:
                    if HeaderFile not in HeaderGen:
                        TopLine = TopLine + "#include " + '"' + HeaderFile + '"\n'
                        HeaderGen.append(HeaderFile)
            # Generate pointer declaration part
            elif ModulePointerNotation.match(Notation):
                Indent  = re.sub("%%DECLARE_MODULE_POINTERS\n", "", Notation)
                TopLine = TopLine + Indent + re.sub("\(.*\)","",self.mModuleMap[Module].mClassName) + ' *'+ self.mModuleMap[Module].mInstanceName + ";\n"
            # Generate Module instantiation part
            elif ModuleInstanceNotation.match(Notation):
                Indent  = re.sub("%%MODULE_INSTANTIATION\n"   , "", Notation)
                TopLine = TopLine + Indent + Module + " = new " + self.mModuleMap[Module].mClassName + ";\n"
            # Generate Call dump profile part
            elif CallDumpProfileNotation.match(Notation):
                Indent  = re.sub("%%DUMP_PROFILE\n" , "", Notation)
                class_name = (self.mModuleMap[Module].mClassName).split('<')
                class_name = (class_name[0]).split('(')
                class_name = (class_name[0]).strip()
                if class_name in ListModuleDump:
                    for element in DumpDict[class_name]:
                        TopLine = TopLine + Indent + Module + "->" + element + ";\n"
            # Generate Delete module part
            elif DeleteModuleNotation.match(Notation):
                Indent  = re.sub("%%DELETE_MODULE_POINTERS\n" , "", Notation)
                TopLine = TopLine + Indent + "delete " + Module + ";\n"

        # Generate handleCommand
        if (HandleCommandNotation.match(Notation)):
            Indent = re.sub("%%COMMAND_HANDLER\n", "", Notation)
            for Module in self.mInstModuleList:
                if not (self.mModuleMap[Module].mInfo.mNoUseHDLCommand):
                    TopLine += Indent + "cmd_handler->register_command_processor(" + Module + "->name()," 
                    TopLine += Module + ",&" + re.sub("\(.*\)","",self.mModuleMap[Module].mClassName) + "::handleCommand)" + ";\n"
            #--------------------------------------------------------------------    
            #Added by Loi Huynh
            for Module in self.mInstModuleList:
                if (self.mModuleMap[Module].mInfo.mHWBreak):
                    TopLine += Indent + Module + "->setCommandHandler(cmd_handler);\n"
            #--------------------------------------------------------------------
        return TopLine

    def GenTopMainCode (self, Notation): #in class CDefineMacroGen
        TopMainLine = ""
        # Generate handleCommand
        MainHandleCommandNotation = re.compile("[ ]*%%MAIN_COMMAND_HANDLER"   )
        if (MainHandleCommandNotation.match(Notation)):
            Indent = re.sub("%%MAIN_COMMAND_HANDLER\n", "", Notation)
            for Module in self.mInstModuleList:
                if (re.search(r"\b(magic|bus|intc|control_port|realio|uac|ctsu_hmtop|dconv|sbsc)", Module) != None): continue
                TopMainLine += Indent + "cmd_handler_ssc->register_command_processor(reslx->" + Module + "->name(), reslx->" 
                TopMainLine += Module + ",&" + re.sub("\(.*\)","",self.mModuleMap[Module].mClassName) + "::handleCommand)" + ";\n"
        return TopMainLine

    def GenMakefileCode (self, Notation):
        MakefileCode = ""

        ImplementationGen = []
        IncludeDirGen     = []
        LibraryDirGen     = []
        LinkedLibGen      = []

        ImplementationFileNotation = re.compile("[ ]*%%IMPLEMENTATION_FILES")
        IncludeDirNotation         = re.compile(".*%%INCLUDED_DIR")
        LibraryDirNotation         = re.compile(".*%%LIBRARY_DIR")
        LinkedLibNotation          = re.compile(".*%%LINKED_LIBRARY")
        ModelObjDirNotation        = re.compile(".*%%MODEL_OBJECT_DIR")

        if (ImplementationFileNotation.match(Notation)):
            Indent = re.sub("%%IMPLEMENTATION_FILES[ ]*\n", "", Notation)
            for Module in self.mInstModuleList:
                for ImplementationFile in self.mModuleMap[Module].mInfo.mImplementationFile:
                    if (ImplementationFile not in ImplementationGen):
                        MakefileCode += Indent + ImplementationFile + ' \\\n'
                        ImplementationGen.append(ImplementationFile)
            MakefileCode = MakefileCode[0:-2] + "\n"
        #--------------------------------------------------------------------
        #Added by Loi Huynh
        if (IncludeDirNotation.match(Notation)):
            MakefileCode = re.sub("%%INCLUDED_DIR[ ]*\n", "", Notation)
            MakefileCode += "-I" + self.mInputPath + " \\\n          "     #Default include directory
            IncludeDirGen.append(self.mInputPath)
            for Module in self.mInstModuleList:
                for IncludeDir in self.mModuleMap[Module].mInfo.mIncludeDir:
                    if (IncludeDir not in IncludeDirGen):
                        MakefileCode += "-I" + IncludeDir + " \\\n          "
                        IncludeDirGen.append(IncludeDir)
            MakefileCode = MakefileCode[0:-13] + "\n"

        if (LibraryDirNotation.match(Notation)):
            MakefileCode = re.sub("%%LIBRARY_DIR[ ]*\n", "", Notation)
            for Module in self.mInstModuleList:
                for LibraryDir in self.mModuleMap[Module].mInfo.mLibraryDir:
                    if (LibraryDir not in LibraryDirGen):
                        MakefileCode += "-L" + LibraryDir + "  \\\n         "
                        LibraryDirGen.append(LibraryDir)
            MakefileCode = MakefileCode[0:-13] + "\n"

        if (LinkedLibNotation.match(Notation)):
            MakefileCode = re.sub("%%LINKED_LIBRARY[ ]*\n", "", Notation)
            for Module in self.mInstModuleList:
                for LinkedLibrary  in self.mModuleMap[Module].mInfo.mLinkedLibrary:
                    if (LinkedLibrary not in LinkedLibGen):
                        MakefileCode += LinkedLibrary + " "
                        LinkedLibGen.append(LinkedLibrary)
            MakefileCode += "\n"

        if (ModelObjDirNotation.match(Notation)):
            MakefileCode = re.sub("%%MODEL_OBJECT_DIR[ ]*\n", "", Notation)
            for Module in self.mInstModuleList:
                for ImplementationFile in self.mModuleMap[Module].mInfo.mImplementationFile:
                    if (ImplementationFile not in ImplementationGen):
                        ImplementationFileName = ((ImplementationFile.split("/"))[-1].split("."))[0]
                        MakefileCode += "$(OBJ_DIR)/" + ImplementationFileName + ".o : " + ImplementationFile  +"\n"
                        MakefileCode += "\t$(strip $(CC)) $(CFLAGS) $(INCDIRS) -c $< -o $@\n\n"
                        ImplementationGen.append(ImplementationFile)
            MakefileCode = MakefileCode[0:-1]
        #----------------------------------------------------------------------

        return MakefileCode
# }}}

# Class used for storing the information of an initiator or a target of a bus
class CIniTgt:
# {{{ 
    def __init__(self):
        self.mInstance = ""
        self.mSocket   = ""
        self.mId       = 0
        self.mPointer  = False
        self.mIsBusModel = False     #Added by Loi Huynh
        self.mStartAddr = "0"
        self.mEndAddr   = "0"
        self.mMemSize   = "1024"
        self.mPreprocessor  = ""
# }}} 

# Class used for generating the list of initiators or targets of a bus
class CIniTgtGen(CGenIF):
# {{{  
    def __init__(self):
        CGenIF.__init__(self)
        self.mIsInitiators          = False
        self.mIniTgtMap             = []
        self.mModuleMapRef          = {}
        self.mBusName               = ""     # Store the name of bus
        self.mConnectedIniSocket    = {}     # Store the list of connected Initiator socket
        self.mEnvInfoRef            = None
        self.mParamMapRef           = []     # Added by Loi Huynh
        self.mIsBusConvAuto         = False

    def GetKeyword(self):
        if (self.mIsInitiators):
            return "%TOP_MODULE_INI_LIST"
        else:
            return "%TOP_MODULE_TGT_LIST"

    def ProcessSCILine(self, Line):
        SplitLine   = Line.split()
        if (self.mIsInitiators):
            CheckResult = self.CheckValidContent(SplitLine, 2, 2)
        else:
            CheckResult = self.CheckValidContent(SplitLine, 2, 3)

        if (CheckResult == None):
            if (SplitLine[0] in self.mModuleMapRef):

                NewIniTgt           = CIniTgt()
                NewIniTgt.mInstance = SplitLine[0]
                NewIniTgt.mSocket   = SplitLine[1]
                NewIniTgt.mId       = len(self.mIniTgtMap)
                NewIniTgt.mIsBusModel = self.mModuleMapRef[NewIniTgt.mInstance].mIsBusModel     #Added by Loi Huynh

                if (len(SplitLine) == 3 and SplitLine[2] == "pointer"):
                    NewIniTgt.mPointer = True
                if ("*" in SplitLine[1]):
                    NewIniTgt.mPointer = True
                    NewIniTgt.mSocket = re.sub("\*", "", SplitLine[1])

                self.mIniTgtMap.append(NewIniTgt)

                return None
            else:
                return [DbgLevel[2],"Instance name does not exist."]
        else:
            return CheckResult

    def GenTopCode (self, Notation):
        DetectNotation = "%%CONNECT_MODULES.*"

        if (re.search(DetectNotation, Notation) != None):
            RetLine = ""
            Indent  = re.sub(DetectNotation, "", Notation)
            Indent  = re.sub("\n","", Indent)

            for Module in self.mIniTgtMap:
                if (self.mIsInitiators):
                    TempConnectedSocket = "{}->{}".format(Module.mInstance, Module.mSocket)
                    if (TempConnectedSocket not in self.mConnectedIniSocket):
                        RetLine += "{}{}->{}({}->target_socket[{}]);\n".format(Indent, Module.mInstance, Module.mSocket, self.mBusName, Module.mId)
                        self.mConnectedIniSocket.append(TempConnectedSocket)
                    elif (Module.mPreprocessor == ""):
                        print ("[GenTopCode:%%CONNECT_MODULES] "  + DbgLevel[1] + ": "  + "Socket '%s' is duplicated."%TempConnectedSocket)
                else:
                    TempConnectedSocket = "{}->initiator_socket[{}]".format(self.mBusName, Module.mId)
                    if (TempConnectedSocket not in self.mConnectedIniSocket):
                        if (Module.mPointer): #Modified by Loi Huynh
                            RetLine += "{}{}->initiator_socket[{}](*{}->{});\n".format(Indent, self.mBusName, Module.mId, Module.mInstance, Module.mSocket)
                        else:
                            RetLine += "{}{}->initiator_socket[{}]({}->{});\n".format(Indent, self.mBusName, Module.mId, Module.mInstance, Module.mSocket)
                        self.mConnectedIniSocket.append(TempConnectedSocket)

            return RetLine

        return ""

    def GenHandleCommandCode(self):
        # Get bus clock
        BusClock=None
        for ParamMapRef in self.mParamMapRef:
            if (ParamMapRef.mInstance == self.mBusName):
                BusClock = ParamMapRef.mPeriod

        HandleCommandCode = ""

        if (BusClock != None):
            for Module in self.mIniTgtMap:
                if (self.mIsInitiators):
                    HandleCommandCode += "reslx."+ Module.mInstance + "\t\tini\t\tset_param\tm_bus_clk=" + BusClock +",SC_NS\n"
                    HandleCommandCode += "reslx."+ Module.mInstance + "\t\tini\t\tset_param\tm_bus_gnt=" + BusClock + ",SC_NS\n"
                else:
                    HandleCommandCode += "reslx."+ Module.mInstance + "\t\ttgt\t\tset_param\tm_bus_clk=" + BusClock + ",SC_NS\n"
                    HandleCommandCode += "reslx."+ Module.mInstance + "\t\ttgt\t\tset_param\tm_bus_rgnt=" + BusClock + ",SC_NS\n"

        return HandleCommandCode

    # A function to check the corresponding number of initiators, number of targets
    # between the template argument in %MODULE_LIST and declaration in TOP_MODULE_INI_LIST, TOP_MODULE_TGT_LIST
    def CheckNumIniTgt(self):
        IniTgtNumDict = {}
        BusList = ["Hpbc" , "Shwy"]
        dbg_level_string = "[" + (DbgLevel[2]).strip() + "]"

        #Increase number of initiator and target when insert the bus width conversion automatically
        if (self.mIsBusConvAuto):
            class_name = (self.mModuleMapRef[self.mBusName].mClassName).split('<')
            temp = class_name[1].split(',') 
            if (self.mIsInitiators):
                if (re.match("\d+", temp[0]) != None):
                    self.mModuleMapRef[self.mBusName].mClassName = class_name[0] + "<" + str(int(temp[0]) + 1) + "," + temp[1] + "," + temp[2]
                else:
                    self.mModuleMapRef[self.mBusName].mClassName = class_name[0] + "<" + temp[0] + "," + temp[1] + "," + temp[2]
            else:
                if (re.match("\d+", temp[1]) != None):
                    self.mModuleMapRef[self.mBusName].mClassName = class_name[0] + "<" + temp[0] + "," + str(int(temp[1]) + 1) + "," + temp[2]
                else:
                    self.mModuleMapRef[self.mBusName].mClassName = class_name[0] + "<" + temp[0] + "," + temp[1] + "," + temp[2]

        # Get class name
        for Module in self.mModuleMapRef:
            class_name = (self.mModuleMapRef[Module].mClassName).split('<')
            class_name = (class_name[0]).split('(')
            class_name = (class_name[0]).strip()
            if (class_name in BusList):
                bus_instance_name = self.mModuleMapRef[Module].mInstanceName
                temp = (self.mModuleMapRef[Module].mClassName).split(',')
                # Get the number of initiator and target of Shwy bus
                if (class_name == "Shwy"):
                    num_initiator = (temp[0]).split('<')
                    if (re.match("\d+", num_initiator[1]) != None):
                        num_initiator = int(num_initiator[1])
                    else:  num_initiator = -1
                    if (re.match("\d+", temp[1]) != None):
                        num_target = int(temp[1])
                    else:  num_target = -1

                # Get the number of target of Hpbc bus
                else:
                    num_initiator = 1
                    num_target = (temp[0]).split('<')
                    if (re.match("\d+", num_target[1]) != None):
                        num_target = int(num_target[1])
                    else: num_target = -1
                # Store got value into a dictionary
                IniTgtNumDict[bus_instance_name] = [num_initiator , num_target]

        # Check the corresponding
        for Module in self.mIniTgtMap:
            if (self.mIsInitiators):# Check number of initiator         
                if (IniTgtNumDict[self.mBusName][0] >= 0 and len(self.mIniTgtMap) != IniTgtNumDict[self.mBusName][0]):
                    print(dbg_level_string,": The number of initiators of ", self.mBusName," is not match.")
                    sys.exit()
            else:# Check number of target
                if (IniTgtNumDict[self.mBusName][1] >= 0 and len(self.mIniTgtMap) != IniTgtNumDict[self.mBusName][1]):
                    print(dbg_level_string,": The number of targets of ", self.mBusName," is not match.")
                    sys.exit()

        return ""
# }}}  

# Class used for storing the information of setting arbitration
class CSetArb:
# {{{
    def __init__(self):
        self.mBusId     = 0
        self.mReqOrResp = ""
        self.mArbTree   = ""
# }}} 

# Class used for generating the arbitration of a bus
class CSetArbGen(CGenIF):
# {{{ 
    def __init__(self):
        CGenIF.__init__(self)
        self.mSetArbMap             = []
        self.mIniModuleMapRef       = []
        self.mTgtModuleMapRef       = []
        self.mBusName               = ""
        self.mAddSocket             = ""
        self.mExternalIniDict       = []
        self.mExternalTgtDict       = []

    def GetKeyword(self):
        return "%SET_ARB"

    def ProcessSCILine(self, Line):
        SplitLine   = Line.split()
        CheckResult = self.CheckValidContent(SplitLine, 3)

        if (CheckResult == None):
            NewSetArb = CSetArb()
            # check bus id
            try:
                NewSetArb.mBusId = int(SplitLine[0])
            except ValueError:
                return [DbgLevel[2], "Bus ID should be an integer."]

            # check type, type must be req or resp.
            if (SplitLine[1] == "Req" or SplitLine[1] == "Resp"):
                NewSetArb.mReqOrResp = SplitLine[1]
            else:
                return [DbgLevel[2],"Invalid Req/Resp setting."]

            # check arbitration tree
            ArbTree = (re.findall("\"[a-zA-Z0-9_]*\"",SplitLine[2]))
            for Instance in ArbTree:
                InstId = ""
                InstanceName = Instance.replace("\"","")
                if (SplitLine[1] == 'Req'):
                    for Module in self.mIniModuleMapRef:
                        if (InstanceName == Module.mInstance):
                            InstId = "{}".format(Module.mId)
                            break
                        elif (InstanceName == "External_tgt"):
                            if (self.mAddSocket == "ADD_BOTH_SOCKET" or self.mAddSocket == "ADD_TGT_SOCKET"):
                                InstId = "{}".format(len(self.mIniModuleMapRef))
                                self.mExternalIniDict = [InstanceName , InstId]
                            else:
                                return [DbgLevel[2],"Adding external target TLM socket was not defined."]
                            break
                    if (InstId == ""):
                        return [DbgLevel[2],"Instance name of initiator does not exist in %TOP_MODULE_INI_LIST."]
                else:
                    for Module in self.mTgtModuleMapRef:
                        if (InstanceName == Module.mInstance):
                            InstId = "{}".format(Module.mId)
                            break
                        elif (InstanceName == "External_ini"):
                            if (self.mAddSocket == "ADD_BOTH_SOCKET" or self.mAddSocket == "ADD_INI_SOCKET"):
                                InstId = "{}".format(len(self.mTgtModuleMapRef))
                                self.mExternalTgtDict = [InstanceName , InstId]
                            else:
                                return [DbgLevel[2],"Adding external initiator TLM socket was not defined."]
                            break
                    if (InstId == ""):
                        return [DbgLevel[2],"Instance name of target does not exist in %TOP_MODULE_TGT_LIST."]

                SplitLine[2] = SplitLine[2].replace(Instance,InstId)

            PatternCheck = re.compile ("\((\(*\d+)+(([\/\-]\d+\)*)*([\/\-](\(*\d+)+([\/\-]\d+\)*)+)*)*\)$")
            if (re.match(PatternCheck, SplitLine[2]) != None):
                if (len(re.split("[\/\-]", SplitLine[2])) != len(ArbTree)):
                    return [DbgLevel[2],"Invalid Arbitration tree setting."]
            else:
                return [DbgLevel[2],"Invalid syntax of Arbitration tree setting."]
            NewSetArb.mArbTree = SplitLine[2]
            self.mSetArbMap.append(NewSetArb)
        else:
            return CheckResult

    def GenHandleCommandCode(self):
        CommentFlag = False
        HandleCommandCode = ""
        for SetArb in self.mSetArbMap:
            if not (CommentFlag):
                HandleCommandCode = "#instance\t\tcommand\t\tBUS_ID\t\tReq/Resp\tarb.tree\n"
                CommentFlag = True

            HandleCommandCode += "reslx." + self.mBusName + "\t\tset_arb\t\t" + str(SetArb.mBusId) + "\t\t"
            HandleCommandCode += SetArb.mReqOrResp + "\t\t" + SetArb.mArbTree + "\n"

        if not (HandleCommandCode == ""):
            HandleCommandCode += "\n"

        return HandleCommandCode
# }}}

# class used for storing address map information
class CAddressMap:
# {{{ 
    def __init__(self):
        self.mId        = ""
        self.mStartAddr = ""     # Store the start address of target
        self.mEndAddr   = ""     # Store the end address of target 
# }}}

# Class used for generating the address map of a bus
class CAddressMapGen(CGenIF):
# {{{
    def __init__(self):
        CGenIF.__init__(self)
        self.mAdressMap       = []
        self.mTgtModuleMapRef = []
        self.mBusName         = ""
        self.mTgtDict         = {} # Dictionary to store instance name of module which connect to target of Shwy

    def GetKeyword(self):
        return "%ADDRESS_MAP"

    def ProcessSCILine(self, Line):
        SplitLine   = Line.split()
        CheckResult = self.CheckValidContent(SplitLine, 3)

        if (CheckResult == None):
            NewAddr = CAddressMap()

            # check target name
            CheckResult = self.CheckValidInstanceName(SplitLine[2])
            if (len(CheckResult) == 1):
                for Module in self.mTgtModuleMapRef:
                    if (CheckResult[0] == Module.mInstance):
                        NewAddr.mId = "{}".format(Module.mId)
                        self.mTgtDict[NewAddr.mId] = Module.mInstance # Store to dictionary
                        break
            else:
                return CheckResult
            if (NewAddr.mId == ""):
                return [DbgLevel[2],"Instance name of target does not exist in %TOP_MODULE_TGT_LIST."]


            # check start address and end address
            CheckResult = self.CheckValidValue(SplitLine[0], None, int, False)
            if (len(CheckResult) == 1):
                NewAddr.mStartAddr = SplitLine[0]
            else:
                return CheckResult

            CheckResult = self.CheckValidValue(SplitLine[1], None, int, False)
            if (len(CheckResult) == 1):
                NewAddr.mEndAddr = SplitLine[1]
            else:
                return CheckResult

            self.mAdressMap.append(NewAddr)
        else:
            return CheckResult

    def GenHandleCommandCode(self):
        CommentFlag = False
        HandleCommandCode = ""
        for Address in self.mAdressMap:
            if not (CommentFlag):
                HandleCommandCode = "#instance\t\tcommand\t\tstart_add\tend_add\t\ttgt_ID\n"
                CommentFlag = True
            HandleCommandCode += "reslx." + self.mBusName + "\t\tset_addrmap\t" + Address.mStartAddr + "\t"
            HandleCommandCode += Address.mEndAddr + "\t" + Address.mId + "\n"

        if not (HandleCommandCode == ""):
            HandleCommandCode += "\n"

        return HandleCommandCode
# }}} 

# Class used for storing information of group of initiator or target
class CSetIniTgtGrp:
# {{{
    def __init__(self):
        self.mId    = ""
        self.mGrpId = ""
# }}} 

# Class used for generating the group declarations of initiators or targets of a bus
class CSetIniTgtGrpGen(CGenIF):
# {{{
    def __init__(self): 
        CGenIF.__init__(self)
        self.mIsInitiators      = False
        self.mModuleMapRef      = []
        self.mSetIniTgtMap      = []
        self.mBusName           = ""
        self.mAddSocket         = ""
#        self.mShwyModuleDict    = {}   # Dictionary to store instance name of module which connect to target of Shwy

    def GetKeyword(self):
        if (self.mIsInitiators):
            return "%SET_INIGRP"
        else:
            return "%SET_TGTGRP"

    def ProcessSCILine(self, Line):
        SplitLine   = Line.split()
        CheckResult = self.CheckValidContent(SplitLine, 2)

        if (CheckResult == None):
            # check module name
            OldLen = len(self.mSetIniTgtMap)
            CheckResult = self.CheckValidInstanceName(SplitLine[0])
            if (len(CheckResult) == 1):
                for Module in self.mModuleMapRef:
                    if (CheckResult[0] == Module.mInstance):
                        # check group id
                        CheckResult = self.CheckValidValue(SplitLine[1], None, int, False)
                        if (len(CheckResult) == 1):
                            NewSetGrp        = CSetIniTgtGrp()
                            NewSetGrp.mId    = "{}".format(Module.mId)
                            NewSetGrp.mGrpId = SplitLine[1]
                            self.mSetIniTgtMap.append(NewSetGrp)
#                            self.mShwyModuleDict[NewSetGrp.mId] = Module.mInstance #store to dictionary

                            return None
                        else:
                            return CheckResult
            else:
                return CheckResult

            if (OldLen == len(self.mSetIniTgtMap)):
                CheckResult = self.CheckValidInstanceName(SplitLine[0])
                ExternalId = None
                if (self.mIsInitiators):
                    if (CheckResult[0] == "External_tgt" and (self.mAddSocket == "ADD_BOTH_SOCKET" or self.mAddSocket == "ADD_TGT_SOCKET")):
                        ExternalId = len(self.mModuleMapRef)
                    else:
                        return [DbgLevel[2],"Instance name of initiator does not exist in %TOP_MODULE_INI_LIST."]
                else:
                    if (CheckResult[0] == "External_ini" and (self.mAddSocket == "ADD_BOTH_SOCKET" or self.mAddSocket == "ADD_INI_SOCKET")):
                        ExternalId = len(self.mModuleMapRef)
                    else:
                        return [DbgLevel[2],"Instance name of target does not exist in %TOP_MODULE_TGT_LIST."   ]
                # check group id
                CheckResult = self.CheckValidValue(SplitLine[1], None, int, False)
                if (len(CheckResult) == 1):
                    NewSetGrp        = CSetIniTgtGrp()
                    NewSetGrp.mId    = "{}".format(ExternalId)
                    NewSetGrp.mGrpId = SplitLine[1]
                    self.mSetIniTgtMap.append(NewSetGrp)
#                    if (self.mIsInitiators):
#                        self.mShwyModuleDict[NewSetGrp.mId] = "External_tgt" #store to dictionary
#                    else:
#                        self.mShwyModuleDict[NewSetGrp.mId] = "External_ini" #store to dictionary

                    return None
                else:
                    return CheckResult
        else:
            return CheckResult

    def GenHandleCommandCode(self):
        Command = ""
        CommentFlag = False
        HandleCommandCode = ""
        if (self.mIsInitiators):
            Command = "set_inigrp"
        else:
            Command = "set_tgtgrp"

        for SetGrp in self.mSetIniTgtMap:
            if not (CommentFlag):
                if (self.mIsInitiators):
                    HandleCommandCode = "#instance\t\tcommand\t\tini_ID\t\tini_grp_ID\n"
                else:
                    HandleCommandCode = "#instance\t\tcommand\t\ttgt_ID\t\ttgt_grp_ID\n"
                CommentFlag = True
            HandleCommandCode += "reslx." + self.mBusName + "\t\t" + Command + "\t\t" + str(SetGrp.mId) + "\t\t" + str(SetGrp.mGrpId) + "\n"            
#            num_tab_first = int(len("reslx." + self.mBusName)/8)
#            num_tab_last = int(len(self.mShwyModuleDict[SetGrp.mId])/8)
#            HandleCommandCode += "reslx." + self.mBusName + "\t"*(3-num_tab_first) + Command
#            HandleCommandCode += "\t" + str(SetGrp.mId) + "\t"*(2-num_tab_last) + str(SetGrp.mGrpId) + "\n"

        if not (HandleCommandCode == ""):
            HandleCommandCode += "\n"

        return HandleCommandCode

# }}} 

# Class used for generating the bus declaration
class CBusInfoGen(CGenIF):
# {{{
    def __init__(self, ModuleMapRef, ParamMapRef):   # Added by Loi Huynh
        CGenIF.__init__(self)

        self.mBusInstance  = ""
        self.mListExistBus = []
        self.mModuleMapRef = ModuleMapRef

        self.mInfoGen = {}
        self.mIniGen  = CIniTgtGen()
        self.mIniGen.mIsInitiators = True
        self.mIniGen.mModuleMapRef = ModuleMapRef
        self.mIniGen.mParamMapRef = ParamMapRef     #Added Loi Huynh
        self.mInfoGen[self.mIniGen.GetKeyword()] = self.mIniGen

        self.mTgtGen = CIniTgtGen()
        self.mTgtGen.mIsInitiators = False
        self.mTgtGen.mModuleMapRef = ModuleMapRef
        self.mTgtGen.mParamMapRef = ParamMapRef     #Added Loi Huynh
        self.mInfoGen[self.mTgtGen.GetKeyword()] = self.mTgtGen

        self.mSetArbGen = CSetArbGen()
        self.mSetArbGen.mIniModuleMapRef = self.mIniGen.mIniTgtMap
        self.mSetArbGen.mTgtModuleMapRef = self.mTgtGen.mIniTgtMap
        self.mInfoGen[self.mSetArbGen.GetKeyword()] = self.mSetArbGen

        self.mSetIniGrpGen = CSetIniTgtGrpGen()
        self.mSetIniGrpGen.mIsInitiators               = True
        self.mSetIniGrpGen.mModuleMapRef               = self.mIniGen.mIniTgtMap
        self.mInfoGen[self.mSetIniGrpGen.GetKeyword()] = self.mSetIniGrpGen

        self.mSetTgtGrpGen = CSetIniTgtGrpGen()
        self.mSetTgtGrpGen.mIsInitiators               = False
        self.mSetTgtGrpGen.mModuleMapRef               = self.mTgtGen.mIniTgtMap
        self.mInfoGen[self.mSetTgtGrpGen.GetKeyword()] = self.mSetTgtGrpGen

        self.mAddressMapGen = CAddressMapGen()
        self.mAddressMapGen.mTgtModuleMapRef            = self.mTgtGen.mIniTgtMap
        self.mInfoGen[self.mAddressMapGen.GetKeyword()] = self.mAddressMapGen

        self.mConnectedIniSocket = []        # This list used to avoid duplicated connected among buses.

    def GetKeyword(self):
        return "%BUS_INFO"

    def CheckMandatory(self):
        if (not self.mDone):
            return [DbgLevel[2], "Lack of %BUS_INFO information."]

#        MandatoryList = [self.mIniGen, self.mTgtGen, self.mAddressMapGen]
        MandatoryList = [self.mTgtGen, self.mAddressMapGen]       #Modified by Trong Truong
        for MandatoryGen in MandatoryList:
            CheckResult = MandatoryGen.CheckMandatory()
            if (CheckResult != None):
                return CheckResult

        return None

    def AddSCISource (self, Lines, LineIndex, EndKeywordIndex, mSciFile, PrintDebugMsg):
        if (Lines[LineIndex] == self.GetKeyword()):
            if (not self.mDone):
                HasContent = False
                for Index in range(LineIndex + 1, EndKeywordIndex + 1):
                    if (Lines[Index] != ""):
                        if (not self.mDone):
                            HasContent = True
                            SplitLine   = Lines[Index].split()
                            CheckResult = self.CheckValidContent(SplitLine, 1)

                            if (CheckResult == None):
                                if (Lines[Index] in self.mModuleMapRef):
                                    self.mBusInstance = Lines[Index]
                                    self.mModuleMapRef[self.mBusInstance].mIsBusModel = True     #Added by Loi Huynh
                                    self.mDone        = True
                                else:
                                    PrintDebugMsg(mSciFile, Index, DbgLevel[2], "Bus instance is not declared in %MODULE_LIST.")
                            else:
                                PrintDebugMsg(mSciFile, Index, CheckResult[0], CheckResult[1])
                            if (self.mBusInstance not in self.mListExistBus):
                                self.mListExistBus.append(self.mBusInstance)
                            else:
                                PrintDebugMsg(mSciFile, Index, DbgLevel[2], "Duplicated bus instance name.")
                        else:
                            PrintDebugMsg(mSciFile, Index, DbgLevel[2], "Invalid content of %BUS_INFO.")

                if (not HasContent):     # BUS_INFO information is empty
                    PrintDebugMsg(mSciFile, LineIndex, DbgLevel[2], "Lack of %BUS_INFO information.")
                self.mDone = HasContent
                return True
            else:
                CheckMandatory = self.CheckMandatory()
                if (CheckMandatory != None):
                    PrintDebugMsg(mSciFile, LineIndex, CheckMandatory[0], CheckMandatory[1])
                return False
        else:
            if (Lines[LineIndex] in self.mInfoGen):
                return self.mInfoGen[Lines[LineIndex]].AddSCISource(Lines, LineIndex, EndKeywordIndex, mSciFile, PrintDebugMsg)
            else:
                return False

    def GenTopCode (self, Notation):
        self.mIniGen.mBusName = self.mBusInstance
        self.mTgtGen.mBusName = self.mBusInstance

        self.mIniGen.mConnectedIniSocket = self.mConnectedIniSocket
        self.mTgtGen.mConnectedIniSocket = self.mConnectedIniSocket

        RetLine = ""

        RetLine += self.mIniGen.GenTopCode(Notation)
        RetLine += self.mTgtGen.GenTopCode(Notation)

        return RetLine

    def GenHandleCommandCode (self):
        HandleCommandCode = ""
        self.mSetArbGen.mBusName     = self.mBusInstance

        HandleCommandCode += self.mSetArbGen.GenHandleCommandCode()
        self.mAddressMapGen.mBusName = self.mBusInstance

        HandleCommandCode += self.mAddressMapGen.GenHandleCommandCode()
        self.mSetIniGrpGen.mBusName  = self.mBusInstance

        HandleCommandCode += self.mSetIniGrpGen.GenHandleCommandCode()
        self.mSetTgtGrpGen.mBusName  = self.mBusInstance
 
        HandleCommandCode += self.mSetTgtGrpGen.GenHandleCommandCode()

        if not (HandleCommandCode == ""):
            HandleCommandCode = "#Setting parameters for bus " + self.mBusInstance + "\n" + HandleCommandCode

        return HandleCommandCode

    def GetBusName(self):
        return self.mBusInstance
# }}} 

class CMainGenerator:
# {{{
    def __init__(self):
        self.mSciFile          = "top.sci"
        self.mScriptName       = os.path.basename(__file__)
        self.mInputPath        = "./" 
        self.mOutputPath       = os.path.abspath(os.path.dirname(__file__)) + "/" 
        #----------------------------------------------
        self.mCompileOption    = []
        self.mModelInfoFile    = []
        self.mEnvMode          = ""
        #----------------------------------------------

        self.mDefineMacro      = CDefineMacroGen()
        self.mModuleList       = CModuleListGen()
        self.mEnvInfoGen       = CEnvInfoGen()
        self.mClockInfoGen     = CClockInfoGen()
        self.mClockParamGen    = CClockParameterGen()
        self.mHandleCmdGen     = CHandleCommandGen()
        self.mChannelSysGen    = CChannelSysGen()
        self.mVcSpecificSysGen = CVcSpecificSysGen()
        self.mBindTLMSocketGen = CBindTLMSocketGen()     #Added by Loi Huynh

        self.mBusInfoGen       = [CBusInfoGen(self.mModuleList.mModuleMap,self.mClockParamGen.mParamMap)]
        self.mInfoGen          = [self.mDefineMacro, self.mEnvInfoGen, self.mClockInfoGen, self.mClockParamGen, self.mChannelSysGen, self.mVcSpecificSysGen, self.mBindTLMSocketGen, self.mModuleList, self.mHandleCmdGen]     #Modified by Loi Huynh

        # Set reference for Environment Info Gen
        self.mEnvInfoGen.mMacroRef   = self.mDefineMacro.mMacro

        # Set references for Module List Gen
        self.mModuleList.mInputPath  = self.mInputPath
        self.mModuleList.mModelInfoFilePaths = self.mModelInfoFile     # Added by Loi Huynh
        self.mModuleList.emType      = modelinfo_parser.GetType() #["in"  ,"out"    ,"inout","signal","buffer"]
        self.mModuleList.emClassType = modelinfo_parser.GetClassType() #["bool","sc_uint","sc_biguint"             ]
        self.mModuleList.mMacroRef   = self.mDefineMacro.mMacro

        # Set references Channel Sys Gen
        self.mChannelSysGen.emType        = self.mModuleList.emType
        self.mChannelSysGen.emClassType   = self.mModuleList.emClassType
        self.mChannelSysGen.mClockMapRef  = self.mClockInfoGen.mClockMap
        self.mChannelSysGen.mMacroRef     = self.mDefineMacro.mMacro
        self.mChannelSysGen.mModuleMapRef = self.mModuleList.mModuleMap

        # Set references for VcSpecificSys Gen
        self.mVcSpecificSysGen.mClockMapRef      = self.mClockInfoGen.mClockMap
        self.mVcSpecificSysGen.mChannelSysMapRef = self.mChannelSysGen.mChannelSysMap
        self.mVcSpecificSysGen.mModuleMapRef     = self.mModuleList.mModuleMap
        self.mVcSpecificSysGen.mMacroRef         = self.mDefineMacro.mMacro
        self.mVcSpecificSysGen.mInitPort         = self.mChannelSysGen.mInitPort
        self.mVcSpecificSysGen.emClassType       = self.mModuleList.emClassType

        # Set references for BindTLMSocket Gen
        self.mBindTLMSocketGen.mModuleMapRef     = self.mModuleList.mModuleMap     #Added by Loi Huynh

        # Set references for Clock Info Gen
        self.mClockInfoGen.mMacroRef = self.mDefineMacro.mMacro

        # Set references for Clock Parameter Gen
        self.mClockParamGen.mClockMapRef  = self.mClockInfoGen.mClockMap
        self.mClockParamGen.mModuleMapRef = self.mModuleList.mModuleMap

        # Error Flag 
        self.mErrorFlag = False
        
    def SetInputPath(self, InputPath):
        self.mInputPath             = InputPath
        self.mModuleList.mInputPath = InputPath

    #--------------------------------
    # Added by Loi Huynh
    def SetModelInfoFilePath(self, ModelInfoFilePaths):
        self.mModelInfoFile                  = ModelInfoFilePaths
        self.mModuleList.mModelInfoFilePaths = ModelInfoFilePaths
    #--------------------------------

    # Get the ending index of block content of a keyword from a starting index of that keyword
    def GetBlockContent(self, SourceLines, StartIndex):
        if (SourceLines[StartIndex].startswith("%")):
            ProcessedIndex = 0

            for ProcessedIndex in range(StartIndex + 1, len(SourceLines)):
                SourceLines[ProcessedIndex] = re.sub("[ ]*#.*","",SourceLines[ProcessedIndex])
                SourceLines[ProcessedIndex] = re.sub("\n" ,"",SourceLines[ProcessedIndex])
                SourceLines[ProcessedIndex] = SourceLines[ProcessedIndex].strip()
                if (SourceLines[ProcessedIndex].startswith("%")):
                    return (ProcessedIndex - 1)
            
            return ProcessedIndex
        else:   # If the Index is not the starting point of the keyword, return None
            return None

    # Open SCI file and pass the content into each component
    def ParseSCIFile(self):
        # open SCI file
        SourceFile = self.OpenFile (self.mSciFile, "r")

        if (SourceFile == None):
            return

        # read all content
        Lines     = SourceFile.readlines()
        LineIndex = 0
        IsNotErr = False 
        while (LineIndex < len(Lines)):
            Lines[LineIndex] = re.sub("[ ]*#.*","",Lines[LineIndex])
            Lines[LineIndex] = re.sub("\n" ,"",Lines[LineIndex])

            if (Lines[LineIndex].strip() != ""):
                EndKeywordIndex = self.GetBlockContent(Lines, LineIndex)
                if (EndKeywordIndex != None and EndKeywordIndex != 0):
                    Result = False     # True: the content is processed by a sub generator
                                       # False: the content is not processed by a sub generator
                    for Info in self.mInfoGen:
                        Result = Result or Info.AddSCISource(Lines, LineIndex, EndKeywordIndex, self.mSciFile, self.PrintDebugMsg)

                    self.mBusInfoGen[-1].mSetArbGen.mAddSocket          = self.mEnvInfoGen.mAddSocket
                    self.mBusInfoGen[-1].mSetIniGrpGen.mAddSocket       = self.mEnvInfoGen.mAddSocket
                    self.mBusInfoGen[-1].mSetTgtGrpGen.mAddSocket       = self.mEnvInfoGen.mAddSocket
                    Result = Result or self.mBusInfoGen[-1].AddSCISource(Lines, LineIndex, EndKeywordIndex, self.mSciFile, self.PrintDebugMsg)

                    # If there is no sub-generator accepting the content, try adding new CBusInfoGen
                    if ((not Result) and Lines[LineIndex] == self.mBusInfoGen[0].GetKeyword()):
                        self.mBusInfoGen.append(CBusInfoGen(self.mModuleList.mModuleMap,self.mClockParamGen.mParamMap))     # Modified by Loi Huynh
                        self.mBusInfoGen[-1].mConnectedIniSocket = self.mBusInfoGen[0].mConnectedIniSocket
                        self.mBusInfoGen[-1].mListExistBus       = self.mBusInfoGen[0].mListExistBus
                        Result = Result or self.mBusInfoGen[-1].AddSCISource(Lines, LineIndex, EndKeywordIndex, self.mSciFile, self.PrintDebugMsg)

                    if (not Result):
                        self.PrintDebugMsg(self.mSciFile, LineIndex, DbgLevel[2], "Invalid content.")

                    LineIndex = EndKeywordIndex + 1
                    IsNotErr = Result
                else:
                    self.PrintDebugMsg(self.mSciFile, LineIndex, DbgLevel[2], "There is no keyword cover this line.")
                    LineIndex += 1
                    IsNotErr = False
            else:
                LineIndex += 1
        #---Added by Trong Truong------------
        #check whether have bus width conversion or not
        HasDconv = False
        ModuleMapId = len(self.mInfoGen)-2
        for Module in self.mInfoGen[ModuleMapId].mModuleMap:
            class_name = (self.mInfoGen[ModuleMapId].mModuleMap[Module].mClassName).split('<')
            class_name = (class_name[0]).strip()
            if (class_name == "tlm_dconv"):
                HasDconv = True
        #Check whether has two different bus width of Shwy or not 
        BusWidthShwy = []
        if (len(self.mBusInfoGen) == 2):
            for BusInfo in self.mBusInfoGen:
                if BusInfo.mBusInstance in self.mInfoGen[ModuleMapId].mModuleMap: 
                    class_name = (self.mInfoGen[ModuleMapId].mModuleMap[BusInfo.mBusInstance].mClassName).split('<')
                    class_name = (class_name[0]).split('(')
                    class_name = (class_name[0]).strip()        
                    if (class_name == "Shwy"):
                        temp = (self.mInfoGen[ModuleMapId].mModuleMap[BusInfo.mBusInstance].mClassName).split(',')
                        bus_width = (temp[2]).split('>')
                        bus_width = (bus_width[0]).strip()
                        BusWidthShwy.append(bus_width)
        IsDiffBusWidth = False
        if (len(BusWidthShwy) == 2):
            if (not self.mInfoGen[0].mMacro[BusWidthShwy[0]].mMacroValue == self.mInfoGen[0].mMacro[BusWidthShwy[1]].mMacroValue):
                IsDiffBusWidth = True

        #Insert the bus width conversion
        if IsDiffBusWidth and (not HasDconv) and IsNotErr:
            IndexLowBus = 0
            IndexHighBus = 1
            if (len(self.mBusInfoGen[0].mIniGen.mIniTgtMap) > 0) and (self.mBusInfoGen[0].mIniGen.mIniTgtMap[0].mInstance == "cpu"):
                IndexHighBus = 0
                IndexLowBus = 1
            BusWidth0 = int(self.mInfoGen[0].mMacro[BusWidthShwy[0]].mMacroValue)
            BusWidth1 = int(self.mInfoGen[0].mMacro[BusWidthShwy[1]].mMacroValue)
            if (BusWidth0 > BusWidth1):
                Dconv_Module = CModule("tlm_dconv<" + BusWidthShwy[0] + ","+ BusWidthShwy[1] + ">(\"dconv\")", "dconv")
            else:
                Dconv_Module = CModule("tlm_dconv<" + BusWidthShwy[1] + ","+ BusWidthShwy[0] + ">(\"dconv\")", "dconv")
            self.mInfoGen[ModuleMapId].mModuleMap["dconv"] = Dconv_Module
            self.mInfoGen[ModuleMapId].mInstModuleList.append("dconv")
            self.mInfoGen[ModuleMapId].mModuleMap["dconv"].mInfo.mHeaderFile.append("tlm_dconv.h")
            #Bus 64
            NewTgt           = CIniTgt()
            NewTgt.mInstance = "dconv" 
            NewTgt.mSocket   = "m_tgt_socket"
            NewTgt.mId       = len(self.mBusInfoGen[IndexHighBus].mTgtGen.mIniTgtMap)        
            self.mBusInfoGen[IndexHighBus].mTgtGen.mIniTgtMap.append(NewTgt)
            self.mBusInfoGen[IndexHighBus].mTgtGen.mIsBusConvAuto = True
            #Address map
            NewAddr = CAddressMap()
            NewAddr.mId = str(NewTgt.mId)
            NewAddr.mStartAddr = "0xFF000000"
            NewAddr.mEndAddr   = "0xFFFFFFFF"
            self.mBusInfoGen[IndexHighBus].mAddressMapGen.mAdressMap.append(NewAddr)
            #SetArb
            if len(self.mBusInfoGen[IndexHighBus].mSetArbGen.mSetArbMap) == 2:
                TempArbTree = self.mBusInfoGen[IndexHighBus].mSetArbGen.mSetArbMap[1].mArbTree
                TempArbTree = TempArbTree.replace(")","/")
                TempArbTree += str(NewTgt.mId) + ")"
                self.mBusInfoGen[IndexHighBus].mSetArbGen.mSetArbMap[1].mArbTree = TempArbTree
            #Set_tgtgrp
            NewSetTgtGrp        = CSetIniTgtGrp()
            NewSetTgtGrp.mId    = str(NewTgt.mId)
            NewSetTgtGrp.mGrpId = "0"
            self.mBusInfoGen[IndexHighBus].mSetTgtGrpGen.mSetIniTgtMap.append(NewSetTgtGrp)

            #Bus 32
            NewIni           = CIniTgt()
            NewIni.mInstance = "dconv" 
            NewIni.mSocket   = "m_ini_socket"
            NewIni.mId       = len(self.mBusInfoGen[IndexLowBus].mIniGen.mIniTgtMap)
            self.mBusInfoGen[IndexLowBus].mIniGen.mIniTgtMap.append(NewIni)
            self.mBusInfoGen[IndexLowBus].mIniGen.mIsBusConvAuto = True
            #Set_inigrp
            NewSetIniGrp        = CSetIniTgtGrp()
            NewSetIniGrp.mId    = "0" 
            NewSetIniGrp.mGrpId = "0"
            self.mBusInfoGen[IndexLowBus].mSetIniGrpGen.mSetIniTgtMap.append(NewSetIniGrp)
            #SetArb
            if len(self.mBusInfoGen[IndexLowBus].mSetArbGen.mSetArbMap) > 0:
                NewSetArb = CSetArb()
                NewSetArb.mBusId = self.mBusInfoGen[IndexLowBus].mSetArbGen.mSetArbMap[-1].mBusId
                NewSetArb.mReqOrResp = "Req"
                NewSetArb.mArbTree = "(0)"
                self.mBusInfoGen[IndexLowBus].mSetArbGen.mSetArbMap.append(NewSetArb)
                self.mBusInfoGen[IndexLowBus].mSetArbGen.mSetArbMap.reverse()

            print("[" + DbgLevel[1] + "] : The bus width conversion is inserted automatically.")            
        #----------------------------------
        # check mandatory
        MandatoryList = [self.mEnvInfoGen, self.mModuleList]
        MandatoryList.append(self.mBusInfoGen[-1])

        for MandatoryGen in MandatoryList:
            CheckResult = MandatoryGen.CheckMandatory()
            if (CheckResult != None):
                self.PrintDebugMsg(self.mSciFile, len(Lines), CheckResult[0], CheckResult[1])

        # Combine BusInfo into mInfoGen
        self.mInfoGen.extend(self.mBusInfoGen)

        message = ""
        for bus in self.mBusInfoGen:
            num_of_ini = len(bus.mIniGen.mIniTgtMap)
            num_of_tgt = len(bus.mTgtGen.mIniTgtMap)
            preprocessor_flag = 0
            for t in bus.mIniGen.mIniTgtMap:
                if (t.mPreprocessor != ""): 
                    preprocessor_flag = 1
                    break
            if (preprocessor_flag == 0):
                for t in bus.mTgtGen.mIniTgtMap:
                    if (t.mPreprocessor != ""): 
                        preprocessor_flag = 1
                        break
            # Auto generate number of initiator and target for each bus
            macro_name_ini = "NR_INI_" + bus.mBusInstance.upper()
            macro_name_tgt = "NR_TGT_" + bus.mBusInstance.upper()
            if (macro_name_ini not in self.mDefineMacro.mMacro): self.mDefineMacro.mMacro[macro_name_ini] = CMacro(macro_name_ini, str(num_of_ini), "")
            elif (preprocessor_flag == 0):
                message += "\t[%s]\t: INI (%d), \tTGT(%d)\n"%(bus.mBusInstance, num_of_ini, num_of_tgt)
            if (macro_name_tgt not in self.mDefineMacro.mMacro): self.mDefineMacro.mMacro[macro_name_tgt] = CMacro(macro_name_tgt, str(num_of_tgt), "")
            elif (preprocessor_flag == 0):
                message += "\t[%s]\t: INI (%d), \tTGT(%d)\n"%(bus.mBusInstance, num_of_ini, num_of_tgt)
            if (preprocessor_flag == 1):
                message += "\t[%s]\t: INI (%d), \tTGT(%d)\n"%(bus.mBusInstance, num_of_ini, num_of_tgt)
        if (message != ""):
            message = "\t>>>> Please check again the number of ini and target at bus instantiation to avoid simulation error.\n" + message
            print(message)


    # Generate the specific (old) code
    def GenSpecificTopCode (self, OldTopLines, StartSpecificNotation, EndSpecificNotation):
        RetLine = ""

        # Generate specific code
        for Line in OldTopLines:
            if   (re.search(StartSpecificNotation, Line) != None):
                RetLine += Line
            elif (re.search(EndSpecificNotation  , Line) != None):
                if ("sbsc" in self.mModuleList.mInstModuleList and "GEN_SPECIFIC_CONNECT_HANDLER_POST_END" in EndSpecificNotation):
                    RetLine += "        std::vector<std::string> cmd_line;\n"
                    RetLine += "        cmd_line.clear();\n"
                    RetLine += "        cmd_line.push_back(\"set_mem\");\n"
                    RetLine += "        cmd_line.push_back(\"0x00000000\");\n"
                    RetLine += "        cmd_line.push_back(\"2G\");\n"
                    RetLine += "        sbsc->handleCommand(cmd_line);\n"
                    RetLine += "        cmd_line.clear();\n"
                RetLine += Line
                return RetLine
            elif (RetLine != ""):
                if ("cmd_line" not in Line):
                    RetLine += Line
                elif ("simple_memory" in self.mModuleList.mInstModuleList):
                    RetLine += Line
        return ""

    def GenTopCode(self):
        # Generate top.h file
        for BusInfoGen in self.mBusInfoGen:
            if (self.mErrorFlag):
                break
            else:
                # Get bus name
                BusInfoGen.mIniGen.mBusName = BusInfoGen.GetBusName()
                BusInfoGen.mTgtGen.mBusName = BusInfoGen.GetBusName()
                # Check number of Initiator, Target
                BusInfoGen.mIniGen.CheckNumIniTgt()
                BusInfoGen.mTgtGen.CheckNumIniTgt()        
        if (not os.path.isfile(self.mInputPath + "top.h.skl")):
            self.mInputPath = "./Input/"
        TopSklFile = self.mInputPath  + "top.h.skl"
        TopFile    = self.mOutputPath + "top.h"
        TempFile   = self.mOutputPath + "top_gen_temp.tmp"
        write_flag = self.CheckAllowWrite("top.h") # Flag to decide write or not
            
        if (write_flag): # If top.h is ALLOWED to [OVER]WRITE
            # Open skeleton and temporary file
            TopSkl     = self.OpenFile(TopSklFile, "r")
            GenTopFile = self.OpenFile(TempFile  , "w")

            OldTopFile = None

            try:
                OldTopFile = open(TopFile, "r")
            except IOError:
                self.PrintDebugMsg(self.mScriptName,0, DbgLevel[1],"Old file " + TopFile + " does not exist.")

            if (TopSkl == None or GenTopFile == None):
                return

            TopSklLines = TopSkl.readlines()
            TopSkl.close()

            OldTopLines = []
            if (OldTopFile == None):
                OldTopLines = TopSklLines
            else:
                OldTopLines = OldTopFile.readlines()
                OldTopFile.close()

            GenSpecificFlag = False     # Flag indicates the specific block
            GenSpecificName = ""     # Name of the current specific block
            Notation        = re.compile(".*%%.*")
        
            for TopLine in TopSklLines:
                if (Notation.match(TopLine)):
                    StartSpecificLine = re.compile(".*%%GEN_SPECIFIC.*POST_START.*")
                    EndSpecificLine   = re.compile(".*%%GEN_SPECIFIC.*POST_END.*"  )

                    if   (StartSpecificLine.match(TopLine) != None):
                        GenSpecificFlag = True
                        GenSpecificName = re.search("%%GEN_SPECIFIC.*POST_START", TopLine).group(0)
                    elif (GenSpecificFlag and EndSpecificLine.match(TopLine) != None):
                        GenSpecificFlag = False
                        EndSpecificName = re.search("%%GEN_SPECIFIC.*POST_END"  , TopLine).group(0)
                        GenTopFile.write(self.GenSpecificTopCode(OldTopLines, GenSpecificName, EndSpecificName))
                    else:
                        for Info in self.mInfoGen:
                            GenTopFile.write(Info.GenTopCode(TopLine))
                else:
                    if (not GenSpecificFlag):
                        GenTopFile.write(TopLine)

            # Close temporary file and rename it to top.h file.
            GenTopFile.close ()
            if (not self.mErrorFlag):
                shutil.copy  (TempFile, TopFile)
            os.remove(TempFile)

        return ""

    def GenTopMainCode(self):
        # Generate top_main.cpp file
        if (not os.path.isfile(self.mInputPath + "top_main.cpp.skl")):
            self.mInputPath = "./Input/"
        TopMainSklFile = self.mInputPath  + "top_main.cpp.skl"
        TopMainFile    = self.mOutputPath + "top_main.cpp"
        TempFile       = self.mOutputPath + "top_gen_temp.tmp"
        write_flag = self.CheckAllowWrite("top_main.cpp") # Flag to decide write or not

        if (write_flag): # # If top_main.cpp is ALLOWED to [OVER]WRITE
            # Open skeleton and temporary file
            TopMainSkl     = self.OpenFile(TopMainSklFile, "r")
            GenTopMainFile = self.OpenFile(TempFile      , "w")

            if (TopMainSkl == None or GenTopMainFile == None):
                return

            TopMainSklLines = TopMainSkl.readlines()
            TopMainSkl.close()

            Notation = re.compile(".*%%.*")

            for TopMainLine in TopMainSklLines:
                if (Notation.match(TopMainLine)):
                    for Info in self.mInfoGen:
                        GenTopMainFile.write(Info.GenTopMainCode(TopMainLine))
                else:
                    GenTopMainFile.write(TopMainLine)

            # Close temporary file and rename it to top.h file.
            GenTopMainFile.close ()
            if (not self.mErrorFlag):
                shutil.copy  (TempFile, TopMainFile)
            os.remove(TempFile)

        return ""

    def GenMakefileCode(self):
        # Generate top_main.cpp file
        if (not os.path.isfile(self.mInputPath + "Makefile.skl")):
            self.mInputPath = "./Input/"
        MakefileSklFile = self.mInputPath  + "Makefile.skl"
        MakefileFile    = self.mOutputPath + "Makefile"
        TempFile        = self.mOutputPath + "top_gen_temp.tmp"
        write_flag = self.CheckAllowWrite("Makefile") # Flag to decide write or not

        if (write_flag): # # If Makefile is ALLOWED to [OVER]WRITE
            # Open skeleton and temporary file
            MakefileSkl     = self.OpenFile(MakefileSklFile, "r")
            GenMakefileFile = self.OpenFile(TempFile       , "w")

            # Generate compile option
            CompileOptionNotation = re.compile(".*%%COMPILE_OPTION")     #Added by Loi Huynh
            LinkLibraryNotation = re.compile(".*%%ENV_LIBRARY")     #Added by Loi Huynh

            if (MakefileSkl == None or GenMakefileFile == None):
                return

            MakefileSklLines = MakefileSkl.readlines()
            MakefileSkl.close()

            Notation = re.compile(".*%%.*")

            for MakefileLine in MakefileSklLines:
                #------------------------------------------------------
                #Added by Loi Huynh
                if (CompileOptionNotation.match(MakefileLine)):
                    MakefileCode = re.sub("%%COMPILE_OPTION[ ]*\n","",MakefileLine)
                    for CompileOption in self.mCompileOption:
                        MakefileCode += " " + CompileOption
                    GenMakefileFile.write(MakefileCode)
                #------------------------------------------------------
                elif (LinkLibraryNotation.match(MakefileLine)):
                    if (self.mEnvMode == "astc"):
                        MakefileCode = re.sub("%%ENV_LIBRARY[ ]*\n","-loscar\n",MakefileLine)
                    else:
                        MakefileCode = re.sub("%%ENV_LIBRARY[ ]*\n","-lsystemc$(strip $(SYSTEMC_DEBUG))\n",MakefileLine)
                    GenMakefileFile.write(MakefileCode)
                elif (Notation.match(MakefileLine)):
                    for Info in self.mInfoGen:
                        GenMakefileFile.write(Info.GenMakefileCode(MakefileLine))
                else:
                    if (self.mEnvMode == "astc" and re.search ("LIBDIRS =", MakefileLine) != None):
                        MakefileLine = re.sub("LIBDIRS =", "LIBDIRS = -L$(OSCAR_HOME)/lib ", MakefileLine)
                    GenMakefileFile.write(MakefileLine)

            GenMakefileFile.close ()
            if (not self.mErrorFlag):
                shutil.copy  (TempFile, MakefileFile)
            os.remove(TempFile)

        return ""

    def GenHandleCommandCode(self):
        # Generate top_main.cpp file
        HandleCommandFile = self.mOutputPath + "handleCommand"
        TempFile          = self.mOutputPath + "top_gen_temp.tmp"
        write_flag = self.CheckAllowWrite("handleCommand")

        if (write_flag): # # If handleCommand is ALLOWED to [OVER]WRITE
            # Open skeleton and temporary file
            GenHandleCommandFile = self.OpenFile(TempFile, "w")

            if (GenHandleCommandFile == None):
                return
            #-----------------------------------------
            BusInfoString = ""            
            GenHandleCommandFile.write(self.mEnvInfoGen.GenHandleCommandCode())            
            for BusInfoGen in self.mBusInfoGen:
                HandleCommandCode = ""
                HandleCommandCode += BusInfoGen.mIniGen.GenHandleCommandCode()
                HandleCommandCode += BusInfoGen.mTgtGen.GenHandleCommandCode()
                if not (HandleCommandCode == ""):
                    BusInfoString += HandleCommandCode + "\n"

            GenHandleCommandFile.write(BusInfoString)
            UniqueID = 0
            for BusInfoGen in self.mBusInfoGen:
                for Module in BusInfoGen.mIniGen.mIniTgtMap:
                    if not (Module.mIsBusModel):
                        GenHandleCommandFile.write("reslx."+ Module.mInstance + "\t\tini\t\tset_param\tm_src_id=" + str(UniqueID) +"\n")
                        UniqueID += 1
            GenHandleCommandFile.write("\n")
            #-----------------------------------------
            GenHandleCommandFile.write(self.mClockParamGen.GenHandleCommandCode())

            for Info in self.mBusInfoGen:
                Info.mIniGen.mEnvInfoRef = self.mEnvInfoGen
                GenHandleCommandFile.write(Info.GenHandleCommandCode())

            GenHandleCommandFile.write(self.mHandleCmdGen.GenHandleCommandCode())

            GenHandleCommandFile.write("source handleCommand_user")     #Added by Loi Huynh
            GenHandleCommandFile.close ()
            if (not self.mErrorFlag):
                shutil.copy  (TempFile, HandleCommandFile)
            os.remove(TempFile)

        return ""

    def PrintDebugMsg(self, filename, line_number, msg_level, dbg_msg):
        if (filename == self.mScriptName):
            print ("[" + self.mScriptName + "] "  + msg_level + ": "  + dbg_msg)
        else:
            print ("[" + self.mScriptName + "] [" + filename  + " - " + "line %(line)d" % {"line":line_number+1} + "] "+ msg_level + ": " + dbg_msg)

        if (msg_level == DbgLevel[2]):
            self.mErrorFlag = True
        
    def OpenFile (self, Filename, Option):
        try:
            FilePointer = open(Filename, Option)
            return FilePointer
        except IOError:
            self.PrintDebugMsg(self.mScriptName,0,DbgLevel[2],"Cannot open " + Filename + " file.")
            return None

    # A function to get user's input key, then decide whether write ouput file or not
    def CheckAllowWrite (self, Filename):
        flag = False
        if (os.path.isfile(self.mOutputPath + Filename)) :     # Check existing file
            confirm_msg = ("Do you want to overwrite " + Filename + " ?\n(y or n)")
            overwrite = code.InteractiveConsole.raw_input(self, confirm_msg)
            while (overwrite not in ["Y","y","N","n"]): # Input key is invalid
                overwrite = code.InteractiveConsole.raw_input(self, confirm_msg)
            if ((overwrite == "Y") or (overwrite == "y")):
                flag = True
        else :
            flag = True
        return flag
# }}} 

# vim600: set foldmethod=marker :
