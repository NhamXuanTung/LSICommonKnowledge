// $Id: arbiter_creator.h v2011_05_12 $

#ifndef __arbiter_creator_h
#define __arbiter_creator_h

#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <map>
#include <assert.h>

#include "arbiter.h"

class arbiter_creator 
{
 private:
  std::map<std::string, arbiter_base *> m_tmap;  // Temporal variable map
  unsigned int m_tmpnum;
  unsigned int m_number_leaf;
  unsigned int *m_leaf_array;

  bus_base* m_bus_base_ptr;

 public:
  arbiter_creator(bus_base* bus_base_ptr = NULL)
  {
    // constructor
    m_bus_base_ptr = bus_base_ptr;
  }

  arbiter_base * parse_exp(std::string exp, unsigned int num_leaf)
  {
    try {
      arbiter_base * arb_top;
      arb_top = parse_exp_main(exp, num_leaf);
      return arb_top;
    }
    catch (const char* str) {
      printf("%s\n", str);
      return NULL;
    }
  }
  
  arbiter_base * parse_exp_main(std::string exp, unsigned int num_leaf)
  {
    m_tmap.clear();
    m_tmpnum = 0;

    arbiter_base * arb_top = NULL;
    int spos = 0;
    m_number_leaf = num_leaf;
    
    m_leaf_array = new unsigned int [m_number_leaf];
    for (unsigned int i=0; i<m_number_leaf; i++) {
      m_leaf_array[i] = 0;
    }
    
    while( true ) {
      unsigned int pos1 = exp.find("(", spos);
      if(pos1 != std::string::npos) {
        unsigned int pos2 = exp.find_first_of("()", pos1+1);
        if(pos2 != std::string::npos) {
          if(exp[pos2] == '(') {
            spos = pos2;
          }
          else if(exp[pos2] == ')') {
            // replace "(exp)" with temporal variable
            arbiter_base * sub_node = parse_lru_term(exp.substr(pos1+1, pos2-pos1-1));
            std::string tmp_name = get_tmp_name(sub_node);
            exp.replace(pos1, pos2-pos1+1, tmp_name);
            spos = 0;
          }
        }
        else {
          // error
          delete [] m_leaf_array;
          return NULL;
        }
      }
      else {
        arb_top = parse_lru_term(exp);
        break;
      }
    }
    
    bool arb_top_error = false;
    
    for (unsigned int i=0; i<m_number_leaf; i++) {
      if (m_leaf_array[i] == 0) {
        printf("[arbiter_creater] The leaf %d is lack in the member for arbitration!\n", i);
        arb_top_error = true;
      }
    }
    
    if (arb_top_error != false) {
      delete [] m_leaf_array;
      throw "[arbiter_creater] Error! the leaf is lack in the member of arbitration!\n";
      //      return NULL;
    }
    
    delete [] m_leaf_array;
    
    return arb_top;
  }

private:
  arbiter_base * parse_lru_term(std::string exp)
  {
    if(exp.find("-") == std::string::npos) {
      // single fix term
      return parse_fix_term(exp);
    }

    arbiter_lru * arb_lru = new arbiter_lru();

    bool flag = true;

    while( flag ) {
      std::string term;
      flag = get_term(exp, "-", term);

      arb_lru->add_child( parse_fix_term(term) );
    }

    return (arbiter_base *)arb_lru;
  }

  arbiter_base * parse_fix_term(std::string exp)
  {
    if(exp.find("/") == std::string::npos) {
      // single leaf node
      return get_sub_node(exp);
    }

    arbiter_fix * arb_fix = new arbiter_fix();

    bool flag = true;

    while( flag ) {
      std::string term;
      flag = get_term(exp, "/", term);

      arb_fix->add_child( get_sub_node(term) );
    }

    return (arbiter_base *)arb_fix;
  }

  bool get_term(std::string & exp, std::string delm, std::string & term)
  {
    bool flag = true;
    unsigned int pos = exp.find(delm);
    if(pos != std::string::npos) {
      term = exp.substr(0, pos);
      flag = true;
    }
    else {
      term = exp;
      flag = false;
    }
    exp = exp.substr(pos+1);
    
    return flag;
  }

  arbiter_base * get_sub_node(std::string term)
  {
    if(m_tmap.find(term) != m_tmap.end()) {
      // term is temporal variable
      return m_tmap[term];
    }
    
    // create new leaf node
    unsigned int iterm = 0;
    std::istringstream sin(term);
    sin >> iterm;
    
    // check leaves
    
    arbiter_leaf * arb_leaf;
    
    if (iterm >= m_number_leaf) {
      printf("[arbiter_creater] Error! leaf number %d is beyond the numbers for arbitration(%d)!\n", iterm, m_number_leaf);
      throw "[arbiter_creater] arbiter_creater ignore this tree!\n";
      //      return false;
    }      
    
    if (iterm < m_number_leaf) {
      if (m_leaf_array[iterm] == 0) {
        m_leaf_array[iterm] = 1;
        arb_leaf = new arbiter_leaf(iterm);
        if(m_bus_base_ptr != NULL) {
          arb_leaf->set_bus_base_ptr(m_bus_base_ptr);
        }
      } else {
        printf("[arbiter_creator] Error! leaf number %d for arbitration is duplex\n", iterm);
        throw "[arbiter_creator] arbiter_creater ignore this tree!\n";
        //        return false;
      }
    }
    return (arbiter_base *)arb_leaf;
  }
  
  std::string get_tmp_name(arbiter_base * sub_node)
  {
    // create temporal variable name
    std::ostringstream sout;
    sout << "X" << m_tmpnum;
    m_tmpnum++;

    std::string name = sout.str();
    
    if (sub_node == NULL) assert(sub_node == NULL);
    
    m_tmap[name] = sub_node;

    return name;
  }

};

#endif
