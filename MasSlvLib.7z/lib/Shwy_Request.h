//$Id: Shwy_Request.h v2011_06_08 $

#ifndef __SHWY_REQUEST_H__
#define __SHWY_REQUEST_H__

#include "arbiter.h"
#include "arbiter_creator.h"
#include "arbiter_dynamic.h"

#include "Shwy_type.h"
#include "tlm_if.h"
#include <map>
#include <climits>

template <int NR_OF_INITIATORS, int NR_OF_TARGETS, int BUS_WIDTH=32>
class Shwy;

template <int NR_OF_INITIATORS, int NR_OF_TARGETS, int BUS_WIDTH=32>
class Shwy_Request : public sc_core::sc_module
{
public:
  typedef tlm::tlm_generic_payload               transaction_type;
  typedef tlm::tlm_phase                         phase_type;
  typedef tlm::tlm_sync_enum                     sync_enum_type;
  typedef tlm_utils::simple_target_socket_tagged<Shwy<NR_OF_INITIATORS, NR_OF_TARGETS, BUS_WIDTH> ,BUS_WIDTH>    target_socket_type;
  typedef tlm_utils::simple_initiator_socket_tagged<Shwy<NR_OF_INITIATORS, NR_OF_TARGETS, BUS_WIDTH> ,BUS_WIDTH> initiator_socket_type;
  
private:
  Shwy<NR_OF_INITIATORS,NR_OF_TARGETS,BUS_WIDTH>* top_ptr;
  transaction_type* req_gp_ptr[NR_OF_INITIATORS];
  arbiter_base* req_arb_top;
  bool arb_dynamic;
  int max_pri;
  
  int debug_print_level;
  bool m_lck;
  
  sc_time m_arb_period;
  bool m_arb_period_init;
  sc_time m_arb_clk;
  unsigned int m_outstanding;

  std::map<std::string, sc_time> m_worst_period;
  std::map<std::string, sc_time> m_prev_time;
  std::map<std::string, unsigned int> m_winner_count;

public:
  SC_HAS_PROCESS(Shwy_Request);
  Shwy_Request(sc_core::sc_module_name name, Shwy<NR_OF_INITIATORS,NR_OF_TARGETS,BUS_WIDTH>* shwy_ptr) :
  sc_core::sc_module(name),
  req_arb_top(),
  mRequestPEQ("requestPEQ")
  {
    // constructor
    top_ptr = shwy_ptr;
    arb_dynamic = false;
    max_pri = 15;

    mWaitingTrans = NULL;
    
    for (unsigned int i = 0; i < NR_OF_INITIATORS; i++) {
      req_gp_ptr[i] = 0;
    }
    // initialize arb_top pointer
    req_arb_top = 0;
    
    // initialize dprint_level
    debug_print_level = top_ptr->debug_print_level;
    m_lck = false;
    
    m_arb_period = SC_ZERO_TIME;
    m_arb_period_init = true;
    m_arb_clk = SC_ZERO_TIME;
    m_outstanding = INT_MAX;

    SC_THREAD(RequestThread);
  }

  ~Shwy_Request() {
    delete req_arb_top;
  }

  // make req_arb_top for resource 
  void set_req_arb (std::string arb_exp)
  {
    // add base class pointer as constructor args.
    arbiter_creator arb_creator(top_ptr);
    req_arb_top = arb_creator.parse_exp(arb_exp, NR_OF_INITIATORS);
    req_arb_top->set_debug_level(debug_print_level);

    if (req_arb_top == NULL) {
      printf("[%s] Fatal Error! arbiter top pointer(set_req_arb) is NULL!\n",this->get_name());
      if (req_arb_top == NULL) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" );
    }
  }

  void set_req_arb_by_number (int number_of_ips)
  {
    // add base class pointer as constructor args.
    arbiter_fix* temp_req_arb_top = new arbiter_fix();
    
    if (temp_req_arb_top == NULL) {
      printf("[%s] Memory allocation error\n",this->get_name());
      SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" );
    }
    
    for (int i=0; i<number_of_ips; i++) {
      arbiter_leaf* arb_i = new arbiter_leaf(i);
      arb_i->set_bus_base_ptr(top_ptr);
      temp_req_arb_top->add_child(arb_i);
    }

    req_arb_top = (arbiter_base *)temp_req_arb_top;
    req_arb_top->set_debug_level(debug_print_level);
  }
  
  void set_req_arb_dynamic(Shwy_Priority * Shwy_Pri, ARB_PRI_MODE mode)
  {
    arb_dynamic = true;

    // instantiate
    arbiter_dynamic * arb_dynamic = new arbiter_dynamic(mode);
    
    if (arb_dynamic == NULL) {
      printf("[%s] Memory allocation error\n",this->get_name());
      SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" );
    }
    
    // add fix priority/interval_time/low_priority
    for (int i=0; i<NR_OF_INITIATORS; i++) {
      arbiter_dynamic_elm * elm = Shwy_Pri->get_arbiter_elm(i);
      arb_dynamic->add_element(i, elm);
    }

    req_arb_top = (arbiter_base *)arb_dynamic;
    req_arb_top->set_bus_base_ptr(top_ptr);
    req_arb_top->set_debug_level(debug_print_level);
  }

  void set_dynamic_arbiter(Shwy_Priority *shwy_pri)
  {
    dynamic_arbiter_subtype arb_subtype = shwy_pri->get_dynamic_arbiter_subtype();
    if (arb_subtype == DEFAULT_ARB) {
      printf("ERROR :  Shwy_Request::set_dynamic_arbiter() : dynamic arbitration type 'DEFAULT_ARB' is unsupported.\n");
      return;
    }
    else if (arb_subtype == FAIR_ARB) {
      req_arb_top = new arbiter_fair(shwy_pri->get_dynamic_arbiter_mode());
    }
    else if (arb_subtype == PROB_ARB) {
      req_arb_top = new arbiter_prob(shwy_pri->get_dynamic_arbiter_mode());
    }
    else {
      printf("ERROR : Shwy_Request::set_dynamic_arbiter() : dynamic arbitration type is invalid.\n");
      return;
    }
    for (int i = 0; i < NR_OF_INITIATORS; i++) {
      req_arb_top->add_element(i, shwy_pri->get_dynamic_arbiter_element(i));
    }
    req_arb_top->set_bus_base_ptr(top_ptr);
    req_arb_top->set_debug_level(debug_print_level);
    arb_dynamic = true;
  }

  void set_max_pri(int pri)
  {
    max_pri = pri;
  }

  void notify_RequestThread(transaction_type& trans, sc_core::sc_time& t)
  {
    mRequestPEQ.notify(trans,t);
  }
  
  void notify_EndRequestEvent(transaction_type& trans, sc_core::sc_time& t)
  {
    if( &trans == mWaitingTrans ) {
      mEndRequestEvent.notify(t);
    }
  }

  void set_dprint_level(int dprint_level) {
    debug_print_level = dprint_level;

    if(req_arb_top != NULL) req_arb_top->set_debug_level(dprint_level);
  }

  void set_request_arbiter_period(sc_time arb_period, bool arb_period_init)
  {
    m_arb_period = arb_period;
    m_arb_period_init = arb_period_init;
  }

  void set_request_arbiter_clk(sc_time arb_clk)
  {
    m_arb_clk = arb_clk;
  }

  void set_request_arbiter_outstanding(unsigned int outstanding)
  {
    m_outstanding = outstanding;
  }

  void reset_dynamic_arbiter_status()
  {
    if (req_arb_top != NULL) {
      req_arb_top->all_reset();
    }
  }

  /*  DUMP PROFILE INFORMATION  */
  bool DumpProfile(FILE *p_file = stdout, sc_time_unit timescale = SC_NS) {
    if(req_arb_top != NULL) {
      req_arb_top->DumpProfile(p_file, timescale);
    }
    if (debug_print_level >= 2) {
      printf("The Worst Latency and The Number of Wins for Request Arbitration\n");
      for (std::map<std::string, sc_time>::iterator it = m_worst_period.begin(); it != m_worst_period.end(); it++) {
        if (m_arb_clk == SC_ZERO_TIME) {
          printf("  %-8s = %12s %8d times\n", it->first.c_str(), it->second.to_string().c_str(), m_winner_count[it->first.c_str()]);
        }
        else {
          printf("  %-8s = %8d cyc %8d times\n", it->first.c_str(), (unsigned int) (it->second / m_arb_clk), m_winner_count[it->first.c_str()]);
        }
      }
      printf("\n");
    }
    return true;
  }

private:
  void RequestThread(void)
  {
    int iniId;

    bool wait_arb_period = m_arb_period_init;

    while (true) {
      wait(mRequestPEQ.get_event() | top_ptr->gnt_event);

      if(req_arb_top == NULL) continue;  // Simulation not started yet
      
      while(1) {
        if (wait_arb_period) {
          while (top_ptr->m_beg_resp_wait >= m_outstanding) {
            wait(top_ptr->m_beg_resp_event);
          }
          if (m_arb_period != SC_ZERO_TIME) {
            wait(m_arb_period);
          }
        }
        else {
          wait_arb_period = true;
        }

        transaction_type* trans;
        while ((trans = mRequestPEQ.get_next_transaction())!=0) {

          vpcl::bus_extension *p_bus_ext = get_bus_extension(trans);

          iniId = top_ptr->getIniIdFromPendingTransactions(*trans);
          
          // register initiater to arbiter
          if (req_arb_top != NULL) {
            if (arb_dynamic != true || p_bus_ext == NULL || p_bus_ext->pri < 0) {
              req_arb_top->request(iniId);
            } else {
              if (p_bus_ext->pri > max_pri) {
                printf("[%s] Error: In [RequestThread], Invalid priority \"%d\"\n", this->get_name(), p_bus_ext->pri);
              }
              req_arb_top->request(iniId, p_bus_ext->pri);
            }
          } else {
            printf("[%s] Fatal Error: In [RequestThread], Request Arbiter Tree is fail to build(Arbiter Top is NULL pointer)!\n", this->get_name());
            sc_stop();
            return;
          }

          if(arb_dynamic == true && top_ptr->m_bank_bit_num > 0) {
            // bank conflict consideration mode
            unsigned int bank = get_bank(trans);
            unsigned int is_write = trans->is_write();
            req_arb_top->set_extra_info(iniId, bank, 0);
            req_arb_top->set_extra_info(iniId, is_write, 1);
            if(top_ptr->m_wtop_opt_level >= 2) {
              req_arb_top->set_extra_info(iniId, bank, 2);

              unsigned int data_len = trans->get_data_length();
              if(data_len > 128) {
                req_arb_top->set_extra_info_size(iniId, 2);
              }
            }
          }

          // store pointer of generic_payload to req_array
          req_gp_ptr[iniId] = trans;
        }
        // When there is no candidate for mediation,
        // escapes from while (1) loop and waits for the next request.
        
        wait( sc_time(0, SC_NS) );
        if((iniId = (req_arb_top->get_winner())) == -1) {
          bool is_req_pending = false;
          for (int i = 0; i < NR_OF_INITIATORS; i++) {
            if (req_gp_ptr[i] != NULL) {
              is_req_pending = true;
              break;
            }
          }
          if (is_req_pending) {
            wait_arb_period = false;
            continue;
          }
          else {
            break;
          }
        } 

        top_ptr->m_beg_resp_wait++;

        if (debug_print_level >= 2) {
          std::string winner_name = get_src_name(req_gp_ptr[iniId]);
          if (winner_name != "UNKNOWN") {
            if (m_worst_period.count(winner_name) == 0) {
              m_worst_period.insert(std::map<std::string, sc_time>::value_type(winner_name, SC_ZERO_TIME));
              m_prev_time.insert(std::map<std::string, sc_time>::value_type(winner_name, sc_time_stamp()));
              m_winner_count.insert(std::map<std::string, unsigned int>::value_type(winner_name, 1));
            }
            else {
              if (m_worst_period[winner_name] < sc_time_stamp() - m_prev_time[winner_name]) {
                m_worst_period[winner_name] = sc_time_stamp() - m_prev_time[winner_name];
              }
              m_prev_time[winner_name] = sc_time_stamp();
              m_winner_count[winner_name]++;
            }
          }

          if (m_arb_clk == SC_ZERO_TIME) {
            printf("%12s :  [%-16s]  ARB_RESULT : %-8s { ", sc_time_stamp().to_string().c_str(), top_ptr->basename(), get_src_name(req_gp_ptr[iniId]).c_str());
          }
          else {
            printf("%8d cyc :  [%-16s]  ARB_RESULT : %-8s { ", (unsigned int) ((sc_time_stamp() - m_arb_period) / m_arb_clk), top_ptr->basename(), get_src_name(req_gp_ptr[iniId]).c_str());
          }
          for (int i = 0; i < NR_OF_INITIATORS; i++) {
            if (req_gp_ptr[i] == NULL) {
              printf("****     ");
            }
            else {
              printf("%-8s ", get_src_name(req_gp_ptr[i]).c_str());
            }
          }
          printf("}\n");

          if (m_arb_clk == SC_ZERO_TIME) {
            printf("%d\t%s\tARB_RESULT_TAB\t%s\t", (unsigned int) sc_time_stamp().value(), top_ptr->basename(), get_src_name(req_gp_ptr[iniId]).c_str());
          }
          else {
            printf("%d\t%s\tARB_RESULT_TAB\t%s\t", (unsigned int) ((sc_time_stamp() - m_arb_period) / m_arb_clk), top_ptr->basename(), get_src_name(req_gp_ptr[iniId]).c_str());
          }
          for (int i = 0; i < NR_OF_INITIATORS; i++) {
            if (req_gp_ptr[i] == NULL) {
              printf("****\t");
            }
            else {
              printf("%s\t", get_src_name(req_gp_ptr[i]).c_str());
            }
          }
          printf("\n");
        }

        trans = req_gp_ptr[iniId];

        if(debug_print_level > 0)  print_log(trans, iniId);

        vpcl::bus_extension *bus_ext = get_bus_extension(trans);

        // winner's lck check
        if (bus_ext != NULL) {
          if (bus_ext->lck) {
            req_arb_top->notify_lck(iniId);
          } else {
            req_arb_top->notify_unlck();
          }
        }

        if(top_ptr->m_level_propagate) {
          set_extension_pri( trans, req_arb_top->get_pri_level() );
        }

        // delete winner from req_array
        req_gp_ptr[iniId] = 0;
        
        // address decode
        int portId = top_ptr->getTgtIdFromPendingTransactions(*trans);
        
        initiator_socket_type* decodeSocket = &(top_ptr->initiator_socket)[portId];
          
        phase_type phase = tlm::BEGIN_REQ;
        sc_core::sc_time t = sc_core::SC_ZERO_TIME;
          
        // time when request from SHwy to Target 
        sc_time req_begin_time = sc_time_stamp();
        top_ptr->setReqToTgtTime(*trans, req_begin_time);
          
        switch ((*decodeSocket)->nb_transport_fw(*trans, phase, t)) {
        case tlm::TLM_ACCEPTED:
        case tlm::TLM_UPDATED:
          // Transaction not yet finished
          if (phase == tlm::BEGIN_REQ) {
            // Request phase not yet finished
            mWaitingTrans = trans;
            wait(mEndRequestEvent);
            wait(SC_ZERO_TIME);
              
          } else if (phase == tlm::END_REQ) {
            // Request phase finished, but response phase not yet started
            wait(t);
              
          } else if (phase == tlm::BEGIN_RESP) {
            // for Resource
            int ini_grp_id1 = 0;
            ini_grp_id1 = top_ptr->Shwy_GroupId0.getInitiatorGroupId(top_ptr->getIniIdFromPendingTransactions(*trans));
            top_ptr->Response_Thread_List[ini_grp_id1]->notify_ResponseThread(*trans, t);
              
            // Not needed to send END_REQ to initiator
            wait(SC_ZERO_TIME);
            continue;
              
          } else { // END_RESP
            if (!false) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" );
          }
            
          // only send END_REQ to initiator if BEGIN_RESP was not already send
          if (top_ptr->getBeginRespFlag(*trans) != 1) {
            phase = tlm::END_REQ;
            t = sc_core::SC_ZERO_TIME;
            (top_ptr->target_socket[top_ptr->getIniIdFromPendingTransactions(*trans)])->nb_transport_bw(*trans, phase, t);
          }
          break;
            
        case tlm::TLM_COMPLETED:
          // Transaction finished
          {
            int ini_grp_id2 = 0;
            ini_grp_id2 = top_ptr->Shwy_GroupId0.getInitiatorGroupId(top_ptr->getIniIdFromPendingTransactions(*trans));
            top_ptr->Response_Thread_List[ini_grp_id2]->notify_ResponseThread(*trans, t);
          }
          // reset to destination port (we must not send END_RESP to target)
          //          it->second.to = -1;
          top_ptr->setTgtIdToPendingTransactions(*trans, -1);
            
          wait(t);
          break;
            
        default:
          if (!false) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" );
        };
      }
    }
  }
  
private:
  tlm_utils::peq_with_get<transaction_type> mRequestPEQ;
  sc_core::sc_event mBeginRequestEvent;
  sc_core::sc_event mEndRequestEvent;
  transaction_type * mWaitingTrans;
  
  // get instance name.
  const char *get_name()
  {
    return this->name();
  }

  std::string get_src_name(tlm::tlm_generic_payload *trans)
  {
    if (trans != NULL) {
      vpcl::tlm_if_extension *p_ext = NULL;
      trans->get_extension(p_ext);
      if (p_ext != NULL) {
        return p_ext->ini_if_param.name;
      }
    }
    return "UNKNOWN";
  }

  unsigned int get_bank(transaction_type* trans)
  {
    unsigned int addr = trans->get_address(); 
    unsigned int isize = sizeof(unsigned int)*8;
    unsigned int bit_num = top_ptr->m_bank_bit_num;
    unsigned int bit_loc = top_ptr->m_bank_bit_loc;
    unsigned int bank = addr << (isize - bit_loc - bit_num) >> (isize - bit_num);

    return bank;
  }

  vpcl::bus_extension * get_bus_extension(transaction_type * trans)
  {
    vpcl::tlm_if_extension *p_ext;
    trans->get_extension(p_ext);

    if(p_ext != NULL) {
      return p_ext->p_bus_ext;
    }
    return NULL;
  }

  void set_extension_pri(transaction_type * trans, int pri)
  {
    vpcl::tlm_if_extension *p_ext;
    trans->get_extension(p_ext);

    if(p_ext == NULL) {
      p_ext = new vpcl::tlm_if_extension;
      trans->set_extension(p_ext);
    }
    if(p_ext->p_bus_ext == NULL) {
      p_ext->p_bus_ext = new vpcl::bus_extension;
    }

    p_ext->p_bus_ext->pri = pri;
  }

  // debug print
  void print_log(transaction_type* trans, int id)
  {
    vpcl::bus_extension *bus_ext = get_bus_extension(trans);

    // winner's lck check
    if (bus_ext != NULL) {
      if (bus_ext->lck) {
        if(m_lck == false) {
          cout << "Info [" << sc_time_stamp() << "] (" << get_name() << ") Request Resource is locked by initiator " << id << endl;
        }
        m_lck = true;
      } else {
        if(m_lck == true) {
          cout << "Info [" << sc_time_stamp() << "] (" << get_name() << ") Request Resource is unlocked by initiator " << id << endl;
        }
        m_lck = false;
      }
    }
  }
};

#endif
