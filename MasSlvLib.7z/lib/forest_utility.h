/****************************************************************************
*
*                        RENESAS confidential
*
*   (C) Copyright RENESAS Technology, 2002-2003 All Rights Reserved.
*
***************************************************************************/
/****************************************************************************
* FOREST
* File name : forest_utility.h
****************************************************************************/

#include <stdio.h>

/* prototype decalration for CEDAR */
extern "C" {
void DumpPerformanceInfo_forest (FILE *fp); // Performance Statistics
void ClearPerformanceInfo_forest (void); // Performance Statistics
}

extern unsigned long debug_mem;
unsigned long ForestGetSystemTime(void);

void ForestStop(void);
void ForestSetResetHigh (); // set reset signal High
void ForestSetResetLow ();  // set reset signal Low
int mytoupper (int c);
char* ForestGetTraceFileName (int argc, char* argv[]);
void ForestCpuInit (void);
void ForestOptionAnalyze (int argc, char* argv[]);
void ForestDefaultMemSet (void);
void ForestHardReset (void);
void ForestManualReset (void);
void ForestHardResetPeripherals (void);
void ForestManualResetPeripherals (void);
void ForestCciRead (char* fname);
void ForestOutputFileClose (void);
unsigned int GetSclkPeriod ();
unsigned int GetSclkPeriod (int shwy_id);
unsigned long Get_clock_cycle_count(int shwy_id);

void ForestExecutePeripherals(void);
void ForestSetCpuRate(long cpuid, unsigned long rate);
void ForestPrintCpuState(void);

void ForestRunExecute (void);
void ForestStepExecute (long cpuid, long step);
void ForestNonScRunExecute (void);
void ForestNonScStepExecute (long cpuid, long step);
void ForestChangeTimedMode(ForestTimedMode mode);
ForestTimedMode ForestGetTimedMode(void);
ForestTimedMode ForestGetTimedModeRequesting(void);
void SetSigIntFlag (int sig);
void ForestSetMemInitValue (unsigned long mem_init_value);
unsigned long ForestGetMemInitValue (void);
void ForestSetInvalidAddress (unsigned long invalid_address);
unsigned long ForestGetMemInvalidAddress (void);
void ForestMemResourceAdd (unsigned long start_addr,
                           unsigned long end_addr,
                           MemRestrictType restrict_type,
                           unsigned long read_latency,
                           MemMappedArea area_type);
void ForestMemResourceDisplay (void);
void ForestMemoryDisplay (unsigned long start_addr, unsigned long end_addr,
                          MemDisplaySize md_size, FILE *p_file, long legacy_mode);
void ForestSetScriptFile (FILE *fp);
FILE *ForestGetScriptFile (void);
void ForestCopyrightPrint (FILE *fp, char *p_cedar_str, char *p_cci_str,
                           char *p_rat_str, char *option_str, long cpuid);
void ForestQuit (void);
unsigned long CutDataSize(unsigned long data, MemAccessDataType size);

void ForestRunCsExecute (void);
void ForestStepCsExecute (long cpuid, long step);
void ForestCycleOverflow(void);

void ForestBreakSystemTimeSet(unsigned long break_time);
void ForestBreakSystemTimeEnable(unsigned long enable);
void ForestSyncCpu(void);

void DmyScifTerminalSet (void);
void DmyScifTerminalReset (void);
void ForestPreOptionAnalyze (int argc, char *argv[]);
void ForestPrintTime(void);

void ForestDumpSave(char *str);
void ForestDumpLoad(char *str);

void ForestSetupSignal(void);
void ForestRestoreDefaultSignal(void);

#ifndef MSVC
void ForestConnectGDB (long gdb_port);
void SetGdbNum (long num);
long GetGdbNum (void);
void SetGdbPort (long port);
long GetGdbPort (void);
#endif // ! MSVC
