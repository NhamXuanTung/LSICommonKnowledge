# ---------------------------------------------------------------------
# $Id: top_gen.py v2017_05_08 $
#
# Copyright(c) 2013-2017 Renesas Electronics Corporation
# Copyright(c) 2013-2017 Renesas Design Vietnam Co., Ltd.
# RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
# This program must be used solely for the purpose for which
# it was furnished by Renesas Electronics Corporation. No part of this
# program may be reproduced or disclosed to others, in any
# form, without the prior written permission of Renesas Electronics
# Corporation.
# ---------------------------------------------------------------------

import top_gen_class
import sys
import os
from optparse import OptionParser

minimum_version = (3,1,2) # minimum Python version: 3.1.2

def main(): # Main function of RegIF Generator
    # Check version of Python
    current_version = sys.version_info[0:3]

    if (current_version >= minimum_version): 

        parser = OptionParser(usage="%prog [options]", version="%prog 2.0")

        # Add option's information
        parser.add_option("-i", "--inputpath" , "--input" , dest="inputpath" , action="store", help="input path for skeleton and module info files.", metavar="PATH")
        parser.add_option("-o", "--outputpath", "--output", dest="outputpath", action="store", help="path used to store the output files."          , metavar="PATH")
        parser.add_option("-s", "--sci"                   , dest="scifile"   , action="store", help="filename of SCI file."                         , metavar="FILE")
        parser.add_option("-m", "--modelinfo"             , dest="modelinfo" , action="append", help="path used to store additional model info file.", metavar="FILE")
        parser.add_option("-c", "--compile"               , dest="compile"   , action="append", help="compile option."                               , metavar="STRING")
        parser.add_option("-e", "--env"               , dest="env"   , action="store", help="environment: osci, astc. Default is none."                               , metavar="STRING")

        (options, args) = parser.parse_args()

        if (len(args) > 0):
            print ("[" + sys.argv[0] + "] [" + top_gen_class.DbgLevel[2] + "] : Too many arguments.\nTry \'" + sys.argv[0] + " -h\' for more information.")
        else:
            try:
                MainGenerator = top_gen_class.CMainGenerator()

                if (options.inputpath  != None):
                    MainGenerator.SetInputPath(options.inputpath + "/")
    
                if (options.outputpath != None):
                    MainGenerator.mOutputPath = options.outputpath + "/"

                if (options.scifile    != None):
                    MainGenerator.mSciFile    = options.scifile
    
                if (options.modelinfo  != None):
                    MainGenerator.SetModelInfoFilePath(options.modelinfo)
    
                if (options.compile    != None):
                    MainGenerator.mCompileOption = options.compile
    
                if (options.env    != None):
                    MainGenerator.mEnvMode = options.env

                FunctionDic = {}
    
                FunctionDic[MainGenerator.ParseSCIFile]         ="[" + top_gen_class.DbgLevel[0] + "] : Parsing " + MainGenerator.mSciFile + "..."
                FunctionDic[MainGenerator.GenTopCode]           ="[" + top_gen_class.DbgLevel[0] + "] : Generating top.h..." 
                FunctionDic[MainGenerator.GenTopMainCode]       ="[" + top_gen_class.DbgLevel[0] + "] : Generating top_main.cpp..." 
                FunctionDic[MainGenerator.GenMakefileCode]      ="[" + top_gen_class.DbgLevel[0] + "] : Generating Makefile..." 
                FunctionDic[MainGenerator.GenHandleCommandCode] ="[" + top_gen_class.DbgLevel[0] + "] : Generating handleCommand..." 
    
                FunctionList = [MainGenerator.ParseSCIFile, MainGenerator.GenTopCode, MainGenerator.GenTopMainCode, MainGenerator.GenMakefileCode, MainGenerator.GenHandleCommandCode]
    
                for Function in FunctionList:
                    print(FunctionDic[Function])
                    Function()
    
                    if (not MainGenerator.mErrorFlag):
                        print("Done!"  )
                    else:
                        print("Failed!")
            except KeyError:
                print("[" + top_gen_class.DbgLevel[2] + "] Progress has error during generating.")
    else:
        print("[" + top_gen_class.DbgLevel[0] + "] : Current Python version: " + sys.version.split("\n")[0]       )
        print("[" + top_gen_class.DbgLevel[2] + "] : Python 3.1.2 or higher is recommended for running this script.")


main()

