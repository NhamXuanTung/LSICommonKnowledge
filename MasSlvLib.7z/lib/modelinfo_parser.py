# ----------------------------------------------------------------------
#   $Id: modelinfo_parser.py V20110427_forRESLX_SystemTest $
# ----------------------------------------------------------------------
#   (C) Copyright 2010   RVC (Renesas Design Vietnam Co., Ltd.)
#   All rights reserved. RVC Confidential Proprietary
#   (C) Copyright 2010   RENESAS Electronics Corp.  All rights reserved.
# ----------------------------------------------------------------------

import re
import os

DbgLevel    = ["INFO", "WARNING", "ERROR"                ]
emType      = ["in"  ,"out"    ,"inout","signal","buffer"]
emClassType = ["bool","sc_uint","sc_biguint"             ]

# Class used for storing the information in the module info file
class CModelInfo:
# {{{
    def __init__(self):
        self.mHeaderFile         = []             # Store the list of header files of Model 
        self.mImplementationFile = []             # Store the list of implementation files of Model
        self.mTemplate           = {}             # Store the template description of Model
        self.mPort               = {}             # Store the list of ports of Model
        self.mListOrderPort      = []             # Store list port ordered in model info file
        #-----------------------------------------------------------
        self.mModuleName         = ""             # Store the module name
        self.mIncludeDir         = []             # Store the include directory path
        self.mLibraryDir         = []             # Store the library directory path
        self.mLinkedLibrary      = []             # Store the linked library
        self.mHWBreak            = False          # Store the flag HW breaking processing
        #-----------------------------------------------------------
# }}} 

class CPort:
# {{{
    def __init__(self):
        self.mPortName   = ""                     # Store the name of port
        self.mBitWidth   = ""                     # Store the bitwidth of port
        self.mPortType   = ""                     # Store the type of port
        self.mClassType  = ""                     # Store the class type of port 
        self.mFixedValue = ""                     # Store the fixed value of non-connection port
        self.mSupported  = True                   # Store supported/unsupported port info
# }}} 

def GetModelInfoContent (ModelInfoFile, ModelInfoLine, MacroRef, ImplementationFileNameList, ImplementationFilePathList):
    TemplateIndex = 0     # Index to count the position of template in class declaration
    ModuleInfo = CModelInfo()
    ScriptName = os.path.basename(__file__)
    if (len(ModelInfoLine) == 0):
        print("[" + ScriptName + "] [" + ModelInfoFile + "] ERROR: Model info file is empty.")
        return None

    ListOfKeys = ["%MODULE", "%HEADER_FILES", "%IMPLEMENTATION_FILES", "%TEMPLATE", "%PORT", "%INCDIR", "%LIBRARY", "%LIBDIR", "%CMD_HWBRK"]

    for Line in ModelInfoLine:
        CurLineNumber = ModelInfoLine.index(Line) + 1
        Info = (Line.lstrip()).replace("\n","  ")
        Info = re.sub("#.*","",Info)
        ErrorMsg = "[" + ScriptName + "] [" + ModelInfoFile + " - line " + str(CurLineNumber) + "] "
        if (Info != ""):
            ModelInfo = Info.split()
            Keyword = ModelInfo[0]
            del ModelInfo[0]
            if (Keyword in ListOfKeys):
                LackFlag = False
                #------------------------------------------------------
                RedundantFlag = False
                if (Keyword == "%MODULE"):          # Process to get module name
                    LackFlag = (len(ModelInfo) == 0)
                    RedundantFlag = (len(ModelInfo) > 1)
                    if not LackFlag:
                        ModuleInfo.mModuleName = ModelInfo[0]
                #------------------------------------------------------
                elif (Keyword == "%HEADER_FILES"):   # Process to get header files
                    LackFlag = (len(ModelInfo) == 0)
                    if not LackFlag:
                        ModuleInfo.mHeaderFile.extend(ModelInfo)
                elif (Keyword == "%IMPLEMENTATION_FILES"):   # Process to get implementation files
                    LackFlag = (len(ModelInfo) == 0)
                    if not LackFlag:
                        #-----------------------------
                        for ImplementationFile in ModelInfo:
                            if (ImplementationFile not in ImplementationFilePathList):
                                FileName = (re.split("/",ImplementationFile))[-1]
                                if (FileName not in ImplementationFileNameList):
                                    ImplementationFileNameList.append(FileName)
                                    ImplementationFilePathList.append(ImplementationFile)
                                else:
                                    print(ErrorMsg + "ERROR: Duplicated implementation file name ("+ FileName + ").")
                                    return None
                        #-----------------------------
                        ModuleInfo.mImplementationFile.extend(ModelInfo)
                elif (Keyword == "%TEMPLATE"):   # Process to get template declaration
                    LackFlag = (len(ModelInfo) == 0)
                    if not LackFlag:
                        TemplateType = ''
                        for Template in ModelInfo:
                            if (Template == ModelInfo[-1]):  # Get template declaration
                                TemplateInfo = [TemplateType,TemplateIndex]
                                ModuleInfo.mTemplate[Template] = TemplateInfo
                                TemplateIndex += 1
                            else:
                                TemplateType += " " + Template
                elif (Keyword == "%PORT"):   # Process to get port declaration
                    PortInfo = GetPortInfo(ScriptName, ModelInfo, CurLineNumber, ModelInfoFile, ModuleInfo.mPort,ModuleInfo.mTemplate, MacroRef)
                    if (PortInfo != None):
                        ModuleInfo.mPort[PortInfo.mPortName] = PortInfo
                        ModuleInfo.mListOrderPort.append(PortInfo.mPortName)
                    else :
                        return None
                #------------------------------------------------------------------------        
                elif (Keyword == "%INCDIR"):   # Process to get included directory path
                    LackFlag = (len(ModelInfo) == 0)
                    if not LackFlag:
                        ModuleInfo.mIncludeDir.extend(ModelInfo)
                elif (Keyword == "%LIBRARY"):   # Process to get linked library option
                    LackFlag = (len(ModelInfo) == 0)
                    if not LackFlag:
                        ModuleInfo.mLinkedLibrary.extend(ModelInfo)
                elif (Keyword == "%LIBDIR"):   # Process to get linked library path
                    LackFlag = (len(ModelInfo) == 0)
                    if not LackFlag:
                        ModuleInfo.mLibraryDir.extend(ModelInfo)
                elif (Keyword == "%CMD_HWBRK"):   # Process to get command hardware break flag
                    LackFlag = False
                    RedundantFlag = (len(ModelInfo) > 0)
                    ModuleInfo.mHWBreak = True
                if (LackFlag):
                    print(ErrorMsg + "ERROR: Lack of " + Keyword + " content.")
                    return None
                if (RedundantFlag):
                    print(ErrorMsg + "ERROR: Too many arguments of " + Keyword + " content.")
                    return None

    if (len(ModuleInfo.mHeaderFile) == 0) and (len(ModuleInfo.mImplementationFile) == 0 ):
        print(ErrorMsg + "ERROR: Lack of header and implementation file name.")
        return None

    return ModuleInfo

#----------Get Port Info from %PORT keyword method ---------- 
def GetPortInfo (ScriptName, PortLineInfo, CurLineNumber, ModelInfoFile, PortRef, TemplateRef, MacroMap): 
#{{{  
    #keyword    port_name     num_of_bit  in/out  type      fix_value
    #%PORT      sys           5           in      sc_uint   -
    ErrorFlag = False
    ErrorMsg = "["+ScriptName+"] [" + ModelInfoFile + " - line " + str(CurLineNumber) + "] "
    if(len(PortLineInfo) < 4):
        print(ErrorMsg + "<ERROR>: Port line info is illegal.")
        return None
    if (len(PortLineInfo) > 5):
        print(ErrorMsg + "<ERROR>: Too many arguments in Port line content.")
        return None
    NamePattern  =  re.compile("[a-zA-Z_].*")
    SettingValue = 0
    PortInfo = CPort()
    # check the duplication port declaration
    if (PortLineInfo[0] in PortRef):  # Check duplicated port
        print(ErrorMsg + "<ERROR>: Duplicated port name (" + PortLineInfo[0] + ").")
        return None
    else:
        PortInfo.mPortName = PortLineInfo[0]
    # check the legality of signal/port name
    if (NamePattern.match(PortLineInfo[0]) == None):
        print(ErrorMsg + "<ERROR>: Invalid signal/port name (" + PortLineInfo[0] + ").")
        return None
    try:
        SettingValue = ExtractValue(PortLineInfo[1], int)
        if (SettingValue > 0):
            PortInfo.mBitWidth = SettingValue
        else:
            print(ErrorMsg + "<ERROR>: Bitwidth must be greater than 0.")
            return None
    except ValueError:
        if (re.match("[0-9]+.[0-9]+$", PortLineInfo[1]) == None):
            if (PortLineInfo[1] in TemplateRef):
                PortInfo.mBitWidth = PortLineInfo[1]
            else:
                print(ErrorMsg + "<ERROR>: Invalid template name (" + PortLineInfo[1] + ").")
                return None
        else:
            print(ErrorMsg + "<ERROR>: Bitwidth should be an integer.")
            return None
    # check the legality of signal/port direction type (in/out/inout)
    if (PortLineInfo[2] in emType): 
        PortInfo.mPortType = PortLineInfo[2]
    else:
        print(ErrorMsg + "<ERROR>: Invalid signal/port type (" + PortLineInfo[2] + ").")
        ErrorFlag = True
    # Check the legality of signal/port class type (sc_uint/sc_biguint/bool)
    if (PortLineInfo[3] in emClassType): 
        PortInfo.mClassType = PortLineInfo[3]
    else:
        print(ErrorMsg + "<ERROR>: Invalid class type of signal/port (" + PortLineInfo[3] + ").")
        ErrorFlag = True
    # Check the legality of setting bitwidth
    if (PortInfo.mClassType == "bool"):
        if (PortInfo.mBitWidth != 1):
            print(ErrorMsg + "<ERROR>: Bitwidth of bool signal/port must equal 1.")
            ErrorFlag = True
    if (len(PortLineInfo) == 4):
        if(PortInfo.mPortName.endswith("_n")):  # Process to get fixed value of port
            PortInfo.mFixedValue = 1
        else:
            PortInfo.mFixedValue = 0
    else:
        if(PortLineInfo[4] == "-"):
            PortInfo.mFixedValue = 0
        elif(PortLineInfo[4].lower() == "true" or PortLineInfo[4].lower() == "false"):
            if(PortInfo.mClassType != "bool"):
                print(ErrorMsg + "<ERROR>: Invalid setting fixed value (" + PortLineInfo[4] + ").")
                ErrorFlag = True
            else:
                PortInfo.mFixedValue = PortLineInfo[4].lower()
        else:    
            CheckResult = CheckValidValue(PortLineInfo[4], MacroMap, float, False)
            if (len(CheckResult) == 1):
                if((PortInfo.mClassType) == "bool" and (CheckResult[0] > 1)):
                    print(ErrorMsg + "<ERROR>: Invalid setting fixed value for bool type (" + PortLineInfo[4] + ").")
                    ErrorFlag = True
                else:
                    PortInfo.mFixedValue = PortLineInfo[4]
            else:
                print(ErrorMsg + "<ERROR>: Invalid setting fixed value (" + PortLineInfo[4] + ").")
                ErrorFlag = True
    if not (ErrorFlag):
        return PortInfo
    else:
        return None
#}}}    

#----------Function to check whether macro was defined or not ----------
def CheckValidValue (CheckValue, MacroMap, ClassType, CheckZero):     
#{{{
    Value = None
    try:
        Value = ExtractValue(CheckValue, ClassType)
        if ((Value < 0) or (CheckZero and Value == 0)):
            return [DbgLevel[2],"Setting value must be greater than 0."]
    except:
        if (MacroMap == None):
            return [DbgLevel[2],"Invalid value setting."]
        elif (CheckValue not in MacroMap):
            return [DbgLevel[2],"Macro was not defined."]
        else:
            try:
                Value = ExtractValue(MacroMap[CheckValue], ClassType)
                if ((Value < 0) or (CheckZero and Value == 0)):
                    return [DbgLevel[2],"Setting value must be greater than 0."]
            except:
                return [DbgLevel[2],"Invalid defined value. Macro should be " + str(ClassType) + "."]
    return [Value]
#}}}   

#----------Function to extract the value in string ----------
def ExtractValue (StringValue, ClassType):                            
#{{{
    Value = 0
    if (re.match("^[-]{0,1}0[xX][0-9a-fA-F]+$", StringValue) != None):
        Value = ClassType(float.fromhex(StringValue))
    else:
        Value = ClassType(StringValue)
    return Value
#}}}    
