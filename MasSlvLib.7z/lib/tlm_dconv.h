// $Id: tlm_dconv.h v2012_04_09 $
// =============================================================
//  
// =============================================================

#ifndef __TLM_DCONV_H
#define __TLM_DCONV_H

#include <systemc.h>
#include "tlm.h"
#ifdef CWR_SYSTEMC
#include <scml.h>
#endif//CWR_SYSTEMC

template<unsigned int I_DWIDTH=64, unsigned int O_DWIDTH=32>
class tlm_dconv
  : public sc_core::sc_module
  , public tlm::tlm_bw_transport_if<>
  , public tlm::tlm_fw_transport_if<>
{
public:
  // tlm initiator socket
  tlm::tlm_initiator_socket<O_DWIDTH> m_ini_socket;
  tlm::tlm_target_socket   <I_DWIDTH> m_tgt_socket;

private:
  bool m_endian_big;

public:
  SC_HAS_PROCESS(tlm_dconv);
  tlm_dconv(sc_core::sc_module_name name)
    : sc_core::sc_module(name)
    , m_ini_socket("m_ini_socket")
    , m_tgt_socket("m_tgt_socket")
  {
    m_ini_socket(*this);
    m_tgt_socket(*this);

#ifdef IS_MODELED_ENDIAN_BIG
    m_endian_big = true;
#else
    m_endian_big = false;
#endif

#ifdef CWR_SYSTEMC
    //handle command
    SCML_COMMAND_PROCESSOR(handleCommand);
    SCML_ADD_COMMAND("set_param", 2, 2, "set_param <param> <value>", "Set parameter");
#endif
  }

  virtual ~tlm_dconv(){ ; }

  void usage()
  {
    printf("tlm_dconv::handleCommand Usage : set_param ENDIAN (BIG | LITTLE)\n");
  }

  std::string handleCommand(const std::vector<std::string>& args)
  {
    if(args.size() != 3) {
      usage();
      return "ERROR";
    }
    if (args[0] == "set_param") {
      if (args[1] == "ENDIAN") {
        if (args[2] == "BIG") {
          m_endian_big = true;
          return "OK";
        }
        else if (args[2] == "LITTLE") {
          m_endian_big = false;
          return "OK";
        }
      }
    }
    printf("Error(%s) handleCommand Format Error!\n", this->basename());
    usage();
    return "ERROR";
  }

private:
  void ByteSwap(unsigned char *p_data, unsigned int size)
  {
    for(unsigned int i=0; i<size/2; i++) {
      unsigned char temp = p_data[i];
      p_data[i]        = p_data[size-i-1];
      p_data[size-i-1] = temp;
    }
  }

  void re_swap(unsigned char *p_data, unsigned int size, unsigned int bus_width)
  {
    if(size > bus_width && size%bus_width != 0) {
      cout << "Error [" << sc_time_stamp() << "] (" << this->name() << ") Invalid data length \"" << size << "\"" << endl;
      sc_stop();
    }

    if (size >= bus_width) {
      unsigned int loop_num = size / bus_width;
      for (unsigned int i = 0; i < loop_num; i++) {
        ByteSwap(p_data + bus_width * i, bus_width);
      }
    }
    else {
      ByteSwap(p_data, size);
    }
  }

  void re_flip(tlm::tlm_generic_payload &trans, unsigned int in_width, unsigned int out_width)
  {
    if(m_endian_big == true && in_width != out_width) {
      unsigned int in_byte_width = in_width/8;
      unsigned int out_byte_width = out_width/8;

      // address flip
      unsigned int addr = (unsigned int)trans.get_address();
      unsigned int size = trans.get_data_length();
      if( size < in_byte_width ) {
        unsigned int flip = in_byte_width - size;
        addr = addr ^ flip;
      }
      if( size < out_byte_width ) {
        unsigned int flip = out_byte_width - size;
        addr = addr ^ flip;
      }
      trans.set_address(addr);

      // swap data
      unsigned char *p_data = trans.get_data_ptr();
      if( size > in_byte_width || size > out_byte_width) {
        re_swap(p_data, size, in_byte_width);
        re_swap(p_data, size, out_byte_width);
      } 

      // swap byte-enable
      unsigned char *p_be = trans.get_byte_enable_ptr();
      unsigned int be_len   = trans.get_byte_enable_length();
      if( p_be != NULL && (be_len > in_byte_width || be_len > out_byte_width)) {
        re_swap(p_be, be_len, in_byte_width);
        re_swap(p_be, be_len, out_byte_width);
      }
    }
    return;
  }

  void b_transport(tlm::tlm_generic_payload &trans, sc_time &t)
  {
    re_flip(trans, I_DWIDTH, O_DWIDTH);

    m_ini_socket->b_transport(trans, t);

    re_flip(trans, O_DWIDTH, I_DWIDTH);
  }

  tlm::tlm_sync_enum nb_transport_fw(tlm::tlm_generic_payload &trans, tlm::tlm_phase &phase, sc_time &t)
  {
    if (phase == tlm::BEGIN_REQ) {
      re_flip(trans, I_DWIDTH, O_DWIDTH);
    }

    tlm::tlm_sync_enum sync = m_ini_socket->nb_transport_fw(trans, phase, t);

    if(sync == tlm::TLM_COMPLETED || phase == tlm::BEGIN_RESP) {
      re_flip(trans, O_DWIDTH, I_DWIDTH);
    }
    return sync;
  }

  bool get_direct_mem_ptr(tlm::tlm_generic_payload &trans, tlm::tlm_dmi &dmi_data)
  {
    if(m_endian_big == true && I_DWIDTH != O_DWIDTH) {
      return false;
    }

    return m_ini_socket->get_direct_mem_ptr(trans, dmi_data);
  }

  unsigned int transport_dbg(tlm::tlm_generic_payload &trans)
  {
    re_flip(trans, I_DWIDTH, O_DWIDTH);

    unsigned int num = m_ini_socket->transport_dbg(trans);

    re_flip(trans, O_DWIDTH, I_DWIDTH);

    return num;
  }

  void invalidate_direct_mem_ptr(sc_dt::uint64 start_range, sc_dt::uint64 end_range){
    m_tgt_socket->invalidate_direct_mem_ptr(start_range, end_range);
  }

  tlm::tlm_sync_enum nb_transport_bw(tlm::tlm_generic_payload& trans, tlm::tlm_phase& phase, sc_core::sc_time& t)
  {
    if (phase == tlm::BEGIN_RESP) {
      re_flip(trans, O_DWIDTH, I_DWIDTH);
    }

    return m_tgt_socket->nb_transport_bw(trans, phase, t);
  }
};

#endif//__TLM_DCONV_H
