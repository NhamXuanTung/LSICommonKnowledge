#!/usr/bin/env python
# ----------------------------------------------------------------------
# 
#  Copyright(c) 2010-2012 Renesas Electronics Corporation
#  Copyright(c) 2010-2012 RVC (Renesas Design Vietnam Co., Ltd.)
#  RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
#  This program must be used solely for the purpose for which
#  it was furnished by Renesas Electronics Corporation. No part of this
#  program may be reproduced or disclosed to others, in any
#  form, without the prior written permission of Renesas Electronics
#  Corporation.
# 
# ----------------------------------------------------------------------
# $Id: gen_regif.py v2017_04_13 $
# ----------------------------------------------------------------------

import sys
from optparse import OptionParser

minimum_version = (3,1,2) # minimum Python version: 3.1.2

def check_version(): # Check Python version
    current_version = sys.version_info[0:3]
    if (current_version < minimum_version):
        print("<INFO> Current Python version: " + sys.version.split("\n")[0])
        print("<ERROR> Python 3.1.2 or higher is recommended for running this script.")
        sys.exit()

def gen_regif(): # Main function of RegIF Generator
    parser = OptionParser(version="%prog 1.0")

    # Add option's information
    parser.add_option("-i", "--hier"   , dest="hiermode"    , action="store_true" , help="hierarchical-type input")
    parser.add_option("-a", "--metadata", dest="metadata"   , action="store_true" , help="generate metadata python file")
    parser.add_option("-o", "--onefile", dest="onefile"     , action="store_true" , help="generate only header file (.h)")
    parser.add_option("-k", "--keyword", dest="keyword"     , action="store"      , help="keyword for output file naming - <keyword>_regif.*"
                                       , metavar="KEYWORD")
    parser.add_option("-m", "--module" , dest="module"      , action="store"      , help="list of generated module name"
                                       , metavar="MODULENAME1,MODULENAME2,..."    , type="string")

    (options, args) = parser.parse_args()

    if (args == []):
        gen_regif_class.PrintDbgMsg("ERROR", "No input file.\nTry \'gen_regif.py -h\' for more information.", False)
    else:
        module_list = []
        if options.module:
            module_list = options.module.split(",")

        keyword = ""
        if options.keyword:
            keyword = options.keyword

        if options.hiermode:
            filetype = "Hierarchical"
        else:
            filetype = "Flat"
        gen_regif_class.PrintDbgMsg("INFO", "Register description file type: " + filetype, False)

        RegIFGen = gen_regif_class.CRegIFGen()
        for filename in args:
            RegIFGen.ReadFile(filename) # Read lines from legal input file(s) to store in mInputfileLineList

        module_line_list = RegIFGen.FindModule(module_list)
        for module_line in module_line_list:
            [start, end, module_name, line_num] = module_line
            RegIFGen.CheckNameFormat(module_name, [["%MODULE", module_name, line_num, filename],""])
            gen_regif_class.PrintDbgMsg("INFO", "Module name found: {}".format(module_name), False)
            module_part = RegIFGen.mInputfileLineList[start:end]
            parse_complete = RegIFGen.ParseInputFile(module_part, options.hiermode)
            if parse_complete:
                RegIFGen.GenerateOutputFile(options.onefile, options.metadata, keyword, module_name)

check_version()
import gen_regif_class
gen_regif()
