// $Id: arbiter.h v2011_05_12 $

#ifndef __arbiter_h
#define __arbiter_h

#include <vector>
#include "bus_base.h"

enum ARB_PRI_MODE {
  ARB_PRI_UPER_HIGH,
  ARB_PRI_LOWER_HIGH
};

enum ARB_STATUS {
  ARB_NORMAL,
  ARB_ERROR
};

class arbiter_base_elm {
};

class arbiter_base {
public:
  virtual void request(int id) = 0 ;
  virtual void reset(int id = -1) = 0 ;
  virtual int get_winner() = 0 ;
  virtual int winner() = 0 ;

  virtual void request(int id, int priority) {
    request(id);
  }

  virtual enum ARB_STATUS get_status() {
    return ARB_NORMAL;
  }

  arbiter_base() {
    bus_base_ptr = NULL;
    debug_level = 0;
  };

  virtual ~arbiter_base() {};

  // lck/r_lck
  virtual void notify_lck(int id) = 0;
  virtual void notify_unlck() = 0;

  // gnt support

  void set_bus_base_ptr(bus_base* p_bus_base)
  {
    bus_base_ptr = p_bus_base;
  }

  // profile
  virtual bool DumpProfile(FILE *p_file = stdout, sc_time_unit timescale = SC_NS)
  {
    return true;
  }

  // debug level
  void set_debug_level(unsigned int level)
  {
    debug_level = level;
  }

  // extra infomation
  virtual void set_extra_info(int id, int value, int flag) {};
  virtual void set_extra_info_size(int id, int size) {};

  virtual int get_pri_level() {
    return 0;
  }

  virtual void add_element(int id, arbiter_base_elm *element)
  {
    printf("ERROR : arbiter_base::add_element() : this virtual function is not overridden.\n");
    return;
  }

  virtual void all_reset()
  {
    printf("ERROR : arbiter_base::all_reset() : this virtual function is not overridden.\n");
    return;
  }

protected:
  bus_base* bus_base_ptr;

  unsigned int debug_level;
};

//////////////////////////////////////////
//  Arbiter FIX class
//////////////////////////////////////////
class arbiter_fix : public arbiter_base {
private:
  std::vector<arbiter_base *> _childList;

public:
  arbiter_fix() { };
  virtual ~arbiter_fix() { 

    for(unsigned int i=0; i<_childList.size(); i++) {
      delete _childList[i];
    }
  }

  void add_child(arbiter_base * ch) {
    _childList.push_back(ch);
  }

  void request(int id) {
    for(unsigned int i=0; i<_childList.size(); i++) {
      _childList[i]->request(id);
    }
  }

  void reset(int id = -1) {
    for(unsigned int i=0; i<_childList.size(); i++) {
      _childList[i]->reset(id);
    }
  }

  int get_winner() {
    for(unsigned int i=0; i<_childList.size(); i++) {
      int id = _childList[i]->get_winner();
      if(id >= 0) return id;
    }
    return -1;
  }

  int winner() {
    for(unsigned int i=0; i<_childList.size(); i++) {
      int id = _childList[i]->winner();
      if(id >= 0) return id;
    }
    return -1;
  }

  void notify_lck(int id) {
    for(unsigned int i=0; i<_childList.size(); i++) {
      _childList[i]->notify_lck(id);
    }
  }

  void notify_unlck(){
    for(unsigned int i=0; i<_childList.size(); i++) {
      _childList[i]->notify_unlck();
    }
  }
  
};

//////////////////////////////////////////
//  Arbiter LRU class
//////////////////////////////////////////
class arbiter_lru : public arbiter_base {
private:
  std::vector<arbiter_base *> _childList;
  int _index;

public:
  arbiter_lru() {
    _index = 0;
  }
  virtual ~arbiter_lru() { 

    for(unsigned int i=0; i<_childList.size(); i++) {
      delete _childList[i];
    }
  }

  void add_child(arbiter_base * ch) {
    _childList.push_back(ch);
  }

  void request(int id) {
    for(unsigned int i=0; i<_childList.size(); i++) {
      _childList[i]->request(id);
    }
  }

  void reset(int id = -1) {
    for(unsigned int i=0; i<_childList.size(); i++) {
      _childList[i]->reset(id);
    }
  }

  int get_winner() {
    unsigned int windex = _index;
    for(unsigned int i=0; i<_childList.size(); i++) {
      int id = _childList[windex]->get_winner();

      windex++;
      if(windex >= _childList.size()) windex = 0;

      if(id >= 0) {
        _index = windex;
        return id;
      }
    }
    return -1;
  }

  int winner() {
    unsigned int windex = _index;
    for(unsigned int i=0; i<_childList.size(); i++) {
      int id = _childList[windex]->winner();

      windex++;
      if(windex >= _childList.size()) windex = 0;

      if(id >= 0) {
        return id;
      }
    }
    return -1;
  }

  void notify_lck(int id) {
    for(unsigned int i=0; i<_childList.size(); i++) {
      _childList[i]->notify_lck(id);
    }
  }

  void notify_unlck(){
    for(unsigned int i=0; i<_childList.size(); i++) {
      _childList[i]->notify_unlck();
    }
  }

};

//////////////////////////////////////////
//  Arbiter leaf class
//////////////////////////////////////////
class arbiter_leaf : public arbiter_base {

private:
  int _id;
  bool _request;
  
  bool lck;

public:
  arbiter_leaf(int id) {
    _id = id;
    _request = 0;

    lck = false;
  }

  void notify_lck(int id) {
    if (id != _id) { 
      lck = true;
    }
  }

  void notify_unlck(){
    lck = false;
  }

  void request(int id) {
    if(id == _id) _request = 1;
  }

  void reset(int id = -1) {
    if(id < 0 || id == _id) _request = 0;
  }

  int get_winner() {
    if ( _request ) {
      if (lck == true) {
        return -1;
      }
      if (bus_base_ptr != NULL) {
        if (bus_base_ptr->get_permission(_id) == false) {
          return -1;
        }
      }
      _request = 0;
      return _id;
    }
    return -1;
  }

  int winner() {
    if( _request ) {
      if (lck == true) {
        return -1;
      }
      if (bus_base_ptr != NULL) {
        if (bus_base_ptr->get_permission(_id) == false) {
          return -1;
        }
      }
      return _id;
    }
    return -1;
  }
  
  arbiter_leaf() {};
  virtual ~arbiter_leaf() {};

};

#endif
