/****************************************************************************
* FOREST
* File name : memory_body.h
****************************************************************************/
#ifndef  __MEMORY_BODY_H__
#define  __MEMORY_BODY_H__

#include <string.h>
#include <stdlib.h>

#define MAX_MEM_RES     256
#define MEM_BLOCK_SIZE  0x00010000  // 64KB/Block

class Cmemory {
public:
    ShadowMode g_shadow_mode;         /* $B%7%c%I%&%b!<%I(B */

    MemoryBlock *p_mem_block_table[MEM_BLOCK_SIZE];  /* $B%a%b%j%V%m%C%/4IM}G[Ns(B */
    MemoryResource *p_mem_resources[MAX_MEM_RES];    /* $B%a%b%j%j%=!<%94IM}G[Ns(B */
    long n_mem_resources;                            /* $B%a%b%j%j%=!<%9?t(B */

    Cmemory (void) {
        memset (p_mem_block_table, 0, sizeof (MemoryBlock *) * MEM_BLOCK_SIZE);
        memset (p_mem_resources, 0, sizeof (MemoryResource *) * MAX_MEM_RES);
        n_mem_resources = 0;
    }

    ~Cmemory () {
        DeleteMemory();
    }

    unsigned long ByteSwap (unsigned long before);
    void MemBurstWriteBody (unsigned long addr, unsigned long *p_data, unsigned long size);
    void MemBurstReadBody  (unsigned long addr, unsigned long *p_data, unsigned long size);
    void MemWriteBody (unsigned long addr, unsigned long data, MemAccessDataType size);
    void MemWriteBodyByte (unsigned char *p_mres_addr, unsigned long data);
    void MemWriteBodyWord (unsigned char *p_mres_addr, unsigned long data);
    void MemWriteBodyLongword (unsigned char *p_mres_addr, unsigned long data);
    void MemWriteBodyQuadwordU (unsigned char *p_mres_addr, unsigned long data);
    void MemWriteBodyQuadwordL (unsigned char *p_mres_addr, unsigned long data);
    unsigned long MemReadBody (unsigned long addr, MemAccessDataType size);
    unsigned long MemReadBodyByte (unsigned char *p_mres_addr);
    unsigned long MemReadBodyWord (unsigned char *p_mres_addr);
    unsigned long MemReadBodyLongword (unsigned char *p_mres_addr);
    unsigned long MemReadBodyQuadwordU (unsigned char *p_mres_addr);
    unsigned long MemReadBodyQuadwordL (unsigned char *p_mres_addr);

    //for ASEmemory(Always Big Endian)
    void MemWriteBodyWordAse (unsigned char *p_mres_addr, unsigned long data);
    void MemWriteBodyLongwordAse (unsigned char *p_mres_addr, unsigned long data);
    void MemWriteBodyQuadwordUAse (unsigned char *p_mres_addr, unsigned long data);
    void MemWriteBodyQuadwordLAse (unsigned char *p_mres_addr, unsigned long data);
    unsigned long MemReadBodyWordAse (unsigned char *p_mres_addr);
    unsigned long MemReadBodyLongwordAse (unsigned char *p_mres_addr);
    unsigned long MemReadBodyQuadwordUAse (unsigned char *p_mres_addr);
    unsigned long MemReadBodyQuadwordLAse (unsigned char *p_mres_addr);

    unsigned char *GetMemBodyPointer(unsigned long addr);
    unsigned long MemBlockSearchBefore(unsigned long addr);
    unsigned long MemBlockSearchAfter(unsigned long addr);
    long MemBlockAllocContinuously (unsigned long block_id,
                             MemRestrictType restrict_type,
                             unsigned long mblock_read_state_count,
                             unsigned long mblock_write_state_count,
                             unsigned long mblock_bus_size,
                             MemMappedArea mblock_area,
                             unsigned long continuous_num);

    long MemBlockAlloc (unsigned long block_id, MemRestrictType restrict_type,
                        unsigned long mblock_read_state_count,
                        unsigned long mblock_write_state_count,
                        unsigned long mblock_bus_size,
                        MemMappedArea mblock_area);
    long MemBlockFree (unsigned long block_id);
    long MemBlockMove (unsigned long block_from_id, unsigned long block_to_id);
    long MemAttributeSet (unsigned long block_id, MemRestrictType restrict_type,
                          unsigned long mblock_read_state_count,
                          unsigned long mblock_write_state_count,
                          unsigned long mblock_bus_size,
                          MemMappedArea mblock_area);
    long MemBlockIsAlloc (unsigned long block_id);
    long MemAttributeGet (unsigned long block_id, MemoryBlock **pp_mem_block);
    MemoryBlock *MemBlockSearch (unsigned long addr);
    MemoryBlock *MemBlockShadowSearch (unsigned long org_addr,
                                       unsigned long *shadow_addr);
    void MemResourceAdd (unsigned long start_addr,
                         unsigned long end_addr,
                         MemRestrictType restrict_type,
                         unsigned long read_latency,
                         MemMappedArea area_type);
    long MemResourceSearch (unsigned long addr);
    long MemAccLatencyGet (unsigned long addr);
    void MemResourceDisplay (void);
    void SetShadowMode (ShadowMode shadow_mode);
    ShadowMode GetShadowMode (void);
    void PushVariables (FILE *fp);
    void PopVariables (FILE *fp);
    void DeleteMemory(void);
    void MemResourceRealloc (unsigned long start_addr,
                              unsigned long end_addr,
                              MemRestrictType restrict_type,
                              unsigned long read_latency,
                              MemMappedArea area_type);
    unsigned long CheckMemoryAddressStart(unsigned long start, unsigned long end);
    unsigned long CheckMemoryAddressEnd(unsigned long start, unsigned long end);
    //unsigned long MemBlockSearchContain(unsigned long start_addr, unsigned long end_addr);
    void DumpValidMemory (void);
    void InitMemData (unsigned long start_addr, unsigned long end_data);
};
#endif /* !__MEMORY_BODY_H__*/
