// $Id: arbiter_fair.h v2011_05_12 $
// =============================================================
//  file name : arbiter_fair.h
// =============================================================

#ifndef __ARBITER_FAIR_H
#define __ARBITER_FAIR_H

#include "systemc.h"
#include "arbiter.h"

#include <map>
#include <list>

/*  ARBITER ELEMENT  */
class arbiter_fair_elm : public arbiter_base_elm
{
  /*  SORT OBJECT  */
  friend class arbiter_fair_sort;

  /*  MEMBER DATA  */
  const int m_id;
  int m_priority;
  bool m_request;
  bool m_mask;

public:
  /*  CONSTRUCTOR  */
  arbiter_fair_elm(int id, int priority)
    : m_id(id)
    , m_priority(priority)
    , m_request(false)
    , m_mask(false)
  {
    /*  DO NOTHING  */
  }

  /*  MEMBER FUNCTION  */
  arbiter_fair_elm *clone() const
  {
    return new arbiter_fair_elm(*this);
  }

  int get_id()
  {
    return m_id;
  }

  void set_priority(int priority)
  {
    m_priority = priority;
  }

  int get_priority()
  {
    return m_priority;
  }

  void request()
  {
    m_request = true;
  }

  void reset_request()
  {
    m_request = false;
  }

  bool is_request()
  {
    return m_request;
  }

  void mask()
  {
    m_mask = true;
  }

  void reset_mask()
  {
    m_mask = false;
  }

  bool is_mask()
  {
    return m_mask;
  }

  void all_reset()
  {
    m_request = false;
    m_mask = false;
  }

  bool is_available()
  {
    return (! m_mask);
  }
};

/*  SORT OBJECT  */
class arbiter_fair_sort
{
  /*  MEMBER DATA  */
  ARB_PRI_MODE m_mode;

public:
  /*  CONSTRUCTOR  */
  arbiter_fair_sort(ARB_PRI_MODE mode)
    : m_mode(mode)
  {
    /*  DO NOTHING  */
  }

  /*  MEMBER FUNCTION  */
  bool operator () (const arbiter_fair_elm *lit, const arbiter_fair_elm *rit)
  {
    if (m_mode == ARB_PRI_UPER_HIGH) {
      return (lit->m_priority == rit->m_priority) ?
        (lit->m_id > rit->m_id) : (lit->m_priority > rit->m_priority);
    }
    else {
      return (lit->m_priority == rit->m_priority) ?
        (lit->m_id < rit->m_id) : (lit->m_priority < rit->m_priority);
    }
  }
};

/*  ARBITER  */
class arbiter_fair : public arbiter_base
{
  /*  TYPE DEFINITION  */
  typedef std::map<int, arbiter_fair_elm *> std_elm_map;
  typedef std::map<int, arbiter_fair_elm *>::iterator std_elm_map_it;
  typedef std::list<arbiter_fair_elm *> std_elm_list;
  typedef std::list<arbiter_fair_elm *>::iterator std_elm_list_it;

  /*  MEMBER DATA  */
  std_elm_map m_elm_map;
  std_elm_list m_elm_list;
  ARB_PRI_MODE m_mode;
  ARB_STATUS m_status;
  bool m_list_update;
  unsigned int m_request_count;
  unsigned int m_mask_count;

public:
  /*  CONSTRUCTOR  */
  arbiter_fair(ARB_PRI_MODE mode = ARB_PRI_UPER_HIGH)
    : m_mode(mode)
    , m_status(ARB_NORMAL)
    , m_list_update(false)
    , m_request_count(0)
    , m_mask_count(0)
  {
    /*  DO NOTHING  */
  }

  /*  DESTRUCTOR  */
  virtual ~arbiter_fair()
  {
    for (std_elm_map_it it = m_elm_map.begin(); it != m_elm_map.end(); it++) {
      delete it->second;
    }
  }

  /*  MEMBER FUNCTIOM  */
  void add_element(int id)
  {
    add_element(id, id);
  }

  void add_element(int id, int priority)
  {
    if (m_elm_map.count(id)) {
      m_status = ARB_ERROR;
    }
    else {
      m_elm_map[id] = new arbiter_fair_elm(id, priority);
      m_elm_list.push_back(m_elm_map[id]);
      m_list_update = true;
      m_status = ARB_NORMAL;
    }
  }

  void add_element(int id, arbiter_base_elm *element) {
    if (m_elm_map.count(id)) {
      m_status = ARB_ERROR;
    }
    else {
      m_elm_map[id] = (arbiter_fair_elm *) element;
      m_elm_list.push_back(m_elm_map[id]);
      m_list_update = true;
      m_status = ARB_NORMAL;
    }
  }

  int get_element_size () {
    m_status = ARB_NORMAL;
    return m_elm_map.size();
  }

  void set_priority(int id, int priority)
  {
    if (! m_elm_map.count(id)) {
      m_status = ARB_ERROR;
    }
    else {
      m_elm_map[id]->set_priority(priority);
      m_list_update = true;
      m_status = ARB_NORMAL;
    }
  }

  int get_priority(int id)
  {
    if (! m_elm_map.count(id)) {
      m_status = ARB_ERROR;
      return -1;
    }
    else {
      m_status = ARB_NORMAL;
      return m_elm_map[id]->get_priority();
    }
  }

  void set_descending_order() {
    m_mode = ARB_PRI_UPER_HIGH;
    m_list_update = true;
    m_status = ARB_NORMAL;
  }

  bool is_descending_order() {
    m_status = ARB_NORMAL;
    return (m_mode == ARB_PRI_UPER_HIGH);
  }

  void set_ascending_order() {
    m_mode = ARB_PRI_LOWER_HIGH;
    m_list_update = true;
    m_status = ARB_NORMAL;
  }

  bool is_ascending_order() {
    m_status = ARB_NORMAL;
    return (m_mode == ARB_PRI_LOWER_HIGH);
  }

  void request(int id)
  {
    if (! m_elm_map.count(id)) {
      m_status = ARB_ERROR;
    }
    else {
      if (! m_elm_map[id]->is_request()) {
        m_elm_map[id]->request();
        m_request_count++;
      }
      m_status = ARB_NORMAL;
    }
  }

  void reset()
  {
    for (std_elm_map_it it = m_elm_map.begin(); it != m_elm_map.end(); it++) {
      it->second->reset_request();
    }
    m_request_count = 0;
    m_status = ARB_NORMAL;
  }

  void reset(int id)
  {
    if (! m_elm_map.count(id)) {
      m_status = ARB_ERROR;
    }
    else {
      if (m_elm_map[id]->is_request()) {
        m_elm_map[id]->reset_request();
        m_request_count--;
      }
      m_status = ARB_NORMAL;
    }
  }

  void all_reset()
  {
    for (std_elm_map_it it = m_elm_map.begin(); it != m_elm_map.end(); it++) {
      it->second->all_reset();
    }
    m_request_count = 0;
    m_mask_count = 0;
    m_status = ARB_NORMAL;
  }

  int get_winner()
  {
    int winner_id = winner();
    update(winner_id);
    return winner_id;
  }

  int winner()
  {
    if (m_list_update) {
      m_elm_list.sort(arbiter_fair_sort(m_mode));
      m_list_update = false;
    }
    m_status = ARB_NORMAL;
    return (m_request_count > 0) ? arbitrate() : -1;
  }

  ARB_STATUS get_status()
  {
    return m_status;
  }

  void notify_lck(int id)
  {
    /*  UNSUPPORTED  */
    m_status = ARB_ERROR;
  }

  void notify_unlck()
  {
    /*  UNSUPPORTED  */
    m_status = ARB_ERROR;
  }

protected:
  /*  ARBITER TYPE SPECIFIC  */
  int arbitrate()
  {
    for (std_elm_list_it it = m_elm_list.begin(); it != m_elm_list.end(); it++) {
      if ((*it)->is_request() && (*it)->is_available()) {
        return (*it)->get_id();
      }
    }
    return -1;
  }

  void update(int winner_id)
  {
    if (winner_id != -1) {
      m_elm_map[winner_id]->reset_request();
      m_request_count--;
      m_elm_map[winner_id]->mask();
      m_mask_count++;
    }
    else {
      if (m_mask_count > 0) {
        for (std_elm_map_it it = m_elm_map.begin(); it != m_elm_map.end(); it++) {
          it->second->reset_mask();
        }
        m_mask_count = 0;
      }
    }
  }
};

#endif
