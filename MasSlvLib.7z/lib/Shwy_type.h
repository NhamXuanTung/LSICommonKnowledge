//$Id: Shwy_type.h v2011_06_08 $

#ifndef __SHWY_TYPE_H__
#define __SHWY_TYPE_H__

#include <vector>
#include <string>
#include "tlm.h"
#include "arbiter_dynamic.h"
#include "arbiter_wait.h"
#include "arbiter_wtop_wait.h"
#include "arbiter_fair.h"
#include "arbiter_prob.h"

enum dynamic_arbiter_subtype {DEFAULT_ARB, FAIR_ARB, PROB_ARB};

struct ConnectionInfo {
  int from;
  int to;
  int BEGIN_RESP_FLAG;
  sc_time ReqFromIniTime;
};

class ResourceInfo {
public:
  ResourceInfo(){
    m_target_id = -1;
    m_gp = NULL;
    m_read = true;
  }

  void setInfo(int tgt_id, tlm::tlm_generic_payload * gp) {
    m_target_id = tgt_id;
    m_gp = gp;
    if (m_gp->get_command() == tlm::TLM_READ_COMMAND) {
      m_read = true;
    }
    else {
      m_read = false;
    }
  }

  int getTgtId() {
    return m_target_id;
  }

  bool isRead() {
    if(m_read != (m_gp->get_command() == tlm::TLM_READ_COMMAND)) {
      cout << "ASSERTION ERROR : ResourceInfo::isRead : internal error" << endl;
    }
    return m_read;
  }

private:
  int  m_target_id;
  bool m_read;
  tlm::tlm_generic_payload * m_gp;
};

template <int NR_OF_INITIATORS, int NR_OF_TARGETS, int BUS_WIDTH=32>
class Shwy_GroupId
{
private:
  int initiator_grp_id[NR_OF_INITIATORS];
  int target_grp_id[NR_OF_TARGETS];
  int ini_grp_max;
  int tgt_grp_max;

public:
  Shwy_GroupId(){
    for (int i = 0; i < NR_OF_INITIATORS; i++) {
      initiator_grp_id[i] = 0;
    }
    for (int i = 0; i< NR_OF_TARGETS; i++) {
      target_grp_id[i] = 0;
    }
    ini_grp_max = 1;
    tgt_grp_max = 1;
  }
  
  void setInitiatorGroupId(int ini_id, int ini_grp_id)
  {
    initiator_grp_id[ini_id] = ini_grp_id;

    if(ini_grp_max < ini_grp_id+1) {
      ini_grp_max = ini_grp_id+1;
    }
  }
  
  void setTargetGroupId(int tgt_id, int tgt_grp_id)
  {
    target_grp_id[tgt_id] = tgt_grp_id;

    if(tgt_grp_max < tgt_grp_id+1) {
      tgt_grp_max = tgt_grp_id+1;
    }
  }
  
  int getInitiatorGroupId(int initiator_id)
  {
    return initiator_grp_id[initiator_id];
  }
  
  int getTargetGroupId(int target_id)
  {
    return target_grp_id[target_id];
  }
  
  int getInitiatorGroupMax()
  {
    return ini_grp_max;
  }
  
  int getTargetGroupMax()
  {
    return tgt_grp_max;
  }
};

class Shwy_Priority
{
private:
  std::vector<arbiter_dynamic_elm *> PriInfo;
  dynamic_arbiter_subtype m_arb_subtype;
  ARB_PRI_MODE m_arb_mode;
  std::vector<arbiter_fair_elm *> m_fair_elm_info;
  std::vector<arbiter_prob_elm *> m_prob_elm_info;

public:
  Shwy_Priority(int NR_IPs) {
    PriInfo.resize(NR_IPs, NULL);
    m_arb_subtype = DEFAULT_ARB;
    m_arb_mode = ARB_PRI_UPER_HIGH;
    m_fair_elm_info.resize(NR_IPs, NULL);
    m_prob_elm_info.resize(NR_IPs, NULL);
  }

  ~Shwy_Priority() {
    for(unsigned int id=0; id<PriInfo.size(); id++) {
      delete PriInfo[id];
      delete m_fair_elm_info[id];
      delete m_prob_elm_info[id];
    }
  }
  
  bool set_priority(int id, int priority = 8, sc_core::sc_time interval_time = sc_time(0, SC_NS), int low_priority = 8) {
    // dynamic priority arbiter
    if (PriInfo[id] != NULL) {
      delete PriInfo[id];
      PriInfo[id] = new arbiter_dynamic_elm(priority, low_priority, interval_time);
      return false;
    }
    PriInfo[id] = new arbiter_dynamic_elm(priority, low_priority, interval_time);
    return true;
  }

  bool set_wait(int id, sc_core::sc_time time, bool count_mode, bool lck_mode) {
    // wait time arbiter
    if (PriInfo[id] != NULL) {
      delete PriInfo[id];
      PriInfo[id] = new arbiter_wait_elm(time, count_mode, lck_mode);
      return false;
    }
    PriInfo[id] = new arbiter_wait_elm(time, count_mode, lck_mode);
    return true;
  }

  bool set_wtop_wait(int id, std::vector<sc_time>& t_list) {
    // wtop arbiter
    if (PriInfo[id] != NULL) {
      delete PriInfo[id];
      PriInfo[id] = new arbiter_wtop_wait_elm(id, t_list);
      return false;
    }
    PriInfo[id] = new arbiter_wtop_wait_elm(id, t_list);
    return true;
  }

  bool set_dynamic_arbiter_subtype(dynamic_arbiter_subtype arb_subtype)
  {
    m_arb_subtype = arb_subtype;
    return true;
  }

  bool set_dynamic_arbiter_mode(ARB_PRI_MODE arb_mode)
  {
    if (m_arb_subtype == DEFAULT_ARB) {
      printf("ERROR : Shwy_Priority::set_dynamic_arbiter_mode() : dynamic arbitration type 'DEFAULT_ARB' is unsupported.\n");
      return false;
    }
    else if ((m_arb_subtype == FAIR_ARB) || (m_arb_subtype == PROB_ARB)) {
      m_arb_mode = arb_mode;
      return true;
    }
    else {
      printf("ERROR : Shwy_Priority::set_dynamic_arbiter_mode() : dynamic arbitration type is invalid.\n");
      return false;
    }
  }

  bool set_dynamic_arbiter_priority(int id, int priority)
  {
    if (m_arb_subtype == DEFAULT_ARB) {
      printf("ERROR : Shwy_Priority::set_dynamic_arbiter_priority() : dynamic arbitration type 'DEFAULT_ARB' is unsupported.\n");
      return false;
    }
    else if (m_arb_subtype == FAIR_ARB) {
      if (m_fair_elm_info[id] == NULL) {
        m_fair_elm_info[id] = new arbiter_fair_elm(id, priority);
      }
      else {
        m_fair_elm_info[id]->set_priority(priority);
      }
      return true;
    }
    else if (m_arb_subtype == PROB_ARB) {
      if (m_prob_elm_info[id] == NULL) {
        m_prob_elm_info[id] = new arbiter_prob_elm(id, priority, 1, 1);
      }
      else {
        m_prob_elm_info[id]->set_priority(priority);
      }
      return true;
    }
    else {
      printf("ERROR : Shwy_Priority::set_dynamic_arbiter_priority() : dynamic arbitration type is invalid.\n");
      return false;
    }
  }

  bool set_dynamic_arbiter_probability(int id, unsigned int prob_num, unsigned int prob_denom)
  {
    if ((m_arb_subtype == DEFAULT_ARB) || (m_arb_subtype == FAIR_ARB)) {
      printf("ERROR : Shwy_Priority::set_dynamic_arbiter_probability() : dynamic arbitration type 'DEFAULT_ARB' and 'FAIR_ARB' is unsupported.\n");
      return false;
    }
    else if (m_arb_subtype == PROB_ARB) {
      if (m_prob_elm_info[id] == NULL) {
        m_prob_elm_info[id] = new arbiter_prob_elm(id, id, prob_num, prob_denom);
      }
      else {
        m_prob_elm_info[id]->set_probability(prob_num, prob_denom);
      }
      return true;
    }
    else {
      printf("ERROR : Shwy_Priority::set_dynamic_arbiter_probability() : dynamic arbitration type is invalid.\n");
      return false;
    }
  }

  arbiter_dynamic_elm * get_arbiter_elm(int id) {
    if(PriInfo[id] == NULL) {
      PriInfo[id] = get_default();
    }
    return PriInfo[id]->clone();
  }

  dynamic_arbiter_subtype get_dynamic_arbiter_subtype()
  {
    return m_arb_subtype;
  }

  ARB_PRI_MODE get_dynamic_arbiter_mode()
  {
    if (m_arb_subtype == DEFAULT_ARB) {
      printf("ERROR : Shwy_Priority::get_dynamic_arbiter_mode() : dynamic arbitration type 'DEFAULT_ARB' is unsupported.\n");
      return ARB_PRI_UPER_HIGH;
    }
    else if ((m_arb_subtype == FAIR_ARB) || (m_arb_subtype == PROB_ARB)) {
      return m_arb_mode;
    }
    else {
      printf("ERROR : Shwy_Priority::get_dynamic_arbiter_mode() : dynamic arbitration type is invalid.\n");
      return ARB_PRI_UPER_HIGH;
    }
    
  }

  arbiter_base_elm *get_dynamic_arbiter_element(int id)
  {
    if (m_arb_subtype == DEFAULT_ARB) {
      printf("ERROR : Shwy_Priority::get_dynamic_arbiter_element() : dynamic arbitration type 'DEFAULT_ARB' is unsupported.\n");
      return NULL;
    }
    else if (m_arb_subtype == FAIR_ARB) {
      return (m_fair_elm_info[id] == NULL) ? new arbiter_fair_elm(id, id) : m_fair_elm_info[id]->clone();
    }
    else if (m_arb_subtype == PROB_ARB) {
      return (m_prob_elm_info[id] == NULL) ? new arbiter_prob_elm(id, id, 1, 1) : m_prob_elm_info[id]->clone();
    }
    else {
      printf("ERROR : Shwy_Priority::get_dynamic_arbiter_element() : dynamic arbitration type is invalid.\n");
      return NULL;
    }
  }

private:
  arbiter_dynamic_elm * get_default() {
    return new arbiter_dynamic_elm(8, 8, sc_time(0,SC_NS));  // default priority
  }
};

struct ArbitrationInfo {
  ArbitrationInfo() {
    grp_id = 0;
    arb_exp = "";
  }
  int grp_id;
  std::string arb_exp;
};

class Shwy_Arbitration
{
private:
  std::vector<ArbitrationInfo> ArbInfo;

public:
  Shwy_Arbitration() {
  }

  void set_arbitration(int grp_id, std::string exp) {
    if((int)ArbInfo.size() < grp_id+1) {
      ArbInfo.resize(grp_id+1);
    }
    ArbInfo[grp_id].grp_id = grp_id;
    ArbInfo[grp_id].arb_exp = exp;
  }

  std::string get_arbitration(int grp_id) {
    if((int)ArbInfo.size() < grp_id+1) {
      ArbInfo.resize(grp_id+1);
    }
    return ArbInfo[grp_id].arb_exp;
  }
};

//
// Profile Classes
//
class Shwy_Access_Data
{
public:
  unsigned int m_NumOfAccess;
  unsigned int m_NumOfCell;
  unsigned int m_TotalSize;

  Shwy_Access_Data() {
    m_NumOfAccess = 0;
    m_NumOfCell   = 0;
    m_TotalSize   = 0;
  }

  void SetProf(unsigned int size, unsigned int cell)
  {
    m_NumOfAccess++;
    m_NumOfCell += cell;
    m_TotalSize += size;
  }

  Shwy_Access_Data & operator+=(const Shwy_Access_Data & other)
  {
    m_NumOfAccess += other.m_NumOfAccess;
    m_NumOfCell   += other.m_NumOfCell;
    m_TotalSize   += other.m_TotalSize;
    return *this;
  }
};

class Shwy_Wait_Data
{
public:
  sc_time  m_Time;
  sc_time  m_MinTime;
  sc_time  m_MaxTime;

  Shwy_Wait_Data() {
    m_Time    = SC_ZERO_TIME;
    m_MinTime = sc_time(10000,SC_SEC);
    m_MaxTime = SC_ZERO_TIME;
  }

  void SetWait(sc_time time) {
    m_Time +=  time;
    if(m_MinTime > time)  m_MinTime = time;
    if(m_MaxTime < time)  m_MaxTime = time;
  }
};

template <int NR_OF_INITIATORS, int NR_OF_TARGETS, int BUS_WIDTH>
class Shwy_Profile
{
private:
  Shwy_Access_Data   m_read [NR_OF_INITIATORS][NR_OF_TARGETS];
  Shwy_Access_Data   m_write[NR_OF_INITIATORS][NR_OF_TARGETS];
  Shwy_Access_Data   m_sum_read;
  Shwy_Access_Data   m_sum_write;

  Shwy_Wait_Data     m_sum_wait;

  Shwy_GroupId<NR_OF_INITIATORS, NR_OF_TARGETS, BUS_WIDTH> * m_group;

public:
  Shwy_Profile(Shwy_GroupId<NR_OF_INITIATORS, NR_OF_TARGETS, BUS_WIDTH> * group)
  {
    m_group = group;
  }

  void SetProf(tlm::tlm_generic_payload & gp, unsigned int ini_id, unsigned int tgt_id)
  {
    unsigned int size = gp.get_data_length();
    unsigned int cell = (size*8 + BUS_WIDTH - 1) / BUS_WIDTH;

    if(gp.get_command() == tlm::TLM_READ_COMMAND) {
      m_read[ini_id][tgt_id].SetProf(size, cell);
      m_sum_read.SetProf(size, cell);
    }
    else {
      m_write[ini_id][tgt_id].SetProf(size, cell);
      m_sum_write.SetProf(size, cell);
    }
  }

  void SetWait(unsigned int ini_id, unsigned int tgt_id, sc_time& time)
  {
    m_sum_wait.SetWait(time);
  }

  void DumpProfile(FILE *p_file, sc_time_unit timescale)
  {
    // Total Access
    fprintf(p_file, "Total Access\n");
    DumpAccessProfile(p_file, "Read Access",  m_sum_read);
    DumpAccessProfile(p_file, "Write Access", m_sum_write);

    // Each Request Resource Access
    for(int res=0; res<m_group->getInitiatorGroupMax(); res++) {
      Shwy_Access_Data   m_read_tmp;
      Shwy_Access_Data   m_write_tmp;
      fprintf(p_file, "\nRequest Resource %d\n",res);
      for(unsigned int ini_id=0; ini_id<NR_OF_INITIATORS; ini_id++) {
        for(unsigned int tgt_id=0; tgt_id<NR_OF_TARGETS; tgt_id++) {
          if(m_group->getTargetGroupId(tgt_id) == res) {
            m_read_tmp += m_read[ini_id][tgt_id];
            m_write_tmp += m_write[ini_id][tgt_id];
          }
        }
      }
      DumpAccessProfile(p_file, "Read Access",  m_read_tmp);
      DumpAccessProfile(p_file, "Write Access", m_write_tmp);
    }

    // Each Response Resource Access
    for(int res=0; res<m_group->getTargetGroupMax(); res++) {
      Shwy_Access_Data   m_read_tmp;
      Shwy_Access_Data   m_write_tmp;
      fprintf(p_file, "\nResponse Resource %d\n",res);
      for(unsigned int ini_id=0; ini_id<NR_OF_INITIATORS; ini_id++) {
        if(m_group->getInitiatorGroupId(ini_id) == res) {
          for(unsigned int tgt_id=0; tgt_id<NR_OF_TARGETS; tgt_id++) {
            m_read_tmp += m_read[ini_id][tgt_id];
            m_write_tmp += m_write[ini_id][tgt_id];
          }
        }
      }
      DumpAccessProfile(p_file, "Read Access",  m_read_tmp);
      DumpAccessProfile(p_file, "Write Access", m_write_tmp);
    }

    // Wait Time
    sc_time average = m_sum_wait.m_Time / (m_sum_read.m_NumOfAccess + m_sum_write.m_NumOfAccess);
    fprintf(p_file, "\nRequest Wait Time\n");
    fprintf(p_file, "  Total Wait Time  = %s\n", m_sum_wait.m_Time.to_string().c_str());
    fprintf(p_file, "  Min Wait Time    = %s\n", m_sum_wait.m_MinTime.to_string().c_str());
    fprintf(p_file, "  Max Wait Time    = %s\n", m_sum_wait.m_MaxTime.to_string().c_str());
    fprintf(p_file, "  Ave Wait Time    = %s\n", average.to_string().c_str());
  }

private:
  void DumpAccessProfile(FILE *p_file, const std::string title, Shwy_Access_Data & prof)
  {
    fprintf(p_file, "  %s\n", title.c_str());
    fprintf(p_file, "    Number of Access  = %6d\n", prof.m_NumOfAccess);
    fprintf(p_file, "    Number of Cell    = %6d\n", prof.m_NumOfCell);
    fprintf(p_file, "    Total Access Size = %6d byte\n", prof.m_TotalSize);
  }
};

#endif
