//$Id: Shwy.h v2011_06_08 $

#ifndef __SHWY_H__
#define __SHWY_H__

#include "systemc.h"
#include "tlm.h"
#include <vector>
#include <string.h>

#include "sysc/kernel/sc_spawn.h"
#include "sysc/kernel/sc_boost.h"

#include "tlm_utils/simple_target_socket.h"
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/peq_with_get.h"
#include "tlm_if.h"

#include "bus_base.h"

#include "address_map.h"

#include "Shwy_type.h"
#include "Shwy_Request.h"
#include "Shwy_Response.h"

template <int NR_OF_INITIATORS, int NR_OF_TARGETS, int BUS_WIDTH>
class Shwy : public sc_core::sc_module , public bus_base
{
public:
  typedef tlm::tlm_generic_payload               transaction_type;
  typedef tlm::tlm_phase                         phase_type;
  typedef tlm::tlm_sync_enum                     sync_enum_type;
  typedef tlm_utils::simple_target_socket_tagged<Shwy,BUS_WIDTH>    target_socket_type;
  typedef tlm_utils::simple_initiator_socket_tagged<Shwy,BUS_WIDTH> initiator_socket_type;
  
  typedef Shwy_Request<NR_OF_INITIATORS,NR_OF_TARGETS,BUS_WIDTH>  ReqResType;
  typedef Shwy_Response<NR_OF_INITIATORS,NR_OF_TARGETS,BUS_WIDTH> RespResType;
  
  target_socket_type target_socket[NR_OF_INITIATORS];
  initiator_socket_type initiator_socket[NR_OF_TARGETS];
  std::vector<ReqResType *>  Request_Thread_List;
  std::vector<RespResType *> Response_Thread_List;
  
  Caddress_map Caddress_map0;
  Shwy_GroupId<NR_OF_INITIATORS, NR_OF_TARGETS, BUS_WIDTH> Shwy_GroupId0;

  Shwy_Profile<NR_OF_INITIATORS, NR_OF_TARGETS, BUS_WIDTH> * m_prof;  // Profile

  int debug_print_level;

  unsigned int m_bank_bit_num;
  unsigned int m_bank_bit_loc;
  unsigned int m_wtop_opt_level;
  bool         m_level_propagate;

  int m_beg_resp_wait;
  sc_event m_beg_resp_event;

private:
  
  int          dynamic_arb;
  ARB_PRI_MODE dynamic_arb_mode;

  ResourceInfo ResInfo[NR_OF_INITIATORS];

  bool default_bus_property_is_set;

  Shwy_Priority Shwy_Initiator_Pri;

  Shwy_Arbitration Request_Arb_Info;
  Shwy_Arbitration Response_Arb_Info;

public:
  SC_HAS_PROCESS(Shwy);
  Shwy(sc_core::sc_module_name name) :
    sc_core::sc_module(name),
    bus_base(NR_OF_TARGETS),
    Caddress_map0(),
    Shwy_GroupId0(),
    Shwy_Initiator_Pri(NR_OF_INITIATORS),
    Request_Arb_Info(),
    Response_Arb_Info(),
    mPendingTransactions()
  {
    for (int i = 0; i < NR_OF_INITIATORS; ++i) {
      // marged from LT 2009.11.26
      target_socket[i].register_b_transport(this, &Shwy::initiatorBTransport, i);
      target_socket[i].register_nb_transport_fw(this, &Shwy::initiatorNBTransport, i);
      target_socket[i].register_transport_dbg(this, &Shwy::transportDebug, i);
      target_socket[i].register_get_direct_mem_ptr(this, &Shwy::getDMIPointer, i);
    }
    for (int i = 0; i < NR_OF_TARGETS; ++i) {
      initiator_socket[i].register_nb_transport_bw(this, &Shwy::targetNBTransport, i);
      initiator_socket[i].register_invalidate_direct_mem_ptr(this, &Shwy::invalidateDMIPointers, i);
    }

    m_prof = new Shwy_Profile<NR_OF_INITIATORS, NR_OF_TARGETS, BUS_WIDTH>(&Shwy_GroupId0);

    dynamic_arb = 0;
    dynamic_arb_mode = ARB_PRI_UPER_HIGH;
    debug_print_level = 0;

    m_bank_bit_num = 0;
    m_bank_bit_loc = 0;
    m_wtop_opt_level = 0;
    m_level_propagate = false;
      
    default_bus_property_is_set = false;

    max_priority = 15;

    get_req_resource(0);  // alloc request resource 0
    get_resp_resource(0); // alloc response resource 0

    m_beg_resp_wait = 0;
  }

  ~Shwy(){
    for (unsigned int i=0; i<Request_Thread_List.size(); i++) {
      delete Request_Thread_List[i];
    }
    for (unsigned int i=0; i<Response_Thread_List.size(); i++) {
      delete Response_Thread_List[i];
    }
    delete m_prof;

  }

  // add handleCommand
  std::string handleCommand(const std::vector<std::string> &args) {
    std::string header = "[" + (std::string)this->get_name() + "]  ";
    std::ostringstream msg;

    if (args[0] == "set_arbtype") {
      if (args.size() == 2) {
        if (args[1] == "is_normal") {
          dynamic_arb = 0;
        }  else if (args[1] == "is_dynamic") {
          dynamic_arb = 1;
          Shwy_Initiator_Pri.set_dynamic_arbiter_subtype(DEFAULT_ARB);
        } else {
          printf("[%s] %s is illeagal arbitration type!\n", this->get_name(), args[1].c_str());
          return "";
        }
      } else { 
        printf("[%s] Data format Error! Data should be 2 colums!(set_arbtype)\n", this->get_name());
        return "";
      }
    }
    else if (args[0] == "set_dprint_level") {
      if (args.size() == 2) {
        int dprint_level = get_value(args[1], args[0], 0, 3);
        
        debug_print_level = dprint_level;
        
        // set debug_print_level to Request Resources
        for (unsigned int i=0; i<Request_Thread_List.size(); i++){
          Request_Thread_List[i]->set_dprint_level(debug_print_level);
        }
        
        // set debug_print_level to Response Resources
        for (unsigned int i=0; i<Response_Thread_List.size(); i++){
          Response_Thread_List[i]->set_dprint_level(debug_print_level);
        }
      } else {
        printf("[%s] Data format Error! Data should be 2 colums!(set_dprint_level)\n", this->get_name());
      }
    } 
    else if (args[0] == "set_request_arbiter_period") {
      if ((args.size() == 3) || (args.size() == 4)) {
        int time_value = get_value(args[1], args[0], 0, INT_MAX);
        sc_time_unit time_unit = get_time_unit(args[2], args[0]);
        std::string option = (args.size() == 4) ? args[3] : "initialize";
        if ((time_value >= 0) && (time_unit != SC_FS) && ((option == "initialize") || (option == "dont_initialize"))) {
          for (unsigned int i = 0; i < Response_Thread_List.size(); i++) {
            Request_Thread_List[i]->set_request_arbiter_period(sc_time(time_value, time_unit), (option == "initialize"));
          }
        }
        else {
          printf("[%s] Arguments are contain illeagal value! (%s)\n", this->get_name(), args[0].c_str());
          return "";
        }
      }
      else {
        printf("[%s] Data format Error! Data should be 3 or 4colums! (%s)\n", this->get_name(), args[0].c_str());
        return "";
      }
    }
    else if (args[0] == "set_request_arbiter_clk") {
      if (args.size() == 3) {
        int time_value = get_value(args[1], args[0], 0, INT_MAX);
        sc_time_unit time_unit = get_time_unit(args[2], args[0]);
        if ((time_value >= 0) && (time_unit != SC_FS)) {
          for (unsigned int i = 0; i < Response_Thread_List.size(); i++) {
            Request_Thread_List[i]->set_request_arbiter_clk(sc_time(time_value, time_unit));
          }
        }
        else {
          printf("[%s] Arguments are contain illeagal value! (%s)\n", this->get_name(), args[0].c_str());
          return "";
        }
      }
      else {
        printf("[%s] Data format Error! Data should be 3 colums! (%s)\n", this->get_name(), args[0].c_str());
        return "";
      }
    }
    else if (args[0] == "set_request_arbiter_outstanding") {
      if (args.size() == 2) {
        int value = get_value(args[1], args[0], 0, INT_MAX);
        if (value >= 0) {
          for (unsigned int i = 0; i < Response_Thread_List.size(); i++) {
            Request_Thread_List[i]->set_request_arbiter_outstanding((unsigned int) value);
          }
        }
        else {
          printf("[%s] Arguments are contain illeagal value! (%s)\n", this->get_name(), args[0].c_str());
          return "";
        }
      }
      else {
        printf("[%s] Data format Error! Data should be 2 colums! (%s)\n", this->get_name(), args[0].c_str());
        return "";
      }
    }
    else if (args[0] == "set_arb") {
      if (args.size() == 4) {
        int bus_id = get_value(args[1], args[0], 0, INT_MAX);
        if (args[2] == "Req") {
          // store arb info to request struct.
          Request_Arb_Info.set_arbitration(bus_id, args[3]);
        } else if (args[2] == "Resp") {
          // store arb info to response struct.
          Response_Arb_Info.set_arbitration(bus_id, args[3]);
        } else {
          printf("[%s] Invalid keyword \"%s\"\n", this->get_name(), args[2].c_str());
        }
      } else {
        printf("[%s] Data format Error! Data should be 4 colums!(set_arb)\n", this->get_name());
      }
    }
    else if (args[0] == "set_maxpri" ||
             args[0] == "set_inipri" ||
             args[0] == "set_wait_time" ||
             args[0] == "set_wtop_wait_time" ||
             args[0] == "set_wtop_opt_level" ||
             args[0] == "set_bank_bit" ||
             args[0] == "arb_level_propagate" ||
             args[0] == "set_dynamic_arbiter_subtype" ||
             args[0] == "set_dynamic_arbiter_mode" ||
             args[0] == "set_dynamic_arbiter_priority" ||
             args[0] == "set_dynamic_arbiter_probability" ||
             args[0] == "reset_dynamic_arbiter_status") {
      return handleCommandDynamic(args);
    }
    else if (args[0] == "set_addrmap") {
      if (args.size() == 4) {
        char *endp1 = NULL;
        char *endp2 = NULL;
        char *endp3 = NULL;
          
        unsigned int start_addr = ((unsigned int) strtoul(args[1].c_str(), &endp1, 16)) & 0xFFFFFFFF;
        unsigned int end_addr = ((unsigned int) strtoul(args[2].c_str(), &endp2, 16)) & 0xFFFFFFFF;
        unsigned int tgtId = (unsigned int) strtoul(args[3].c_str(), &endp3, 10);
          
        bool legal_input = true;
          
        if (*endp1 != '\0') {
          printf("[%s] Illeagal Data inputted %s in start_addr colum(set_addrmap)!\n", this->get_name(), args[1].c_str());
          legal_input = false;
        }
        if (*endp2 != '\0') {
          printf("[%s] Illeagal Data inputted %s in end_addr colum(set_addrmap)!\n", this->get_name(), args[2].c_str());
          legal_input = false;
        }
        if (*endp3 != '\0') {
          printf("[%s] Illeagal Data inputted %s in tgtID colum(set_addrmap)!\n", this->get_name(), args[3].c_str());
          legal_input = false;
        }
          
        if (legal_input == true) {
          Caddress_map0.addAddrRange (start_addr, end_addr, tgtId);
        }
      } else {
        printf("[%s] Data format Error! Data should be 4 colums!(set_addrmap)\n", this->get_name());
      }
    }
    else if (args[0] == "set_inigrp") {  // Resource group id
      if (args.size() == 3) {
        // call API to make array
        char *endp = NULL;
        char *endp1 = NULL;
        int ini_id = (int) strtoul(args[1].c_str(), &endp, 10);
        int ini_grp_id = (int) strtoul(args[2].c_str(), &endp1, 10);
          
        if (*endp != '\0') {
          printf("[%s] Error! Initiator ID must be integer number! \"%s\" is invalid!\n", this->get_name(), args[1].c_str());
          if (*endp != '\0') SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" );
        }
        if (*endp1 != '\0') {
          printf("[%s] Error! Initiator group ID must be integer number! \"%s\" is invalid!\n", this->get_name(), args[2].c_str());
          if (*endp != '\1') SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" );
        }
        if (ini_id >= 0 && ini_id < NR_OF_INITIATORS) {
          Shwy_GroupId0.setInitiatorGroupId(ini_id, ini_grp_id);
          get_resp_resource((unsigned int)ini_grp_id);  // allocate response resource if not allocated yet
        } else if (ini_id >= NR_OF_INITIATORS){
          printf("[%s] Error! Initiator ID must be less than the number of initiators! \"%s\" is invalid!\n", this->get_name(), args[1].c_str());
          if (ini_id >= NR_OF_INITIATORS) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" );
        } else {
          printf("[%s] Error! Initiator ID must be zero or more integer!  \"%s\" is invalid!\n", this->get_name(), args[1].c_str());
          if (ini_id < 0 || ini_id >= NR_OF_INITIATORS) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" ); 
        }
          
        if (ini_grp_id < 0) {
          printf("[%s] Error! Initiator BUS ID must be zero or more integer! \"%s\" in invalid!\n", this->get_name(), args[2].c_str());
          if (ini_grp_id < 0) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" ); 
        }
          
      } else {
        printf("[%s] Data format Error! Data must be 3 colums!(set_inigrp)\n", this->get_name());
      }
    }
    else if (args[0] == "set_tgtgrp") {
      if (args.size() == 3) {
        // call API to make array
        char *endp = NULL;
        char *endp1 = NULL;
        int tgt_id = (int) strtoul(args[1].c_str(), &endp, 10);
        int tgt_grp_id = (int) strtoul(args[2].c_str(), &endp1, 10);
          
        if (*endp != '\0') {
          printf("[%s] Error! Target ID must be integer number! \"%s\" is invalid!\n", this->get_name(), args[1].c_str());
          if (*endp != '\0') SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" ); 
        }
        if (*endp1 != '\0') {
          printf("[%s] Error! Target group ID must be integer number! \"%s\" is invalid!\n", this->get_name(), args[2].c_str());
          if (*endp != '\0') SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" ); 
        }
        if (tgt_id >= 0 && tgt_id < NR_OF_TARGETS) {
          Shwy_GroupId0.setTargetGroupId(tgt_id, tgt_grp_id);
          get_req_resource((unsigned int)tgt_grp_id);  // allocate request resource if not allocated yet
        } else if (tgt_id >= NR_OF_TARGETS) {
          printf("[%s] Error! Target ID must be less than the number of targets! \"%s\" is invalid!\n", this->get_name(), args[1].c_str());
          if (tgt_id >= NR_OF_TARGETS) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" ); 
        } else {
          printf("[%s] Error! Target ID must be zero or more integer! \"%s\" is invalid!\n", this->get_name(), args[1].c_str());
          if (tgt_id < 0) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" ); 
        } 
          
        if (tgt_grp_id < 0) {
          printf("[%s] Error! Target BUS ID must be zero or more integer! \"%s\" in invalid!\n", this->get_name(), args[2].c_str());
          if (tgt_grp_id < 0) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" ); 
        }
      } else {
        printf("[%s] Data format Error! Data must be 3 colums!(set_tgtgrp)\n", this->get_name());
      }
    }
    else if (args[0] == "help") {
      printf("%s has the following SHwy commands.\n",this->get_name());
      printf("\n");
      print_help();
    }
    else {
      msg << "Warning (" << (std::string)this->get_name() << ") Invalid command \"" << args[0] << "\"" << endl;
    }
    return msg.str();
  }
  
private:

  // handleCommand for dynamic arbitration
  std::string handleCommandDynamic(const std::vector<std::string> &args) {

    if (dynamic_arb == false) {
      printf("Warning (%s) Command \"%s\" is invalid for normal arbitration mode\n", this->get_name(), args[0].c_str());
    }

    if (args[0] == "set_maxpri") {
      if (args.size() == 2) {
        max_priority = get_value(args[1], args[0], 0, INT_MAX);
      } else {
        printf("[%s] Data format Error! Data should be 2 colums!(set_maxpri)\n", this->get_name());
      }
    }
    else if (args[0] == "set_inipri") {
      if (args.size() != 3 && args.size() != 5) {
        printf("[%s] Data format Error! Data should be 3 or 5 colums!(set_inipri)\n", this->get_name());
        return "";
      }
      int ini_id = get_value(args[1], args[0], 0, NR_OF_INITIATORS-1);
      int ini_pri = get_value(args[2], args[0], 0, max_priority);
      
      if (args.size() == 3) {
        if (Shwy_Initiator_Pri.set_priority(ini_id, ini_pri, sc_time(0, SC_NS), 8) == false) {
          printf("Warning (%s) set_inipri's ini_id \"%d\" is duplicate!. Overwrite previous one.\n", this->get_name(), ini_id);
        }
        
      } else if (args.size() == 5) {
        int intrtime_val = get_value(args[4], args[0], 0, INT_MAX);
        sc_time ini_intrtime(intrtime_val,SC_NS);
        int ini_lowpri = get_value(args[3], args[0], 0, max_priority);
        
        if (Shwy_Initiator_Pri.set_priority(ini_id, ini_pri, ini_intrtime, ini_lowpri) == false) {
          printf("Warinig (%s) set_inipri's ini_id \"%d\" is duplicate!. Overwrite previous one.\n", this->get_name(), ini_id);
        }
      } 
    } else if (args[0] == "set_wait_time") {
      int ini_id   = get_value(args[1], args[0], 0, INT_MAX);
      int time_val = get_value(args[2], args[0], 0, INT_MAX);
      sc_time time(time_val,SC_NS);

      bool count_mode = (bool)get_value(args[3], args[0], 0, 1);
      bool lck_mode   = (bool)get_value(args[4], args[0], 0, 1);

      if (Shwy_Initiator_Pri.set_wait(ini_id, time, count_mode, lck_mode) == false) {
        printf("Warinig (%s) set_wait_time's ini_id \"%d\" is duplicate!. Overwrite previous one.\n", this->get_name(), ini_id);
      }
      dynamic_arb_mode = ARB_PRI_LOWER_HIGH;
    }
    else if (args[0] == "set_wtop_wait_time") {
      int ini_id   = get_value(args[1], args[0], 0, INT_MAX);

      std::vector<sc_time> t_list;
      for(unsigned int i=2; i<args.size(); i++) {
        int time_val = get_value(args[i], args[0], 0, INT_MAX);
        t_list.push_back( sc_time(time_val, SC_NS) );
      }

      if (Shwy_Initiator_Pri.set_wtop_wait(ini_id, t_list) == false) {
        printf("Warinig (%s) set_wtop_wait_time's ini_id \"%d\" is duplicate!. Overwrite previous one.\n", this->get_name(), ini_id);
      }
    }
    else if (args[0] == "set_wtop_opt_level") {
      m_wtop_opt_level = get_value(args[1], args[0], 0, INT_MAX);
    }
    else if (args[0] == "set_bank_bit") {
      if (args.size() != 3) {
        printf("[%s] Data format Error! Data should be 3 colums!(set_bank_bit)\n", this->get_name());
        return "";
      }
      m_bank_bit_num = get_value(args[1], args[0], 0, INT_MAX);
      m_bank_bit_loc = get_value(args[2], args[0], 0, INT_MAX);
    }
    else if (args[0] == "arb_level_propagate") {
      m_level_propagate = true;
    }
    else if (args[0] == "set_dynamic_arbiter_subtype") {
      if (args.size() == 2) {
        if (args[1] == "default_arb") {
          Shwy_Initiator_Pri.set_dynamic_arbiter_subtype(DEFAULT_ARB);
        }
        else if (args[1] == "fair_arb") {
          Shwy_Initiator_Pri.set_dynamic_arbiter_subtype(FAIR_ARB);
        }
        else if (args[1] == "prob_arb") {
          Shwy_Initiator_Pri.set_dynamic_arbiter_subtype(PROB_ARB);
        }
        else {
          printf("[%s] %s is illeagal dynamic arbitration type! (%s)\n", this->get_name(), args[1].c_str(), args[0].c_str());
          return "";
        }
      }
      else {
        printf("[%s] Data format Error! Data should be 2 colums! (%s)\n", this->get_name(), args[0].c_str());
        return "";
      }
    }
    else if (args[0] == "set_dynamic_arbiter_mode") {
      if (args.size() == 2) {
        if (args[1] == "upper_high") {
          Shwy_Initiator_Pri.set_dynamic_arbiter_mode(ARB_PRI_UPER_HIGH);
        }
        else if (args[1] == "lower_high") {
          Shwy_Initiator_Pri.set_dynamic_arbiter_mode(ARB_PRI_LOWER_HIGH);
        }
        else {
          printf("[%s] %s is illeagal dynamic priority mode! (%s)\n", this->get_name(), args[1].c_str(), args[0].c_str());
          return "";
        }
      }
      else {
        printf("[%s] Data format Error! Data should be 2 colums! (%s)\n", this->get_name(), args[0].c_str());
        return "";
      }
    }
    else if (args[0] == "set_dynamic_arbiter_priority") {
      if (args.size() == 3) {
        int id = get_value(args[1], args[0], 0, NR_OF_INITIATORS - 1);
        int priority = get_value(args[2], args[0], 0, INT_MAX);
        if ((id >= 0) && (id < NR_OF_INITIATORS) && (priority >= 0)) {
          Shwy_Initiator_Pri.set_dynamic_arbiter_priority(id, priority);
        }
        else {
          printf("[%s] Arguments are contain illeagal value! (%s)\n", this->get_name(), args[0].c_str());
          return "";
        }
      }
      else {
        printf("[%s] Data format Error! Data should be 3 colums! (%s)\n", this->get_name(), args[0].c_str());
        return "";
      }
    }
    else if (args[0] == "set_dynamic_arbiter_probability") {
      if (args.size() == 4) {
        int id = get_value(args[1], args[0], 0, NR_OF_INITIATORS - 1);
        unsigned int prob_num = (unsigned int) get_value(args[2], args[0], 1, INT_MAX);
        unsigned int prob_denom = (unsigned int) get_value(args[3], args[0], 1, INT_MAX);
        if ((id >= 0) && (id < NR_OF_INITIATORS) && (prob_num >= 1) && (prob_denom >= 1) && (prob_num <= prob_denom)) {
          Shwy_Initiator_Pri.set_dynamic_arbiter_probability(id, prob_num, prob_denom);
        }
        else {
          printf("[%s] Arguments are contain illeagal value! (%s)\n", this->get_name(), args[0].c_str());
          return "";
        }
      }
      else {
        printf("[%s] Data format Error! Data should be 4 colums! (%s)\n", this->get_name(), args[0].c_str());
        return "";
      }
    }
    else if (args[0] == "reset_dynamic_arbiter_status") {
      if (args.size() == 1) {
        for (unsigned int i = 0; i < Response_Thread_List.size(); i++){
          Request_Thread_List[i]->reset_dynamic_arbiter_status();
        }
      }
      else {
        printf("[%s] Data format Error! Data should be 1 colums! (%s)\n", this->get_name(), args[0].c_str());
        return "";
      }
    }


    return "";
  }

  int get_value(const std::string & str, const std::string & command, int minVal, int maxVal) {
    char *endp = NULL;
    int val = (int) strtoul(str.c_str(), &endp, 0);

    if( *endp != '\0'  || val < minVal || val > maxVal ) {
      printf("Error (%s) Value \"%s\" in command \"%s\" is invalid.\n", this->get_name(), str.c_str(), command.c_str());
      SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" );
    }

    return val;
  }

  sc_time_unit get_time_unit(const std::string &str, const std::string &command)
  {
    sc_time_unit time_unit = SC_FS;

    if ((str == "sec") || (str == "SEC")) {
      time_unit = SC_SEC;
    }
    else if ((str == "ms") || (str == "MS")) {
      time_unit = SC_MS;
    }
    else if ((str == "us") || (str == "US")) {
      time_unit = SC_US;
    }
    else if ((str == "ns") || (str == "NS")) {
      time_unit = SC_NS;
    }
    else if ((str == "ps") || (str == "PS")) {
      time_unit = SC_PS;
    }
    else {
      printf("Error (%s) Value \"%s\" in command \"%s\" is invalid.\n", this->get_name(), str.c_str(), command.c_str());
      SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" );
    }

    return time_unit;
  }

  void print_help()
  {
    printf("    Command                                      Description\n");
    printf("    -----------------------------------------------------------------------------------------\n");
    printf("    set_addrmap <start_addr> <end_addr> <tgtID>  User sets address map to SHwy module.\n");
    printf("                                                 start_addr is set start address Ex. 00001000\n");
    printf("                                                 end_addr is set end address Ex. 00001FFF\n");
    printf("                                                 tgtID is set port number which target is\n"); 
    printf("                                                 connected Ex. 0\n");
    printf("\n");
    printf("    set_arb <BUS ID> <Req/Resp> <arb.tree>       User sets arbitor tree to SHwy module.\n");
    printf("                                                 BUS ID is used to identify SHwy Resource Ex. 0\n");
    printf("                                                 Req is set for id as Request Arbitration.\n");
    printf("                                                 Resp is set for id as Response Arbitration.\n");
    printf("                                                 arb.tree is set for Arbitration specification.\n");
    printf("                                                 Ex. (0/1/2)/(3-4-5-6)/(7/8/9)\n");
    printf("\n");
    printf("    set_inigrp <iniID> <BUS ID>                  User sets initiator group ID to initiator ID\n");
    printf("                                                 The paremeter \"ini ID\" is port number which is\n");
    printf("                                                 connected initiator.\n");
    printf("                                                 Requests are arbitrated in this group.\n");
    printf("\n");
    printf("    set_tgtgrp <tgtID> <BUS ID>                  User sets target group ID to target ID\n");
    printf("                                                 The parameter \"tgt ID\" is port number which is\n");
    printf("                                                 connected target.\n");
    printf("                                                 Responses are arbitrated in this group.\n");
    printf("\n");
  }

  void initiatorBTransport(int initiator_id, transaction_type& trans, sc_core::sc_time& t)
  {
    if (default_bus_property_is_set == false) {
      set_default_bus_property();
      default_bus_property_is_set = true;
    }

    unsigned int portId = Caddress_map0.getModuleID ((unsigned int)trans.get_address());

    if (portId == ERROR_MODULE_ID) {
      printf ("[%s] Error: In [initiatorBTransport], no module covers the address 0x%08X\n", this->name(), (unsigned int)trans.get_address());
      trans.set_response_status(tlm::TLM_ADDRESS_ERROR_RESPONSE);
      sc_stop();
      return;
    }

    // Set Profile Data
    m_prof->SetProf(trans, (unsigned int)initiator_id, (unsigned int)portId);
      
    initiator_socket_type* decodeSocket = &initiator_socket[portId];
    (*decodeSocket)->b_transport(trans, t);
  }
  
  sync_enum_type initiatorNBTransport(int initiator_id, 
                                      transaction_type& trans,
                                      phase_type& phase,
                                      sc_core::sc_time& t)
  {
    if (default_bus_property_is_set == false) {
      set_default_bus_property();
      default_bus_property_is_set = true;
    }

    int tgtId = (int)Caddress_map0.getModuleID((unsigned int)trans.get_address());

    if (tgtId == (int)ERROR_MODULE_ID) {
      printf ("[%s] Error: In [initiatorNBTransport], no module covers the address 0x%08X\n", this->name(), (unsigned int)trans.get_address());
      trans.set_response_status(tlm::TLM_ADDRESS_ERROR_RESPONSE);
      sc_stop();
      return tlm::TLM_ACCEPTED;
    }

    if (phase == tlm::BEGIN_REQ) {

      int tgt_grp_id = Shwy_GroupId0.getTargetGroupId(tgtId);

      // Add array ini_id -> tgt_id/tgt_grp_id for grant
      ResInfo[initiator_id].setInfo(tgtId, &trans);

      trans.acquire();
      // for profile
      sc_time tran_start_time = sc_time_stamp();
      // printf("----- Req Start to TargetId[%d] Time = %d\n", tgtId, tran_start_time);

      // Set Profile Data
      m_prof->SetProf(trans, (unsigned int)initiator_id, (unsigned int)tgtId);
      
      addPendingTransaction(trans, initiator_id, tgtId, 0, tran_start_time);

      // Shwy resource
      Request_Thread_List[tgt_grp_id]->notify_RequestThread(trans, t);
        
    } else if (phase == tlm::END_RESP) {
      int iniId = getIniIdFromPendingTransactions(trans);
      int ini_grp_id = Shwy_GroupId0.getInitiatorGroupId(iniId);
        
      Response_Thread_List[ini_grp_id]->notify_EndResponseEvent(t);
      return tlm::TLM_COMPLETED;
        
    } else {
      std::cout << "ERROR: '" << name()
                << "': Illegal phase received from initiator." << std::endl;
      if (!false) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "Illegal phase received from initiator!" );
    }
      
    return tlm::TLM_ACCEPTED;
  }
  
  sync_enum_type targetNBTransport(int portId,
                                   transaction_type& trans,
                                   phase_type& phase,
                                   sc_core::sc_time& t)
  {
    int iniId      = getIniIdFromPendingTransactions(trans);
    int ini_grp_id = Shwy_GroupId0.getInitiatorGroupId(iniId);
    int tgtId      = getTgtIdFromPendingTransactions(trans);
    int tgt_grp_id = Shwy_GroupId0.getTargetGroupId(tgtId);
      
    if (phase != tlm::END_REQ && phase != tlm::BEGIN_RESP) {
      std::cout << "ERROR: '" << name()
                << "': Illegal phase received from target." << std::endl;
      if (!false) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" ); 
    }
      
    // call Response Thread for resource
      
    Request_Thread_List[tgt_grp_id]->notify_EndRequestEvent(trans, t);
    if (phase == tlm::BEGIN_RESP) {
      Response_Thread_List[ini_grp_id]->notify_ResponseThread(trans, t);
    }
      
    return tlm::TLM_ACCEPTED;
  }
  
  unsigned int transportDebug(int initiator_id, transaction_type& trans)
  {
    unsigned int portId = Caddress_map0.getModuleID((unsigned int)trans.get_address());
      
    if (portId != ERROR_MODULE_ID) {
      initiator_socket_type* decodeSocket = &initiator_socket[portId];
      trans.set_address(trans.get_address());
    
      return (*decodeSocket)->transport_dbg(trans);
        
    } else {
      trans.set_response_status(tlm::TLM_ADDRESS_ERROR_RESPONSE);
      return trans.get_data_length();
    }
  }
  
  bool getDMIPointer(int initiator_id,
                     transaction_type& trans,
                     tlm::tlm_dmi&  dmi_data)
  {
    unsigned int address = (unsigned int)trans.get_address();

    int portId = (int)Caddress_map0.getModuleID(address);

    bool result = false;
    if (portId != (int)ERROR_MODULE_ID) {
      initiator_socket_type* decodeSocket = &Shwy::initiator_socket[portId];
      trans.set_address(address);
        
      result = (*decodeSocket)->get_direct_mem_ptr(trans, dmi_data);
        
      if (result) {
        assert(dmi_data.get_start_address() <= address);
        assert(dmi_data.get_end_address() >= address);
      }
    } else {
      trans.set_response_status(tlm::TLM_ADDRESS_ERROR_RESPONSE);
    }
    return result;
  }
  
  void invalidateDMIPointers(int portId, sc_dt::uint64 start_range, sc_dt::uint64 end_range)
  {
    for (unsigned int i = 0; i < NR_OF_INITIATORS; ++i) {
      (target_socket[i])->invalidate_direct_mem_ptr((unsigned int)start_range, (unsigned int)end_range);
    }
  }
    
private:
  void addPendingTransaction(transaction_type& trans,
                             int from,
                             int to,
                             int BEGIN_RESP_FLAG,
                             sc_time ReqFromIniTime)
  {
    const ConnectionInfo info = { from, to, BEGIN_RESP_FLAG, ReqFromIniTime };

    if (mPendingTransactions.find(&trans) != mPendingTransactions.end()) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" ); 

    mPendingTransactions[&trans] = info;
  }

  void set_default_bus_property()
  {
    // This API will be called at once when user don't set bus property by handleCommand. 

    // make resource
    set_request_resource();
    set_response_resource();
  }
  
  void set_request_resource()
  {
    unsigned int resource_num = Request_Thread_List.size();
      
    // set param & error check
    for (unsigned int i=0; i<resource_num; i++) {
      if(Request_Thread_List[i] != NULL) {
        Request_Thread_List[i]->set_max_pri(max_priority);
      }
    }
      
    // set normal arbitration
    if (dynamic_arb == 0) {
      for (unsigned int i=0; i<resource_num; i++) {
        std::string arb_exp = Request_Arb_Info.get_arbitration((int)i);
        if( !arb_exp.empty() ) {
          Request_Thread_List[i]->set_req_arb(arb_exp);
        }
        else {
          // set fixed(default) arbitration
          Request_Thread_List[i]->set_req_arb_by_number(NR_OF_INITIATORS);
        } 
      }
    }
    // set dynamic arbitration
    else if (dynamic_arb == 1) {
      dynamic_arbiter_subtype arb_subtype = Shwy_Initiator_Pri.get_dynamic_arbiter_subtype();
      if (arb_subtype == DEFAULT_ARB) {
        for (unsigned int i = 0; i < resource_num; i++) {
          Request_Thread_List[i]->set_req_arb_dynamic(&Shwy_Initiator_Pri, dynamic_arb_mode);
        }
      }
      else if ((arb_subtype == FAIR_ARB) || (arb_subtype == PROB_ARB)) {
        for (unsigned int i = 0; i < resource_num; i++) {
          Request_Thread_List[i]->set_dynamic_arbiter(&Shwy_Initiator_Pri);
        }
      }
      else {
        printf("ERROR : Shwy::set_request_resource() : dynamic arbitration type is invalid.\n");
      }
    }
  }

  void set_response_resource()
  {
    unsigned int resource_num = Response_Thread_List.size();
      
    // set normal arbitration
    for (unsigned int i=0; i<resource_num; i++) {
      std::string arb_exp = Response_Arb_Info.get_arbitration((int)i);
      if( !arb_exp.empty() ) {
        Response_Thread_List[i]->set_resp_arb(arb_exp);
      }
      else {
        // set fixed(default) arbitration
        Response_Thread_List[i]->set_resp_arb_by_number(NR_OF_TARGETS);
      } 
    }
  }

  ReqResType * get_req_resource(unsigned int id)
  {
    if(Request_Thread_List.size() < id+1) {
      Request_Thread_List.resize(id+1, NULL);
    }
    for(unsigned int i=0; i<Request_Thread_List.size(); i++) {
      if(Request_Thread_List[i] == NULL) {
        std::ostringstream buf;
        buf << "SHwy_Request_" << i;
        Request_Thread_List[i] = new ReqResType(buf.str().c_str(), this);
        if(Request_Thread_List[i] == NULL) {
          std::cout << "ERROR: '" << name() << "': Memory allocation error" << std::endl;
        }
      }
    }
    return Request_Thread_List[id];
  }

  RespResType * get_resp_resource(unsigned int id)
  {
    if(Response_Thread_List.size() < id+1) {
      Response_Thread_List.resize(id+1, NULL);
    }
    for(unsigned int i=0; i<Response_Thread_List.size(); i++) {
      if(Response_Thread_List[i] == NULL) {
        std::ostringstream buf;
        buf << "SHwy_Response_" << i;
        Response_Thread_List[i] = new RespResType(buf.str().c_str(), this);
        if(Response_Thread_List[i] == NULL) {
          std::cout << "ERROR: '" << name() << "': Memory allocation error" << std::endl;
        }
      }
    }
    return Response_Thread_List[id];
  }

public:
  bool get_permission(int ini_id)
  {
    int tgt_id = ResInfo[ini_id].getTgtId();
    if( ResInfo[ini_id].isRead() == true ) {
      return get_read_permission_stat(tgt_id);
    }
    else {
      return get_write_permission_stat(tgt_id);
    }
  }
  
  void setBeginRespFlag(transaction_type& trans)
  {
    PendingTransactionsIterator it = mPendingTransactions.find(&trans);
    if (it == mPendingTransactions.end()) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" ); 

    it->second.BEGIN_RESP_FLAG = 1;
  }
  
  int getBeginRespFlag(transaction_type& trans)
  {
    PendingTransactionsIterator it = mPendingTransactions.find(&trans);
    if (it == mPendingTransactions.end()) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" ); 

    return it->second.BEGIN_RESP_FLAG;
  }
  
  int getIniIdFromPendingTransactions(transaction_type& trans)
  {
    PendingTransactionsIterator it = mPendingTransactions.find(&trans);
    if (it == mPendingTransactions.end()) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" ); 

    return it->second.from;
  }
  
  int getTgtIdFromPendingTransactions(transaction_type& trans)
  {
    PendingTransactionsIterator it = mPendingTransactions.find(&trans);
    if (it == mPendingTransactions.end()) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" ); 

    return it->second.to;
  }  
  
  void setTgtIdToPendingTransactions(transaction_type& trans, int tgtId)
  {
    PendingTransactionsIterator it = mPendingTransactions.find(&trans);
    if (it == mPendingTransactions.end()) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" ); 
      
    it->second.to = tgtId;
  }
  
  void setReqToTgtTime(transaction_type& trans, sc_time& settime)
  {
    PendingTransactionsIterator it = mPendingTransactions.find(&trans);
    if (it == mPendingTransactions.end()) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" ); 

    // Profile
    sc_time wait_time = settime - it->second.ReqFromIniTime;
    m_prof->SetWait((unsigned int)it->second.from, (unsigned int)it->second.to, wait_time);
  }

  void erasePendingTransactions(transaction_type& trans)
  {
    PendingTransactionsIterator it = mPendingTransactions.find(&trans);
    mPendingTransactions.erase(it);
  }

  /*  DUMP PROFILE INFORMATION  */
  bool DumpProfile(FILE *p_file = stdout, sc_time_unit timescale = SC_NS)
  {
    if (p_file == NULL) return false;

    fprintf(p_file, "\n---------- %s Profile ----------\n", get_name());

    for (unsigned int i=0; i<Request_Thread_List.size(); i++) {
      Request_Thread_List[i]->DumpProfile(p_file, timescale);
    }
    for (unsigned int i=0; i<Response_Thread_List.size(); i++) {
      Response_Thread_List[i]->DumpProfile(p_file, timescale);
    }

    m_prof->DumpProfile(p_file, timescale);
    return true;
  }

  /*  CLEAR PROFILE HISTORY  */
  void ClearProfile(void)
  {
    delete m_prof;
    m_prof = new Shwy_Profile<NR_OF_INITIATORS, NR_OF_TARGETS, BUS_WIDTH>(&Shwy_GroupId0);
  }
  
private:
  typedef std::map<transaction_type*, ConnectionInfo> PendingTransactions;
  typedef typename PendingTransactions::iterator PendingTransactionsIterator;
  typedef typename PendingTransactions::const_iterator PendingTransactionsConstIterator;

  PendingTransactions mPendingTransactions;
  int max_priority;

  // get instance name.
  const char *get_name()
  {
    return this->name();
  }
};

#endif
