// $Id: address_map.h V20110427_forRESLX_SystemTest $
// ----------------------------------------------------------------------
// Status    :
//     Source: /shsv/sld/ipp/project/200907_prj_verification_environment_phase2/Output/cvsroot/090521_ver_env/ver_env/src/address_map.h,v $
//     Revision: 1.2 $
//     Date: 2009/08/31 07:32:15 $
//     Author: sontran $
//     Locker:  $
//     State: Exp $
//     Id: address_map.h,v 1.2 2009/08/31 07:32:15 sontran Exp $
// ----------------------------------------------------------------------
//   (C) Copyright 2009   RVC (Renesas Design Vietnam Co., Ltd.)
//   All rights reserved. RVC Confidential Proprietary
//   (C) Copyright 2009   RENESAS Technology Corp.  All rights reserved.
// ----------------------------------------------------------------------
//    Log: address_map.h,v $
//    Revision 1.2  2009/08/31 07:32:15  sontran
//    - Change the way to check overlapped range
//    - Move AddrRange into private section
//
//    Revision 1.1  2009/08/20 02:20:37  tuantu
//    Create new
//
// ----------------------------------------------------------------------

#ifndef __ADDRESS_MAP_H__
#define __ADDRESS_MAP_H__

#include <vector>

#define ERROR_MODULE_ID 0xFFFFFFFF

// Address map manages an array of address ranges.
class Caddress_map
{
public:
    // Constructor.
    Caddress_map ()
    {
        addr_map.clear();
    }

    // Destructor.
    ~Caddress_map ()
    {
        addr_map.clear();
    }

    // Get id of module that covers the addr.
    unsigned int getModuleID (unsigned int addr) {
        // Looking for module id.
        for (unsigned int index = 0; index < addr_map.size(); index++) {
            if ((addr_map[index].start_range <= addr) && (addr <= addr_map[index].end_range)) {
                // return module id if found.
                return addr_map[index].module_id;
            }
        }

        // Return error if not found.
        return ERROR_MODULE_ID;
    }

    // Add an address range into map. Return true if success (no overlap). Otherwise, return false.
    bool addAddrRange (unsigned int start_range, unsigned int end_range, unsigned int module_id) {
        // Validate input range
        if (start_range > end_range) {
            #ifndef __ADDRESS_MAP_ERR_MSG_DISABLE__
            printf ("[Caddress_map] Error: Input start range is bigger than input end range!\n");
            printf ("[Caddress_map] Error: Input address range information: start = %X, end = %X, module ID = %d!\n", start_range, end_range, module_id);
            #endif
            return false;
        }

        // Check overlapped range.
        for (unsigned int index = 0; index < addr_map.size(); index++) {
            if ((addr_map[index].start_range <= end_range) && (start_range <= addr_map[index].end_range)) {
                #ifndef __ADDRESS_MAP_ERR_MSG_DISABLE__
                printf ("[Caddress_map] Error: Overlapped input address range!\n");
                printf ("[Caddress_map] Error: Address range information: start = %X, end = %X, module ID = %d!\n", start_range, end_range, module_id);
                #endif
                return false;
            }
        }

        // Construct new range.
        AddrRange new_range (start_range, end_range, module_id);
        // Add new range to address map.
        addr_map.push_back (new_range);

        return true;
    }

private:
    // Address range structure.
    struct AddrRange {
        unsigned int start_range;   // start address.
        unsigned int end_range;     // end address.
        unsigned int module_id;     // module ID.

        // Constructor
        AddrRange (unsigned int start_range, unsigned int end_range, unsigned int module_id) {
            this->start_range = start_range;
            this->end_range = end_range;
            this->module_id = module_id;
        }
    };

    // Store the array of address range.
    std::vector <AddrRange> addr_map;
};
#endif
