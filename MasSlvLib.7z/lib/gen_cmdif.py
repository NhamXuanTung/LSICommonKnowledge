#!/usr/bin/env python
 # -----------------------------------------------------------------------------
 #
 #  $Id: gen_cmdif.py v2015_02_12 $
 #
 # Copyright(c) 2010-2013 Renesas Electronics Corporation
 # Copyright(c) 2013 Renesas Design Vietnam Co., Ltd.
 # RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 # This program must be used solely for the purpose for which
 # it was furnished by Renesas Electronics Corporation. No part of this
 # program may be reproduced or disclosed to others, in any
 # form, without the prior written permission of Renesas Electronics
 # Corporation.
 #
 # -----------------------------------------------------------------------------
__author__ = "Son Tran"
__version__ = "4.0"

import sys
import os
import re
import code
from optparse import OptionParser
import modelinfo_parser

# Keep command argument information
class CCommandArg:
    def __init__(self):
        self.mName = ""            # variable name
        self.mLevel = ""           # option or must
        self.mType = ""            # variable type
        self.mDefaultList = []     # default value
        self.mAltRule = ""         # | or / or null
        self.mAltList = []         # alternative list
        self.mOther = ""           # temporal area


# Keep command information
class CCommand:
    def __init__(self):
        self.mType = ""            # CMD_RW or CMD_ACTION
        self.mName = ""            # command name
        self.mUsage = ""           # usage of command
        self.mRetType = ""         # return type (only CMD_ACTION)
        self.mAltList = []         # alternative list
        self.mArg = CCommandArg()  # argument information


class CGenCommandIf:
    #
    # constructor : just initialize data member
    #
    def __init__(self):
        self.mPythonIfEnable = False
        self.mModuleName = ""
        self.mCmdID = ""
        self.mBaseClassList = []
        self.mCmdList = []
        self.mPortRef = []
        self.mPortList = []
        self.mDefinedCtl = []
        self.mNoDumpApiList = [
            "%%HWBreak%%"]
        self.mInFileContents = ""
        self.mReserveCmdList = {
            "help":[],
            "CommandCB":[],
            "MessageLevel":["input_arg"],
            "EnableInsertInput":["input_arg"],
#            "DumpRegisterRW",
            "DumpProfile":[],
            "ClearProfile":[],
            "AssertReset":["input_arg"],
            "EnableDumpResult":["input_arg"],
            "HWBreak":[]}
        self.mReplacedKeywordList = [
            "%%VERSION%%",
            "%%GEN_CMDIF_PY_ID%%",
            "%%MODULE%%",
            "%%CMD_ID%%",
            "%%REMOVE_1ST_ARG%%",
            "%%HANDLE_COMMAND_NAME%%",
            "%%INPUT_FILE_CONTENTS%%",
            "%%CALL_ONLY_PARENT%%",
            "%%CALL_PARENT_TOO%%",
            "%%USER_CMD_USAGE%%",
            "%%CMD_RW%%",
            "%%INIT_CMD_DB%%",
            "%%INIT_PORT_ACCESS%%",
            "%%USER_CMD_DEC%%",
            "%%REGIF_HANDLE_COMMAND%%",
            "%%PORT_HANDLE_COMMAND%%",
            "%%PORT_ACCESS%%",
            "%%PORT_METHOD_DECLARE%%",
            "%%WRITE_PORT_API%%",
            "%%SET_COMMAND_ID%%",
            "%%COPYRIGHT%%",
            "%%CLASS_NAME%%",
            "%%PY_FUNCTION_DECLARATION%%",
            "%%PY_FUNCTION_REGISTRATION%%",
            "%%PY_FUNCTION_IMPLEMENTATION%%"]
        self.mNativeTypeList = [
            "char", "unsigned char",
            "short", "unsigned short",
            "int", "unsigned int",
            "bool", "double",
            "uint64_t", "sc_dt::uint64"]
        self.mPositiveTypeList = [
            "unsigned char",
            "unsigned short",
            "unsigned int",
            "uint64_t",
            "sc_dt::uint64"]
        indent_base = " "*4
        self.indent = ["", indent_base, indent_base*2, indent_base*3, indent_base*4, indent_base*5]

    #
    # Load the input file and generate the output file
    #
    def DecodeFile(self, file):
        try:
            nline = 0
            fp = open(file)
            for cur_line in fp.readlines():
                nline = nline + 1
                # store input file contents which are dumped
                # at the beginning of generated file
                self.mInFileContents = self.mInFileContents + "//" + cur_line

                # ignore the contents after # keyword and skip NULL line
                (cur_line, keyword, comment) = cur_line.partition("#")
                cur_line = cur_line.strip()  # remove space
                if cur_line == "":
                    continue

                # divide a line into a keyword and an argument
                (ctl_key, keyword, args) = cur_line.partition(" ")

                self.DecodeLine(ctl_key, args, file, nline)
            fp.close()

            # if %MODULE has already specified, dump that information
            # NOTE: even if %MODULE is not specified at all, not dump error
            #       message because input file is shared with other scripts.
            if self.mModuleName != "":
                self.GenerateOutputFile()

        except IOError as strerror:
            sys.stderr.write("\n    *** ERROR \"%s(%d)\" : %s\n\n"
                % (file, nline, strerror))
            sys.exit()

    #
    # Decode a control keyword and store that information to internal table
    #
    def DecodeLine(self, ctl_key, args, file, nline):
        arg_list = args.split()

        if ctl_key == "%MODULE":
            # if %MODULE has already specified at the below line,
            # generate that information in advance.
            if self.mModuleName != "":
                self.GenerateOutputFile()
                # initialize member variables just in case
                self.mModuleName = ""
                self.mBaseClassList = []
                self.mCmdList = []
                self.mDefinedCtl = []

            self.ArgCheck(ctl_key, arg_list, False, [], False, 1, -1)
            if arg_list[0].startswith("C"):
                sys.stderr.write("    INFO:Module name adjusted to omit redundant \"C\" prefix: %s\n" % (arg_list[0]))
                arg_list[0] = re.sub("^C", "", arg_list[0])
            self.mModuleName = arg_list[0]

        elif ctl_key == "%CMD_BASEID" or ctl_key == "%CMD_BASECLASS":
            self.ArgCheck(ctl_key, arg_list, True, [], True, -1, -1)
            self.mBaseClassList = arg_list

        elif ctl_key == "%CMD_ID":
            self.ArgCheck(ctl_key, arg_list, True, [], True, 1, 1)
            self.mCmdID = arg_list[0]

        elif ctl_key == "%CMD_NODUMP_API":
            self.ArgCheck(ctl_key, arg_list, True, [], True, 1, -1)

            # store specified name if it is same as reserved name
            for api_name in arg_list:
                if api_name in self.mReserveCmdList:
                    self.mNoDumpApiList.append("%%" + api_name + "%%")
                else:
                    raise IOError(api_name + " is not correct API name")
        elif ctl_key == "%CMD_RW":
            self.ArgCheck(ctl_key, [arg_list[0]], True, self.mReserveCmdList, \
            False, -1, -1)
            self.DecodeCMD(args, "CMD_RW")

        elif ctl_key == "%CMD_ACTION":
            self.ArgCheck(ctl_key, [arg_list[0]], True, self.mReserveCmdList, \
            False, -1, -1)
            self.DecodeCMD(args, "CMD_ACTION")

        elif ctl_key == "%PORT":
            self.ArgCheck(ctl_key, arg_list,  True, [], False, 4, 5)
            port = modelinfo_parser.GetPortInfo(os.path.basename(__file__), args.split(), nline, file, self.mPortRef, [], [])
            if port != None:
                # in -> 4, out -> 5
                if port.mPortType == "in" and len(arg_list) != 4:
                        raise IOError("input port definition should be 4 arguments")
                elif port.mPortType == "out" and len(arg_list) != 5:
                        raise IOError("output port definition should be 5 arguments")

                if port != "":
                    self.mPortRef.append(port.mPortName)
                    self.mPortList.append(port)
            else:
                raise IOError("Port definition error causes")

        elif ctl_key == "%CMD_HWBRK":
            if len(arg_list) > 0:
                raise IOError("%CMD_HWBRK does not have any argument")

            if "%%HWBreak%%" not in self.mNoDumpApiList:
                raise IOError("%CMD_HWBRK has aleady specified")
            else:
                self.mNoDumpApiList.remove("%%HWBreak%%")
        #else:
        #    just ignore other control keywords

    #
    # Decode CMD_RW and CMD_ACTION control key line
    #
    def DecodeCMD(self, args, type):
        cmd = CCommand()
        cmd.mType = type
        cmd.mRetType = ""
        cmd.mAltList = []

        (args_wo_usage, keyword, usage) = args.lstrip().partition("@")
        cmd.mUsage = usage.lstrip()

        # check (1) include a usage
        if cmd.mUsage == "":
            raise IOError("There is no usage description")
        # check (2) command name and argument format
        (cmd.mName, space, arg_def) = args_wo_usage.partition(" ")

        # check (3) command name should be unique
        for entied_cmd in self.mCmdList:
            if cmd.mName == entied_cmd.mName:
                raise IOError("%s is entied yet" % (cmd.mName))

        cmd.mArg = []
        index = 0
        while index < len(arg_def):
            if arg_def[index] == " ":
                """
                do nothing
                """
            # must argument
            elif arg_def[index] == "<":
                s_p = index + 1
                e_p = self.FindBrace(arg_def, "<>", index + 1)
                if s_p == len(arg_def) or e_p == -1:
                    raise IOError("Argument format error : not found '>'")

                # previous argument should not be option
                if cmd.mArg != [] and cmd.mArg[-1].mLevel == "option":
                    raise IOError("Cannot specify must type argument after option type argument")

                arg = CCommandArg()
                arg.mLevel = "must"
                arg.mOther = arg_def[s_p:e_p]
                cmd.mArg.append(arg)
                index = e_p
            # option argument
            elif arg_def[index] == "[":
                # 1st argument should not be option
                if cmd.mType == "CMD_RW" and cmd.mArg == []:
                    raise IOError("1st argument should be must type argument")

                s_p = index + 1
                e_p = self.FindBrace(arg_def, "[]", index + 1)
                if s_p == len(arg_def) or e_p == -1:
                    raise IOError("Argument format error : not found ']'")
                arg = CCommandArg()
                arg.mLevel = "option"
                arg.mOther = arg_def[s_p:e_p]
                cmd.mArg.append(arg)
                index = e_p

            # return type
            elif arg_def[index] == ":":
                cmd.mRetType = arg_def[index + 1:].strip()
                cmd.mRetType = cmd.mRetType.replace(">", "")
                cmd.mRetType = cmd.mRetType.replace("]", "")

                if cmd.mRetType.find("enum") == 0:
                    if cmd.mRetType.find("{") == -1:
                        raise IOError("return type \"%s\" is invalid format" % (cmd.mRetType))
                    (cmd.mRetType, sep_key, other) = cmd.mRetType.partition("{")
                    cmd.mRetType = cmd.mRetType.strip()
                    other = other.replace("}", "").strip()
                    if other.find("/") == -1:
                        raise IOError("return type \"%s\" does not include separator /" % (cmd.mRetType))
                    cmd.mAltList = other.split("/")

                elif cmd.mRetType not in self.mNativeTypeList \
                    and cmd.mRetType not in ["string", "std::string", "sc_time", "void"] \
                    and cmd.mRetType.replace(" ", "") not in ["map<string,bool>", "std::map<std::string,bool>"]:
                    raise IOError("Return type \"%s\" is not supported" % (cmd.mRetType))

                break

            else:
                if cmd.mType == "CMD_RW" and cmd.mArg == []:
                    raise IOError("Needs an argument at least")
                else:
                    raise IOError("Argument is invalid")

            index = index + 1

        if cmd.mType == "CMD_ACTION" and cmd.mRetType == "":
            raise IOError("%CMD_ACTION's return type is not defined")

        # extract name, type, initial value and alternative
        for arg in cmd.mArg:
            def_val = ""

            if arg.mOther.strip().find(":") == -1:
                raise IOError("There is no argument's name or type definition")

            (arg.mName, sep_key, other) = arg.mOther.partition(":")
            # argument name always is needed
            if arg.mName.strip() == "":
                raise IOError("argument name is not specified")
            elif " " in arg.mName.strip():
                raise IOError("There are 2 or more than argument names")
            elif other.strip() == "":
                raise IOError("There is no argument's type definition")

            # check argument's naming rule
            name_rule = re.compile('^[a-zA-Z][a-zA-Z0-9_]*$')
            if name_rule.match(arg.mName) == None:
                raise IOError("Invalid argument name of \"" + arg.mName + "\"")

            if other.find("=") != -1:
                (arg.mType, sep_key, other) = other.partition("=")
                if other.find("=") != -1:
                    raise IOError("There are 2 or more than initial definition")

                # <name:type=init {alternative}>
                if other.find("{") != -1:
                    (def_val, sep_key, alternative) = other.partition("{")
                    alternative = alternative.replace("}", "").strip()
                    if alternative == "":
                        raise IOError("There is no factor in alternative list")
                # <name:type=init>
                else:
                    (def_val, sep_key, other) = other.partition(">")
                    alternative = ""
            else:
                def_val = ""
                # <name:type {alternative}>
                if other.find("{") != -1:
                    (arg.mType, sep_key, alternative) = other.partition("{")
                    alternative = alternative.replace("}", "").strip()
                    if alternative == "":
                        raise IOError("There is no factor in alternative list")

                # <name:type>
                else:
                    alternative = ""
                    arg.mType = other.strip()

            if cmd.mType == "CMD_RW" and def_val == "":
                raise IOError("%CMD_RW command needs initial value")
            elif cmd.mType == "CMD_ACTION":
                if arg.mLevel == "must" and def_val != "":
                    raise IOError("The default value of %CMD_ACTION's must argument not needed")
                elif arg.mLevel == "option" and def_val == "":
                    raise IOError("The default value of %CMD_ACTION's option argument needed")

            arg.mType = arg.mType.strip()
            if arg.mType not in self.mNativeTypeList \
                and arg.mType not in ["string", "std::string", "sc_time"] \
                and arg.mType.replace(" ", "") not in ["map<string,bool>", "std::map<std::string,bool>"] \
                and arg.mType.find("enum") != 0:
                raise IOError("Argument type \"%s\" is not supported" % (arg.mType))

            elif arg.mType == "enum":
                raise IOError("Argument type enum needs name")

            arg.mDefaultList = []
            arg.mAltList = []
            if alternative != "":
                if alternative.find("{") != -1:
                    raise IOError("There are 2 or more than factor lists ")

                if alternative[:-1].find("|") > 0 and alternative[:-1].find("/") > 0:
                    raise IOError("Cannot use both | and / at same time")

                if alternative[:-1].find("|") >= 0:
                    arg.mAltRule = "|"
                    for factor in alternative.split("|"):
                        if factor.strip() == "":
                            raise IOError("Specified factor is NULL")
                        arg.mAltList.append(factor.strip())
                    for factor in def_val.split("|"):
                        if factor.strip() == "":
                            raise IOError("Specified factor is NULL")
                        arg.mDefaultList.append(factor.strip())
                elif alternative[:-1].find("/") >= 0:
                    arg.mAltRule = "/"
                    for factor in alternative.split("/"):
                        if factor.strip() == "":
                            raise IOError("Specified factor is NULL")
                        arg.mAltList.append(factor.strip())
                    arg.mDefaultList.append(def_val.strip())
                else:  # just 1 alternative item
                    arg.mAltRule = "/"
                    arg.mAltList.append(alternative.strip())
                    arg.mDefaultList.append(def_val.strip())

                #FIXME: if arg.mAltList == []:
                #FIXME:     raise IOError("There is no factor in alternative list")
            else:
                arg.mAltRule = ""
                arg.mAltList = []
                arg.mDefaultList.append(def_val.strip())

        self.mCmdList.append(cmd)

    #
    # Argument stype check
    #
    def ArgCheck(self, ctl_key, arg_list, is_mod_defined_check,
                  reserved_key_list, is_defined_check, min_check, max_check):
        # check (1) %MODULE should be defined in advance
        if is_mod_defined_check and self.mModuleName == "":
            raise IOError("%MODULE should be defined in advance")

        # check (2) some arguments are required
        if len(arg_list) == 0:
            raise IOError(ctl_key + " should have argument")

        # check (3) argument's naming rule
        name_rule = re.compile('^[a-zA-Z][a-zA-Z0-9_]*$')
        if name_rule.match(arg_list[0]) == None:
            raise IOError("Invalid name of " + ctl_key + " :" + arg_list[0])

        # check (4) name overlapped
        registered_name = {}
        for name in arg_list:
            if name in registered_name:
                raise IOError("same name is defined :" + name)
            registered_name[name] = True

        # check (5) should differ from reserved keyword
        for name in arg_list:
            for reserved_key in reserved_key_list:
                if name == reserved_key:
                    raise IOError(name + " is reserved")

        # check (6) defined yet
        if is_defined_check:
            if ctl_key in self.mDefinedCtl:
                raise IOError(ctl_key + " is defined yet")
            else:
                self.mDefinedCtl.append(ctl_key)

        # check (7) the min number of argument
        if min_check > -1 and len(arg_list) < min_check:
            raise IOError(ctl_key + " needs %d arguments at least" % min_check)

        # check (8) the max number of argument
        if max_check > -1 and len(arg_list) > max_check:
            raise IOError(ctl_key + " needs %d arguments at most" % max_check)

    #
    # Generate the content of Python Function declaration
    #
    def PyFuncDeclaration(self):
        output_lines = "" 
        for cmd in self.mCmdList:
            param_name = cmd.mName
            output_lines += self.indent[1] + "static PyObject* " + param_name +"Py (PyObject* self, PyObject* args);\n"
        for cmd in self.mBaseClassList:
            param_name = cmd
            output_lines += self.indent[1] + "static PyObject* " + param_name +"Py (PyObject* self, PyObject* args);\n"
        for cmd in self.mReserveCmdList:
            if ((("%%" + cmd + "%%") not in self.mNoDumpApiList) and (cmd != "CommandCB")) or (cmd == "help"):
                param_name = cmd
                output_lines += self.indent[1] + "static PyObject* " + param_name +"Py (PyObject* self, PyObject* args);\n"
        return output_lines.rstrip("\n\r")

    #
    # Generate the content of Python Fucntion registration
    #
    def PyFuncRegistration(self):
        mod_name_upper = self.mModuleName.upper()
        output_lines = ""
        for cmd in self.mCmdList:
            param_name = cmd.mName
            output_lines += self.indent[2] + "{\"" + mod_name_upper + "_" + param_name + "\", " + param_name + "Py, METH_VARARGS, \"\"},\n"
        for cmd in self.mBaseClassList:
            param_name = cmd
            output_lines += self.indent[2] + "{\"" + mod_name_upper + "_" + param_name + "\", " + param_name + "Py, METH_VARARGS, \"\"},\n"
        for cmd in self.mReserveCmdList:
            if ((("%%" + cmd + "%%") not in self.mNoDumpApiList) and (cmd != "CommandCB")) or (cmd == "help"):
                param_name = cmd
                output_lines += self.indent[2] + "{\"" + mod_name_upper + "_" + param_name + "\", " + param_name + "Py, METH_VARARGS, \"\"},\n"
        return output_lines.rstrip("\n\r")
        
    #
    # Generate the content of Python Function implemenatation
    #
    def PyFuncImplementation(self):
        output_lines = ""
        # generate implementation of Py function
        for cmd in self.mCmdList:
            arg_list = []
            param_name = cmd.mName
            if (cmd.mType == "CMD_ACTION"):
                if len(cmd.mArg) > 0:
                    arg_list.append("input_arg")
            else :
                arg_list.append("input_arg")
            output_lines += self.GeneratePyFunction("", param_name, arg_list)
        for cmd in self.mBaseClassList:
            param_name = cmd
            output_lines += self.GeneratePyFunction(cmd, param_name,["input_arg"])
        for cmd in self.mReserveCmdList:
            if ((("%%" + cmd + "%%") not in self.mNoDumpApiList) and (cmd != "CommandCB")) or (cmd == "help"):
                param_name = cmd
                output_lines += self.GeneratePyFunction("", param_name, self.mReserveCmdList[cmd])
        return output_lines.rstrip("\n\r")

    #
    # Generate the content of PY function
    #
    def GeneratePyFunction(self, cmd_id, cmd_name, arg_list):
        cont_line = self.indent[1] + "PyObject* " + cmd_name + "Py(PyObject* self, PyObject* args)\n"
        cont_line += self.indent[1] + "{//{{{\n"
        cont_line += self.indent[2] + "sc_assert((self != NULL) && (args != NULL));\n"
        # generate content
        if len(arg_list) > 0:
            for arg in arg_list:
                cont_line += self.indent[2] + "char* " + arg + ";\n"
        cont_line += self.indent[2] + "char* token;\n"
        cont_line += self.indent[2] + "if (PyArg_ParseTuple(args, \""
        if len(arg_list) > 0:
            cont_line += "s"*(len(arg_list) + 1) + "\", &token"
            for arg in arg_list:
                cont_line += ", &" + arg 
            cont_line += ") == true) {\n"
        else :
            cont_line += "s\", &token) == true) {\n"
        cont_line += self.indent[3] + "ProcessCommand("
        # input cmd_id and cmd_name
        if (cmd_id != ""):
            cont_line += "\"" + cmd_name + "\", \"\""
        else:
            cont_line += "\"command\", \"" + cmd_name + "\""
        # input token and argument
        if len(arg_list) > 0:
            cont_line += ", token, input_arg"
        else:
            cont_line += ", token, NULL"
        cont_line += ");\n"
        cont_line += self.indent[2] + "} else {\n"
        cont_line += self.indent[3] + "printf (\"Wrong number of argurment for " + self.mModuleName.upper() + "_" + cmd_name + " command.\\n\");\n"
        cont_line += self.indent[2] + "}\n"
        cont_line += self.indent[2] + "return Py_BuildValue(\"\");\n"
        cont_line += self.indent[1] + "}//}}}\n\n"
        return cont_line

    #
    # Generate the output file
    #
    def GenerateOutputFile(self):
        # announce information message to user just in case
        if not self.mCmdList:
            sys.stderr.write("    INFO:User command of \"%s\" is not defined\n"
                % self.mModuleName)

        # replace string into specified information
        install_dir = os.path.abspath(os.path.dirname(__file__))
        output_lines = []
        revision = re.compile('^//  [ ]*[$]Id: .+[$][ ]*$')
        # Generate Command IF file
        fp_skelton = open(install_dir + "/handleCommand.skl", "r")
        for cur_line in fp_skelton.readlines():
            if cur_line.find("%%") != -1:
                # replace %% keyword into meaningful string
                for rep_key in self.mReplacedKeywordList:
                    cur_line = cur_line.replace(rep_key, self.ReplaceStr(rep_key))

                # not active for no-dumped API
                matched = False
                for no_dump_api in self.mNoDumpApiList:
                    #if cur_line.find(no_dump_api) == 0:
                    if cur_line.find(no_dump_api) != -1:
                        cur_line = cur_line.replace(no_dump_api, "0")
                        matched = True
                        break
                # active
                if not matched and cur_line.find("%%") != -1:
                    for no_dump_api in self.mReserveCmdList:
                        cur_line = cur_line.replace("%%" + no_dump_api + "%%", "1")

            # replace $Id: gen_cmdif.py v2015_02_12 $
            elif revision.match(cur_line) != None:
                cur_line = cur_line[0:cur_line.find("$", cur_line.find("$Id: gen_cmdif.py v2015_02_12 $

            output_lines.append(cur_line)
        fp_skelton.close()

        # generate output file
        ofile_name = self.mModuleName + "_cmdif.h"
        if os.path.exists(ofile_name):
            print("Do you overwrite existing file " + ofile_name + " ? (Y/N)")
            overwrite = code.InteractiveConsole.raw_input(self, "")
            if ((overwrite != "Y") and (overwrite != "y")):
                raise IOError("Suspended to generate a file by a user")
        fp_handle_def = open(ofile_name, "w")
        fp_handle_def.writelines(output_lines)
        fp_handle_def.close()

        if self.mPythonIfEnable:
            # Generate Python IF header file
            fp_skelton = open(install_dir + "/py_model.h.skl", "r")
            py_header_name = "PY_" + self.mModuleName.upper() + ".h"
            py_header_lines = []
            for cur_line in fp_skelton.readlines():
                if cur_line.find("%%") != -1:
                    # replace %% keyword into meaningful string
                    for rep_key in self.mReplacedKeywordList:
                        cur_line = cur_line.replace(rep_key, self.ReplaceStr(rep_key))
                py_header_lines.append(cur_line)
            fp_skelton.close()
            if os.path.exists(py_header_name):
                print("Do you overwrite existing file " + py_header_name + " ? (Y/N)")
                overwrite = code.InteractiveConsole.raw_input(self, "")
                if ((overwrite != "Y") and (overwrite != "y")):
                    raise IOError("Suspended to generate a file by a user")
            fp_handle_def = open(py_header_name, "w")
            fp_handle_def.writelines(py_header_lines)
            fp_handle_def.close()

            # Generate Python IF implemetation file
            fp_skelton = open(install_dir + "/py_model.cpp.skl", "r")
            py_impl_name = "PY_" + self.mModuleName.upper() + ".cpp"
            py_impl_lines = []
            for cur_line in fp_skelton.readlines():
                if cur_line.find("%%") != -1:
                    # replace %% keyword into meaningful string
                    for rep_key in self.mReplacedKeywordList:
                        cur_line = cur_line.replace(rep_key, self.ReplaceStr(rep_key))
                py_impl_lines.append(cur_line)
            fp_skelton.close()
            if os.path.exists(py_impl_name):
                print("Do you overwrite existing file " + py_impl_name + " ? (Y/N)")
                overwrite = code.InteractiveConsole.raw_input(self, "")
                if ((overwrite != "Y") and (overwrite != "y")):
                    raise IOError("Suspended to generate a file by a user")
            fp_handle_def = open(py_impl_name, "w")
            fp_handle_def.writelines(py_impl_lines)
            fp_handle_def.close()

    #
    # Replace %%XXX%% keyword in skelton file into specified information
    #
    def ReplaceStr(self, keyword):
        line = ""
        if keyword == "%%VERSION%%":
            line = __version__
        elif keyword == "%%GEN_CMDIF_PY_ID%%":
            temp_line = "//      $Id: gen_cmdif.py v2015_02_12 $
            line = temp_line[0:-2]
        elif keyword == "%%MODULE%%":
            line = self.mModuleName.upper()
        elif keyword == "%%CMD_ID%%":
            if self.mCmdID:
                line = self.mCmdID
            else:
                line = "command"
        elif keyword == "%%REMOVE_1ST_ARG%%":
            if self.mCmdID in ["ini", "tgt", "reg"]:
                line = "//"
            else:
                line = ""
        elif keyword == "%%INPUT_FILE_CONTENTS%%":
            line = line + self.mInFileContents
        elif keyword == "%%HANDLE_COMMAND_NAME%%":
            if self.mCmdID:
                line = self.mCmdID + "_handle_command"
            else:
                line = "handleCommand"
        elif keyword == "%%CALL_ONLY_PARENT%%":
            for base_class in self.mBaseClassList:
                regif_api = ""
                if base_class == "reg":
                    regif_api = "if"
                line = line + "  else if (_args[0] == \"%s\") {\n" % base_class
                if not base_class in ["ini", "tgt", "reg"]:
                    line = line + "    _args.erase(_args.begin());\n"
                line = line + "    ret = this->%s_handle_command(_args);\n" % (base_class + regif_api)
                line = line + "    if (ret != \"\") {\n"
                line = line + "      ret += \"\\n\";\n"
                line = line + "    }\n"
                line = line + "  }\n"
        elif keyword == "%%CALL_PARENT_TOO%%":
            for base_class in self.mBaseClassList:
                regif_api = ""
                if base_class == "reg":
                    regif_api = "if"
                line = line + "\n"
                if base_class in ["ini", "tgt", "reg"]:
                    line = line + "    _args.insert(_args.begin(), \"%s\");\n" % (base_class)
                #FIXME line = line + "    _args.insert(_args.begin(), \"%s\");\n" % (base_class)
                line = line + "    baseid_message = this->%s_handle_command(_args);\n" % (base_class + regif_api)
                line = line + "    if (baseid_message.find(\"is invalid\", 0) == std::string::npos) {\n"
                line = line + "      cmd_found = true;\n"
                line = line + "      if (baseid_message != \"\") {\n"
                line = line + "        ret += baseid_message;\n"
                line = line + "      }\n"
                line = line + "    }\n"
                if base_class in ["ini", "tgt", "reg"]:
                    line = line + "    _args.erase(_args.begin());\n"
                #FIXME line = line + "    _args.erase(_args.begin());\n"
        elif keyword == "%%USER_CMD_USAGE%%":
            for cmd in self.mCmdList:
                arg_str = ""
                s_str = "    ret += \"    "
                e_str = "\\n\";\n"
                for arg in cmd.mArg:
                    l_brase = "<"
                    r_brase = ">"
                    if arg.mLevel == "option":
                        l_brase = "["
                        r_brase = "]"
                    arg_str = arg_str + " " + l_brase + arg.mName + r_brase
                if len(cmd.mName + arg_str) + 1 > 41:
                    line = line + "%s%s%s" % (s_str, cmd.mName + arg_str, e_str)
                    line = line + "%s%-41s %s" % (s_str, " ", cmd.mUsage)
                else:
                    line = line + "%s%-41s %s" % (s_str, cmd.mName + arg_str, cmd.mUsage)
                # dump default value
                if cmd.mType == "CMD_RW":
                    line = line + " ( Default:"
                    for arg in cmd.mArg:
                        if arg.mAltRule == "|":
                            def_list = []
                            for factor in arg.mDefaultList:
                                def_list.append(factor.replace("\"", "\\\""))
                            line = line + "|".join(def_list)
                        else:
                            line = line + arg.mDefaultList[0].replace("\"", "\\\"") + " "
                        line = line + " "
                    line = line + ")"
                line = line + e_str
        elif keyword == "%%CMD_RW%%":
            for cmd in self.mCmdList:
                line = line + "  else if (args[0] == \"%s\") {\n" % cmd.mName
                if cmd.mType == "CMD_ACTION":
                    line = line + self.ReplaceCmdAction(cmd)
                elif cmd.mType == "CMD_RW":
                    line = line + self.ReplaceCmdRW(cmd)
        elif keyword == "%%INIT_CMD_DB%%":
            for cmd in self.mCmdList:
                if cmd.mType != "CMD_RW":
                    continue
                for arg in cmd.mArg:
                    # if there are 2 or more than arguments, variable name is
                    # command name + argument name
                    val_name = cmd.mName
                    if len(cmd.mArg) > 1:
                        val_name = val_name + "." + arg.mName
                    # the number of initial value factor is more than 1
                    if arg.mAltRule == "|":
                        for factor in arg.mAltList:
                            matched = False
                            for default_val in arg.mDefaultList:
                                if factor == default_val:
                                    line = line + "  %s[%s] = true;\n" % (val_name, factor)
                                    matched = True
                                    break
                            if not matched:
                                line = line + "  %s[%s] = false;\n" % (val_name, factor)
                    # if type is sc_time, add SC_NS
                    elif arg.mType == "sc_time":
                        line = line + "  %s = sc_time(%s, SC_NS);\n" % (val_name, arg.mDefaultList[0])
                    #FIXME # if type is string, surround "
                    #FIXME elif arg.mType == "string" or arg.mType == "std::string":
                    #FIXME     line = line + "  %s = \"%s\";\n" % (val_name, arg.mDefaultList[0])
                    # the number of initial value factor is equal to 1
                    else:
                        if arg.mType in ["uint64_t", "sc_dt::uint64"]:
                           line = line + "  %s = %s;\n" % (val_name, arg.mDefaultList[0] + "ULL")
                        else:
                           line = line + "  %s = %s;\n" % (val_name, arg.mDefaultList[0])
        elif keyword == "%%INIT_PORT_ACCESS%%":
            temp_line = ""
            for port in self.mPortList:
                if port.mPortType != "out":
                    continue
                if port.mClassType == "uint64_t" or port.mClassType == "sc_dt::uint64" or port.mClassType == "sc_biguint":
                    line += "  mVal_%s = %sULL;\n" % (port.mPortName, port.mFixedValue.strip("ULL"))
                else:
                    line += "  mVal_%s = %s;\n" % (port.mPortName, port.mFixedValue)
                temp_line += "  SC_METHOD(write_port_%s_method);\n" % (port.mPortName) 
                temp_line += "  dont_initialize();\n" 
                temp_line += "  sensitive << mEvtWr_%s;\n\n" % (port.mPortName)
            if temp_line != "":
                line += "\n" + temp_line.strip("\n")
        elif keyword == "%%USER_CMD_DEC%%":
            # user define command's member
            for cmd in self.mCmdList:
                if cmd.mType != "CMD_RW":
                    continue
                if len(cmd.mArg) > 1:
                    # declare enum
                    for arg in cmd.mArg:
                        if cmd.mArg[0].mType.find("enum") == 0:
                            line = line + "%s {" % (arg.mType)
                            line = line + ", ".join(arg.mAltList)
                            line = line + "};\n"

                    line = line + "struct {\n"
                    for arg in cmd.mArg:
                        line = line + "  %s %s;\n" % (arg.mType.replace("enum ", ""), arg.mName)
                    line = line + "} %s;\n" % (cmd.mName)
                else:
                    if cmd.mArg[0].mType.find("enum") == 0:
                        line = line + "%s {" % (cmd.mArg[0].mType)
                        line = line + ", ".join(cmd.mArg[0].mAltList)
                        line = line + "} %s;\n" % (cmd.mName)
                    else:
                        line = line + "%s %s;\n" % (cmd.mArg[0].mType, cmd.mName)
            temp_line = ""
            for port in self.mPortList:
                if port.mPortType != "out":
                    continue
                if port.mClassType == "sc_uint": 
                    line += "unsigned int mVal_%s;\n" % (port.mPortName)
                elif port.mClassType == "sc_biguint":
                    line += "uint64_t mVal_%s;\n" % (port.mPortName)
                else:
                    line += "%s mVal_%s;\n" % (port.mClassType, port.mPortName)
                temp_line += "sc_event mEvtWr_%s;\n" % (port.mPortName)
            if temp_line != "":
                line += temp_line.strip("\n")
        elif keyword == "%%REGIF_HANDLE_COMMAND%%":
            if not "reg" in self.mBaseClassList:
                line = "0"
            else:
                line = "1"
        elif keyword == "%%PORT_HANDLE_COMMAND%%":
            if not "port" in self.mBaseClassList:
                line = "0"
            else:
                line = "1"
        elif keyword == "%%PORT_ACCESS%%":
            for port in self.mPortList:
                line = line + "        if (obj_name == mInstName + (std::string)\".%s\") {\n" % (port.mPortName)
                if port.mClassType == "sc_uint" or port.mClassType == "sc_biguint":
                    a_type = "sc_%s<%s<%s> >" % (port.mPortType, port.mClassType, port.mBitWidth)
                    p_type = "unsigned int"
                    read_api = ".to_uint()"
                    if port.mClassType == "sc_biguint":
                        p_type = "uint64_t"
                        read_api = ".to_uint64()"
                else:
                    a_type = "sc_%s<%s>" % (port.mPortType, port.mClassType)
                    p_type = port.mClassType
                    read_api = ""
                line = line + "          %s *port_obj = dynamic_cast<%s*>(*it);\n" % (a_type, a_type)
                call_macro = "PORT_READ_WRITE"
                print_func = "print_uint"
                str2_func = "str2num"
                if port.mPortType == "in":
                    call_macro = "PORT_READ"
                if port.mClassType == "double":
                    print_func = "print_double"
                    str2_func = "str2dbl"
                elif port.mClassType == "uint64_t" or port.mClassType == "sc_dt::uint64" or port.mClassType == "sc_biguint":
                    print_func = "print_uint64"
                    str2_func = "str2num"
                if port.mPortType == "in":
                    line = line + "          %s(%s, port_obj->read()%s, %s);\n" % (call_macro, port.mPortName, read_api, print_func)
                else:
                    line = line + "          %s(%s, port_obj->read()%s, %s, %s, %s);\n" % (call_macro, port.mPortName, read_api, p_type, print_func, str2_func)
                if port.mPortType != "in":
                    line = line + "          if (find_success) WritePort(\"%s\", mVal_%s);\n" % (port.mPortName, port.mPortName)
                line = line + "        }\n"
        elif keyword == "%%PORT_METHOD_DECLARE%%":
            for port in self.mPortList:
                if port.mPortType != "out":
                    continue
                line += "void write_port_%s_method(){%s.write(mVal_%s);}\n" % (port.mPortName, port.mPortName, port.mPortName)
        elif keyword == "%%WRITE_PORT_API%%":
            initial_flag = False
            for port in self.mPortList:
                if port.mPortType == "in":
                    continue
                if not initial_flag:
                    initial_flag = True
                    line += "template<typename T>\n"
                    line += "void WritePort(std::string port_name, T port_val)\n"
                    line += "{\n"
                    line += "  if (port_name == \"%s\") {\n" % (port.mPortName)
                else:
                    line += "  } else if (port_name == \"%s\") {\n" % (port.mPortName)
                if port.mClassType == "sc_uint":
                    line += "    mVal_%s = (unsigned int) port_val;\n" % (port.mPortName)
                elif port.mClassType == "sc_biguint":
                    line += "    mVal_%s = (uint64_t) port_val;\n" % (port.mPortName)
                else:
                    line += "    mVal_%s = (%s) port_val;\n" % (port.mPortName, port.mClassType)
                line += "    mEvtWr_%s.notify();\n" % (port.mPortName)
            if initial_flag:
                line += "  }\n"
                line += "}\n"
        elif keyword == "%%SET_COMMAND_ID%%":
            if self.mCmdID == "":
                line = line + "  mCmdId = \"%s\";\n" % ("self")
            else:
                line = line + "  mCmdId = \"%s\";\n" % (self.mCmdID)
        elif keyword == "%%COPYRIGHT%%":
            # Add copyright information
            line = ""
            install_dir = os.path.abspath(os.path.dirname(__file__))
            fp_copyright = open(install_dir + "/copyright.txt", "r")
            for cur_line in fp_copyright.readlines():
                line += cur_line
            line = line.rstrip("\n\r")
            fp_copyright.close()
        elif keyword == "%%CLASS_NAME%%":
            line = self.mModuleName
        elif keyword == "%%PY_FUNCTION_DECLARATION%%":
            line = self.PyFuncDeclaration()
        elif keyword == "%%PY_FUNCTION_REGISTRATION%%":
            line = self.PyFuncRegistration()
        elif keyword == "%%PY_FUNCTION_IMPLEMENTATION%%":
            line = self.PyFuncImplementation()
        return line

    #
    # Dump CMD_ACTION command
    #
    def ReplaceCmdAction(self, cmd):
        line = ""

        # research the required argument number
        arg_less_than = len(cmd.mArg) + 1
        arg_more_than = -1 + 1
        for arg in cmd.mArg:
            if arg.mLevel == "option":
                break
            arg_more_than = arg_more_than + 1

        # not declare return variable if type is void
        if cmd.mRetType != "void":
            line = line + "    %s ret_val;\n" % (cmd.mRetType)

        line = line + "    if ((int)args.size() > %s && (int)args.size() <= %s) {\n" % (arg_more_than, arg_less_than)
        index = 1
        for arg in cmd.mArg:
            # declare argument variable
            type_name = arg.mType + " " + arg.mName
            default_val = ""
            if arg.mType == "sc_time":
                type_name = "double val_%d" % (index)
            if arg.mDefaultList[0] != "":
                default_val = " = " + arg.mDefaultList[0]

            line = line + "      %s%s;\n" % (type_name, default_val)
            line = line + "      if ((int)args.size() >= %d) {\n" % (index + 1)

            # argument in alternative list ?
            if arg.mAltRule == "/":
                line = line + "      if(1\n"
                for factor in arg.mAltList:
                    if factor == "+":
                        line = line + "      && (args[%d][0] == \'-\' || args[%d] == \"0\")\n" % (index, index)
                    elif factor == "-":
                        line = line + "      && args[%d][0] != \'-\'\n" % (index)
                    else:
                        if arg.mType.find("string") != -1:
                            line = line + "      && args[%d] != %s\n" % (index, factor)
                        else:
                            line = line + "      && args[%d] != \"%s\"\n" % (index, factor)

                line = line + "      ) {\n"
                line = line + "        return err_msg + (std::string)args[%d] + \" is not included in alternative list\" + specified_cmd;\n" % (index)
                line = line + "      }\n"

            if arg.mType in self.mNativeTypeList:
                if arg.mType == "bool":
                    line = line + "        {\n"
                    line = line + "          bool write_val = false;\n"
                    line = line + "          if (!str2num(args[%d], write_val)) {\n" % (index)
                    line = line + "            ret += err_msg + \"wrong argument\" + specified_cmd;\n"
                    line = line + "            return ret;\n"
                    line = line + "          } else {\n"
                    line = line + "            %s = write_val;\n" % (arg.mName)
                    line = line + "          }\n"
                    line = line + "        }\n"
                else:
                    if arg.mType in self.mPositiveTypeList:
                        line = line + "        if (args[%d][0] == \'-\') {\n" % (index)
                        line = line + "          ret = err_msg + \"wrong argument\" + specified_cmd;\n"
                        line = line + "          return ret;\n"
                        line = line + "        }\n"
                    if arg.mType == "double":
                        line = line + "        if (!str2dbl(args[%d], %s)) {\n" % (index, arg.mName)
                        line = line + "          ret = err_msg + \"wrong argument\" + specified_cmd;\n"
                        line = line + "          return ret;\n"
                        line = line + "        }\n"
                    elif arg.mAltRule != "/":
                        line = line + "        if (!str2num(args[%d], %s)) {\n" % (index, arg.mName)
                        line = line + "          ret = err_msg + \"wrong argument\" + specified_cmd;\n"
                        line = line + "          return ret;\n"
                        line = line + "        }\n"
                    else:
                        line = line + "        str2num(args[%d], %s);\n" % (index, arg.mName)
                line = line + "      }\n"
            elif arg.mType.find("string") != -1:
                line = line + "        %s = (std::string)args[%d];\n" % (arg.mName, index)
                line = line + "      }\n"
            elif arg.mType.find("sc_time") != -1:
                line = line + "        if (args[%d][0] == \'-\') {\n" % (index)
                line = line + "          ret = err_msg + \"wrong argument\" + specified_cmd;\n"
                line = line + "          return ret;\n"
                line = line + "        }\n"
                line = line + "        if (!str2dbl(args[%d], val_%d)) {\n" % (index, index)
                line = line + "          ret = err_msg + \"wrong argument\" + specified_cmd;\n"
                line = line + "          return ret;\n"
                line = line + "        }\n"
                line = line + "      }\n"
                line = line + "      sc_time %s(val_%d, SC_NS);\n" % (arg.mName, index)
            elif arg.mType.find("enum") == 0:
                line = line + "        if(0) {;}\n"
                for factor in arg.mAltList:
                    line = line + "        else if( args[%d] == \"%s\") {\n" % (index, factor)
                    line = line + "          %s = %s;\n" % (arg.mName, factor)
                    line = line + "        }\n"
                line = line + "      }\n"

            index = index + 1

        # call user function
        if cmd.mRetType == "void":
            line = line + "      %s(" % (cmd.mName)
        else:
            line = line + "      ret_val = %s(" % (cmd.mName)

        arg_name_list = []
        for arg in cmd.mArg:
            arg_name_list.append(arg.mName)
        line = line + ", ".join(arg_name_list)
        line = line + ");\n"

        if cmd.mRetType == "bool":
            line = line + "      if (!ret_val) {\n"
            line = line + "        ret = err_msg + \"fail to \" + (std::string)args[0] + \" command\" + specified_cmd;\n"
            line = line + "      }\n"

        elif cmd.mRetType in self.mNativeTypeList:
            line = line + "      std::ostringstream ret_str;\n"
            line = line + "      ret_str << "
            if cmd.mRetType == "char":
                line = line + "(int)"
            elif cmd.mRetType == "unsigned char":
                line = line + "(unsigned int)"
            line = line + "ret_val;\n"
            line = line + "      ret = ret_str.str();\n"

        elif cmd.mRetType == "std::string" or cmd.mRetType == "string":
            line = line + "      ret = ret_val;\n"

        elif cmd.mRetType == "sc_time":
            line = line + "      ret = ret_val.to_string();\n"

        elif cmd.mRetType.find("enum") == 0:
            line = line + "      if (0){}\n"
            for factor in cmd.mAltList:
                line = line + "      else if( ret_val == %s ) {\n" % (factor)
                line = line + "        ret = \"%s\";\n" % (factor)
                line = line + "      }\n"

        line = line + "    }\n"
        line = line + "    else {\n"
        line = line + "      ret = err_msg + \"wrong number of arguments\" + specified_cmd;\n"
        line = line + "    }\n"
        line = line + "  }\n"

        return line

    #
    # Dump CMD_RW command
    #
    def ReplaceCmdRW(self, cmd):
        line = ""
        # read action
        line = line + "    // read mode\n"
        line = line + "    if (0) {;}\n"
        line = line + "    else if ((int)args.size() == 1) {\n"
        if len(cmd.mArg) == 1:
            if cmd.mArg[0].mType in self.mNativeTypeList:
                if cmd.mArg[0].mType == "bool":
                    line = line + "      if (" + cmd.mName + ") {\n"
                    line = line + "        ret = \"true\";\n"
                    line = line + "      }\n"
                    line = line + "      else {\n"
                    line = line + "        ret = \"false\";\n"
                    line = line + "      }\n"
                else:
                    line = line + "      std::ostringstream stream;\n"
                    line = line + "      stream << "
                    if cmd.mArg[0].mType == "char":
                        line = line + "(int)"
                    elif cmd.mArg[0].mType == "unsigned char":
                        line = line + "(unsigned int)"
                    line = line + cmd.mName + ";\n"
                    line = line + "      ret = stream.str();\n"
                line = line + "    }\n"
            elif cmd.mArg[0].mType == "sc_time":
                line = line + "      ret = %s.to_string();\n" % (cmd.mName)
                line = line + "    }\n"
            elif cmd.mArg[0].mType.find("enum") == 0:
                line = line + "      if (0) {;}\n"
                for factor in cmd.mArg[0].mAltList:
                    line = line + "      else if( %s == %s) {\n" % (cmd.mName, factor)
                    line = line + "        ret = \"%s\";\n" % (factor)
                    line = line + "      }\n"
                line = line + "    }\n"
            elif cmd.mArg[0].mAltRule == "|":
                line = line + "      std::map<std::string, bool>::iterator it;\n"
                line = line + "      for (it = %s.begin(); it != %s.end(); it++) {\n" % (cmd.mName, cmd.mName)
                line = line + "        if (it->second) {\n"
                line = line + "          ret += \" \" + it->first;\n"
                line = line + "        }\n"
                line = line + "      }\n"
                line = line + "    }\n"
            else:
                line = line + "      ret = " + cmd.mName + ";\n"
                line = line + "    }\n"
        else:
            native_cmd_list = []
            for arg in cmd.mArg:
                if arg.mType in self.mNativeTypeList:
                    str_name = "str_" + arg.mName
                    line = line + "      std::ostringstream %s;\n" % (str_name)
                    line = line + "      %s << " % (str_name)
                    if arg.mType == "char":
                        line = line + "(int)"
                    elif arg.mType == "unsigned char":
                        line = line + "(unsigned int)"
                    line = line + "%s.%s;\n\n" % (cmd.mName, arg.mName)
                    native_cmd_list.append(str_name + ".str()")
                elif arg.mType.find("enum") == 0:
                    str_name = "str_" + arg.mName
                    line = line + "      std::string %s;\n" % (str_name)
                    line = line + "      if (0) {;}\n"
                    for factor in arg.mAltList:
                        line = line + "      else if( %s.%s == %s) {\n" % (cmd.mName, arg.mName, factor)
                        line = line + "        %s = \"%s\";\n" % (str_name, factor)
                        line = line + "      }\n"
                    native_cmd_list.append(str_name)
                elif arg.mType == "sc_time":
                    str_name = "str_" + arg.mName
                    line = line + "      std::string %s = %s.%s.to_string();\n" % (str_name, cmd.mName, arg.mName)
                    native_cmd_list.append(str_name)
                elif arg.mAltRule == "|":
                    str_name = "str_" + arg.mName
                    line = line + "      std::string %s;\n" % (str_name)
                    line = line + "      {\n"
                    line = line + "        std::map<std::string, bool>::iterator it;\n"
                    line = line + "        for (it = %s.%s.begin(); it != %s.%s.end(); it++) {\n" % (cmd.mName, arg.mName, cmd.mName, arg.mName)
                    line = line + "          if (it->second) {\n"
                    line = line + "            %s += \" \" + it->first;\n" % (str_name)
                    line = line + "          }\n"
                    line = line + "        }\n"
                    line = line + "      }\n"
                    native_cmd_list.append(str_name)
                else:
                    native_cmd_list.append(cmd.mName + "." + arg.mName)
            line = line + "      ret = " + "+ \" \" +".join(native_cmd_list) + ";\n"
            line = line + "    }\n"
        # write action
        arg_less_than = len(cmd.mArg)
        arg_more_than = 0
        for arg in cmd.mArg:
            if arg.mLevel == "option":
                break
            arg_more_than = arg_more_than + 1
        line = line + "    // write mode\n"
        index1 = arg_more_than
        #for index1 in list(range(arg_more_than, arg_less_than)):
        while index1 <= arg_less_than:
            line = line + "    else if ((int)args.size() == %d) {\n" % (index1 + 1)
            index2 = 1
            #for index2 in list(range(1, arg_less_than)):
            while index2 <= arg_less_than:
                # data member name is struct name(command) + member name(arg)
                # if that type is struct.
                if len(cmd.mArg) > 1:
                    val_name = cmd.mName + "." + cmd.mArg[index2 - 1].mName
                else:
                    val_name = cmd.mName
                # use argument value
                if index2 <= index1:
                    if cmd.mArg[index2 - 1].mAltRule == "/":
                        line = line + "      if(1\n"
                        for factor in cmd.mArg[index2 - 1].mAltList:
                            if factor == "+":
                                line = line + "      && (args[%d][0] == \'-\' || args[%d] == \"0\")\n" % (index2, index2)
                            elif factor == "-":
                                line = line + "      && args[%d][0] != \'-\'\n" % (index2)
                            else:
                                if cmd.mArg[index2-1].mType.find("string") != -1:
                                    line = line + "      && args[%d] != %s\n" % (index2, factor)
                                else:
                                    line = line + "      && args[%d] != \"%s\"\n" % (index2, factor)
                        line = line + "      ) {\n"
                        line = line + "        return err_msg + (std::string)args[%d] + \" is not included in alternative list\" + specified_cmd;\n" % (index2)
                        line = line + "      }\n"
                    if cmd.mArg[index2 - 1].mType == "bool":
                        line = line + "      {\n"
                        line = line + "        %s write_val = false;\n" % (cmd.mArg[index2 - 1].mType)
                        line = line + "        if (!str2num(args[%d], write_val)) {\n" % (index2)
                        line = line + "          ret += err_msg + \"wrong argument: \" + (std::string)args[%d] + specified_cmd;\n" % (index2)
                        line = line + "        } else {\n"
                        line = line + "          %s = write_val;\n" % (val_name)
                        line = line + "        }\n"
                        line = line + "      }\n"
                    elif cmd.mArg[index2 - 1].mType == "double":
                        line = line + "      {\n"
                        line = line + "        std::istringstream is(args[%d]);\n" % (index2)
                        line = line + "        double backup = %s;\n" % (val_name)
                        line = line + "        is >> %s;\n" % (val_name)
                        line = line + "        \n"
                        line = line + "        if (is.fail() || !is.eof()) {\n"
                        line = line + "          %s = backup;\n" % (val_name)
                        line = line + "          ret += err_msg + \"wrong argument: \" + args[%d] + specified_cmd;\n" % (index2)
                        line = line + "        }\n"
                        line = line + "      }\n"
                    elif cmd.mArg[index2 - 1].mType.find("enum") == 0:
                        line = line + "      if (0) {;}\n"
                        for factor in cmd.mArg[index2 - 1].mAltList:
                            line = line + "      else if( args[%d] == \"%s\") {\n" % (index2, factor)
                            line = line + "        %s = %s;\n" % (val_name, factor)
                            line = line + "      }\n"
                    elif cmd.mArg[index2 - 1].mType == "sc_time":
                        line = line + "      {\n"
                        line = line + "        std::istringstream is(args[%d]);\n" % (index2)
                        line = line + "        double num;\n"
                        line = line + "        is >> num;\n"
                        line = line + "        \n"
                        line = line + "        if (is.fail() || !is.eof()) {\n"
                        line = line + "          ret += err_msg + \"wrong argument: \" + args[%d] + specified_cmd;\n" % (index2)
                        line = line + "        }\n"
                        line = line + "        else{\n"
                        line = line + "          %s = sc_time(num, SC_NS);\n" % (val_name)
                        line = line + "        }\n"
                        line = line + "      }\n"
                    elif cmd.mArg[index2 - 1].mAltRule == "|":
                        line = line + "      std::vector<std::string> arg_vec_%d = str2vec(args[%d], '|');\n" % (index2, index2)
                        line = line + "      {\n"
                        line = line + "        std::map<std::string, bool>::iterator it;\n"
                        line = line + "        for (it = %s.begin(); it != %s.end(); it++) {\n" % (val_name, val_name)
                        line = line + "          %s[it->first] = false;\n" % (val_name)
                        line = line + "        }\n"
                        line = line + "      }\n"
                        line = line + "      {\n"
                        line = line + "        std::vector<std::string>::iterator it;\n"
                        line = line + "        for (it = arg_vec_%d.begin(); it != arg_vec_%d.end(); it++) {\n" % (index2, index2)
                        line = line + "          %s[*it] = true;\n" % (val_name)
                        line = line + "        }\n"
                        line = line + "      }\n"
                    elif cmd.mArg[index2 - 1].mType in self.mNativeTypeList:
                        # unsigned type check
                        if cmd.mArg[index2 - 1].mType in self.mPositiveTypeList:
                            line = line + "      if (args[%d].substr(0, 1) == \"-\") {\n" % (index2)
                            line = line + "          ret += err_msg + \"wrong value: \" + (std::string)args[%d] + specified_cmd;\n" % (index2)
                            line = line + "      }\n"
                        else:
                            line = line + "      if (0) {\n"
                            line = line + "      }\n"

                        line = line + "      else {\n"
                        line = line + "        %s write_val = 0;\n" % (cmd.mArg[index2 - 1].mType)
                        line = line + "        if (!str2num(args[%d], write_val)) {\n" % (index2)
                        line = line + "          ret += err_msg + \"wrong argument: \" + (std::string)args[%d] + specified_cmd;\n" % (index2)
                        line = line + "        } else {\n"
                        line = line + "          %s = write_val;\n" % (val_name)
                        line = line + "        }\n"
                        line = line + "      }\n"
                    else:
                        line = line + "      %s = (std::string)args[%d];\n" % (val_name, index2)
                # use default value
                else:
                    if cmd.mArg[index2 - 1].mType in ["uint64_t", "sc_dt::uint64"]:
                        line = line + "      %s = %s;\n" % (val_name, cmd.mArg[index2 - 1].mDefaultList[0] + "ULL")
                    else:
                        line = line + "      %s = %s;\n" % (val_name, cmd.mArg[index2 - 1].mDefaultList[0])
                index2 = index2 + 1
            line = line + "    }\n"
            index1 = index1 + 1
        line = line + "    else {\n"
        line = line + "      ret = err_msg + \"wrong number of arguments\" + specified_cmd;\n"
        line = line + "    }\n"
        line = line + "  }\n"

        return line

    #
    # Find brace pair position
    #
    def FindBrace(self, str, key, offset):
        lbrace_cnt = 0
        for index in list(range(offset, len(str))):
            if str[index] == key[0]:
                lbrace_cnt = lbrace_cnt + 1
            elif str[index] == key[1]:
                if lbrace_cnt == 0:
                    return index
                lbrace_cnt = lbrace_cnt - 1
        return -1


#
# Load specified model information files and dump handleCommand code
# with command database.
#
def main():
    # Define & check argument
    script_name = "gen_cmdif.py"
    pythonif_enable = False 
    usage_message = script_name + " <model information file> [-h/--help] [-v/--version] [-p/--pythonif] [--usage] [--sample]"
    arg_info = OptionParser(usage=usage_message)

    arg_info.add_option("-v",
        dest="version",
        action="store_true",
        help="show this version number")

    arg_info.add_option("--version",
        dest="detailed_version",
        action="store_true",
        help="show this version number in detailed")

    arg_info.add_option("-p",
        dest="pythonif",
        action="store_true",
        help="generate python I/F files")

    arg_info.add_option("--pythonif",
        dest="detailed_pythonif",
        action="store_true",
        help="generate python I/F files")

    arg_info.add_option("--usage",
        dest="detailed_usage",
        action="store_true",
        help="show detailed explanation")

    arg_info.add_option("--sample",
        dest="example",
        action="store_true",
        help="show a model information file example")

    (options, args) = arg_info.parse_args()

    # -v option
    if options.version:
        sys.stderr.write("%s\n" % (__version__))
        sys.exit()
    # --version option
    elif options.detailed_version:
        # get version number of handleCommand.skl
        install_dir = os.path.abspath(os.path.dirname(__file__))
        fp_skelton = open(install_dir + "/handleCommand.skl", "r")
        skl_ver_dict = {"gen_cmdif":["","","","-"], "handleCommand":["","","","-"], "modelinfo_parser":["","","","-"]}
        for cur_line in fp_skelton.readlines():
            if cur_line.find("handleCommand.skl,v") != -1:
                skl_ver_dict["handleCommand"] = cur_line.split()
                break
        fp_skelton = open(install_dir + "/handleCommand.skl", "r")
        for cur_line in fp_skelton.readlines():
            if cur_line.find("modelinfo_parser.py,v") != -1:
                skl_ver_dict["modelinfo_parser"] = cur_line.split()
                break
        fp_skelton = open(install_dir + "/gen_cmdif.py", "r")
        for cur_line in fp_skelton.readlines():
            if cur_line.find("gen_cmdif.py,v") != -1:
                skl_ver_dict["gen_cmdif"] = cur_line.split()
                break

        # dump detailed version
        sys.stderr.write("Command IF Generator version %s\n" % (__version__))
        sys.stderr.write("    gen_cmdif.py        %s\n" % (skl_ver_dict["gen_cmdif"][3]))
        sys.stderr.write("    handleCommand.skl   %s\n" % (skl_ver_dict["handleCommand"][3]))
        sys.stderr.write("    modelinfo_parser.py %s\n" % (skl_ver_dict["modelinfo_parser"][3]))
        sys.exit()
    # -p/--pythonif option
    elif options.pythonif or options.detailed_pythonif:
        pythonif_enable = True
    # --usage option
    elif options.detailed_usage:
        # get version number of handleCommand.skl
        install_dir = os.path.abspath(os.path.dirname(__file__))
        fp_usage = open(install_dir + "/usage.txt", "r")
        sys.stderr.write(fp_usage.read())
        sys.exit()
    # --sample option
    elif options.example:
        sys.stderr.write("%MODULE sample\n")
        sys.stderr.write("%CMD_RW cmd <A:int=0>\n")
        sys.stderr.write("%CMD_RW cmd <A:string=X {X/Y/Z}>\n")
        sys.stderr.write("%CMD_RW cmd <A:int=0> [B:string=X]\n")
        sys.stderr.write("%CMD_ACTION cmd <A:int=0> : void\n")
        sys.stderr.write("%CMD_ACTION cmd [A:bool=true] : bool\n")
        sys.stderr.write("%CMD_BASEID ini tgt reg port\n")
        sys.stderr.write("%CMD_NODUMP_API CommandCB MessageLevel EnableInsertInput EnableDumpResult DumpProfile ClearProfile AssertReset\n")
        sys.exit()
    elif (args == []):
        arg_info.print_help()
        return 1

    # Welcome message
    sys.stderr.write("\n\n    %s --- %s\n\n" % (script_name, __version__))

    # Load specified model information file
    for a_file in args:
        sys.stderr.write("Loading %s ...\n" % a_file)
        gen_cmdif = CGenCommandIf()
        gen_cmdif.mPythonIfEnable = pythonif_enable
        gen_cmdif.DecodeFile(a_file)
    
    # Dump include file list
    sys.stderr.write("\n### Users should include the following files which are referred by Command IF:\n")
    sys.stderr.write("  + cstdio\n")
    sys.stderr.write("  + cstdlib\n")
    sys.stderr.write("  + string\n")
    sys.stderr.write("  + vector\n")
    sys.stderr.write("  + map\n")
    sys.stderr.write("  + iterator\n")
    sys.stderr.write("  + sstream\n")
    sys.stderr.write("  + stdint  # for uint64_t\n")

    # Before good-bye
    sys.stderr.write("\nSuccess to run a script\n\n")

#
# Start my program !
#
if (__name__ == "__main__"):
    main()
