#include "systemc.h"
#include "cpu.h"

///////////////////////////////////////////
// Global variables (forest_utility.cpp)
///////////////////////////////////////////

ErrorCode cedarErrno;
ErrorCode cedarErrnoMulti;
EndianType ced_endian_type;

FILE *p_file_system = stdout;
ScriptMode script_mode;
unsigned long print_time = 0;
unsigned long system_time_overflow = 0UL;
unsigned long system_time = 0UL;
unsigned long cpu_time[N_CPU] = {2UL};
unsigned long debug_dtu = 0;
unsigned long debug_mem = 0;

typedef struct {
    unsigned long ctrlreg_addr;
    char ctrlreg_name[32];
} CtrlRegAddrTable;
CtrlRegAddrTable *regaddr_table;
unsigned long n_regaddr_table;

unsigned long pam_disable = 0;
unsigned long snc_disable = 0;

////////////////////////////
// forest_api.cpp
////////////////////////////

void ForestSetInvalidAddress (unsigned long invalid_address)
{
}

////////////////////////////
// forest_utility.cpp
////////////////////////////

unsigned long ForestGetSystemTime(void)
{
#ifdef CFOREST
    return(system_time);
#endif //CFOREST
#ifdef SCFOREST
    return(sc_time_stamp().value());
#endif //SCFOREST
#ifndef CWR_SYSTEMC
    return(0);
#endif
}

int mytoupper (int c)
{
    if ('a' <= c && c <= 'z') {
        c = c - 'a' + 'A';
    }
    return (c);
}

static void strtoupper (const char *fromstr, char *tostr)
{
    long i;

    if (fromstr == NULL || tostr == NULL) { 
        printf("ERROR : function \"strtoupper\" Get NULL Pointer.\n" );
        sc_stop();
    }
    /* ʸ�������ʸ�����Ѵ� */
    for (i = 0; fromstr[i] != '\0'; i++) {
        tostr[i] = (char)mytoupper ((int)(fromstr[i]));
    }
    tostr[i] = '\0';
}

int mystrcasecmp(const char *s1, const char *s2)
{
    int ret;

    //��ʸ���Ѵ�ʸ����γ�Ǽ�ΰ�����
    //������malloc���ʤ��Ȥ��ᡣ��256ʸ���ʾ����core��Ϥ���������
    char large_s1[256];
    char large_s2[256];

    //ʸ�������ʸ�����Ѵ�
    strtoupper(s1, large_s1);
    strtoupper(s2, large_s2);

    //ʸ��������
    ret = strcmp(large_s1, large_s2);

    return(ret);
}

ScriptMode ForestGetScriptMode (void)
{
    return (script_mode);
}

void ForestSetMemInitValue (unsigned long mem_init_value)
{
}

unsigned long ForestGetMemInitValue (void)
{
    return(1);
}

void ForestCycleOverflow(void)
{
}

void ForestManualReset (void)
{
}

char *ForestCtrlRegGetName (unsigned long addr)
{
    /* ���ɥ쥹�򸡺� */
    if (regaddr_table != NULL) {
        for (unsigned long i = 0; i < n_regaddr_table; i++) {
            if (addr == regaddr_table[i].ctrlreg_addr) {
                return ((char *)regaddr_table[i].ctrlreg_name);
            }
        }
    }

    /* ���Ĥ���ʤ��ä� */
    return ((char *)"");
}

////////////////////////////
// snv_wrapper.cpp
////////////////////////////

void WrapperSetCcrCcd(long cpu_id, unsigned long ccd)
{
}

void WrapperDupCacheReset (long cpu_id)
{
}

void WrapperDupCacheAddrArrayWrite (long cpu_id, unsigned long addr, unsigned long data)
{
}

unsigned long WrapperDupCacheAddrArrayRead (long cpu_id, unsigned long addr)
{
    return(0);
}

void WrapperPrintDupOCArray(long cpu_id)
{
}

void WrapperSetDupCacheSize (long cpu_id)
{
}

void WrapperBarwRegBroadcast (long cpu_id, unsigned long channel, unsigned long data)
{
}

void WrapperSetWaySize(long cpu_id, unsigned long oc2w)
{
}

BusResponseType WrapperDupCacheSnoop (long           cpu_id,
                                      unsigned long  phys_addr,
                                      long           replace_way,
                                      unsigned long  v12,
                                      unsigned long  diff_p12,
                                      BusCommandType cmd,
                                      unsigned long  **p_data,
                                      SncAccessReason reason,
                                      unsigned long *snoop_exe,
                                      unsigned long b_type)
{
    return(EXCLU_CLEAN);
}

void WrapperIncReadHitCount(long cpu_id, unsigned long phys_addr, long way)
{
}

void WrapperIncWriteHitNotShareCount(long cpu_id)
{
}

void WrapperSncAllSnoopUnlock(long cpu_id)
{
}

void WrapperCheckSnoopConflict(long cpu_id, unsigned long addr)
{
}

void WrapperSncSnoopUnlock(long cpu_id)
{
}

void WrapperSncAllSnoopLock(long cpu_id)
{
}

////////////////////////////
// intc.cpp
////////////////////////////

void SetInterruptDtu(long cpu_id, unsigned long factor, unsigned long value)
{
}

void IntcNotifyInterruptionAccepted(long cpu_id)
{
}

////////////////////////////
// ext_test.cpp
////////////////////////////

IntcTestMode ced_intc_test_mode = INTC_TEST_OFF;
unsigned long intc_test_flag = 0;
long intc_test_count         = 0;
long intc_test_decrement_num = 1;

void IntcTestRegWrite (unsigned long regaddr, unsigned long data, MemAccessDataType size)
{
}

unsigned long IntcTestRegRead (unsigned long regaddr, MemAccessDataType size)
{
    return (0);
}
