# ----------------------------------------------------------------------
# 
#  Copyright(c) 2010-2012 Renesas Electronics Corporation
#  Copyright(c) 2010-2012 RVC (Renesas Design Vietnam Co., Ltd.)
#  RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
#  This program must be used solely for the purpose for which
#  it was furnished by Renesas Electronics Corporation. No part of this
#  program may be reproduced or disclosed to others, in any
#  form, without the prior written permission of Renesas Electronics
#  Corporation.
# 
# ----------------------------------------------------------------------
# $Id: gen_regif_class.py v2017_04_13 $
# ----------------------------------------------------------------------
import os
import sys
import re
import code

work_dir     = os.path.abspath(os.path.dirname(__file__))
hed_skl_file = work_dir + "/regif_h.skl"
src_skl_file = work_dir + "/regif_cpp.skl"
one_skl_file = work_dir + "/regif_onefile.skl"
mdl_skl_file = work_dir + "/model_templ.skl"
cpy_rgt_file = work_dir + "/copyright.txt"

def PrintDbgMsg(msg_type, msg, exit = True):
    print("<" + msg_type + "> " + msg)
    if exit:
        print("Script terminated abnormally.")
        sys.exit()

def ExtractCVSInfo(filename): # Extract Id marker from a target file
    f_ptr = open(filename, "r")
    info = ""
    for line in f_ptr:
        if line.find("$Id: gen_regif_class.py v2017_04_13 $
            # remove keyword to avoid the updating
            info = line
            info = info.replace("$Id: gen_regif_class.py v2017_04_13 $
            info = info.replace(" Exp $","")
            info = info.replace("#","//")
            info = info.replace(",v","")
            break
    f_ptr.close()
    return info

def Str2Num(str): # Support hex, oct and dec type
    if re.match("^[0-9]+$", str) != None:
        return int(str, 10)
    elif re.match("^0[0-7]+$", str) != None:
        return int(str, 8)
    elif re.match("^0x[0-9a-fA-F]+$", str) != None:
        return int(str, 16)
    else:
        PrintDbgMsg("ERROR", "Invalid string to exchange into a number (" + str + ")\n")

def NumberConvert(offset_str, arg_name = "", info_line = []): # check string (hexadecimal or decimal or not) and convert to number
    if (str(offset_str)).startswith("0x"):
        try:
            value = int(offset_str, 16)
        except (ValueError):
            PrintDbgMsg("ERROR", "\"{}\" - Illegal hexadecimal value: {}\n{}".format(arg_name, offset_str, PrintMessage(info_line)))
    else:
        try:
            value = int(str(offset_str), 10)
        except (ValueError):
            PrintDbgMsg("ERROR", "\"{}\" - Illegal value: {}. Numeric value expected.\n{}".format(arg_name, offset_str, PrintMessage(info_line)))
    if value < 0 :
        PrintDbgMsg("ERROR", "\"{}\" - Illegal value: {}. {} must be greater than 0.\n{}".format(arg_name, offset_str, arg_name, PrintMessage(info_line)))
    return value

def PrintMessage(info_list): # get items from "info_list" list to form a string for message display
    string = ""
    if (info_list[1] == ""): # 'info_list' has only 1 line
        info_list.pop(1)
    elif (info_list[0][0] != "%%TITLE"): # 1st line of 'info_list' is not %%TITLE line
        info_list.pop(0)
    for line in info_list:
        string += "File \"{}\", ".format(str(line[-1]))
        string += "line {:<6}".format(str(line[-2]) + ":")
        for item in line[0:-2]:
            if (item == ""):
                item = "-"
            string += "{:<10}".format(str(item) + " ")
        string += "\n"
    string = string[0:-1] # omit last "\n"
    return string

class CRegisterItem:
    def __init__(self, hier_name, hier_inst_name, reg_name, inst_name, index, size, wsize, rsize, length, offset, factor_start, factor_end, factor_index, factor_step, is_reg_instance, reg_info, bit_info):
        self.mHierName = hier_name
        self.mHierInstName = hier_inst_name
        self.mRegname = reg_name
        self.mRegInstName = inst_name
        self.mIndex   = index
        self.mSize    = size
        self.mWrSize  = wsize
        self.mRdSize  = rsize
        self.mLength  = length
        self.mOffset  = offset
        self.mFactorStart = factor_start
        self.mFactorEnd = factor_end
        self.mFactorIndex = factor_index
        self.mFactorStep = factor_step
        self.mIsRegInstance = is_reg_instance
        self.mRegInfo = reg_info
        self.mBitInfo = bit_info

class CBitItem:
    def __init__(self, regname, instname, index, bitname, upper, lower, init, access, support, factor, callback, value, overlap):
        self.mRegname     = regname              # Register name
        self.mRegInstName = instname             # Register instance name
        self.mIndex       = index                # Channel index
        self.mBitname     = bitname              # Bit name
        self.mUpper       = upper                # Bit range's upper
        self.mLower       = lower                # Bit range's lower
        self.mInit        = Str2Num(str(init))   # Initial value
        self.mAccess      = access               # Access mode
        self.mFactor      = factor               # Factor index of register
        self.mSupport     = support              # Support mode
        self.mCallback    = callback             # Call-back function
        self.mWritableStr = value                # Writable value string (parsed from input file)
        self.mIsWriteCb   = False                # support Write call-back function
        self.mIsReadCb    = False                # support Read call-back function
        self.mCbFuncname  = ""                   # Call-back function name
        self.mValue       = ""                   # Writable value string - numbers only (used for bit definition)
        self.mOverlap     = overlap              # Overlap bit or not

class CSameFactorRegisterItem:
    def __init__(self, factor_start, factor_end, register_list):
        self.mFactorStart = factor_start
        self.mFactorEnd   = factor_end
        self.mRegList     = register_list

class CCwCombineRegItem:
    def __init__(self, comb_reg_name, comb_addr, comb_reg_list):
        self.mCombRegName = comb_reg_name   # Combine register name for CoWare
        self.mCombAddr    = comb_addr       # Combine register address for CoWare
        self.mCombRegList = comb_reg_list   # List of combined registers for CoWare

class CCwCombineRegNameDictItem:
    def __init__(self):
        self.mCombRegIndexDict = {}        # Dictionary of register by register group index keyword
        self.mCombRegFactorIndexList = []  # List of factor index of combined register which has no group index

class CRegisterTable:  # stores Table of Register and generates register-related source code
    def __init__(self):
        self.mRegisterTable = []
        self.mMaxlenRegname = 0
        self.mMaxlenIndex   = 0
        self.mMaxLenString  = 0
        self.indent = []
        self.mOffsetList = []  # List of registers which of length less than maximum register's length
        self.mRegDict = {}
        self.mCwCombRegNameList = {}
        self.mCwCombRegList = []
        self.mType = {1:"unsigned char", 2: "unsigned short", 4: "uint"}
        self.mCwmemDecl = 0;
        self.mAlterFactorIndexFlag = 0;

    def GetRegInstanceItem(self): # Get position of item in mRegisterTable which represents a register channel (from a %%REG_INSTANCE)
        i = 0
        for item in self.mRegisterTable:
            if item.mIsRegInstance: # item is a %%REG_INSTANCE
                return i
            else:
                i = i + 1
        return (-1)

    def Replace(self, pos, item_list): # Replace a channel item with its registers (or sub-channels)
        old_item = self.mRegisterTable.pop(pos)
        for item in item_list:
            if (old_item.mHierInstName != ""):
                item.mInstName = old_item.mHierInstName
            if ((item.mIndex.strip(" ") != "") and (item.mIndex.strip(" ") != "-")):
                if (old_item.mIndex != ""):
                    item.mIndex = old_item.mIndex + "_" + item.mHierName + item.mIndex # update group index
            else:
                item.mIndex = old_item.mIndex
            item.mOffset = old_item.mOffset + item.mOffset       # update address offset
#            if ((item.mIndex.strip(" ") != "") and (item.mIndex.strip(" ") != "-")): # TODO
#                item.mRegInstName = item.mRegInstName + "_" + item.mIndex
            self.mRegisterTable.insert(pos,item)
            pos = pos + 1

    def StringAlignment(self, StringList): # Calculate the max length of strings 'regname' and 'index'
        if (StringList == ""):
            for reg in self.mRegisterTable:
                if (reg.mIndex != ""):
                    reg.mIndex = "em" + reg.mIndex # add "em" prefix for enumeration
                if (len(reg.mRegname) > self.mMaxlenRegname):
                    self.mMaxlenRegname = max([len(reg.mRegname),len(reg.mRegInstName)])
                if (len(reg.mIndex) > self.mMaxlenIndex):
                    self.mMaxlenIndex = len(reg.mIndex)
        else:
            for string in StringList :
                if (len(string) > self.mMaxLenString):
                    self.mMaxLenString = len(string)

    def AddedSpaces(self, string, type, add_length = 0):
        if (type == "regname"):
            maxlen = self.mMaxlenRegname + add_length
        elif (type == "string"):
            maxlen = self.mMaxLenString + add_length
        else:
            maxlen = self.mMaxlenIndex + add_length
        return string + " "*(maxlen - len(string))

    def PrintEnumDeclare(self): # [Source code generating] Print enumeration declaration
        string = self.indent[1] + "enum eRegGroup {\n" + self.indent[2]
        duplicated_check = []
        reg_duplicated_check = []
        list_reg_enum = []
        for reg in self.mRegisterTable:
            if (reg.mIndex != ""): # group index enum existed
                if not reg.mIndex in duplicated_check:
                    string += reg.mIndex + ", "
                    duplicated_check.append(reg.mIndex)
            if (reg.mFactorIndex != []):
                if not reg.mRegname in reg_duplicated_check:
                    list_reg_enum.append([reg.mRegInstName, len(reg.mFactorIndex)])
                    reg_duplicated_check.append(reg.mRegname)
            elif (reg.mFactorEnd != ""):
                if not reg.mRegname in reg_duplicated_check:
                    list_reg_enum.append([reg.mRegInstName, (reg.mFactorEnd - reg.mFactorStart) + 1])
                    reg_duplicated_check.append(reg.mRegname)

        string += "emNum_of_gr\n" + self.indent[1] + "}; ///< Enumeration for register group index\n"
        if list_reg_enum  != [] :
            string += self.indent[1] + "enum eRegIndex {\n"
            str_tmp = ""
            for reg in list_reg_enum:
                str_tmp += self.indent[2] + "emNUM_" + self.AddedSpaces(reg[0],"regname") + " = " + str(reg[1]) + ",\n"
            string += str_tmp[0:-2] + "\n" + self.indent[1] + "}; ///< Enumeration for register factor index"

        return string

    def PrintRegDeclare(self): # [Source code generating] Print re_register pointer declaration
        string = ""
        reg_duplicated_check = []
        bit_duplicated_check = []
        cw_reg_define = self.indent[1] + "#ifdef CWR_SYSTEMC\n"
        cw_reg_define += self.indent[1] + "scml2::memory<REG_TYPE> cwmem;\n"
        for cw_comb_reg in self.mCwCombRegList:
            [reg_factor_index, factor_start, factor_end, factor_index] = cw_comb_reg.mCombRegList[0][1]
        for reg in self.mRegisterTable:
            if not reg.mRegname in reg_duplicated_check:
                reg_duplicated_check.append(reg.mRegname)
                reg_name = self.AddedSpaces(reg.mRegname,"regname")
                if (reg.mIndex != ""): # "group" index existed
                    reg_name += "[emNum_of_gr]"
                string += self.indent[1] + "vpcl::re_register *" + reg_name
                if reg.mFactorIndex != []:
                    string += "[" + str(max(reg.mFactorIndex) + 1) + "];\n"
                elif reg.mFactorEnd != "":
                    string += "[" + str(reg.mFactorEnd - reg.mFactorStart + 1) + "];\n"
                else:
                    string += ";\n"
        cw_reg_define += self.indent[1] + "#endif\n"
        string += "\n" + cw_reg_define
        string += "\n"
        tmp_var_decl = ""
        for reg in self.mRegisterTable:
            for bit in reg.mBitInfo: # print bit variable declaration
                tmp_name = bit.mRegname.strip(" ") + "_" + bit.mBitname 
                if ((bit.mIndex.strip(" ") != "") and (bit.mIndex.strip(" ") != "-")):
                    tmp_name += "_" + bit.mIndex.strip(" ")
                if tmp_name not in bit_duplicated_check:
                    bit_duplicated_check.append(tmp_name)
                    tmp_var_decl += self.indent[1] + "uint " + self.AddedSpaces(tmp_name,"string")
                    if reg.mFactorIndex != []:
                        tmp_var_decl += "[" + str(max(reg.mFactorIndex) + 1) + "];\n"
                    elif reg.mFactorEnd != "":
                        tmp_var_decl += "[" + str(reg.mFactorEnd - reg.mFactorStart + 1) + "];\n"
                    else:
                        tmp_var_decl += ";\n"
        string += tmp_var_decl
        return string

    def PrintFactorLoop(self, RegInstName, FactorStart, IsFactorIndex):
        string = ""
        if IsFactorIndex :
            string += self.indent[1] + "for(uint i = 0; i < emNUM_" + RegInstName + "; i++) {\n"
            string += self.indent[2] + "str_tmp.str(\"\");\n"
            string += self.indent[2] + "str_tmp<<\"" + RegInstName + "\"<< mFactorIndex" + RegInstName + "[i];\n"
        else:
            string += self.indent[1] + "for(uint i = 0; i < emNUM_" + RegInstName + "; i++) {\n"
            string += self.indent[2] + "str_tmp.str(\"\");\n"
            string += self.indent[2] + "str_tmp<<\"" + RegInstName + "\"<< i"
            if (FactorStart == 0):
                string += ";\n"
            else:
                string += " + " + str(FactorStart) + ";\n"

        return string

    def PrintRegInstance(self): # [Source code generating] Print re_register instantiation
        string = ""
        str_tmp = ""
        for reg in self.mRegisterTable:
            if (reg.mIndex != ""): # "group" index existed
                reg_name = self.AddedSpaces(reg.mRegname,"regname") + "[" + self.AddedSpaces(reg.mIndex,"index") + "]"
                reg_name_str = reg.mRegInstName
                reg_name_str = "\"" + reg_name_str + "\"" + " "*(len(reg_name) - len(reg_name_str))
            else:
                reg_name = self.AddedSpaces(reg.mRegname,"regname") + " "*(self.mMaxlenIndex)
                reg_name_str = reg.mRegInstName
                reg_name_str = "\"" + reg_name_str + "\"" + " "*(len(reg_name) - len(reg_name_str))
            reg_addr = "0x" + "{:04X}".format(reg.mOffset)
            if (reg.mFactorStep != ""):
                factor_step = int(reg.mFactorStep)
            else:
                factor_step = int(int(reg.mLength)/8)
            if reg.mFactorIndex != [] :
                str_tmp += self.PrintFactorLoop(reg.mRegInstName, 0, True)
                str_tmp += self.indent[2] + reg_name + "[mFactorIndex" + reg.mRegInstName + "[i]] = new vpcl::re_register("
                str_tmp += "(" + reg_addr + ") + "  # To avoid decimal fraction expression
                if (factor_step != 1):
                    str_tmp += str(factor_step) + "*"
                if min(reg.mFactorIndex) == 0:
                    str_tmp += "mFactorIndex" + reg.mRegInstName + "[i]"
                    str_tmp += ", this, str_tmp.str(), name.c_str());\n"
                else:
                    str_tmp += "(mFactorIndex" + reg.mRegInstName + "[i]"
                    str_tmp += "-" + str(min(reg.mFactorIndex)) + "), this, str_tmp.str(), name.c_str());\n"
                str_tmp += self.indent[1] + "}\n"
            elif reg.mFactorEnd != "":
                str_tmp += self.PrintFactorLoop(reg.mRegInstName, reg.mFactorStart, False)
                str_tmp += self.indent[2] + reg_name + "[i] = new vpcl::re_register("
                str_tmp += "(" + reg_addr + ") + " # To avoid decimal fraction expression
                if (factor_step != 1):
                    str_tmp += str(factor_step) + "*"
                str_tmp += "i, this, str_tmp.str(), name.c_str());\n"
                str_tmp += self.indent[1] + "}\n"
            else:
                string += self.indent[1] + reg_name + " = new vpcl::re_register(" + reg_addr + ", this, " + reg_name_str + ", name.c_str());\n"
        if str_tmp != "":
            string += self.indent[1] + "std::ostringstream str_tmp;\n"
            string += str_tmp
        return string

    def PrintRegPointerDefine(self, access_size): # [Source code generating] Print block define pointer list for registers  # Son added
        string = ""
        RegisterTable = sorted(self.mRegisterTable, key=lambda Register: Register.mOffset, reverse=False)   # Sort register based on the address offset
        string =  self.indent[1] + "uint index = 0;\n"
        string += self.indent[1] + "mRegMap = new uint [1<<" + str(access_size) + "];\n"
        string += self.indent[1] + "for (uint i = 0; i < (1<<" + str(access_size) + "); i++) {\n"
        string += self.indent[2] + "mRegMap[i] = (1<<" + str(access_size) + ");\n"
        string += self.indent[1] + "}\n\n"
        for reg in RegisterTable:
            factor_list = []
            if ((reg.mFactorIndex == []) and (reg.mFactorStart != "")):
                mem_index = reg.mFactorStart
                while mem_index <= reg.mFactorEnd:
                    factor_list.append(mem_index)
                    mem_index += 1
            else:
                factor_list = reg.mFactorIndex
            if (reg.mFactorStep != ""):
                factor_step = int(reg.mFactorStep)
            else:
                factor_step = int(int(reg.mLength)/8)
            reg_addr = "0x" + "{:04X}".format(reg.mOffset)
            if reg.mFactorIndex != []:
                addr_tmp = "(" + reg_addr + ")     + "  # To avoid decimal fraction expression
                str_tmp  = ""
                if min(reg.mFactorIndex) == 0:
                    str_tmp += "mFactorIndex" + reg.mRegInstName + "[i]"
                else:
                    str_tmp += "(mFactorIndex" + reg.mRegInstName + "[i]"
                    str_tmp += "-" + str(min(reg.mFactorIndex)) + ")"
                if (factor_step != 1):
                    str_tmp += "*" + str(factor_step)
                string += self.indent[1] + "for(uint i = 0; i < emNUM_" + self.AddedSpaces(reg.mRegInstName + ";","regname") + " i++) {\n"
                string += self.indent[2] + "mRegMap[" + addr_tmp + str_tmp + "] = index"
                if int(int(reg.mLength)/8) == 1:
                    string += "++;\n"
                else :
                    string += ";\n"
                    for index in range(1,int(int(reg.mLength)/8)):
                        addr_tmp = "(" + reg_addr + " + " + str(index) + ") + "
                        string += self.indent[2] + "mRegMap[" + addr_tmp + str_tmp + "] = index"
                        if index == (int(int(reg.mLength)/8) - 1):
                            string += "++"
                        string += ";\n"
                string += self.indent[1] + "}\n"
            elif reg.mFactorEnd != "":
                string += self.indent[1] + "for(uint i = 0; i < emNUM_" + self.AddedSpaces(reg.mRegInstName + ";","regname") + " i++) {\n"
                string += self.indent[2] + "mRegMap[(0x" + "{:04X}".format(reg.mOffset) + ")     + i*" + "{: <2}".format(str(reg.mFactorStep)) + "] = index"
                if int(int(reg.mLength)/8) == 1:
                    string += "++;\n"
                else :
                    string += ";\n"
                    for index in range(1,int(int(reg.mLength)/8)):
                        string += self.indent[2] + "mRegMap[(0x" + "{:04X}".format(reg.mOffset) + " + " + str(index) + ") + i*" + "{: <2}".format(str(reg.mFactorStep)) + "] = index"
                        if index == (int(int(reg.mLength)/8) - 1):
                            string += "++"
                        string += ";\n"
                string += self.indent[1] + "}\n"
            else:
                string += self.indent[1] + "mRegMap[0x" + "{:04X}".format(reg.mOffset) + "]     = index"
                if int(int(reg.mLength)/8) == 1:
                    string += "++;\n"
                else :
                    string += ";\n"
                    for index in range(1,int(int(reg.mLength)/8)):
                        string += self.indent[1] + "mRegMap[0x" + "{:04X}".format(reg.mOffset) + " + " + str(index) + "] = index"
                        if index == (int(int(reg.mLength)/8) - 1):
                            string += "++"
                        string += ";\n"
        string += self.indent[1] + "mTotalRegNum = index;\n"
        string += self.indent[1] + "mRegArray = new SRegList* [mTotalRegNum];\n"
        string += self.indent[1] + "index = 0;\n"
        tmp_cnt = 0
        for reg in RegisterTable:
            channel = reg.mIndex.strip(" ")
            if reg.mFactorIndex != []:
                channel = "mFactorIndex" + self.AddedSpaces(reg.mRegInstName,"regname") + "[i]"
            elif reg.mFactorEnd != "":
                channel = "i"
            else:
                if (channel == ""):
                    channel = "0"
            if (reg.mIndex != ""): # "group" index existed
                reg_name = self.AddedSpaces(reg.mRegname,"regname") + "[" + self.AddedSpaces(reg.mIndex,"index") + "]"
            else :
                reg_name = self.AddedSpaces(reg.mRegname,"regname") + " " + self.AddedSpaces("","index") + " "
            reg_length = int(int(reg.mLength)/8)
            if (reg.mWrSize != ""):
                access_size_wr = "{:>9}".format("\"" + reg.mWrSize + "\"")
            else:
                access_size_wr = "{:>9}".format("\"" + reg.mSize + "\"")
            if (reg.mRdSize != ""):
                access_size_rd = "{:>9}".format("\"" + reg.mRdSize + "\"")
            else:
                access_size_rd = "{:>9}".format("\"" + reg.mSize + "\"")
            if tmp_cnt == 0:
                defined_content  = self.AddedSpaces(channel,"index") + ", " + "{:>2}".format(reg_length) + ", " + access_size_wr + ", " + access_size_rd + ", false, &cwmem);\n" #thanh add
                string += "#ifdef CWR_SYSTEMC\n"
                if reg.mFactorIndex != []:
                    string += self.indent[1] + "for(uint i = 0; i < emNUM_" + self.AddedSpaces(reg.mRegInstName,"regname") + "; i++) "
                    string += "mCurReg = mRegArray[index++] = new SRegList(" + reg_name + "[" + channel + "], mCurReg, "
                    string += defined_content
                elif reg.mFactorEnd != "":
                    string += self.indent[1] + "for(uint i = 0; i < emNUM_" + self.AddedSpaces(reg.mRegInstName,"regname") + "; i++) "
                    string += "mCurReg = mRegArray[index++] = new SRegList(" + reg_name + "[" + channel + "], mCurReg, "
                    string += defined_content
                else:
                    string += self.indent[1] + "mCurReg = mRegArray[index++] = new SRegList(" + reg_name + ", mCurReg, "
                    string += defined_content
                string += "#else\n"
            defined_content  = self.AddedSpaces(channel,"index") + ", " + "{:>2}".format(reg_length) + ", " + access_size_wr + ", " + access_size_rd + ");\n"
            if reg.mFactorIndex != []:
                string += self.indent[1] + "for(uint i = 0; i < emNUM_" + self.AddedSpaces(reg.mRegInstName,"regname") + "; i++) "
                string += "mCurReg = mRegArray[index++] = new SRegList(" + reg_name + "[" + channel + "], mCurReg, "
                string += defined_content
            elif reg.mFactorEnd != "":
                string += self.indent[1] + "for(uint i = 0; i < emNUM_" + self.AddedSpaces(reg.mRegInstName,"regname") + "; i++) "
                string += "mCurReg = mRegArray[index++] = new SRegList(" + reg_name + "[" + channel + "], mCurReg, "
                string += defined_content
            else:
                string += self.indent[1] + "mCurReg = mRegArray[index++] = new SRegList(" + reg_name + ", mCurReg, "
                string += defined_content
            if tmp_cnt == 0:
                string += "#endif\n"
            tmp_cnt = 1
        return string

    def PrintBitCbFuncList(self, BitTable): # [Source code generating] Replace %%LIST_BIT_CB_FUNC%% with list declaration of bits' callback function
        string = ""
        wr_cb_str = ""
        rd_cb_str = ""
        str_factor = ""
        cb_bit_name = []
        cb_bit_factor_name = []
        list_cb_bit = {}
        list_factor_bit_str = {}
        for bit in BitTable:
            cb_info = ["",""]
            reg_name_str = "\"" + bit.mRegInstName.strip(" ") + "\""
            if (bit.mIsWriteCb or bit.mIsReadCb) : # for reg_wr, and bit support write call-back function
                bit_name = "[" + self.AddedSpaces(reg_name_str,"regname") + "][" + self.AddedSpaces("\"" + bit.mBitname + "\"","regname") + "]"
                if bit.mIsWriteCb:
                    cb_info[0] = "Wr"
                if bit.mIsReadCb:
                    cb_info[1] = "Rd"
                list_cb_bit[bit_name] = [cb_info,bit.mCbFuncname,bit.mRegInstName,bit.mBitname,bit.mFactor]
                cb_bit_name.append(bit_name)

        for cb_bit in cb_bit_name:
            [Operation, CbFuncname, RegInstName, Bitname, Factor] = list_cb_bit[cb_bit]
            if (Operation[0] == "Wr") or (Operation[1] == "Rd"):
                if Factor[2] != [] or Factor[1] != "":
                    if RegInstName not in list_factor_bit_str:
                        list_factor_bit_str[RegInstName] = ["",["",""], Factor[0]]
                        cb_bit_factor_name.append(RegInstName)
                if Factor[2] != [] or Factor[1] != "":
                    if Factor[2] != [] :
                        list_factor_bit_str[RegInstName][0] = True
                    else:
                        list_factor_bit_str[RegInstName][0] = False
                    bit_name = "[str_tmp.str()][\"" + Bitname + "\"]"
                    if Operation[0] == "Wr":
                        str_factor = self.indent[2] + "mWrCbAPI" + bit_name + " = &C%%MODULE_NAME%%_regif::" + CbFuncname + ";\n"
                        list_factor_bit_str[RegInstName][1][0] += str_factor
                    if Operation[1] == "Rd":
                        str_factor = self.indent[2] + "mRdCbAPI" + bit_name + " = &C%%MODULE_NAME%%_regif::" + CbFuncname + ";\n"
                        list_factor_bit_str[RegInstName][1][1] += str_factor
                else:
                    if Operation[0] == "Wr":
                        str_tmp = self.indent[1] + "mWrCbAPI" + cb_bit + " = &C%%MODULE_NAME%%_regif::" + list_cb_bit[cb_bit][1] + ";\n"
                        wr_cb_str += str_tmp
                    if Operation[1] == "Rd":
                        str_tmp = self.indent[1] + "mRdCbAPI" + cb_bit + " = &C%%MODULE_NAME%%_regif::" + list_cb_bit[cb_bit][1] + ";\n"
                        rd_cb_str += str_tmp
        string += wr_cb_str
        if wr_cb_str != "":
            string += "\n"
        string += rd_cb_str
        if rd_cb_str != "":
            string += "\n"
        for factor in cb_bit_factor_name:
                string += CRegisterTable.PrintFactorLoop(self, factor, list_factor_bit_str[factor][2], list_factor_bit_str[factor][0])
                for cb_factor in list_factor_bit_str:
                    if (factor == cb_factor) and (list_factor_bit_str[cb_factor][1][0] != ""):
                        string += list_factor_bit_str[cb_factor][1][0]
                for cb_factor in list_factor_bit_str:
                    if (factor == cb_factor) and (list_factor_bit_str[cb_factor][1][1] != ""):
                        string += list_factor_bit_str[cb_factor][1][1]
                string += self.indent[1] + "}\n"

        return string.strip("\n")

    def PrintScmlMemDecl(self): # [Source code generating] Print scml member variable declaration content for CoWare  # Son added
        string = ""
        reg_list = []
        reg_list_name = []
        for reg in self.mRegisterTable:
            if reg.mFactorIndex != []:
                reg_name = reg.mRegInstName + "[" + str(len(reg.mFactorIndex)) + "]"
            elif reg.mFactorEnd != "":
                reg_name = reg.mRegInstName + "[" + str(reg.mFactorEnd - reg.mFactorStart + 1) + "]"
            else:
                reg_name = reg.mRegInstName
            reg_list_name.append(reg_name)
            reg_list.append([reg_name, int(reg.mLength)/8])
        self.StringAlignment(reg_list_name)
        if self.mCwmemDecl > 0 :
                string  = self.indent[1] + "#ifdef CWR_SYSTEMC\n"
                string += self.indent[1] + "%%CWR_MEM_TYPE%% cw_rd_cb(tlm::tlm_generic_payload& trans, int tag);\n"
                string += self.indent[1] + "%%CWR_MEM_TYPE%% cw_wr_cb(tlm::tlm_generic_payload& trans, int tag);\n"
                string += self.indent[1] + "virtual void cw_set_callback_reg(scml2::reg<REG_TYPE> * reg, int offset);\n"
                string += self.indent[1] + "void cw_set_all_callback_reg(void);\n"
                string += self.indent[1] + "#endif"
        return string

    def PrintFactorIndexDeclare(self): # [Source code generating] Print factor index declaration  # Son added
        string = ""
        for reg in self.mRegisterTable:
            if (reg.mFactorIndex != []):
                string += self.indent[1] + "uint mFactorIndex" + reg.mRegInstName + "[emNUM_" + reg.mRegInstName + "];\n"
        return string

    def PrintInitLocalVal(self): # [Source code generating] Print function InitLocalVal to initialize local variables  # Son added
        string = "// Initialize local variables\n"
        for reg in self.mRegisterTable:
            str_tmp = ""
            if reg.mFactorIndex != []:
                str_tmp = "mFactorIndex" + reg.mRegInstName + "[i]"
                string += self.indent[1] + "for(uint i = 0; i < emNUM_" + self.AddedSpaces(reg.mRegInstName + ";","regname") + " i++) {\n"
            elif reg.mFactorEnd != "":
                string += self.indent[1] + "for(uint i = 0; i < emNUM_" + self.AddedSpaces(reg.mRegInstName + ";","regname") + " i++) {\n"
            for bit in reg.mBitInfo: # print bit variable declaration
                tmp_name = bit.mRegname.strip(" ") + "_" + bit.mBitname 
                if ((bit.mIndex.strip(" ") != "") and (bit.mIndex.strip(" ") != "-")):
                    tmp_name += "_" + bit.mIndex.strip(" ")
                if reg.mFactorIndex != []:
                    string += self.indent[2] + self.AddedSpaces(tmp_name,"string") + "[" + str_tmp + "] = 0x" + "{:X}".format(bit.mInit) + ";\n"
                elif reg.mFactorEnd != "":
                    string += self.indent[2] + self.AddedSpaces(tmp_name,"string") + "[i] = 0x" + "{:X}".format(bit.mInit) + ";\n"
                else:
                    string += self.indent[1] + self.AddedSpaces(tmp_name,"string") + " = 0x" + "{:X}".format(bit.mInit) + ";\n"
            if reg.mFactorIndex != []:
                string += self.indent[1] + "}\n"
            elif reg.mFactorEnd != "":
                string += self.indent[1] + "}\n"
        return string.strip("\n")

    def PrintUpdateLocalVal(self): # [Source code generating] Print function UpdateLocalVal to update local variables  # Son added
        string = ""
        i = 0
        for reg in self.mRegisterTable:
            if (reg.mIndex != ""): # "group" index existed
                reg_name = self.AddedSpaces(reg.mRegname,"regname") + "[" + self.AddedSpaces(reg.mIndex,"index") + "]"
                reg_name_str = reg.mRegInstName
                reg_name_str = "\"" + reg_name_str + "\"" + " "*(len(reg_name) - len(reg_name_str))
            else:
                reg_name = self.AddedSpaces(reg.mRegname,"regname") + " "*(self.mMaxlenIndex)
                reg_name_str = reg.mRegInstName
                reg_name_str = "\"" + reg_name_str + "\"" + " "*(len(reg_name) - len(reg_name_str))
            reg_offset = "0x" + "{:04X}".format(reg.mOffset)
            if (i != 0):
                string += self.indent[1]
            string += "if ("
            offset_reg = ""
            reg_alternative_factor_index = 0
            if reg.mFactorIndex != []:
                reg_start_addr  = reg.mOffset
                reg_end_addr    = reg.mOffset + max(reg.mFactorIndex)*reg.mFactorStep
                string += "(" + reg_offset + " <= addr) && (addr <= (" + reg_offset + ")+(" + str(reg.mFactorStep) + "*" + str(max(reg.mFactorIndex) - min(reg.mFactorIndex)) + ")) "
                string += "&& ((addr-" + reg_offset + ")%" + str(reg.mFactorStep) + " == 0) "
                if (int(min(reg.mFactorIndex)) != 0):
                    offset_reg = " + " + str(min(reg.mFactorIndex))
                for tmp_reg in self.mRegisterTable:
                    if tmp_reg.mFactorIndex != []:
                        tmp_reg_start_addr  = tmp_reg.mOffset
                        tmp_reg_end_addr    = tmp_reg.mOffset + max(tmp_reg.mFactorIndex)*tmp_reg.mFactorStep
                        if (((reg_start_addr < tmp_reg_start_addr) and (tmp_reg_start_addr < reg_end_addr)) or ((reg_start_addr < tmp_reg_end_addr) and (tmp_reg_end_addr < reg_end_addr)) or ((tmp_reg_start_addr < reg_start_addr) and (reg_start_addr < tmp_reg_end_addr))):
                            reg_alternative_factor_index = 1
                            self.mAlterFactorIndexFlag = 1
                            break
                if (reg_alternative_factor_index):
                    string += "&& ChkAddrWithFactorIndex((addr-" + reg_offset + ")/" + str(reg.mFactorStep) + offset_reg + ", mFactorIndex" + reg.mRegInstName + ", " + str(len(reg.mFactorIndex)) +")) {\n"
                else:
                    string += ") {\n"
                string += self.indent[2] + "uint i = (addr - " + reg_offset + ")/" + str(reg.mFactorStep) + offset_reg + ";\n"
                for bit in reg.mBitInfo:
                    tmp_name = bit.mRegname.strip(" ") + "_" + bit.mBitname 
                    if ((bit.mIndex.strip(" ") != "") and (bit.mIndex.strip(" ") != "-")):
                        tmp_name += "_" + bit.mIndex.strip(" ")
                    string += self.indent[2] 
                    string += self.AddedSpaces(tmp_name,"regname",20) + "[i]"
                    string += " = " 
                    string += "(*(" + reg_name + "[i]))[" + self.AddedSpaces("\"" + bit.mBitname + "\"","regname",2) + "]"
                    string += ";\n"
            elif reg.mFactorEnd != "":
                string += "(" + reg_offset + " <= addr) && (addr <= (" + reg_offset + ")+(" + str(reg.mFactorStep) + "*" + str(reg.mFactorEnd - reg.mFactorStart) + ")) "
                string += "&& ((addr-" + reg_offset + ")%" + str(reg.mFactorStep) + " == 0)) {\n"
                if (int(reg.mFactorStart) != 0):
                    offset_reg = " + " + str(reg.mFactorStart)
                string += self.indent[2] + "uint i = (addr - " + reg_offset + ")/" + str(reg.mFactorStep) + offset_reg + ";\n"
                for bit in reg.mBitInfo:
                    tmp_name = bit.mRegname.strip(" ") + "_" + bit.mBitname 
                    if ((bit.mIndex.strip(" ") != "") and (bit.mIndex.strip(" ") != "-")):
                        tmp_name += "_" + bit.mIndex.strip(" ")
                    string += self.indent[2]
                    string += self.AddedSpaces(tmp_name,"regname",20) + "[i]"
                    string += " = "
                    string += "(*(" + reg_name + "[i]))[" + self.AddedSpaces("\"" + bit.mBitname + "\"","regname",2) + "]"
                    string += ";\n"
            else :
                string += "addr == " + reg_offset + ") {\n" 
                for bit in reg.mBitInfo:
                    tmp_name = bit.mRegname.strip(" ") + "_" + bit.mBitname 
                    if ((bit.mIndex.strip(" ") != "") and (bit.mIndex.strip(" ") != "-")):
                        tmp_name += "_" + bit.mIndex.strip(" ")
                    string += self.indent[2]
                    string += self.AddedSpaces(tmp_name,"regname",20)
                    string += " = "
                    string += "(*" + reg_name + ")[" + self.AddedSpaces("\"" + bit.mBitname + "\"","regname",2) + "]"
                    string += ";\n"
            string += self.indent[2] + "return;\n"
            string += self.indent[1] + "}\n"
            i = i + 1
        return string.strip("\n")

    def PrintUpdateRegVal(self): # [Source code generating] Print function UpdateRegVal to update registers  # Son added
        string = ""
        i = 0
        for reg in self.mRegisterTable:
            if (reg.mIndex != ""): # "group" index existed
                reg_name = self.AddedSpaces(reg.mRegname,"regname") + "[" + self.AddedSpaces(reg.mIndex,"index") + "]"
                reg_name_str = reg.mRegInstName
                reg_name_str = "\"" + reg_name_str + "\"" + " "*(len(reg_name) - len(reg_name_str))
            else:
                reg_name = self.AddedSpaces(reg.mRegname,"regname") + " "*(self.mMaxlenIndex)
                reg_name_str = reg.mRegInstName
                reg_name_str = "\"" + reg_name_str + "\"" + " "*(len(reg_name) - len(reg_name_str))
            reg_offset = "0x" + "{:04X}".format(reg.mOffset)
            if (i != 0):
                string += self.indent[1]
            string += "if ("
            offset_reg = ""
            reg_alternative_factor_index = 0
            if reg.mFactorIndex != []:
                reg_start_addr  = reg.mOffset
                reg_end_addr    = reg.mOffset + max(reg.mFactorIndex)*reg.mFactorStep
                string += "(" + reg_offset + " <= addr) && (addr <= (" + reg_offset + ")+(" + str(reg.mFactorStep) + "*" + str(max(reg.mFactorIndex) - min(reg.mFactorIndex)) + ")) "
                string += "&& ((addr-" + reg_offset + ")%" + str(reg.mFactorStep) + " == 0) "
                if (int(min(reg.mFactorIndex)) != 0):
                    offset_reg = " + " + str(min(reg.mFactorIndex))
                for tmp_reg in self.mRegisterTable:
                    if tmp_reg.mFactorIndex != []:
                        tmp_reg_start_addr  = tmp_reg.mOffset
                        tmp_reg_end_addr    = tmp_reg.mOffset + max(tmp_reg.mFactorIndex)*tmp_reg.mFactorStep
                        if (((reg_start_addr < tmp_reg_start_addr) and (tmp_reg_start_addr < reg_end_addr)) or ((reg_start_addr < tmp_reg_end_addr) and (tmp_reg_end_addr < reg_end_addr)) or ((tmp_reg_start_addr < reg_start_addr) and (reg_start_addr < tmp_reg_end_addr))):
                            reg_alternative_factor_index = 1
                            break
                if (reg_alternative_factor_index):
                    string += "&& ChkAddrWithFactorIndex((addr-" + reg_offset + ")/" + str(reg.mFactorStep) + offset_reg + ", mFactorIndex" + reg.mRegInstName + ", " + str(len(reg.mFactorIndex)) +")) {\n"
                else:
                    string += ") {\n"
                string += self.indent[2] + "uint i = (addr - " + reg_offset + ")/" + str(reg.mFactorStep) + offset_reg + ";\n"
                for bit in reg.mBitInfo:
                    tmp_name = bit.mRegname.strip(" ") + "_" + bit.mBitname 
                    if ((bit.mIndex.strip(" ") != "") and (bit.mIndex.strip(" ") != "-")):
                        tmp_name += "_" + bit.mIndex.strip(" ")
                    string += self.indent[2] 
                    string += "(*(" + reg_name + "[i]))[" + self.AddedSpaces("\"" + bit.mBitname + "\"","regname",2) + "]"
                    string += " = " 
                    string += tmp_name + "[i]"
                    string += ";\n"
            elif reg.mFactorEnd != "":
                string += "(" + reg_offset + " <= addr) && (addr <= (" + reg_offset + ")+(" + str(reg.mFactorStep) + "*" + str(reg.mFactorEnd - reg.mFactorStart) + ")) "
                string += "&& ((addr-" + reg_offset + ")%" + str(reg.mFactorStep) + " == 0)) {\n"
                if (int(reg.mFactorStart) != 0):
                    offset_reg = " + " + str(reg.mFactorStart)
                string += self.indent[2] + "uint i = (addr - " + reg_offset + ")/" + str(reg.mFactorStep) + offset_reg + ";\n"
                for bit in reg.mBitInfo:
                    tmp_name = bit.mRegname.strip(" ") + "_" + bit.mBitname 
                    if ((bit.mIndex.strip(" ") != "") and (bit.mIndex.strip(" ") != "-")):
                        tmp_name += "_" + bit.mIndex.strip(" ")
                    string += self.indent[2]
                    string += "(*(" + reg_name + "[i]))[" + self.AddedSpaces("\"" + bit.mBitname + "\"","regname",2) + "]"
                    string += " = "
                    string += tmp_name + "[i]"
                    string += ";\n"
            else :
                string += "addr == " + reg_offset + ") {\n" 
                for bit in reg.mBitInfo:
                    tmp_name = bit.mRegname.strip(" ") + "_" + bit.mBitname 
                    if ((bit.mIndex.strip(" ") != "") and (bit.mIndex.strip(" ") != "-")):
                        tmp_name += "_" + bit.mIndex.strip(" ")
                    string += self.indent[2]
                    string += "(*" + reg_name + ")[" + self.AddedSpaces("\"" + bit.mBitname + "\"","regname",2) + "]"
                    string += " = "
                    string += tmp_name
                    string += ";\n"
            string += self.indent[2] + "return;\n"
            string += self.indent[1] + "}\n"
            i = i + 1
        return string.strip("\n")

    def PrintChkAddrWithFactorIndex(self, module_name, onefile): # [Source code generating] Print ChkAddrWithFactorIndex
        string = ""
        if (self.mAlterFactorIndexFlag):
            string += "/// Check address for multiple registers\n"
            string += "/// @return true/false\n"
            if onefile:
                string += "bool ChkAddrWithFactorIndex(cuint num, cuint factor_index[], cuint len)\n{\n"
            else :
                string += "bool C" + module_name + "_regif::ChkAddrWithFactorIndex(cuint num, cuint factor_index[], cuint len)\n{\n"
            string += self.indent[1] + "assert(factor_index != NULL);\n"
            string += self.indent[1] + "for (uint i = 0; i < len; i++) {\n"
            string += self.indent[2] + "if (num == factor_index[i]) {\n"
            string += self.indent[3] + "return true;\n"
            string += self.indent[2] + "}\n"
            string += self.indent[1] + "}\n" + self.indent[1] + "return false;\n"
            string += "}\n\n"
        return string

    def PrintDeclareChkAddrWithFactorIndex(self): # [Source code generating] Print declaration of ChkAddrWithFactorIndex
        string = ""
        if (self.mAlterFactorIndexFlag):
            string += self.indent[1] + "bool ChkAddrWithFactorIndex(cuint num, cuint factor_index[], cuint len);\n"
        return string;

    def PrintScmlMemInit(self, factor): # [Source code generating] Print scml member variable declaration content for CoWare  # Son added
        string = ""
        factor_tmp_str = ""
        factor_array_str = ""
        total_size = 0
        for reg in self.mRegisterTable:
            offset = reg.mOffset
            if (reg.mFactorStep != ""):
                reg_length = int(reg.mFactorStep)
            else:
                reg_length = int(int(reg.mLength)/8)
            if (reg.mFactorIndex != []):
                if factor:
                    # generate factor temp declaration
                    factor_tmp_str += self.indent[1] + "uint FactorIndex_" + reg.mRegInstName + "_tmp[emNUM_" + reg.mRegInstName + "] = { "
                    tmp_str = ""
                    cnt_index = 1
                    for index in reg.mFactorIndex :
                        tmp_str += "{:>3}".format(index) 
                        if cnt_index != len(reg.mFactorIndex):
                            tmp_str += ", "
                        else:
                            factor_tmp_str += tmp_str + "};\n"
                            break
                        if ((cnt_index%15) == 0):
                            tmp_str += "\n" + self.indent[5] + self.indent[5] + self.indent[3]
                        cnt_index += 1
                    # generate factor array
                    factor_array_str += self.indent[1] + "for(uint i = 0; i < emNUM_" + reg.mRegInstName + "; i++) {\n"
                    factor_array_str += self.indent[2] + "mFactorIndex" + reg.mRegInstName + "[i] = FactorIndex_" + reg.mRegInstName +  "_tmp[i];\n"
                    factor_array_str += self.indent[1] + "}\n"
                offset += (max(reg.mFactorIndex) - min(reg.mFactorIndex))*reg_length
            elif (reg.mFactorEnd != ""):
                offset += (reg.mFactorEnd - reg.mFactorStart)*reg_length
            if (offset > total_size):
                total_size = offset
        total_size = offset + (self.mCwmemDecl - (offset % self.mCwmemDecl))
        if not factor:
            if total_size != 0:
                string += self.indent[1] + ", cwmem(\"register\", 0x" + (str(hex(total_size))).upper().replace("0X","") + ")\n"
        else:
            if factor_tmp_str != "":
                string = factor_tmp_str + ""
            if factor_array_str != "":
                string += factor_array_str + "\n"
        return string

class CBitTable:  # stores Table of Bit and generates bit-related source code
    def __init__(self):
        self.mBitTable = []
        self.mWritableValueList = []
        self.indent = []

    def Replace(self, pos, item_list): # Replace a register item with its bits
        old_item = self.mBitTable.pop(pos)
        for item in item_list:
            item.mRegname = old_item.mRegname
            item.mIndex   = old_item.mIndex
            self.mBitTable.insert(pos,item)
            pos = pos + 1

    def GetCbFuncName(self): # read "call-back" field value of each item to update 3 fields (is_wr:boolean, is_rd:boolean, func_name: string of call-back function name)
        for bit in self.mBitTable:
            if (bit.mCallback != ""):
                bit.mCbFuncname = "cb_" + bit.mRegname.strip(" ") + "_" + bit.mBitname
                cb_split = bit.mCallback.split("|")
                if ("W" in cb_split):
                    bit.mIsWriteCb = True
                if ("R" in cb_split):
                    bit.mIsReadCb  = True

    def PrintBitInstance(self): # [Source code generating] Print bit defintion for re_register variables
        string = ""
        str_factor_index = ""
        str_factor = ""
        list_factor_bit_str = {}
        for bit in self.mBitTable:
            if bit.mIndex.startswith("em"):
                regname = bit.mRegname + "[" + bit.mIndex + "]"
            else:
                regname = bit.mRegname + " "*(len(bit.mIndex) + 2)
            bitname = "{:<10}, ".format("\"" + (bit.mBitname).strip() + "\"")
            upper   = "{:>2}, ".format(str(bit.mUpper))
            lower   = "{:>2}, ".format(str(bit.mLower))
            init    = "0x{:<8X}, ".format(bit.mInit)
            if (bit.mOverlap == "true"):
                overlap = ", {:<4}".format(bit.mOverlap)
            else:
                overlap = ""
            if (bit.mSupport == "true"):
                support = "vpcl::SPP_ENABLE"
            else:
                support = "vpcl::SPP_DISABLE"
            access_mode = "{:<8}, ".format("\"" + bit.mAccess + "\"")
            if (bit.mValue != ""):
                writable_value = ", \"" + bit.mValue + "\""
            elif (bit.mOverlap == "true"):
                writable_value = ", \"\""
            else:
                writable_value = ""
            if bit.mFactor[2] != [] or bit.mFactor[1] != "":
                if (bit.mRegInstName not in list_factor_bit_str):
                    list_factor_bit_str[bit.mRegInstName] = ""
            if bit.mFactor[2] != []:
                str_factor_index = self.indent[2] + "(*" + regname + "[mFactorIndex" + bit.mRegInstName + "[i]]) (" + upper + lower + bitname + init + access_mode + support + writable_value + overlap +");\n"
                list_factor_bit_str[bit.mRegInstName] += str_factor_index
            elif bit.mFactor[1] != "":
                str_factor = self.indent[2] + "(*" + regname + "[i]) (" + upper + lower + bitname + init + access_mode + support + writable_value + overlap +");\n"
                list_factor_bit_str[bit.mRegInstName] += str_factor
            else:
                string += self.indent[1] + "(*" + regname + ") (" + upper + lower + bitname + init + access_mode + support + writable_value + overlap +");\n"

        for factor in list_factor_bit_str:
                string += self.indent[1] + "for(uint i = 0; i < emNUM_" + factor + "; i++) {\n"
                string += list_factor_bit_str[factor]
                string += self.indent[1] + "}\n"
        return string

    def PrintCbFuncDeclare(self): # [Source code generating] Print call-back function prototype declaration
        string  = ""
        string_virtual = ""
        duplicated_check = []
        for bit in self.mBitTable:
            if (bit.mCbFuncname != ""):
                if not bit.mCbFuncname in duplicated_check:
                    duplicated_check.append(bit.mCbFuncname)
                    func_string  = "void " + bit.mCbFuncname + "(RegCBstr str)"
                    # function declaration used in "model.h" file
                    string  = string  + self.indent[1] + func_string + ";\n"
                    # pure virtual function declaration used in "model_regif.h" file
                    string_virtual = string_virtual + self.indent[1] + "virtual " + func_string + " = 0;\n"
        return [string, string_virtual]

    def PrintCallbackWrite(self): # [Source code generating] Print the call call-back-write function for bit
        string  = ""
        for bit in self.mBitTable:
            if (bit.mIsWriteCb):
                chk_cb_string = "if ((mWrCbAPI[Register->name()][it->name()]) != NULL) {\n"
                call_string   = self.indent[4] + "(this->*(mWrCbAPI[Register->name()][it->name()]))(RegCBstr(mRegArray[reg_index]->channel, true, size, pre_data, data));\n"
                string = chk_cb_string + call_string + self.indent[3] + "}\n"
                break
        return string.strip("\n")

    def PrintCallbackRead(self): # [Source code generating] Print the call-back read function call for bit
        string  = ""
        define_pre_data = ""
        set_pre_data = ""
        for bit in self.mBitTable:
            if (bit.mIsReadCb):
                loop_string    = self.indent[3] + "for (vpcl::bit_info *it=Register->mBitInfo ; it!=NULL ; it=it->next) {\n"
                chk_cb_string  = self.indent[4] + "if (((mRdCbAPI[Register->name()][it->name()]) != NULL)\n"
                chk_cb_string += self.indent[4] + "&& (((start_pos < it->mStartAddr) && (it->mEndAddr < start_pos + size * 8))\n" 
                chk_cb_string += self.indent[4] + " || ((it->mStartAddr <= start_pos) && (start_pos <= it->mEndAddr))\n"
                chk_cb_string += self.indent[4] + " || ((it->mStartAddr <= start_pos + size * 8) && (start_pos + size * 8 <= it->mEndAddr)) )) {\n"
                call_string    = self.indent[5] + "(this->*(mRdCbAPI[Register->name()][it->name()]))(RegCBstr(mRegArray[reg_index]->channel, false, size, pre_data, pst_data));\n"
                string = loop_string + chk_cb_string + call_string + self.indent[4] + "}\n" + self.indent[3] + "}"
                # Define and set pre_data if ReadCallback existed
                define_pre_data = "uint pre_data = 0;\n"
                set_pre_data = "pre_data = (uint)(*Register);\n"
                break
        return [string, define_pre_data, set_pre_data]

    def GetWritableValueList(self): # Check writable value to add to writable_value_list
        self.mWritableValueList = []
        for bit in self.mBitTable:
            value_only = ""
            if (bit.mWritableStr[0] != ""):
                value = bit.mWritableStr[0]
                value_split = value.split(",")
                for factor in value_split:
                    if (factor != ""):
                        factor_split = factor.split(":")
                        number = factor_split[0]
                        if (len(factor_split) > 2):
                            PrintDbgMsg("ERROR", "\"value\": Too many \":\" in a factor - \"{}\"\n{}".format(factor, PrintMessage([bit.mWritableStr[1], ""])))
                        elif (len(factor_split) == 2): # value = "number:string"
                            string = factor_split[1]
                            if (string == ""):
                                PrintDbgMsg("ERROR", "\"value\": Require string after \":\" - \"{}\"\n{}".format(factor, PrintMessage([bit.mWritableStr[1], ""])))
                            elif (number.count("-") > 0): # skip generating enum if 'number' is a range of value
                                value_only = value_only + number + ","
                            else:
                                self.mWritableValueList.append([number, string, bit.mWritableStr[1]])
                                value_only = value_only + number + ","
                        else: # value = "number"
                            value_only = value_only + number + ","
            bit.mValue = value_only[0:-1]

        # Check and convert number value
        for item in self.mWritableValueList:
            if item[0].startswith("b"):
                item[0] = re.sub("^b", "", item[0])
                try:
                    item[0] = int(item[0],2)
                except ValueError:
                    PrintDbgMsg("ERROR", "\"value\": Illegal binary number value - \"0b{}\"\n{}".format(item[0], PrintMessage([item[2], ""])))
            elif item[0].startswith("0x"):
                try:
                    item[0] = int(item[0],16)
                except ValueError:
                    PrintDbgMsg("ERROR", "\"value\": Illegal hexadecimal number value - \"{}\"\n{}".format(item[0], PrintMessage([item[2], ""])))
            else:
                try:
                    item[0] = int(item[0],10)
                except ValueError:
                    PrintDbgMsg("ERROR", "\"value\": Illegal number value - \"{}\"\n{}".format(item[0], PrintMessage([item[2], ""])))

        # Check to remove duplicate value or name
        list_temp = []
        for item in self.mWritableValueList:
            exist = False
            for exist_item in list_temp:
                if (exist_item[1] == item[1]):
                    if (exist_item[0] != item[0]):
                        PrintDbgMsg("ERROR", "\"value\": Different values are assigned to the same name - \"{}:{}\" and \"{}:{}\"\n{}".format(exist_item[0], exist_item[1], item[0], item[1], PrintMessage([item[2], ""])))
                    else:
                        exist = True
                if (exist_item[0] == item[0]):
                    if (exist_item[1] != item[1]):
                        PrintDbgMsg("ERROR", "\"value\": Different enumeration names have the same value - \"{}:{}\" and \"{}:{}\"\n{}".format(exist_item[0], exist_item[1], item[0], item[1], PrintMessage([item[2], ""])))
                    else:
                        exist = True
            if not exist:
                list_temp.append(item)
        self.mWritableValueList = list_temp

    def PrintWritableValueEnum(self): # [Source code generating] Print enumeration for writable value
        string = ""
        if (self.mWritableValueList != []) :
            string = self.indent[1] + "enum eWriteVal {\n"
            value_str = ""
            for item in self.mWritableValueList:
                value_str += self.indent[2] + item[1] + " = " + str(item[0]) + ", \n"
            string += value_str[0:-3]
            string += "\n" + self.indent[1] + "}; ///< Enumeration for register writing value\n"
        return string

class CRegIFGen: # Main class of RegIF Generator
    def __init__(self):
        self.mInputfileLineList = []
        self.mReg = CRegisterTable()
        self.mBit = CBitTable()
        self.mAccessSize = 0
        self.mInputContent = []
        self.mInputFileName = ""
        self.mWebSimInfo = CWebSim()  # Added Websim
        indent_base = " "*4

        self.indent = ["", indent_base, indent_base*2, indent_base*3, indent_base*4, indent_base*5, indent_base*6] # space indent for source code generation

        self.mReg.indent = self.indent
        self.mBit.indent = self.indent
        self.mCwmemDecl = 0
        self.mDuplicatedInstanceNameCheck = []

    def CreateDataOfRegStruct(self, keyword): #generate data in iodefine_<modelname>.h file
        string = ""
        # Insert copyright
        f_cpy_rgt = open(cpy_rgt_file, "r")
        for line in f_cpy_rgt:
            string += line
        f_cpy_rgt.close()

        # Insert generator and skelton file with the version
        string += "// This file is generated by Register I/F generator\n"
        string += ExtractCVSInfo(work_dir + "/gen_regif.py")
        string += ExtractCVSInfo(work_dir + "/gen_regif_class.py")
        string += ExtractCVSInfo(self.mInputFileName)
        string += "//\n"
        string += "// Input file : " + self.mInputFileName+ "\n"
        string += "/" * 80 + "\n"

        # Insert input file contets
        f_in = open(self.mInputFileName, "r")
        for line in f_in:
            string += "// " + line
        string += "/" * 80 + "\n"

        string += "/// The structure of all registers for " + keyword.upper() + " model\n"
        string += "/// $Id: gen_regif_class.py v2017_04_13 $
        string += "/// $Date"    + "$\n"
        string += "/// $Revison" + "$\n"
        string += "/// $Author"  + "$\n"
        string += "/" * 80 + "\n"

        string += "#ifndef __IODEFINE_" + keyword.upper() + "_H__\n"
        string += "#define __IODEFINE_" + keyword.upper() + "_H__\n"

        string += "struct st_" + keyword.lower() + " {\n"
        list_address = []
        list_register_string = {}
        previous_offset = 0
        index = 0

        dup_reg_check = []
        for reg in self.mReg.mRegisterTable:
            if not reg.mRegInstName in dup_reg_check:
                dup_reg_check.append(reg.mRegInstName)
                declare_bit_string = ""
                reg_string = ""
                num_reserve_bit = 0
                current_point = int(reg.mLength)
                # the declaration part of all bits in a register
                tmp_reg_string = self.indent[1] + "union {\n"
                type_dict = {8:["unsigned char","BYTE"], 16:["unsigned short","WORD"], 32:["unsigned long","LONG"]}
                tmp_reg_string += self.indent[2] + type_dict[int(reg.mLength)][0] + " " + type_dict[int(reg.mLength)][1] + ";\n"
                # declaration part for accessing size less than register's length
                size_list = []
                # write access size
                if (reg.mWrSize != ""):
                    temp_list = reg.mWrSize.split("|")
                else:
                    temp_list = reg.mSize.split("|")
                for acc_size in temp_list:
                    size_list.append(acc_size)
                # read access size
                if (reg.mRdSize != ""):
                    temp_list = reg.mRdSize.split("|")
                else:
                    temp_list = reg.mSize.split("|")
                for acc_size in temp_list:
                    if acc_size not in size_list:
                        size_list.append(acc_size)
                # generate access size list
                size_list = sorted(size_list)
                for acc_size in size_list:
                    if int(acc_size) < int(reg.mLength):
                        tmp_reg_string += self.indent[2] + "struct {\n"
                        for i in range(0,int(int(reg.mLength)/int(acc_size))):
                            tmp_reg_string += self.indent[3] + type_dict[int(acc_size)][0] + " " + type_dict[int(acc_size)][1] + str(i) + ";\n"
                        tmp_reg_string += self.indent[2] + "} " + type_dict[int(acc_size)][1] + "S;\n"
                # the declaration bits structure in a register
                tmp_reg_string += self.indent[2] + "struct {\n"
                for i in reversed(range(0,int(reg.mLength))):
                    # bit CORRESPONDING with position "i" of register
                    for bit in self.mBit.mBitTable:
                        if not (bit.mOverlap == "true"):
                            if (i < current_point) and (bit.mUpper == i) and ((bit.mRegInstName).strip() == (reg.mRegInstName).strip()):
                                # NONE specified bit in register
                                if (bit.mUpper - bit.mLower + 1) == int(reg.mLength):
                                    declare_bit_string += self.indent[3] + type_dict[int(reg.mLength)][0] + " D:" + str(reg.mLength) + ";\n"
                                # SOME specified bits in register
                                else:
                                    if (num_reserve_bit != 0):  # There are some reserve bits before
                                        declare_bit_string += self.indent[3] + type_dict[int(reg.mLength)][0] + " : " + str(num_reserve_bit) + ";\n"
                                    declare_bit_string += self.indent[3] + type_dict[int(reg.mLength)][0] + " " + (bit.mBitname).strip() + " : " + str(bit.mUpper - bit.mLower + 1) + ";\n"
                                current_point = bit.mLower
                                num_reserve_bit = 0
                                break
                    # NONE corresponding
                    if (i < current_point):
                        num_reserve_bit += 1
                if (num_reserve_bit != 0):
                    declare_bit_string += self.indent[3] + type_dict[int(reg.mLength)][0] + " : " + str(num_reserve_bit) + ";\n"
                tmp_reg_string += declare_bit_string + self.indent[2] + "} BIT;\n"

                # Get the list of register's factor
                factor_list = []
                if ((reg.mFactorIndex == []) and (reg.mFactorStart != "")):
                    mem_index = reg.mFactorStart
                    while mem_index <= reg.mFactorEnd:
                        factor_list.append(mem_index)
                        mem_index += 1
                else:
                    factor_list = reg.mFactorIndex
                #Non factor
                if (factor_list == []):
                    reg_string = tmp_reg_string + self.indent[1] + "} " + reg.mRegInstName + ";\n"
                    if not reg.mOffset in list_address:
                        list_address.append(reg.mOffset)
                        list_register_string[int(reg.mOffset)] = [reg_string,int(int(reg.mLength)/8), reg.mRegInstName]
                        if int(int(reg.mLength)/8) < self.mReg.mCwmemDecl:
                            self.mReg.mOffsetList.append(reg.mOffset)
                            self.mReg.mRegDict[reg.mOffset] = ["", reg]
                    else:
                        PrintDbgMsg("WARNING", "The address of " + reg.mRegInstName + " is same with address of " + list_register_string[reg.mOffset][2], False)
                    if (int(reg.mOffset)%(int(reg.mLength)/8)) != 0:
                        PrintDbgMsg("ERROR", "\"{}\": Illegal offset address \"0x{:X}\" or length \"{}\" - Offset address must be a multiple of length.\n".format(reg.mRegInstName, int(reg.mOffset), int(reg.mLength)))
                else:#factor
                    for factor_index in factor_list:
                        offset_member = (reg.mFactorStep * (factor_index - min(factor_list))) + reg.mOffset
                        reg_instance_name = reg.mRegInstName + str(factor_index)
#                        reg_instance_name = reg.mRegInstName # TODO
                        reg_string = tmp_reg_string + self.indent[1] + "} " + reg_instance_name + ";\n"
                        if not offset_member in list_address:
                            list_address.append(offset_member)
                            list_register_string[int(offset_member)] = [reg_string,int(int(reg.mLength)/8), reg_instance_name]
                            if int(int(reg.mLength)/8) < self.mReg.mCwmemDecl:
                                self.mReg.mOffsetList.append(offset_member)
                                self.mReg.mRegDict[offset_member] = [factor_index, reg]
                        else:
                            PrintDbgMsg("WARNING", "The address of " + reg_instance_name + " is same with address of " + list_register_string[offset_member][2], False)
                        if (int(reg.mOffset)%(int(reg.mLength)/8)) != 0:
                            PrintDbgMsg("ERROR", "\"{}\": Illegal offset address \"0x{:X}\" or length \"{}\" - Offset address must be a multiple of length.\n".format(reg.mRegInstName + "[" + str(factor_index) + "]", int(offset_member), int(reg.mLength)))
        # Combine the registers which of length less than maximum register's length for CoWare
        self.mReg.mOffsetList = sorted(self.mReg.mOffsetList)
        is_combine = False
        comb_reg_item = CCwCombineRegItem("", 0, [])
        reg_cnt = 0
        for addr in self.mReg.mOffsetList:
            reg_cnt += 1
            reg_name = self.mReg.mRegDict[addr][1].mRegname
            reg_instance_name = self.mReg.mRegDict[addr][1].mRegInstName
            ins_name = reg_name
            reg_factor_index = str(self.mReg.mRegDict[addr][0])
            reg_index = self.mReg.mRegDict[addr][1].mIndex
            if reg_index != "":
                ins_name += "_" + str(reg_index)
            if reg_factor_index != "":
                ins_name = ins_name + "_" + reg_factor_index
            factor_info = [reg_factor_index, self.mReg.mRegDict[addr][1].mFactorStart, self.mReg.mRegDict[addr][1].mFactorEnd, self.mReg.mRegDict[addr][1].mFactorIndex]
            start_bit = (addr%self.mReg.mCwmemDecl)*8
            reg_length = self.mReg.mRegDict[addr][1].mLength
            comb_addr = addr - addr%self.mReg.mCwmemDecl
            if not is_combine:
                comb_reg_item = CCwCombineRegItem(ins_name, comb_addr, [[reg_name, factor_info, start_bit, reg_length, reg_index, reg_instance_name]])
            else:
                if comb_reg_item.mCombAddr + self.mReg.mCwmemDecl > addr:
                    comb_reg_item.mCombRegName += "_" + ins_name
                    comb_reg_item.mCombRegList.append([reg_name, factor_info, start_bit, reg_length, reg_index, reg_instance_name])
                else:
                    self.AppendCombReg(comb_reg_item, self.mReg.mCwCombRegList, self.mReg.mCwCombRegNameList)
                    comb_reg_item = CCwCombineRegItem(ins_name, comb_addr, [[reg_name, factor_info, start_bit, reg_length, reg_index, reg_instance_name]])
                    if reg_cnt == len(self.mReg.mOffsetList):
                        self.AppendCombReg(comb_reg_item, self.mReg.mCwCombRegList, self.mReg.mCwCombRegNameList)
                    continue
            if (addr + (int(reg_length)/8)) % self.mReg.mCwmemDecl == 0 :
                self.AppendCombReg(comb_reg_item, self.mReg.mCwCombRegList, self.mReg.mCwCombRegNameList)
                is_combine = False
            else:
                if reg_cnt == len(self.mReg.mOffsetList):
                    self.AppendCombReg(comb_reg_item, self.mReg.mCwCombRegList, self.mReg.mCwCombRegNameList)
                is_combine = True

        #print iodefine
        list_address = sorted(list_address)
        for address in list_address:
            if (address - previous_offset) > 0:
                string += self.indent[1] + "unsigned char wk" + str(index) + "[" + "0x" + ("{:0>x}".format(address - previous_offset)).upper() + "];\n"
                index += 1
            if (address - previous_offset) < 0:
                PrintDbgMsg("WARNING", "The address of " + list_register_string[address][2] + " is overlapped", False)
            string += list_register_string[address][0]
            previous_offset = address + list_register_string[address][1]
        string += "};\n"
        string += "#endif // __IODEFINE_" + keyword.upper() + "_H__\n"
        return string

    def AppendCombReg(self, comb_reg_item, comb_reg_list, comb_reg_name_list):
        if len(comb_reg_item.mCombRegList) == 1:
            comb_reg_item.mCombRegName += "_"
        comb_reg_list.append(comb_reg_item)
        for reg in comb_reg_item.mCombRegList:
            check_reg_name = reg[0]
            check_reg_factor_index = reg[1][0]
            check_reg_index = reg[4]
            comb_reg_name_dict_item = CCwCombineRegNameDictItem()
            if check_reg_name not in comb_reg_name_list:
                if check_reg_index == "":
                    if len(comb_reg_item.mCombRegList) > 1:
                        comb_reg_name_dict_item.mCombRegFactorIndexList = [check_reg_factor_index]
                    else:
                        comb_reg_name_dict_item.mCombRegFactorIndexList = []
                else:
                    if len(comb_reg_item.mCombRegList) > 1:
                        comb_reg_name_dict_item.mCombRegIndexDict[check_reg_index] = [check_reg_factor_index]
                    else:
                        comb_reg_name_dict_item.mCombRegIndexDict[check_reg_index] = []
                comb_reg_name_list[check_reg_name] = comb_reg_name_dict_item
            else:
                if check_reg_index == "":
                    if len(comb_reg_item.mCombRegList) > 1:
                        comb_reg_name_list[check_reg_name].mCombRegFactorIndexList.append(check_reg_factor_index)
                else:
                    if check_reg_index not in comb_reg_name_list[check_reg_name].mCombRegIndexDict:
                        if len(comb_reg_item.mCombRegList) > 1:
                            comb_reg_name_list[check_reg_name].mCombRegIndexDict[check_reg_index] = [check_reg_factor_index]
                        else:
                            comb_reg_name_list[check_reg_name].mCombRegIndexDict[check_reg_index] = []
                    else:
                        if len(comb_reg_item.mCombRegList) > 1:
                            comb_reg_name_list[check_reg_name].mCombRegIndexDict[check_reg_index].append(check_reg_factor_index)
            if check_reg_index == "":
                comb_reg_name_list[check_reg_name].mCombRegFactorIndexList = sorted(set(comb_reg_name_list[check_reg_name].mCombRegFactorIndexList))
            else:
                comb_reg_name_list[check_reg_name].mCombRegIndexDict[check_reg_index] = sorted(set(set(comb_reg_name_list[check_reg_name].mCombRegIndexDict[check_reg_index])))

    def CreateDataOfInitRegC(self, keyword): #generate data in <modelname>_initregchk.c file
        string = ""
        # Insert copyright
        f_cpy_rgt = open(cpy_rgt_file, "r")
        for line in f_cpy_rgt:
            string += line
        f_cpy_rgt.close()

        # Insert generator and skelton file with the version
        string += "// This file is generated by Register I/F generator\n"
        string += ExtractCVSInfo(work_dir + "/gen_regif.py")
        string += ExtractCVSInfo(work_dir + "/gen_regif_class.py")
        string += ExtractCVSInfo(self.mInputFileName)
        string += "//\n"
        string += "// Input file : " + self.mInputFileName+ "\n"
        string += "/" * 80 + "\n"

        # Insert input file contets
        f_in = open(self.mInputFileName, "r")
        for line in f_in:
            string += "// " + line
        string += "/" * 80 + "\n"

        string += "/// @file " + keyword.lower() + "_initregchk.c\n"
        string += "/// @brief Check the initial value of all registers for " + keyword.upper() + " model\n"
        string += "/// $Id: gen_regif_class.py v2017_04_13 $
        string += "/// $Date"    + "$\n"
        string += "/// $Revison" + "$\n"
        string += "/// $Author"  + "$\n"
        string += "/" * 80 + "\n"

        string += "#ifndef __" + keyword.upper() + "_INITREGCHK_C__\n"
        string += "#define __" + keyword.upper() + "_INITREGCHK_C__\n\n"
        string += "#include \"iodefine_" + keyword.lower() + ".h\"\n"
        string += "#include \"common.h\"\n\n"
        string += "// Please define the model base address in the line below\n"
        string += "#define " + keyword.upper() + "_BASE 0x0\n"
        string += "#define " + keyword.upper() + " (*(volatile struct st_" + keyword.lower() + " *)" + keyword.upper() + "_BASE" + ")\n"
        string += "int main() {\n"
        string += self.indent[1] + "cpu_setup();\n"
        for reg in self.mReg.mRegisterTable:
            type_dict = {8:"BYTE", 16:"WORD", 32:"LONG"}
            reg_initial_value = self.GetRegInitialValue(reg.mRegInstName)
            front_chk_string = "if (" + keyword.upper() + "."
            end_chk_string = "." + type_dict[int(reg.mLength)] + " != "

            if int(int(reg.mLength)/4) == 2:
                end_chk_string += "0x" + ("{:0>2x}".format(reg_initial_value)).upper() + ") { fail_bp(); }\n"
            elif int(int(reg.mLength)/4) == 4:
                end_chk_string += "0x" + ("{:0>4x}".format(reg_initial_value)).upper() + ") { fail_bp(); }\n"
            else:
                end_chk_string += "0x" + ("{:0>8x}".format(reg_initial_value)).upper() + ") { fail_bp(); }\n"
            # Get the list of register's factor
            factor_list = []
            if ((reg.mFactorIndex == []) and (reg.mFactorStart != "")):
                mem_index = reg.mFactorStart
                while mem_index <= reg.mFactorEnd:
                    factor_list.append(mem_index)
                    mem_index += 1
            else:
                factor_list = reg.mFactorIndex
            
            if (factor_list == []):
                string += self.indent[1] + front_chk_string + reg.mRegInstName + end_chk_string
            else:
                for factor_index in factor_list:
                    reg_instance_name = reg.mRegInstName + str(factor_index)
#                    reg_instance_name = reg.mRegInstName #TODO
                    string += self.indent[1] + front_chk_string + reg_instance_name + end_chk_string
        string += self.indent[1] + "pass_bp();\n"
        string += "}\n"
        string += "#endif // __" + keyword.upper() + "_INITREGCHK_C__\n"
        return string

    def CreateMetadata(self): #generate data in C<modelname>_metadata.py file
        string = "import vlab\n"
        string += "bus = vlab.bus(name=\"m_tgt_sockets\", dim=1, kind=\"target\", width=32)\n"
        same_factor_list = []
        reg_single_list = []
        for reg in self.mReg.mRegisterTable:
            if reg.mFactorEnd != "":
                if same_factor_list != [] :
                    is_factor_match = False
                    for item in same_factor_list:
                        if reg.mFactorStart == item.mFactorStart and reg.mFactorEnd == item.mFactorEnd:
                            item.mRegList.append(reg)
                            is_factor_match = True
                            break
                    if not is_factor_match:
                        same_reg_item = CSameFactorRegisterItem(reg.mFactorStart, reg.mFactorEnd,[reg])
                        same_factor_list.append(same_reg_item)
                else:
                    same_reg_item = CSameFactorRegisterItem(reg.mFactorStart, reg.mFactorEnd,[reg])
                    same_factor_list.append(same_reg_item)
            elif reg.mFactorIndex != [] :
                if (max(reg.mFactorIndex) - min(reg.mFactorIndex)) == (len(reg.mFactorIndex) - 1) and len(reg.mFactorIndex) > 1:
                    if same_factor_list != [] :
                        is_factor_match = False
                        for item in same_factor_list:
                            if min(reg.mFactorIndex) == item.mFactorStart and max(reg.mFactorIndex) == item.mFactorEnd:
                                item.mRegList.append(reg)
                                is_factor_match = True
                                break
                        if not is_factor_match:
                            same_reg_item = CSameFactorRegisterItem(min(reg.mFactorIndex), max(reg.mFactorIndex),[reg])
                            same_factor_list.append(same_reg_item)
                    else:
                        same_reg_item = CSameFactorRegisterItem(min(reg.mFactorIndex), max(reg.mFactorIndex),[reg])
                        same_factor_list.append(same_reg_item)
                else:
                    reg_single_list.append(reg)
            else:
                reg_single_list.append(reg)
        for item in same_factor_list:
            if (int(item.mFactorStart) == 0):
                string +=  "for i in range(" + str(int(item.mFactorEnd) + 1) + "):\n"
            else:
                string +=  "for i in range(" + str(item.mFactorStart) + ", " + str(int(item.mFactorEnd) + 1) + "):\n"
            for reg in item.mRegList:
                string += "    vlab.register(\"" + self.mReg.AddedSpaces(reg.mRegInstName + "_%d\"%(i)","regname", 13) 
                string += ", offset=(0x" + "{:04X}".format(reg.mOffset) + ")+i*0x" + "{: <4X}".format(reg.mFactorStep)
                string += ", width=" + "{: <2d}".format(int(reg.mLength))
                string += ", block=(bus,0))\n"

        for reg in reg_single_list:
            if reg.mFactorIndex != [] :
                for index in reg.mFactorIndex:
                    string += "vlab.register(\"" + self.mReg.AddedSpaces(reg.mRegInstName + "_" + str(index) + "\"","regname", 10) 
                    offset_member = (reg.mFactorStep * (index - min(reg.mFactorIndex))) + reg.mOffset
                    string += ", offset=0x" + "{:04X}".format(offset_member)
                    string += ", width=" + "{: <2d}".format(int(reg.mLength))
                    string += ", block=(bus,0))\n"
            else:
                string += "vlab.register(\"" + self.mReg.AddedSpaces(reg.mRegInstName + "\"","regname", 10) 
                string += ", offset=0x" + "{:04X}".format(reg.mOffset)
                string += ", width=" + "{: <2d}".format(int(reg.mLength))
                string += ", block=(bus,0))\n"
        return string

    def LineProcess(self, line): # Read a line, split arguments and store in a list
        line_pre = []
        for arg in line:
            if (arg == "-"):
                num = ""
            else:
                num = arg
            line_pre.append(num)
        return line_pre

    def ReadFile(self, filename): # Read input file to import register information to 'mInputfileLineList'
        try:
            f = open(filename,  "r")
            file_lines = f.readlines()
            f.close()
        except IOError:
            PrintDbgMsg("ERROR","Input file not found: " + filename)
        self.mInputContent = file_lines
        self.mInputFileName = filename
        line_num = 1 # line number
        for line in file_lines:
            line = line[0:-1]   # remove "\n" character
            line_split = line.split('\"')
            if (len(line_split) > 3):
                PrintDbgMsg("ERROR", "Too many \" in a line. None or two \" (for \"writable value string\") expected\n"+ PrintMessage([(line_num,filename),""]) + line)
            elif (len(line_split) > 1):
                line_split[1] = line_split[1].replace(" ","") # remove all spaces between " " (writable data)
                line = ""
                for str_temp in line_split:
                    line = line + str_temp

            line_split = line.split()
            i = 0
            arg_line = []   # arguments in a line
            while (i < len(line_split)) and (not line_split[i].startswith("#")): # remove comment content (begin with "#")
                arg_line.append(line_split[i])
                i = i + 1
            if (arg_line != []):
                if (not arg_line[0].startswith("%")):
                    PrintDbgMsg("ERROR", "Expected control keyword at the beginning of line:\n" + PrintMessage([(line_num,filename),""]) + line)
                arg_line = self.LineProcess(arg_line)
                # check argurment of title  # Son added
                defined_title = ("%%TITLE","name","offset","size","wsize","rsize","length","group","callback","init","access","support","offset_start","offset_skip","offset_times","upper","lower","value","reg_name","factor_start","factor_end","factor_index","factor_step", "overlap")
                if (arg_line[0] == "%%TITLE"):
                    for title in arg_line:
                        if title not in defined_title:
                            PrintDbgMsg("ERROR", "Wrong title name :\"" + title + "\".\n" + PrintMessage([(line_num,filename),""]) + line)

                arg_line.append(line_num) # store line number
                arg_line.append(filename) # Son added
                self.mInputfileLineList.append(arg_line)
            line_num = line_num + 1

    def FindModule(self, module_list): # return the number of the line which contains %MODULE keyword
        module_line_list = []
        if (module_list == []): # No "-module" argument
            module_name = ""
            start = -1
            i = 0
            for line in self.mInputfileLineList:
                if (line[0] == "%MODULE"):
                    if (len(line) < 4):
                        PrintDbgMsg("ERROR", "Require a name after %MODULE.\n" + PrintMessage([line,""]))
                    if (len(line) > 4):
                        PrintDbgMsg("ERROR", "More than one name after %MODULE. Only one is expected.\n" + PrintMessage([line,""]))
                    if (start == -1):
                        start = i
                        line_num = line[-2]
                    else:
                        end = i
                        module_line_list.append([start, end, module_name, line_num])
                        start = end
                    module_name = line[1]
                i = i + 1
            if (start != -1):
                module_line_list.append([start, len(self.mInputfileLineList), module_name, line_num])
            else:
                PrintDbgMsg("WARNING", "No %MODULE found in input description file(s)!", False)
        else:
            for module_name in module_list:
                start = -1
                end = -1
                i = 0
                for line in self.mInputfileLineList:
                    if (line[0] == "%MODULE"):
                        if (len(line) < 4):
                            PrintDbgMsg("ERROR", "Require a name after %MODULE.\n" + PrintMessage([line,""]))
                        if (len(line) > 4):
                            PrintDbgMsg("ERROR", "More than one name after %MODULE. Only one is expected.\n" + PrintMessage([line,""]))
                        if (line[1] == module_name):
                            start = i
                            line_num = line[-2]
                    if ((start != -1) and (end == -1)): # found %MODULE <module_name>
                        if ((line[0] == "%MODULE") and (line[1] != module_name)):
                            end = i
                            module_line_list.append([start, end, module_name, line_num])
                        elif (i == len(self.mInputfileLineList)-1):
                            module_line_list.append([start, len(self.mInputfileLineList), module_name, line_num])
                    i = i + 1
                if (start == -1):
                    PrintDbgMsg("WARNING", "Module specified by user [ {} ] not found in input description file(s).".format(module_name), False)
        return module_line_list

    def GetFactor (self, factor_start, factor_end, factor_index, info_line = []): # Get factor index of register
        factor_index_map = []
        if (factor_start != ""):
            factor_start = NumberConvert(factor_start,"factor_start", info_line)
            if (factor_end != ""):
                factor_end = NumberConvert(factor_end, "factor_end", info_line)
            else:
                PrintDbgMsg("ERROR", "\"factor_end\" - Numeric value is expected. {}\n{}".format(factor_end, PrintMessage(info_line)))
        else:
            if (factor_end != ""):
                factor_start = 0;
                factor_end = NumberConvert(factor_end, "factor_end", info_line)
        if factor_start > factor_end :
            PrintDbgMsg("ERROR", "\"factor_start\" - factor_start must be equal or smaller than factor_end. {}\n{}".format(factor_end, PrintMessage(info_line)))
        if (factor_start != "") and (factor_end != ""): # Add index if factor_start and factor_end existed
            if factor_index != "":
                factor_index += ","
            factor_index += str(factor_start) + "-" + str(factor_end)
        if (factor_index != ""):
            factor_index_split = factor_index.split(",")
            factor_split = []
            for factor in factor_index_split:
                index_split = factor.split("-")
                if len(index_split) == 1:
                    factor_split.append(NumberConvert(index_split[0], "factor_index", info_line))
                elif len(index_split) == 2:
                    index_start = NumberConvert(index_split[0], "factor_index", info_line)
                    index_end   = NumberConvert(index_split[1], "factor_index", info_line) + 1
                    if index_start > index_end:
                        PrintDbgMsg("ERROR", "\"factor_index\" - invalid factor_index range. {}\n{}".format(factor_end, PrintMessage(info_line)))
                    for index in list(range(index_start, index_end)):
                        factor_split.append(index)
                else:
                    PrintDbgMsg("ERROR", "\"factor_index\": Too many \"-\" in a factor - \"{}\"\n{}".format(factor_index, PrintMessage(info_line)))
            if (len(factor_split) != len(set(factor_split))):
                    PrintDbgMsg("ERROR", "\"factor_index\": Duplicated factor index - \"{}\"\n{}".format(factor_index, PrintMessage(info_line)))
            if max(factor_split) == (len(factor_split) - 1) and min(factor_split) == 0:
                factor_start = 0
                factor_end = max(factor_split)
            else:
                factor_index_map = sorted(factor_split);
                factor_start = ""
                factor_end = ""
        return [factor_start, factor_end, factor_index_map]


    def GetOffsetList(self, offset_info, info_line): # return list of all address offset from [offset_start, offset_skip, offset_times]
        [offset_start, offset_skip, offset_times] = offset_info

         # check and convert offset values
        offset_start = NumberConvert(offset_start,"offset_start", info_line)
        offset_skip  = NumberConvert(offset_skip, "offset_skip", info_line)
        offset_times   = NumberConvert(offset_times, "offset_times", info_line)

        if (offset_skip == 0):
            PrintDbgMsg("ERROR","\"offset_skip\" must not be zero.\n" + PrintMessage(info_line))
        if (offset_times == 0):
            PrintDbgMsg("ERROR","\"offset_times\" must not be zero.\n" + PrintMessage(info_line))

        # Convert offset_times, offset_skip into offset_end
        offset_end = offset_start + offset_times*offset_skip   # Son added

        return range(offset_start, offset_end, offset_skip)

    def GetRegChannel(self, module_part, channel_name): # find the "%REG_CHANNEL <channel_name>" line and get its %% content
        i = 0
        for line in module_part:
            i = i + 1
            if (line[0] == "%REG_CHANNEL"):
                if (len(line) < 4):
                    PrintDbgMsg("ERROR", "Require a name after %REG_CHANNEL.\n" + PrintMessage([line,""]))
                if (len(line) > 4):
                    PrintDbgMsg("ERROR", "More than one name after %REG_CHANNEL. Only one is expected.\n" + PrintMessage([line,""]))
                if (line[1] == channel_name):
                    reg_channel_info = []
                    while ((i < len(module_part)) and (module_part[i][0].startswith("%%"))):
                        reg_channel_info.append(module_part[i])
                        i = i + 1
                    return reg_channel_info
        return None

    def GetRegInitialValue(self, reg_name):#get the initial value of register
        reg_value = 0
        for reg in self.mReg.mRegisterTable:
            if (reg.mRegInstName == reg_name):
                current_point = int(reg.mLength)
                for i in reversed(range(0,int(reg.mLength))):
                    # bit CORRESPONDING with position "i" of register
                    for bit in self.mBit.mBitTable:
                        if (i < current_point) and (bit.mUpper == i) and ((bit.mRegInstName).strip() == (reg.mRegInstName).strip()):
                            reg_value |= (bit.mInit) << (bit.mLower)
                            current_point = bit.mLower
        return reg_value


    def GetField(self, info_list, search_title, info_type = "REG"): # Get field position in a %% content (info_list). Field name specified by "search_title"
    # example of "search_title": "name", "size" ...

        pos = -1
        if (info_list[0][0] == "%%TITLE"):
            i = 0
            for title in info_list[0]:
                if (title == search_title):
                    pos = i
                i = i + 1
        else: # no "%%TITLE" line
            if (info_type == "REG"):
                default_order = {"name": 1, "offset": 2, "size": 3, "length": 4, "group": 5, "callback": 6, "init": 7, "access": 8, "support": 9, "offset_start":10, "offset_skip":11, "offset_times":12, "factor_start":13, "factor_end":14, "factor_index":15, "factor_step":16, "wsize":17, "rsize":18, "reg_name":19}
            if (info_type == "BIT"):
                default_order = {"name": 1, "upper": 2, "lower": 3, "init": 4, "access": 5, "support": 6, "callback": 7, "value": 8, "overlap":9}
            pos = default_order[search_title]
            if (pos >= (len(info_list[0]) - 2)): # no value
                pos = -1
        return pos

    def CreateRegItem(self, info_list, hier_mode, hier_name): # create a list of register info items to add or update to Register Table.
    # "info_list" contains all %% lines of a %REG_INSTANCE
    #   ['%%TITLE'       ,'name' ,'group','offset','size',....]
    #   ['%%REG'         ,'CMSTR','-'    ,'0x02'  ,'16  ',....]
    #   ['%%REG'         ,'CMCNT','-'    ,'0x04'  ,'16  ',....]
    #   ['%%REG'         , ....]
    #   ['%%REG_INSTANCE', 'ch'  ,'-'    , ....]
    #   [....]
    # Register item format: [name, channel_index, size, length, address offset, is_reg_instance(True/False), bit info]

        RegItem_list = []

        if (info_list[0][0] == "%%TITLE"):
            info_list_no_title = info_list[1:len(info_list)]
        else:
            info_list_no_title = info_list[:]

        for line in info_list_no_title:
            if (line[0] == "%%TITLE"):
                PrintDbgMsg("ERROR", "%%TITLE not at the top of %REG_CHANNEL list:\n" + PrintMessage([line,""]))
        for line in info_list_no_title:
            if not line[0] in ["%%REG", "%%REG_INSTANCE", "%%TITLE"]:
                PrintDbgMsg("ERROR", "Expected %%REG or %%REG_INSTANCE at the beginning of line:\n" + PrintMessage([info_list[0],line]))
            if (len(line) != len(info_list[0])):
                PrintDbgMsg("ERROR","Number of arguments not match with %%TITLE line.\n" + PrintMessage([info_list[0], line]))
            index = ""
            size = "32"
            wsize = ""
            rsize = ""
            length = "32"
            instname = "";
            if (self.GetField(info_list, "name") != -1):
                name = line[self.GetField(info_list, "name")]
            else:
                PrintDbgMsg("ERROR", "%REG_CHANNEL - Require \"name\":\n" + PrintMessage([info_list[0],""]))
            if not (hier_mode):
                if (self.GetField(info_list, "reg_name") != -1):       # Get instance name of register # Son added
                    instname = line[self.GetField(info_list, "reg_name")]
                if (self.GetField(info_list, "group") != -1):           # Get and check group information in "flat" type # Son added
                    index_temp = str(line[self.GetField(info_list, "group")])
                    check_flag = 0
                    if (index_temp != "") :
                        if (re.match("[0-9]+$", index_temp) != None):
                            check_flag = self.CheckGroupSetting(RegItem_list, name, index_temp, 1)
                        elif (re.match("[0-9]+_[0-9]+$", index_temp) != None):
                            check_flag = self.CheckGroupSetting(RegItem_list, name, index_temp, 2)
                        else:
                            PrintDbgMsg("ERROR", "%REG_CHANNEL - Invalid setting for \"group\":\n" + PrintMessage([info_list[0],line]))
                    if (check_flag == -1):
                        PrintDbgMsg("ERROR", "%REG_CHANNEL - Duplicated setting for \"group\":\n" + PrintMessage([info_list[0],line]))
                    elif (check_flag == -2):
                        PrintDbgMsg("ERROR", "%REG_CHANNEL - Mixed setting is not allowed for \"group\":\n" + PrintMessage([info_list[0],line]))
                    else:
                        index = index_temp
            if (self.GetField(info_list, "size") != -1):
                size_temp = line[self.GetField(info_list, "size")]
                if (size_temp != ""): # empty 'size'
                    size = size_temp
            if (self.GetField(info_list, "wsize") != -1):
                size_temp = line[self.GetField(info_list, "wsize")]
                if (size_temp != ""): # empty 'wsize'
                    wsize = size_temp
            if (self.GetField(info_list, "rsize") != -1):
                size_temp = line[self.GetField(info_list, "rsize")]
                if (size_temp != ""): # empty 'wsize'
                    rsize = size_temp
            if (self.GetField(info_list, "length") != -1):
                length_temp = line[self.GetField(info_list, "length")]
                if (length_temp != ""): # empty 'length'
                    length = NumberConvert(length_temp, "length", [info_list[0],line])

            if (line[0] == "%%REG_INSTANCE"):
                sub_hier_name = ""
                offset_start = "0"
                offset_skip  = "65536" # default value = 0x10000
                offset_times = "1"     # default value = 1
                if (self.GetField(info_list, "name") != -1): # Name of hierachy channel
                    hier_name_temp = line[self.GetField(info_list, "name")]
                    if (hier_name_temp != ""):
                        sub_hier_name = hier_name_temp
                    else:
                        sub_hier_name = "ch"
                if (self.GetField(info_list, "offset") != -1): # 'offset' can be used if 'offset_start' not provided
                    offset_start_temp = line[self.GetField(info_list, "offset")]
                    if (offset_start_temp != ""):
                        offset_start = offset_start_temp
                if (self.GetField(info_list, "offset_start") != -1):
                    offset_start_temp = line[self.GetField(info_list, "offset_start")]
                    if (offset_start_temp != ""):
                        offset_start = offset_start_temp
                if (self.GetField(info_list, "offset_times") != -1):
                    offset_times_temp = line[self.GetField(info_list, "offset_times")]
                    if (offset_times_temp != ""):
                        offset_times = offset_times_temp
                if (self.GetField(info_list, "offset_skip") != -1):
                    offset_skip_temp = line[self.GetField(info_list, "offset_skip")]
                    if (offset_skip_temp != ""):
                        offset_skip = offset_skip_temp

                offset_list = self.GetOffsetList([offset_start, offset_skip, offset_times], [info_list[0],line]) # Get address list of a channel
                i = 0
                for addr in offset_list:
                    Item = CRegisterItem(sub_hier_name, "", name, "", str(i), size, wsize, rsize, length, addr, "", "", "", "", True, [], [])
                    self.CheckLegalRegData(RegItem_list, Item, [info_list[0], line]) # check legality of register info item (script stops in case of illegal data)
                    RegItem_list.append(Item)
                    i = i + 1
            elif (line[0] == "%%REG"):
                if (self.GetField(info_list, "offset") != -1):
                    offset = line[self.GetField(info_list, "offset")]
                    if (offset == ""):
                        PrintDbgMsg("ERROR", "%REG_CHANNEL - Require value for \"offset\":\n" + PrintMessage([info_list[0],line]))
                else:
                    PrintDbgMsg("ERROR", "%REG_CHANNEL - Require \"offset\":\n" + PrintMessage([info_list[0],""]))
                offset = NumberConvert(offset, "offset", [info_list[0],line])

                factor_start = ""
                factor_end = ""
                factor_step = ""
                factor_index_tmp = ""
                factor_step_tmp = ""#Add to fix error "assigned before declare"
                if (self.GetField(info_list, "factor_index") != -1):
                    factor_index_tmp = line[self.GetField(info_list, "factor_index")]
                if (self.GetField(info_list, "factor_start") != -1):
                    factor_start = line[self.GetField(info_list, "factor_start")]
                if (self.GetField(info_list, "factor_end") != -1):
                    factor_end = line[self.GetField(info_list, "factor_end")]
                [factor_start, factor_end, factor_index] = self.GetFactor(factor_start, factor_end, factor_index_tmp, [info_list[0],line])
                if self.GetField(info_list, "factor_step") != -1:
                    factor_step_tmp = line[self.GetField(info_list, "factor_step")]
                    if factor_step_tmp == "":
                        factor_step_tmp = int(int(length)/8)
                    else:
                        factor_step_tmp = NumberConvert(factor_step_tmp,"factor_step", [info_list[0],line])
                    if factor_step_tmp == 0:
                        PrintDbgMsg("ERROR", "%REG_CHANNEL - \"factor_step\" must be greater than 0: \n" + PrintMessage([info_list[0],line]))
                else:
                    factor_step_tmp = int(int(length)/8)
                if (factor_end != "") or (factor_index != []):
                    factor_step = factor_step_tmp
                offset = NumberConvert(offset, "offset", [info_list[0],line])
                hier_inst_name = ""
                if not (hier_mode):     # In hierachy mode, instance name is set later if not existed
                    if (instname == ""):
                        if (index != "") :
                            instname = name + "_" + index
                        else :
                            instname = name
                else:
                    if (self.GetField(info_list, "reg_name") != -1):       # Get instance name of register # Son added
                        hier_inst_name = line[self.GetField(info_list, "reg_name")]
                        
                if not (hier_mode):
                    if (instname in self.mDuplicatedInstanceNameCheck):
                        PrintDbgMsg("ERROR", "\"name\": Duplicated register instance name declaration.\n" + PrintMessage([info_list[0], line]))
                    elif (instname != ""):
                        self.mDuplicatedInstanceNameCheck.append(instname)
                Item = CRegisterItem(hier_name, hier_inst_name, name, instname, index, size, wsize, rsize, length, offset, factor_start, factor_end, factor_index, factor_step, False, self.GetRegBitInfo(info_list, line), [])
                self.CheckLegalRegData(RegItem_list, Item, [info_list[0], line]) # check legality of register info item (script stops in case of illegal data)
                RegItem_list.append(Item)
        for reg in RegItem_list:
            if int((int(reg.mLength)/8)) > self.mCwmemDecl:
                self.mCwmemDecl = int((int(reg.mLength)/8))
                if self.mCwmemDecl == 4:
                    break
        return RegItem_list

    def CheckGroupSetting(self, RegItem_list, Name, Index, GroupHier):  # Check "group" setting from %%REG line # Son added
    # return  0 : valid setting
    # return -1 : duplicated group setting
    # return -2 : mixed group setting
        if (GroupHier == 1):
            CheckPattern = re.compile ("[0-9]+$")
        elif(GroupHier == 2):
            CheckPattern = re.compile ("[0-9]+_[0-9]+$")
        for pre_reg in RegItem_list:
            if (pre_reg.mRegname == Name):
                if (CheckPattern.match(str(pre_reg.mIndex)) != None):
                    Index = Index.split("_")
                    PreIndex = pre_reg.mIndex.split("_")
                    for temp in list(range(GroupHier)):
                        if (int(Index[temp]) != int(PreIndex[temp])):
                            return (0)
                    return (-1)
                else:
                    return (-2)
        return (0)

    def GetRegBitInfo(self, info_list, reg_line):  # Get bit info from %%REG line
    # bit info: [initial value, access, support, callback]
        init = "0"
        access = "W|R"
        support = "TRUE"
        callback = ""
        if (self.GetField(info_list, "init") != -1):
            init_temp = reg_line[self.GetField(info_list, "init")]
            if (init_temp != ""): # empty "init"
                init = init_temp
        if (self.GetField(info_list, "access") != -1):
            access_temp = reg_line[self.GetField(info_list, "access")]
            if (access_temp != ""): # empty "access"
                access = access_temp
        if (self.GetField(info_list, "support") != -1):
            support_temp = reg_line[self.GetField(info_list, "support")]
            if (support_temp != ""): # empty "support"
                support = support_temp
        if (self.GetField(info_list, "callback") != -1):
            callback = reg_line[self.GetField(info_list, "callback")]
        # Check legality of bit data
        BitItem = CBitItem("", "", "", "bitname", 0, 0, init, "", support, ["","",[],""],callback, [""], "")
        self.CheckLegalBitData(BitItem, [info_list[0], reg_line]) # (script stops in case of illegal data)
        init = NumberConvert(init) # convert 'init' to number
        return [init, access.upper(), support.lower(), callback.upper()]

    def CheckLegalRegData(self, RegItem_list, Item, info_line): # check legality of register info item before update to Register Table
        [name, instname, index, size, wsize, rsize, length, address] = [Item.mRegname, Item.mRegInstName, Item.mIndex, Item.mSize, Item.mWrSize, Item.mRdSize, Item.mLength, Item.mOffset]
        self.CheckNameFormat(name, info_line)

        for reg in RegItem_list :
            if ((name == reg.mRegname) and (index == reg.mIndex)) :
                PrintDbgMsg("ERROR", "\"name\": Duplicated register name.\n{}".format(PrintMessage(info_line)))
        length = int(length)
        if (not (length in [8,16,32])): # length must be 8 or 16 or 32
            PrintDbgMsg("ERROR", "\"length\": Illegal data \"{}\" - One value among (8,16,32) expected.\n{}".format(length, PrintMessage(info_line)))
        # size must contain value(s) in (8,16,32)
        size_list = size.split("|")
        for value in size_list:
            try:
                value = int(value)
                if (not (value in [8,16,32])):
                    PrintDbgMsg("ERROR", "\"size\": Illegal data \"{}\" - Value(s) among (8,16,32) expected.\n{}".format(size, PrintMessage(info_line)))
            except ValueError:
                PrintDbgMsg("ERROR", "\"size\": Illegal data \"{}\" - Numeric value expected.\n{}".format(size, PrintMessage(info_line)))
        # wsize must contain value(s) in (8,16,32)
        if (wsize != ""):
            size_list = wsize.split("|")
            for value in size_list:
                try:
                    value = int(value)
                    if (not (value in [8,16,32])):
                        PrintDbgMsg("ERROR", "\"wsize\": Illegal data \"{}\" - Value(s) among (8,16,32) expected.\n{}".format(wsize, PrintMessage(info_line)))
                except ValueError:
                    PrintDbgMsg("ERROR", "\"wsize\": Illegal data \"{}\" - Numeric value expected.\n{}".format(wsize, PrintMessage(info_line)))
        # rsize must contain value(s) in (8,16,32)
        if (rsize != ""):
            size_list = rsize.split("|")
            for value in size_list:
                try:
                    value = int(value)
                    if (not (value in [8,16,32])):
                        PrintDbgMsg("ERROR", "\"rsize\": Illegal data \"{}\" - Value(s) among (8,16,32) expected.\n{}".format(rsize, PrintMessage(info_line)))
                except ValueError:
                    PrintDbgMsg("ERROR", "\"rsize\": Illegal data \"{}\" - Numeric value expected.\n{}".format(rsize, PrintMessage(info_line)))

    def GetRegName(self, module_part, reg_name, reg_ins_name, check_duplicate_index, check_duplicate_reg): # find the "%REG_NAME <reg_name>" line and get its %% content
        i = 0
        is_exist = False
        for line in module_part:
            i = i + 1
            if (line[0] == "%REG_NAME"):
                if (len(line) < 4):
                    PrintDbgMsg("ERROR", "Require a name after %REG_NAME.\n" + PrintMessage([line,""]))
                if (len(line) > 4):
                    PrintDbgMsg("ERROR", "More than one name after %REG_NAME. Only one is expected.\n" + PrintMessage([line,""]))
                if (line[1] == reg_name):
                    if not is_exist:
                        reg_name_info = []
                        if (i not in check_duplicate_index) or (reg_ins_name not in check_duplicate_reg): # One register only has one bit definition
                            is_exist = True
                            while ((i < len(module_part)) and (module_part[i][0].startswith("%%"))):
                                reg_name_info.append(module_part[i])
                                check_duplicate_index.append(i)
                                i = i + 1
                            check_duplicate_reg.append(reg_ins_name)
                            return reg_name_info
                    else: # One register only has one bit definition
                        PrintDbgMsg("WARNING", "More than one bit definition for one register. The first one is used.\n" + PrintMessage([line,""]), False)
        return None

    def CreateBitItem(self, info_list, RegInstName, factor): # create a list bit info items to add or update to Bit Table.
    # "info_list" contains all %% lines of a %REG_NAME
    #   ['%%TITLE','name','upper','lower','init',....]
    #   ['%%BIT'  ,'STR0', 0     , 0     , 0    ,....]
    #   ['%%BIT'  ,'STR1', 1     , 1     , 0    ,....]
    #   ['%%BIT'  , ....]
    #   [....]
    # Register item format: [name, channel_index, size, length, address offset, is_reg_instance(True/False)]

        BitItem_list = []
        if (info_list[0][0] == "%%TITLE"):
            info_list_no_title = info_list[1:len(info_list)]
        else:
            info_list_no_title = info_list[:]

        for line in info_list_no_title:
            if (line[0] == "%%TITLE"):
                PrintDbgMsg("ERROR", "%%TITLE not at the top of %REG_NAME list:\n" + PrintMessage([line,""]))

        for line in info_list_no_title:
            if not line[0] in ["%%BIT", "%%TITLE"]:
                PrintDbgMsg("ERROR", "Expected %%BIT at the beginning of line:\n" + PrintMessage([info_list[0],line]))
            if (len(line) != len(info_list[0])):
                PrintDbgMsg("ERROR","Number of arguments not match with %%TITLE line.\n" + PrintMessage([info_list[0], line]))
            init = "0"
            access = "W|R"
            support = "TRUE"
            callback = ""
            value = ""
            overlap = "FALSE"
            if (self.GetField(info_list, "name","BIT") != -1):
                bitname = line[self.GetField(info_list, "name","BIT")]
                if (bitname == ""):
                    PrintDbgMsg("ERROR", "%BIT - Require value for \"name\":\n" + PrintMessage([info_list[0],line]))
            else:
                PrintDbgMsg("ERROR", "%REG_NAME - Require \"name\":\n" + PrintMessage([info_list[0],""]))
            if (self.GetField(info_list, "upper","BIT") != -1):
                upper = line[self.GetField(info_list, "upper","BIT")]
                if (upper == ""):
                    PrintDbgMsg("ERROR", "%BIT - Require value for \"upper\":\n" + PrintMessage([info_list[0],line]))
            else:
                PrintDbgMsg("ERROR", "%REG_NAME - Require \"upper\":\n" + PrintMessage([info_list[0],""]))
            if (self.GetField(info_list, "lower","BIT") != -1):
                lower = line[self.GetField(info_list, "lower","BIT")]
                if (lower == ""):
                    PrintDbgMsg("ERROR", "%%BIT - Require value for \"lower\":\n" + PrintMessage([info_list[0],line]))
            else:
                PrintDbgMsg("ERROR", "%REG_NAME - Require \"lower\":\n" + PrintMessage([info_list[0],""]))

            if (self.GetField(info_list, "init","BIT") != -1):
                init_temp = line[self.GetField(info_list, "init","BIT")]
                if (init_temp != ""): # empty "init"
                    init = init_temp
            if (self.GetField(info_list, "access","BIT") != -1):
                access_temp = line[self.GetField(info_list, "access","BIT")]
                if (access_temp != ""): # empty "access"
                    access = access_temp
            if (self.GetField(info_list, "support","BIT") != -1):
                support_temp = line[self.GetField(info_list, "support","BIT")]
                if (support_temp != ""): # empty "support"
                    support = support_temp
            if (self.GetField(info_list, "callback","BIT") != -1):
                callback = line[self.GetField(info_list, "callback","BIT")]
            if (self.GetField(info_list, "value","BIT") != -1):
                value = line[self.GetField(info_list, "value","BIT")]
            if (self.GetField(info_list, "overlap","BIT") != -1):
                overlap = line[self.GetField(info_list, "overlap","BIT")]
            if (line[0] == "%%BIT"):
                BitItem = CBitItem("", RegInstName, "", bitname, upper, lower, init, access, support, factor, callback, [value, line], overlap)
                self.CheckLegalBitData(BitItem, [info_list[0], line]) # check legality of bit data (script stops in case of illegal data)
                BitItem = CBitItem("", RegInstName, "", bitname, int(upper), int(lower), init, access.upper(), support.lower(), factor, callback.upper(), [value, line], overlap.lower())
                BitItem_list.append(BitItem)
        return BitItem_list

    def CheckLegalBitData(self, item, info_line): # check legality of bit info item before update to Bit Table
        [bitname, upper, lower, init, support, callback, overlap] = [item.mBitname, item.mUpper, item.mLower, item.mInit, item.mSupport, item.mCallback, item.mOverlap]
        self.CheckNameFormat(bitname, info_line)
        # upper must be integer from 0-32
        try:
            upper = int(upper)
            if not ((upper >= 0) and (upper <= 32)):
                PrintDbgMsg("ERROR", "\"upper\": Illegal data \"{}\" - Value in range 0~32 expected.\n{}".format(upper, PrintMessage(info_line)))
        except ValueError:
            PrintDbgMsg("ERROR", "\"upper\": Illegal data \"{}\" - Numeric value expected.\n{}".format(upper, PrintMessage(info_line)))
        # lower must be integer
        try:
            lower = int(lower)
        except ValueError:
            PrintDbgMsg("ERROR", "\"lower\": Illegal data \"{}\" - Numeric value expected.\n{}".format(lower, PrintMessage(info_line)))
        # upper must be greater than or equal to lower
        if (upper < lower):
            PrintDbgMsg("ERROR", "\"lower\" ({}) greater than \"upper\" ({})\n{}".format(lower, upper, PrintMessage(info_line)))
        # init must be integer
        init = NumberConvert(init, "init", info_line) # check and convert 'init' to number
        # support must be "true" or "false"
        if (not (support.lower() in ["true","false",""])):
            PrintDbgMsg("ERROR", "\"support\": Illegal data \"{}\" - \"true\" or \"false\" expected.\n{}".format(support, PrintMessage(info_line)))
        # overlap must be "TRUE" or "FALSE"
        if (not (overlap.lower() in ["true","false",""])):
            PrintDbgMsg("ERROR", "\"overlap\": Illegal data \"{}\" - \"true\" or \"false\" expected.\n{}".format(overlap, PrintMessage(info_line)))
        # callback must contain string among ("W","R")
        callback_split = callback.split("|")
        for cb_str in callback_split:
            if (not cb_str.upper() in ["W","R",""]):
                PrintDbgMsg("ERROR", "\"callback\": Illegal data \"{}\" - String among (\"W\",\"R\") expected.\n{}".format(callback, PrintMessage(info_line)))

    def CheckNameFormat(self, name, info_line): # check legality of names (module name, register name, bit name)
        if (name == ""):
            PrintDbgMsg("ERROR", "Illegal name \"{}\" - Name was not defined.\n{}".format(name, PrintMessage(info_line)))
        if (re.match("[a-zA-Z0-9_]+$",str(name)) == None):
            PrintDbgMsg("ERROR", "Illegal name \"{}\" - Only alphabetical characters, numbers (0~9) and underscore (_) can be used in naming.\n{}".format(name, PrintMessage(info_line)))
        if re.match("^[0-9]",str(name)):
            PrintDbgMsg("ERROR", "Illegal name \"{}\" - Name cannot start with number.\n{}".format(name, PrintMessage(info_line)))

    def ParseInputFile(self, module_part, hier_mode): # Parse input file to update Register Table and Bit Table
        # Reset Register Table and Bit Table
        self.mReg.mRegisterTable = []
        self.mBit.mBitTable = []

        reg_instance_found = False
        i = 1
        while ((i<len(module_part)-1) and module_part[i][0].startswith("%%") and not reg_instance_found): # find %%REG_INSTANCE in %MODULE
            if (module_part[i][0] == "%%REG_INSTANCE"):
                reg_instance_found = True
                module_reg_instance = module_part[i]
            i = i + 1
        #-------------- REG_VALUE_ID begin --------
        reg_value_id_found = False
        reg_value_id_line = 0
        j = 1
        while ((j<len(module_part)-1) and module_part[j][0].startswith("%")):
            if (module_part[j][0] == "%REG_VALUE_ID"):
                if reg_value_id_found:
                    PrintDbgMsg("ERROR", "Duplicate %REG_VALUE_ID at line {} and {}.".format(module_part[reg_value_id_line][-2], module_part[j][-2]))
                else:
                    reg_value_id_found = True
                    reg_value_id_line = j
            if ((module_part[j][0] == "%REG_NAME") or (module_part[j][0] == "%REG_CHANNEL")):
                if reg_value_id_found:
                    PrintDbgMsg("ERROR", "Unexpected %REG_NAME or %REG_CHANNEL is defined after %REG_VALUE_ID at line {}.".format(module_part[j][-2]))
            j = j + 1
        #-------------- REG_VALUE_ID end --------

        if reg_instance_found:
            ### Update Register Table ###

            # Read %%REG_INSTANCE in %MODULE and insert item to Register Table (fixed-order field titles)
            # Get name
            if (len(module_reg_instance) > 3):
                name = module_reg_instance[1]
            else:
                PrintDbgMsg("ERROR","%MODULE: Require \"name\" after %%REG_INSTANCE.\n" + PrintMessage([module_reg_instance, ""]))
            if (name == ""):
                PrintDbgMsg("ERROR","%MODULE: Require \"name\" after %%REG_INSTANCE.\n" + PrintMessage([module_reg_instance, ""]))
            self.CheckNameFormat(name, [module_reg_instance, ""]) # check the legality of name
            # Get access size
            if ((len(module_reg_instance) > 4) and (module_reg_instance[2] != "")):
                self.mAccessSize = module_reg_instance[2]
            else:
                self.mAccessSize = ""
            if (self.mAccessSize == ""):
                self.mAccessSize = "16"
            try: # check the legality of access size
                access_size = int(self.mAccessSize)
                if not ((access_size >= 1) and (access_size <=32)):
                    PrintDbgMsg("ERROR", "\"offset_size\": Illegal data \"{}\" - Value in range 1~32 expected.\n{}".format(self.mAccessSize, PrintMessage([module_reg_instance, ""])))
            except ValueError:
                PrintDbgMsg("ERROR", "\"offset_size\": Illegal data \"{}\" - Numeric value expected.\n{}".format(self.mAccessSize, PrintMessage([module_reg_instance, ""])))
            hier_name = ""
            if (hier_mode):
                hier_name = name
                # Get offset_start, offset_skip, offset_times
                if (len(module_reg_instance) > 4):
                    offset_start = module_reg_instance[3]
                else:
                    offset_start = ""
                if (len(module_reg_instance) > 5):
                    offset_skip = module_reg_instance[4]
                else:
                    offset_skip   = ""
                if (len(module_reg_instance) > 6):
                    offset_times = module_reg_instance[5]
                else:
                    offset_times  = ""
                if (offset_start == ""):
                    offset_start = "0"
                if (offset_times == ""):   # Son added
                    offset_times = "1"
                if (offset_skip == ""):
                    offset_skip = "65536"

                offset_list = self.GetOffsetList([offset_start, offset_skip, offset_times], [module_reg_instance, ""]) # Get address list of channel
                i = 0
                for address in offset_list:
                    Item = CRegisterItem(hier_name, "", name, "", hier_name + str(i), "", "","", "", address, "", "", "", "", True, [], [])
                    self.mReg.mRegisterTable.append(Item)
                    i = i + 1
            else:
                Item = CRegisterItem(hier_name, "", name, "", "", "", "", "", "", 0, "", "", "", "", True, [], [])
                self.mReg.mRegisterTable.append(Item)

            # Find reg_instance in Register Table and update from corresponding %REG_CHANNEL
            reg_instance_pos = self.mReg.GetRegInstanceItem(); # position of a reg_instance in Register Table
            reg_channel_info = 0
            while ((reg_instance_pos != -1) and (reg_channel_info != -1)):
                reg_channel_info = self.GetRegChannel(module_part, self.mReg.mRegisterTable[reg_instance_pos].mRegname) # corresponding %REG_CHANNEL contents
                if (reg_channel_info):
                    # Update Register Table from %REG_CHANNEL content
                    RegItem_list = self.CreateRegItem(reg_channel_info, hier_mode, self.mReg.mRegisterTable[reg_instance_pos].mRegname)
                    self.mReg.Replace(reg_instance_pos, RegItem_list)
                else:
                    # not found %REG_CHANNEL
                    PrintDbgMsg("ERROR", "%REG_CHANNEL information for \"{}\" not found.".format(self.mReg.mRegisterTable[reg_instance_pos].mRegname))
                reg_instance_pos = self.mReg.GetRegInstanceItem();

            self.mReg.StringAlignment("") # Add spaces to strings for alignment
            if hier_mode:
                for reg in self.mReg.mRegisterTable:
                    if (reg.mHierInstName == ""):
                        if (reg.mRegInstName == ""):
                            reg.mRegInstName = reg.mRegname + "_" + reg.mIndex.replace("em","")
                    else:
                        reg.mRegInstName = reg.mHierInstName + "_" + reg.mIndex.replace("em","")

            ### Update Bit Table ###

            # Transfer from Register Table
            for reg in self.mReg.mRegisterTable:
                bitname = reg.mRegname
                regname  = self.mReg.AddedSpaces(reg.mRegname,"regname")
                instname = self.mReg.AddedSpaces(reg.mRegInstName, "string")  # Son added
                channel  = self.mReg.AddedSpaces(reg.mIndex, "index")
                upper = int(reg.mLength) - 1   # upper = register's length - 1
                lower = 0
                [init, access, support, callback] = reg.mRegInfo
                factor = [reg.mFactorStart, reg.mFactorEnd, reg.mFactorIndex, reg.mFactorStep]
                item = CBitItem(regname, instname, channel, bitname, upper, lower, init, access, support, factor, callback, [""], "")
                self.mBit.mBitTable.append(item)
            self.mReg.mCwmemDecl = self.mCwmemDecl
            # Find for %REG_NAME (bit definition) for each item in Bit Table
            i = 0
            check_duplicate_index = []
            check_duplicate_reg = []
            for reg in self.mBit.mBitTable:
                reg_name_info = self.GetRegName(module_part, reg.mBitname, reg.mRegInstName, check_duplicate_index, check_duplicate_reg) # corresponding %REG_NAME contents

                # Find target register's length
                reg_length = 0
                for reg_info in self.mReg.mRegisterTable:
                    if (reg.mRegname.rstrip() == reg_info.mRegname.strip()):
                        reg_length = int(reg_info.mLength)
                        break
                if (reg_name_info):
                    BitItem_list = self.CreateBitItem(reg_name_info, reg.mRegInstName, reg.mFactor)
                    for bit in BitItem_list:
                        if (int(bit.mUpper) >= reg_length):
                            PrintDbgMsg("ERROR", "%BIT - Upper NG")
                    self.mBit.Replace(i, BitItem_list)
                i = i + 1

            self.mBit.GetCbFuncName()
            self.mBit.GetWritableValueList()
            # Update bits of each registers
            i = 0
            is_wrong_overlap = 0
            for reg in self.mReg.mRegisterTable:
                bit_info = []
                bit_duplicated_check = []
                tmp_reg_length = 0
                tmp_reg_length = int(reg.mLength)
                [init, access, support, callback] = reg.mRegInfo
                factor = [reg.mFactorStart, reg.mFactorEnd, reg.mFactorIndex, reg.mFactorStep]
                tmp_bit  = []
                is_overlap_false = 0
                tmp_cnt = 0
                overlap_pos = 0
                for bit in self.mBit.mBitTable:
                    tmp_cnt += 1
                    if (bit.mRegInstName == reg.mRegInstName) and (bit.mIndex.strip(" ") == reg.mIndex.strip(" ")): 
                        if bit.mBitname not in bit_duplicated_check:
                            bit_duplicated_check.append(bit.mBitname)
                            bit_info.append(bit)
                            tmp_bit = bit
                            ### Check overlap value ###
                            overlap_pos = tmp_cnt
                            if (bit.mOverlap == "true"):
                                if not (tmp_reg_length >= (bit.mUpper - bit.mLower + 1)):
                                    PrintDbgMsg("ERROR", "Bit {}.{}: \"overlap : true\" is defined, bit-width can not greater than register length".format(bit.mRegname, bit.mBitname), False)
                                    is_wrong_overlap = 1
                            else:
                                is_overlap_false = 1
                
                if not (tmp_bit == [] or is_overlap_false):
                    item = []
                    item = CBitItem(tmp_bit.mRegname, tmp_bit.mRegInstName, tmp_bit.mIndex, tmp_bit.mRegname.strip(), tmp_reg_length - 1, 0, init, access, support, factor, callback, "", "false")
                    self.mBit.mBitTable.insert(overlap_pos, item)
                    bit_info.append(item)

                self.mReg.mRegisterTable[i].mBitInfo = bit_info
                i = i + 1

            if is_wrong_overlap:
                return False

            #-------------- REG_VALUE_ID begin --------
            if reg_value_id_found:
                reg_value_id_complete = self.mWebSimInfo.GetInfoFromInput(module_part[reg_value_id_line+1:], self.mBit.mBitTable)
                if not reg_value_id_complete:
                    return False
            #-------------- REG_VALUE_ID end --------

            return True
        else:
            PrintDbgMsg("ERROR", "Not found %%REG_INSTANCE in %MODULE {0}. Skip generating output file for %MODULE {0}.".format(module_part[0][1]), False)
            return False

    def IndentAdjust(self, content, onefile): # Add spaces for code line indent adjustment in -onefile mode
        if onefile:
            content = self.indent[1] + content
            content = content.replace("\n","\n"+ self.indent[1])
        return content

    def GenerateOutputFile(self, onefile, metadata, keyword, module_name): # Read skeleton file, replace strings to generate output source file
        module_name_pre = module_name
        write_flag = False
        while module_name.startswith("C"):
            module_name = re.sub("^C", "", module_name) # omit redundant "C" at the begining of module name
        if (module_name != module_name_pre):
            PrintDbgMsg("INFO", "Module name adjusted to omit redundant \"C\" prefix: " + module_name, False)

        print("Generate output files ...")

        if (keyword == ""):
            keyword = module_name
        # Generate file WITHOUT skeleton file
        iodefine_file = "iodefine_" + keyword.lower() + ".h"
        initregchk_c_file = keyword.lower() + "_initregchk.c"
        metadata_file = "C" + keyword.lower() + "_metadata.py"

        lines_of_iodefine = self.CreateDataOfRegStruct(keyword)
        lines_of_initregchk_c = self.CreateDataOfInitRegC(keyword)
        lines_of_metadata = self.CreateMetadata()
        generating_file_list = [iodefine_file, initregchk_c_file]
        if metadata:
            generating_file_list.append(metadata_file);

        for filename in generating_file_list:
            f_out = None
            write_flag = False
            if (os.path.isfile(filename)) :            # Check existing file
                print ("Are you sure you want to overwrite existing file " + filename + " ? (Y/N) ")
                overwrite = code.InteractiveConsole.raw_input(self, "")
                if ((overwrite == "Y") or (overwrite == "y")):
                    write_flag = True
                    f_out = open(filename, "w")
            else :
                write_flag = True
                f_out = open(filename, "w")
            if write_flag:
                if filename == generating_file_list[0]:   # iodefine_file
                    f_out.writelines(lines_of_iodefine)
                elif filename == generating_file_list[1]:   # initregchk_c_file
                    f_out.writelines(lines_of_initregchk_c)
                else:                                     # metadata_file
                    f_out.writelines(lines_of_metadata)
                print("Finish generating source files:", filename)
                f_out.close()

        # Generate file WITH specified format in skeleton file
        if (onefile):
            skl_file = [one_skl_file, mdl_skl_file]
        else:
            skl_file = [hed_skl_file, src_skl_file, mdl_skl_file]

        for filename in skl_file:
            f_skl = None
            f_out = None
            try:
                f_skl = open(filename, "r")
                file_lines = f_skl.readlines()
                f_skl.close()
                if (filename in [one_skl_file, hed_skl_file]):
                    output_filename = keyword.lower() + "_regif.h"
                elif (filename == src_skl_file):
                    output_filename = keyword.lower() + "_regif.cpp"
                else: # model_templ.skl
                    output_filename = keyword.lower() + ".h"
                if (os.path.isfile(output_filename)) :            # Check existing file   # Son added
                    print ("Are you sure you want to overwrite existing file " + output_filename + " ? (Y/N) ")
                    overwrite = code.InteractiveConsole.raw_input(self, "")
                    if ((overwrite == "Y") or (overwrite == "y")):
                        write_flag = True
                        f_out = open(output_filename, "w")
                    else :
                        continue
                else :
                    write_flag = True
                    f_out = open(output_filename, "w")

            except IOError:
                if f_skl == None:
                    PrintDbgMsg("ERROR", "Skeleton file {} not found.".format(filename))
                if f_out == None:
                    PrintDbgMsg("ERROR", "Cannot create output file " + output_filename)

            output_lines = []
            insert_index = 0

            # Remove skelton's Id
            file_lines.pop(0)   # The first line of skelton file must be Id

            # Insert copyright
            f_cpy_rgt = open(cpy_rgt_file, "r")
            for line in f_cpy_rgt:
                file_lines.insert(insert_index, line)
                insert_index += 1
            f_cpy_rgt.close()

            # Insert generator and skelton file with the version
            file_lines.insert(insert_index, "// This file is generated by Register I/F generator\n"); insert_index += 1
            file_lines.insert(insert_index, ExtractCVSInfo(work_dir + "/gen_regif.py"))             ; insert_index += 1
            file_lines.insert(insert_index, ExtractCVSInfo(work_dir + "/gen_regif_class.py"))       ; insert_index += 1
            file_lines.insert(insert_index, ExtractCVSInfo(filename))                               ; insert_index += 1
            file_lines.insert(insert_index, "//\n" )                                                ; insert_index += 1
            file_lines.insert(insert_index, "// Input file : " + self.mInputFileName+ "\n" )        ; insert_index += 1
            file_lines.insert(insert_index, "/"*80 + "\n" )                                         ; insert_index += 1

            # Insert input file contets
            for line in self.mInputContent:
                if line.find("$Id: gen_regif_class.py v2017_04_13 $
                    # remove keyword to avoid the updating
                    line = line.replace(" Exp $","")
                file_lines.insert(insert_index,"// " + line)
                insert_index += 1
            file_lines.insert(insert_index,"/"*80 + "\n" ); insert_index += 1

            file_lines.insert(insert_index, "/// @file " + output_filename + "\n")                                                     ; insert_index += 1
            file_lines.insert(insert_index, "/// @brief Register IF class of model " + module_name.upper() + "\n") ; insert_index += 1
            file_lines.insert(insert_index, "/// $Id: gen_regif_class.py v2017_04_13 $
            file_lines.insert(insert_index, "/// $Date"    + "$\n")                                                                    ; insert_index += 1
            file_lines.insert(insert_index, "/// $Revison" + "$\n")                                                                    ; insert_index += 1
            file_lines.insert(insert_index, "/// $Author"  + "$\n")                                                                    ; insert_index += 1
            file_lines.insert(insert_index,"/"*80 + "\n" ); insert_index += 1

            for line in file_lines:
                if line.find("%%") != -1 :
                    line = line.replace("%%LIST_BIT_CB_FUNC%%", self.IndentAdjust(self.mReg.PrintBitCbFuncList(self.mBit.mBitTable), onefile))
                    line = line.replace("%%WRITABLE_VALUE%%", self.mBit.PrintWritableValueEnum())
                    line = line.replace("%%MODULE_NAME_UPPER%%", module_name.upper())
                    line = line.replace("%%MODULE_NAME%%", module_name.lower())
                    line = line.replace("%%ADDED_SPACE%%", " "*len(module_name))
                    line = line.replace("%%KEYWORD_LOWER%%", keyword.lower())
                    line = line.replace("%%KEYWORD_UPPER%%", keyword.upper())
                    line = line.replace("%%ENUM_DECLARE%%", self.mReg.PrintEnumDeclare())
                    line = line.replace("%%REGISTER_DECLARE%%", self.mReg.PrintRegDeclare())
                    line = line.replace("%%REGISTER_INSTANCE%%", self.IndentAdjust(self.mReg.PrintRegInstance(), onefile))
                    line = line.replace("%%BIT_DEFINE%%", self.IndentAdjust(self.mBit.PrintBitInstance(), onefile))
                    line = line.replace("%%SCML_MEMBER_DECLARE%%", self.mReg.PrintScmlMemDecl())
                    line = line.replace("%%SCML_MEMBER_INSTANCE%%", self.IndentAdjust(self.mReg.PrintScmlMemInit(False), onefile))
                    line = line.replace("%%SCML_FACTOR_MEMBER_INSTANCE%%", self.IndentAdjust(self.mReg.PrintScmlMemInit(True), onefile))
                    line = line.replace("%%ACCESS_SIZE%%", str(self.mAccessSize))
                    bit_callback_decl = self.mBit.PrintCbFuncDeclare()
                    line = line.replace("%%CALLBACK_DECLARE%%", bit_callback_decl[0])
                    line = line.replace("%%CALLBACK_DECLARE_VIRTUAL%%", bit_callback_decl[1])
                    line = line.replace("%%CALL_CALLBACK_WRITE%%", self.IndentAdjust(self.mBit.PrintCallbackWrite(), onefile))
                    line = line.replace("%%LIST_REGISTER_POINTER_DEFINE%%", self.IndentAdjust(self.mReg.PrintRegPointerDefine(self.mAccessSize), onefile))
                    line = line.replace("%%FACTOR_INDEX_DECL%%", self.mReg.PrintFactorIndexDeclare())
                    line = line.replace("%%INIT_LOCAL_VAL_CONTENT%%", self.IndentAdjust(self.mReg.PrintInitLocalVal(), onefile))
                    line = line.replace("%%UPDATE_LOCAL_VAL_CONTENT%%", self.IndentAdjust(self.mReg.PrintUpdateLocalVal(), onefile))
                    line = line.replace("%%UPDATE_REG_VAL_CONTENT%%", self.IndentAdjust(self.mReg.PrintUpdateRegVal(), onefile))
                    line = line.replace("%%CWR_MEM_TYPE%%", self.mReg.mType[self.mReg.mCwmemDecl])
                    line = line.replace("%%ALTERNATIVE_FACTOR_INDEX%%", self.IndentAdjust(self.mReg.PrintChkAddrWithFactorIndex(module_name, onefile), onefile))
                    line = line.replace("%%ALTERNATIVE_FACTOR_INDEX_DECL%%", self.mReg.PrintDeclareChkAddrWithFactorIndex())
                    read_cb_content = self.mBit.PrintCallbackRead()
                    line = line.replace("%%CALL_CALLBACK_READ%%", self.IndentAdjust(read_cb_content[0], onefile))
                    line = line.replace("%%DEFINE_RD_PRE_DATA%%", read_cb_content[1].strip("\n"))
                    line = line.replace("%%SET_RD_PRE_DATA%%", read_cb_content[2].strip("\n"))
                    #-------------- REG_VALUE_ID begin --------
                    line = line.replace("%%ENUM_CONSTANT_FOR_REG_VALUE_ID%%", self.mWebSimInfo.PrintEnumConstant())
                    line = line.replace("%%INIT_BIT_INFO%%", self.mWebSimInfo.PrintInitBitInfoPtr())
                    line = line.replace("%%BUILD_REG_VALUE_ID_LIB%%", self.mWebSimInfo.PrintRegValueIDLib())
                    #-------------- REG_VALUE_ID end --------

                output_lines.append(line)

            if write_flag:
                f_out.writelines(output_lines)
                print("Finish generating source files:", output_filename)
                f_out.close()

#-------------- REG_VALUE_ID begin --------
class CWebSim:
    def __init__(self):
        self.mCCRegNameList    = []
        self.mCCBitNameList    = []
        self.mCCBitValList     = []
        self.mRegIDList        = []
        self.mNumOfChannel     = 1   # Number of channel, currently fixed 1
        self.mRegIDNum         = 0
        self.mBitnameNum       = 0
        self.mIndent           = [" ", " "*4, " "*8, " "*12, " "*16]

    def GetInfoFromInput(self, websim_part, bit_table):
        regname_line  = -1
        bitname_line  = -1
        cc_regname_list  = []
        cc_bitname_list  = []
        cc_bitval_matrix = []
        cc_regid_column  = []
        cc_bitval_linenum_column = []

        # Get info from input file
        i = 0
        while (i < len(websim_part)):
            if (websim_part[i][0] == "%%REGNAME"):
                if regname_line > -1: # %%REGNAME already exist
                    PrintDbgMsg("ERROR", "%REGVALUEID: More than one %%REGNAME. Only one is expected.\n{}\n{}".format(PrintMessage([websim_part[regname_line], ""]), PrintMessage([websim_part[i], ""])))
                else:
                    if (("REGVALUEID" in websim_part[i]) and (websim_part[i][-3] == "REGVALUEID")): # Define REGVALUEID keyword at the end of line
                        regname_line = i
                        for j in range(1, len(websim_part[i]) - 3):
                            cc_regname_list.append(websim_part[i][j])
                    else:
                        PrintDbgMsg("ERROR", "%REGVALUEID: Expected \"REGVALUEID\" keyword at the end of %%REGNAME line.\n{}".format(PrintMessage([websim_part[i], ""])))

            elif (websim_part[i][0] == "%%BITNAME"):
                if bitname_line > -1: # %%BITNAME already exist
                    PrintDbgMsg("ERROR", "%REGVALUEID: More than one %%BITNAME. Only one is expected.\n{}\n{}".format(PrintMessage([websim_part[bitname_line], ""]), PrintMessage([websim_part[i], ""])))
                else:
                    bitname_line = i
                    for j in range(1, len(websim_part[i]) - 3):
                        cc_bitname_list.append(websim_part[i][j])

            elif (websim_part[i][0] == "%%BITVAL"):
                cc_bitval_row = []
                for j in range(1, len(websim_part[i]) - 3):
                    if (websim_part[i][j] == "-"):
                        cc_bitval_row.append("-1") # store "-" (don't care) as "-1" value
                    else:
                        cc_bitval_row.append(NumberConvert(websim_part[i][j], "%%BITVAL", [websim_part[i], ""]))

                cc_bitval_linenum_column.append(i)  # store the line number for message
                cc_bitval_matrix.append(cc_bitval_row)
                cc_regid_column.append(websim_part[i][-3])
            i = i + 1

        if regname_line == -1: # %%REGNAME not found
            PrintDbgMsg("ERROR", "%REGVALUEID: %%REGNAME not found.")

        if bitname_line == -1: # %%BITNAME not found
            PrintDbgMsg("ERROR", "%REGVALUEID: %%BITNAME not found.")

        if cc_bitval_matrix == []: # %%BITVAL not found
            PrintDbgMsg("ERROR", "%REGVALUEID: %%BITVAL not found.")

        if len(cc_regname_list) != len(cc_bitname_list):
            PrintDbgMsg("ERROR", "%REGVALUEID: Number of fields of %%REGNAME and %%BITNAME do not match.\n{}\n{}".format(PrintMessage([websim_part[regname_line], ""]), PrintMessage([websim_part[bitname_line], ""])))

        for bitval_row in cc_bitval_matrix:
            if len(cc_regname_list) != len(bitval_row):
                pos = cc_bitval_matrix.index(bitval_row)
                PrintDbgMsg("ERROR", "%REGVALUEID: Number of fields of %%REGNAME and %%BITVAL do not match.\n{}\n{}".format(PrintMessage([websim_part[regname_line], ""]), PrintMessage([websim_part[cc_bitval_linenum_column[pos]], ""])))

        # Check whether the defined register name and bit name in input (register info file) is correct
        # Get the list of all bit: [register name, bit name, bit initial value]
        # Note: register with factor definition
        bit_name_list = []
        for bit in bit_table: # self.mBit.mBitTable
            reg_name = bit.mRegInstName.strip()
            regvarname = bit.mRegname
            if bit.mIndex.startswith("em"):
                index_str = bit.mIndex.replace("em","_")
                reg_name = reg_name.replace(index_str, "")
                regvarname += "[" + bit.mIndex.strip() + "]"

            if bit.mFactor[2] != []: # for registers with factor_index
                for factor in bit.mFactor[2]:
                    bit_name_list.append([reg_name + str(factor), bit.mBitname, regvarname + str(factor)])
            elif bit.mFactor[1] != "": # for registers with factor_start, factor_end
                for factor in range(bit.mFactor[0], bit.mFactor[1]+1):
                    bit_name_list.append([reg_name + str(factor), bit.mBitname, regvarname + "[" + str(factor) + "]"])
            else:
                bit_name_list.append([reg_name, bit.mBitname, regvarname])

        cc_regvarname_list = []
        j = 0
        while (j < len(cc_regname_list)):
            bit_found = False
            i = 0
            while ((not bit_found) and (i < len(bit_name_list))): # search the bit list
                if ((cc_regname_list[j] == bit_name_list[i][0]) and (cc_bitname_list[j] == bit_name_list[i][1])):
                    bit_found = True
                    cc_regvarname_list.append(bit_name_list[i][2])
                i = i + 1
            if not bit_found:
                PrintDbgMsg("ERROR", "%REGVALUEID: Bit not found {}[{}].\n{}\n{}".format(cc_regname_list[j], cc_bitname_list[j], PrintMessage([websim_part[regname_line], ""]), PrintMessage([websim_part[bitname_line], ""])))
            j = j + 1

        # Check for duplicate ID in cc_regid_column
        for regid in cc_regid_column:
            if cc_regid_column.count(regid) > 1: # duplicate ID
                first  = cc_regid_column.index(regid)
                second = cc_regid_column.index(regid, first+1)
                if cc_bitval_matrix[first] == cc_bitval_matrix[second]: # bit value are duplicate too
                    PrintDbgMsg("WARNING", "%REGVALUEID: Duplicate %%BITVAL line, consider as one only.\n{}\n{}".format(PrintMessage([websim_part[cc_bitval_linenum_column[first]], ""]), PrintMessage([websim_part[cc_bitval_linenum_column[second]], ""])), False)
                    del cc_bitval_matrix[second]
                    del cc_regid_column[second]
                else:
                    PrintDbgMsg("ERROR", "%REGVALUEID: Duplicate REGVALUEID {}.\n{}\n{}".format(regid, PrintMessage([websim_part[cc_bitval_linenum_column[first]], ""]), PrintMessage([websim_part[cc_bitval_linenum_column[second]], ""])))

        # Update global variable
        self.mCCRegNameList    = cc_regvarname_list 
        self.mCCBitNameList    = cc_bitname_list
        self.mCCBitValList     = cc_bitval_matrix
        self.mRegIDList        = cc_regid_column
        self.mRegIDNum         = len(cc_regid_column)
        self.mBitnameNum       = len(cc_bitname_list)
        return True

    def PrintEnumConstant(self):
        string = ""
        string += self.mIndent[1] + "enum eRegValIDConstant {\n"
        string += self.mIndent[1] + "    emBitNum       = " + str(self.mBitnameNum) + ",\n"
        string += self.mIndent[1] + "    emRegIDNum     = " + str(self.mRegIDNum) + ",\n"
        string += self.mIndent[1] + "    emNumOfChannel = " + str(self.mNumOfChannel) + "\n"
        string += self.mIndent[1] + "};"
        return string

    def PrintInitBitInfoPtr(self):
        string = self.mIndent[1] + "vpcl::bit_info* bit_ref[emBitNum] = { "
        i = 0
        while (i < self.mBitnameNum):
            if i > 0:
                string += self.mIndent[1] + " "*37 + ","
            string +=  "&(*" + self.mCCRegNameList[i] + ")[\"" + self.mCCBitNameList[i] + "\"]\n"
            i = i + 1
        string = string[0:-1] # omit last "\n"
        string += " };\n"
        return string

    def PrintRegValueIDLib(self):
        string = ""
        string += self.mIndent[1] + "int bit_val[emRegIDNum][emBitNum] = { "
        i = 0
        while (i < self.mRegIDNum):
            if i > 0:
                string += self.mIndent[1] + " "*37 + ","
            bit_val_tmp = ""
            for val in self.mCCBitValList[i]:
                bit_val_tmp += str(val) + ","
            bit_val_tmp = bit_val_tmp[0:-1]  # omit last ","
            string += "{" + bit_val_tmp + "}\n"
            i = i + 1
        string = string[0:-1] # omit last "\n"
        string += " };\n\n"

        i = 0
        while (i < self.mRegIDNum):
            string += self.mIndent[1] + "mRegValueIDLib[" + str(i) + "] = strRegValueID(bit_val["+ str(i) + "], \""+ self.mRegIDList[i] +"\");\n"
            i = i + 1
        string = string[0:-1] # omit last "\n"
        return string
#-------------- REG_VALUE_ID end --------
