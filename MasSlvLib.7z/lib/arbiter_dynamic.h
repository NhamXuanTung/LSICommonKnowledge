// $Id: arbiter_dynamic.h v2011_05_12 $
#ifndef __ARBITER_DYNAMIC_H
#define __ARBITER_DYNAMIC_H

#include "systemc.h"
#include <limits.h>
#include <map>
#include "arbiter.h"

// extra infomation
class arbiter_extra_elm {
private:
  int m_value;
  int m_flag;

public:
  arbiter_extra_elm(int value, int flag) {
    m_value = value;
    m_flag  = flag;
  }

  bool get_penalty(arbiter_extra_elm * prev, arbiter_extra_elm * prev_prev = NULL) {
    if((m_flag == 0 && m_value == prev->m_value) ||
       (m_flag == 1 && m_value != prev->m_value)) {
      return true;
    }
    if(prev_prev != NULL) {
      if(m_flag == 2 && m_value == prev_prev->m_value) {
        return true;
      }
    }
    return false;
  }
};

class arbiter_extra {
private:
  std::vector<arbiter_extra_elm> extra_list;

public:
  int m_size;

  arbiter_extra() {
    m_size  = 1;
  }

  void push_back(int value, int flag) {
    arbiter_extra_elm extra(value, flag);
    extra_list.push_back(extra);
  }

  arbiter_extra_elm * get_elm(unsigned int index) {
    return &(extra_list[index]);
  }

  bool empty() {
    return extra_list.empty();
  }

  void clear() {
    extra_list.clear();
  }

  unsigned int get_priority(arbiter_extra * prev_extra, arbiter_extra * prev_prev_extra = NULL) {
    unsigned int pri = 0;
    if(prev_extra != NULL && prev_extra->empty() == false) {
      for(unsigned int i=0; i<extra_list.size(); i++) {
        pri *= 10;
        arbiter_extra_elm * prev_prev = NULL;
        if(prev_prev_extra != NULL && prev_extra->m_size == 1) {
          prev_prev = prev_prev_extra->get_elm(i);
        }
        bool penalty = extra_list[i].get_penalty( prev_extra->get_elm(i), prev_prev);
        if(penalty == false) {
          pri += 1;
        }
      }
    }
    return pri;
  }
};

// arbiter profile class
class arbiter_profile {
private:
  const unsigned int m_scale;
  unsigned int m_max_level;
  unsigned int m_max_candi;
  unsigned int m_max_req;

  std::vector<int> m_level_cnt;
  std::vector<int> m_candi_cnt;
  std::vector<int> m_req_cnt;

public:
  // constructor
  arbiter_profile() : m_scale(100000000), m_max_level(4), m_max_candi(10), m_max_req(10) {
    m_level_cnt.resize(m_max_level+1, 0);
    m_candi_cnt.resize(m_max_candi+1, 0);
    m_req_cnt.resize(m_max_req+1, 0);
  }

  void set_profile(std::vector<int> pri_list, int max_priority) {
    if(max_priority < 0)  return;

    unsigned int level = max_priority/m_scale;
    if(level > m_max_level) {
      m_max_level = level;
      m_level_cnt.resize(m_max_level+1, 0);
    }
    m_level_cnt[level]++;

    unsigned int ccnt = 0;
    unsigned int rcnt = 0;
    for(unsigned int i=0; i<pri_list.size(); i++) {
      if(pri_list[i] < 0) continue;
      if(pri_list[i]/m_scale == level)  ccnt++;
      rcnt++;
    }
    if(ccnt > m_max_candi) {
      m_max_candi = ccnt;
      m_candi_cnt.resize(m_max_candi+1, 0);
    }
    m_candi_cnt[ccnt]++;

    if(rcnt > m_max_req) {
      m_max_req = rcnt;
      m_req_cnt.resize(m_max_req+1, 0);
    }
    m_req_cnt[rcnt]++;
  }

  /*  DUMP PROFILE INFORMATION  */
  bool DumpProfile(FILE *p_file = stdout, sc_time_unit timescale = SC_NS) {
    if (p_file == NULL) return false;

    fprintf(p_file, "Arbiter Profile\n");
    for(unsigned int i=0; i<m_level_cnt.size(); i++) {
      if(m_level_cnt[i] == 0)  continue;
      fprintf(p_file, "  Level %d : %d\n", i, m_level_cnt[i]);
    }
    for(unsigned int i=0; i<m_candi_cnt.size(); i++) {
      if(m_candi_cnt[i] == 0)  continue;
      fprintf(p_file, "  Num of Candidate %2d : %8d\n", i, m_candi_cnt[i]);
    }
    for(unsigned int i=0; i<m_req_cnt.size(); i++) {
      if(m_req_cnt[i] == 0)  continue;
      fprintf(p_file, "  Num of Request %2d : %8d\n", i, m_req_cnt[i]);
    }
    fprintf(p_file, "\n");
    return true;
  }
};

// arbiter_dynamic element class
class arbiter_dynamic_elm {
protected:
  bool    m_request;
  bool    m_lck;
  int     m_priority;
  int     m_fixed_priority;
  int     m_low_priority;
  sc_time m_win_time;
  sc_time m_time_interval;

public:
  // constructor
  arbiter_dynamic_elm(int fixed_priority, int low_priority, sc_time time_interval) {
    m_fixed_priority = fixed_priority;
    m_low_priority = low_priority;
    m_time_interval = time_interval;

    m_request = 0;
    m_lck     = 0;
    m_priority = -1;
    m_win_time = SC_ZERO_TIME;
  }

  virtual arbiter_dynamic_elm * clone() const {
    return new arbiter_dynamic_elm(*this);
  }

  virtual void request(int priority = -1) {
    m_request = 1;
    m_priority = priority;
  }

  virtual void reset() {
    m_request = 0;
  }

  // extra information
  virtual void set_extra_info(int value, int flag) {};
  virtual void set_extra_info_size(int size) {};
  virtual void get_extra_info(arbiter_extra & extra) {};
  virtual void set_prev_extra(arbiter_extra * prev_extra, arbiter_extra * prev_prev_extra = NULL) {};

  virtual int get_priority() {
    if( !m_request ) return -1;  // no request

    int priority = (m_priority >= 0) ? m_priority : m_fixed_priority;

    if (m_time_interval > SC_ZERO_TIME) {
      if( m_win_time > SC_ZERO_TIME && (sc_time_stamp() - m_win_time) < m_time_interval ) {
        priority = m_low_priority;
      }
    }
    return priority;
  }

  virtual int get_pri_level() {
    return 0;
  }

  virtual void set_win() {
    m_request = 0;
    m_win_time = sc_time_stamp();
  }

  virtual void set_win_id(unsigned int id) {
  }

  virtual void set_lck(bool lck) {
    m_lck = lck;
  }
};

/// dynamic priority support arbiter class
class arbiter_dynamic : public arbiter_base {
private:
  enum ARB_STATUS   m_status;
  enum ARB_PRI_MODE m_mode;

  std::map<int, arbiter_dynamic_elm *> m_elm_list;

  bool         m_lck;
  unsigned int m_lck_id;

  arbiter_extra m_prev_extra;
  arbiter_extra m_prev_prev_extra;

  unsigned int  m_pri_level;

  arbiter_profile m_prof;

public:
  // constructor
  arbiter_dynamic(enum ARB_PRI_MODE mode = ARB_PRI_UPER_HIGH) {
    m_status = ARB_NORMAL;
    m_mode = mode;
    m_lck  = false;
    m_pri_level = 0;
  }

  void notify_lck(int id) {
    m_lck = true;
    m_lck_id = id;
    m_elm_list[id]->set_lck(true);
  }

  void notify_unlck(){
    if(m_lck == true) {
      m_elm_list[m_lck_id]->set_lck(false);
    }
    m_lck = false;
  }

  virtual ~arbiter_dynamic() {
    for(unsigned int i=0; i<m_elm_list.size(); i++) {
      delete m_elm_list[i];
    }
  }

  void add_element(int id, int priority) {
    m_elm_list[id] = new arbiter_dynamic_elm(priority, 0, SC_ZERO_TIME);
  }

  void add_element(int id, arbiter_dynamic_elm * element) {
    m_elm_list[id] = element;
  }

  void request(int id) {
    m_elm_list[id]->request();
  }

  void request(int id, int priority) {
    m_elm_list[id]->request(priority);
  }

  void reset(int id = -1) {
    if(id >= 0) {
      m_elm_list[id]->reset();
    }
    else {
      std::map<int, arbiter_dynamic_elm *>::iterator it;
      for(it=m_elm_list.begin(); it!=m_elm_list.end(); it++) {
        it->second->reset();
      }
    }
  }

  virtual void set_extra_info(int id, int value, int flag) {
    m_elm_list[id]->set_extra_info(value, flag);
  }

  virtual void set_extra_info_size(int id, int size) {
    m_elm_list[id]->set_extra_info_size(size);
  }

  virtual int get_pri_level() {
    return m_pri_level;
  }

  int get_winner() {
    int id = winner();
    if(id >= 0) {
      m_pri_level = m_elm_list[id]->get_pri_level();

      m_prev_prev_extra = m_prev_extra;

      m_elm_list[id]->set_win();
      m_elm_list[id]->get_extra_info(m_prev_extra);

      std::map<int, arbiter_dynamic_elm *>::iterator it;
      for(it=m_elm_list.begin(); it!=m_elm_list.end(); it++) {
        it->second->set_win_id(id);
        if( ! m_prev_extra.empty() ) {
          arbiter_extra * prev_prev = ( ! m_prev_prev_extra.empty() ) ? &m_prev_prev_extra : NULL;
          it->second->set_prev_extra(&m_prev_extra, prev_prev);
        }
      }
    }
    return id;
  }

  int winner() {
    m_status = ARB_NORMAL;
    int win_id = -1;
    int max_priority = -1;

    std::vector<int> pri_list;  // for profile

    if(m_lck == true) {
      if(m_elm_list[m_lck_id]->get_priority() >= 0) {
        // check permission (gnt)
        if(bus_base_ptr != NULL && bus_base_ptr->get_permission(m_lck_id) == false) {
          return -1;
        } else {
          return m_lck_id;
        }
      }
      else {
        return -1;
      }
    }

    if(debug_level >= 2) {
      cout << "[" << sc_time_stamp() << "]  Arbitration start" << endl;
    }

    std::map<int, arbiter_dynamic_elm *>::iterator it;
    for(it=m_elm_list.begin(); it!=m_elm_list.end(); it++) {
      int priority = it->second->get_priority();

      if(debug_level >= 1) {
        pri_list.push_back(priority);
        if(debug_level >= 2) {
          cout << "  (" << it->first << ")  priority = " << priority << endl;
        }
      }

      if(priority >= 0) {
        // check permission (gnt)
        if (bus_base_ptr != NULL) {
          if (bus_base_ptr->get_permission(it->first) == false) {
            if(debug_level >= 2) {
              cout << "  target buffer full" << endl;
            }
            continue;
          }
        }

        if(m_mode == ARB_PRI_LOWER_HIGH) priority = INT_MAX - priority;
        if(priority > max_priority) {
          max_priority = priority;
          win_id = it->first;
        }
        else if(priority == max_priority) {
          // This code certainly evaluates from smaller ID.
          // So the code, as below 3 lines, are not necesary. 
          // same priority
          //          if(win_id > it->first) {
          //            win_id = it->first;
          //          }
          m_status = ARB_ERROR;
        }
      }
    }

    if(debug_level >= 1) {
      m_prof.set_profile(pri_list, max_priority);
      if(debug_level >= 2) {
        cout << "  WINNER = " << win_id << endl;
      }
    }

    return win_id;
  }

  enum ARB_STATUS get_status() {
    return m_status;
  }

  /*  DUMP PROFILE INFORMATION  */
  bool DumpProfile(FILE *p_file = stdout, sc_time_unit timescale = SC_NS) {
    if(debug_level >= 1) {
      return m_prof.DumpProfile(p_file, timescale);
    }
    return true;
  }
};

#endif//__ARBITER_DYNAMIC_H
