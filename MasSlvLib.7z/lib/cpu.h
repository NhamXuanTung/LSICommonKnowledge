//$Id: cpu.h v2014_09_29 $
/****************************************************************************
* File name : cpu.h
****************************************************************************/
#ifndef  __CPU_H__
#define  __CPU_H__
#include <iostream>
#include "cedar_forest_api.h"

#include "systemc.h"

#ifdef CWR_SYSTEMC
#include "scml.h"
#include "PV/PV.h"
#else
#include "commandHandler.h"
#endif

#define CPU_TLM20_BUS

#ifdef CPU_TLM20_BUS
#include "tlm_ini_if.h"
#include "tlm_tgt_if.h"
#endif // CPU_TLM20_BUS

#include "format_info.h"

using namespace std;

#define N_CPU_STRG 1024
#define N_CPU_DIV  1024
#define ISS_EXEC_STEPS 10

#define N_CPU 1

// Comment Out For Debug 
// Comment Out H.M #define RAM_MAX_ADDR 0x20000
// Add For Debug
#define RAM_MAX_ADDR 0xFFFFFFFF
// Add End.

#ifndef SNC_DISABLE
#define  N_SNC  1
#endif //#ifndef SNC_DISABLE

#define TOTAL_N_IRQ 8

#define BUS_WIDTH_INI 64
#define BUS_WIDTH_TGT 32

#ifndef re_printf
#define re_printf get_fileline(__FILE__, __LINE__); _re_printf
#endif//re_printf

typedef void (*handler_t)(int);

class Ccpu : public sc_module
#ifdef CPU_TLM20_BUS
 , public vpcl::tlm_tgt_if<BUS_WIDTH_TGT>
 , public vpcl::tlm_ini_if<BUS_WIDTH_INI>
#endif // CPU_TLM20_BUS
{
public:
    // -------- Port list --------
    sc_in<bool>            clk_in;      // Clock
    sc_in<bool>            rst_in;      // Reset
    sc_in<bool>            irq_in;      // Interrupt request
    sc_out<bool>           irq_out;     // Interrupt request

    sc_in<sc_uint<9> >     inpt_int_evt;      // IntEvt From INTCA
    sc_in<sc_uint<4> >     inpt_int_priority; // Priority From INTCA

    int _x;
    unsigned long _src;

#ifdef CWR_SYSTEMC
    PVTarget_port <unsigned long long, unsigned int> p_tgt;       // Target port
    scml_post_port<unsigned long long, unsigned int> p_post;      // Initiator port

    scml_property<int>     icache_size;
    scml_property<int>     ocache_size;

    // -------- Clock object --------
    scml_divided_clock cpu_div_clk;

    scml_memory<unsigned int> m_regs;

    unsigned long long                                         cpu_strg[N_CPU_STRG];
    scml_array<unsigned long long>                             cpu_arry;
    scml_transaction_request<unsigned long long, unsigned int> cpu_trans_req;
#endif

    const unsigned int bus_width;
    const unsigned int bus_byte_width;

    long id;
    void *cedar_p;
    long cpu_start_flag;
    unsigned long src_id;
    //Cmemory *mem_body;
    long sigint_flag;

private:
#ifndef CWR_SYSTEMC
    vpcl::commandHandler * cmd_handler;
#endif

public:
    /* Module Constructor */
    SC_HAS_PROCESS(Ccpu);

    Ccpu (sc_module_name name,int x, unsigned long src) : sc_module(name)
#ifdef CPU_TLM20_BUS
                , vpcl::tlm_tgt_if<BUS_WIDTH_TGT>(name)
                , vpcl::tlm_ini_if<BUS_WIDTH_INI>(name,src)
#endif // CPU_TLM20_BUS
                , clk_in      ("clk_in")
                , rst_in      ("rst_in")
                , irq_in      ("irq_in")
                , irq_out     ("irq_out")
                , inpt_int_evt     ("inpt_int_evt")
                , inpt_int_priority     ("inpt_int_priority")
                , _x          (x)
                , _src        (src)
#ifdef  CWR_SYSTEMC
                , icache_size ("icache_size",0)
                , ocache_size ("ocache_size",0)
#endif // CWR_SYSTEMC
#ifndef CPU_TLM20_BUS
                , p_tgt       ("p_tgt")
                , p_post      ("p_post", scml_little_endian)
#endif // CPU_TLM20_BUS
#ifdef  CWR_SYSTEMC
                , cpu_div_clk ("cpu_div_clk", clk_in, N_CPU_DIV, 0)
                , m_regs      ("m_regs", scml_memsize(0x0800000/4))
                , cpu_arry    (cpu_strg, N_CPU_STRG)
#endif
                , bus_width        (BUS_WIDTH_INI)
                , bus_byte_width   (BUS_WIDTH_INI/8)
    {
        id = (long)x;
        cedar_p = CreateCedar (id, this);
        mInstName = (std::string)name;

        //mem_body = (Cmemory*)GetMemBodyP (cedar_p);
        irq_out.initialize(true);

        cpu_start_flag = 0;
        src_id = src;

//        m_irq_req_st = true;
        m_irq_req_st = false;
        m_int_evt = 0;
        m_int_priority = 0;

        sigint_flag = 0;
        m_step_count = 0;
        m_step_run = 0;
        m_step_check = false;
        m_run_time = 0;
        m_run_time_check = false;
        m_break_system_time_enable = 0;
        m_break_system_time = 0;
        mFileName = "";
        mLineNum = 0;

        mMessageLevel["fatal"] = true;
        mMessageLevel["error"] = true;
        mMessageLevel["warning"] = false;
        mMessageLevel["info"] = false;

#ifndef CWR_SYSTEMC
        cmd_handler = NULL;
#endif

        CpuCedarInit ();
        CedarFsHardReset (cedar_p);
        CpuSetEndian (CPU_ENDIAN_LITTLE);
        CpuSetCpuType (SH4A);
        CpuSetXYramSize (XYRAM_128K);
        CpuCedarDefaultMemSet();
        CpuSetDebugMode(DBG_OFF);

        // -------- Setting of target model I/F --------
#ifndef CPU_TLM20_BUS
        p_tgt(m_regs);
#endif  // CPU_TLM20_BUS
#ifdef  CWR_SYSTEMC
        m_regs.set_addressing_mode(8);
        m_regs.initialize(0);
        MEMORY_REGISTER_TRANSPORT(m_regs, MemAccCB);

        // -------- SCML command processor --------
        SCML_COMMAND_PROCESSOR(handleCommand);
        SCML_ADD_COMMAND("set_cpu", 1, 4, "set_cpu <fname> <addr>", "Set cpu(SH4A) environment of <argv[1]> to <argv[2]>.");
        SCML_ADD_COMMAND("cpu_command", 1, 4, "cpu_command <command>", "SH4A ISS command");
        SCML_ADD_COMMAND("mem_load", 1, 2, "mem_load <fname> <addr>", "Loads the contents of <fname> in cpu(SH4A) memory starting from the offset <addr>.");
        SCML_ADD_COMMAND("mem_save", 3, 3, "mem_save <fname> <addr> <size>", "Copies the contents of cpu(SH4A) memory starting from the byte <addr> until <addr>+<size> into the file <fname>.");
#endif

        set_cpu_parameter();

        // -------- Setting of HardWare Reset by rst_in Signal --------
        SC_METHOD( CpuFsHardReset );
        sensitive << rst_in.neg();

        // -------- Setting of ISS Call Interval by clk_in Signal --------
        SC_THREAD( Lap_CpuFsStepExecute );
#ifdef  CWR_SYSTEMC
        sensitive_pos << cpu_div_clk;
#else
        sensitive << clk_in.pos();
#endif  // CWR_SYSTEMC
        dont_initialize();

    }

    virtual ~Ccpu (){
        DeleteCedar(cedar_p);
    }

#ifndef CWR_SYSTEMC
    void setCommandHandler(vpcl::commandHandler * handler)
    {
      if (handler != NULL) {
          cmd_handler = handler;
      }
      else {
          re_printf("error", "Error(%s) : handler parameter(at setCommandHandler) is NULL pointer.\n" , this->basename() );
      }
    }
#endif

    // IF
#ifdef  CWR_SYSTEMC
    scml_memory_pv64_if::response_type MemAccCB(const scml_memory_pv64_if::request_type &req);
#endif  // CWR_SYSTEMC

    // -------- Initiator I/F API --------
    void BusAccWrite(unsigned int addr, unsigned long *p_data, unsigned int size);
    void BusAccRead (unsigned int addr, unsigned long *p_data, unsigned int size);
    void BusAccWriteDebug(unsigned int addr, unsigned long *p_data, unsigned int size);
    void BusAccReadDebug (unsigned int addr, unsigned long *p_data, unsigned int size);

    void WordSwap(unsigned long *p_data, unsigned int size);

    // -------- SCML command processor --------
    std::string handleCommand(const std::vector<std::string>& args);

    // -------- Breakpoint --------
    void CpuBreak();

    // -------- Target I/F API --------
    void TargetWrite (unsigned long src, unsigned long addr,
                      unsigned long *p_data, unsigned long size);
    void TargetRead  (unsigned long src, unsigned long addr,
                      unsigned long *p_data, unsigned long size);
    void TargetWriteDebug (unsigned long src, unsigned long addr,
                           unsigned long *p_data, unsigned long size);
    void TargetReadDebug  (unsigned long src, unsigned long addr,
                           unsigned long *p_data, unsigned long size);

    void CpuHardReset (void);
    void CpuManualReset (void);
    void CpuCedarInit (void);
    void CpuInstQueueInit (void);
    void CpuSetDebugMode (DebugMode mode);
    DebugMode CpuGetDebugMode (void);
    void CpuSetDebugEnable (DebugMode mode);
    std::string CpuSetBpEnable(const std::vector<std::string>& args);
    std::string CpuSetBpAddrEnable(const std::vector<std::string>& args);
    void CpuSetCedarMode (CedarMode mode);
    CedarMode CpuGetCedarMode (void);
    void CpuSetCedarProf (ProfMode mode);
    void CpuSetCpuType (CpuType cpu_type);
    void CpuSetSnapDump (SnapDumpMode mode);
    void CpuSetSleepMode (SleepMode mode);
    void CpuSetExpmaskInitValue (unsigned long expmask_init_value);
    void CpuSetCoproBaseMode (CoproBaseMode copro_mode);
    CpuType CpuGetCpuType (void);
    void CpuSetEndian (EndianType endian);
    EndianType CpuGetEndian (void);
    void CpuCedarDefaultMemSet (void);
    //void CpuFsExecute (unsigned long step, InstDispMode inst_disp);
    //void CpuCsExecute (unsigned long step, InstDispMode inst_disp);
    SimState CpuFsExecute (InstDispMode inst_disp);
    SimState CpuCsExecute (InstDispMode inst_disp);
    void Lap_CpuFsStepExecute (void);
    void CpuFsStepExecute (void);
    void CpuFsSleepWakeUpProcess (void);
    void CpuCsTraceSimulate (void);
    unsigned long CpuGetBranchInfo (void);
    unsigned long CpuGetBranchAddr (void);

    unsigned long CpuGetInstAddr (void);
    unsigned long CpuGetInstCode (void);
    unsigned long CpuGetInstCode32 (void);
    unsigned long CpuGetNextInstAddr (void);
    long CpuGetInstId (void);
    long CpuGetReadRegNum (void);
    SH_Reg CpuGetReadRegName (unsigned long index);
    unsigned long CpuGetReadRegValue (unsigned long index);
    long CpuGetWriteRegNum (void);
    SH_Reg CpuGetWriteRegName (unsigned long index);
    unsigned long CpuGetWriteRegValue (unsigned long index);
    unsigned long CpuGetReadMemNum (void);
    unsigned long CpuGetReadMemAddr (unsigned long index);
    unsigned long CpuGetReadMemValue (unsigned long index);
    unsigned long CpuGetReadMemSize (unsigned long index);
    unsigned long CpuGetWriteMemNum (void);
    unsigned long CpuGetWriteMemAddr (unsigned long index);
    unsigned long CpuGetWriteMemValue (unsigned long index);
    unsigned long CpuGetWriteMemSize (unsigned long index);
    unsigned long CpuGetInstStepCount (void);
    unsigned long CpuGetInstCycleCount (void);
    unsigned long *CpuGetInstStageCycle (void);
    ConditionResultType CpuGetConditionResult (void);
    unsigned long CpuGetInstParallel (void);

    void CpuCedarQuit (void);
    void CpuFsHardReset (void);
    void CpuCsHardReset (void);
    void CpuFsStateDisplay (void);
    void CpuRegisterDisplay (FILE *ptr_file);
    void CpuRegWriteDebug (SH_Reg regno, unsigned long data, BankChangeMode bank_change_flag);
    unsigned long CpuRegReadDebug (SH_Reg regno, BankChangeMode bank_change_flag);
    unsigned long CpuRegReadPC (void);
    unsigned long CpuRegReadBody (SH_Reg end_addr_reg);
    SH_Reg CpuRegGetRegno (const char *regname);
    unsigned long CpuCtrlRegGetRegno (const char *regname);
    void CpuCtrlRegWrite (unsigned long regaddr, unsigned long data, MemAccessDataType size);
    unsigned long CpuCtrlRegRead (unsigned long regaddr, MemAccessDataType size);
    SimState CpuGetSimState (void);
    void CpuSetSimState (SimState sim_state);
    ScriptMode CpuGetScriptMode (void);
    void CpuSetScriptMode (ScriptMode mode);
    void CpuSetClockRatio (ClockType clock_type, unsigned long ratio);
    void CpuErrorCodeSet (ErrorCode err_no);
    ErrorCode CpuGetErrorCode (void);
    ErrorCode CpuGetExpCode (void);
    SH_Reg CpuGetWriteVReg (unsigned long num);
    void CpuSetOutFilePointer (FILE*);
    FILE* CpuGetOutFilePointer (void);
    void CpuSetInterrupt (int intlevel, int intvecno);
    long CpuCheckInterruptAccept (void);
    void CpuBreakAccessAdd (unsigned long start_addr, unsigned long end_addr,
                            MemRestrictType access_type);
    void CpuBreakAccessDisplay (void);
    void CpuBreakAccessEnable (long enable, long index, long all);
    void CpuBreakPointAdd (unsigned long address, unsigned long count);
    void CpuBreakPointDisplay (void);
    void CpuBreakPointEnable (long enable, long index, long all);
    void CpuBreakSleepSet (long flag);
    BreakPoint **CpuGetBreakPoint (void);
    void CpuBreakPcstopSet (unsigned long count);
    void CpuBreakMaxSet (unsigned long count);

    void CpuSetFpuAlgorithm (FpuAlgorithmMode fpu_algolithm);
    void CpuSetIcacheSize (ICacheSize icache_size);
    void CpuSetOcacheSize (OCacheSize ocache_size);
    L2CacheSize CpuGetL2cacheSize (void);
    void CpuSetL2cacheSize (L2CacheSize l2cache_size);
    void CpuSetXYramSize (XYramSize xyram_size);
    void CpuSetILramSize (ILramSize ilram_size);
    void CpuSetLramSize (LramSize lram_size);
    void CpuSetUramSize (UramSize uram_size);
    UramSize CpuGetUramSize (void);
    void CpuSetIcacheWayMode (CacheWayMode cache_way_mode);
    void CpuSetOcacheWayMode (CacheWayMode cache_way_mode);
    void CpuSetScdFixMode (ScdFixMode scd_fix_mode);
    void CpuCruFlushCacheLine (unsigned long flush_addr);
    void CpuCruPurgeCacheLine (unsigned long purge_addr);
    unsigned long CpuGetIcacheAccessCount (void);
    unsigned long CpuGetIcacheHitCount (void);
    unsigned long CpuGetOcacheAccessCount (void);
    unsigned long CpuGetOcacheHitCount (void);
    unsigned long CpuGetL2cacheAccessCount (void);
    unsigned long CpuGetL2cacheHitCount (void);

    void CpuAddCycleCount (unsigned long add_cycle);
    void CpuClearCycleCount (void);
    void CpuClearStepCount (void);
    void CpuClearOverflow (void);

    const char *CpuRegGetName (SH_Reg regno);

    void CpuClearInterrupt (void);
    void CpuSetNMIB(unsigned long data);
    void CpuSetResetVecAddr (unsigned long addr);
    unsigned long CpuGetResetVecAddr (void);
    void CpuSetCpuEnable (CpuEnable enable);
    CpuEnable CpuGetCpuEnable (void);
    void CpuSetBootAddrMode (BootAddrMode boot_addr_mode);
    BootAddrMode CpuGetBootAddrMode (void);
    void CpuSet32BitBootAddr (Boot32AddrIndex pn, unsigned long addr);
    void CpuSetUxyAdrSel (UxyPhysAddr uxyadrsel);
    void CpuUpdateUxyPhysAddr (void);

    void CpuSetSimioEnable (long flag);
    long CpuCheckSimioExec (void);
    void CpuSetSimioAddress (unsigned long address);
    void CpuSetVirtualSimioEnable (long flag);
    void CpuSetVirtualSimioAddress (unsigned long address);

    void CpuMemWriteDebug (unsigned long addr, unsigned long data,
                             MemAccessDataType size);
    unsigned long CpuMemReadDebug (unsigned long addr, MemAccessDataType size);
    void CpuMemoryDisplay (unsigned long start_addr, unsigned long end_addr,
                           MemDisplaySize size, FILE *ptr_file);
    void CpuFileLoad (char *filename, unsigned long offset);

//    void CpuSetIntcTestMode (IntcTestMode intc_test_mode);
//    void CpuSetIntcTestDecrementNum (long decrement_num);

    void CpuSetCompatibleMode (unsigned long mode);
    void CpuSetEmuMode (EmuMode emu_mode);
    long CpuGetSleepState (void);
    void CpuSetSleepState (long state);
    long CpuCheckDebugMode (DebugMode target_mode);
    void CpuWakeupProcess (InstDispMode inst_disp);
    void CpuProfileDump (void);
    void CpuClearProfHash (void);

    unsigned long CpuGetCcr_CCD(void);
    unsigned long CpuGetOcTagMASK(void);
    unsigned long CpuReadRAMCR_OC2W(void);
    CacheSize CpuGetOcacheSize (void);
    SnoopResponseType CpuOCacheSnoop(
                      long req_id,              /* �v����CPUID */
                      unsigned long entry,      /* �A�N�Z�X����G���g���ԍ� */
                      long way,                 /* �A�N�Z�X����E�F�C */
                      SnoopCommandType cmd,     /* �X�k�[�v�R�}���h(Flush, Purge, Invalidate) */
                      unsigned long **p_data,   /* �L���b�V���ԓ]���߂�l(M State���̂�) */
                      SncAccessReason reason);
    void CpuAddSnpLatency(unsigned long stall);

    void DumpPerformanceInfo(FILE *fp);
    void ClearPerformanceInfo(void);
    void CpuFsDisplayInstructionCount(FILE *fp);
    void CpuFsClearInstructionCount(void);
    void CpuFsEnableInstructionCount(void);
    void CpuFsDisableInstructionCount(void);

    void CpuSetLightSleep(unsigned long mode);
    unsigned long CpuGetLightSleep(void);

    void CpuInitExceptionBreak(unsigned long enable_flag);
    void CpuSetExceptionBreak(unsigned long exception_code, unsigned long enable_flag);
    void CpuEnableExceptionBreak(unsigned long enable_flag);
    void CpuDisplayExceptionBreak(void);
    unsigned long CpuGetOmemReadCount(void);
    unsigned long CpuGetOmemWriteCount(void);

    void PushVariables (FILE *fp);
    void PopVariables (FILE *fp);

private:
    bool m_irq_req_st;     // Interrupt request
    int  m_int_evt;        // Interrupt event
    int  m_int_priority;   // Interrupt priority

    unsigned int mbus_end_type; // BUS endian type.(big/little).

    unsigned int m_break_system_time_enable; //enable/disable break system time variable 
    unsigned int m_break_system_time;        //break system time
    unsigned int m_run_time;                 //run time
    bool  m_run_time_check;               //check run time
    unsigned int m_step_count;               //run step
    unsigned int m_step_run;                 //input run step
    bool  m_step_check;                   //check run step
    std::string mInstName;                   //Instance name of cpu model
    std::string mFileName;                   //File name
    int mLineNum;                            //Line number
    std::map<std::string, bool> mMessageLevel;
    std::vector<std::string> Str2Vec(std::string str, const char sep);

    void set_cpu_parameter();
    void reg_write (std::string regname, unsigned int val);

    std::string own_handle_command(const std::vector<std::string> &args);
    std::string SetCpuProcess(const std::vector<std::string> &args); 
    std::string CpuCommandProcess(const std::vector<std::string> &args);
    std::string CtrlSimCommand(const std::vector<std::string> &args);
    void HardReset(void);
    void BreakSystemTimeSet(const unsigned int break_time);
    void BreakSystemTimeEnable(const unsigned int enable);
    void MemLoad(const char *fname, const unsigned int in_addr);
    void MemSave(const char *fname, const unsigned int in_addr, const unsigned int in_size);
    bool num_check(const std::string input_str, unsigned int *value);
    void get_fileline(std::string filename, int line_number);
    void _re_printf(std::string group, const char *message, ...);

    //----------Load file functions ------------
    int FileStypeLoad(const char *filename);   
    void FileStypeDataLoad (std::string cur_line);
    bool FileElfLoad(const char *filename); 
    bool FileBinLoad(const char *fname, const unsigned int in_addr); 
    bool ChkEhdr (const Elf_Ehdr *Ehdr);
    bool ChkPhdr (const Elf_Phdr *Phdr, const unsigned char endian);
    std::string PrintSscHelp();

    std::string handleSetEndian(const std::string str);
    std::string handleSetCpuType(const std::string str);
    std::string handleSetILramSize(const std::string str);
    std::string handleSetLramSize(const std::string str);
    std::string handleSetUramSize(const std::string str);
    std::string handleSetIcacheSize(const std::string str);
    std::string handleSetOcacheSize(const std::string str);
    std::string handleMemLoad(const std::vector<std::string>& args);
    std::string handleMemSave(const std::vector<std::string>& args);
    std::string handleMemDump(const std::vector<std::string>& args);

#ifdef CPU_TLM20_BUS // TLM20_BUS
    // TLM Common Function
    bool tgt_wr(unsigned int addr, unsigned char *p_data, unsigned int size, vpcl::tlm_if_extension *p_ext);
    bool tgt_rd(unsigned int addr, unsigned char *p_data, unsigned int size, vpcl::tlm_if_extension *p_ext);
    bool tgt_wr(unsigned int addr, unsigned char *p_data, unsigned int size, vpcl::tlm_if_extension *p_ext, sc_time *p_time);
    bool tgt_rd(unsigned int addr, unsigned char *p_data, unsigned int size, vpcl::tlm_if_extension *p_ext, sc_time *p_time);
    bool tgt_wr_dbg(unsigned int addr, unsigned char *p_data, unsigned int size, vpcl::tlm_if_extension *p_ext);
    bool tgt_rd_dbg(unsigned int addr, unsigned char *p_data, unsigned int size, vpcl::tlm_if_extension *p_ext);
    void tlmWrite(unsigned int addr, unsigned long *p_data, unsigned int size);
#endif // CPU_TLM20_BUS

    // Byte Swap.
    void ByteSwap32( unsigned int *p_data , const unsigned int size );
    unsigned int swap_data(const unsigned char endian, const unsigned int size, unsigned int value); 
};

unsigned long BusAccessRead (void* inip, unsigned long addr, MemAccessDataType size);
void BusAccessWrite (void* inip, unsigned long addr, unsigned long data, MemAccessDataType size);
void BusAccessBurstWrite (void* inip, unsigned long addr, unsigned long *p_data, unsigned long burst_bytes);
void BusAccessBurstRead (void* inip, unsigned long addr, unsigned long *p_data, unsigned long burst_bytes);
void BusAccessWriteDebug (void* inip, unsigned long addr, unsigned long data, MemAccessDataType size);
unsigned long BusAccessReadDebug (void* inip, unsigned long addr, MemAccessDataType size);
void BusAccessBurstWriteDebug (void* inip, unsigned long addr, unsigned long *p_data, unsigned long burst_bytes);
void BusAccessBurstReadDebug (void* inip, unsigned long addr, unsigned long *p_data, unsigned long burst_bytes);

unsigned long ForestGetSystemTime(void);
void ForestSetInvalidAddress (unsigned long invalid_address);
void ForestManualReset (void);
unsigned long ForestGetMemInitValue (void);
int mystrcasecmp(const char *s1, const char *s2);
// static void strtoupper (const char *fromstr, char *tostr);
int mytoupper (int c);
unsigned long IntcTestRegRead (unsigned long regaddr, MemAccessDataType size);
void IntcTestRegWrite (unsigned long regaddr, unsigned long data, MemAccessDataType size);

#endif /*__CPU_H__*/
