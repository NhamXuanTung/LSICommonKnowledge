/****************************************************************************
* FOREST
* File name : dmac.cpp
****************************************************************************/
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include "cedar_forest_api.h"
#include "memory_body.h"
#include "forest_utility.h"

#define MEMALLOC_CONTINUOUSLY

#define DEBUG_MEM
//#define _ASE_BIG_

unsigned long Cmemory::ByteSwap (unsigned long before)
{
#ifdef _INTEL
    return (_bswap(before));

#else /* _INTEL */
    unsigned long after;
    unsigned char *p_before;
    unsigned char *p_after;

    p_before = (unsigned char *)(&before);
    p_after = (unsigned char *)(&after);
    p_after[0] = p_before[3];
    p_after[1] = p_before[2];
    p_after[2] = p_before[1];
    p_after[3] = p_before[0];

    return (after);
#endif /* _INTEL */
}


void Cmemory::MemBurstWriteBody (unsigned long addr, unsigned long *p_data, unsigned long size)
{
    unsigned long base_addr;
    unsigned long rap_arround_mask;
    unsigned long lws;
    unsigned long i;

    rap_arround_mask = ~(size - 1);
    base_addr = addr & rap_arround_mask & 0xFFFFFFFC;
    lws = size >> 2;
    for (i = 0; i < lws; i++) {
       MemWriteBody (base_addr+(i<<2), p_data[i], MEMACCESS_LONGWORD);
    }
}


void Cmemory::MemBurstReadBody (unsigned long addr, unsigned long *p_data, unsigned long size)
{
    unsigned long base_addr;
    unsigned long rap_arround_mask;
    unsigned long lws;
    unsigned long i;
    
    rap_arround_mask = ~(size - 1);
    base_addr = addr & rap_arround_mask & 0xFFFFFFFC;
    lws = size >> 2;
    for (i = 0; i < lws; i++) {
        p_data[i] = MemReadBody (base_addr+(i<<2), MEMACCESS_LONGWORD);
    }
}


void Cmemory::MemWriteBody (unsigned long addr, unsigned long data, MemAccessDataType size)
{
    unsigned char *p_mem_addr;
    MemoryBlock *p_mem_block;

#ifdef DEBUG_MEM
if (debug_mem == 1){
    printf("W: addr:%08lx, data:%08lx, size:%lx\n", addr, data, size);
}
#endif

    /* $B0z?t$N%"%I%l%9$+$i%a%b%j%V%m%C%/$N<BBN$r8!:w(B */
    p_mem_block = MemBlockSearch (addr);

    if (p_mem_block != NULL) {
        /* $B%a%b%j$N<BBN$X$N%]%$%s%?$r<hF@(B */
        p_mem_addr = p_mem_block->p_mblock_body + (addr & 0x0000FFFF);
    } else {
        if (g_shadow_mode == SHADOW_ON) {
            /* $B%@%_!<NN0h$r3NJ](B */
            d_printf (MSG_WAR, "<Warning: Allocated Dummy Memory Area %08lX-%08lX>\n",
                      addr & 0xFFFF0000, addr | 0x0000FFFF);
            //ForestMemResourceAdd (addr & 0xFFFF0000, addr | 0x0000FFFF,
            MemResourceAdd (addr & 0xFFFF0000, addr | 0x0000FFFF,
                                  READ_WRITE, 0, DUMMY_MEM_AREA);
            p_mem_block = MemBlockSearch (addr);
        }
        if (p_mem_block == NULL) {
            ErrorCodeSet (E_MEM_INVALID_ADDRESS);  /* $B%a%b%jNN0h30$X$N%"%/%;%9(B */
            d_printf (MSG_ERR, "E_MEM_INVALID_ADDRESS: UNALLOC: %08lX\n", addr);
            ForestSetInvalidAddress (addr);
            return;                /* $BNc30H/@8(B */
        }
        /* $B%a%b%j$N<BBN$X$N%]%$%s%?$r<hF@(B */
        p_mem_addr = p_mem_block->p_mblock_body + (addr & 0x0000FFFF);
    }

    /* $B%"%/%;%9$N5v2DH=Dj(B */
    /* $B%7%_%e%l!<%7%g%sCf$N$_M-8z(B */
    if (p_mem_block->mblock_restrict_type == READ_ONLY) { // @@ && ced_sim_state == SIMULATE_ON) {
        ErrorCodeSet (E_MEM_WRITE_TO_RO);  /* $B%j!<%I%*%s%j!<NN0h$X$N=q$-9~$_(B */
        ForestSetInvalidAddress (addr);
        return;
    }

#ifdef HEW_REG
    if (p_mem_block->mblock_area == HEW_REG_AREA) {
        /* HEW $B%l%8%9%?$X$N=q$-9~$_(B */
        if (HewRegWrite (addr, data, size) == 1) {
            /* $B@.8y$9$l$P=hM}40N;(B */
            /* $B<:GT$9$l$P3NJ]NN0h$X$N%"%/%;%9(B */
            return;
        }
    }
#endif /* HEW_REG */

    /* $B%a%b%j;HMQ%U%i%0$rN)$F$k(B */
    p_mem_block->mblock_use = 1;

    /* $B%a%b%jNN0h$X$N%]%$%s%?$r<hF@(B */
    p_mem_addr = p_mem_block->p_mblock_body + (addr & 0x0000FFFF);
    
#ifndef _ASE_BIG_
    /* $B%G!<%?%i%$%H=hM}(B */
    switch (size) {
    case MEMACCESS_BYTE:       MemWriteBodyByte (p_mem_addr, data);      break;
    case MEMACCESS_WORD:       MemWriteBodyWord (p_mem_addr, data);      break;
    case MEMACCESS_LONGWORD:   MemWriteBodyLongword (p_mem_addr, data);  break;
    case MEMACCESS_QUADWORD_U: MemWriteBodyQuadwordU (p_mem_addr, data); break;
    case MEMACCESS_QUADWORD_L: MemWriteBodyQuadwordL (p_mem_addr, data); break;
    default:         ErrorCodeSet (E_CEDAR_INTERNAL); return;  // H.M break;
    }
#else //_ASE_BIG_
    if ((addr < 0xFC000000) || (addr > 0xFC3FFFFF)){
        /* $B%G!<%?%i%$%H=hM}(B */
        switch (size) {
        case MEMACCESS_BYTE:       MemWriteBodyByte (p_mem_addr, data);      break;
        case MEMACCESS_WORD:       MemWriteBodyWord (p_mem_addr, data);      break;
        case MEMACCESS_LONGWORD:   MemWriteBodyLongword (p_mem_addr, data);  break;
        case MEMACCESS_QUADWORD_U: MemWriteBodyQuadwordU (p_mem_addr, data); break;
        case MEMACCESS_QUADWORD_L: MemWriteBodyQuadwordL (p_mem_addr, data); break;
        default:         ErrorCodeSet (E_CEDAR_INTERNAL); return;  break;
        }
    } else {
        //ASE$B%a%b%jNN0h(B($B>o;~(BBIG$B%(%s%G%#%"%s(B)
        /* $B%G!<%?%i%$%H=hM}(B */
        switch (size) {
        case MEMACCESS_BYTE:       MemWriteBodyByte (p_mem_addr, data);         break;
        case MEMACCESS_WORD:       MemWriteBodyWordAse (p_mem_addr, data);      break;
        case MEMACCESS_LONGWORD:   MemWriteBodyLongwordAse (p_mem_addr, data);  break;
        case MEMACCESS_QUADWORD_U: MemWriteBodyQuadwordUAse (p_mem_addr, data); break;
        case MEMACCESS_QUADWORD_L: MemWriteBodyQuadwordLAse (p_mem_addr, data); break;
        default:         ErrorCodeSet (E_CEDAR_INTERNAL); return;  break;
        }
    }
#endif //_ASE_BIG_
}


void Cmemory::MemWriteBodyByte (unsigned char *p_mres_addr, unsigned long data)
{
    *p_mres_addr = (unsigned char)(data & 0x000000ff);
}


void Cmemory::MemWriteBodyWord (unsigned char *p_mres_addr, unsigned long data)
{
#ifdef _HOST_ENDIAN_BIG
    if (ced_endian_type == CPU_ENDIAN_BIG) {
        *(unsigned short *)p_mres_addr = data & 0x0000ffff;
    } else {
        *(p_mres_addr + 1) = (unsigned char)((data >> 8) & 0x000000ff);
        *(p_mres_addr)     = (unsigned char)( data       & 0x000000ff);
    }
#else  /* _HOST_ENDIAN_BIG (_LITTLE_ENDIAN) */
    if (ced_endian_type == CPU_ENDIAN_BIG) {
        *(p_mres_addr)     = (unsigned char)((data >> 8) & 0x000000ff);
        *(p_mres_addr + 1) = (unsigned char)( data       & 0x000000ff);
    } else {
        *(unsigned short *)p_mres_addr = data & 0x0000ffff;
    }
#endif  /* _HOST_ENDIAN_BIG */
}


void Cmemory::MemWriteBodyLongword (unsigned char *p_mres_addr, unsigned long data)
{
#ifdef _HOST_ENDIAN_BIG
    if (ced_endian_type == CPU_ENDIAN_BIG) {
        *(unsigned long *)p_mres_addr = data;
    } else {
        *(p_mres_addr + 3) = (unsigned char)((data >> 24) & 0x000000ff);
        *(p_mres_addr + 2) = (unsigned char)((data >> 16) & 0x000000ff);
        *(p_mres_addr + 1) = (unsigned char)((data >>  8) & 0x000000ff);
        *(p_mres_addr)     = (unsigned char)( data        & 0x000000ff);
    }
#else  /* _HOST_ENDIAN_BIG (_LITTLE_ENDIAN) */
    if (ced_endian_type == CPU_ENDIAN_BIG) {
        *(p_mres_addr)     = (unsigned char)((data >> 24) & 0x000000ff);
        *(p_mres_addr + 1) = (unsigned char)((data >> 16) & 0x000000ff);
        *(p_mres_addr + 2) = (unsigned char)((data >>  8) & 0x000000ff);
        *(p_mres_addr + 3) = (unsigned char)( data        & 0x000000ff);
    } else {
        *(unsigned long *)p_mres_addr = data;
    }
#endif  /* _HOST_ENDIAN_BIG */
}


void Cmemory::MemWriteBodyQuadwordU (unsigned char *p_mres_addr, unsigned long data)
{
#ifdef _HOST_ENDIAN_BIG
    if (ced_endian_type == CPU_ENDIAN_BIG) {
        *(unsigned long *)p_mres_addr = data;
    } else {
        *(p_mres_addr + 7) = (unsigned char)((data >> 24) & 0x000000ff);
        *(p_mres_addr + 6) = (unsigned char)((data >> 16) & 0x000000ff);
        *(p_mres_addr + 5) = (unsigned char)((data >>  8) & 0x000000ff);
        *(p_mres_addr + 4) = (unsigned char)( data        & 0x000000ff);
    }
#else  /* _HOST_ENDIAN_BIG (_LITTLE_ENDIAN) */
    if (ced_endian_type == CPU_ENDIAN_BIG) {
        *(p_mres_addr)     = (unsigned char)((data >> 24) & 0x000000ff);
        *(p_mres_addr + 1) = (unsigned char)((data >> 16) & 0x000000ff);
        *(p_mres_addr + 2) = (unsigned char)((data >>  8) & 0x000000ff);
        *(p_mres_addr + 3) = (unsigned char)( data        & 0x000000ff);
    } else {
        *((unsigned long *)p_mres_addr + 1) = data;
    }
#endif  /* _HOST_ENDIAN_BIG */
}


void Cmemory::MemWriteBodyQuadwordL (unsigned char *p_mres_addr, unsigned long data)
{
#ifdef _HOST_ENDIAN_BIG
    if (ced_endian_type == CPU_ENDIAN_BIG) {
        *((unsigned long *)p_mres_addr + 1) = data;
    } else {
        *(p_mres_addr + 3) = (unsigned char)((data >> 24) & 0x000000ff);
        *(p_mres_addr + 2) = (unsigned char)((data >> 16) & 0x000000ff);
        *(p_mres_addr + 1) = (unsigned char)((data >>  8) & 0x000000ff);
        *(p_mres_addr)     = (unsigned char)( data        & 0x000000ff);
    }
#else  /* _HOST_ENDIAN_BIG (_LITTLE_ENDIAN) */
    if (ced_endian_type == CPU_ENDIAN_BIG) {
        *(p_mres_addr + 4) = (unsigned char)((data >> 24) & 0x000000ff);
        *(p_mres_addr + 5) = (unsigned char)((data >> 16) & 0x000000ff);
        *(p_mres_addr + 6) = (unsigned char)((data >>  8) & 0x000000ff);
        *(p_mres_addr + 7) = (unsigned char)( data        & 0x000000ff);
    } else {
        *(unsigned long *)p_mres_addr = data;
    }
#endif  /* _HOST_ENDIAN_BIG */
}


void Cmemory::MemWriteBodyWordAse (unsigned char *p_mres_addr, unsigned long data)
{
#ifdef _HOST_ENDIAN_BIG
    *(unsigned short *)p_mres_addr = data & 0x0000ffff;
#else  /* _HOST_ENDIAN_BIG (_LITTLE_ENDIAN) */
    *(p_mres_addr)     = (unsigned char)((data >> 8) & 0x000000ff);
    *(p_mres_addr + 1) = (unsigned char)( data       & 0x000000ff);
#endif  /* _HOST_ENDIAN_BIG */
}


void Cmemory::MemWriteBodyLongwordAse (unsigned char *p_mres_addr, unsigned long data)
{
#ifdef _HOST_ENDIAN_BIG
    *(unsigned long *)p_mres_addr = data;
#else  /* _HOST_ENDIAN_BIG (_LITTLE_ENDIAN) */
    *(p_mres_addr)     = (unsigned char)((data >> 24) & 0x000000ff);
    *(p_mres_addr + 1) = (unsigned char)((data >> 16) & 0x000000ff);
    *(p_mres_addr + 2) = (unsigned char)((data >>  8) & 0x000000ff);
    *(p_mres_addr + 3) = (unsigned char)( data        & 0x000000ff);
#endif  /* _HOST_ENDIAN_BIG */
}


void Cmemory::MemWriteBodyQuadwordUAse (unsigned char *p_mres_addr, unsigned long data)
{
#ifdef _HOST_ENDIAN_BIG
    *(unsigned long *)p_mres_addr = data;
#else  /* _HOST_ENDIAN_BIG (_LITTLE_ENDIAN) */
    *(p_mres_addr)     = (unsigned char)((data >> 24) & 0x000000ff);
    *(p_mres_addr + 1) = (unsigned char)((data >> 16) & 0x000000ff);
    *(p_mres_addr + 2) = (unsigned char)((data >>  8) & 0x000000ff);
    *(p_mres_addr + 3) = (unsigned char)( data        & 0x000000ff);
#endif  /* _HOST_ENDIAN_BIG */
}


void Cmemory::MemWriteBodyQuadwordLAse (unsigned char *p_mres_addr, unsigned long data)
{
#ifdef _HOST_ENDIAN_BIG
    *((unsigned long *)p_mres_addr + 1) = data;
#else  /* _HOST_ENDIAN_BIG (_LITTLE_ENDIAN) */
    *(p_mres_addr + 4) = (unsigned char)((data >> 24) & 0x000000ff);
    *(p_mres_addr + 5) = (unsigned char)((data >> 16) & 0x000000ff);
    *(p_mres_addr + 6) = (unsigned char)((data >>  8) & 0x000000ff);
    *(p_mres_addr + 7) = (unsigned char)( data        & 0x000000ff);
#endif  /* _HOST_ENDIAN_BIG */
}


unsigned long Cmemory::MemReadBody (unsigned long addr, MemAccessDataType size)
{
    unsigned char *p_mem_addr;
    unsigned long read_data;
    MemoryBlock *p_mem_block;

    /* $B0z?t$N%"%I%l%9$+$i%a%b%j%V%m%C%/$N<BBN$r8!:w(B */
    p_mem_block = MemBlockSearch (addr);

    if (p_mem_block != NULL) {
        /* $B%a%b%j$N<BBN$X$N%]%$%s%?$r<hF@(B */
        p_mem_addr = p_mem_block->p_mblock_body + (addr & 0x0000FFFF);
    } else {
        if (g_shadow_mode == SHADOW_ON) {
            /* $B%@%_!<NN0h$r3NJ](B */
            d_printf (MSG_WAR, "<Warning: Allocated Dummy Memory Area %08lX-%08lX>\n",
                      addr & 0xFFFF0000, addr | 0x0000FFFF);
            //ForestMemResourceAdd (addr & 0xFFFF0000, addr | 0x0000FFFF,
            MemResourceAdd (addr & 0xFFFF0000, addr | 0x0000FFFF,
                                  READ_WRITE, 0, DUMMY_MEM_AREA);
            p_mem_block = MemBlockSearch (addr);
        }
        if (p_mem_block == NULL) {
            ErrorCodeSet (E_MEM_INVALID_ADDRESS);  /* $B%a%b%jNN0h30$X$N%"%/%;%9(B */
            d_printf (MSG_ERR, "E_MEM_INVALID_ADDRESS: UNALLOC: %08lX\n", addr);
            ForestSetInvalidAddress (addr);
            return (U_NG);                /* $BNc30H/@8(B */
        }
        /* $B%a%b%j$N<BBN$X$N%]%$%s%?$r<hF@(B */
        p_mem_addr = p_mem_block->p_mblock_body + (addr & 0x0000FFFF);
    }

    /* $B%"%/%;%9$N5v2DH=Dj(B */
    if (p_mem_block->mblock_restrict_type == WRITE_ONLY) { // @@ && ced_sim_state == SIMULATE_ON) {
        ErrorCodeSet (E_MEM_READ_FROM_WO);  /* $B%i%$%H%*%s%j!<NN0h$+$i$NFI$_9~$_(B */
        ForestSetInvalidAddress (addr);
        return (U_NG);
    }

#ifdef HEW_REG
    if (p_mem_block->mblock_area == HEW_REG_AREA) {
        /* HEW $B%l%8%9%?$+$i$NFI$_=P$7(B */
        if (HewRegRead (addr, &read_data, size) == 1) {
            /* $B@.8y$9$l$P=hM}40N;(B */
            /* $B<:GT$9$l$P3NJ]NN0h$X$N%"%/%;%9(B */
            return (read_data);
        }
    }
#endif /* HEW_REG */

    /* $B%a%b%jNN0h$X$N%]%$%s%?$r<hF@(B */
    p_mem_addr = p_mem_block->p_mblock_body + (addr & 0x0000FFFF);

#ifndef _ASE_BIG_
    /* $B%G!<%?%j!<%I=hM}(B */
    switch (size) {
    case MEMACCESS_BYTE:       read_data = MemReadBodyByte (p_mem_addr);      break;
    case MEMACCESS_WORD:       read_data = MemReadBodyWord (p_mem_addr);      break;
    case MEMACCESS_LONGWORD:   read_data = MemReadBodyLongword (p_mem_addr);  break;
    case MEMACCESS_QUADWORD_U: read_data = MemReadBodyQuadwordU (p_mem_addr); break;
    case MEMACCESS_QUADWORD_L: read_data = MemReadBodyQuadwordL (p_mem_addr); break;
    default:         ErrorCodeSet (E_CEDAR_INTERNAL); return (U_NG);  // H.M break;
    }
#else //_ASE_BIG_
    if ((addr < 0xFC000000) || (addr > 0xFC3FFFFF)){
        /* $B%G!<%?%j!<%I=hM}(B */
        switch (size) {
        case MEMACCESS_BYTE:       read_data = MemReadBodyByte (p_mem_addr);      break;
        case MEMACCESS_WORD:       read_data = MemReadBodyWord (p_mem_addr);      break;
        case MEMACCESS_LONGWORD:   read_data = MemReadBodyLongword (p_mem_addr);  break;
        case MEMACCESS_QUADWORD_U: read_data = MemReadBodyQuadwordU (p_mem_addr); break;
        case MEMACCESS_QUADWORD_L: read_data = MemReadBodyQuadwordL (p_mem_addr); break;
        default:         ErrorCodeSet (E_CEDAR_INTERNAL); return (U_NG);  break;
        }
    } else {
        //ASE$B%a%b%jNN0h(B($B>o;~(BBIG$B%(%s%G%#%"%s(B)
        /* $B%G!<%?%j!<%I=hM}(B */
        switch (size) {
        case MEMACCESS_BYTE:       read_data = MemReadBodyByte (p_mem_addr);      break;
        case MEMACCESS_WORD:       read_data = MemReadBodyWordAse (p_mem_addr);      break;
        case MEMACCESS_LONGWORD:   read_data = MemReadBodyLongwordAse (p_mem_addr);  break;
        case MEMACCESS_QUADWORD_U: read_data = MemReadBodyQuadwordUAse (p_mem_addr); break;
        case MEMACCESS_QUADWORD_L: read_data = MemReadBodyQuadwordLAse (p_mem_addr); break;
        default:         ErrorCodeSet (E_CEDAR_INTERNAL); return (U_NG);  break;
        }
    }
#endif //_ASE_BIG_

#ifdef DEBUG_MEM
if (debug_mem == 1){
    printf("R: addr:%08lx, data:%08lx, size:%lx\n", addr, read_data, size);
}
#endif

    return (read_data);
}


unsigned long Cmemory::MemReadBodyByte (unsigned char *p_mres_addr)
{
    unsigned long read_data;

    read_data = *p_mres_addr;

    return (read_data);
}


unsigned long Cmemory::MemReadBodyWord (unsigned char *p_mres_addr)
{
    unsigned long read_data;

#ifdef _HOST_ENDIAN_BIG
    if (ced_endian_type == CPU_ENDIAN_BIG) {
        read_data = *(unsigned short *)p_mres_addr;
    } else {
        read_data =  (*(p_mres_addr + 1) << 8) + (*(p_mres_addr));
    }
#else  /* _HOST_ENDIAN_BIG (_LITTLE_ENDIAN) */
    if (ced_endian_type == CPU_ENDIAN_BIG) {
        read_data =  (*(p_mres_addr)     << 8) + (*(p_mres_addr + 1));
    } else {
        read_data = *(unsigned short *)p_mres_addr;
    }
#endif  /* _HOST_ENDIAN_BIG */

    return (read_data);
}


unsigned long Cmemory::MemReadBodyLongword (unsigned char *p_mres_addr)
{
    unsigned long read_data;

#ifdef _HOST_ENDIAN_BIG
    if (ced_endian_type == CPU_ENDIAN_BIG) {
        read_data = *(unsigned long *)p_mres_addr;
    } else {
        read_data =  (*(p_mres_addr + 3) << 24) + (*(p_mres_addr + 2) << 16)
                   + (*(p_mres_addr + 1) <<  8) + (*(p_mres_addr));
    }
#else  /* _HOST_ENDIAN_BIG (_LITTLE_ENDIAN) */
    if (ced_endian_type == CPU_ENDIAN_BIG) {
        read_data =  (*(p_mres_addr)     << 24) + (*(p_mres_addr + 1) << 16)
                   + (*(p_mres_addr + 2) <<  8) + (*(p_mres_addr + 3));
    } else {
        read_data = *(unsigned long *)p_mres_addr;
    }
#endif  /* _HOST_ENDIAN_BIG */

    return (read_data);
}


unsigned long Cmemory::MemReadBodyQuadwordU (unsigned char *p_mres_addr)
{
    unsigned long read_data;

#ifdef _HOST_ENDIAN_BIG
    if (ced_endian_type == CPU_ENDIAN_BIG) {
        read_data = *(unsigned long *)p_mres_addr;
    } else {
        read_data =  (*(p_mres_addr + 7) << 24) + (*(p_mres_addr + 6) << 16)
                   + (*(p_mres_addr + 5) <<  8) + (*(p_mres_addr + 4));
    }
#else  /* _HOST_ENDIAN_BIG (_LITTLE_ENDIAN) */
    if (ced_endian_type == CPU_ENDIAN_BIG) {
        read_data =  (*(p_mres_addr)     << 24) + (*(p_mres_addr + 1) << 16)
                   + (*(p_mres_addr + 2) <<  8) + (*(p_mres_addr + 3));
    } else {
        read_data = *((unsigned long *)p_mres_addr + 1);
    }
#endif  /* _HOST_ENDIAN_BIG */

    return (read_data);
}


unsigned long Cmemory::MemReadBodyQuadwordL (unsigned char *p_mres_addr)
{
    unsigned long read_data;

#ifdef _HOST_ENDIAN_BIG
    if (ced_endian_type == CPU_ENDIAN_BIG) {
        read_data = *((unsigned long *)p_mres_addr + 1);
    } else {
        read_data =  (*(p_mres_addr + 3) << 24) + (*(p_mres_addr + 2) << 16)
                   + (*(p_mres_addr + 1) <<  8) + (*(p_mres_addr));
    }
#else  /* _HOST_ENDIAN_BIG (_LITTLE_ENDIAN) */
    if (ced_endian_type == CPU_ENDIAN_BIG) {
        read_data =  (*(p_mres_addr + 4) << 24) + (*(p_mres_addr + 5) << 16)
                   + (*(p_mres_addr + 6) <<  8) + (*(p_mres_addr + 7));
    } else {
        read_data = *(unsigned long *)p_mres_addr;
    }
#endif  /* _HOST_ENDIAN_BIG */

    return (read_data);
}


unsigned long Cmemory::MemReadBodyWordAse (unsigned char *p_mres_addr)
{
    unsigned long read_data;

#ifdef _HOST_ENDIAN_BIG
    read_data = *(unsigned short *)p_mres_addr;
#else  /* _HOST_ENDIAN_BIG (_LITTLE_ENDIAN) */
    read_data =  (*(p_mres_addr)     << 8) + (*(p_mres_addr + 1));
#endif  /* _HOST_ENDIAN_BIG */

    return (read_data);
}


unsigned long Cmemory::MemReadBodyLongwordAse (unsigned char *p_mres_addr)
{
    unsigned long read_data;

#ifdef _HOST_ENDIAN_BIG
    read_data = *(unsigned long *)p_mres_addr;
#else  /* _HOST_ENDIAN_BIG (_LITTLE_ENDIAN) */
    read_data =  (*(p_mres_addr)     << 24) + (*(p_mres_addr + 1) << 16)
               + (*(p_mres_addr + 2) <<  8) + (*(p_mres_addr + 3));
#endif  /* _HOST_ENDIAN_BIG */

    return (read_data);
}


unsigned long Cmemory::MemReadBodyQuadwordUAse (unsigned char *p_mres_addr)
{
    unsigned long read_data;

#ifdef _HOST_ENDIAN_BIG
    read_data = *(unsigned long *)p_mres_addr;
#else  /* _HOST_ENDIAN_BIG (_LITTLE_ENDIAN) */
    read_data =  (*(p_mres_addr)     << 24) + (*(p_mres_addr + 1) << 16)
               + (*(p_mres_addr + 2) <<  8) + (*(p_mres_addr + 3));
#endif  /* _HOST_ENDIAN_BIG */

    return (read_data);
}


unsigned long Cmemory::MemReadBodyQuadwordLAse (unsigned char *p_mres_addr)
{
    unsigned long read_data;

#ifdef _HOST_ENDIAN_BIG
    read_data = *((unsigned long *)p_mres_addr + 1);
#else  /* _HOST_ENDIAN_BIG (_LITTLE_ENDIAN) */
    read_data =  (*(p_mres_addr + 4) << 24) + (*(p_mres_addr + 5) << 16)
               + (*(p_mres_addr + 6) <<  8) + (*(p_mres_addr + 7));
#endif  /* _HOST_ENDIAN_BIG */

    return (read_data);
}


long Cmemory::MemBlockAlloc (unsigned long block_id,
                             MemRestrictType restrict_type,
                             unsigned long mblock_read_state_count,
                             unsigned long mblock_write_state_count,
                             unsigned long mblock_bus_size,
                             MemMappedArea mblock_area)
{
    MemoryBlock   *p_new_block;       /* $B?75,%a%b%j%V%m%C%/$X$N%]%$%s%?(B */
    unsigned char *p_new_block_body;  /* $B?75,%a%b%j<BBN$X$N%]%$%s%?(B */

    /* $B%a%b%j%V%m%C%/B8:_%A%'%C%/(B */
    if (MemBlockIsAlloc (block_id) == 1) {
        ErrorCodeSet (E_MEM_OVERLAP);  /* $B%a%b%j=EJ#%(%i!<(B */
        ForestSetInvalidAddress (block_id << 16);
        return (0);
    }

    /* $B%a%b%j6u4V9=B$BN$NNN0h3NJ](B */
    p_new_block = (MemoryBlock *) malloc (sizeof (MemoryBlock));
    if (p_new_block == NULL) {
        ErrorCodeSet (E_MEM_ALLOCATE);  /* $B%a%b%j3NJ]%(%i!<(B */
        ForestSetInvalidAddress (block_id << 16);
        return (0);
    }

    /* $B%a%b%j<BBN$NNN0h3NJ](B & $B=i4|2=(B */
    p_new_block_body = (unsigned char *) malloc (sizeof (unsigned char) * MEM_BLOCK_SIZE);
    if (p_new_block_body == NULL) {
        ErrorCodeSet (E_MEM_ALLOCATE);  /* $B%a%b%j3NJ]%(%i!<(B */
        ForestSetInvalidAddress (block_id << 16);
        return (0);
    }
    memset (p_new_block_body, ForestGetMemInitValue(), sizeof(unsigned char) * MEM_BLOCK_SIZE);

    /* $B%a%b%j6u4V9=B$BN$KCM$r%;%C%H(B */
    p_new_block->p_mblock_body            = p_new_block_body;
    p_new_block->mblock_restrict_type     = restrict_type;
    p_new_block->mblock_read_state_count  = mblock_read_state_count;
    p_new_block->mblock_write_state_count = mblock_write_state_count;
    p_new_block->mblock_bus_size          = mblock_bus_size;
    p_new_block->mblock_area              = mblock_area;
    p_new_block->mblock_use               = 0;
    /* $B%a%b%j%V%m%C%/%F!<%V%k$XEPO?(B */
    p_mem_block_table[block_id] = p_new_block;

    /* $B@5>o=*N;(B */
    return (1);
}


long Cmemory::MemBlockFree (unsigned long block_id)
{
    /* $B%a%b%j%V%m%C%/B8:_%A%'%C%/(B */
    if (MemBlockIsAlloc (block_id) == 0) {
        ErrorCodeSet (E_MEM_UNALLOCATE);  /* $B%a%b%jHs3NJ]NN0h$r;XDj(B */
        ForestSetInvalidAddress (block_id << 16);
        return (0);
    }

    /* $B%a%b%j%V%m%C%/2rJ|(B */
    free (p_mem_block_table[block_id]->p_mblock_body);
    free (p_mem_block_table[block_id]);
    p_mem_block_table[block_id] = NULL;

    return (1);
}


long Cmemory::MemBlockMove (unsigned long block_from_id, unsigned long block_to_id)
{
    /* $B%a%b%j%V%m%C%/B8:_%A%'%C%/(B */
    if (MemBlockIsAlloc (block_from_id) == 0) {
        ErrorCodeSet (E_MEM_UNALLOCATE);  /* $B%a%b%jHs3NJ]NN0h$r;XDj(B */
        ForestSetInvalidAddress (block_from_id << 16);
        return (0);
    }

    /* $B%a%b%j%V%m%C%/=EJ#%A%'%C%/(B */
    if (MemBlockIsAlloc (block_to_id) == 1) {
        ErrorCodeSet (E_MEM_OVERLAP);  /* $B%a%b%j=EJ#%(%i!<(B */
        ForestSetInvalidAddress (block_to_id << 16);
        return (0);
    }

    /* $B%a%b%j%V%m%C%/%3%T!<(B */
    p_mem_block_table[block_to_id]   = p_mem_block_table[block_from_id];
    p_mem_block_table[block_from_id] = NULL;

    return (1);
}


long Cmemory::MemAttributeSet (unsigned long block_id, MemRestrictType restrict_type,
                               unsigned long mblock_read_state_count,
                               unsigned long mblock_write_state_count,
                               unsigned long mblock_bus_size,
                               MemMappedArea mblock_area)
{
    /* $B%a%b%j%V%m%C%/B8:_%A%'%C%/(B */
    if (MemBlockIsAlloc (block_id) == 0) {
        ErrorCodeSet (E_MEM_UNALLOCATE);  /* $B%a%b%jHs3NJ]NN0h$r;XDj(B */
        ForestSetInvalidAddress (block_id << 16);
        return (0);
    }

    /* $B%a%b%j%V%m%C%/B0@-%;%C%H(B */
    p_mem_block_table[block_id]->mblock_restrict_type     = restrict_type;
    p_mem_block_table[block_id]->mblock_read_state_count  = mblock_read_state_count;
    p_mem_block_table[block_id]->mblock_write_state_count = mblock_write_state_count;
    p_mem_block_table[block_id]->mblock_bus_size          = mblock_bus_size;
    p_mem_block_table[block_id]->mblock_area              = mblock_area;

    return (1);
}


long Cmemory::MemAttributeGet (unsigned long block_id, MemoryBlock **pp_mem_block)
{
    /* $B%a%b%j%V%m%C%/B8:_%A%'%C%/(B */
    if (MemBlockIsAlloc (block_id) == 0) {
        ErrorCodeSet (E_MEM_UNALLOCATE);  /* $B%a%b%jHs3NJ]NN0h$r;XDj(B */
        ForestSetInvalidAddress (block_id << 16);
        return (0);
    }

    *pp_mem_block = p_mem_block_table[block_id];

    return (1);
}


long Cmemory::MemBlockIsAlloc (unsigned long block_id)
{
    if (p_mem_block_table[block_id] != NULL) {
        /* $B3NJ]:Q$_(B */
        return (1);
    } else {
        /* $BL$3NJ](B */
        return (0);
    }
}


MemoryBlock *Cmemory::MemBlockSearch (unsigned long addr)
{
    return (p_mem_block_table[addr>>16]);
}


unsigned char *Cmemory::GetMemBodyPointer(unsigned long addr)
{
    unsigned char *p_mem_addr;
    MemoryBlock *p_mem_block;

    /* $B0z?t$N%"%I%l%9$+$i%a%b%j%V%m%C%/$N<BBN$r8!:w(B */
    p_mem_block = MemBlockSearch (addr);

    if (p_mem_block != NULL) {
        /* $B%a%b%j$N<BBN$X$N%]%$%s%?$r<hF@(B */
        p_mem_addr = p_mem_block->p_mblock_body + (addr & 0x0000FFFF);
        /* $B%a%b%jNN0h$X$N%]%$%s%?$r<hF@(B */
        return(p_mem_addr);
    } else {
        ErrorCodeSet (E_MEM_INVALID_ADDRESS);  /* $B%a%b%jNN0h30$X$N%"%/%;%9(B */
        d_printf (MSG_ERR, "E_MEM_INVALID_ADDRESS: UNALLOC: %08lX\n", addr);
        ForestSetInvalidAddress (addr);
        return(NULL);                /* $BNc30H/@8(B */
    }
}


long Cmemory::MemBlockAllocContinuously (unsigned long block_id,
                             MemRestrictType restrict_type,
                             unsigned long mblock_read_state_count,
                             unsigned long mblock_write_state_count,
                             unsigned long mblock_bus_size,
                             MemMappedArea mblock_area,
                             unsigned long continuous_num)
{
    MemoryBlock   *p_new_block;       /* $B?75,%a%b%j%V%m%C%/$X$N%]%$%s%?(B */
    unsigned char *p_new_block_body;  /* $B?75,%a%b%j<BBN$X$N%]%$%s%?(B */
    //MemoryBlock   *p_old_block;       /* $B5l%a%b%j%V%m%C%/$X$N%]%$%s%?(B */
    unsigned long i;
    
// H.M    unsigned long need_free_before, need_free_after;
    MemoryBlock *p_new_block_array;
    unsigned long block_id_fix, continuous_num_fix;
    unsigned long before_area_addr, after_area_addr;
    unsigned long before_num = 0, after_num = 0;
//    MemoryBlock *p_old_block_free_before = NULL, *p_old_block_free_after = NULL;
    MemoryBlock *p_old_memory_block = NULL;

    //printf("<<< MemBlockAllocContinuously Start >>>\n");
    //printf("block_id:%lX, continuous_num:%ld\n", block_id, continuous_num);
    //fflush(NULL);

    /* $B3NJ]MW5a$NN>B&$KNY@\$9$kNN0h$r3NG'(B */
    before_area_addr = MemBlockSearchBefore(block_id << 16UL);
    if (before_area_addr != 0xFFFFFFFF){
        before_num = block_id - (before_area_addr >> 16);
        block_id_fix = (before_area_addr >> 16);
    } else {
        block_id_fix = block_id;
    }
    after_area_addr  = MemBlockSearchAfter((block_id + (continuous_num - 1UL)) << 16UL);
    if (after_area_addr != 0xFFFFFFFF){
        after_num = (after_area_addr >> 16) - (block_id + (continuous_num - 1UL));
    }

    continuous_num_fix = continuous_num + before_num + after_num;

#if 0
    //$BNY@\$9$k%V%m%C%/$N5l%a%b%j$r3+J|$9$k$?$a$NA0=hM}(B
    //free$B$9$Y$-$ONY@\%V%m%C%/72$N@hF,$N$_$G$"$k$3$H$KCm0U(B  
    if (MemBlockIsAlloc (block_id_fix) == 1) {
        //$BA0J}$KNY@\%V%m%C%/M-$j(B  
        need_free_before = block_id_fix;
    } else {
        need_free_before = 0xFFFFFFFF;
    }
    if (MemBlockIsAlloc (block_id + 1) == 1) {
        //$B8eJ}$KNY@\%V%m%C%/M-$j(B  
        need_free_after = block_id + 1;
    } else {
        need_free_after = 0xFFFFFFFF;
    }
#endif // 0

    //$B4{$K3NJ]:Q$_!JA08e$KNY@\$9$k%a%b%j$N%]%$%s%?$,F10l!K$J$i$P!"=hM}ITMW!#(B  
    //$BA46u4V=hM}$,O"B3E*$K3NJ]$5$l$F$$$k$+!"3NG'I,?\(B  
    //if (
    //    return(1)
    //}

    //printf("block_id_fix:%lX, continuous_num_fix:%ld\n", block_id_fix, continuous_num_fix);
    //fflush(NULL);
    p_new_block_array = (MemoryBlock *) malloc (sizeof (MemoryBlock) * continuous_num_fix);
    if (p_new_block_array == NULL) {
        ErrorCodeSet (E_MEM_ALLOCATE);  /* $B%a%b%j3NJ]%(%i!<(B */
        ForestSetInvalidAddress (block_id << 16);
        return (0);
    }

    //printf("p_new_block_array:%p, size:%ld\n", p_new_block_array, sizeof (MemoryBlock *) * continuous_num_fix);
    //fflush(NULL);
    /* $B%a%b%j<BBN$NNN0h3NJ](B & $B=i4|2=(B */
    p_new_block_body = (unsigned char *) malloc (sizeof (unsigned char) * MEM_BLOCK_SIZE * continuous_num_fix);
    if (p_new_block_body == NULL) {
        ErrorCodeSet (E_MEM_ALLOCATE);  /* $B%a%b%j3NJ]%(%i!<(B */
        ForestSetInvalidAddress (block_id << 16);
        free(p_new_block_array);
        return (0);
    }
    memset (p_new_block_body, ForestGetMemInitValue(), sizeof(unsigned char) * MEM_BLOCK_SIZE * continuous_num_fix);
    
    //printf("p_new_block_body:%p, size:%lX\n", p_new_block_body, sizeof(unsigned char) * MEM_BLOCK_SIZE * continuous_num_fix);
    //fflush(NULL);
    for (i = block_id_fix; i < block_id_fix + continuous_num_fix; i++){
        /* $B%a%b%j%V%m%C%/B8:_%A%'%C%/(B */
        if (MemBlockIsAlloc (i) == 1) {
            //$BB8:_$7$?$i(B  
            //$B5l(B->$B?7$X$N%a%b%j%3%T!<!"5l%a%b%j<BBN$N2rJ|!"5l%a%b%j6u4V9=B$BN$N2rJ|$,I,MW(B  
            //printf("[%lX] memcpy : source=%p, dest=%p, size=%lX\n", i, p_new_block_body + (MEM_BLOCK_SIZE*(i - block_id_fix)), p_mem_block_table[i]->p_mblock_body, sizeof(unsigned char) * MEM_BLOCK_SIZE);
            //fflush(NULL);
            memcpy( p_new_block_body + (MEM_BLOCK_SIZE*(i - block_id_fix)), p_mem_block_table[i]->p_mblock_body, sizeof(unsigned char) * MEM_BLOCK_SIZE);
            if (p_old_memory_block == NULL){
                // $B$"$H$G3+J|$9$k$?$a$K%]%$%s%?$r3JG<!#(BNULL$B$OO"B3NN0h$N@hF,$r<($9(B  
                p_old_memory_block = p_mem_block_table[i];
            }
            /* $B%a%b%j6u4V9=B$BN$NNN0h3NJ](B */
            p_new_block = &p_new_block_array[i-block_id_fix];
            /* $B;HMQ>pJs%U%i%0$r5l%a%b%j%V%m%C%/$+$i%3%T!<(B */
            p_new_block->mblock_use = p_mem_block_table[i]->mblock_use;
            
        } else {
            /* $BB8:_$7$J$$>l9g(B */
            //memset( p_new_block_body + (MEM_BLOCK_SIZE*(i - block_id_fix)), mem_init_val, sizeof(unsigned char) * MEM_BLOCK_SIZE);
            if (p_old_memory_block != NULL){
                free(p_old_memory_block->p_mblock_body);
                free(p_old_memory_block);
                p_old_memory_block = NULL;
            }
            /* $B%a%b%j6u4V9=B$BN$NNN0h3NJ](B */
            p_new_block = &p_new_block_array[i-block_id_fix];
            /* $B?75,%a%b%j%V%m%C%/$J$N$G;HMQ>pJs%U%i%0$r#0$K@_Dj(B */
            p_new_block->mblock_use               = 0;
        }

        /* $B%a%b%j6u4V9=B$BN$KCM$r%;%C%H(B */
        p_new_block->p_mblock_body            = p_new_block_body + MEM_BLOCK_SIZE * (i - block_id_fix);
        p_new_block->mblock_restrict_type     = restrict_type;
        p_new_block->mblock_read_state_count  = mblock_read_state_count;
        p_new_block->mblock_write_state_count = mblock_write_state_count;
        p_new_block->mblock_bus_size          = mblock_bus_size;
        p_new_block->mblock_area              = mblock_area;

        /* $B%a%b%j%V%m%C%/%F!<%V%k$XEPO?(B */
        p_mem_block_table[i] = p_new_block;
    }

    /* $B:G8e$NNN0h$,4{B8NN0h$@$C$?$i$3$3$G3+J|(B */
    if (p_old_memory_block != NULL){
        free(p_old_memory_block->p_mblock_body);
        free(p_old_memory_block);
        p_old_memory_block = NULL;
    }


#if 0
    if (need_free_before != 0xFFFFFFFF){
        //$BA0J}$KNY@\%V%m%C%/M-$j(B  
        p_old_block_free_before = p_mem_block_table[need_free_before];
    }

    for (i = 0; i < before_num; i++){
        /* $B%a%b%j6u4V9=B$BN$NNN0h3NJ](B */
        p_new_block = &p_new_block_array[i];
        p_old_block = p_mem_block_table[block_id_fix + i];

        /* $B%a%b%j6u4V9=B$BN$KCM$r%;%C%H(B */
        p_new_block->p_mblock_body            = p_new_block_body + MEM_BLOCK_SIZE * i;
        p_new_block->mblock_restrict_type     = p_old_block->mblock_restrict_type;
        p_new_block->mblock_read_state_count  = p_old_block->mblock_read_state_count;
        p_new_block->mblock_write_state_count = p_old_block->mblock_write_state_count;
        p_new_block->mblock_bus_size          = p_old_block->mblock_bus_size;
        p_new_block->mblock_area              = p_old_block->mblock_area;
        p_new_block->mblock_use               = p_old_block->mblock_use;

        /* $B%a%b%j%V%m%C%/%F!<%V%k$XEPO?(B */
        p_mem_block_table[i + block_id_fix] = p_new_block;
    }

    //$BNY@\$9$k%V%m%C%/$N5l%a%b%j$r3+J|(B
    //free$B$9$Y$-$ONY@\%V%m%C%/72$N@hF,$N$_$G$"$k$3$H$KCm0U(B  
    if (need_free_before != 0xFFFFFFFF){
        //$BA0J}$KNY@\%V%m%C%/M-$j(B  
        free(p_old_block_free_before->p_mblock_body);
        free(p_old_block_free_before);
    }


    for (i = before_num; i < continuous_num + before_num; i++){
        /* $B%a%b%j6u4V9=B$BN$NNN0h3NJ](B */
        p_new_block = &p_new_block_array[i];

        /* $B%a%b%j6u4V9=B$BN$KCM$r%;%C%H(B */
        p_new_block->p_mblock_body            = p_new_block_body + MEM_BLOCK_SIZE * i;
        p_new_block->mblock_restrict_type     = restrict_type;
        p_new_block->mblock_read_state_count  = mblock_read_state_count;
        p_new_block->mblock_write_state_count = mblock_write_state_count;
        p_new_block->mblock_bus_size          = mblock_bus_size;
        p_new_block->mblock_area              = mblock_area;
        p_new_block->mblock_use               = 0;

        /* $B%a%b%j%V%m%C%/%F!<%V%k$XEPO?(B */
        p_mem_block_table[i + block_id_fix] = p_new_block;
    }


    if (need_free_after != 0xFFFFFFFF){
        //$B8eJ}$KNY@\%V%m%C%/M-$j(B  
        p_old_block_free_after = p_mem_block_table[need_free_after];
    }
    for (i = continuous_num + before_num; i < continuous_num_fix; i++){
        /* $B%a%b%j6u4V9=B$BN$NNN0h3NJ](B */
        p_new_block = &p_new_block_array[i];
        p_old_block = p_mem_block_table[block_id_fix + i];

        /* $B%a%b%j6u4V9=B$BN$KCM$r%;%C%H(B */
        p_new_block->p_mblock_body            = p_new_block_body + MEM_BLOCK_SIZE * i;
        p_new_block->mblock_restrict_type     = p_old_block->mblock_restrict_type;
        p_new_block->mblock_read_state_count  = p_old_block->mblock_read_state_count;
        p_new_block->mblock_write_state_count = p_old_block->mblock_write_state_count;
        p_new_block->mblock_bus_size          = p_old_block->mblock_bus_size;
        p_new_block->mblock_area              = p_old_block->mblock_area;
        p_new_block->mblock_use               = p_old_block->mblock_use;

        /* $B%a%b%j%V%m%C%/%F!<%V%k$XEPO?(B */
        p_mem_block_table[i + block_id_fix] = p_new_block;
    }
    if (need_free_after != 0xFFFFFFFF){
        //$B8eJ}$KNY@\%V%m%C%/M-$j(B  
        free(p_old_block_free_after->p_mblock_body);
        free(p_old_block_free_after);
    }
#endif //0

    /* $B@5>o=*N;(B */
    return (1);
}


//$B;XDj%"%I%l%9$NNN0h$KO"B3$9$k8eJ}$N%a%b%jNN0h$r8!:w(B
unsigned long Cmemory::MemBlockSearchAfter(unsigned long addr)
{
    unsigned long i;
    unsigned long target = 0xFFFFFFFF;

    //$B;XDj%"%I%l%9$HNY@\$9$k%a%b%jNN0h$r8eJ}8!:w(B  
    for (i = ((addr >> 16UL) + 1UL); i < MEM_BLOCK_SIZE; i++){
        if (p_mem_block_table[i] == NULL){
            //$BHsO"B3NN0h$r8!=P$7$?(B  
            //$BHsO"B3NN0h!\#1$NNN0h$^$G$OO"B3(B  
            target = (i - 1UL) << 16UL;
            //$BO"B3NN0h$,;XDj%"%I%l%9$NNN0h$H0lCW$9$k$+%A%'%C%/(B  
            if (target == (addr & 0xFFFF0000)){
                //$B0lCW$7$?$N$G!";XDj%"%I%l%9$NO"B3NN0h$OL5$7(B  
                target = 0xFFFFFFFF;
            }
            break;
        }
    }

    //0xFFFF0000$BHVCO$NNN0h$^$GO"B3NN0h$,B8:_$9$k$H$-MQ$N%k!<%A%s(B  
    if (i >= MEM_BLOCK_SIZE){
        //0$BHVCONN0h$^$GO"B3NN0h$,B8:_(B  
        if ((addr & 0xFFFF0000) == 0xFFFF0000){
            //0$BHVCONN0h$O;XDj%"%I%l%9$NNN0h$H0lCW(B  
            target = 0xFFFFFFFF;
        } else {
            //0$BHVCONN0h$O;XDj%"%I%l%9$NNN0h$HIT0lCW(B  
            target = 0xFFFF0000;
        }
    }

    return (target);
}


//$B;XDj%"%I%l%9$NNN0h$KO"B3$9$kA0J}$N%a%b%jNN0h$r8!:w(B
unsigned long Cmemory::MemBlockSearchBefore(unsigned long addr)
{
    unsigned long i;
    unsigned long target = 0xFFFFFFFF;

    //$B;XDj%"%I%l%9$HNY@\$9$k%a%b%jNN0h$rA0J}8!:w(B  
    for (i = ((addr >> 16UL) - 1UL); i < MEM_BLOCK_SIZE; i--){
        if (p_mem_block_table[i] == NULL){
            //$BHsO"B3NN0h$r8!=P$7$?(B  
            //$BHsO"B3NN0h!\#1$NNN0h$^$G$OO"B3(B  
            target = (i + 1UL) << 16UL;
            //$BO"B3NN0h$,;XDj%"%I%l%9$NNN0h$H0lCW$9$k$+%A%'%C%/(B  
            if (target == (addr & 0xFFFF0000)){
                //$B0lCW$7$?$N$G!";XDj%"%I%l%9$NO"B3NN0h$OL5$7(B  
                target = 0xFFFFFFFF;
            }
            break;
        }
    }

    //0x0$BHVCO$NNN0h$^$GO"B3NN0h$,B8:_$9$k$H$-MQ$N%k!<%A%s(B  
    if (i >= MEM_BLOCK_SIZE){
        //0$BHVCONN0h$^$GO"B3NN0h$,B8:_(B  
        if ((addr & 0xFFFF0000) == 0x00000000){
            //0$BHVCONN0h$O;XDj%"%I%l%9$NNN0h$H0lCW(B  
            target = 0xFFFFFFFF;
        } else {
            //0$BHVCONN0h$O;XDj%"%I%l%9$NNN0h$HIT0lCW(B  
            target = 0x00000000;
        }
    }

    return (target);
}

#if 0
// $B;XDj%"%I%l%9$NNN0h$K4^$^$l$k%a%b%jNN0h$r8!:w(B
unsigned long Cmemory::MemBlockSearchContain(unsigned long start_addr, unsigned long end_addr)
{
    unsigned long i;
    unsigned long target = 0xFFFFFFFF;
    unsigned long start_fix = start_addr >> 16UL;
    unsigned long end_fix = end_addr >> 16UL;

    /* $B40A4$K4^$^$l$F$$$J$$NN0h$OL5;k(B ($BB>%k!<%A%s$,=hM}$9$k$N$G(B) */
    if ((start_fix != 0) && (p_mem_block_table[start_fix - 1UL] != NULL)){
        // $BNY@\$9$k6u4V$H%*!<%P!<%i%C%W$9$kNN0h$,$"$k$J$i3+;O0LCV$rJd@5(B  
        while((p_mem_block_table[start_fix] != NULL) && (start_fix < (MEM_BLOCK_SIZE - 1))){
            start_fix++;
        }
    }

    if ((end_fix != 0xFFFF) && (p_mem_block_table[end_fix + 1UL] != NULL)){
        // $BNY@\$9$k6u4V$H%*!<%P!<%i%C%W$9$kNN0h$,$"$k$J$i=*N;0LCV$rJd@5(B  
        while((p_mem_block_table[end_fix] != NULL) && (end_fix >= 1)){
            end_fix--;
        }
    }

    // $B;XDj%"%I%l%9$HNY@\$9$k%a%b%jNN0h$r;XDj(BID$B0J9_$+$i8!:w(B  
    for (i = start_fix ; i < MEM_BLOCK_SIZE; i++){
        if (p_mem_block_table[i] != NULL){
            // $B4{B8NN0h$r8!=P$7$?(B  
            //$BO"B3NN0h$,;XDj%"%I%l%9$NNN0hFb$+%A%'%C%/(B  
            if (i >= end_fix){
                //$B0lCW$7$?$N$G!";XDj%"%I%l%9$NO"B3NN0h$OL5$7(B  
                target = 0xFFFFFFFF;
            } else {
                target = i << 16UL;
            }
            break;
        }
    }

    return (target);
}
#endif //0

unsigned long Cmemory::CheckMemoryAddressStart(unsigned long start, unsigned long end)
{
    int i;
    unsigned long fix_addr = start;
    unsigned long previous_fix_addr = 0xFFFFFFFFUL;

    /* $B%a%b%j%^%C%W4IM}G[Ns$X$NEPO?$,$J$$>l9g(B */
    if (n_mem_resources == 0) {
        return(start);
    } else {
        /* $B3+;O%"%I%l%9$,B>%(%s%H%jHO0O$K4^$^$l$F$$$J$$$+%A%'%C%/(B */
        while(fix_addr != previous_fix_addr) {
            previous_fix_addr = fix_addr;
            for (i = 0; i < n_mem_resources; i++) {
                if ((p_mem_resources[i]->mres_start_addr <= fix_addr) && (p_mem_resources[i]->mres_end_addr >= fix_addr)){
                    if (p_mem_resources[i]->mres_end_addr == 0xFFFFFFFFUL){
                        fix_addr = 0xFFFFFFFFUL;
                        return(fix_addr); /* $B3+;O0LCV$,:GBgCM$@$C$?$i3NJ]ITMW$J$N$G$9$0%j%?!<%s(B */
                    }
                    fix_addr = p_mem_resources[i]->mres_end_addr + 1UL;
                }
            }
        }
    }

    if (fix_addr > end){
        fix_addr = 0xFFFFFFFFUL;
    }

    return(fix_addr);
}


unsigned long Cmemory::CheckMemoryAddressEnd(unsigned long start, unsigned long end)
{
    int i;
    unsigned long fix_addr = end;
    unsigned long previous_fix_addr = 0x00000000UL;

    /* $B%a%b%j%^%C%W4IM}G[Ns$X$NEPO?$,$J$$>l9g(B */
    if (n_mem_resources == 0) {
        return(end);
    } else {
        /* $B3+;O%"%I%l%9$,B>%(%s%H%jHO0O$K4^$^$l$F$$$J$$$+%A%'%C%/(B */
        while(fix_addr != previous_fix_addr) {
            previous_fix_addr = fix_addr;
            for (i = 0; i < n_mem_resources; i++) {
                if ((p_mem_resources[i]->mres_start_addr <= fix_addr) && (p_mem_resources[i]->mres_end_addr >= fix_addr)){
                    if (p_mem_resources[i]->mres_end_addr == 0x00000000UL){
                        fix_addr = 0x00000000UL;
                        return(fix_addr); /* $B3+;O0LCV$,:GBgCM$@$C$?$i3NJ]ITMW$J$N$G$9$0%j%?!<%s(B */
                    }
                    fix_addr = p_mem_resources[i]->mres_start_addr - 1UL;
                }
            }
        }
    }

    if (start > fix_addr){
        fix_addr = 0UL;
    }

    return(fix_addr);
}


void Cmemory::MemResourceAdd (unsigned long start_addr,
                              unsigned long end_addr,
                              MemRestrictType restrict_type,
                              unsigned long read_latency,
                              MemMappedArea area_type)
{
    MemoryResource *p_new_resource;       /* $B?75,%a%b%j%^%C%W9=B$BN$X$N%]%$%s%?(B */
    unsigned long i;
    unsigned long start_addr_fix, end_addr_fix;

#if 0
    start_addr_fix = start_addr;
    end_addr_fix = end_addr;

#else
    /* $B;XDjNN0h$,4{B8$+%A%'%C%/(B */
    /* $B3+;ONN0h$rJd@5(B */
    start_addr_fix = CheckMemoryAddressStart(start_addr & 0xFFFF0000, end_addr | 0x0000FFFF);
    /* $B=*N;NN0h$rJd@5(B */
    end_addr_fix = CheckMemoryAddressEnd(start_addr_fix, end_addr | 0x0000FFFF);
    /* $B$b$7$bA4NN0h$r4^$s$G$$$?$i2?$b$;$:%j%?!<%s(B */
    if (end_addr_fix <= start_addr_fix){
        return;
    }
    //printf("start:%08lX, end:%08lX\n", start_addr_fix, end_addr_fix);
    //fflush(NULL);
#endif //0

    /* $B%a%b%j%^%C%W?t$N%*!<%P!<%U%m!<%A%'%C%/(B */
    if (n_mem_resources == MAX_MEM_RES) {
        ErrorCodeSet (E_MEM_RES_OVERFLOW);  /* $B%a%b%j%^%C%W?t%*!<%P!<%U%m!<(B */
        d_printf (MSG_ERR, "E_MEM_RES_OVERFLOW: %ld\n", n_mem_resources);
        ForestSetInvalidAddress (start_addr);
        return;
    }

    /* $B%a%b%j%^%C%W9=B$BN$NNN0h3NJ](B */
    p_new_resource = (MemoryResource *) malloc (sizeof (MemoryResource));
    if (p_new_resource == NULL) {
        ErrorCodeSet (E_MEM_ALLOCATE);  /* $B%a%b%j3NJ]%(%i!<(B */
        d_printf (MSG_ERR, "E_MEM_ALLOCATE: Struct: %08lX - %08lX\n", start_addr, end_addr);
        ForestSetInvalidAddress (start_addr);
        return;
    }

#ifndef MEMALLOC_CONTINUOUSLY
    for (i = (start_addr >> 16); i <= (end_addr >> 16); i++) {
        MemBlockAlloc (i, restrict_type, read_latency, 0, 0, area_type);
    }
#else //MEMALLOC_CONTINUOUSLY
    MemBlockAllocContinuously (start_addr_fix >> 16, restrict_type, read_latency, 0, 0, area_type, ((end_addr_fix >> 16UL) - (start_addr_fix >> 16UL)) + 1);
#endif //MEMALLOC_CONTINUOUSLY
    
    if (cedarErrno == E_MEM_OVERLAP) {
        d_printf (MSG_ERR, "E_MEM_OVERLAP: %08lX - %08lX\n", start_addr, end_addr);            
        ForestSetInvalidAddress (start_addr);
    }

    if (cedarErrno == E_MEM_ALLOCATE) {
        d_printf (MSG_ERR, "E_MEM_ALLOCATE: %08lX - %08lX\n", start_addr, end_addr);            
        ForestSetInvalidAddress (start_addr);
        free(p_new_resource);
        return;
    }

    /* $B%a%b%j%^%C%W9=B$BN$KCM$r%;%C%H(B */
    p_new_resource->mres_start_addr    = start_addr_fix & 0xFFFF0000;
    p_new_resource->mres_end_addr      = end_addr_fix   | 0x0000FFFF;
    p_new_resource->mres_restrict_type = restrict_type;
    p_new_resource->mres_read_latency  = read_latency;
    p_new_resource->mres_area_type     = area_type;

    /* $B%a%b%j%^%C%W4IM}G[Ns$X$NEPO?(B */
    if (n_mem_resources == 0) {
        p_mem_resources[0] = p_new_resource;
        p_mem_resources[0]->mres_index = 0;
    } else {
        /* $B%a%b%j%^%C%W4IM}G[Ns$X$NA^F~0LCV$N8!:w(B */
        for (i = n_mem_resources; i > 0; i--) {
            if (p_mem_resources[i-1]->mres_start_addr < start_addr_fix)
                break;
            p_mem_resources[i] = p_mem_resources[i-1];
            p_mem_resources[i]->mres_index = i;
        }
        p_mem_resources[i] = p_new_resource;
        p_mem_resources[i]->mres_index = i;
    }

    /* $B%a%b%j%^%C%W?t$N99?7(B */
    n_mem_resources++;
}


long Cmemory::MemResourceSearch (unsigned long addr)
{
    long mres_index;    /* $B%^%C%W8!:w%$%s%G%C%/%9(B */

    /* $B0z?t$N%"%I%l%9$+$i%a%b%j%^%C%W$N<BBN$r8!:w(B */
    for (mres_index = 0; mres_index < n_mem_resources; mres_index++) {
        /* $B%"%I%l%9$N%a%b%j%^%C%W$r<hF@(B */
        if (addr >= p_mem_resources[mres_index]->mres_start_addr &&
            addr <= p_mem_resources[mres_index]->mres_end_addr) {
            /* $B%a%b%j%^%C%W$N<BBN$rH/8+$G$-$?(B */
            return (mres_index);            /* $B@5>o%k!<%WC&=P(B */
        }
    }

    /* $B%a%b%j%^%C%W$N<BBN$rH/8+$G$-$J$+$C$?(B */
    return (U_NG);
}


long Cmemory::MemAccLatencyGet (unsigned long addr)
{
    MemoryBlock *p_mem_block;

    p_mem_block = MemBlockSearch (addr);
    if (p_mem_block == NULL) {
        if (g_shadow_mode == SHADOW_ON) {
            /* $B%@%_!<NN0h$r3NJ](B */
            d_printf (MSG_WAR, "<Warning: Allocated Dummy Memory Area %08lX-%08lX>\n",
                      addr & 0xFFFF0000, addr | 0x0000FFFF);
            //ForestMemResourceAdd (addr & 0xFFFF0000, addr | 0x0000FFFF,
            MemResourceAdd (addr & 0xFFFF0000, addr | 0x0000FFFF,
                                  READ_WRITE, 0, DUMMY_MEM_AREA);
            p_mem_block = MemBlockSearch (addr);
        }
    }

    /* success */
    if (p_mem_block != NULL) {
        return (p_mem_block -> mblock_read_state_count); 
    }
    /* fail to find */
    else {
        d_printf (MSG_WAR, "<Warning Detect: MemAccLatencyGet/Un-Allocated MemResource %08lX>\n", addr);
        return (0); 
    }
}


void Cmemory::MemResourceDisplay (void)
{
    int i;

    for (i = 0; i < n_mem_resources; i++) {
        d_printf (MSG_ERR, "%2lX %08lX-%08lX\n",
                p_mem_resources[i]->mres_index,
                p_mem_resources[i]->mres_start_addr,
                p_mem_resources[i]->mres_end_addr);
    }
}


void Cmemory::SetShadowMode (ShadowMode shadow_mode)
{
    g_shadow_mode = shadow_mode;
}


ShadowMode Cmemory::GetShadowMode (void)
{
    return (g_shadow_mode);
}


void Cmemory::PushVariables (FILE *fp)
{
    int i;

    //fwrite(& g_shadow_mode, sizeof( ShadowMode), 1, fp);
    fwrite(& n_mem_resources, sizeof( long), 1, fp);

    //memmap$B>pJs$rJ]B8(B  
    for (i = 0; i < n_mem_resources; i++){
        fwrite(p_mem_resources[i], sizeof(MemoryResource), 1, fp);
    }

    for (i = 0; i < MEM_BLOCK_SIZE; i++){
        //NULL$B$G$J$1$l$P!"BTHr$9$k(Bmem_block$B$,B8:_$9$k(B  
        if (p_mem_block_table[i] != NULL){
            fwrite(&p_mem_block_table[i]->mblock_use, sizeof(unsigned long), 1, fp);
        }
    }
    
    //$B%a%b%j%G!<%?$r%@%s%W$9$k(B  
    for (i = 0; i < MEM_BLOCK_SIZE; i++){
        //NULL$B$G$J$1$l$P!"BTHr$9$k(Bmem_block$B$,B8:_$9$k(B  
        if (p_mem_block_table[i] != NULL){
            if (p_mem_block_table[i]->mblock_use == 1){
                fwrite(p_mem_block_table[i]->p_mblock_body, sizeof(unsigned char)*MEM_BLOCK_SIZE, 1, fp);
            }
        }
    }
}


void Cmemory::PopVariables (FILE *fp)
{
    int i;
    unsigned long use;
    
    //$B8=:_B8:_$9$k%a%b%j$r3+J|(B  
    DeleteMemory();
    
    //fread (& g_shadow_mode, sizeof( ShadowMode), 1, fp);
    fread (& n_mem_resources, sizeof( long), 1, fp);

    //memmap$B>pJs$rJ]B8(B  
    for (i = 0; i < n_mem_resources; i++){
        p_mem_resources[i] = (MemoryResource *) malloc (sizeof (MemoryResource));
        if (p_mem_resources[i] == NULL) {
            ErrorCodeSet (E_MEM_ALLOCATE);  /* $B%a%b%j3NJ]%(%i!<(B */
            d_printf (MSG_ERR, "E_MEM_ALLOCATE\n");
            return;
        }
        
        fread(p_mem_resources[i], sizeof(MemoryResource), 1, fp);
        //$BBP1~$9$k%a%b%jNN0h$r:F3NJ](B($BCf?H$O$3$3$GI|5"$7$J$$(B)  
        //MemResourceRealloc(p_mem_resources[i]->mres_start_addr, p_mem_resources[i]->mres_end_addr, 
        //                   p_mem_resources[i]->mres_restrict_type, p_mem_resources[i]->mres_read_latency, p_mem_resources[i]->mres_area_type);
    }
    //$B;D$jMWAG$r(B0$B=i4|2=(B  
    //for (i = n_mem_resources; i < MAX_MEM_RES; i++){
    //    p_mem_resources[i] = NULL;
    //}

    for (i = 0; i < n_mem_resources; i++){
        //$BBP1~$9$k%a%b%jNN0h$r:F3NJ](B($BCf?H$O$3$3$GI|5"$7$J$$(B)  
        MemResourceRealloc(p_mem_resources[i]->mres_start_addr, p_mem_resources[i]->mres_end_addr, 
                           p_mem_resources[i]->mres_restrict_type, p_mem_resources[i]->mres_read_latency, p_mem_resources[i]->mres_area_type);
    }


    
    //$B%a%b%j(Bblock$B4IM}>pJs$rI|5"(B  
    for (i = 0; i < MEM_BLOCK_SIZE; i++){
        if (p_mem_block_table[i] != NULL){
            fread(&use, sizeof(unsigned long), 1, fp);
            p_mem_block_table[i]->mblock_use = use;
        }
    }
    
    //$B%a%b%j%G!<%?$r=q$-La$9(B  
    for (i = 0; i < MEM_BLOCK_SIZE; i++){
        //NULL$B$G$J$1$l$P!"BTHr$9$k(Bmem_block$B$,B8:_$9$k(B  
        if (p_mem_block_table[i] != NULL){
            if (p_mem_block_table[i]->mblock_use == 1){
                fread(p_mem_block_table[i]->p_mblock_body, sizeof(unsigned char)*MEM_BLOCK_SIZE, 1, fp);
            }
        }
    }
}


void Cmemory::MemResourceRealloc (unsigned long start_addr,
                              unsigned long end_addr,
                              MemRestrictType restrict_type,
                              unsigned long read_latency,
                              MemMappedArea area_type)
{
#ifdef MEMALLOC_CONTINUOUSLY
    MemBlockAllocContinuously (start_addr >> 16, restrict_type, read_latency, 0, 0, area_type, ((end_addr >> 16UL) - (start_addr >> 16UL)) + 1);
#else //MEMALLOC_CONTINUOUSLY
    unsigned long i;
    for (i = (start_addr >> 16); i <= (end_addr >> 16); i++) {
        MemBlockAlloc (i, restrict_type, read_latency, 0, 0, area_type);
    }
#endif //MEMALLOC_CONTINUOUSLY
    if (cedarErrno == E_MEM_OVERLAP) {
        d_printf (MSG_ERR, "E_MEM_OVERLAP: %08lX - %08lX\n", start_addr, end_addr);            
        ForestSetInvalidAddress (start_addr);
    }
}

void Cmemory::DeleteMemory(void)
{
    unsigned long i;
    
    // Delete MemoryBlock & mem body
    //$BO"B3NN0h$O@hF,MWAG$@$1(Bfree$B$9$k$N$G!"$=$l0J30$r(BNULL$B2=$7$F:F(Bfree$B$rKI$0(B  
    for(i = MEM_BLOCK_SIZE - 1; i > 0; i--){
        if ((p_mem_block_table[i] != NULL) && (p_mem_block_table[i-1] != NULL)){
            p_mem_block_table[i]->p_mblock_body = NULL;
            p_mem_block_table[i] = NULL;
        }
    }
    for(i = 0; i < MEM_BLOCK_SIZE; i++){
        if (p_mem_block_table[i] != NULL){
            free(p_mem_block_table[i]->p_mblock_body);
            free(p_mem_block_table[i]);
        }
    }

    // Delete MemoryResource
    for(i = 0; i < MAX_MEM_RES; i++){
        if (p_mem_resources[i] != NULL){
            free(p_mem_resources[i]);
        }
    }

    memset (p_mem_block_table, 0, sizeof (MemoryBlock *) * MEM_BLOCK_SIZE);
    memset (p_mem_resources, 0, sizeof (MemoryResource *) * MAX_MEM_RES);
    n_mem_resources = 0;
}


void Cmemory::DumpValidMemory (void)
{
    unsigned long i, j, k;
    FILE *fp;
    
    fp = fopen ("memdump.dat", "w");
    
    //$B%a%b%j%G!<%?$r=q$-La$9(B  
    for (i = 0; i < MEM_BLOCK_SIZE; i++){
        //NULL$B$G$J$1$l$P!"BTHr$9$k(Bmem_block$B$,B8:_$9$k(B  
        if (p_mem_block_table[i] != NULL){
            if (p_mem_block_table[i]->mblock_use == 1){
                //fread(p_mem_block_table[i]->p_mblock_body, sizeof(unsigned char)*MEM_BLOCK_SIZE, 1, fp);
                for (k = 0; k < 0xFFF; k++){
                    fprintf(fp, "%08lX : ", (i << 16UL) + (k << 4UL));
                    for (j = 0; j < 0x10; j++){
                        fprintf(fp, "%02X", *(p_mem_block_table[i]->p_mblock_body + j + (k << 4UL)));
                    }
                    fprintf(fp, "\n");
                }
            }
        }
    }
    
    fclose(fp);
}



void Cmemory::InitMemData (unsigned long start_addr, unsigned long end_addr)
{
    unsigned long i;
    unsigned long length;
    unsigned long base_addr;
    unsigned char *p_mem_addr;
    MemoryBlock *p_mem_block;

//#ifdef DEBUG_MEM
//if (debug_mem == 1){
//    printf("W: addr:%08lx, data:%08lx, size:%lx\n", addr, data, size);
//}
//#endif
    if ((end_addr | 0x0000FFFF) < (start_addr & 0xFFFF0000)) {
        return;
    }

    base_addr = start_addr & 0xFFFF0000;
    length = ((end_addr | 0x0000FFFF) - (start_addr & 0xFFFF0000)) >> 16;
    for (i = 0; i <= length; i++){
        /* $B0z?t$N%"%I%l%9$+$i%a%b%j%V%m%C%/$N<BBN$r8!:w(B */
        p_mem_block = MemBlockSearch (base_addr + 0x10000UL * i);
        if (p_mem_block != NULL) {
            /* $B%a%b%j;HMQ%U%i%0$r:o=|(B */
            p_mem_block->mblock_use = 0;
            /* $B%a%b%jNN0h$N@hF,%]%$%s%?$r<hF@(B */
            p_mem_addr = p_mem_block->p_mblock_body;
            /* $B=i4|CM$G%a%b%j$r=i4|2=(B */
            memset (p_mem_addr, ForestGetMemInitValue(), sizeof(unsigned char) * MEM_BLOCK_SIZE);
        }
    }
}
