// $Id: arbiter_wait.h v2011_05_12 $
#ifndef __ARBITER_WAIT_H
#define __ARBITER_WAIT_H

#include "systemc.h"
#include <limits.h>
#include <map>
#include "arbiter_dynamic.h"

// arbiter class
class arbiter_wait_elm : public arbiter_dynamic_elm {
private:
  sc_time m_allowed_time;
  sc_time m_updated_time;
  sc_time m_counter;
  bool    m_count_mode;
  bool    m_lck_mode;

  sc_time m_period;
  sc_time m_thresh_time;

public:
  // constructor
  arbiter_wait_elm(sc_time time, bool count_mode, bool lck_mode)
    : arbiter_dynamic_elm(0,0,SC_ZERO_TIME)
  {
    m_period      = sc_time(    10, SC_NS);  // temporary
    m_thresh_time = sc_time(100000, SC_NS);  // temporary

    m_allowed_time = time;
    m_updated_time = SC_ZERO_TIME;
    m_counter      = m_thresh_time;

    m_count_mode = count_mode;
    m_lck_mode  = lck_mode;
  }

  virtual arbiter_wait_elm * clone() const {
    return new arbiter_wait_elm(*this);
  }

  virtual void request(int priority = -1) {
    m_request = 1;

    if(m_lck == false || m_lck_mode == 0) {
      // update counter
      if(m_count_mode == 0) {
        m_counter = m_thresh_time + m_allowed_time;
      }
      else {
        m_counter = m_counter + m_allowed_time;
      }

      m_updated_time = sc_time_stamp();
    }
  }

  int get_priority() {
    if( !m_request ) return -1;  // no request

    update_counter();

    if(m_counter < m_thresh_time) {
      return 0;
    }
    return (m_counter - m_thresh_time)/m_period;
  }

  void set_win() {
    m_request = 0;
    update_counter();
  }

private:
  void update_counter() {
    m_counter = m_counter - (sc_time_stamp() - m_updated_time);
    if(m_counter < m_thresh_time) {
      m_counter = m_thresh_time;
    }
    m_updated_time = sc_time_stamp();
  }
};

#endif//__ARBITER_WAIT_H
