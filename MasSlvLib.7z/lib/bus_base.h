//$Id: bus_base.h v2011_06_08 $

#ifndef __BUS_BASE__
#define __BUS_BASE__

#include "systemc.h"

class bus_base
{
private:
  int num_targets;
  bool* grant_read;
  bool* grant_write;

public:
  bus_base(int number_of_targets){

    num_targets = number_of_targets;
    grant_read  = new bool[num_targets];
    grant_write = new bool[num_targets];

    for (int i=0; i<num_targets; i++) {
      grant_read[i] = 1;
      grant_write[i] = 1;
    }
  }

  virtual ~bus_base() {
    delete [] grant_read;
    delete [] grant_write;
  };

  // notify gnt arrival
  sc_event gnt_event;

  // override by get_permission API which is implementd in inherited class. 
  virtual bool get_permission(int ini_id) { return true; };

  void notify_permission(bool status, int tgt_id) {
    grant_read[tgt_id] = status;
    grant_write[tgt_id] = status;

    if(status == true) {
      gnt_event.notify();
    }
  }

  void notify_read_permission(bool status, int tgt_id) {
    grant_read[tgt_id] = status;

    if(status == true) {
      gnt_event.notify();
    }
  }

  void notify_write_permission(bool status, int tgt_id) {
    grant_write[tgt_id] = status;

    if(status == true) {
      gnt_event.notify();
    }
  }

  bool get_permission_stat(int tgt_id) {
    return grant_read[tgt_id] && grant_write[tgt_id];
  }

  bool get_read_permission_stat(int tgt_id) {
    return grant_read[tgt_id];
  }

  bool get_write_permission_stat(int tgt_id) {
    return grant_write[tgt_id];
  }
};

#endif
