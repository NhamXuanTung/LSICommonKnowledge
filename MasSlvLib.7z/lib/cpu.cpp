//$Id: cpu.cpp v2014_09_29 $
/****************************************************************************
* File name : cpu.cpp
****************************************************************************/
#include <iostream>
#include <signal.h>
#include <stdarg.h>

#include "cpu.h"

#ifdef CPU_TLM20_BUS
// =================================================================
// TLM2.0 Part(CoWare)
// =================================================================
bool Ccpu::tgt_wr(unsigned int addr, unsigned char *p_data, unsigned int size, vpcl::tlm_if_extension *p_ext, sc_time *p_time){

    if ( p_ext == NULL ) {
        re_printf("error", "Error(%s) : TLM extension parameter is NULL pointer.\n" , this->basename() );
        sc_stop();
    }
    if ( size > 4 ) {
        re_printf("error", "Error(%s) : To Large Write Size = %d\n" , this->basename(), size );
    }

    this->ini_wr( addr, p_data, size );

    return true;
  }

bool Ccpu::tgt_rd(unsigned int addr, unsigned char *p_data, unsigned int size, vpcl::tlm_if_extension *p_ext, sc_time *p_time){

    this->ini_rd( addr, p_data, size );

    if ( size > 4 ) {
        re_printf("error", "Error(%s) : Too Large Read Size = %d\n" , this->basename() , size );
    }

    return true;
  }

bool Ccpu::tgt_wr(unsigned int addr, unsigned char *p_data, unsigned int size, vpcl::tlm_if_extension *p_ext){

    if ( p_ext == NULL ) {
        re_printf("error", "Error(%s) : TLM extension parameter is NULL pointer.\n" , this->basename() );
        sc_stop();
    }
    if ( size > 4 ) {
        re_printf("error", "Error(%s) : To Large Write Size = %d\n" , this->basename(), size );
    }

    this->ini_wr( addr, p_data, size );

    return true;
  }

bool Ccpu::tgt_rd(unsigned int addr, unsigned char *p_data, unsigned int size, vpcl::tlm_if_extension *p_ext){

    this->ini_rd( addr, p_data, size );

    if ( size > 4 ) {
        re_printf("error", "Error(%s) : Too Large Read Size = %d\n" , this->basename() , size );
    }

    return true;
  }

bool Ccpu::tgt_wr_dbg(unsigned int addr, unsigned char *p_data, unsigned int size, vpcl::tlm_if_extension *p_ext){

    if ( p_ext == NULL ) {
        re_printf("error", "Error(%s) : TLM extension parameter is NULL pointer.\n" , this->basename() );
        sc_stop();
    }
    if ( size > 4 ) {
        re_printf("error", "Error(%s) : To Large Write Size = %d\n" , this->basename(), size );
    }

    this->ini_wr_dbg( addr, p_data, size );
    return true;
  }

bool Ccpu::tgt_rd_dbg(unsigned int addr, unsigned char *p_data, unsigned int size, vpcl::tlm_if_extension *p_ext){

    this->ini_rd_dbg( addr, p_data, size );

    if ( size > 4 ) {
        re_printf("error", "Error(%s) : Too Large Read Size = %d\n" , this->basename() , size );
    }

    return true;
  }

#endif // CPU_TLM20_BUS

#ifdef  CWR_SYSTEMC
// -------------------------------------------------------------
//  MemAccCB
// -------------------------------------------------------------

scml_memory_pv64_if::response_type Ccpu::MemAccCB(const scml_memory_pv64_if::request_type &req)
{
    scml_memory_pv64_if::response_type res = req.obtainResp();

    unsigned int size   = req.getDataSize();
    unsigned int offset = req.getOffset();

// Add For Bug Fix By H.M.
    unsigned long addr = (offset & 0x007FFFFC) | 0xE5000000;
// Add End.

    // -------- Write access --------
    if (req.getType() == pvWrite) {
        unsigned long wr_data = req.getWriteData(0);

        CedarOcMemWrite (cedar_p, addr, &wr_data, size/8, 0);
    }

    // -------- Read access --------
    else if (req.getType() == pvRead) {
        unsigned long rd_data;

        CedarOcMemRead (cedar_p, addr, &rd_data, size/8, 0);

        res.setReadData(rd_data, 0);
    }

    res.setResponse(pvOk);

    return res;
}
#endif // CWR_SYSTEMC

// -------------------------------------------------------------
// BusAccWrite
// -------------------------------------------------------------
void Ccpu::BusAccWrite(unsigned int addr, unsigned long *p_data, unsigned int size)
{
#ifdef CPU_TLM20_BUS
    // Need to p_data to swp_buf.
    tlmWrite(addr, p_data, size);
#else
    unsigned int  bit_size = min(bus_width, (unsigned int)(8*size));
    unsigned int  burst_count = (8*size + bus_width - 1)/bus_width;
    unsigned int ndata = bus_width/32;

    cpu_arry.claim_space(0, burst_count);
    for(unsigned int i=0; i<burst_count; i++) {
        cpu_arry.put(&p_data[i*ndata], i, bit_size, 0);
    }
    cpu_arry.nb_release_data(0, burst_count);

    // -------- Transaction attribute setting --------
    cpu_trans_req.setDataManager(cpu_arry);
    cpu_trans_req.setType(pvWrite);
    cpu_trans_req.setAddress(addr);
    cpu_trans_req.setDataSize(bit_size);
    cpu_trans_req.setBurstCount(burst_count);
    cpu_trans_req.setOffset(0);
    cpu_trans_req.setStartIndex(0);

    // -------- Transaction request sending with scml_post_port --------
    p_post.post(cpu_trans_req);
    wait(cpu_trans_req.end_event());
#endif // CPU_TLM20_BUS
}

#ifdef CPU_TLM20_BUS
void Ccpu::tlmWrite(unsigned int addr, unsigned long *p_data, unsigned int size){
  if ( CpuGetEndian() == CPU_ENDIAN_BIG ) {
    WordSwap(p_data, size);

    if ( size < bus_byte_width ) {
      unsigned int flip = bus_byte_width - size;
      addr = addr ^ flip;
    }
  }
  this->ini_wr( addr, (unsigned char *)p_data, size );
}
#endif

void Ccpu::BusAccWriteDebug(unsigned int addr, unsigned long *p_data, unsigned int size)
{
#ifdef CPU_TLM20_BUS
  if ( CpuGetEndian() == CPU_ENDIAN_BIG ) {
    WordSwap(p_data, size);

    if ( size < bus_byte_width ) {
      unsigned int flip = bus_byte_width - size;
      addr = addr ^ flip;
    }
  }
  this->ini_wr_dbg( addr, (unsigned char *)p_data, size );
#endif
}

void Ccpu::BusAccReadDebug(unsigned int addr, unsigned long *p_data, unsigned int size)
{
#ifdef CPU_TLM20_BUS

  if ( CpuGetEndian() == CPU_ENDIAN_BIG ) {
    if ( size < bus_byte_width ) {
      unsigned int flip = bus_byte_width - size;
      addr = addr ^ flip;
    }
  }

  this->ini_rd_dbg( addr, (unsigned char *)p_data, size );

  if ( CpuGetEndian() == CPU_ENDIAN_BIG ) {
    WordSwap(p_data, size);
  }
#endif
} 

// -------------------------------------------------------------
//  BusAccRead
// -------------------------------------------------------------
void Ccpu::BusAccRead(unsigned int addr, unsigned long *p_data, unsigned int size)
{
#ifdef CPU_TLM20_BUS

  if ( CpuGetEndian() == CPU_ENDIAN_BIG ) {
    if ( size < bus_byte_width ) {
      unsigned int flip = bus_byte_width - size;
      addr = addr ^ flip;
    }
  }

  this->ini_rd( addr, (unsigned char *)p_data, size );

  if ( CpuGetEndian() == CPU_ENDIAN_BIG ) {
    WordSwap(p_data, size);
  }

#else
    // -------- Transaction attribute setting --------
    unsigned int  bit_size = min(bus_width, (unsigned int)(8*size));
    unsigned int  burst_count = (8*size + bus_width - 1)/bus_width;
    
    cpu_trans_req.setDataManager(cpu_arry);
    cpu_trans_req.setType(pvRead);
    cpu_trans_req.setAddress(addr);
    cpu_trans_req.setDataSize(bit_size);
    cpu_trans_req.setBurstCount(burst_count);
    cpu_trans_req.setOffset(0);
    cpu_trans_req.setStartIndex(0);

    // -------- Transaction request sending with scml_post_port --------
    p_post.post(cpu_trans_req);
    wait(cpu_trans_req.end_event());

    // -------- Read data getting from scml_array --------
    unsigned int ndata = bus_width/32;
    cpu_arry.claim_data(0, burst_count);
    for(unsigned int i=0; i<burst_count; i++) {
        cpu_arry.get(&p_data[i*ndata], i, bit_size, 0);
    }
#endif // End of CPU_TLM20_BUS

#ifndef CPU_TLM20_BUS
    cpu_arry.nb_release_space(0, burst_count);
#endif
}

void Ccpu::WordSwap(unsigned long *p_data, unsigned int size)
{
  unsigned int word_size = size/4;
  unsigned int bus_word_size = bus_byte_width/4;
  unsigned int flip = bus_word_size - 1;
  if (p_data == NULL) {
      re_printf("error","[%s]  ERROR : function \"WaordSwap\" Get NULL Pointer.\n", this->basename());
      sc_stop();
  }
  if(word_size < bus_word_size) {
    flip = word_size - 1;
  }

  for(unsigned int index=0; index<word_size; index++) {
    unsigned int findex = index ^ flip;
    if(findex < word_size && index < findex) {
      unsigned long temp = p_data[index];
      p_data[index]      = p_data[findex];
      p_data[findex]     = temp;
    }
  }
}

void ClockWait (long id)
{
//    wait ();
//    cpu_time[id] += cpu_rate[id];
}

void DeltaCycleWait (long id)
{
//    wait (1, SC_NS);
}


void Ccpu::CpuCedarInit (void)
{
    CedarCedarInit (cedar_p); 
} 

void Ccpu::CpuInstQueueInit (void)
{
    CedarInstQueueInit (cedar_p); 
} 

void Ccpu::CpuSetCpuType (CpuType cpu_type)
{
    CedarSetCpuType (cedar_p, cpu_type);
}

CpuType Ccpu::CpuGetCpuType (void)
{
    return (CedarGetCpuType (cedar_p));
}

void Ccpu::CpuSetCoproBaseMode (CoproBaseMode copro_mode)
{
    CedarSetCoproBaseMode (cedar_p, copro_mode);
}

void Ccpu::CpuSetDebugMode (DebugMode mode)
{
    CedarSetDebugMode (cedar_p, mode);
}

void Ccpu::CpuSetSnapDump (SnapDumpMode mode)
{
    CedarSetSnapDump (cedar_p, mode);
}

void Ccpu::CpuSetDebugEnable (DebugMode mode)
{
    CedarSetDebugEnable (cedar_p, mode);
}

void Ccpu::CpuSetSleepMode (SleepMode mode)
{
    CedarSetSleepMode (cedar_p, mode);
}

void Ccpu::CpuSetExpmaskInitValue (unsigned long expmask_init_value)
{
    CedarSetExpmaskInitValue (cedar_p, expmask_init_value);
}

void Ccpu::CpuSetCedarMode (CedarMode mode)
{
    CedarSetCedarMode (cedar_p, mode);
}

void Ccpu::CpuSetCedarProf (ProfMode mode)
{
    CedarSetCedarProf (cedar_p, mode);
}

// void Ccpu::CpuCedarCciRead (char *fname)
// {
//     CedarCedarCciRead (cedar_p, fname); 
// }

void Ccpu::CpuCedarDefaultMemSet (void)
{
    CedarCedarDefaultMemSet (cedar_p);
}

void Ccpu::CpuSetInterrupt (int intlevel, int intvecno)
{
    CedarSetInterrupt (cedar_p, (unsigned long)intlevel, (unsigned long)intvecno);
}

void Ccpu::CpuClearInterrupt (void)
{
    CedarClearInterrupt (cedar_p);
}

long Ccpu::CpuCheckInterruptAccept ()
{
    return (CedarCheckInterruptAccept (cedar_p));
}

void Ccpu::CpuSetNMIB(unsigned long data)
{
    CedarSetNMIB (cedar_p, data);
}

void Ccpu::CpuRegWriteDebug (SH_Reg regno, unsigned long data, BankChangeMode bank_change_flag)
{
    CedarRegWriteDebug (cedar_p, (unsigned long)regno, data, bank_change_flag);
}

unsigned long Ccpu::CpuRegReadDebug (SH_Reg regno, BankChangeMode bank_change_flag)
{
    return (CedarRegReadDebug (cedar_p, regno, bank_change_flag));
}

unsigned long Ccpu::CpuRegReadPC (void)
{
    return (CedarRegReadPC (cedar_p));
}

//void Ccpu::CpuFsExecute (unsigned long step, InstDispMode inst_disp)
//{
//    CedarFsExecute (cedar_p, step, inst_disp);
//}

SimState Ccpu::CpuFsExecute (InstDispMode inst_disp)
{
    return(CedarFsExecute (cedar_p, inst_disp));
}

// void Ccpu::CpuFsStepExecute (void)
// {
//    CedarFsStepExecute (cedar_p);
// }

void Ccpu::Lap_CpuFsStepExecute (void)
{
    while(1){
        if (((m_break_system_time_enable == 1) && (m_break_system_time <= (unsigned int)(sc_time_stamp().value()))) 
             || ( (m_run_time_check == 1) && (m_run_time <= (unsigned int)(sc_time_stamp().value())))) {
            CpuBreak();
            return;
        }
        m_irq_req_st   = irq_in.read();
        if ( m_irq_req_st == true ){
            m_int_evt      = (int)(( inpt_int_evt.read() ) << 5);
            m_int_priority = (int)(inpt_int_priority.read());
            CpuSetInterrupt(m_int_priority, m_int_evt);
        } else {
        // Comment out on Mon Jan 30 20:46:58 JST 2012
        // CpuClearInterrupt();
        }

        CpuFsStepExecute();

        wait();
    }
}

void Ccpu::CpuFsStepExecute (void)
{
//    static sighandler_t coware_sig_int_bak = SIG_DFL;

    int i; // loop counter.
    SimState rtn     = SIMULATE_STOP;
    SimState rtn_buf = SIMULATE_STOP;
    long err_flag = 0;

    /* Hook Ctrl-C */
//    coware_sig_int_bak = signal (SIGINT, SetSigIntFlag);
    sigint_flag = 0;

    for ( i = 0 ; i < ISS_EXEC_STEPS ; i++ ) {
        if ((m_step_check == true)&&((m_step_run - 1) == m_step_count)) {
            err_flag = 1;
        }
        if ( CpuGetDebugMode () >= DBG_ON ) { // Instruction Display On.
    	    rtn_buf = CedarFsExecute (cedar_p,INST_DISP_ON);
        }
        else {                      // Instruction Display Off.
    	    rtn_buf = CedarFsExecute (cedar_p,INST_DISP_OFF);
        }
        if ( rtn_buf > rtn ) rtn = rtn_buf;
        if ( rtn == SIMULATE_ERR ) {
            re_printf("error", "Error(%s) : ISS find error.\n" , this->basename() );
            sc_stop();
        }
        if ( rtn >= SIMULATE_BREAK ) err_flag = 1;
        if (sigint_flag + err_flag != 0) {
            CpuBreak();
            break;
        }
        m_step_count += 1; 
    }

    /* Release hook Ctrl-C */
//    signal (SIGINT, coware_sig_int_bak);
}

void Ccpu::CpuBreak(void)
{
#ifdef CWR_SYSTEMC
#else
    cmd_handler->handleCommand();
#endif // CWR_SYSTEMC
    
    return;
}

void Ccpu::CpuFsSleepWakeUpProcess (void)
{
    CedarFsSleepWakeUpProcess (cedar_p);
}

void Ccpu::CpuCsTraceSimulate (void)
{
    CedarCsTraceSimulate (cedar_p);
}

unsigned long Ccpu::CpuGetBranchInfo (void)
{
    return (CedarGetBranchInfo (cedar_p));
}

unsigned long Ccpu::CpuGetBranchAddr (void)
{
    return (CedarGetBranchAddr (cedar_p));
}

unsigned long Ccpu::CpuGetInstAddr (void)
{
    return (CedarGetInstAddr (cedar_p));
}

unsigned long Ccpu::CpuGetInstCode (void)
{
    return (CedarGetInstCode (cedar_p));
}

unsigned long Ccpu::CpuGetInstCode32 (void)
{
    return (CedarGetInstCode32 (cedar_p));
}

unsigned long Ccpu::CpuGetNextInstAddr (void)
{
    return (CedarGetNextInstAddr (cedar_p));
}

long Ccpu::CpuGetInstId (void)
{
    return (CedarGetInstId (cedar_p));
}

long Ccpu::CpuGetReadRegNum (void)
{
    return (CedarGetReadRegNum (cedar_p));
}

SH_Reg Ccpu::CpuGetReadRegName (unsigned long index)
{
    return (CedarGetReadRegName (cedar_p, index));
}

unsigned long Ccpu::CpuGetReadRegValue (unsigned long index)
{
    return (CedarGetReadRegValue (cedar_p, index));
}

long Ccpu::CpuGetWriteRegNum (void)
{
    return (CedarGetWriteRegNum (cedar_p));
}

SH_Reg Ccpu::CpuGetWriteRegName (unsigned long index)
{
    return (CedarGetWriteRegName (cedar_p, index));
}

unsigned long Ccpu::CpuGetWriteRegValue (unsigned long index)
{
    return (CedarGetWriteRegValue (cedar_p, index));
}

unsigned long Ccpu::CpuGetReadMemNum (void)
{
    return (CedarGetReadMemNum (cedar_p));
}

unsigned long Ccpu::CpuGetReadMemAddr (unsigned long index)
{
    return (CedarGetReadMemAddr (cedar_p, index));
}

unsigned long Ccpu::CpuGetReadMemValue (unsigned long index)
{
    return (CedarGetReadMemValue (cedar_p, index));
}

unsigned long Ccpu::CpuGetReadMemSize (unsigned long index)
{
    return (CedarGetReadMemSize (cedar_p, index));
}

unsigned long Ccpu::CpuGetWriteMemNum (void)
{
    return (CedarGetWriteMemNum (cedar_p));
}

unsigned long Ccpu::CpuGetWriteMemAddr (unsigned long index)
{
    return (CedarGetWriteMemAddr (cedar_p, index));
}

unsigned long Ccpu::CpuGetWriteMemValue (unsigned long index)
{
    return (CedarGetWriteMemValue (cedar_p, index));
}

unsigned long Ccpu::CpuGetWriteMemSize (unsigned long index)
{
    return (CedarGetWriteMemSize (cedar_p, index));
}

unsigned long Ccpu::CpuGetInstStepCount (void)
{
    return (CedarGetInstStepCount (cedar_p));
}

unsigned long Ccpu::CpuGetInstCycleCount (void)
{
    return (CedarGetCycleCount (cedar_p));
}

unsigned long *Ccpu::CpuGetInstStageCycle (void)
{
    return (CedarGetInstStageCycle (cedar_p));
}

ConditionResultType Ccpu::CpuGetConditionResult (void)
{
    return (CedarGetConditionResult (cedar_p));
}

unsigned long Ccpu::CpuGetInstParallel (void)
{
    return (CedarGetInstParallel (cedar_p));
}

void Ccpu::CpuBreakAccessAdd (unsigned long start_addr, unsigned long end_addr, MemRestrictType access_type)
{
    CedarBreakAccessAdd (cedar_p, start_addr, end_addr, access_type);
}

void Ccpu::CpuBreakAccessDisplay (void)
{
    CedarBreakAccessDisplay (cedar_p);
}

void Ccpu::CpuBreakAccessEnable (long enable, long index, long all)
{
    CedarBreakAccessEnable (cedar_p, enable, index, all);
}

void Ccpu::CpuBreakPointAdd (unsigned long address, unsigned long count)
{
    CedarBreakPointAdd (cedar_p, address, count);
}

void Ccpu::CpuBreakPointDisplay (void)
{
    CedarBreakPointDisplay (cedar_p);
}

void Ccpu::CpuBreakPointEnable (long enable, long index, long all)
{
    CedarBreakPointEnable (cedar_p, enable, index, all);
}

void Ccpu::CpuBreakSleepSet (long flag)
{
    CedarBreakSleepSet (cedar_p, flag);
}

DebugMode Ccpu::CpuGetDebugMode (void)
{
    return (CedarGetDebugMode (cedar_p));
}

CedarMode Ccpu::CpuGetCedarMode (void)
{
    return (CedarGetCedarMode (cedar_p));
}

void Ccpu::CpuBreakMaxSet (unsigned long count)
{
    CedarBreakMaxSet (cedar_p, count);
}

void Ccpu::CpuCedarQuit (void)
{
    CedarCedarQuit (cedar_p);
}

void Ccpu::CpuRegisterDisplay (FILE *ptr_file)
{
    if (ptr_file == NULL) {
      re_printf("error","[%s]  ERROR : function \"CpuRegisterDisplay\" Get NULL Pointer.\n", this->basename());
      sc_stop();
    }
    CedarRegisterDisplay (cedar_p, ptr_file);
}

void Ccpu::CpuFsHardReset (void)
{
//    CedarFsHardReset (cedar_p);
}

void Ccpu::CpuCsHardReset (void)
{
    CedarCsHardReset (cedar_p);
}

void Ccpu::CpuFsStateDisplay (void)
{
    CedarFsStateDisplay (cedar_p);
}

SH_Reg Ccpu::CpuRegGetRegno (const char *regname)
{
    if (regname == NULL) {
      re_printf("error","[%s]  ERROR : function \"CpuRegGetRegno\" Get NULL Pointer.\n", this->basename());
      sc_stop();
    }
    return (SH_Reg)(CedarRegGetRegno (cedar_p, (char *)regname));
}

unsigned long Ccpu::CpuCtrlRegGetRegno (const char *regname)
{
    if (regname == NULL) {
      re_printf("error","[%s]  ERROR : function \"CpuCtrlRegGetRegno\" Get NULL Pointer.\n", this->basename());
      sc_stop();
    }
    return (CedarCtrlRegGetRegno (cedar_p, (char *)regname));
}

const char* Ccpu::CpuRegGetName (SH_Reg regno)
{
    return (CedarRegGetName (cedar_p, regno));
}

void Ccpu::CpuCtrlRegWrite (unsigned long regaddr, unsigned long data, MemAccessDataType size)
{
    CedarCtrlRegWrite (cedar_p, regaddr, data, size);
}

unsigned long Ccpu::CpuCtrlRegRead (unsigned long regaddr, MemAccessDataType size)
{
    return (CedarCtrlRegRead (cedar_p, regaddr, size));
}

void Ccpu::CpuSetEndian (EndianType endian)
{
    CedarSetEndian (cedar_p, endian);
}

EndianType Ccpu::CpuGetEndian (void)
{
    return (CedarGetEndian (cedar_p));
}

//void Ccpu::CpuCsExecute (unsigned long step, InstDispMode inst_disp)
//{
//    CedarCsExecute (cedar_p, step, inst_disp);
//}
SimState Ccpu::CpuCsExecute (InstDispMode inst_disp)
{
    return(CedarCsExecute (cedar_p, inst_disp));
}

SimState Ccpu::CpuGetSimState (void)
{
    return (CedarGetSimState (cedar_p));
}

void Ccpu::CpuSetSimState (SimState sim_state)
{
    CedarSetSimState (cedar_p, sim_state);
}

unsigned long Ccpu::CpuRegReadBody (SH_Reg end_addr_reg)
{
    return (CedarRegReadBody (cedar_p, end_addr_reg));
}

void Ccpu::CpuBreakPcstopSet (unsigned long count)
{
    CedarBreakPcstopSet (cedar_p, count);
}

void Ccpu::CpuSetClockRatio (ClockType clock_type, unsigned long ratio)
{
    CedarSetClockRatio (cedar_p, clock_type, ratio);
}

void Ccpu::CpuErrorCodeSet (ErrorCode err_no)
{
    CedarErrorCodeSet (cedar_p, err_no);
}

ErrorCode Ccpu::CpuGetErrorCode (void)
{
    return (CedarGetErrorCode (cedar_p));
}

ErrorCode Ccpu::CpuGetExpCode (void)
{
    return (CedarGetExpCode (cedar_p));
}

SH_Reg Ccpu::CpuGetWriteVReg (unsigned long num)
{
    return (CedarGetWriteVReg (cedar_p, num));
}

void Ccpu::CpuSetOutFilePointer (FILE* fp)
{
    if (fp == NULL) {
      re_printf("error","[%s]  ERROR : function \"CpuSetOutFilePointer\" Get NULL Pointer.\n", this->basename());
      sc_stop();
    }
    CedarSetOutFilePointer (cedar_p, fp);
}

FILE* Ccpu::CpuGetOutFilePointer (void)
{
    return (CedarGetOutFilePointer (cedar_p));
}

void Ccpu::CpuClearStepCount (void)
{
    CedarClearStepCount (cedar_p);
}

void Ccpu::CpuAddCycleCount (unsigned long add_cycle)
{
    CedarAddCycleCount (cedar_p, add_cycle);
}

void Ccpu::CpuClearCycleCount (void)
{
    CedarClearCycleCount (cedar_p);
}

void Ccpu::CpuCruFlushCacheLine (unsigned long flush_addr)
{
    CedarCruFlushCacheLine (cedar_p, flush_addr);
}

void Ccpu::CpuCruPurgeCacheLine (unsigned long purge_addr)
{
    CedarCruPurgeCacheLine (cedar_p, purge_addr);
}


void Ccpu::CpuSetFpuAlgorithm (FpuAlgorithmMode fpu_algolithm)
{
    CedarSetFpuAlgorithm (cedar_p, fpu_algolithm);
}


void Ccpu::CpuSetIcacheSize (ICacheSize icache_size)
{
    CedarSetIcacheSize (cedar_p, icache_size);
}


void Ccpu::CpuSetOcacheSize (OCacheSize ocache_size)
{
    CedarSetOcacheSize (cedar_p, ocache_size);
}


L2CacheSize Ccpu::CpuGetL2cacheSize (void)
{
    return (CedarGetL2cacheSize (cedar_p));
}


void Ccpu::CpuSetL2cacheSize (L2CacheSize l2cache_size)
{
    CedarSetL2cacheSize (cedar_p, l2cache_size);
}


void Ccpu::CpuSetXYramSize (XYramSize xyram_size)
{
    CedarSetXYramSize (cedar_p, xyram_size);
}


void Ccpu::CpuSetILramSize (ILramSize ilram_size)
{
    CedarSetILramSize (cedar_p, ilram_size);
}


void Ccpu::CpuSetLramSize (LramSize lram_size)
{
    CedarSetLramSize (cedar_p, lram_size);
}


void Ccpu::CpuSetUramSize (UramSize uram_size)
{
    CedarSetUramSize (cedar_p, uram_size);
}


UramSize Ccpu::CpuGetUramSize (void)
{
    return (CedarGetUramSize (cedar_p));
}


void Ccpu::CpuSetIcacheWayMode (CacheWayMode cache_way_mode)
{
    CedarSetIcacheWayMode (cedar_p, cache_way_mode);
}


void Ccpu::CpuSetOcacheWayMode (CacheWayMode cache_way_mode)
{
    CedarSetOcacheWayMode (cedar_p, cache_way_mode);
}


void Ccpu::CpuSetScdFixMode (ScdFixMode scd_fix_mode)
{
    CedarSetScdFixMode (cedar_p, scd_fix_mode);
}


unsigned long Ccpu::CpuGetIcacheAccessCount (void)
{
    return (CedarGetIcacheAccessCount (cedar_p));
}


unsigned long Ccpu::CpuGetIcacheHitCount (void)
{
    return (CedarGetIcacheHitCount (cedar_p));
}


unsigned long Ccpu::CpuGetOcacheAccessCount (void)
{
    return (CedarGetOcacheAccessCount (cedar_p));
}


unsigned long Ccpu::CpuGetOcacheHitCount (void)
{
    return (CedarGetOcacheHitCount (cedar_p));
}


unsigned long Ccpu::CpuGetL2cacheAccessCount (void)
{
    return (CedarGetL2cacheAccessCount (cedar_p));
}


unsigned long Ccpu::CpuGetL2cacheHitCount (void)
{
    return (CedarGetL2cacheHitCount (cedar_p));
}


void Ccpu::CpuSetResetVecAddr (unsigned long addr)
{
    CedarSetResetVecAddr (cedar_p, addr);
}


unsigned long Ccpu::CpuGetResetVecAddr (void)
{
    return (CedarGetResetVecAddr (cedar_p));
}


void Ccpu::CpuSetCpuEnable (CpuEnable enable)
{
    if (enable == CPU_ON && cpu_start_flag == 0) {
        /* $B<BO@M}$O(B CPU0 $B0J30$O%j%;%C%H>uBV$G5/F0(B */
        /* $B:G=i$K(B CPU_ON $B$K$J$C$?;~$@$1(B Power-On Reset $B$H$7$F=hM}(B */
        CpuHardReset ();
        cpu_start_flag = 1;
    }

    CedarSetCpuEnable (cedar_p, enable);
}


CpuEnable Ccpu::CpuGetCpuEnable (void)
{
    return (CedarGetCpuEnable (cedar_p));
}


void Ccpu::CpuSetBootAddrMode (BootAddrMode boot_addr_mode)
{
    CedarSetBootAddrMode (cedar_p, boot_addr_mode);
}


BootAddrMode Ccpu::CpuGetBootAddrMode (void)
{
    return (CedarGetBootAddrMode (cedar_p));
}


void Ccpu::CpuSet32BitBootAddr (Boot32AddrIndex pn, unsigned long addr)
{
    CedarSet32BitBootAddr (cedar_p, pn, addr);
}


void Ccpu::CpuSetUxyAdrSel (UxyPhysAddr uxyadrsel)
{
    CedarSetUxyAdrSel (cedar_p, uxyadrsel);
}


void Ccpu::CpuUpdateUxyPhysAddr (void)
{
    CedarUpdateUxyPhysAddr (cedar_p); 
}


void Ccpu::CpuSetSimioEnable (long flag)
{
    CedarSetSimioEnable (cedar_p, flag);
}


long Ccpu::CpuCheckSimioExec (void)
{
    return (CedarGetSimioExec (cedar_p));
}


void Ccpu::CpuSetSimioAddress (unsigned long address)
{
    CedarSetSimioAddress (cedar_p, address);
}


void Ccpu::CpuSetVirtualSimioEnable (long flag)
{
    CedarSetVirtualSimioEnable (cedar_p, flag);
}


void Ccpu::CpuSetVirtualSimioAddress (unsigned long address)
{
    CedarSetVirtualSimioAddress (cedar_p, address);
}


void Ccpu::CpuMemWriteDebug (unsigned long addr, unsigned long data,
                       MemAccessDataType size)
{
    CedarMemWriteDebug (cedar_p, addr, data, size);
}


unsigned long Ccpu::CpuMemReadDebug (unsigned long addr, MemAccessDataType size)
{
    return (CedarMemReadDebug (cedar_p, addr, size));
}


void Ccpu::CpuMemoryDisplay (unsigned long start_addr, unsigned long end_addr,
                             MemDisplaySize size, FILE *ptr_file)
{
    if (ptr_file == NULL) {
      re_printf("error","[%s]  ERROR : function \"CpuMemoryDisplay\" Get NULL Pointer.\n", this->basename());
      sc_stop();
    }
    CedarMemoryDisplay (cedar_p, start_addr, end_addr, size, ptr_file);
}


void Ccpu::CpuFileLoad (char *filename, unsigned long offset)
{
    if (filename == NULL) {
      re_printf("error","[%s]  ERROR : function \"CpuFileLoad\" Get NULL Pointer.\n", this->basename());
      sc_stop();
    }
    CedarFileLoad (cedar_p, filename, offset);
}

#if 0
void Ccpu::CpuSetIntcTestMode (IntcTestMode intc_test_mode)
{
    CedarSetIntcTestMode(cedar_p, intc_test_mode);
}


void Ccpu::CpuSetIntcTestDecrementNum (long decrement_num)
{
    CedarSetIntcTestDecrementNum(cedar_p, decrement_num);
}
#endif //0

unsigned long Ccpu::CpuGetCcr_CCD(void){
    return(CedarGetCcr_CCD(cedar_p));
}


unsigned long Ccpu::CpuGetOcTagMASK(void){
    return(CedarGetOcTagMASK(cedar_p));
}


unsigned long Ccpu::CpuReadRAMCR_OC2W(void){
    return(CedarReadRAMCR_OC2W(cedar_p));
}

CacheSize Ccpu::CpuGetOcacheSize (void){
    return(CedarGetOcacheSize(cedar_p));
}


SnoopResponseType Ccpu::CpuOCacheSnoop(
                      long          req_id,
                      unsigned long entry,      /* $B%"%/%;%9$9$k%(%s%H%jHV9f(B */
                      long way,                 /* $B%"%/%;%9$9$k%&%'%$(B */
                      SnoopCommandType cmd,     /* $B%9%L!<%W%3%^%s%I(B(Flush, Purge, Invalidate) */
                      unsigned long **p_data,   /* $B%-%c%C%7%e4VE>AwLa$jCM(B(M State$B;~$N$_(B) */
                      SncAccessReason reason){
    return(CedarOCacheSnoop(cedar_p, req_id, entry, way, cmd, p_data, reason));
}


void Ccpu::CpuSetCompatibleMode (unsigned long mode){
    CedarSetCompatibleMode(cedar_p, mode);
}


void Ccpu::CpuWakeupProcess (InstDispMode inst_disp)
{
    CedarWakeupProcess(cedar_p, inst_disp);
}


/*** %%PROTO CpuSetEmuMode ***/
void Ccpu::CpuSetEmuMode (EmuMode emu_mode)
{
    CedarSetEmuMode(cedar_p, emu_mode);
}


long Ccpu::CpuGetSleepState (void)
{
    return( CedarGetSleepState(cedar_p) );
}


void Ccpu::CpuSetSleepState (long state)
{
    CedarSetSleepState(cedar_p, state);
}


long Ccpu::CpuCheckDebugMode (DebugMode target_mode)
{
    return( CedarCheckDebugMode(cedar_p, target_mode) );
}


void Ccpu::DumpPerformanceInfo(FILE *fp)
{
    if (fp == NULL) {
      re_printf("error","[%s]  ERROR : function \"DumpPerformanceInfo\" Get NULL Pointer.\n", this->basename());
      sc_stop();
    }
    CedarFsDisplayPerformanceCount(cedar_p, fp);
}


void Ccpu::ClearPerformanceInfo(void)
{
    CedarFsClearPerformanceCount(cedar_p);
}


void Ccpu::CpuFsDisplayInstructionCount(FILE *fp)
{
    if (fp == NULL) {
      re_printf("error","[%s]  ERROR : function \"CpuFsDisplayInstructionCount\" Get NULL Pointer.\n", this->basename());
      sc_stop();
    }
    CedarFsDisplayInstructionCount(cedar_p, fp);
}


void Ccpu::CpuFsClearInstructionCount(void)
{
    CedarFsClearInstructionCount(cedar_p);
}


void Ccpu::CpuFsEnableInstructionCount(void)
{
    CedarFsEnableInstructionCount(cedar_p);
}


void Ccpu::CpuFsDisableInstructionCount(void)
{
    CedarFsDisableInstructionCount(cedar_p);
}

void Ccpu::CpuProfileDump (void)
{
    CedarProfileDump (cedar_p);
}


void Ccpu::CpuClearProfHash (void)
{
    CedarClearProfHash (cedar_p);
}


void Ccpu::CpuSetLightSleep(unsigned long mode)
{
    CedarSetLightSleep(cedar_p, mode);
}


unsigned long Ccpu::CpuGetLightSleep(void)
{
    return( CedarGetLightSleep(cedar_p) );
}


void Ccpu::CpuClearOverflow (void)
{
    CedarClearOverflow(cedar_p);
}


void Ccpu::CpuInitExceptionBreak(unsigned long enable_flag)
{
    CedarInitExceptionBreak(cedar_p, enable_flag);
}


void Ccpu::CpuSetExceptionBreak(unsigned long exception_code, unsigned long enable_flag)
{
    CedarSetExceptionBreak(cedar_p, exception_code, enable_flag);
}


void Ccpu::CpuEnableExceptionBreak(unsigned long enable_flag)
{
    CedarEnableExceptionBreak(cedar_p, enable_flag);
}


void Ccpu::CpuDisplayExceptionBreak(void)
{
    CedarDisplayExceptionBreak(cedar_p);
}


void Ccpu::CpuAddSnpLatency(unsigned long stall)
{
    CedarAddSnpLatency(cedar_p, stall);
}

unsigned long Ccpu::CpuGetOmemReadCount(void)
{
    return(CedarGetOmemReadCount(cedar_p));
}


unsigned long Ccpu::CpuGetOmemWriteCount(void)
{
    return(CedarGetOmemWriteCount(cedar_p));
}


void Ccpu::PushVariables (FILE *fp)
{
}


void Ccpu::PopVariables (FILE *fp)
{
}

void Ccpu::CpuHardReset (void)
{
    CedarCsHardReset (cedar_p);
}

void BusAccessWrite (void* inip, unsigned long addr,
                     unsigned long data, MemAccessDataType size)
{
    ((Ccpu *)inip)->BusAccWrite (addr, &data, size);
}


unsigned long BusAccessRead (void* inip, unsigned long addr, MemAccessDataType size)
{
   unsigned long data = 0;

   ((Ccpu *)inip)->BusAccRead (addr, &data, size);

   return (data);
}


void BusAccessBurstWrite (void* inip, unsigned long addr, unsigned long *p_data, unsigned long burst_bytes)
{
    if (inip == NULL || p_data == NULL) {
      printf("ERROR : function \"BusAccessBurstWrite\" Get NULL Pointer.\n");
      sc_stop();
    }
    ((Ccpu *)inip)->BusAccWrite (addr, p_data, burst_bytes);
}


void BusAccessBurstRead (void* inip, unsigned long addr, unsigned long *p_data, unsigned long burst_bytes)
{
    if (inip == NULL || p_data == NULL) {
      printf("ERROR : function \"BusAccessBurstRead\" Get NULL Pointer.\n");
      sc_stop();
    }
    ((Ccpu *)inip)->BusAccRead (addr, p_data, burst_bytes);
}


void BusAccessWriteDebug (void* inip, unsigned long addr,
                          unsigned long data, MemAccessDataType size)
{
    if (inip == NULL) {
      printf("ERROR : function \"BusAccessWriteDebug\" Get NULL Pointer.\n");
      sc_stop();
    }
    ((Ccpu *)inip)->BusAccWriteDebug (addr, &data, size);
}


unsigned long BusAccessReadDebug (void* inip, unsigned long addr, MemAccessDataType size)
{
    unsigned long data=0;

    if (inip == NULL) {
      printf("ERROR : function \"BusAccessReadDebug\" Get NULL Pointer.\n");
      sc_stop();
    }
    ((Ccpu *)inip)->BusAccReadDebug (addr, &data, size);

    return (data);
}


void BusAccessBurstWriteDebug (void* inip, unsigned long addr, unsigned long *p_data, unsigned long burst_bytes)
{
    if (inip == NULL || p_data == NULL) {
      printf("ERROR : function \"BusAccessBurstWriteDebug\" Get NULL Pointer.\n");
      sc_stop();
    }
    ((Ccpu *)inip)->BusAccWrite(addr, p_data, burst_bytes);
}


void BusAccessBurstReadDebug (void* inip, unsigned long addr, unsigned long *p_data, unsigned long burst_bytes)
{
    if (inip == NULL) {
      printf("ERROR : function \"BusAccessBurstReadDebug\" Get NULL Pointer.\n");
      sc_stop();
    }
    ((Ccpu *)inip)->BusAccRead(addr, p_data, burst_bytes);

}

// Not Support Now. BusAccessSetLock, BusAccessSetUnLock, BusAccessSYNCO.
void BusAccessSetLock  (void *inip)
{
}


// for atomic operation TAS
void BusAccessSetUnLock  (void *inip)
{
}

void BusAccessSYNCO  (void *inip)
{
}

unsigned long GetCycleOfBusRead (long cpuid)
{
    return (0);
}

unsigned long GetCycleOfBusWrite (long cpuid)
{
    return (0);
}

unsigned long GetCycleOfBusReadLastCell (long cpuid)
{
    return (0);
}

void ForestVcr1ErrRcvWrite (long cpuid, unsigned long data)
{
}

void Ccpu::reg_write (std::string regname, unsigned int val)
{
    SH_Reg regno = CpuRegGetRegno(regname.c_str());
    if (CpuGetErrorCode () == E_OK) {
        CpuRegWriteDebug (regno, val, BANK_CHANGE_OFF);
    } else {
        if (CpuGetErrorCode () == E_REG_INVALID_REGNO) {
            CpuErrorCodeSet (E_OK);
        }
        unsigned long regaddr = CpuCtrlRegGetRegno (regname.c_str());
        if (regaddr != U_NG) {
            CpuCtrlRegWrite (regaddr, val, MEMACCESS_LONGWORD);
        }
    }
}

