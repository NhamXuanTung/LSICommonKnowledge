//$Id: Shwy_Response.h v2011_06_08 $

#ifndef __SHWY_RESPONSE_H__
#define __SHWY_RESPONSE_H__

#include "arbiter.h"
#include "arbiter_creator.h"
#include "arbiter_dynamic.h"

#include "Shwy_type.h"

template <int NR_OF_INITIATORS, int NR_OF_TARGETS, int BUS_WIDTH>
class Shwy;

template <int NR_OF_INITIATORS, int NR_OF_TARGETS, int BUS_WIDTH=32>
class Shwy_Response : public sc_core::sc_module
{
public:
  typedef tlm::tlm_generic_payload               transaction_type;
  typedef tlm::tlm_phase                         phase_type;
  typedef tlm::tlm_sync_enum                     sync_enum_type;
  typedef tlm_utils::simple_target_socket_tagged<Shwy<NR_OF_INITIATORS,NR_OF_TARGETS,BUS_WIDTH>, BUS_WIDTH> target_socket_type;
  typedef tlm_utils::simple_initiator_socket_tagged<Shwy<NR_OF_INITIATORS,NR_OF_TARGETS,BUS_WIDTH>, BUS_WIDTH> initiator_socket_type;

private:
  Shwy<NR_OF_INITIATORS,NR_OF_TARGETS,BUS_WIDTH>* top_ptr;
  transaction_type* resp_gp_ptr[NR_OF_TARGETS];
  arbiter_base* resp_arb_top;

  int debug_print_level;
  bool m_lck;

public:
  SC_HAS_PROCESS(Shwy_Response);
  Shwy_Response(sc_core::sc_module_name name, Shwy<NR_OF_INITIATORS,NR_OF_TARGETS,BUS_WIDTH>* shwy_ptr) :
  sc_core::sc_module(name),
  mResponsePEQ("responsePEQ")
  { // constructor
    
    top_ptr = shwy_ptr;
    
    for (unsigned int i = 0; i < NR_OF_TARGETS; i++) {
      resp_gp_ptr[i] = 0;
    }
    // initialize response arb_top
    resp_arb_top = 0;

    // initialize debugprint_level
    debug_print_level = top_ptr->debug_print_level;
    m_lck = false;
    
    SC_THREAD(ResponseThread);
  }

  ~Shwy_Response() {
    delete resp_arb_top;
  }
  
  void set_resp_arb (std::string arb_exp)
  {
    arbiter_creator arb_creator;
    resp_arb_top = arb_creator.parse_exp(arb_exp, NR_OF_TARGETS);

    if (resp_arb_top == NULL) {
      printf("[%s] Fatal Error! arbiter top pointer(set_resp_arb) is NULL!\n",this->get_name());
      exit(1);
      if (resp_arb_top == NULL) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" );
    }
  }

  
  void set_resp_arb_by_number (int number_of_ips)
  {
    //
    arbiter_fix* temp_resp_arb_top = new arbiter_fix();

    if (temp_resp_arb_top == NULL) {
      printf("[%s] Memory allocation error\n",this->get_name());
      SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" );
    }

    for (int i=0; i<number_of_ips; i++) {
      arbiter_leaf* arb_i = new arbiter_leaf(i);
      temp_resp_arb_top->add_child(arb_i);
    }
    resp_arb_top = (arbiter_base *)temp_resp_arb_top;
  }

  void notify_ResponseThread(transaction_type& trans, sc_core::sc_time& t)
  {
    mResponsePEQ.notify(trans,t);
  }
  
  void notify_EndResponseEvent(sc_core::sc_time& t)
  {
    mEndResponseEvent.notify(t);
  }
  
  void set_dprint_level(int dprint_level) {
    debug_print_level = dprint_level;
  }

  /*  DUMP PROFILE INFORMATION  */
  bool DumpProfile(FILE *p_file = stdout, sc_time_unit timescale = SC_NS)
  {
    return true;
  }

private:
  void ResponseThread()
  {
    while (true) {

      transaction_type* trans = mResponsePEQ.get_next_transaction();

      if(trans == 0) {
        wait(mResponsePEQ.get_event());
        trans = mResponsePEQ.get_next_transaction();
      }

      while(1) {

        if(trans == 0) {
          trans = mResponsePEQ.get_next_transaction();
        }

        while (trans != 0) {

          // decode address
          int wTargetId = (int)top_ptr->Caddress_map0.getModuleID((unsigned int)trans->get_address());
	  // The return value type of get_address() method is sc_dt::uint64. But, this data can describe at 32bit.
	  // So, cast unsigned int from sc_dt::uint64.

          //          printf("Resp Candidate is tgt%d\n", wTargetId);
          
          // register target to arbiter
          if (resp_arb_top != NULL) {
            resp_arb_top->request(wTargetId);
          } else {
            printf("[%s] Error In [ResponseThread], Response Arbitor Tree is fail to build(Arbiter Top is NULL pointer)!\n", this->get_name());
            sc_stop();
            return;
          }
          
          // store pointer of generic_payload to resp_arry
          resp_gp_ptr[wTargetId] = trans;

          trans = mResponsePEQ.get_next_transaction();
        }
        // When there is no candidate for mediation,
        // escapes from while (1) loop and waits for the next response.

        wait( sc_time(0, SC_NS) );

        int TargetId = resp_arb_top->get_winner();
        if ( TargetId == -1) {
          break;
        } 

        top_ptr->m_beg_resp_wait--;
        top_ptr->m_beg_resp_event.notify();

        trans = resp_gp_ptr[TargetId];

        if(debug_print_level > 0)  print_log(trans, TargetId);

        vpcl::bus_extension *bus_ext = get_bus_extension(trans);
          
        // winner's r_lck check
        if (bus_ext !=NULL) {
          if (bus_ext->r_lck) {
            resp_arb_top->notify_lck(TargetId);
          } else {
            resp_arb_top->notify_unlck();
          }
        }
        
        // delete winner from resp_array
        resp_gp_ptr[TargetId] = 0;
        
        phase_type phase = tlm::BEGIN_RESP;
        sc_core::sc_time t = sc_core::SC_ZERO_TIME;
        
        target_socket_type* initiatorSocket = &(top_ptr->target_socket)[top_ptr->getIniIdFromPendingTransactions(*trans)];
        
        // if BEGIN_RESP is send first we don't have to send END_REQ anymore
        top_ptr->setBeginRespFlag(*trans);

        // int resp_begin_time = (int)sc_time_stamp().value();
        // top_ptr->setRespToIniTime(*trans, resp_begin_time);

        switch ((*initiatorSocket)->nb_transport_bw(*trans, phase, t)) {
          
        case tlm::TLM_COMPLETED:
          // Transaction finished
          wait(t);
          break;
          
        case tlm::TLM_ACCEPTED:
          if ( phase == tlm::BEGIN_RESP ) {
            wait(mEndResponseEvent);
            break;
          } 
        case tlm::TLM_UPDATED:
          //Transaction not yet finished
          if ( phase == tlm::END_RESP ) {
            wait(t);
            break;
          } 
        default:
    	  if (!false) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" );
        };
        
        // forward END_RESP to target
        if (top_ptr->getTgtIdFromPendingTransactions(*trans) >= 0) {
          phase = tlm::END_RESP;
          t = sc_core::SC_ZERO_TIME;
          sync_enum_type r = (top_ptr->initiator_socket[top_ptr->getTgtIdFromPendingTransactions(*trans)])->nb_transport_fw(*trans, phase, t);
	  if (r != tlm::TLM_COMPLETED) SC_REPORT_ERROR( SC_ID_ASSERTION_FAILED_ , "" );
        }
        
        top_ptr->erasePendingTransactions(*trans);
        trans->release();
        trans = 0;
      }
    }
  }
  
private:
  tlm_utils::peq_with_get<transaction_type> mResponsePEQ;
  sc_core::sc_event mBeginResponseEvent;
  sc_core::sc_event mEndResponseEvent;
  
  // get instance name.
  const char *get_name()
  {
    return this->name();
  }

  vpcl::bus_extension * get_bus_extension(transaction_type * trans)
  {
    vpcl::tlm_if_extension *p_ext;
    trans->get_extension(p_ext);

    if(p_ext != NULL) {
      return p_ext->p_bus_ext;
    }
    return NULL;
  }

  // debug print
  void print_log(transaction_type* trans, int id)
  {
    vpcl::bus_extension *bus_ext = get_bus_extension(trans);

    // winner's lck check
    if (bus_ext != NULL) {
      if (bus_ext->r_lck) {
        if(m_lck == false) {
          cout << "Info [" << sc_time_stamp() << "] (" << get_name() << ") Response Resource is locked by target " << id << endl;
        }
        m_lck = true;
      } else {
        if(m_lck == true) {
          cout << "Info [" << sc_time_stamp() << "] (" << get_name() << ") Response Resource is unlocked by target " << id << endl;
        }
        m_lck = false;
      }
    }
  }
};

#endif
