// $Id: arbiter_prob.h v2011_05_12 $
// =============================================================
//  file name : arbiter_prob.h
// =============================================================

#ifndef __ARBITER_PROB_H
#define __ARBITER_PROB_H

#include "systemc.h"
#include "arbiter.h"

#include <map>
#include <list>

/*  ARBITER ELEMENT  */
class arbiter_prob_elm : public arbiter_base_elm
{
  /*  SORT OBJECT  */
  friend class arbiter_prob_sort;

  /*  MEMBER DATA  */
  const int m_id;
  int m_priority;
  bool m_request;
  unsigned int m_prob_num;
  unsigned int m_prob_denom;  // NO USE
  unsigned int m_count;

public:
  /*  CONSTRUCTOR  */
  arbiter_prob_elm(int id, int priority, unsigned int prob_num, unsigned int prob_denom)
    : m_id(id)
    , m_priority(priority)
    , m_request(false)
    , m_prob_num()
    , m_prob_denom()
    , m_count(0)
  {
    if (prob_denom == 0) {
      m_prob_denom = 1;
    }
    else {
      m_prob_denom = prob_denom;
    }
    if (prob_num == 0) {
      m_prob_num = 1;
    }
    else if (prob_num > m_prob_denom) {
      m_prob_num = m_prob_denom;
    }
    else {
      m_prob_num = prob_num;
    }
  }

  /*  MEMBER FUNCTION  */
  arbiter_prob_elm *clone() const
  {
    return new arbiter_prob_elm(*this);
  }

  int get_id()
  {
    return m_id;
  }

  void set_priority(int priority)
  {
    m_priority = priority;
  }

  int get_priority()
  {
    return m_priority;
  }

  void set_probability(unsigned int prob_num, unsigned int prob_denom)
  {
    if (prob_denom == 0) {
      m_prob_denom = 1;
    }
    else {
      m_prob_denom = prob_denom;
    }
    if (prob_num == 0) {
      m_prob_num = 1;
    }
    else if (prob_num > m_prob_denom) {
      m_prob_num = m_prob_denom;
    }
    else {
      m_prob_num = prob_num;
    }
    m_count = 0;
  }

  unsigned int get_prob_num()
  {
    return m_prob_num;
  }

  unsigned int get_prob_denom()
  {
    return m_prob_denom;
  }

  void request()
  {
    m_request = true;
  }

  void reset_request()
  {
    m_request = false;
  }

  bool is_request()
  {
    return m_request;
  }

  void count()
  {
    m_count++;
    if (m_count == m_prob_num) {
      m_count = 0;
    }
  }

  void reset_count()
  {
    m_count = 0;
  }

  int get_count()
  {
    return m_count;
  }

  void all_reset()
  {
    m_request = false;
    m_count = 0;
  }
};

/*  SORT OBJECT  */
class arbiter_prob_sort
{
  /*  MEMBER DATA  */
  ARB_PRI_MODE m_mode;

public:
  /*  CONSTRUCTOR  */
  arbiter_prob_sort(ARB_PRI_MODE mode)
    : m_mode(mode)
  {
    /*  DO NOTHING  */
  }

  /*  MEMBER FUNCTION  */
  bool operator () (const arbiter_prob_elm *lit, const arbiter_prob_elm *rit)
  {
    if (m_mode == ARB_PRI_UPER_HIGH) {
      return (lit->m_priority == rit->m_priority) ?
        (lit->m_id > rit->m_id) : (lit->m_priority > rit->m_priority);
    }
    else {
      return (lit->m_priority == rit->m_priority) ?
        (lit->m_id < rit->m_id) : (lit->m_priority < rit->m_priority);
    }
  }
};

/*  ARBITER  */
class arbiter_prob : public arbiter_base
{
  /*  TYPE DEFINITION  */
  typedef std::map<int, arbiter_prob_elm *> std_elm_map;
  typedef std::map<int, arbiter_prob_elm *>::iterator std_elm_map_it;
  typedef std::list<arbiter_prob_elm *> std_elm_list;
  typedef std::list<arbiter_prob_elm *>::iterator std_elm_list_it;

  /*  MEMBER DATA  */
  std_elm_map m_elm_map;
  std_elm_list m_elm_list;
  ARB_PRI_MODE m_mode;
  ARB_STATUS m_status;
  bool m_list_update;
  std_elm_list_it t_winner; // TEMPORARY DATA BETWEEN MEMBER FUNCTION

public:
  /*  CONSTRUCTOR  */
  arbiter_prob(ARB_PRI_MODE mode = ARB_PRI_UPER_HIGH)
    : m_mode(mode)
    , m_status(ARB_NORMAL)
    , m_list_update(false)
  {
    /*  DO NOTHING  */
  }

  /*  DESTRUCTOR  */
  virtual ~arbiter_prob()
  {
    for (std_elm_map_it it = m_elm_map.begin(); it != m_elm_map.end(); it++) {
      delete it->second;
    }
  }

  /*  MEMBER FUNCTIOM  */
  void add_element(int id, int priority = 0, unsigned int prob_num = 1, unsigned int prob_denom = 1)
  {
    if (m_elm_map.count(id)) {
      m_status = ARB_ERROR;
    }
    else {
      m_elm_map[id] = new arbiter_prob_elm(id, priority, prob_num, prob_denom);
      m_elm_list.push_back(m_elm_map[id]);
      m_list_update = true;
      m_status = ARB_NORMAL;
    }
  }

  void add_element(int id, arbiter_base_elm *element) {
    if (m_elm_map.count(id)) {
      m_status = ARB_ERROR;
    }
    else {
      m_elm_map[id] = (arbiter_prob_elm *) element;
      m_elm_list.push_back(m_elm_map[id]);
      m_list_update = true;
      m_status = ARB_NORMAL;
    }
  }

  int get_element_size () {
    m_status = ARB_NORMAL;
    return m_elm_map.size();
  }

  void set_priority(int id, int priority)
  {
    if (! m_elm_map.count(id)) {
      m_status = ARB_ERROR;
    }
    else {
      m_elm_map[id]->set_priority(priority);
      m_list_update = true;
      m_status = ARB_NORMAL;
    }
  }

  int get_priority(int id)
  {
    if (! m_elm_map.count(id)) {
      m_status = ARB_ERROR;
      return -1;
    }
    else {
      m_status = ARB_NORMAL;
      return m_elm_map[id]->get_priority();
    }
  }

  void set_descending_order() {
    m_mode = ARB_PRI_UPER_HIGH;
    m_list_update = true;
    m_status = ARB_NORMAL;
  }

  bool is_descending_order() {
    m_status = ARB_NORMAL;
    return (m_mode == ARB_PRI_UPER_HIGH);
  }

  void set_ascending_order() {
    m_mode = ARB_PRI_LOWER_HIGH;
    m_list_update = true;
    m_status = ARB_NORMAL;
  }

  bool is_ascending_order() {
    m_status = ARB_NORMAL;
    return (m_mode == ARB_PRI_LOWER_HIGH);
  }

  void request(int id)
  {
    if (! m_elm_map.count(id)) {
      m_status = ARB_ERROR;
    }
    else {
      m_elm_map[id]->request();
      m_status = ARB_NORMAL;
    }
  }

  void reset()
  {
    for (std_elm_map_it it = m_elm_map.begin(); it != m_elm_map.end(); it++) {
      it->second->reset_request();
    }
    m_status = ARB_NORMAL;
  }

  void reset(int id)
  {
    if (! m_elm_map.count(id)) {
      m_status = ARB_ERROR;
    }
    else {
      m_elm_map[id]->reset_request();
      m_status = ARB_NORMAL;
    }
  }

  void all_reset()
  {
    for (std_elm_map_it it = m_elm_map.begin(); it != m_elm_map.end(); it++) {
      it->second->all_reset();
    }
    m_list_update = true;
    m_status = ARB_NORMAL;
  }

  int get_winner()
  {
    int winner_id = winner();
    if (winner_id != -1) {
      (*t_winner)->reset_request();
      (*t_winner)->count();
      if ((*t_winner)->get_count() == 0) {
        m_elm_list.push_back(*t_winner);
        m_elm_list.erase(t_winner);
      }
    }
    return winner_id;
  }

  int winner()
  {
    if (m_list_update) {
      m_elm_list.sort(arbiter_prob_sort(m_mode));
      m_list_update = false;
    }
    int winner_id = -1;
    for (std_elm_list_it it = m_elm_list.begin(); it != m_elm_list.end(); it++) {
      if ((*it)->is_request()) {
        t_winner = it;
        winner_id = (*it)->get_id();
        break;
      }
    }
    m_status = ARB_NORMAL;
    return winner_id;
  }

  ARB_STATUS get_status()
  {
    return m_status;
  }

  void notify_lck(int id)
  {
    /*  UNSUPPORTED  */
    m_status = ARB_ERROR;
  }

  void notify_unlck()
  {
    /*  UNSUPPORTED  */
    m_status = ARB_ERROR;
  }
};

#endif
