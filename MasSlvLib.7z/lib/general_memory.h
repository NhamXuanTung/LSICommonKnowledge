// $Id: general_memory.h v2014_03_26 $
/* ============================================================= */
/*  file name : general_memory.h                                 */
/* ============================================================= */

#ifndef __GENERAL_MEMORY_H__
#define __GENERAL_MEMORY_H__

#include "systemc.h"
#include "tlm.h"
#include "tlm_tgt_if.h"
#include <cstdio>
#include <cstring>
#include <cstdarg>
#include <iostream>
#include <string>
#include <vector>
#include <map>

#ifdef CWR_SYSTEMC
#include "scml2.h"
#endif

namespace gm
{
enum gm_command {
  gm_COMMAND_NONE = 0,
  gm_COMMAND_READ = 1,
  gm_COMMAND_WRITE = 2
};

enum gm_permission {
  gm_PERMISSION_NONE = 0,
  gm_PERMISSION_READ = 1,
  gm_PERMISSION_WRITE = 2,
  gm_PERMISSION_READ_WRITE = gm_PERMISSION_READ | gm_PERMISSION_WRITE
};
struct gm_block_config {
  const sc_dt::uint64 m_size;
  sc_dt::uint64 m_tdmi_beg;
  sc_dt::uint64 m_tdmi_end;
#ifdef CWR_SYSTEMC
  scml2::memory<unsigned char> *const m_data;
#else
  unsigned char *const m_data;
#endif
  gm_block_config(sc_dt::uint64 size, unsigned char default_value) 
     : m_size(size)
     , m_tdmi_beg(0ULL)
     , m_tdmi_end(0ULL)
#ifdef CWR_SYSTEMC
     , m_data(new scml2::memory<unsigned char>("", size))
#else
     , m_data(new unsigned char [ToUint(size)])
#endif
  {
    if (m_data == NULL) {
      printf("fatal : Invalid memory allocation has occured.\n"),
      exit(1);
    }
    Initialize(default_value);
  }
  ~gm_block_config(void)
  {
#ifdef CWR_SYSTEMC
     delete m_data;
#else
     delete [] m_data;
#endif
  }
  void Initialize(unsigned char default_value) {
#ifdef CWR_SYSTEMC
    m_data->initialize(default_value);
#else
    memset(m_data, default_value, (unsigned int) m_size);
#endif
  }
  unsigned int ToUint(sc_dt::uint64 size) {
    if (sizeof(void *) == 4) {
      if (size > 0xFFFFFFFFULL) {
        return 0xFFFFFFFF;
      }
      else {
        return (unsigned int) size;
      }
    }
    else if (sizeof(void *) == 8) {
      return (unsigned int) size;
    }
    else {
      exit(1);
    }
  }
};
struct gm_area_config {
  const std::string m_name;
  const sc_dt::uint64 m_offset;
  const sc_dt::uint64 m_size;
  const bool m_dmi_enable;
  std::map<unsigned int, gm_block_config*> m_blocks;
  const std::string m_ref_name;
  gm_permission m_perm;
  sc_time m_read_wait;
  sc_time m_write_wait;
  sc_dt::uint64 m_tdmi_beg;
  sc_dt::uint64 m_tdmi_end;
  sc_dt::uint64 m_block_size;
  unsigned char m_default_value;

  gm_area_config(const std::string &area, sc_dt::uint64 offset, sc_dt::uint64 size, bool dmi_enable, sc_dt::uint64 block_size)
    : m_name(area)
    , m_offset(offset)
#ifdef CWR_SYSTEMC
    , m_size(size)
#else
    , m_size(ToUint(size))
#endif
    , m_dmi_enable(dmi_enable)
    , m_ref_name("")
    , m_perm(gm_PERMISSION_READ_WRITE)
    , m_read_wait(SC_ZERO_TIME)
    , m_write_wait(SC_ZERO_TIME)
    , m_tdmi_beg(0ULL)
    , m_tdmi_end(0ULL)
    , m_block_size(block_size)
    , m_default_value(0x00)
  {
  }

  gm_area_config(const std::string &area, sc_dt::uint64 offset, sc_dt::uint64 size, gm_area_config *ref_cfg, sc_dt::uint64 block_size)
    : m_name(area)
    , m_offset(offset)
#ifdef CWR_SYSTEMC
    , m_size(size)
#else
    , m_size(ToUint(size))
#endif
    , m_dmi_enable(ref_cfg->m_dmi_enable)
    , m_blocks(ref_cfg->m_blocks)
    , m_ref_name(ref_cfg->m_name)
    , m_perm(gm_PERMISSION_READ_WRITE)
    , m_read_wait(SC_ZERO_TIME)
    , m_write_wait(SC_ZERO_TIME)
    , m_tdmi_beg(0ULL)
    , m_tdmi_end(0ULL)
    , m_block_size(block_size)
    , m_default_value(ref_cfg->m_default_value)
  {
  }

  ~gm_area_config()
  {
    if (m_ref_name == "") {
      for (std::map<unsigned int, gm_block_config*>::const_iterator it = m_blocks.begin(); it != m_blocks.end(); it++) {
        delete it->second;
      }
    }
  }

  void Initialize(void) {
    for (std::map<unsigned int, gm_block_config*>::const_iterator it = m_blocks.begin(); it != m_blocks.end(); it++) {
      it->second->Initialize(0x00);
    }
    m_perm = gm_PERMISSION_READ_WRITE;
    m_read_wait = SC_ZERO_TIME;
    m_write_wait = SC_ZERO_TIME;
    m_tdmi_beg = 0ULL;
    m_tdmi_end = 0ULL;
    m_default_value = 0x00;
  }

  unsigned int ToUint(sc_dt::uint64 size) {
    if (sizeof(void *) == 4) {
      if (size > 0xFFFFFFFFULL) {
        return 0xFFFFFFFF;
      }
      else {
        return (unsigned int) size;
      }
    }
    else if (sizeof(void *) == 8) {
      return (unsigned int) size;
    }
    else {
      exit(1);
    }
  }

  void ReadArea(sc_dt::uint64 offset, unsigned int size, unsigned char* p_data)
  {
    unsigned int block_index = offset/m_block_size;
    unsigned int block_offset = offset%m_block_size;
    unsigned int accessed_block_num = (block_offset + size)/m_block_size;
    if(((block_offset + size) % m_block_size) > 0) {
      accessed_block_num++;
    }
    unsigned int accumulate_size = 0;
    unsigned int acc_size = 0;
    for(unsigned int i=0;i<accessed_block_num;i++) {
      acc_size = (block_offset + size - accumulate_size) > m_block_size ? (m_block_size - block_offset):(size-accumulate_size);
      if(m_blocks.find(block_index + i) == m_blocks.end()) { // for unallocated block -> return default value
#ifdef CWR_SYSTEMC
        memset(&p_data[accumulate_size],m_default_value,acc_size);
#else
        memset(&p_data[accumulate_size],m_default_value,acc_size);
#endif
      } else { // for allocated block
#ifdef CWR_SYSTEMC
        m_blocks[block_index+i]->m_data->get(block_offset,&p_data[accumulate_size],acc_size);
#else
        memcpy(&p_data[accumulate_size],&(m_blocks[block_index+i]->m_data[block_offset]),acc_size);
#endif
      }
      accumulate_size += acc_size;
      block_offset = 0;
    }  
  }

  void WriteArea(sc_dt::uint64 offset, unsigned int size, const unsigned char* p_data)
  {
    unsigned int block_index = offset/m_block_size;
    unsigned int block_offset = offset%m_block_size;
    unsigned int accessed_block_num = AllocateMemoryBlock(block_index,block_offset,size);
    unsigned int accumulate_size = 0;
    unsigned int acc_size = 0;
    for(unsigned int i=0;i<accessed_block_num;i++) {
      acc_size = (block_offset + size - accumulate_size) > m_block_size ? (m_block_size - block_offset):(size-accumulate_size);
#ifdef CWR_SYSTEMC
      m_blocks[block_index+i]->m_data->put(block_offset,&p_data[accumulate_size],acc_size);
#else
      memcpy(&(m_blocks[block_index+i]->m_data[block_offset]),&p_data[accumulate_size],acc_size);
#endif
      accumulate_size += acc_size;
      block_offset = 0;
    }  
  }

  unsigned int AllocateMemoryBlock(unsigned int block_index, unsigned int block_offset, unsigned int size)
  {
    unsigned int allocated_block_num = (block_offset + size)/m_block_size;
    if(((block_offset + size) % m_block_size) > 0) {
      allocated_block_num++;  
    }
    for(unsigned int i=0;i<allocated_block_num;i++) {
      if(m_blocks.find(block_index + i) == m_blocks.end()) {
        if(i == (allocated_block_num-1)) { // allocated is last block
          if((block_index + allocated_block_num)*m_block_size > m_size) { // last block reachs area bottom 
            m_blocks[block_index+i] = new gm_block_config(m_size%m_block_size, m_default_value);
          } else {
            m_blocks[block_index+i] = new gm_block_config(m_block_size, m_default_value);
          }
        } else {
          m_blocks[block_index+i] = new gm_block_config(m_block_size, m_default_value);
        }
      }
    }
    return allocated_block_num;
  }
};

typedef std::map<const std::string, gm_area_config *const> gm_memory_config;

template <unsigned int REG_BUSWIDTH, unsigned int REG_N, unsigned int MEM_BUSWIDTH, unsigned int MEM_N>
class gm_register_tgt;

template <unsigned int REG_BUSWIDTH, unsigned int REG_N, unsigned int MEM_BUSWIDTH, unsigned int MEM_N>
class gm_memory_tgt;

template <unsigned int REG_BUSWIDTH, unsigned int REG_N, unsigned int MEM_BUSWIDTH, unsigned int MEM_N>
class Cgeneral_memory
{
#include "general_memory_cmdif.h"
private:
  enum eGeneralMemoryParam
  {
    emDefaultBlockSize = 1048576  // 1MB
  };

public:
  tlm::tlm_target_socket<REG_BUSWIDTH, tlm::tlm_base_protocol_types, 1, sc_core::SC_ONE_OR_MORE_BOUND> *m_reg_sockets[REG_N];
  tlm::tlm_target_socket<MEM_BUSWIDTH, tlm::tlm_base_protocol_types, 1, sc_core::SC_ONE_OR_MORE_BOUND> *m_mem_sockets[MEM_N];

  friend class gm_register_tgt<REG_BUSWIDTH, REG_N, MEM_BUSWIDTH, MEM_N>;
  gm_register_tgt<REG_BUSWIDTH, REG_N, MEM_BUSWIDTH, MEM_N> m_reg_tgt;
  friend class gm_memory_tgt<REG_BUSWIDTH, REG_N, MEM_BUSWIDTH, MEM_N>;
  gm_memory_tgt<REG_BUSWIDTH, REG_N, MEM_BUSWIDTH, MEM_N> m_mem_tgt;

private:
  unsigned int m_address_width;
  gm_memory_config m_mem_cfg;
  gm_command m_prev_cmd;
  std::string m_prev_area;
  sc_time m_prev_end;
  sc_dt::uint64 m_prev_block_size;

protected:
  Cgeneral_memory(const char *name, unsigned int address_width)
    : m_reg_tgt((std::string(name) + "_reg_tgt").c_str(), this)
    , m_mem_tgt((std::string(name) + "_mem_tgt").c_str(), this)
    , m_address_width(address_width)
    , m_mem_cfg()
    , m_prev_cmd(gm_COMMAND_NONE)
    , m_prev_area("")
    , m_prev_end(SC_ZERO_TIME)
    , m_prev_block_size(emDefaultBlockSize)
  {
    CommandInit(name);
    for (unsigned int i = 0; i < REG_N; i++) {
      m_reg_sockets[i] = m_reg_tgt.m_tgt_sockets[i];
    }
    for (unsigned int i = 0; i < MEM_N; i++) {
      m_mem_sockets[i] = m_mem_tgt.m_tgt_sockets[i];
    }
  }

  virtual ~Cgeneral_memory()
  {
    RemoveAreaConfig();
  }

  void Initialize(void)
  {
    RemoveAreaConfig();
    m_prev_cmd = gm_COMMAND_NONE;
    m_prev_area = "";
    m_prev_end = SC_ZERO_TIME;
    re_printf("info", "Initialize() succeeded.\n");
  }

  bool GetHistory(gm_command &prev_cmd, std::string &prev_area, sc_time &prev_end)
  {
    prev_cmd = m_prev_cmd;
    prev_area = m_prev_area;
    prev_end = m_prev_end;
    return (m_prev_cmd != gm_COMMAND_NONE);
  }

  bool AddAreaConfig(const std::string &area, sc_dt::uint64 offset, sc_dt::uint64 size, bool dmi_enable = true)
  {
    char func_name[256] = "";
    sprintf(func_name, "AddAreaConfig(%s, 0x%08llX, 0x%08llX, %s)", area.c_str(), offset, size, dmi_enable ? "true" : "false");
    if (m_mem_cfg.count(area) > 0) {
      re_printf("error", "%s failed. argument of area name is duplicate.\n", func_name);
      return false;
    }
    if ((offset + size) > (1ULL << m_address_width)) {
      re_printf("error", "%s failed. argument of area range is out of bounds.\n", func_name);
      return false;
    }
    for (gm_memory_config::const_iterator it = m_mem_cfg.begin(); it != m_mem_cfg.end(); it++) {
      if ((offset < (it->second->m_offset + it->second->m_size)) && ((offset + size) > it->second->m_offset)) {
        re_printf("error", "%s failed. argument of area range is overlap with other area.\n", func_name);
        return false;
      }
    }
    m_mem_cfg.insert(gm_memory_config::value_type(area, new gm_area_config(area, offset, size, dmi_enable, AreaBlockSize)));
    re_printf("info", "%s succeeded.\n", func_name);
    return true;
  }

  bool AddAreaConfig(const std::string &area, sc_dt::uint64 offset, sc_dt::uint64 size, const char *ref_name)
  {
    std::string ref(ref_name);
    char func_name[256] = "";
    sprintf(func_name, "AddAreaConfig(%s, 0x%08llX, 0x%08llX, %s)", area.c_str(), offset, size, ref.c_str());
    if (m_mem_cfg.count(area) > 0) {
      re_printf("error", "%s failed. argument of area name is duplicate.\n", func_name);
      return false;
    }
    if ((offset + size) > (1ULL << m_address_width)) {
      re_printf("error", "%s failed. argument of area range is out of bounds.\n", func_name);
      return false;
    }
    for (gm_memory_config::const_iterator it = m_mem_cfg.begin(); it != m_mem_cfg.end(); it++) {
      if ((offset < (it->second->m_offset + it->second->m_size)) && ((offset + size) > it->second->m_offset)) {
        re_printf("error", "%s failed. argument of area range is overlap with other area.\n", func_name);
        return false;
      }
    }
    if (m_mem_cfg.count(ref) == 0) {
      re_printf("error", "%s failed. argument of reference name is unfound.\n", func_name);
      return false;
    }
    if (m_mem_cfg[ref]->m_ref_name != "") {
      re_printf("error", "%s failed. argument of reference name specifies alias area.\n", func_name);
      return false;
    }
    if (size > m_mem_cfg[ref]->m_size) {
      re_printf("error", "%s failed. argument of area range is greater than reference range.\n", func_name);
      return false;
    }
    m_mem_cfg.insert(gm_memory_config::value_type(area, new gm_area_config(area, offset, size, m_mem_cfg[ref], AreaBlockSize)));
    re_printf("info", "%s succeeded.\n", func_name);
    return true;
  }

  bool RemoveAreaConfig(const std::string &area = "")
  {
    char func_name[256] = "";
    sprintf(func_name, "RemoveAreaConfig(%s)", area.c_str());
    if (area == "") {
      if (m_mem_cfg.size() == 0) {
        re_printf("warning", "%s was no point. there are no area configuration.\n", func_name);
        return false;
      }
      for (gm_memory_config::const_iterator it = m_mem_cfg.begin(); it != m_mem_cfg.end(); it++) {
        if (it->second->m_tdmi_end != 0ULL) {
          for (unsigned int i = 0; i < MEM_N; i++) {
            m_mem_tgt.tgt_reset_dmi(i, it->second->m_tdmi_beg, it->second->m_tdmi_end);
          }
        }
        delete it->second;
      }
      m_mem_cfg.clear();
    }
    else {
      if (m_mem_cfg.count(area) == 0) {
        re_printf("error", "%s failed. argument of area name is unfound.\n", func_name);
        return false;
      }
      if (m_mem_cfg[area]->m_tdmi_end != 0ULL) {
        for (unsigned int i = 0; i < MEM_N; i++) {
          m_mem_tgt.tgt_reset_dmi(i, m_mem_cfg[area]->m_tdmi_beg, m_mem_cfg[area]->m_tdmi_end);
        }
      }
      delete m_mem_cfg[area];
      m_mem_cfg.erase(area);
      gm_memory_config::iterator it = m_mem_cfg.begin();
      while (it != m_mem_cfg.end()) {
        if (it->second->m_ref_name == area) {
          if (it->second->m_tdmi_end != 0ULL) {
            for (unsigned int i = 0; i < MEM_N; i++) {
              m_mem_tgt.tgt_reset_dmi(i, it->second->m_tdmi_beg, it->second->m_tdmi_end);
            }
          }
          delete it->second;
          m_mem_cfg.erase(it++);
        }
        else {
          it++;
        }
      }
    }
    re_printf("info", "%s succeeded.\n", func_name);
    return true;
  }

  bool InitializeAreaConfig(const std::string &area = "")
  {
    char func_name[256] = "";
    sprintf(func_name, "InitializeAreaConfig(%s)", area.c_str());
    if (area == "") {
      if (m_mem_cfg.size() == 0) {
        re_printf("warning", "%s was no point. there are no area configuration.\n", func_name);
        return false;
      }
      for (gm_memory_config::const_iterator it = m_mem_cfg.begin(); it != m_mem_cfg.end(); it++) {
        if (it->second->m_tdmi_end != 0ULL) {
          for (unsigned int i = 0; i < MEM_N; i++) {
            m_mem_tgt.tgt_reset_dmi(i, it->second->m_tdmi_beg, it->second->m_tdmi_end);
          }
        }
        it->second->Initialize();
      }
    }
    else {
      if (m_mem_cfg.count(area) == 0) {
        re_printf("error", "%s failed. argument of area name is unfound.\n", func_name);
        return false;
      }
      if (m_mem_cfg[area]->m_tdmi_end != 0ULL) {
        for (unsigned int i = 0; i < MEM_N; i++) {
          m_mem_tgt.tgt_reset_dmi(i, m_mem_cfg[area]->m_tdmi_beg, m_mem_cfg[area]->m_tdmi_end);
        }
      }
      m_mem_cfg[area]->Initialize();
    }
    re_printf("info", "%s succeeded.\n", func_name);
    return true;
  }

  bool SetAreaData(const std::string &area, unsigned char data)
  {
    char func_name[256] = "";
    sprintf(func_name, "SetAreaData(%s, 0x%02X)", area.c_str(), data);
    if (area == "") {
      if (m_mem_cfg.size() == 0) {
        re_printf("warning", "%s was no point. there are no area configuration.\n", func_name);
        return false;
      }
      for (gm_memory_config::const_iterator it = m_mem_cfg.begin(); it != m_mem_cfg.end(); it++) {
        gm_area_config *area_cfg = it->second;
        for (std::map<unsigned int, gm_block_config*>::const_iterator it1 = area_cfg->m_blocks.begin(); it1 != area_cfg->m_blocks.end(); it1++) {
          it1->second->Initialize(data);
        }
        area_cfg->m_default_value = data;
      }
    }
    else {
      if (m_mem_cfg.count(area) == 0) {
        re_printf("error", "%s failed. argument of area name is unfound.\n", func_name);
        return false;
      }
      gm_area_config *area_cfg = m_mem_cfg[area];
      for (std::map<unsigned int, gm_block_config*>::const_iterator it1 = area_cfg->m_blocks.begin(); it1 != area_cfg->m_blocks.end(); it1++) {
        it1->second->Initialize(data);
      }
      area_cfg->m_default_value = data;
    }
    re_printf("info", "%s succeeded.\n", func_name);
    return true;
  }

  bool SetAreaPermission(const std::string &area, gm_permission perm)
  {
    char func_name[256] = "";
    sprintf(func_name, "SetAreaPermission(%s, %s)", area.c_str(), ToString(perm).c_str());
    if (area == "") {
      if (m_mem_cfg.size() == 0) {
        re_printf("warning", "%s was no point. there are no area configuration.\n", func_name);
        return false;
      }
      for (gm_memory_config::const_iterator it = m_mem_cfg.begin(); it != m_mem_cfg.end(); it++) {
        gm_area_config *area_cfg = it->second;
        for (std::map<unsigned int, gm_block_config*>::const_iterator it1 = area_cfg->m_blocks.begin(); it1 != area_cfg->m_blocks.end(); it1++) {
          if (it1->second->m_tdmi_end != 0ULL) {
            for (unsigned int i = 0; i < MEM_N; i++) {
              m_mem_tgt.tgt_reset_dmi(i, it1->second->m_tdmi_beg, it1->second->m_tdmi_end);
            }
            it1->second->m_tdmi_beg = 0ULL;
            it1->second->m_tdmi_end = 0ULL;
          }  
        }
        it->second->m_perm = perm;
      }
    }
    else {
      if (m_mem_cfg.count(area) == 0) {
        re_printf("error", "%s failed. argument of area name is unfound.\n", func_name);
        return false;
      }
      gm_area_config *area_cfg = m_mem_cfg[area];
      for (std::map<unsigned int, gm_block_config*>::const_iterator it1 = area_cfg->m_blocks.begin(); it1 != area_cfg->m_blocks.end(); it1++) {
        if (it1->second->m_tdmi_end != 0ULL) {
          for (unsigned int i = 0; i < MEM_N; i++) {
            m_mem_tgt.tgt_reset_dmi(i, it1->second->m_tdmi_beg, it1->second->m_tdmi_end);
          }
          it1->second->m_tdmi_beg = 0ULL;
          it1->second->m_tdmi_end = 0ULL;
        }  
      }
      m_mem_cfg[area]->m_perm = perm;
    }
    re_printf("info", "%s succeeded.\n", func_name);
    return true;
  }

  bool SetAreaWait(const std::string &area, const sc_time &read_wait, const sc_time &write_wait)
  {
    char func_name[256] = "";
    sprintf(func_name, "SetAreaWait(%s, %s, %s)", area.c_str(), read_wait.to_string().c_str(), write_wait.to_string().c_str());
    if (area == "") {
      if (m_mem_cfg.size() == 0) {
        re_printf("warning", "%s was no point. there are no area configuration.\n", func_name);
        return false;
      }
      for (gm_memory_config::const_iterator it = m_mem_cfg.begin(); it != m_mem_cfg.end(); it++) {
        gm_area_config *area_cfg = it->second;
        for (std::map<unsigned int, gm_block_config*>::const_iterator it1 = area_cfg->m_blocks.begin(); it1 != area_cfg->m_blocks.end(); it1++) {
          if (it1->second->m_tdmi_end != 0ULL) {
            for (unsigned int i = 0; i < MEM_N; i++) {
              m_mem_tgt.tgt_reset_dmi(i, it1->second->m_tdmi_beg, it1->second->m_tdmi_end);
            }
            it1->second->m_tdmi_beg = 0ULL;
            it1->second->m_tdmi_end = 0ULL;
          }  
        }
        it->second->m_read_wait = read_wait;
        it->second->m_write_wait = write_wait;
      }
    }
    else {
      if (m_mem_cfg.count(area) == 0) {
        re_printf("error", "%s failed. argument of area name is unfound.\n", func_name);
        return false;
      }
      gm_area_config *area_cfg = m_mem_cfg[area];
      for (std::map<unsigned int, gm_block_config*>::const_iterator it1 = area_cfg->m_blocks.begin(); it1 != area_cfg->m_blocks.end(); it1++) {
        if (it1->second->m_tdmi_end != 0ULL) {
          for (unsigned int i = 0; i < MEM_N; i++) {
            m_mem_tgt.tgt_reset_dmi(i, it1->second->m_tdmi_beg, it1->second->m_tdmi_end);
          }
          it1->second->m_tdmi_beg = 0ULL;
          it1->second->m_tdmi_end = 0ULL;
        }  
      }
      m_mem_cfg[area]->m_read_wait = read_wait;
      m_mem_cfg[area]->m_write_wait = write_wait;
    }
    re_printf("info", "%s succeeded.\n", func_name);
    return true;
  }

  std::string GetAreaName(sc_dt::uint64 addr)
  {
    const sc_dt::uint64 taddr = addr & (0xFFFFFFFFFFFFFFFFULL >> (64 - m_address_width));
    for (gm_memory_config::const_iterator it = m_mem_cfg.begin(); it != m_mem_cfg.end(); it++) {
      if ((taddr >= it->second->m_offset) && (taddr < (it->second->m_offset + it->second->m_size))) {
        return it->first;
      }
    }
    return "";
  }

  unsigned int GetAreaName(std::vector<std::string> &area_names)
  {
    area_names.clear();
    for (gm_memory_config::const_iterator it = m_mem_cfg.begin(); it != m_mem_cfg.end(); it++) {
      area_names.push_back(it->first);
    }
    return area_names.size();
  }

  bool GetAreaRange(const std::string &area, sc_dt::uint64 &offset, sc_dt::uint64 &size)
  {
    if (m_mem_cfg.count(area) == 0) {
      re_printf("error", "GetAreaRange(%s, %s, %s) failed. argument of area name is unfound.\n", area.c_str(), "--", "--");
      return false;
    }
    offset = m_mem_cfg[area]->m_offset;
    size = m_mem_cfg[area]->m_size;
    return true;
  }

  bool GetAreaPermission(const std::string &area, gm_permission &perm)
  {
    if (m_mem_cfg.count(area) == 0) {
      re_printf("error", "GetAreaPermission(%s, %s) failed. argument of area name is unfound.\n", area.c_str(), "--");
      return false;
    }
    perm = m_mem_cfg[area]->m_perm;
    return true;
  }

  bool GetAreaWait(const std::string &area, sc_time &read_wait, sc_time &write_wait)
  {
    if (m_mem_cfg.count(area) == 0) {
      re_printf("error", "GetAreaWait(%s, %s, %s) failed. argument of area name is unfound.\n", area.c_str(), "--", "--");
      return false;
    }
    read_wait = m_mem_cfg[area]->m_read_wait;
    write_wait = m_mem_cfg[area]->m_write_wait;
    return true;
  }

  std::string ToString(gm_command cmd)
  {
    if (cmd == gm_COMMAND_NONE) {
      return "gm_COMMAND_NONE";
    }
    else if (cmd == gm_COMMAND_READ) {
      return "gm_COMMAND_READ";
    }
    else if (cmd == gm_COMMAND_WRITE) {
      return "gm_COMMAND_WRITE";
    }
    return "";
  }

  std::string ToString(gm_permission perm)
  {
    if (perm == gm_PERMISSION_NONE) {
      return "gm_PERMISSION_NONE";
    }
    else if (perm == gm_PERMISSION_READ) {
      return "gm_PERMISSION_READ";
    }
    else if (perm == gm_PERMISSION_WRITE) {
      return "gm_PERMISSION_WRITE";
    }
    else if (perm == gm_PERMISSION_READ_WRITE) {
      return "gm_PERMISSION_READ_WRITE";
    }
    return "";
  }

  bool ReadMemory(sc_dt::uint64 addr, unsigned char *p_data, unsigned int size, sc_time &wait)
  {
    char func_name[256] = "";
    sprintf(func_name, "ReadMemory(0x%08llX, %s, %d, %s)", addr, "--", size, "--");
    if (p_data == NULL) {
      re_printf("error", "%s failed. argument of data pointer is null.\n", func_name);
      return false;
    }
    const std::string area = GetAreaName(addr);
    if (area == "") {
      re_printf("error", "%s failed. argument of access address is out of bounds.\n", func_name);
      return false;
    }
    const sc_dt::uint64 taddr = addr & (0xFFFFFFFFFFFFFFFFULL >> (64 - m_address_width));
    gm_area_config *area_cfg = m_mem_cfg[area];
    if ((taddr + size) > (area_cfg->m_offset + area_cfg->m_size)) {
      re_printf("error", "%s failed. argument of access range is out of bounds.\n", func_name);
      return false;
    }
    if (GetAccessPermission(area, taddr - area_cfg->m_offset) & gm_PERMISSION_READ) {
      area_cfg->ReadArea(taddr - area_cfg->m_offset,size,p_data);
    }
    wait = GetAccessWait(gm_COMMAND_READ, area, m_prev_cmd, m_prev_area, sc_time_stamp() - m_prev_end);
    m_prev_cmd = gm_COMMAND_READ;
    m_prev_area = area;
    m_prev_end = sc_time_stamp() + wait;

    // Display a head of 4 byte data
    unsigned int pi_data = 0;
    memcpy(&pi_data, p_data, (size>4)? 4 : size);
    re_printf("debug", "ReadMemory(0x%08llX, 0x%08X, %d, %s) succeeded.\n", addr, pi_data, size, wait.to_string().c_str());
    return true;
  }

  bool WriteMemory(sc_dt::uint64 addr, const unsigned char *p_data, unsigned int size, sc_time &wait)
  {
    char func_name[256] = "";
    sprintf(func_name, "WriteMemory(0x%08llX, %s, %d, %s)", addr, "--", size, "--");
    if (p_data == NULL) {
      re_printf("error", "%s failed. argument of data pointer is null.\n", func_name);
      return false;
    }
    const std::string area = GetAreaName(addr);
    if (area == "") {
      re_printf("error", "%s failed. argument of access address is out of bounds.\n", func_name);
      return false;
    }
    const sc_dt::uint64 taddr = addr & (0xFFFFFFFFFFFFFFFFULL >> (64 - m_address_width));
    gm_area_config *area_cfg = m_mem_cfg[area];
    if ((taddr + size) > (area_cfg->m_offset + area_cfg->m_size)) {
      re_printf("error", "%s failed. argument of access range is out of bounds.\n", func_name);
      return false;
    }
    if (GetAccessPermission(area, taddr - area_cfg->m_offset) & gm_PERMISSION_WRITE) {
      area_cfg->WriteArea(taddr - area_cfg->m_offset,size,p_data);
    }
    wait = GetAccessWait(gm_COMMAND_WRITE, area, m_prev_cmd, m_prev_area, sc_time_stamp() - m_prev_end);
    m_prev_cmd = gm_COMMAND_WRITE;
    m_prev_area = area;
    m_prev_end = sc_time_stamp() + wait;

    // Display a head of 4 byte data
    unsigned int pi_data = 0;
    memcpy(&pi_data, p_data, (size>4)? 4 : size);
    re_printf("debug", "WriteMemory(0x%08llX, 0x%08X, %d, %s) succeeded.\n", addr, pi_data, size, wait.to_string().c_str());
    return true;
  }

  bool DebugReadMemory(sc_dt::uint64 addr, unsigned char *p_data, unsigned int size)
  {
    if (p_data == NULL) {
      re_printf("error", "DebugReadMemory(0x%08llX, %s, %d, %s) failed. argument of data pointer is null.\n", addr, "--", size, "--");
      return false;
    }
    const std::string area = GetAreaName(addr);
    if (area == "") {
      return false;
    }
    const sc_dt::uint64 taddr = addr & (0xFFFFFFFFFFFFFFFFULL >> (64 - m_address_width));
    gm_area_config *area_cfg = m_mem_cfg[area];
    if ((taddr + size) > (area_cfg->m_offset + area_cfg->m_size)) {
      return false;
    }
    area_cfg->ReadArea(taddr - area_cfg->m_offset,size,p_data);
    return true;
  }

  bool DebugWriteMemory(sc_dt::uint64 addr, const unsigned char *p_data, unsigned int size)
  {
    if (p_data == NULL) {
      re_printf("error", "DebugWriteMemory(0x%08llX, %s, %d, %s) failed. argument of data pointer is null.\n", addr, "--", size, "--");
      return false;
    }
    const std::string area = GetAreaName(addr);
    if (area == "") {
      return false;
    }
    const sc_dt::uint64 taddr = addr & (0xFFFFFFFFFFFFFFFFULL >> (64 - m_address_width));
    gm_area_config *area_cfg = m_mem_cfg[area];
    if ((taddr + size) > (area_cfg->m_offset + area_cfg->m_size)) {
      return false;
    }
    area_cfg->WriteArea(taddr - area_cfg->m_offset,size,p_data);
    return true;
  }
  
  bool GetDmiMemory(tlm::tlm_generic_payload &trans, tlm::tlm_dmi &dmi_data)
  {
    char func_name[256] = "";
    std::string command = "TLM_IGNORE_COMMAND";
    if (trans.is_read()) {
      command = "TLM_READ_COMMAND";
    }
    else if (trans.is_write()) {
      command = "TLM_WRITE_COMMAND";
    }
    sprintf(func_name, "GetDmiMemory({%s, 0x%08llX, ...}, %s)", command.c_str(), trans.get_address(), "--");
    const std::string area = GetAreaName(trans.get_address());
    if (area == "") {
      re_printf("error", "%s failed. argument of access address is out of bounds.\n", func_name);
      dmi_data.allow_none();
      return false;
    }
    gm_area_config *area_cfg = m_mem_cfg[area];
    unsigned int offset = trans.get_address() - area_cfg->m_offset;
    unsigned int block_start = area_cfg->m_offset + (offset/area_cfg->m_block_size)*area_cfg->m_block_size; 
    unsigned int block_index = offset/area_cfg->m_block_size;
    unsigned int block_offset = offset%area_cfg->m_block_size;

    if (! area_cfg->m_dmi_enable) { 
      re_printf("info", "%s was not accepted. dmi is disabled in this area.\n", func_name);
      dmi_data.allow_none();
      dmi_data.set_dmi_ptr(NULL);
      dmi_data.set_start_address((trans.get_address() & (0xFFFFFFFFFFFFFFFFULL << m_address_width)) | area_cfg->m_offset);
      dmi_data.set_end_address((trans.get_address() & (0xFFFFFFFFFFFFFFFFULL << m_address_width)) | (area_cfg->m_offset + area_cfg->m_size) - 1);
      return false;
    }
    else {
      if (area_cfg->m_blocks.find(block_index) == area_cfg->m_blocks.end()) { // for unallocated block 
        area_cfg->AllocateMemoryBlock(block_index, block_offset, 1);
        dmi_data.set_granted_access((tlm::tlm_dmi::dmi_access_e) area_cfg->m_perm);
      }
      else {
        dmi_data.set_granted_access((tlm::tlm_dmi::dmi_access_e) area_cfg->m_perm);
      }
    }
    dmi_data.set_dmi_ptr(NULL);
    dmi_data.set_start_address((trans.get_address() & (0xFFFFFFFFFFFFFFFFULL << m_address_width)) | block_start);
    dmi_data.set_end_address((trans.get_address() & (0xFFFFFFFFFFFFFFFFULL << m_address_width)) | (block_start + area_cfg->m_blocks[block_index]->m_size) - 1);
    dmi_data.set_read_latency(area_cfg->m_read_wait);
    dmi_data.set_write_latency(area_cfg->m_write_wait);
    if (trans.is_read()) {
      if (! dmi_data.is_read_allowed()) {
        return false;
      }
    }
    else if (trans.is_write()) {
      if (! dmi_data.is_write_allowed()) {
        return false;
      }
    }
    else {
      return false;
    }
#ifdef CWR_SYSTEMC
    tlm::tlm_generic_payload tmp_trans;
    unsigned char tmp_data = 0;
    tmp_trans.set_read();
    tmp_trans.set_address(((trans.get_address() & (0xFFFFFFFFFFFFFFFFULL >> (64 - m_address_width))) - area_cfg->m_offset)%area_cfg->m_block_size);
    tmp_trans.set_data_ptr(&tmp_data);
    tmp_trans.set_data_length(1);
    tmp_trans.set_streaming_width(1);
    tlm::tlm_dmi tmp_dmi_data;
    if (area_cfg->m_blocks[block_index]->m_data->get_direct_mem_ptr(tmp_trans, tmp_dmi_data)) {
      dmi_data.set_dmi_ptr(tmp_dmi_data.get_dmi_ptr());
    }
    else {
      re_printf("warning", "%s was not accepted. dmi is enabeled in this area, but scml memory did not allowed.\n", func_name);
      dmi_data.allow_none();
      return false;
    }
#else
    dmi_data.set_dmi_ptr(area_cfg->m_blocks[block_index]->m_data);
#endif
    m_mem_cfg[area]->m_tdmi_beg = dmi_data.get_start_address();
    m_mem_cfg[area]->m_tdmi_end = dmi_data.get_end_address();
    m_mem_cfg[area]->m_blocks[block_index]->m_tdmi_beg = dmi_data.get_start_address();
    m_mem_cfg[area]->m_blocks[block_index]->m_tdmi_end = dmi_data.get_end_address();
    re_printf("info", "%s succeeded. dmi allowed range is 0x%08llX-0x%08llX.\n", func_name, dmi_data.get_start_address(), dmi_data.get_end_address());
    return true;
  }
  virtual void tgt_acc_cb(unsigned int id, tlm::tlm_generic_payload &trans, sc_time &t) {;}

private:
  virtual gm_permission GetAccessPermission(const std::string &area, sc_dt::uint64 area_addr)
  {
    if (m_mem_cfg.count(area) == 0) {
      re_printf("error", "GetAccessPermission(%s, 0x%08llX) failed. argument of area name is unfound.\n", area.c_str(), area_addr);
      return gm::gm_PERMISSION_NONE;
    }
    else {
      return m_mem_cfg[area]->m_perm;
    }
  }

  virtual sc_time GetAccessWait(gm_command cmd, const std::string &area,
    gm_command prev_cmd, const std::string &prev_area, const sc_time &wait_margin)
  {
    if (m_mem_cfg.count(area) == 0) {
      re_printf("error", "GetAccessWait(%s, %s, %s, %s, %s) failed. argument of area name is unfound.\n",
        ToString(cmd).c_str(), area.c_str(), ToString(prev_cmd).c_str(), prev_area.c_str(), wait_margin.to_string().c_str());
      return SC_ZERO_TIME;
    }
    else {
      return (cmd & gm_COMMAND_READ) ? m_mem_cfg[area]->m_read_wait : m_mem_cfg[area]->m_write_wait;
    }
  }

  virtual void reg_acc(unsigned int id, tlm::tlm_generic_payload &trans, sc_time &t) = 0;
  virtual unsigned int reg_acc_dbg(unsigned int id, tlm::tlm_generic_payload &trans) = 0;
  
  std::string CommandCB(const std::vector<std::string>& args)
  {
    std::vector<std::string> _args = args;
    if (args[0] == "command") {
      _args.erase(_args.begin());
    }
    if((_args[0] == "AreaBlockSize") && (_args.size() == 2)) {
      if(AreaBlockSize < emDefaultBlockSize) { 
        re_printf("error", "Setting value %d to AreaBlockSize is illegal. Setting value should be equal or greater than 1048576 (1MB).\n", AreaBlockSize);
        AreaBlockSize = m_prev_block_size;
      }
      if((AreaBlockSize & (AreaBlockSize -1)) != 0x0) {
        re_printf("error", "Setting value %d to AreaBlockSize is illegal. Setting value should be power of 2.\n", AreaBlockSize);
        AreaBlockSize = m_prev_block_size;
      }
    }
    return "";
  }

public:
  std::string reg_tgt_handle_command(const std::vector<std::string> &args)
  {
    std::vector<std::string> targs = args;
    targs.insert(targs.begin(), "tgt");
    return m_reg_tgt.tgt_handle_command(targs);
  }

  std::string mem_tgt_handle_command(const std::vector<std::string> &args)
  {
    std::vector<std::string> targs = args;
    targs.insert(targs.begin(), "tgt");
    return m_mem_tgt.tgt_handle_command(targs);
  }
};

template <unsigned int REG_BUSWIDTH, unsigned int REG_N, unsigned int MEM_BUSWIDTH, unsigned int MEM_N>
class gm_register_tgt : public vpcl::tlm_tgt_if<REG_BUSWIDTH, tlm::tlm_base_protocol_types, REG_N>
{
  Cgeneral_memory<REG_BUSWIDTH, REG_N, MEM_BUSWIDTH, MEM_N> *m_gm_ptr;

public:
  gm_register_tgt(const char *name, Cgeneral_memory<REG_BUSWIDTH, REG_N, MEM_BUSWIDTH, MEM_N> *gm_ptr)
    : vpcl::tlm_tgt_if<REG_BUSWIDTH, tlm::tlm_base_protocol_types, REG_N>(name)
    , m_gm_ptr(gm_ptr)
  {
  }

  virtual ~gm_register_tgt()
  {
  }

  bool tgt_get_gp_attribute(tlm::tlm_command &command, sc_dt::uint64 &address, unsigned char *&data_ptr, unsigned int &data_length, const tlm::tlm_generic_payload &trans, bool is_debug = false) const
  {
    return this->vpcl::tlm_tgt_if<REG_BUSWIDTH, tlm::tlm_base_protocol_types, REG_N>::
      tgt_get_gp_attribute(command, address, data_ptr, data_length, trans, is_debug);
  }

  void tgt_resp_tx(unsigned int id, tlm::tlm_generic_payload &trans)
  {
    this->vpcl::tlm_tgt_if<REG_BUSWIDTH, tlm::tlm_base_protocol_types, REG_N>::
      tgt_resp_tx(id, trans);
  }

  void tgt_reset_dmi(unsigned int id, sc_dt::uint64 start_range, sc_dt::uint64 end_range)
  {
    this->vpcl::tlm_tgt_if<REG_BUSWIDTH, tlm::tlm_base_protocol_types, REG_N>::
      tgt_reset_dmi(id, start_range, end_range);
  }

private:
  void tgt_acc(unsigned int id, tlm::tlm_generic_payload &trans, sc_time &t)
  {
    m_gm_ptr->reg_acc(id, trans, t);
  }

  unsigned int tgt_acc_dbg(unsigned int id, tlm::tlm_generic_payload &trans)
  {
    return m_gm_ptr->reg_acc_dbg(id, trans);
  }

  bool tgt_get_dmi(unsigned int id, tlm::tlm_generic_payload &trans, tlm::tlm_dmi &dmi_data)
  {
    std::string command = "TLM_IGNORE_COMMAND";
    if (trans.is_read()) {
      command = "TLM_READ_COMMAND";
    }
    else if (trans.is_write()) {
      command = "TLM_WRITE_COMMAND";
    }
    m_gm_ptr->get_fileline(__FILE__, __LINE__);
    m_gm_ptr->_re_printf("info", "gm_register_tgt::tgt_get_dmi(%d, {%s, 0x%08llX, ...}, %s) was not accepted. dmi is disabled in register area.\n", id, command.c_str(), trans.get_address(), "--");
    dmi_data.allow_none();
    return false;
  }
};

template <unsigned int REG_BUSWIDTH, unsigned int REG_N, unsigned int MEM_BUSWIDTH, unsigned int MEM_N>
class gm_memory_tgt : public vpcl::tlm_tgt_if<MEM_BUSWIDTH, tlm::tlm_base_protocol_types, MEM_N>
{
  Cgeneral_memory<REG_BUSWIDTH, REG_N, MEM_BUSWIDTH, MEM_N> *m_gm_ptr;

public:
  gm_memory_tgt(const char *name, Cgeneral_memory<REG_BUSWIDTH, REG_N, MEM_BUSWIDTH, MEM_N> *gm_ptr)
    : vpcl::tlm_tgt_if<MEM_BUSWIDTH, tlm::tlm_base_protocol_types, MEM_N>(name)
    , m_gm_ptr(gm_ptr)
  {
  }

  virtual ~gm_memory_tgt()
  {
  }

  bool tgt_get_gp_attribute(tlm::tlm_command &command, sc_dt::uint64 &address, unsigned char *&data_ptr, unsigned int &data_length, const tlm::tlm_generic_payload &trans, bool is_debug = false) const
  {
    return this->vpcl::tlm_tgt_if<MEM_BUSWIDTH, tlm::tlm_base_protocol_types, MEM_N>::
      tgt_get_gp_attribute(command, address, data_ptr, data_length, trans, is_debug);
  }

  void tgt_resp_tx(unsigned int id, tlm::tlm_generic_payload &trans)
  {
    this->vpcl::tlm_tgt_if<MEM_BUSWIDTH, tlm::tlm_base_protocol_types, MEM_N>::
      tgt_resp_tx(id, trans);
  }

  void tgt_reset_dmi(unsigned int id, sc_dt::uint64 start_range, sc_dt::uint64 end_range)
  {
    this->vpcl::tlm_tgt_if<MEM_BUSWIDTH, tlm::tlm_base_protocol_types, MEM_N>::
      tgt_reset_dmi(id, start_range, end_range);
  }

private:
  void tgt_acc(unsigned int id, tlm::tlm_generic_payload &trans, sc_time &t)
  {
    tlm::tlm_command command = tlm::TLM_IGNORE_COMMAND;
    sc_dt::uint64 address = 0ULL;
    unsigned char *data_ptr = NULL;
    unsigned int data_length = 0;
    bool status = false;
    status = this->vpcl::tlm_tgt_if<MEM_BUSWIDTH, tlm::tlm_base_protocol_types, MEM_N>::
      tgt_get_gp_attribute(command, address, data_ptr, data_length, trans);
    if (! status) {
      trans.set_response_status(tlm::TLM_BYTE_ENABLE_ERROR_RESPONSE);
      m_gm_ptr->get_fileline(__FILE__, __LINE__); 
      m_gm_ptr->_re_printf("error", "gm_memory_tgt::tgt_acc(%d, %s, %s) failed. discrete byte enable is unsupported.\n", id, "--", t.to_string().c_str());
      return;
    }
    m_gm_ptr->tgt_acc_cb(id,trans,t);
    if (command == tlm::TLM_READ_COMMAND) {
      status = m_gm_ptr->ReadMemory(address, data_ptr, data_length, t);
    }
    else if (command == tlm::TLM_WRITE_COMMAND) {
      status = m_gm_ptr->WriteMemory(address, data_ptr, data_length, t);
    }
    else {
      status = true;
    }
    trans.set_response_status(status ? tlm::TLM_OK_RESPONSE : tlm::TLM_GENERIC_ERROR_RESPONSE);
  }

  unsigned int tgt_acc_dbg(unsigned int id, tlm::tlm_generic_payload &trans)
  {
    tlm::tlm_command command = tlm::TLM_IGNORE_COMMAND;
    sc_dt::uint64 address = 0ULL;
    unsigned char *data_ptr = NULL;
    unsigned int data_length = 0;
    bool status = false;
    this->vpcl::tlm_tgt_if<MEM_BUSWIDTH, tlm::tlm_base_protocol_types, MEM_N>::
      tgt_get_gp_attribute(command, address, data_ptr, data_length, trans, true);
    if (command == tlm::TLM_READ_COMMAND) {
      status = m_gm_ptr->DebugReadMemory(address, data_ptr, data_length);
    }
    else if (command == tlm::TLM_WRITE_COMMAND) {
      status = m_gm_ptr->DebugWriteMemory(address, data_ptr, data_length);
    }
    else {
      data_length = 0;
      status = true;
    }
    trans.set_response_status(status ? tlm::TLM_OK_RESPONSE : tlm::TLM_GENERIC_ERROR_RESPONSE);
    return status ? data_length : 0;
  }

  bool tgt_get_dmi(unsigned int id, tlm::tlm_generic_payload &trans, tlm::tlm_dmi &dmi_data)
  {
    return m_gm_ptr->GetDmiMemory(trans, dmi_data);
  }
};
}

#endif
