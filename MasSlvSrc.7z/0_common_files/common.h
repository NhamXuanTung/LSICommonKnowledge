#include "machine.h"
#include "regdef.h"
#include "iodefine_clk_gen.h"
// #include "ECM_drv.h"
// #include "CONTROL_drv.h"
//FOR INTC
#include "intc_handler.h"
#include "set_int_factor.h"

#define SC_NS   0
#define SC_US   1

// define macro for timing

// ****************************************
// initial setting
// ****************************************
void cpu_setup()
{
  // set status register
  set_cr (0x400010A0);
  set_vbr (( void *) 0x0C500000);

  // Cache ON
  //*(unsigned int *)(0xFF00001C) = 0x00010107;
}

void delay (unsigned int period) {
    ICLK.WAITNS.LONG = period;
    for(int i=0; i < 1; i++);
}

void idle (unsigned int period) {
    *CTRL_REG_CPUSTOP = period;
    delay (1);
}
void wait (unsigned int period, unsigned int tu = SC_US)
{
    delay(period);
}

// ****************************************
// for debug
// ****************************************
#pragma section _PASS
void pass_bp()
{
  while(1);
}
#pragma section


#pragma section _FAIL
void fail_bp()
{
  while(1);
}
#pragma section


#pragma section _REST
void rest_bp()
{
  for( int i=0 ; i<10 ; i++ );
}
#pragma section

