// $Id: set_int_factor.cpp,v 1.1.1.1 2013/05/13 13:41:24 trongtruong Exp $
// Note: this file is not used for SH-NaviJ/INTC project
/****************************************************************************
*
*                        RVC confidential
*
*   (C) Copyright by Renesas Viet Nam Company, Ltd., 2008 All Rights Reserved.
*
***************************************************************************/
#include "set_int_factor.h"
#include "regdef.h"
//#pragma section _SET_INT_FACTOR
void set_int_factor(mod_name mname, int_name iname, int mask, int prio)
{
//        prio = prio&0xF;
//        switch(mname)
//        {
//           case TMU:
//           switch(iname)
//           {
//                case TUNI0:
//                   *INT2PRI0 |= (prio<<16);
//                   if (mask) *INT2MSKRG |= 0x02;
//                   else      *INT2MSKCR|= 0x02;
//                   break;
//                case TUNI1:
//                   *INT2PRI0 |= (prio<<8);
//                   if (mask) *INT2MSKRG |= 0x02;
//                   else      *INT2MSKCR|= 0x02;
//                   break;
//                case TUNI2:
//                   *INT2PRI0 |= (prio);
//                   if (mask) *INT2MSKRG |= 0x02;
//                   else      *INT2MSKCR|= 0x02;
//                   break;
//                case TUNI5:
//                case TUNI4:
//                case TUNI3:
//                   *INT2PRI1 |= (prio<<24);
//                   if (mask) *INT2MSKRG |= 0x04;
//                   else      *INT2MSKCR|= 0x04;
//                   break;
//                case TUNI8:
//                case TUNI7:
//                case TUNI6:
//                   *INT2PRI1 |= (prio<<16);
//                   if (mask) *INT2MSKRG |= 0x04;
//                   else      *INT2MSKCR|= 0x04;
//                   break;
//           }
//           break;
//        }
}
