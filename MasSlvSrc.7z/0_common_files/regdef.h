/*****************************************************************************
 *	Modules Register 
 *	Copyright(C) 2008/07/03 Renesas Viet Nam Co.,Ltd
 *****************************************************************************/

#ifndef __REGDEF__
#define __REGDEF__

#define INTERRUPT_ECMTI     ((volatile unsigned long*)0x0C700300)
#define INTERRUPT_ECMTNMI   ((volatile unsigned long*)0x0C700304)
#define CTRL_REG_CPUSTOP    ((volatile unsigned long*)0xFFF80064)

#define ICLK                    (*(volatile struct st_clk_gen *) 0xFFFFB000)
//-------------For check Interrupt--------//
#define INT_flag_base     0x0C600000
#define INT_DU_DU	       ((volatile unsigned long*) (INT_flag_base + 0x2004))
#define INT_TMU_TMU00	       ((volatile unsigned long*) (INT_flag_base + 0x2008))
#define INT_TMU_TMU10	       ((volatile unsigned long*) (INT_flag_base + 0x200C))
#define INT_TMU_TMU20	       ((volatile unsigned long*) (INT_flag_base + 0x2000))
#define INT_TMU_TMU21	       ((volatile unsigned long*) (INT_flag_base + 0x2014))
#define INT_TMU_TMU30	       ((volatile unsigned long*) (INT_flag_base + 0x2018))
#define INT_TMU_TMU40	       ((volatile unsigned long*) (INT_flag_base + 0x201C))
#define INT_TMU_TMU50	       ((volatile unsigned long*) (INT_flag_base + 0x2010))
#define INT_TMU_TMU51	       ((volatile unsigned long*) (INT_flag_base + 0x2024))
#define INT_TMU_TMU60	       ((volatile unsigned long*) (INT_flag_base + 0x2028))
#define INT_TMU_TMU70	       ((volatile unsigned long*) (INT_flag_base + 0x202C))
#define INT_TMU_TMU80	       ((volatile unsigned long*) (INT_flag_base + 0x2020))
#define INT_WDT_RESET	       ((volatile unsigned long*) (INT_flag_base + 0x2034))
#define INT_USB2_USB2	       ((volatile unsigned long*) (INT_flag_base + 0x2038))
#define INT_SIU2_SIU2	       ((volatile unsigned long*) (INT_flag_base + 0x203C))
#define INT_FM_DARC	       ((volatile unsigned long*) (INT_flag_base + 0x2030))
#define INT_DEBUG_HUDI	       ((volatile unsigned long*) (INT_flag_base + 0x2044))
#define INT_SHWY_DMAC01	       ((volatile unsigned long*) (INT_flag_base + 0x2048))
#define INT_TSIF_TSIF	       ((volatile unsigned long*) (INT_flag_base + 0x204C))
#define INT_REMOCON_REMOCON    ((volatile unsigned long*) (INT_flag_base + 0x2040))
#define INT_SSI_SSI0	       ((volatile unsigned long*) (INT_flag_base + 0x2054))
#define INT_SSI_SSI1	       ((volatile unsigned long*) (INT_flag_base + 0x2058))
#define INT_SSI_SSI2	       ((volatile unsigned long*) (INT_flag_base + 0x205C))
#define INT_SSI_SSI3	       ((volatile unsigned long*) (INT_flag_base + 0x2050))
#define INT_VIN_VIN	       ((volatile unsigned long*) (INT_flag_base + 0x2064))
#define INT_RGP1_RGP1	       ((volatile unsigned long*) (INT_flag_base + 0x2068))
#define INT_HSPI_HSPI	       ((volatile unsigned long*) (INT_flag_base + 0x206C))
#define INT_LSBC_ATA	       ((volatile unsigned long*) (INT_flag_base + 0x2060))
#define INT_I2C_I2C0	       ((volatile unsigned long*) (INT_flag_base + 0x2074))
#define INT_RCAN_RCAN	       ((volatile unsigned long*) (INT_flag_base + 0x2078))
#define INT_TAB_II	       ((volatile unsigned long*) (INT_flag_base + 0x20BC))
#define INT_SDIF_SDIF	       ((volatile unsigned long*) (INT_flag_base + 0x20B0))
#define INT_IE_BUS	       ((volatile unsigned long*) (INT_flag_base + 0x20C4))
#define INT_HPB_DMAC0	       ((volatile unsigned long*) (INT_flag_base + 0x20C8))
#define INT_HPB_DMAC1	       ((volatile unsigned long*) (INT_flag_base + 0x20CC))
#define INT_HPB_DMAC2	       ((volatile unsigned long*) (INT_flag_base + 0x20C0))
#define INT_HPB_DMAC3	       ((volatile unsigned long*) (INT_flag_base + 0x20D4))
#define INT_HPB_DMAC4	       ((volatile unsigned long*) (INT_flag_base + 0x20D8))
#define INT_HPB_DMAC5	       ((volatile unsigned long*) (INT_flag_base + 0x20DC))
#define INT_HPB_DMAC6	       ((volatile unsigned long*) (INT_flag_base + 0x20D0))
#define INT_HPB_DMAC7	       ((volatile unsigned long*) (INT_flag_base + 0x20E4))
#define INT_HPB_DMAC8	       ((volatile unsigned long*) (INT_flag_base + 0x20E8))
#define INT_HPB_DMAC9	       ((volatile unsigned long*) (INT_flag_base + 0x20EC))
#define INT_HPB_DMAC10	       ((volatile unsigned long*) (INT_flag_base + 0x20E0))
#define INT_HPB_DMAC11	       ((volatile unsigned long*) (INT_flag_base + 0x20F4))
#define INT_GPIO_GPIO0	       ((volatile unsigned long*) (INT_flag_base + 0x20F8))
#define INT_GPIO_GPIO1	       ((volatile unsigned long*) (INT_flag_base + 0x20FC))
#define INT_GPIO_GPIO2	       ((volatile unsigned long*) (INT_flag_base + 0x20F0))
#define INT_GPIO_GPIO3	       ((volatile unsigned long*) (INT_flag_base + 0x2104))
#define INT_GPS_GPS	       ((volatile unsigned long*) (INT_flag_base + 0x210C))

#endif
