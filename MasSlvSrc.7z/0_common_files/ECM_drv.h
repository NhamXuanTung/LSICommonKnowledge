// ---------------------------------------------------------------------
// $Id: ECM_drv.h,v 1.3 2013/05/13 13:48:12 trongtruong Exp $
//
// Copyright(c) 2012 Renesas Electronics Corporation
// Copyright(c) 2012 Renesas Design Vietnam Co., Ltd.
// RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
// This program must be used solely for the purpose for which
// it was furnished by Renesas Electronics Corporation. No part of this
// program may be reproduced or disclosed to others, in any
// form, without the prior written permission of Renesas Electronics
// Corporation.
// ---------------------------------------------------------------------

#ifndef __ECM_DRV__
#define __ECM_DRV__
#include "iodefine_ecm_e2.h" 

#define ECM_M     (*(volatile struct st_ecm *)       0xFFCB0000)
#define ECM_C     (*(volatile struct st_ecm *)       0xFFCB1000)
#define ECMCommon (*(volatile struct st_ecm_common *)0xFFCB2000)

void DisableAllOutputPortConfiguration()
{//{{{//{{{
    ECMCommon.ECMEMK9.BIT.ECMEMK928 = 1;
    ECMCommon.ECMMICFG9.BIT.ECMMIE928 = 1;
    ECMCommon.ECMNMICFG9.BIT.ECMNMIE928 = 1;
    ECMCommon.ECMIRCFG9.BIT.ECMIRE928 = 1;

}//}}}//}}}

void WriteProtectionCommand(unsigned int value)
{//{{{
    ECMCommon.ECMKCPROT.LONG = value;
}//}}}

void UnlockWriteProtect()
{//{{{
    ECMCommon.ECMKCPROT.LONG = 0xA5A5A501;
}//}}}
void LockWriteProtect() 
{//{{{
    ECMCommon.ECMKCPROT.LONG = 0xA5A5A500;
}//}}}

unsigned int GetWriteProtectionStatus(void)
{//{{{
    return ECMCommon.ECMKCPROT.LONG;
}//}}}

void SetFactorBit(unsigned char* reg_pointer, unsigned int factor, unsigned int value)
{//{{{
    unsigned int pos;
    volatile unsigned char* reg_p;
    if (factor <=3){//from error factor 0 to 3
        reg_p = reg_pointer;
    }else if (factor <=7){// 4 to 7
        reg_p = reg_pointer + 1;
    }else if (factor <=15){
        reg_p = reg_pointer + 2;
    }else if (factor <=23){
        reg_p = reg_pointer + 3;
    }else{
        unsigned int temp = (factor - 24)%32;
        reg_p = reg_pointer + temp/8;
    }

    unsigned char temp_val  = 0;
    unsigned char reg_val  = (*reg_p);
    unsigned char reverse_reg_val  = ~(reg_val);
    unsigned char mask = 0;
    
    if (factor <= 7){
        pos = (factor % 4)*2;
        mask = 3 << pos;
    }else{
        pos = factor % 8;
        mask = 1 << pos;
    }

    UnlockWriteProtect();
    temp_val = ~(reverse_reg_val | mask);
    temp_val = (temp_val | (value << pos));
    *reg_p = temp_val;
    LockWriteProtect();
}//}}}

void ClearFactorBit(unsigned char* reg_pointer, unsigned int factor)
{//{{{
    unsigned int pos;
    volatile unsigned char* reg_p;
    if (factor <=3){//from error factor 0 to 3
        reg_p = reg_pointer;
    }else if (factor <=7){// 4 to 7
        reg_p = reg_pointer + 1;
    }else if (factor <=15){
        reg_p = reg_pointer + 2;
    }else if (factor <=23){
        reg_p = reg_pointer + 3;
    }else{
        unsigned int temp = (factor - 24)%32;
        reg_p = reg_pointer + temp/8;
    }

    unsigned char reg_val  = ~(*reg_p);
    unsigned char mask = 1 << ((factor-1) % 8);

    if (factor <= 7){
        pos = (factor % 4)*2;
        mask = 3 << pos;
    }else{
        pos = factor % 8;
        mask = 1 << pos;
    }

    UnlockWriteProtect();
    *reg_p = ~(reg_val|mask);
    LockWriteProtect();
}//}}}

unsigned int GetFactorBit(unsigned char* reg_pointer, unsigned int factor)
{//{{{
    unsigned int pos;
    volatile unsigned char* reg_p;
    if (factor <=3){//from error factor 0 to 3
        reg_p = reg_pointer;
    }else if (factor <=7){// 4 to 7
        reg_p = reg_pointer + 1;
    }else if (factor <=15){
        reg_p = reg_pointer + 2;
    }else if (factor <=23){
        reg_p = reg_pointer + 3;
    }else{
        unsigned int temp = (factor - 24)%32;
        reg_p = reg_pointer + temp/8;
    }

    unsigned char reg_val  = *reg_p;

    if (factor <= 7){
        pos = (factor % 4)*2;
    }else{
        pos = factor % 8;
    }

    return ((reg_val >> pos) & 0x1);
}//}}}

void SetFactorBitLong(unsigned int* reg_pointer, unsigned int factor, unsigned int value)
{//{{{
    unsigned int mask;
    unsigned int pos;
    volatile unsigned int reg_val  = *reg_pointer;
    unsigned int reverse_reg_val = ~reg_val;
    unsigned int temp_val = 0;
    UnlockWriteProtect();

    if (factor <= 7){
        pos = (factor)*2;
        mask = 3 << pos;
    }else{
        pos = (factor + 8) % 32;
        mask = 1 << pos;
    }

    temp_val = ~(reverse_reg_val | mask);
    temp_val = (temp_val| (value << pos));
    *reg_pointer = temp_val;
    LockWriteProtect();
}//}}}

void ClearFactorBitLong(unsigned int* reg_pointer, unsigned int factor)
{//{{{
    unsigned int mask;
    unsigned int pos;
    volatile unsigned int reg_val  = ~(*reg_pointer);
    UnlockWriteProtect();
    if (factor <= 7){
        pos = (factor)*2;
        mask = 3 << pos;
    }else{
        pos = (factor + 8) % 32;
        mask = 1 << pos;
    }
//    if (factor <= 7){/XXX
//        pos = (factor % 4)*2;
//        mask = 3 << pos;
//    }else{
//        pos = factor % 8;
//        mask = 1 << pos;
//    }
    *reg_pointer = ~(reg_val|mask);
    LockWriteProtect();

}//}}}

void ErrorSetTrigger(unsigned int target)
{//{{{
    UnlockWriteProtect();
    if (target == 0) {
        ECM_M.ECMmESET.BYTE = 0x01;
    } else {
        ECM_C.ECMmESET.BYTE = 0x01;
    }
    LockWriteProtect();
}//}}}

void ErrorSetTrigger(unsigned int target, unsigned int value)
{//{{{
    if (target == 0) {
        WriteProtectionCommand(0xA5A5A501);
        ECM_M.ECMmESET.BYTE = value;
    } else {
        WriteProtectionCommand(0xA5A5A501);
        ECM_C.ECMmESET.BYTE = value;
    }
}//}}}

void ErrorClearTrigger(unsigned int target, unsigned int value)
{//{{{
    if (target == 0) {
        WriteProtectionCommand(0xA5A5A501);
        ECM_M.ECMmECLR.BYTE = value;
    } else {
        WriteProtectionCommand(0xA5A5A501);
        ECM_C.ECMmECLR.BYTE = value;
    }
}//}}}

void SetDelayTimerControlRegister(unsigned int value)
{//{{{
    WriteProtectionCommand(0xA5A5A501);
    ECMCommon.ECMDTMCTL.BYTE = value;
}//}}}

void SetOperationMode(unsigned int value)
{//{{{
    WriteProtectionCommand(0xA5A5A501);
    ECMCommon.ECMEPCFG.BYTE = value;
}//}}}

void ErrorClearTrigger(unsigned int target)
{//{{{
    UnlockWriteProtect();
    if (target == 0) {
        ECM_M.ECMmECLR.BYTE = 0x01;
    } else {
        ECM_C.ECMmECLR.BYTE = 0x01;
    }
    LockWriteProtect();
}//}}}

unsigned int GetErrorClearTrigger(unsigned int target)
{//{{{
    if (target == 0) {
        return ECM_M.ECMmECLR.BIT.ECMmECT;
    } else {
        return ECM_C.ECMmECLR.BIT.ECMmECT;
    }
}//}}}

unsigned int GetErrorStatus(unsigned int target, unsigned int factor)
{//{{{
    if (target == 0) {
        if ((factor <= 7)){
            unsigned int reg = ECM_M.ECMmESSTR0.LONG;
            return ((reg >> (factor*2)  & 0x3));
        } else if ((8 <= factor) && (factor <= 23)){
            unsigned int reg = ECM_M.ECMmESSTR0.LONG;
            return ((reg >> (factor+8))  & 0x1);
        } else if ((24 <= factor) && (factor <= 55)){// reg 1
            unsigned int reg = ECM_M.ECMmESSTR1.LONG;
            return ((reg >> (factor -24))  & 0x1);
        } else if ((56 <= factor) && (factor <= 87)){// reg 2
            unsigned int reg = ECM_M.ECMmESSTR2.LONG;
            return ((reg >> (factor-56)) & 0x1);
        } else if ((88 <= factor) && (factor <= 119)){// reg 3
            unsigned int reg = ECM_M.ECMmESSTR3.LONG;
            return ((reg >> (factor-88)) & 0x1);
        } else if ((120 <= factor) && (factor <= 151)){// reg 4
            unsigned int reg = ECM_M.ECMmESSTR4.LONG;
            return ((reg >> (factor-120)) & 0x1);
        } else if ((152 <= factor) && (factor <= 183)){// reg 5
            unsigned int reg = ECM_M.ECMmESSTR5.LONG;
            return ((reg >> (factor-152)) & 0x1);
        } else if ((184 <= factor) && (factor <= 215)){// reg 6
            unsigned int reg = ECM_M.ECMmESSTR6.LONG;
            return ((reg >> (factor-184)) & 0x1);
        } else if ((216 <= factor) && (factor <= 247)){// reg 7
            unsigned int reg = ECM_M.ECMmESSTR7.LONG;
            return ((reg >> (factor-216)) & 0x1);
        } else if ((248 <= factor) && (factor <= 279)){// reg 8
            unsigned int reg = ECM_M.ECMmESSTR8.LONG;
            return ((reg >> (factor-248)) & 0x1);
        }else{
            unsigned int reg = ECM_M.ECMmESSTR9.LONG;
            return ((reg >> (factor-280)) & 0x1);
        }
    } else {
        if ((factor <= 7)){
            unsigned int reg = ECM_C.ECMmESSTR0.LONG;
            return ((reg >> (factor*2)  & 0x3));
        } else if ((8 <= factor) && (factor <= 23)){
            unsigned int reg = ECM_C.ECMmESSTR0.LONG;
            return ((reg >> (factor+8))  & 0x1);
        } else if ((24 <= factor) && (factor <= 55)){// reg 1
            unsigned int reg = ECM_C.ECMmESSTR1.LONG;
            return ((reg >> (factor -24))  & 0x1);
        } else if ((56 <= factor) && (factor <= 87)){// reg 2
            unsigned int reg = ECM_C.ECMmESSTR2.LONG;
            return ((reg >> (factor-56)) & 0x1);
        } else if ((88 <= factor) && (factor <= 119)){// reg 3
            unsigned int reg = ECM_C.ECMmESSTR3.LONG;
            return ((reg >> (factor-88)) & 0x1);
        } else if ((120 <= factor) && (factor <= 151)){// reg 4
            unsigned int reg = ECM_C.ECMmESSTR4.LONG;
            return ((reg >> (factor-120)) & 0x1);
        } else if ((152 <= factor) && (factor <= 183)){// reg 5
            unsigned int reg = ECM_C.ECMmESSTR5.LONG;
            return ((reg >> (factor-152)) & 0x1);
        } else if ((184 <= factor) && (factor <= 215)){// reg 6
            unsigned int reg = ECM_C.ECMmESSTR6.LONG;
            return ((reg >> (factor-184)) & 0x1);
        } else if ((216 <= factor) && (factor <= 247)){// reg 7
            unsigned int reg = ECM_C.ECMmESSTR7.LONG;
            return ((reg >> (factor-216)) & 0x1);
        } else if ((248 <= factor) && (factor <= 279)){// reg 8
            unsigned int reg = ECM_C.ECMmESSTR8.LONG;
            return ((reg >> (factor-248)) & 0x1);
        }else{
            unsigned int reg = ECM_C.ECMmESSTR9.LONG;
            return ((reg >> (factor-280)) & 0x1);
        }
    }
}//}}}

unsigned int GetErrorStatusRegister(unsigned int target, unsigned int reg_id)
{//{{{
    if (target == 0) {
        if (reg_id == 0) {
            return ECM_M.ECMmESSTR0.LONG;
        } else if (reg_id == 1) {
            return ECM_M.ECMmESSTR1.LONG;
        } else if (reg_id == 2){
            return ECM_M.ECMmESSTR2.LONG;
        } else if (reg_id == 3){
            return ECM_M.ECMmESSTR3.LONG;
        } else if (reg_id == 4){
            return ECM_M.ECMmESSTR4.LONG;
        } else if (reg_id == 5){
            return ECM_M.ECMmESSTR5.LONG;
        } else if (reg_id == 6){
            return ECM_M.ECMmESSTR6.LONG;
        } else if (reg_id == 7){
            return ECM_M.ECMmESSTR7.LONG;
        } else if (reg_id == 8){
            return ECM_M.ECMmESSTR8.LONG;
        }else {
            return ECM_M.ECMmESSTR9.LONG;
        }
    } else {
        if (reg_id == 0) {
            return ECM_C.ECMmESSTR0.LONG;
        } else if (reg_id == 1) {
            return ECM_C.ECMmESSTR1.LONG;
        } else if (reg_id == 2){
            return ECM_C.ECMmESSTR2.LONG;
        } else if (reg_id == 3){
            return ECM_C.ECMmESSTR3.LONG;
        } else if (reg_id == 4){
            return ECM_C.ECMmESSTR4.LONG;
        } else if (reg_id == 5){
            return ECM_C.ECMmESSTR5.LONG;
        } else if (reg_id == 6){
            return ECM_C.ECMmESSTR6.LONG;
        } else if (reg_id == 7){
            return ECM_C.ECMmESSTR7.LONG;
        } else if (reg_id == 8){
            return ECM_C.ECMmESSTR8.LONG;
        }else {
            return ECM_C.ECMmESSTR9.LONG;
        }
    }
}//}}}

unsigned int GetTimerOverflowStatus(unsigned int target)
{//{{{
    if (target == 0) {
        return ECM_M.ECMmESSTR9.BIT.ECMmSSE929;
    } else {
        return ECM_C.ECMmESSTR9.BIT.ECMmSSE929;
    }
}//}}}

unsigned int GetErrorSetTriggerStatus(unsigned int target)
{//{{{
    if (target == 0) {
        return ECM_M.ECMmESSTR9.BIT.ECMmSSE930;
    } else {
        return ECM_C.ECMmESSTR9.BIT.ECMmSSE930;
    }
}//}}}

unsigned int GetLoopbackStatus(unsigned int target)
{//{{{
    if (target == 0) {
        return ECM_M.ECMmESSTR9.BIT.ECMmSSE931;
    } else {
        return ECM_C.ECMmESSTR9.BIT.ECMmSSE931;
    }
}//}}}

void SetErrorOutputClearInvalidation(unsigned int value)
{//{{{
    UnlockWriteProtect();
    ECMCommon.ECMEOCCFG.BIT.ECMEOUTCLRT = value;
//    ECMCommon.ECMEOCCFG.BIT.ECMEOUTCLRT = ~value;
//    ECMCommon.ECMEOCCFG.BIT.ECMEOUTCLRT = value; 
    LockWriteProtect();
}//}}}

unsigned int GetErrorOutputClearInvalidation(void)
{//{{{
    return ECMCommon.ECMEOCCFG.BIT.ECMEOUTCLRT;
}//}}}

void SetDynamicMode(void)
{//{{{
    UnlockWriteProtect();
    ECMCommon.ECMEPCFG.BYTE = 0x01;
    LockWriteProtect();
}//}}}

void SetNonDynamicMode(void)
{//{{{
    UnlockWriteProtect();
    ECMCommon.ECMEPCFG.BYTE = 0x00;
    LockWriteProtect();
}//}}}

unsigned int GetMode(void)
{//{{{
    return ECMCommon.ECMEPCFG.BIT.ECMSL0;
}//}}}

void SetMaskableInterruptEnableRegister(unsigned int reg_id, unsigned int data)
{//{{{
    UnlockWriteProtect();
    /*unsigned char byte0 = data & 0xFF;
    unsigned char byte1 = (data >> 8) & 0xFF;
    unsigned char byte2 = (data >> 16) & 0xFF;
    unsigned char byte3 = (data >> 24) & 0xFF;
     // if can access 8bit only
    if (reg_id == 0) {
        ECMCommon.ECMMICFG0.BYTES.BYTE0 = byte0;
        ECMCommon.ECMMICFG0.BYTES.BYTE1 = byte1;
        ECMCommon.ECMMICFG0.BYTES.BYTE2 = byte2;
        ECMCommon.ECMMICFG0.BYTES.BYTE3 = byte3;
    } else if (reg_id == 1) {
        ECMCommon.ECMMICFG1.BYTES.BYTE0 = byte0;
        ECMCommon.ECMMICFG1.BYTES.BYTE1 = byte1;
        ECMCommon.ECMMICFG1.BYTES.BYTE2 = byte2;
        ECMCommon.ECMMICFG1.BYTES.BYTE3 = byte3;
    } else if (reg_id == 2){
        ECMCommon.ECMMICFG2.BYTES.BYTE0 = byte0;
        ECMCommon.ECMMICFG2.BYTES.BYTE1 = byte1;
        ECMCommon.ECMMICFG2.BYTES.BYTE2 = byte2;
        ECMCommon.ECMMICFG2.BYTES.BYTE3 = byte3;
    } else if (reg_id == 3){
        ECMCommon.ECMMICFG3.BYTES.BYTE0 = byte0;
        ECMCommon.ECMMICFG3.BYTES.BYTE1 = byte1;
        ECMCommon.ECMMICFG3.BYTES.BYTE2 = byte2;
        ECMCommon.ECMMICFG3.BYTES.BYTE3 = byte3;
    } else if (reg_id == 4){
        ECMCommon.ECMMICFG4.BYTES.BYTE0 = byte0;
        ECMCommon.ECMMICFG4.BYTES.BYTE1 = byte1;
        ECMCommon.ECMMICFG4.BYTES.BYTE2 = byte2;
        ECMCommon.ECMMICFG4.BYTES.BYTE3 = byte3;
    } else if (reg_id == 5){
        ECMCommon.ECMMICFG5.BYTES.BYTE0 = byte0;
        ECMCommon.ECMMICFG5.BYTES.BYTE1 = byte1;
        ECMCommon.ECMMICFG5.BYTES.BYTE2 = byte2;
        ECMCommon.ECMMICFG5.BYTES.BYTE3 = byte3;
    } else if (reg_id == 6){
        ECMCommon.ECMMICFG6.BYTES.BYTE0 = byte0;
        ECMCommon.ECMMICFG6.BYTES.BYTE1 = byte1;
        ECMCommon.ECMMICFG6.BYTES.BYTE2 = byte2;
        ECMCommon.ECMMICFG6.BYTES.BYTE3 = byte3;
    } else if (reg_id == 7){
        ECMCommon.ECMMICFG7.BYTES.BYTE0 = byte0;
        ECMCommon.ECMMICFG7.BYTES.BYTE1 = byte1;
        ECMCommon.ECMMICFG7.BYTES.BYTE2 = byte2;
        ECMCommon.ECMMICFG7.BYTES.BYTE3 = byte3;
    } else if (reg_id == 8){
        ECMCommon.ECMMICFG8.BYTES.BYTE0 = byte0;
        ECMCommon.ECMMICFG8.BYTES.BYTE1 = byte1;
        ECMCommon.ECMMICFG8.BYTES.BYTE2 = byte2;
        ECMCommon.ECMMICFG8.BYTES.BYTE3 = byte3;
    }else{
        ECMCommon.ECMMICFG9.BYTES.BYTE0 = byte0;
        ECMCommon.ECMMICFG9.BYTES.BYTE1 = byte1;
        ECMCommon.ECMMICFG9.BYTES.BYTE2 = byte2;
        ECMCommon.ECMMICFG9.BYTES.BYTE3 = byte3;
    }*/
    // if can access 32 bits
    if (reg_id == 0) {
        ECMCommon.ECMMICFG0.LONG = data;
    } else if (reg_id == 1) {
        ECMCommon.ECMMICFG1.LONG = data;
    } else if (reg_id == 2){
        ECMCommon.ECMMICFG2.LONG = data;
    } else if (reg_id == 3){
        ECMCommon.ECMMICFG3.LONG = data;
    } else if (reg_id == 4){
        ECMCommon.ECMMICFG4.LONG = data;
    } else if (reg_id == 5){
        ECMCommon.ECMMICFG5.LONG = data;
    } else if (reg_id == 6){
        ECMCommon.ECMMICFG6.LONG = data;
    } else if (reg_id == 7){
        ECMCommon.ECMMICFG7.LONG = data;
    } else if (reg_id == 8){
        ECMCommon.ECMMICFG8.LONG = data;
    }else{
        ECMCommon.ECMMICFG9.LONG = data;
    }
    LockWriteProtect();
}//}}}

unsigned int GetMaskableInterruptEnableRegister(unsigned int reg_id)
{//{{{
    /*unsigned char byte0, byte1, byte2, byte3;
    /* // if access 8bit only
    if (reg_id == 0) {
        byte0 = ECMCommon.ECMMICFG0.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMMICFG0.BYTES.BYTE1;
        byte2 = ECMCommon.ECMMICFG0.BYTES.BYTE2;
        byte3 = ECMCommon.ECMMICFG0.BYTES.BYTE3;
    } else if (reg_id == 1) {
        byte0 = ECMCommon.ECMMICFG1.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMMICFG1.BYTES.BYTE1;
        byte2 = ECMCommon.ECMMICFG1.BYTES.BYTE2;
        byte3 = ECMCommon.ECMMICFG1.BYTES.BYTE3;
    } else if (reg_id == 2){
        byte0 = ECMCommon.ECMMICFG2.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMMICFG2.BYTES.BYTE1;
        byte2 = ECMCommon.ECMMICFG2.BYTES.BYTE2;
        byte3 = ECMCommon.ECMMICFG2.BYTES.BYTE3;
    }else{
        byte0 = ECMCommon.ECMMICFG3.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMMICFG3.BYTES.BYTE1;
        byte2 = ECMCommon.ECMMICFG3.BYTES.BYTE2;
        byte3 = ECMCommon.ECMMICFG3.BYTES.BYTE3;
    }*/
    // if access 32bit
    if (reg_id == 0) {
        return (unsigned int) ECMCommon.ECMMICFG0.LONG; 
    } else if (reg_id == 1) {
        return (unsigned int) ECMCommon.ECMMICFG1.LONG; 
    } else if (reg_id == 2){
        return (unsigned int) ECMCommon.ECMMICFG2.LONG; 
    } else if (reg_id == 3){
        return (unsigned int) ECMCommon.ECMMICFG3.LONG; 
    } else if (reg_id == 4){
        return (unsigned int) ECMCommon.ECMMICFG4.LONG; 
    } else if (reg_id == 5){
        return (unsigned int) ECMCommon.ECMMICFG5.LONG; 
    } else if (reg_id == 6){
        return (unsigned int) ECMCommon.ECMMICFG6.LONG; 
    } else if (reg_id == 7){
        return (unsigned int) ECMCommon.ECMMICFG7.LONG; 
    } else if (reg_id == 8){
        return (unsigned int) ECMCommon.ECMMICFG8.LONG; 
    }else{
        return (unsigned int) ECMCommon.ECMMICFG9.LONG; 
    }

    /*return (byte3 << 24)|(byte2 << 16)|(byte1 << 8)|byte0;*/
    return 0;
}//}}}

void EnableMaskableInterrupt(unsigned int factor, unsigned int value = 1)
{//{{{
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG9.BYTES.BYTE0;
    }

    SetFactorBit(reg_pointer, factor, value);
}//}}}

void DisableMaskableInterrupt(unsigned int factor)
{//{{{
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG9.BYTES.BYTE0;
    }

    ClearFactorBit(reg_pointer, factor);
}//}}}

unsigned int GetEnableMaskableInterrupt(unsigned int factor)
{//{{{
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMICFG9.BYTES.BYTE0;
    }

    return GetFactorBit(reg_pointer, factor);
}//}}}

void SetNonMaskableInterruptEnableRegister(unsigned int reg_id, unsigned int data)
{//{{{
    UnlockWriteProtect();
    /*unsigned char byte0 = data & 0xFF;
    unsigned char byte1 = (data >> 8) & 0xFF;
    unsigned char byte2 = (data >> 16) & 0xFF;
    unsigned char byte3 = (data >> 24) & 0xFF;
    if (reg_id == 0) {
        ECMCommon.ECMNMICFG0.BYTES.BYTE0 = byte0;
        ECMCommon.ECMNMICFG0.BYTES.BYTE1 = byte1;
        ECMCommon.ECMNMICFG0.BYTES.BYTE2 = byte2;
        ECMCommon.ECMNMICFG0.BYTES.BYTE3 = byte3;
    } else if (reg_id == 1) {
        ECMCommon.ECMNMICFG1.BYTES.BYTE0 = byte0;
        ECMCommon.ECMNMICFG1.BYTES.BYTE1 = byte1;
        ECMCommon.ECMNMICFG1.BYTES.BYTE2 = byte2;
        ECMCommon.ECMNMICFG1.BYTES.BYTE3 = byte3;
    } else if (reg_id == 2) {
        ECMCommon.ECMNMICFG2.BYTES.BYTE0 = byte0;
        ECMCommon.ECMNMICFG2.BYTES.BYTE1 = byte1;
        ECMCommon.ECMNMICFG2.BYTES.BYTE2 = byte2;
        ECMCommon.ECMNMICFG2.BYTES.BYTE3 = byte3;
    }else{
        ECMCommon.ECMNMICFG3.BYTES.BYTE0 = byte0;
        ECMCommon.ECMNMICFG3.BYTES.BYTE1 = byte1;
        ECMCommon.ECMNMICFG3.BYTES.BYTE2 = byte2;
        ECMCommon.ECMNMICFG3.BYTES.BYTE3 = byte3;
    }*/
    if (reg_id == 0) {
        ECMCommon.ECMNMICFG0.LONG = data;
    } else if (reg_id == 1) {
        ECMCommon.ECMNMICFG1.LONG = data;
    } else if (reg_id == 2){
        ECMCommon.ECMNMICFG2.LONG = data;
    } else if (reg_id == 3){
        ECMCommon.ECMNMICFG3.LONG = data;
    } else if (reg_id == 4){
        ECMCommon.ECMNMICFG4.LONG = data;
    } else if (reg_id == 5){
        ECMCommon.ECMNMICFG5.LONG = data;
    } else if (reg_id == 6){
        ECMCommon.ECMNMICFG6.LONG = data;
    } else if (reg_id == 7){
        ECMCommon.ECMNMICFG7.LONG = data;
    } else if (reg_id == 8){
        ECMCommon.ECMNMICFG8.LONG = data;
    }else{
        ECMCommon.ECMNMICFG9.LONG = data;
    }
    LockWriteProtect();
}//}}}

unsigned int GetNonMaskableInterruptEnableRegister(unsigned int reg_id)
{//{{{
    /*unsigned char byte0, byte1, byte2, byte3;
    if (reg_id == 0) {
        byte0 = ECMCommon.ECMNMICFG0.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMNMICFG0.BYTES.BYTE1;
        byte2 = ECMCommon.ECMNMICFG0.BYTES.BYTE2;
        byte3 = ECMCommon.ECMNMICFG0.BYTES.BYTE3;
    } else if (reg_id == 1) {
        byte0 = ECMCommon.ECMNMICFG1.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMNMICFG1.BYTES.BYTE1;
        byte2 = ECMCommon.ECMNMICFG1.BYTES.BYTE2;
        byte3 = ECMCommon.ECMNMICFG1.BYTES.BYTE3;
    } else if (reg_id == 2){
        byte0 = ECMCommon.ECMNMICFG2.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMNMICFG2.BYTES.BYTE1;
        byte2 = ECMCommon.ECMNMICFG2.BYTES.BYTE2;
        byte3 = ECMCommon.ECMNMICFG2.BYTES.BYTE3;
    }else{
        byte0 = ECMCommon.ECMNMICFG3.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMNMICFG3.BYTES.BYTE1;
        byte2 = ECMCommon.ECMNMICFG3.BYTES.BYTE2;
        byte3 = ECMCommon.ECMNMICFG3.BYTES.BYTE3;
    }
    return (byte3 << 24)|(byte2 << 16)|(byte1 << 8)|byte0;*/
    if (reg_id == 0) {
        return (unsigned int) ECMCommon.ECMNMICFG0.LONG; 
    } else if (reg_id == 1) {
        return (unsigned int) ECMCommon.ECMNMICFG1.LONG; 
    } else if (reg_id == 2){
        return (unsigned int) ECMCommon.ECMNMICFG2.LONG; 
    } else if (reg_id == 3){
        return (unsigned int) ECMCommon.ECMNMICFG3.LONG; 
    } else if (reg_id == 4){
        return (unsigned int) ECMCommon.ECMNMICFG4.LONG; 
    } else if (reg_id == 5){
        return (unsigned int) ECMCommon.ECMNMICFG5.LONG; 
    } else if (reg_id == 6){
        return (unsigned int) ECMCommon.ECMNMICFG6.LONG; 
    } else if (reg_id == 7){
        return (unsigned int) ECMCommon.ECMNMICFG7.LONG; 
    } else if (reg_id == 8){
        return (unsigned int) ECMCommon.ECMNMICFG8.LONG; 
    }else{
        return (unsigned int) ECMCommon.ECMNMICFG9.LONG; 
    }
    return 0;
}//}}}

void EnableNonMaskableInterrupt(unsigned int factor, unsigned int value = 1)
{//{{{
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG9.BYTES.BYTE0;
    }

    SetFactorBit(reg_pointer, factor, value);
}//}}} 

void DisableNonMaskableInterrupt(unsigned int factor)
{//{{{ 
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG9.BYTES.BYTE0;
    }

    ClearFactorBit(reg_pointer, factor);
}//}}}

unsigned int GetEnableNonMaskableInterrupt(unsigned int factor)
{//{{{ 
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMICFG9.BYTES.BYTE0;
    }

    return GetFactorBit(reg_pointer, factor);
}//}}}

void SetInternalResetEnableRegister(unsigned int reg_id, unsigned int data)
{//{{{
    UnlockWriteProtect();
    /*unsigned char byte0 = data & 0xFF;
    unsigned char byte1 = (data >> 8) & 0xFF;
    unsigned char byte2 = (data >> 16) & 0xFF;
    unsigned char byte3 = (data >> 24) & 0xFF;
    if (reg_id == 0) {
        ECMCommon.ECMIRCFG0.BYTES.BYTE0 = byte0;
        ECMCommon.ECMIRCFG0.BYTES.BYTE1 = byte1;
        ECMCommon.ECMIRCFG0.BYTES.BYTE2 = byte2;
        ECMCommon.ECMIRCFG0.BYTES.BYTE3 = byte3;
    } else if (reg_id == 1) {
        ECMCommon.ECMIRCFG1.BYTES.BYTE0 = byte0;
        ECMCommon.ECMIRCFG1.BYTES.BYTE1 = byte1;
        ECMCommon.ECMIRCFG1.BYTES.BYTE2 = byte2;
        ECMCommon.ECMIRCFG1.BYTES.BYTE3 = byte3;
    } else if (reg_id == 2){
        ECMCommon.ECMIRCFG2.BYTES.BYTE0 = byte0;
        ECMCommon.ECMIRCFG2.BYTES.BYTE1 = byte1;
        ECMCommon.ECMIRCFG2.BYTES.BYTE2 = byte2;
        ECMCommon.ECMIRCFG2.BYTES.BYTE3 = byte3;
    }else{
        ECMCommon.ECMIRCFG3.BYTES.BYTE0 = byte0;
        ECMCommon.ECMIRCFG3.BYTES.BYTE1 = byte1;
        ECMCommon.ECMIRCFG3.BYTES.BYTE2 = byte2;
        ECMCommon.ECMIRCFG3.BYTES.BYTE3 = byte3;
    }*/
    if (reg_id == 0) {
        ECMCommon.ECMIRCFG0.LONG = data;
    } else if (reg_id == 1) {
        ECMCommon.ECMIRCFG1.LONG = data;
    } else if (reg_id == 2){
        ECMCommon.ECMIRCFG2.LONG = data;
    } else if (reg_id == 3){
        ECMCommon.ECMIRCFG3.LONG = data;
    } else if (reg_id == 4){
        ECMCommon.ECMIRCFG4.LONG = data;
    } else if (reg_id == 5){
        ECMCommon.ECMIRCFG5.LONG = data;
    } else if (reg_id == 6){
        ECMCommon.ECMIRCFG6.LONG = data;
    } else if (reg_id == 7){
        ECMCommon.ECMIRCFG7.LONG = data;
    } else if (reg_id == 8){
        ECMCommon.ECMIRCFG8.LONG = data;
    }else{
        ECMCommon.ECMIRCFG9.LONG = data;
    }
    LockWriteProtect();
}//}}}

unsigned int GetInternalResetEnableRegister(unsigned int reg_id)
{//{{{
    /*unsigned char byte0, byte1, byte2, byte3;
    if (reg_id == 0) {
        byte0 = ECMCommon.ECMIRCFG0.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMIRCFG0.BYTES.BYTE1;
        byte2 = ECMCommon.ECMIRCFG0.BYTES.BYTE2;
        byte3 = ECMCommon.ECMIRCFG0.BYTES.BYTE3;
    } else if (reg_id == 1) {
        byte0 = ECMCommon.ECMIRCFG1.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMIRCFG1.BYTES.BYTE1;
        byte2 = ECMCommon.ECMIRCFG1.BYTES.BYTE2;
        byte3 = ECMCommon.ECMIRCFG1.BYTES.BYTE3;
    } else if (reg_id == 2) {
        byte0 = ECMCommon.ECMIRCFG2.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMIRCFG2.BYTES.BYTE1;
        byte2 = ECMCommon.ECMIRCFG2.BYTES.BYTE2;
        byte3 = ECMCommon.ECMIRCFG2.BYTES.BYTE3;
    }else{
        byte0 = ECMCommon.ECMIRCFG3.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMIRCFG3.BYTES.BYTE1;
        byte2 = ECMCommon.ECMIRCFG3.BYTES.BYTE2;
        byte3 = ECMCommon.ECMIRCFG3.BYTES.BYTE3;
    }
    return (byte3 << 24)|(byte2 << 16)|(byte1 << 8)|byte0;*/
    if (reg_id == 0) {
        return (unsigned int) ECMCommon.ECMIRCFG0.LONG; 
    } else if (reg_id == 1) {
        return (unsigned int) ECMCommon.ECMIRCFG1.LONG; 
    } else if (reg_id == 2){
        return (unsigned int) ECMCommon.ECMIRCFG2.LONG; 
    } else if (reg_id == 3){
        return (unsigned int) ECMCommon.ECMIRCFG3.LONG; 
    } else if (reg_id == 4){
        return (unsigned int) ECMCommon.ECMIRCFG4.LONG; 
    } else if (reg_id == 5){
        return (unsigned int) ECMCommon.ECMIRCFG5.LONG; 
    } else if (reg_id == 6){
        return (unsigned int) ECMCommon.ECMIRCFG6.LONG; 
    } else if (reg_id == 7){
        return (unsigned int) ECMCommon.ECMIRCFG7.LONG; 
    } else if (reg_id == 8){
        return (unsigned int) ECMCommon.ECMIRCFG8.LONG; 
    }else{
        return (unsigned int) ECMCommon.ECMIRCFG9.LONG; 
    }
}//}}}

void EnableInternalResetFactor(unsigned int factor, unsigned int value = 1)
{//{{{
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG9.BYTES.BYTE0;
    }

    SetFactorBit(reg_pointer, factor, value);
}//}}}

void DisableInternalResetFactor(unsigned int factor)
{//{{{
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG9.BYTES.BYTE0;
    }

    ClearFactorBit(reg_pointer, factor);
}//}}}

unsigned int GetEnableInternalResetFactor(unsigned int factor)
{//{{{
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG9.BYTES.BYTE0;
    }

    return GetFactorBit(reg_pointer, factor);
}//}}}

void EnableInternalResetTimerOverflow(void)
{//{{{
    unsigned char* reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG9.BYTES.BYTE0;
    SetFactorBit(reg_pointer, 309, 1);
}//}}}

void DisableInternalResetTimerOverflow(void)
{//{{{
    unsigned char* reg_pointer = (unsigned char*) &ECMCommon.ECMIRCFG9.BYTES.BYTE0;
    ClearFactorBit(reg_pointer, 309);
}//}}}

unsigned int GetEnableInternalResetTimerOverflow(void)
{//{{{
    return ECMCommon.ECMIRCFG9.BIT.ECMIRE929;
}//}}}

void SetErrorMaskEnableRegister(unsigned int reg_id, unsigned int data)
{//{{{
    UnlockWriteProtect();
    /*unsigned char byte0 = data & 0xFF;
    unsigned char byte1 = (data >> 8) & 0xFF;
    unsigned char byte2 = (data >> 16) & 0xFF;
    unsigned char byte3 = (data >> 24) & 0xFF;
    if (reg_id == 0) {
        ECMCommon.ECMEMK0.BYTES.BYTE0 = byte0;
        ECMCommon.ECMEMK0.BYTES.BYTE1 = byte1;
        ECMCommon.ECMEMK0.BYTES.BYTE2 = byte2;
        ECMCommon.ECMEMK0.BYTES.BYTE3 = byte3;
    } else if (reg_id == 1) {
        ECMCommon.ECMEMK1.BYTES.BYTE0 = byte0;
        ECMCommon.ECMEMK1.BYTES.BYTE1 = byte1;
        ECMCommon.ECMEMK1.BYTES.BYTE2 = byte2;
        ECMCommon.ECMEMK1.BYTES.BYTE3 = byte3;
    } else if (reg_id == 2){
        ECMCommon.ECMEMK2.BYTES.BYTE0 = byte0;
        ECMCommon.ECMEMK2.BYTES.BYTE1 = byte1;
        ECMCommon.ECMEMK2.BYTES.BYTE2 = byte2;
        ECMCommon.ECMEMK2.BYTES.BYTE3 = byte3;
    }else{
        ECMCommon.ECMEMK3.BYTES.BYTE0 = byte0;
        ECMCommon.ECMEMK3.BYTES.BYTE1 = byte1;
        ECMCommon.ECMEMK3.BYTES.BYTE2 = byte2;
        ECMCommon.ECMEMK3.BYTES.BYTE3 = byte3;
    }*/
    if (reg_id == 0) {
        ECMCommon.ECMEMK0.LONG = data;
    } else if (reg_id == 1) {
        ECMCommon.ECMEMK1.LONG = data;
    } else if (reg_id == 2){
        ECMCommon.ECMEMK2.LONG = data;
    } else if (reg_id == 3){
        ECMCommon.ECMEMK3.LONG = data;
    } else if (reg_id == 4){
        ECMCommon.ECMEMK4.LONG = data;
    } else if (reg_id == 5){
        ECMCommon.ECMEMK5.LONG = data;
    } else if (reg_id == 6){
        ECMCommon.ECMEMK6.LONG = data;
    } else if (reg_id == 7){
        ECMCommon.ECMEMK7.LONG = data;
    } else if (reg_id == 8){
        ECMCommon.ECMEMK8.LONG = data;
    }else{
        ECMCommon.ECMEMK9.LONG = data;
    }
    LockWriteProtect();
}//}}}

unsigned int GetErrorMaskEnableRegister(unsigned int reg_id)
{//{{{
    /*unsigned char byte0, byte1, byte2, byte3;
    if (reg_id == 0) {
        byte0 = ECMCommon.ECMEMK0.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMEMK0.BYTES.BYTE1;
        byte2 = ECMCommon.ECMEMK0.BYTES.BYTE2;
        byte3 = ECMCommon.ECMEMK0.BYTES.BYTE3;
    } else if (reg_id == 1) {
        byte0 = ECMCommon.ECMEMK1.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMEMK1.BYTES.BYTE1;
        byte2 = ECMCommon.ECMEMK1.BYTES.BYTE2;
        byte3 = ECMCommon.ECMEMK1.BYTES.BYTE3;
    } else if (reg_id ==2 ){
        byte0 = ECMCommon.ECMEMK2.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMEMK2.BYTES.BYTE1;
        byte2 = ECMCommon.ECMEMK2.BYTES.BYTE2;
        byte3 = ECMCommon.ECMEMK2.BYTES.BYTE3;
    }else{
        byte0 = ECMCommon.ECMEMK3.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMEMK3.BYTES.BYTE1;
        byte2 = ECMCommon.ECMEMK3.BYTES.BYTE2;
        byte3 = ECMCommon.ECMEMK3.BYTES.BYTE3;
    }
    return (byte3 << 24)|(byte2 << 16)|(byte1 << 8)|byte0;*/
    if (reg_id == 0) {
        return (unsigned int) ECMCommon.ECMEMK0.LONG; 
    } else if (reg_id == 1) {
        return (unsigned int) ECMCommon.ECMEMK1.LONG; 
    } else if (reg_id == 2){
        return (unsigned int) ECMCommon.ECMEMK2.LONG; 
    } else if (reg_id == 3){
        return (unsigned int) ECMCommon.ECMEMK3.LONG; 
    } else if (reg_id == 4){
        return (unsigned int) ECMCommon.ECMEMK4.LONG; 
    } else if (reg_id == 5){
        return (unsigned int) ECMCommon.ECMEMK5.LONG; 
    } else if (reg_id == 6){
        return (unsigned int) ECMCommon.ECMEMK6.LONG; 
    } else if (reg_id == 7){
        return (unsigned int) ECMCommon.ECMEMK7.LONG; 
    } else if (reg_id == 8){
        return (unsigned int) ECMCommon.ECMEMK8.LONG; 
    }else{
        return (unsigned int) ECMCommon.ECMEMK9.LONG; 
    }
    return 0;
}//}}}

void EnableErrorOutputFactor(unsigned int factor)
{//{{{
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK9.BYTES.BYTE0;
    }

    ClearFactorBit(reg_pointer, factor);
}//}}} 

void MaskErrorOutputFactor(unsigned int factor, unsigned int value = 1)
{//{{{
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK9.BYTES.BYTE0;
    }

    SetFactorBit(reg_pointer, factor, value);
}//}}} 

unsigned int GetEnableErrorOutputFactor(unsigned int factor)
{//{{{
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMEMK9.BYTES.BYTE0;
    }

    return GetFactorBit(reg_pointer, factor);
}//}}} 

void EnableErrorOutputTimerOverflow(void)
{//{{{
    unsigned char* reg_pointer = (unsigned char*) &ECMCommon.ECMEMK9.BYTES.BYTE0;
    ClearFactorBit(reg_pointer, 309);
}//}}}

void MaskErrorOutputTimerOverflow(void)
{//{{{
    unsigned char* reg_pointer = (unsigned char*) &ECMCommon.ECMEMK9.BYTES.BYTE0;
    SetFactorBit(reg_pointer, 309, 1);
}//}}}

unsigned int GetEnableErrorOutputTimerOverflow(void)
{//{{{
    return ECMCommon.ECMEMK9.BIT.ECMEMK929;
}//}}}

void SetErrorStatusClearRegister(unsigned int reg_id, unsigned int data)
{//{{{
    UnlockWriteProtect();
    /*if (reg_id == 0) {
        ECMCommon.ECMESSTC0.LONG = data;
    } else if (reg_id == 1) {
        ECMCommon.ECMESSTC1.LONG = data;
    } else if (reg_id == 2 ) {
        ECMCommon.ECMESSTC2.LONG = data;
    }else{
        ECMCommon.ECMESSTC3.LONG = data;
    }*/
    if (reg_id == 0) {
        ECMCommon.ECMESSTC0.LONG = data;
    } else if (reg_id == 1) {
        ECMCommon.ECMESSTC1.LONG = data;
    } else if (reg_id == 2){
        ECMCommon.ECMESSTC2.LONG = data;
    } else if (reg_id == 3){
        ECMCommon.ECMESSTC3.LONG = data;
    } else if (reg_id == 4){
        ECMCommon.ECMESSTC4.LONG = data;
    } else if (reg_id == 5){
        ECMCommon.ECMESSTC5.LONG = data;
    } else if (reg_id == 6){
        ECMCommon.ECMESSTC6.LONG = data;
    } else if (reg_id == 7){
        ECMCommon.ECMESSTC7.LONG = data;
    } else if (reg_id == 8){
        ECMCommon.ECMESSTC8.LONG = data;
    }else{
        ECMCommon.ECMESSTC9.LONG = data;
    }
    LockWriteProtect();
}//}}}

unsigned int GetErrorStatusClearRegister(unsigned int reg_id)
{//{{{
    if (reg_id == 0) {
        return (unsigned int) ECMCommon.ECMESSTC0.LONG; 
    } else if (reg_id == 1) {
        return (unsigned int) ECMCommon.ECMESSTC1.LONG; 
    } else if (reg_id == 2){
        return (unsigned int) ECMCommon.ECMESSTC2.LONG; 
    } else if (reg_id == 3){
        return (unsigned int) ECMCommon.ECMESSTC3.LONG; 
    } else if (reg_id == 4){
        return (unsigned int) ECMCommon.ECMESSTC4.LONG; 
    } else if (reg_id == 5){
        return (unsigned int) ECMCommon.ECMESSTC5.LONG; 
    } else if (reg_id == 6){
        return (unsigned int) ECMCommon.ECMESSTC6.LONG; 
    } else if (reg_id == 7){
        return (unsigned int) ECMCommon.ECMESSTC7.LONG; 
    } else if (reg_id == 8){
        return (unsigned int) ECMCommon.ECMESSTC8.LONG; 
    }else{
        return (unsigned int) ECMCommon.ECMESSTC9.LONG; 
    }
}//}}}

void ClearErrorStatus(unsigned int factor, unsigned int value = 1)
{//{{{
    unsigned int* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC0.LONG;
    } else if (factor <= 55) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC1.LONG;
    } else if (factor <= 87) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC2.LONG;
    } else if (factor <= 119) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC3.LONG;
    } else if (factor <= 151) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC4.LONG;
    } else if (factor <= 183) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC5.LONG;
    } else if (factor <= 215) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC6.LONG;
    } else if (factor <= 247) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC7.LONG;
    } else if (factor <= 279) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC8.LONG;
    } else {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC9.LONG;
    }

    SetFactorBitLong(reg_pointer, factor, value);
}//}}}

void ClearTimerOverflowStatus(void)
{//{{{
    unsigned int* reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC9.LONG;
    SetFactorBitLong(reg_pointer, 309, 1);
}//}}}

void ReleaseErrorStatus(unsigned int factor)
{//{{{
    unsigned int* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC0.LONG;
    } else if (factor <= 55) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC1.LONG;
    } else if (factor <= 87) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC2.LONG;
    } else if (factor <= 119) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC3.LONG;
    } else if (factor <= 151) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC4.LONG;
    } else if (factor <= 183) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC5.LONG;
    } else if (factor <= 215) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC6.LONG;
    } else if (factor <= 247) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC7.LONG;
    } else if (factor <= 279) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC8.LONG;
    } else {
        reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC9.LONG;
    }

    ClearFactorBitLong(reg_pointer, factor);
}//}}}

void ReleaseTimerOverflowStatus(void)
{//{{{
    unsigned int* reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC9.LONG;
    ClearFactorBitLong(reg_pointer, 309);
}//}}}

void ReleaseErrorSetTriggerStatus(void)
{//{{{
    unsigned int* reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC9.LONG;
    ClearFactorBitLong(reg_pointer, 310);
}//}}}

void ClearErrorSetTriggerStatus(void)
{//{{{
    unsigned int* reg_pointer = (unsigned int*) &ECMCommon.ECMESSTC9.LONG;
    SetFactorBitLong(reg_pointer, 310, 1);
}//}}}

void SetPseudoErrorRegister(unsigned int reg_id, unsigned int data)
{//{{{
    UnlockWriteProtect();
    if (reg_id == 0) {
        ECMCommon.ECMPE0.LONG = data;
    } else if (reg_id == 1) {
        ECMCommon.ECMPE1.LONG = data;
    } else if (reg_id == 2){
        ECMCommon.ECMPE2.LONG = data;
    } else if (reg_id == 3){
        ECMCommon.ECMPE3.LONG = data;
    } else if (reg_id == 4){
        ECMCommon.ECMPE4.LONG = data;
    } else if (reg_id == 5){
        ECMCommon.ECMPE5.LONG = data;
    } else if (reg_id == 6){
        ECMCommon.ECMPE6.LONG = data;
    } else if (reg_id == 7){
        ECMCommon.ECMPE7.LONG = data;
    } else if (reg_id == 8){
        ECMCommon.ECMPE8.LONG = data;
    }else{
        ECMCommon.ECMPE9.LONG = data;
    }
    LockWriteProtect();
}//}}}

void EnablePseudoErrorFactor(unsigned int factor, unsigned int value = 1)
{//{{{
    unsigned int* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE0.LONG;
    } else if (factor <= 55) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE1.LONG;
    } else if (factor <= 87) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE2.LONG;
    } else if (factor <= 119) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE3.LONG;
    } else if (factor <= 151) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE4.LONG;
    } else if (factor <= 183) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE5.LONG;
    } else if (factor <= 215) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE6.LONG;
    } else if (factor <= 247) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE7.LONG;
    } else if (factor <= 279) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE8.LONG;
    } else {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE9.LONG;
    }

    SetFactorBitLong(reg_pointer, factor, value);
}//}}}

void DisablePseudoErrorFactor(unsigned int factor)
{//{{{
    unsigned int* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE0.LONG;
    } else if (factor <= 55) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE1.LONG;
    } else if (factor <= 87) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE2.LONG;
    } else if (factor <= 119) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE3.LONG;
    } else if (factor <= 151) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE4.LONG;
    } else if (factor <= 183) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE5.LONG;
    } else if (factor <= 215) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE6.LONG;
    } else if (factor <= 247) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE7.LONG;
    } else if (factor <= 279) {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE8.LONG;
    } else {
        reg_pointer = (unsigned int*) &ECMCommon.ECMPE9.LONG;
    }

    ClearFactorBitLong(reg_pointer, factor);
}//}}} 

void EnablePseudoErrorTimerOverflow(void)
{//{{{
    unsigned int* reg_pointer = (unsigned int*) &ECMCommon.ECMPE9.LONG;
    SetFactorBitLong(reg_pointer, 309, 1);//117->309, 118->310
}//}}}

void DisablePseudoErrorTimerOverflow(void)
{//{{{
    unsigned int* reg_pointer = (unsigned int*) &ECMCommon.ECMPE9.LONG;
    ClearFactorBitLong(reg_pointer, 309);
}//}}}

void TimerReset(void)
{//{{{
    UnlockWriteProtect();
    unsigned char reg_value = ECMCommon.ECMDTMCTL.BYTE;
    ECMCommon.ECMDTMCTL.BYTE = reg_value|0x2;
    LockWriteProtect();
}//}}}

void TimerOn(void)
{//{{{
    UnlockWriteProtect();
    ECMCommon.ECMDTMCTL.BYTE = 0x01; // Set STP = 0, STA = 1
    LockWriteProtect();
}//}}}

void TimerOff(void)
{//{{{
    UnlockWriteProtect();
//    unsigned char reg_value = ECMCommon.ECMDTMCTL.BYTE;
//    ECMCommon.ECMDTMCTL.BYTE = reg_value & 0x2F;
    ECMCommon.ECMDTMCTL.BIT.DTMSTP = 0x1;
    LockWriteProtect();
}//}}}

unsigned int GetTimerOnOff(void)
{//{{{
    return ECMCommon.ECMDTMCTL.BIT.DTMSTA;
}//}}}

unsigned int GetTimerCounter(void)
{//{{{
    return ECMCommon.ECMDTMR.WORD;
}//}}}

void SetTimerCompare(unsigned int value)
{//{{{
    UnlockWriteProtect();
    ECMCommon.ECMDTMCMP.BIT.ECMDTMCMP = value;
    LockWriteProtect();
}//}}}

unsigned int GetTimerCompare(void)
{//{{{
    return ECMCommon.ECMDTMCMP.BIT.ECMDTMCMP;
}//}}}

void SetMaskTimerEnableRegister(unsigned int reg_id, unsigned int data)
{//{{{
    UnlockWriteProtect();
    /*unsigned char byte0 = data & 0xFF;
    unsigned char byte1 = (data >> 8) & 0xFF;
    unsigned char byte2 = (data >> 16) & 0xFF;
    unsigned char byte3 = (data >> 24) & 0xFF;
    if (reg_id == 0) {
        ECMCommon.ECMDTMCFG0.BYTES.BYTE0 = byte0;
        ECMCommon.ECMDTMCFG0.BYTES.BYTE1 = byte1;
        ECMCommon.ECMDTMCFG0.BYTES.BYTE2 = byte2;
        ECMCommon.ECMDTMCFG0.BYTES.BYTE3 = byte3;
    } else if (reg_id == 1) {
        ECMCommon.ECMDTMCFG1.BYTES.BYTE0 = byte0;
        ECMCommon.ECMDTMCFG1.BYTES.BYTE1 = byte1;
        ECMCommon.ECMDTMCFG1.BYTES.BYTE2 = byte2;
        ECMCommon.ECMDTMCFG1.BYTES.BYTE3 = byte3;
    } else if (reg_id == 2) {
        ECMCommon.ECMDTMCFG2.BYTES.BYTE0 = byte0;
        ECMCommon.ECMDTMCFG2.BYTES.BYTE1 = byte1;
        ECMCommon.ECMDTMCFG2.BYTES.BYTE2 = byte2;
        ECMCommon.ECMDTMCFG2.BYTES.BYTE3 = byte3;
    } else if (reg_id == 3) {
        ECMCommon.ECMDTMCFG3.BYTES.BYTE0 = byte0;
        ECMCommon.ECMDTMCFG3.BYTES.BYTE1 = byte1;
        ECMCommon.ECMDTMCFG3.BYTES.BYTE2 = byte2;
        ECMCommon.ECMDTMCFG3.BYTES.BYTE3 = byte3;
    } else if (reg_id == 4) {
        ECMCommon.ECMDTMCFG4.BYTES.BYTE0 = byte0;
        ECMCommon.ECMDTMCFG4.BYTES.BYTE1 = byte1;
        ECMCommon.ECMDTMCFG4.BYTES.BYTE2 = byte2;
        ECMCommon.ECMDTMCFG4.BYTES.BYTE3 = byte3;
    } else if (reg_id == 5){
        ECMCommon.ECMDTMCFG5.BYTES.BYTE0 = byte0;
        ECMCommon.ECMDTMCFG5.BYTES.BYTE1 = byte1;
        ECMCommon.ECMDTMCFG5.BYTES.BYTE2 = byte2;
        ECMCommon.ECMDTMCFG5.BYTES.BYTE3 = byte3;
    } else if (reg_id == 6){
        ECMCommon.ECMDTMCFG6.BYTES.BYTE0 = byte0;
        ECMCommon.ECMDTMCFG6.BYTES.BYTE1 = byte1;
        ECMCommon.ECMDTMCFG6.BYTES.BYTE2 = byte2;
        ECMCommon.ECMDTMCFG6.BYTES.BYTE3 = byte3;
    }else{
        ECMCommon.ECMDTMCFG7.BYTES.BYTE0 = byte0;
        ECMCommon.ECMDTMCFG7.BYTES.BYTE1 = byte1;
        ECMCommon.ECMDTMCFG7.BYTES.BYTE2 = byte2;
        ECMCommon.ECMDTMCFG7.BYTES.BYTE3 = byte3;
    }*/
    if (reg_id == 0) {
        ECMCommon.ECMMIDTMCFG0.LONG = data;
    } else if (reg_id == 1) {
        ECMCommon.ECMMIDTMCFG1.LONG = data;
    } else if (reg_id == 2){
        ECMCommon.ECMMIDTMCFG2.LONG = data;
    } else if (reg_id == 3){
        ECMCommon.ECMMIDTMCFG3.LONG = data;
    } else if (reg_id == 4){
        ECMCommon.ECMMIDTMCFG4.LONG = data;
    } else if (reg_id == 5){
        ECMCommon.ECMMIDTMCFG5.LONG = data;
    } else if (reg_id == 6){
        ECMCommon.ECMMIDTMCFG6.LONG = data;
    } else if (reg_id == 7){
        ECMCommon.ECMMIDTMCFG7.LONG = data;
    } else if (reg_id == 8){
        ECMCommon.ECMMIDTMCFG8.LONG = data;
    }else{
        ECMCommon.ECMMIDTMCFG9.LONG = data;
    }
    LockWriteProtect();
}//}}}

void SetNonMaskTimerEnableRegister(unsigned int reg_id, unsigned int data)
{//{{{ 
    UnlockWriteProtect();
    /*unsigned char byte0 = data & 0xFF;
    unsigned char byte1 = (data >> 8) & 0xFF;
    unsigned char byte2 = (data >> 16) & 0xFF;
    unsigned char byte3 = (data >> 24) & 0xFF;
    if (reg_id == 0) {
        ECMCommon.ECMDTMCFG0.BYTES.BYTE0 = byte0;
        ECMCommon.ECMDTMCFG0.BYTES.BYTE1 = byte1;
        ECMCommon.ECMDTMCFG0.BYTES.BYTE2 = byte2;
        ECMCommon.ECMDTMCFG0.BYTES.BYTE3 = byte3;
    } else if (reg_id == 1) {
        ECMCommon.ECMDTMCFG1.BYTES.BYTE0 = byte0;
        ECMCommon.ECMDTMCFG1.BYTES.BYTE1 = byte1;
        ECMCommon.ECMDTMCFG1.BYTES.BYTE2 = byte2;
        ECMCommon.ECMDTMCFG1.BYTES.BYTE3 = byte3;
    } else if (reg_id == 2) {
        ECMCommon.ECMDTMCFG2.BYTES.BYTE0 = byte0;
        ECMCommon.ECMDTMCFG2.BYTES.BYTE1 = byte1;
        ECMCommon.ECMDTMCFG2.BYTES.BYTE2 = byte2;
        ECMCommon.ECMDTMCFG2.BYTES.BYTE3 = byte3;
    } else if (reg_id == 3) {
        ECMCommon.ECMDTMCFG3.BYTES.BYTE0 = byte0;
        ECMCommon.ECMDTMCFG3.BYTES.BYTE1 = byte1;
        ECMCommon.ECMDTMCFG3.BYTES.BYTE2 = byte2;
        ECMCommon.ECMDTMCFG3.BYTES.BYTE3 = byte3;
    } else if (reg_id == 4) {
        ECMCommon.ECMDTMCFG4.BYTES.BYTE0 = byte0;
        ECMCommon.ECMDTMCFG4.BYTES.BYTE1 = byte1;
        ECMCommon.ECMDTMCFG4.BYTES.BYTE2 = byte2;
        ECMCommon.ECMDTMCFG4.BYTES.BYTE3 = byte3;
    } else if (reg_id == 5){
        ECMCommon.ECMDTMCFG5.BYTES.BYTE0 = byte0;
        ECMCommon.ECMDTMCFG5.BYTES.BYTE1 = byte1;
        ECMCommon.ECMDTMCFG5.BYTES.BYTE2 = byte2;
        ECMCommon.ECMDTMCFG5.BYTES.BYTE3 = byte3;
    } else if (reg_id == 6){
        ECMCommon.ECMDTMCFG6.BYTES.BYTE0 = byte0;
        ECMCommon.ECMDTMCFG6.BYTES.BYTE1 = byte1;
        ECMCommon.ECMDTMCFG6.BYTES.BYTE2 = byte2;
        ECMCommon.ECMDTMCFG6.BYTES.BYTE3 = byte3;
    }else{
        ECMCommon.ECMDTMCFG7.BYTES.BYTE0 = byte0;
        ECMCommon.ECMDTMCFG7.BYTES.BYTE1 = byte1;
        ECMCommon.ECMDTMCFG7.BYTES.BYTE2 = byte2;
        ECMCommon.ECMDTMCFG7.BYTES.BYTE3 = byte3;
    }*/
    if (reg_id == 0) {
        ECMCommon.ECMNMIDTMCFG0.LONG = data;
    } else if (reg_id == 1) {
        ECMCommon.ECMNMIDTMCFG1.LONG = data;
    } else if (reg_id == 2){
        ECMCommon.ECMNMIDTMCFG2.LONG = data;
    } else if (reg_id == 3){
        ECMCommon.ECMNMIDTMCFG3.LONG = data;
    } else if (reg_id == 4){
        ECMCommon.ECMNMIDTMCFG4.LONG = data;
    } else if (reg_id == 5){
        ECMCommon.ECMNMIDTMCFG5.LONG = data;
    } else if (reg_id == 6){
        ECMCommon.ECMNMIDTMCFG6.LONG = data;
    } else if (reg_id == 7){
        ECMCommon.ECMNMIDTMCFG7.LONG = data;
    } else if (reg_id == 8){
        ECMCommon.ECMNMIDTMCFG8.LONG = data;
    }else{
        ECMCommon.ECMNMIDTMCFG9.LONG = data;
    }
    LockWriteProtect();
}//}}}

unsigned int GetMaskTimerEnableRegister(unsigned int reg_id)
{//{{{
    /*unsigned char byte0, byte1, byte2, byte3;
    if (reg_id == 0) {
        byte0 = ECMCommon.ECMDTMCFG0.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMDTMCFG0.BYTES.BYTE1;
        byte2 = ECMCommon.ECMDTMCFG0.BYTES.BYTE2;
        byte3 = ECMCommon.ECMDTMCFG0.BYTES.BYTE3;
    } else if (reg_id == 1) {
        byte0 = ECMCommon.ECMDTMCFG1.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMDTMCFG1.BYTES.BYTE1;
        byte2 = ECMCommon.ECMDTMCFG1.BYTES.BYTE2;
        byte3 = ECMCommon.ECMDTMCFG1.BYTES.BYTE3;
    } else if (reg_id == 2) {
        byte0 = ECMCommon.ECMDTMCFG2.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMDTMCFG2.BYTES.BYTE1;
        byte2 = ECMCommon.ECMDTMCFG2.BYTES.BYTE2;
        byte3 = ECMCommon.ECMDTMCFG2.BYTES.BYTE3;
    } else if (reg_id == 3) {
        byte0 = ECMCommon.ECMDTMCFG3.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMDTMCFG3.BYTES.BYTE1;
        byte2 = ECMCommon.ECMDTMCFG3.BYTES.BYTE2;
        byte3 = ECMCommon.ECMDTMCFG3.BYTES.BYTE3;
    } else if (reg_id == 4) {
        byte0 = ECMCommon.ECMDTMCFG4.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMDTMCFG4.BYTES.BYTE1;
        byte2 = ECMCommon.ECMDTMCFG4.BYTES.BYTE2;
        byte3 = ECMCommon.ECMDTMCFG4.BYTES.BYTE3;
    } else {
        byte0 = ECMCommon.ECMDTMCFG5.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMDTMCFG5.BYTES.BYTE1;
        byte2 = ECMCommon.ECMDTMCFG5.BYTES.BYTE2;
        byte3 = ECMCommon.ECMDTMCFG5.BYTES.BYTE3;
    }
    return (byte3 << 24)|(byte2 << 16)|(byte1 << 8)|byte0;*/
    if (reg_id == 0) {
        return (unsigned int) ECMCommon.ECMMIDTMCFG0.LONG; 
    } else if (reg_id == 1) {
        return (unsigned int) ECMCommon.ECMMIDTMCFG1.LONG; 
    } else if (reg_id == 2){
        return (unsigned int) ECMCommon.ECMMIDTMCFG2.LONG; 
    } else if (reg_id == 3){
        return (unsigned int) ECMCommon.ECMMIDTMCFG3.LONG; 
    } else if (reg_id == 4){
        return (unsigned int) ECMCommon.ECMMIDTMCFG4.LONG; 
    } else if (reg_id == 5){
        return (unsigned int) ECMCommon.ECMMIDTMCFG5.LONG; 
    } else if (reg_id == 6){
        return (unsigned int) ECMCommon.ECMMIDTMCFG6.LONG; 
    } else if (reg_id == 7){
        return (unsigned int) ECMCommon.ECMMIDTMCFG7.LONG; 
    } else if (reg_id == 8){
        return (unsigned int) ECMCommon.ECMMIDTMCFG8.LONG; 
    }else{
        return (unsigned int) ECMCommon.ECMMIDTMCFG9.LONG; 
    }
}//}}}

unsigned int GetNonMaskTimerEnableRegister(unsigned int reg_id)
{//{{{
    /*unsigned char byte0, byte1, byte2, byte3;
    if (reg_id == 0) {
        byte0 = ECMCommon.ECMDTMCFG0.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMDTMCFG0.BYTES.BYTE1;
        byte2 = ECMCommon.ECMDTMCFG0.BYTES.BYTE2;
        byte3 = ECMCommon.ECMDTMCFG0.BYTES.BYTE3;
    } else if (reg_id == 1) {
        byte0 = ECMCommon.ECMDTMCFG1.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMDTMCFG1.BYTES.BYTE1;
        byte2 = ECMCommon.ECMDTMCFG1.BYTES.BYTE2;
        byte3 = ECMCommon.ECMDTMCFG1.BYTES.BYTE3;
    } else if (reg_id == 2) {
        byte0 = ECMCommon.ECMDTMCFG2.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMDTMCFG2.BYTES.BYTE1;
        byte2 = ECMCommon.ECMDTMCFG2.BYTES.BYTE2;
        byte3 = ECMCommon.ECMDTMCFG2.BYTES.BYTE3;
    } else if (reg_id == 3) {
        byte0 = ECMCommon.ECMDTMCFG3.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMDTMCFG3.BYTES.BYTE1;
        byte2 = ECMCommon.ECMDTMCFG3.BYTES.BYTE2;
        byte3 = ECMCommon.ECMDTMCFG3.BYTES.BYTE3;
    } else if (reg_id == 4) {
        byte0 = ECMCommon.ECMDTMCFG4.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMDTMCFG4.BYTES.BYTE1;
        byte2 = ECMCommon.ECMDTMCFG4.BYTES.BYTE2;
        byte3 = ECMCommon.ECMDTMCFG4.BYTES.BYTE3;
    } else {
        byte0 = ECMCommon.ECMDTMCFG5.BYTES.BYTE0; 
        byte1 = ECMCommon.ECMDTMCFG5.BYTES.BYTE1;
        byte2 = ECMCommon.ECMDTMCFG5.BYTES.BYTE2;
        byte3 = ECMCommon.ECMDTMCFG5.BYTES.BYTE3;
    }
    return (byte3 << 24)|(byte2 << 16)|(byte1 << 8)|byte0;*/
    if (reg_id == 0) {
        return (unsigned int) ECMCommon.ECMNMIDTMCFG0.LONG; 
    } else if (reg_id == 1) {
        return (unsigned int) ECMCommon.ECMNMIDTMCFG1.LONG; 
    } else if (reg_id == 2){
        return (unsigned int) ECMCommon.ECMNMIDTMCFG2.LONG; 
    } else if (reg_id == 3){
        return (unsigned int) ECMCommon.ECMNMIDTMCFG3.LONG; 
    } else if (reg_id == 4){
        return (unsigned int) ECMCommon.ECMNMIDTMCFG4.LONG; 
    } else if (reg_id == 5){
        return (unsigned int) ECMCommon.ECMNMIDTMCFG5.LONG; 
    } else if (reg_id == 6){
        return (unsigned int) ECMCommon.ECMNMIDTMCFG6.LONG; 
    } else if (reg_id == 7){
        return (unsigned int) ECMCommon.ECMNMIDTMCFG7.LONG; 
    } else if (reg_id == 8){
        return (unsigned int) ECMCommon.ECMNMIDTMCFG8.LONG; 
    }else{
        return (unsigned int) ECMCommon.ECMNMIDTMCFG9.LONG; 
    }
}//}}}

void EnableTimerMaskableInterrupt(unsigned int factor, unsigned int value = 1)
{//{{{
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG9.BYTES.BYTE0;
    }

    SetFactorBit(reg_pointer, factor, value);
}//}}}

void DisableTimerMaskableInterrupt(unsigned int factor)
{//{{{
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG9.BYTES.BYTE0;
    }

    ClearFactorBit(reg_pointer, factor);
}//}}}

unsigned int GetEnableTimerMaskableInterrupt(unsigned int factor)
{//{{{
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMMIDTMCFG9.BYTES.BYTE0;
    }

    return GetFactorBit(reg_pointer, factor);
}//}}}

void EnableTimerNonMaskableInterrupt(unsigned int factor, unsigned int value = 1)
{//{{{
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG9.BYTES.BYTE0;
    }

    SetFactorBit(reg_pointer, factor, value);
}//}}}

void DisableTimerNonMaskableInterrupt(unsigned int factor)
{//{{{
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG9.BYTES.BYTE0;
    }

    ClearFactorBit(reg_pointer, factor);
}//}}}

unsigned int GetEnableTimerNonMaskableInterrupt(unsigned int factor)
{//{{{
    unsigned char* reg_pointer;
    if (factor <= 23) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG0.BYTES.BYTE0;
    } else if (factor <= 55) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG1.BYTES.BYTE0;
    } else if (factor <= 87) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG2.BYTES.BYTE0;
    } else if (factor <= 119) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG3.BYTES.BYTE0;
    } else if (factor <= 151) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG4.BYTES.BYTE0;
    } else if (factor <= 183) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG5.BYTES.BYTE0;
    } else if (factor <= 215) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG6.BYTES.BYTE0;
    } else if (factor <= 247) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG7.BYTES.BYTE0;
    } else if (factor <= 279) {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG8.BYTES.BYTE0;
    } else {
        reg_pointer = (unsigned char*) &ECMCommon.ECMNMIDTMCFG9.BYTES.BYTE0;
    }

    return GetFactorBit(reg_pointer, factor);
}//}}}

void SetMaskErrorIn92Register(unsigned int value)
{//{{{
    ECMCommon.ECMPEM.LONG = value;
}//}}}

#endif
// vim600: set foldmethod=marker :
