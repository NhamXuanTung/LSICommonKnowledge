// ---------------------------------------------------------------------
// $Id: CONTROL_drv.h,v 1.4 2013/12/11 14:46:18 ducduong Exp $
//
// Copyright(c) 2012 Renesas Electronics Corporation
// Copyright(c) 2012 Renesas Design Vietnam Co., Ltd.
// RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
// This program must be used solely for the purpose for which
// it was furnished by Renesas Electronics Corporation. No part of this
// program may be reproduced or disclosed to others, in any
// form, without the prior written permission of Renesas Electronics
// Corporation.
// ---------------------------------------------------------------------

#ifndef __CONTROL_DRV__
#define __CONTROL_DRV__
#include "iodefine_control_port.h" 

#define CONTROL_PORT (*(volatile struct st_control_port *)0xFFF80000)

#define NUM_PORT 307
#define NUM_FACTOR 308

unsigned char noname[5]           = { 1, 1, 1, 1, 1};

// Control port drivers 
void ForceESSTR(unsigned int target, unsigned int reg_num, unsigned int reg_letter, unsigned int value)
{//{{{
//    CONTROL_PORT.FORCE_ESS_SEL.BIT.TARGET = target;
//    CONTROL_PORT.FORCE_ESS_SEL.BIT.ESS_REG_NUM = reg_num;
//    CONTROL_PORT.FORCE_ESS_SEL.BIT.ESS_REG_LETTER = reg_letter;
//    CONTROL_PORT.FORCE_ESS_VAL.LONG = value;
//    CONTROL_PORT.HDLECOMM.BIT.FORCE_ESS = 1;
}//}}}

void ForcePort(unsigned int target, unsigned int port_id, unsigned int value)
{//{{{
    CONTROL_PORT.PORT.BIT.TARGET = target;
    CONTROL_PORT.PORT.BIT.PORT_SEL = port_id;
    CONTROL_PORT.PORT.BIT.PORT_VAL = value;
    CONTROL_PORT.HDLECOMM.BIT.PORT_SET = 0x1;
}//}}}

void GetPort(unsigned int target, unsigned int port_id)
{//{{{
    CONTROL_PORT.PORT.BIT.TARGET = target;
    CONTROL_PORT.PORT.BIT.PORT_SEL = port_id;
    CONTROL_PORT.HDLECOMM.BIT.PORT_GET = 0x1;
}//}}}

void WritePort(unsigned int factor, unsigned int value)
{//{{{
    if (factor == 308) { // force different sgaterroz
        ForcePort(0, 9, 1);
        ForcePort(1, 9, ~value);
        return;
    }
    unsigned int reg_val;
    unsigned int pos = factor%32;
    unsigned int reg_index = factor /32;
    unsigned int mask = 1 << pos;
    switch (reg_index) {
        case 0:
            reg_val = CONTROL_PORT.ERRIN0.LONG;
            CONTROL_PORT.ERRIN0.LONG = (reg_val & (~mask)) | ((value << pos) & mask);        
            break;
        case 1:
            reg_val = CONTROL_PORT.ERRIN1.LONG;
            CONTROL_PORT.ERRIN1.LONG = (reg_val & (~mask)) | ((value << pos) & mask);        
            break;
        case 2:
            reg_val = CONTROL_PORT.ERRIN2.LONG;
            CONTROL_PORT.ERRIN2.LONG = (reg_val & (~mask)) | ((value << pos) & mask);        
            break;
        case 3:
            reg_val = CONTROL_PORT.ERRIN3.LONG;
            CONTROL_PORT.ERRIN3.LONG = (reg_val & (~mask)) | ((value << pos) & mask);        
            break;
        case 4:
            reg_val = CONTROL_PORT.ERRIN4.LONG;
            CONTROL_PORT.ERRIN4.LONG = (reg_val & (~mask)) | ((value << pos) & mask);        
            break;
        case 5:
            reg_val = CONTROL_PORT.ERRIN5.LONG;
            CONTROL_PORT.ERRIN5.LONG = (reg_val & (~mask)) | ((value << pos) & mask);        
            break;
        case 6:
            reg_val = CONTROL_PORT.ERRIN6.LONG;
            CONTROL_PORT.ERRIN6.LONG = (reg_val & (~mask)) | ((value << pos) & mask);        
            break;
        case 7:
            reg_val = CONTROL_PORT.ERRIN7.LONG;
            CONTROL_PORT.ERRIN7.LONG = (reg_val & (~mask)) | ((value << pos) & mask);        
            break;
        case 8:
            reg_val = CONTROL_PORT.ERRIN8.LONG;
            CONTROL_PORT.ERRIN8.LONG = (reg_val & (~mask)) | ((value << pos) & mask);        
            break;
        case 9:
            reg_val = CONTROL_PORT.ERRIN9.LONG;
            CONTROL_PORT.ERRIN9.LONG = (reg_val & (~mask)) | ((value << pos) & mask);        
            break;

        default:
            break;
    }
    CONTROL_PORT.CTRL.BIT.CTRL = 0x1;
}//}}}

void SetCounterClockRegister(unsigned int value)
{//{{{
    CONTROL_PORT.CNTCLK0.LONG = value;
}//}}}

void SetPclkClockRegister(unsigned int value)
{//{{{
    CONTROL_PORT.PCLK0.LONG = value;
    CONTROL_PORT.CTRL.BIT.CTRL = 0x1;
}//}}}

//void SetMaskErrorIn92Register(unsigned int value)// move this func to ECM_drv due to ECMPEM reg
//{//{{{
//    CONTROL_PORT.MSKERRIN.LONG = value;
//    CONTROL_PORT.CTRL.BIT.CTRL = 0x1;
//}//}}}

void CtrlPortClearAllInterrupt(void)
{//{{{
    CONTROL_PORT.TIPE1.LONG = 0;
    CONTROL_PORT.TIPE2.LONG = 0;
    CONTROL_PORT.TIPE3.LONG = 0;
    CONTROL_PORT.TIPE4.LONG = 0;
    CONTROL_PORT.TIPE5.LONG = 0;
    CONTROL_PORT.TIPE6.LONG = 0;
    CONTROL_PORT.TIPE7.LONG = 0;
    CONTROL_PORT.TIPE8.LONG = 0;
    CONTROL_PORT.NMI.LONG = 0;
}//}}}

void CtrlPortClearAllError(void)
{//{{{
    CONTROL_PORT.DCLSINT1.LONG = 0;
    CONTROL_PORT.DCLSINT2.LONG = 0;
    CONTROL_PORT.DCLSINT3.LONG = 0;
    CONTROL_PORT.DCLSINT4.LONG = 0;
    CONTROL_PORT.DCLSINT5.LONG = 0;
    CONTROL_PORT.DCLSINT6.LONG = 0;
    CONTROL_PORT.DCLSINT7.LONG = 0;
    CONTROL_PORT.DCLSINT8.LONG = 0;
}//}}}

void CtrlPortClearReset(void)
{//{{{
    CONTROL_PORT.RESZ.LONG = 0;
}//}}}

unsigned int GetInterruptECMTIPE(unsigned int factor)
{//{{{
    if (factor == 0){
        return CONTROL_PORT.TIPE1.LONG;
    }else if (factor == 1){
        return CONTROL_PORT.TIPE2.LONG;
    }else if (factor == 2){
        return CONTROL_PORT.TIPE3.LONG;
    }else if (factor == 3){
        return CONTROL_PORT.TIPE4.LONG;
    }else if (factor == 4){
        return CONTROL_PORT.TIPE5.LONG;
    }else if (factor == 5){
        return CONTROL_PORT.TIPE6.LONG;
    }else if (factor == 6){
        return CONTROL_PORT.TIPE7.LONG;
    }else if (factor == 7){
        return CONTROL_PORT.TIPE8.LONG;
    }
    return 99;
}//}}}

unsigned int GetErrorECMDCLSINT(unsigned int factor)
{//{{{
    if (factor == 2-2){
        return CONTROL_PORT.DCLSINT1.LONG;
    }else if (factor == 3-2){
        return CONTROL_PORT.DCLSINT2.LONG;
    }else if (factor == 4-2){
        return CONTROL_PORT.DCLSINT3.LONG;
    }else if (factor == 5-2){
        return CONTROL_PORT.DCLSINT4.LONG;
    }else if (factor == 6-2){
        return CONTROL_PORT.DCLSINT5.LONG;
    }else if (factor == 7-2){
        return CONTROL_PORT.DCLSINT6.LONG;
    }else if (factor == 8-2){
        return CONTROL_PORT.DCLSINT7.LONG;
    }else if (factor == 9-2){
        return CONTROL_PORT.DCLSINT8.LONG;
    }
    return 99;
}//}}}
#endif
// vim600: set foldmethod=marker :
