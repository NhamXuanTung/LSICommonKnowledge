#ifndef __COMMON_DRV_H__
#define __COMMON_DRV_H__
#include "iodefine_model_rvc.h"
#include "iodefine_general_io.h"
#include "iodefine_control_port.h" 

#define CONTROL_PORT (*(volatile struct st_control_port *)0xFFF80000)


#define RESVAL                      4002                                //    This macro is used to check reset value of all output ports/registers when all reset active
#define RES1VAL                     4003                                //    This macro is used to check reset value of all output ports/registers when preset_n active
#define RES2VAL                     4004                                //    This macro is used to check reset value of all output ports/registers when cntclk_preset_n active
#define RES3VAL                     4005                                //    This macro is used to check reset value of all output ports/registers when erroutresz active
#define RES4VAL                     4006                                //    This macro is used to check reset value of all output ports/registers when cntclk_erroutresz active
#define RES5VAL                     4007                                //    This macro is used to check reset value of all output ports/registers when resstg1z active
#define RES6VAL                     4008                                //    This macro is used to check reset value of all output ports/registers when pclkin_resstg1z active
#define RES7VAL                     4009                                //    This macro is used to check reset value of all output ports/registers when erroutresz_for_sync active
#define CAPALLVAL                   4010                                //    This macro is used to check value of all output ports/registers after capture all error source
#define PE_CAPALLVAL                4011                                //    This macro is used to check value of all output ports/registers after capture all pseudo error
#define NEQZERO                     4012                                //    This macro is used to check value of registers != 0
#define ERR_ACTIVE_NUM              307                                 //    The number error (include reserved errors; exclude error306, ECM compare match error, timeout error)
//////{{{ Access target model
#define ECMM_base                   0xFFCB0000                          //ECM's registers    -
#define ECMC_base                   0xFFCB1000                          //    -
#define ECM_base                    0xFFCB2000                          //    -
#define REG_ECMMESET                (ECMM_base)                         //    -
#define REG_ECMCESET                (ECMC_base)                         //    -
#define REG_ECMMECLR                (ECMM_base + 0x04)                  //    -
#define REG_ECMCECLR                (ECMC_base + 0x04)                  //    -
#define REG_ECMMESSTR(n)            (ECMM_base + 0x08 + 0x4*n)          //    n: 0 -> 9
#define REG_ECMCESSTR(n)            (ECMC_base + 0x08 + 0x4*n)          //    n: 0 -> 9
#define REG_ECMEPCFG                (ECM_base)                          //    -
#define REG_ECMMICFG(n)             (ECM_base + 0x04 + 0x4*n)           //    n: 0 -> 9
#define REG_ECMNMICFG(n)            (ECM_base + 0x2C + 0x4*n)           //    n: 0 -> 9
#define REG_ECMIRCFG(n)             (ECM_base + 0x54 + 0x4*n)           //    n: 0 -> 9
#define REG_ECMEMK(n)               (ECM_base + 0x7C + 0x4*n)           //    n: 0 -> 9
#define REG_ECMESSTC(n)             (ECM_base + 0xA4 + 0x4*n)           //    n: 0 -> 9
#define REG_ECMKCPROT               (ECM_base + 0xCC)                   //    -
#define REG_ECMPE(n)                (ECM_base + 0xD0 + 0x4*n)           //    n: 0 -> 9
#define REG_ECMDTMCTL               (ECM_base + 0xF8)                   //    -
#define REG_ECMDTMR                 (ECM_base + 0xFC)                   //    -
#define REG_ECMDTMCMP               (ECM_base + 0x100)                  //    -
#define REG_ECMMIDTMCFG(n)          (ECM_base + 0x104 + 0x4*n)          //    n: 0 -> 9
#define REG_ECMNMIDTMCFG(n)         (ECM_base + 0x12C + 0x4*n)          //    n: 0 -> 9
#define REG_ECMEOCCFG               (ECM_base + 0x154)                  //    -
#define REG_ECMPEM                  (ECM_base + 0x158)                  //    -
#define REGS_LIST                   5000                                //    This macro is used to check all registers
#define REG_ESSTRs                  5001                                //    This macro is used to check all status registers
#define REG_PSEUDO                  5002                                //    This macro is used to create pseudo error
#define ERROUT0                     5003                                //    ERROUT status = 0
#define ERROUT1                     5004                                //    ERROUT status = 1
#define ERR308OUT0                  5005                                //    ECM compare error status = 0
#define ERR308OUT1                  5006                                //    ECM compare error status = 1
#define ERR309OUT0                  5007                                //    Timeout error status = 0
#define ERR309OUT1                  5008                                //    Timeout error status = 1
#define ERR310OUT0                  5009                                //    ECMESET status = 0
#define ERR310OUT1                  5010                                //    ECMESET status = 1
#define ERR306OUT0                  5011                                //    Error 306 status = 0
#define ERR306OUT1                  5012                                //    Error 306 status = 1
#define REG_MESST07(n)              (5020 + n)                          //    n: 0 -> 7: Error status 0 -> 7
#define REG_CESST07(n)              (5030 + n)                          //    n: 0 -> 7: Error status 0 -> 7
#define PROTECTWRITE_DIS            0xA5A5A501                          //    Disable write protection => protected register can be written
#define PROTECTWRITE_EN             0xA5A5A500                          //    Enable write protection => protected register can NOT be written

#define BYTE0_type                  10                                  //Type of accessing (read/write access size)    -
#define BYTE1_type                  11                                  //                                              -
#define BYTE2_type                  12                                  //                                              -
#define BYTE3_type                  13                                  //                                              -
#define BYTES_type                  1                                   //                                              -
#define WORD0_type                  20                                  //                                              -
#define WORD1_type                  21                                  //                                              -
#define WORDS_type                  2                                   //                                              -
#define LONG_type                   4                                   //                                              -

#define MODEL_REGS(n)               (*(volatile struct st_modelRVC_reg *)n)
/*********************************
Function: Common_ReadReg
Description: Check value of register
(0: returned value != expected value;
1: returned value == expected value)
Parameter:
    reg_name
          REG_XXX: name of XXX register
    size
          Read access size (BYTES, WORDS, LONG)
    exp_val
          Expected value of register
**********************************/
unsigned int Common_ReadReg(const unsigned int reg_name, const unsigned int size, const unsigned int exp_val){
    unsigned int ret = 1;
    unsigned int n = 0;
    unsigned int reg_val = 0;
    switch (size){
        case BYTE0_type:
            if (exp_val == NEQZERO) {
                if (MODEL_REGS(reg_name).MODEL_REG.BYTES.BYTE0 == 0) { ret = 0; }
            } else {
                if (MODEL_REGS(reg_name).MODEL_REG.BYTES.BYTE0 != (exp_val&0xFF)) { ret = 0; }
            }
            break;
        case BYTE1_type:
            if (MODEL_REGS(reg_name).MODEL_REG.BYTES.BYTE1 != ((exp_val>>8)&0xFF)) { ret = 0; }
            break;
        case BYTE2_type:
            if (MODEL_REGS(reg_name).MODEL_REG.BYTES.BYTE2 != ((exp_val>>16)&0xFF)) { ret = 0; }
            break;
        case BYTE3_type:
            if (MODEL_REGS(reg_name).MODEL_REG.BYTES.BYTE3 != ((exp_val>>24)&0xFF)) { ret = 0; }
            break;
        case WORD0_type:
            if (exp_val == NEQZERO) {
                if (MODEL_REGS(reg_name).MODEL_REG.WORDS.WORD0 == 0) { ret = 0; }
            } else {
                if (MODEL_REGS(reg_name).MODEL_REG.WORDS.WORD0 != (exp_val&0xFFFF)) { ret = 0; }
            }
            break;
        case WORD1_type:
            if (MODEL_REGS(reg_name).MODEL_REG.WORDS.WORD1 != ((exp_val>>16)&0xFFFF)) { ret = 0; }
            break;
        case BYTES_type:
            if (MODEL_REGS(reg_name).MODEL_REG.BYTES.BYTE0 != (exp_val&0xFF)) { ret = 0; }
            if (MODEL_REGS(reg_name).MODEL_REG.BYTES.BYTE1 != ((exp_val>>8)&0xFF)) { ret = 0; }
            if (MODEL_REGS(reg_name).MODEL_REG.BYTES.BYTE2 != ((exp_val>>16)&0xFF)) { ret = 0; }
            if (MODEL_REGS(reg_name).MODEL_REG.BYTES.BYTE3 != ((exp_val>>24)&0xFF)) { ret = 0; }
            break;
        case WORDS_type:
            if (MODEL_REGS(reg_name).MODEL_REG.WORDS.WORD0 != (exp_val&0xFFFF)) { ret = 0; }
            if (MODEL_REGS(reg_name).MODEL_REG.WORDS.WORD1 != ((exp_val>>16)&0xFFFF)) { ret = 0; }
            break;
        case LONG_type:
            if (reg_name == REGS_LIST) {
                if (exp_val == RESVAL) { //Reset value
                    //Master
                    if (MODEL_REGS(REG_ECMMESET).MODEL_REG.BYTES.BYTE0 != 0) { ret = 0; }//size 8
                    if (MODEL_REGS(REG_ECMMECLR).MODEL_REG.BYTES.BYTE0 != 0) { ret = 0; }//size 8
                    for (n = 0; n < 9; n++){
                        if (MODEL_REGS(REG_ECMMESSTR(n)).MODEL_REG.LONG != 0) { ret = 0; }//size 32
                    }
                    if ((0xFBFFFFFF & MODEL_REGS(REG_ECMMESSTR(9)).MODEL_REG.LONG) != 0) { ret = 0; }//not reset bit 26
                    //Checker
                    if (MODEL_REGS(REG_ECMCESET).MODEL_REG.BYTES.BYTE0 != 0) { ret = 0; }//size 8
                    if (MODEL_REGS(REG_ECMCECLR).MODEL_REG.BYTES.BYTE0 != 0) { ret = 0; }//size 8
                    for (n = 0; n < 9; n++){
                        if (MODEL_REGS(REG_ECMCESSTR(n)).MODEL_REG.LONG != 0) { ret = 0; }//size 32
                    }
                    if ((0xFBFFFFFF & MODEL_REGS(REG_ECMCESSTR(9)).MODEL_REG.LONG) != 0) { ret = 0; }//not reset bit 26
                    //Common
                    if (MODEL_REGS(REG_ECMEPCFG).MODEL_REG.BYTES.BYTE0  != 0)       { ret = 0; }//size 8
                    if (MODEL_REGS(REG_ECMIRCFG(0)).MODEL_REG.LONG      != 0x10000) { ret = 0; }//size 32
                    if (MODEL_REGS(REG_ECMDTMCTL).MODEL_REG.BYTES.BYTE0 != 0x0)     { ret = 0; }//size 8
                    if (MODEL_REGS(REG_ECMDTMR).MODEL_REG.WORDS.WORD0   != 0x0)     { ret = 0; }//size 16
                    if (MODEL_REGS(REG_ECMEMK(0)).MODEL_REG.LONG != 0xC0C0F0F0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(1)).MODEL_REG.LONG != 0xC0C0C0C0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(2)).MODEL_REG.LONG != 0xC0FFFFC0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(3)).MODEL_REG.LONG != 0xC0FFC0C0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(4)).MODEL_REG.LONG != 0xFFFFFFC0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(5)).MODEL_REG.LONG != 0xC00001F0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(6)).MODEL_REG.LONG != 0xF8F0FFFF) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(7)).MODEL_REG.LONG != 0x80E0F0F8) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(8)).MODEL_REG.LONG != 0xFFFFFFFF) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(9)).MODEL_REG.LONG != 0xCC040E00) { ret = 0; }
                    for (n = (REG_ECMMICFG(0)); n <= (REG_ECMPEM); n = n+4){
                        if ((n != REG_ECMIRCFG(0)) && (n != REG_ECMDTMCTL) && (n != REG_ECMDTMR) && (n < REG_ECMEMK(0) || n > REG_ECMEMK(9))){
                            if (MODEL_REGS(n).MODEL_REG.LONG != 0) { ret = 0; }//size 32
                        }
                    }
                } else if (exp_val == RES1VAL){ //Reset by presetn: Reset registers (other than ECMmESSTRn, ECMEOCCFG)
                    //Master
                    if (MODEL_REGS(REG_ECMMESET).MODEL_REG.BYTES.BYTE0 != 0) { ret = 0; }//size 8
                    if (MODEL_REGS(REG_ECMMECLR).MODEL_REG.BYTES.BYTE0 != 0) { ret = 0; }//size 8
                    //Checker
                    if (MODEL_REGS(REG_ECMCESET).MODEL_REG.BYTES.BYTE0 != 0) { ret = 0; }//size 8
                    if (MODEL_REGS(REG_ECMCECLR).MODEL_REG.BYTES.BYTE0 != 0) { ret = 0; }//size 8
                    //Common
                    if (MODEL_REGS(REG_ECMEPCFG).MODEL_REG.BYTES.BYTE0  != 0)       { ret = 0; }//size 8
                    if (MODEL_REGS(REG_ECMIRCFG(0)).MODEL_REG.LONG      != 0x10000) { ret = 0; }//size 32
                    if (MODEL_REGS(REG_ECMDTMCTL).MODEL_REG.BYTES.BYTE0 != 0x0)     { ret = 0; }//size 8
                    if (MODEL_REGS(REG_ECMDTMR).MODEL_REG.WORDS.WORD0   != 0x0)     { ret = 0; }//size 16
                    if (MODEL_REGS(REG_ECMEMK(0)).MODEL_REG.LONG != 0xC0C0F0F0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(1)).MODEL_REG.LONG != 0xC0C0C0C0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(2)).MODEL_REG.LONG != 0xC0FFFFC0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(3)).MODEL_REG.LONG != 0xC0FFC0C0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(4)).MODEL_REG.LONG != 0xFFFFFFC0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(5)).MODEL_REG.LONG != 0xC00001F0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(6)).MODEL_REG.LONG != 0xF8F0FFFF) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(7)).MODEL_REG.LONG != 0x80E0F0F8) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(8)).MODEL_REG.LONG != 0xFFFFFFFF) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(9)).MODEL_REG.LONG != 0xCC040E00) { ret = 0; }
                    for (n = (REG_ECMMICFG(0)); n <= (REG_ECMPEM); n = n+4){
                        if ((n != REG_ECMIRCFG(0)) && (n != REG_ECMDTMCTL) && (n != REG_ECMDTMR) && (n < REG_ECMEMK(0) || n > REG_ECMEMK(9)) &&
                            (n != REG_ECMEOCCFG)){
                            if (MODEL_REGS(n).MODEL_REG.LONG != 0) { ret = 0; }//size 32
                        }
                    }
                } else if (exp_val == RES2VAL){ //Reset by cntclk_preset_n: not effect to registers
                    ret = 1; //not effect to registers
                } else if (exp_val == RES3VAL){ //Reset by erroutresz: Reset ECMEOCCFG
                    if (MODEL_REGS(REG_ECMEOCCFG).MODEL_REG.LONG != 0) { ret = 0; }//size 32
                } else if (exp_val == RES4VAL){ //Reset by cntclk_erroutresz: not effect to registers
                    ret = 1; //not effect to registers
                } else if (exp_val == RES5VAL){ //Reset by resstg1z: Reset ECMmESSTR9 (bit 30)
                    if (((MODEL_REGS(REG_ECMMESSTR(9)).MODEL_REG.LONG >> 30)&0x1) != 0) { ret = 0; }//size 32
                    if (((MODEL_REGS(REG_ECMCESSTR(9)).MODEL_REG.LONG >> 30)&0x1) != 0) { ret = 0; }//size 32
                } else if (exp_val == RES6VAL){ //Reset by pclkin_resstg1z: Reset ECMmESSTR other than ECMmESSTR9 (bits 30 & 26)
                    for (n = 0; n < 9; n++){
                        if (MODEL_REGS(REG_ECMMESSTR(n)).MODEL_REG.LONG != 0) { ret = 0; }//size 32
                    }
                    if ((0xBBFFFFFF & MODEL_REGS(REG_ECMMESSTR(9)).MODEL_REG.LONG) != 0) { ret = 0; }//not reset bits 30 & 26
                    for (n = 0; n < 9; n++){
                        if (MODEL_REGS(REG_ECMCESSTR(n)).MODEL_REG.LONG != 0) { ret = 0; }//size 32
                    }
                    if ((0xBBFFFFFF & MODEL_REGS(REG_ECMCESSTR(9)).MODEL_REG.LONG) != 0) { ret = 0; }//not reset bits 30 & 26
                } else if (exp_val == RES7VAL){ //Reset by erroutresz_for_sync: not effect to registers
                    ret = 1; //not effect to registers
                } else if (exp_val == PROTECTWRITE_EN){ //Enable write protection => protected register can NOT be written
                    //Master
                    if (MODEL_REGS(REG_ECMMESET).MODEL_REG.BYTES.BYTE0 != 0) { ret = 0; }//size 8
                    if (MODEL_REGS(REG_ECMMECLR).MODEL_REG.BYTES.BYTE0 != 0) { ret = 0; }//size 8
                    //Checker
                    if (MODEL_REGS(REG_ECMCESET).MODEL_REG.BYTES.BYTE0 != 0) { ret = 0; }//size 8
                    if (MODEL_REGS(REG_ECMCECLR).MODEL_REG.BYTES.BYTE0 != 0) { ret = 0; }//size 8
                    //Common
                    if (MODEL_REGS(REG_ECMEPCFG).MODEL_REG.BYTES.BYTE0  != 0)       { ret = 0; }//size 8
                    if (MODEL_REGS(REG_ECMIRCFG(0)).MODEL_REG.LONG      != 0x10000) { ret = 0; }//size 32
                    if (MODEL_REGS(REG_ECMEMK(0)).MODEL_REG.LONG != 0xC0C0F0F0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(1)).MODEL_REG.LONG != 0xC0C0C0C0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(2)).MODEL_REG.LONG != 0xC0FFFFC0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(3)).MODEL_REG.LONG != 0xC0FFC0C0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(4)).MODEL_REG.LONG != 0xFFFFFFC0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(5)).MODEL_REG.LONG != 0xC00001F0) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(6)).MODEL_REG.LONG != 0xF8F0FFFF) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(7)).MODEL_REG.LONG != 0x80E0F0F8) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(8)).MODEL_REG.LONG != 0xFFFFFFFF) { ret = 0; }
                    if (MODEL_REGS(REG_ECMEMK(9)).MODEL_REG.LONG != 0xCC040E00) { ret = 0; }
                    if (MODEL_REGS(REG_ECMDTMCTL).MODEL_REG.BYTES.BYTE0 != 0x0)     { ret = 0; }//size 8
                    for (n = (REG_ECMMICFG(0)); n <= (REG_ECMPEM); n = n+4){
                        if ((n != REG_ECMIRCFG(0)) && (n < REG_ECMEMK(0) || n > REG_ECMEMK(9)) && (n != REG_ECMKCPROT) &&
                            (n != REG_ECMDTMCTL) && (n != REG_ECMDTMR) && (n != REG_ECMPEM)){
                            if (MODEL_REGS(n).MODEL_REG.LONG != 0) { ret = 0; }//size 32
                        }
                    }
                }
            } else if (reg_name == REG_ESSTRs) {
                if (exp_val == CAPALLVAL) { //Captured value
                    if (MODEL_REGS(REG_ECMMESSTR(0)).MODEL_REG.LONG != 0xFFFF5555) { ret = 0; }//size 32
                    if (MODEL_REGS(REG_ECMCESSTR(0)).MODEL_REG.LONG != 0xFFFF5555) { ret = 0; }//size 32
                    for (n = 1; n <= 8; n++){
                        if (MODEL_REGS(REG_ECMMESSTR(n)).MODEL_REG.LONG != 0xFFFFFFFF) { ret = 0; }//size 32
                        if (MODEL_REGS(REG_ECMCESSTR(n)).MODEL_REG.LONG != 0xFFFFFFFF) { ret = 0; }//size 32
                    }
                    if ((0x0FFFFFFF & MODEL_REGS(REG_ECMMESSTR(9)).MODEL_REG.LONG) != 0x0FFFFFFF) { ret = 0; }//size 32 (not include error 308, 309)
                    if ((0x0FFFFFFF & MODEL_REGS(REG_ECMCESSTR(9)).MODEL_REG.LONG) != 0x0FFFFFFF) { ret = 0; }//size 32 (not include error 308, 309)
                } else if (exp_val == PE_CAPALLVAL) { //Captured value by pseudo error
                    if (MODEL_REGS(REG_ECMMESSTR(0)).MODEL_REG.LONG != 0xFFFF5555) { ret = 0; }//size 32
                    if (MODEL_REGS(REG_ECMCESSTR(0)).MODEL_REG.LONG != 0xFFFF5555) { ret = 0; }//size 32
                    for (n = 1; n <= 8; n++){
                        if (MODEL_REGS(REG_ECMMESSTR(n)).MODEL_REG.LONG != 0xFFFFFFFF) { ret = 0; }//size 32
                        if (MODEL_REGS(REG_ECMCESSTR(n)).MODEL_REG.LONG != 0xFFFFFFFF) { ret = 0; }//size 32
                    }
                    if ((0x3FFFFFFF & MODEL_REGS(REG_ECMMESSTR(9)).MODEL_REG.LONG) != 0x33FFFFFF) { ret = 0; }//size 32 (not include error 306, 307)
                    if ((0x3FFFFFFF & MODEL_REGS(REG_ECMCESSTR(9)).MODEL_REG.LONG) != 0x33FFFFFF) { ret = 0; }//size 32 (not include error 306, 307)
                } else if (exp_val == 0) {
                    for (n = 0; n <= 8; n++){
                        if (MODEL_REGS(REG_ECMMESSTR(n)).MODEL_REG.LONG != 0) { ret = 0; }//size 32
                        if (MODEL_REGS(REG_ECMCESSTR(n)).MODEL_REG.LONG != 0) { ret = 0; }//size 32
                    }
                    if (((MODEL_REGS(REG_ECMMESSTR(9)).MODEL_REG.LONG)&0x1FFFFFFF) != 0) { ret = 0; }//size 32 (not include error 309)
                    if (((MODEL_REGS(REG_ECMCESSTR(9)).MODEL_REG.LONG)&0x1FFFFFFF) != 0) { ret = 0; }//size 32 (not include error 309)
                } else if (exp_val == NEQZERO) {
                    for (n = 0; n <= 9; n++){
                        if (MODEL_REGS(REG_ECMMESSTR(n)).MODEL_REG.LONG == 0) { ret = 0; }//size 32
                        if (MODEL_REGS(REG_ECMCESSTR(n)).MODEL_REG.LONG == 0) { ret = 0; }//size 32
                    }
                }
            } else if (reg_name >= REG_MESST07(0) && reg_name <= REG_MESST07(7)){
                n = reg_name - REG_MESST07(0);
                reg_val = (unsigned int)MODEL_REGS(REG_ECMMESSTR(0)).MODEL_REG.LONG;
                if (((reg_val>> (n*2))&0x3) != (exp_val&0x3)) { ret = 0; }
            } else if (reg_name >= REG_CESST07(0) && reg_name <= REG_CESST07(7)){
                n = reg_name - REG_CESST07(0);
                reg_val = (unsigned int)MODEL_REGS(REG_ECMCESSTR(0)).MODEL_REG.LONG;
                if (((reg_val>> (n*2))&0x3) != (exp_val&0x3)) { ret = 0; }
            } else {
                if (exp_val == ERROUT0) {
                    if (reg_name == REG_ECMMESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMMESSTR(9)).MODEL_REG.LONG >> 31)&0x1) != 0) { ret = 0; }//size 32
                    } else if (reg_name == REG_ECMCESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMCESSTR(9)).MODEL_REG.LONG >> 31)&0x1) != 0) { ret = 0; }//size 32
                    }
                } else if (exp_val == ERROUT1) {
                    if (reg_name == REG_ECMMESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMMESSTR(9)).MODEL_REG.LONG >> 31)&0x1) != 1) { ret = 0; }//size 32
                    } else if (reg_name == REG_ECMCESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMCESSTR(9)).MODEL_REG.LONG >> 31)&0x1) != 1) { ret = 0; }//size 32
                    }
                } else if (exp_val == ERR308OUT0) {
                    if (reg_name == REG_ECMMESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMMESSTR(9)).MODEL_REG.LONG >> 28)&0x1) != 0) { ret = 0; }//size 32
                    } else if (reg_name == REG_ECMCESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMCESSTR(9)).MODEL_REG.LONG >> 28)&0x1) != 0) { ret = 0; }//size 32
                    }
                } else if (exp_val == ERR308OUT1) {
                    if (reg_name == REG_ECMMESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMMESSTR(9)).MODEL_REG.LONG >> 28)&0x1) != 1) { ret = 0; }//size 32
                    } else if (reg_name == REG_ECMCESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMCESSTR(9)).MODEL_REG.LONG >> 28)&0x1) != 1) { ret = 0; }//size 32
                    }
                } else if (exp_val == ERR309OUT0) {
                    if (reg_name == REG_ECMMESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMMESSTR(9)).MODEL_REG.LONG >> 29)&0x1) != 0) { ret = 0; }//size 32
                    } else if (reg_name == REG_ECMCESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMCESSTR(9)).MODEL_REG.LONG >> 29)&0x1) != 0) { ret = 0; }//size 32
                    }
                } else if (exp_val == ERR309OUT1) {
                    if (reg_name == REG_ECMMESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMMESSTR(9)).MODEL_REG.LONG >> 29)&0x1) != 1) { ret = 0; }//size 32
                    } else if (reg_name == REG_ECMCESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMCESSTR(9)).MODEL_REG.LONG >> 29)&0x1) != 1) { ret = 0; }//size 32
                    }
                } else if (exp_val == ERR310OUT0) {
                    if (reg_name == REG_ECMMESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMMESSTR(9)).MODEL_REG.LONG >> 30)&0x1) != 0) { ret = 0; }//size 32
                    } else if (reg_name == REG_ECMCESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMCESSTR(9)).MODEL_REG.LONG >> 30)&0x1) != 0) { ret = 0; }//size 32
                    }
                } else if (exp_val == ERR310OUT1) {
                    if (reg_name == REG_ECMMESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMMESSTR(9)).MODEL_REG.LONG >> 30)&0x1) != 1) { ret = 0; }//size 32
                    } else if (reg_name == REG_ECMCESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMCESSTR(9)).MODEL_REG.LONG >> 30)&0x1) != 1) { ret = 0; }//size 32
                    }
                } else if (exp_val == ERR306OUT0) {
                    if (reg_name == REG_ECMMESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMMESSTR(9)).MODEL_REG.LONG >> 26)&0x1) != 0) { ret = 0; }//size 32
                    } else if (reg_name == REG_ECMCESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMCESSTR(9)).MODEL_REG.LONG >> 26)&0x1) != 0) { ret = 0; }//size 32
                    }
                } else if (exp_val == ERR306OUT1) {
                    if (reg_name == REG_ECMMESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMMESSTR(9)).MODEL_REG.LONG >> 26)&0x1) != 1) { ret = 0; }//size 32
                    } else if (reg_name == REG_ECMCESSTR(9)) {
                        if (((MODEL_REGS(REG_ECMCESSTR(9)).MODEL_REG.LONG >> 26)&0x1) != 1) { ret = 0; }//size 32
                    }
                } else if (exp_val == NEQZERO) {
                    if (MODEL_REGS(reg_name).MODEL_REG.LONG == 0) { ret = 0; }
                } else {
                    if (MODEL_REGS(reg_name).MODEL_REG.LONG != (exp_val&0xFFFFFFFF)) { ret = 0; }
                }
            }
            break;
        default:
            ret = 0;
            break;
    }
    return ret;
}

/*********************************
Function: Common_WriteReg
Description: Write a value into register
Parameter:
    reg_name
          REG_XXX: name of XXX register
    size
          Write access size (BYTE0_type -> BYTE3_type, WORD0_type -> WORD1_type, LONG_type)
    val
          Written value
**********************************/
void Common_WriteReg(unsigned int reg_name, unsigned int size, unsigned int val){
    unsigned int n = 0;
    unsigned int reg_val = 0;
    switch (size){
        case BYTE0_type:
            MODEL_REGS(reg_name).MODEL_REG.BYTES.BYTE0 = val&0xFF;
            break;
        case BYTE1_type:
            MODEL_REGS(reg_name).MODEL_REG.BYTES.BYTE1 = val&0xFF;
            break;
        case BYTE2_type:
            MODEL_REGS(reg_name).MODEL_REG.BYTES.BYTE2 = val&0xFF;
            break;
        case BYTE3_type:
            MODEL_REGS(reg_name).MODEL_REG.BYTES.BYTE3 = val&0xFF;
            break;
        case WORD0_type:
            MODEL_REGS(reg_name).MODEL_REG.WORDS.WORD0 = val&0xFFFF;
            break;
        case WORD1_type:
            MODEL_REGS(reg_name).MODEL_REG.WORDS.WORD1 = val&0xFFFF;
            break;
        case LONG_type:
            if (reg_name == REGS_LIST) {
                MODEL_REGS(REG_ECMMESET).MODEL_REG.BYTES.BYTE0 = val&0xFF;
                MODEL_REGS(REG_ECMMECLR).MODEL_REG.BYTES.BYTE0 = val&0xFF;
                for (n = (REG_ECMMESSTR(0)); n <= (REG_ECMMESSTR(9)); n = n+4){
                    MODEL_REGS(n).MODEL_REG.LONG = val&0xFFFFFFFF;
                }
                MODEL_REGS(REG_ECMCESET).MODEL_REG.BYTES.BYTE0 = val&0xFF;
                MODEL_REGS(REG_ECMCECLR).MODEL_REG.BYTES.BYTE0 = val&0xFF;
                for (n = (REG_ECMCESSTR(0)); n <= (REG_ECMCESSTR(9)); n = n+4){
                    MODEL_REGS(n).MODEL_REG.LONG = val&0xFFFFFFFF;
                }
                MODEL_REGS(REG_ECMEPCFG).MODEL_REG.BYTES.BYTE0 = val&0xFF;
                if (val&0x3 == 0x3) {
                    MODEL_REGS(REG_ECMDTMCTL).MODEL_REG.BYTES.BYTE0 = val&0xFD;
                } else {
                    MODEL_REGS(REG_ECMDTMCTL).MODEL_REG.BYTES.BYTE0 = val&0xFF;
                }
                MODEL_REGS(REG_ECMDTMR).MODEL_REG.WORDS.WORD0 = val&0xFFFF;
                for (n = (REG_ECMMICFG(0)); n <= (REG_ECMPEM); n = n+4){
                    if ((n != REG_ECMDTMCTL) && (n != REG_ECMDTMR)){
                        MODEL_REGS(n).MODEL_REG.LONG = val&0xFFFFFFFF;
                    }
                }
            } else if (reg_name == REG_PSEUDO) {
                if (val <= 7) {
                    reg_val = MODEL_REGS(REG_ECMPE(0)).MODEL_REG.LONG;
                    MODEL_REGS(REG_ECMPE(0)).MODEL_REG.LONG = reg_val | (1 << (val*2));
                } else if (val <= 23) {
                    reg_val = MODEL_REGS(REG_ECMPE(0)).MODEL_REG.LONG;
                    MODEL_REGS(REG_ECMPE(0)).MODEL_REG.LONG = reg_val | (1 << (val+8));
                } else if (val <= 309) {
                    n = 1 + (unsigned int)((val - 24)/32);
                    reg_val = MODEL_REGS(REG_ECMPE(n)).MODEL_REG.LONG;
                    MODEL_REGS(REG_ECMPE(n)).MODEL_REG.LONG = reg_val | (1 << (val + 8 - (32*n)));
                }
            } else {
                MODEL_REGS(reg_name).MODEL_REG.LONG = val&0xFFFFFFFF;
            }
            break;
        default:
            break;
    }
}

/*********************************
Function: ClearInitErrorOut
Description: Clear initial value of ERROROUT
Parameter:
    None
**********************************/
void ClearInitErrorOut(void){
    unsigned int i = 0;
    MODEL_REGS(REG_ECMKCPROT).MODEL_REG.LONG = PROTECTWRITE_DIS;
    for(i = 0;i < 50;i++);
    MODEL_REGS(REG_ECMPEM).MODEL_REG.LONG = 0x3;
    for(i = 0;i < 50;i++);
    MODEL_REGS(REG_ECMMECLR).MODEL_REG.BYTES.BYTE0 = 0x1;
    MODEL_REGS(REG_ECMCECLR).MODEL_REG.BYTES.BYTE0 = 0x1;
    for(i = 0;i < 1000;i++);
    MODEL_REGS(REG_ECMPEM).MODEL_REG.LONG = 0x0;
    for(i = 0;i < 50;i++);
}

/*********************************
Function: ClearAllErrorStatus
Description: Clear all error status
Parameter:
    None
**********************************/
void ClearAllErrorStatus(void){
    unsigned int i = 0;
    MODEL_REGS(REG_ECMKCPROT).MODEL_REG.LONG = PROTECTWRITE_DIS;
    for(i = 0;i < 50;i++);
    for (i = 0; i <= 9; i++){
        MODEL_REGS(REG_ECMESSTC(i)).MODEL_REG.LONG = 0xFFFFFFFF;
    }
    for(i = 0;i < 50;i++);
}
//////}}}
//////{{{ Access generalIO model
#define DUMMY_PERIPHERAL            (*(volatile struct st_general_io *)0xFFD20000)

#define preset_n                    0                                   //ECM's reset signals    -
#define cntclk_preset_n             1                                   //    -
#define erroutresz                  2                                   //    -
#define cntclk_erroutresz           3                                   //    -
#define resstg1z                    4                                   //    -
#define pclkin_resstg1z             5                                   //    -
#define erroutresz_for_sync         6                                   //    
#define pclk                        7                                   //ECM's clock signals    -
#define cntclk                      8                                   //    -
#define ecmterrin(n)                (1000 + n)                          //Other ECM's input signals    n: 0 -> 309
#define ecmterrlbz_m                2001                                //    -
#define ecmterrlbz_c                2002                                //    -
#define ecmttin                     2003                                //    -
#define ecmterroz                   3001                                //ECM's output signals    -
#define ecmterroutz_m               3002                                //    -
#define ecmterroutz_c               3003                                //    -
#define ecmti_pe(n)                 (3010 + n)                          //    n: 0 -> 7
#define ecmtnmi                     3020                                //    -
#define ecmdclsint(n)               (3030 + n)                          //    n: 0 -> 7
#define ecmtresz                    3040                                //    -
#define global_errclr               3041                                //    -
#define OPORTS_LIST                 4000                                //    This macro is used to check all output ports
#define OPORTS_INITVAL              4001                                //    This macro is used to check initial value of all output ports

/*********************************
Function: DPeripheral_Pass
Description: Check TM pass
Parameter: None
**********************************/
void DPeripheral_Pass(void){
    DUMMY_PERIPHERAL.JUDGE_REG.LONG = 1;
}

/*********************************
Function: DPeripheral_Fail
Description: Check TM fail
Parameter: None
**********************************/
void DPeripheral_Fail(void){
    DUMMY_PERIPHERAL.JUDGE_REG.LONG = 0;
}

/*********************************
Function: DPeripheral_SetCLKfreq
Description: Set clock frequency
Parameter:
    clk_name
          Name of clock port
          (pclk, cntclk)
    value
          Frequency clock (Hz)
**********************************/
void DPeripheral_SetCLKfreq(unsigned int clk_name, unsigned int value){
    switch (clk_name){
        case pclk:
            DUMMY_PERIPHERAL.CLKL_REG0.LONG = value;
            break;
        case cntclk:
            DUMMY_PERIPHERAL.CLKL_REG1.LONG = value;
            break;
        default:
            break;
    }
}

/*********************************
Function: DPeripheral_Set64bitCLKfreq
Description: Set clock frequency
Parameter:
    clk_name
          Name of clock port
          (pclk, cntclk)
    high_value
          Frequency clock (32 high bits) (Hz)
    low_value
          Frequency clock (32 low bit) (Hz)
**********************************/
void DPeripheral_Set64bitCLKfreq(unsigned int clk_name, unsigned int high_value, unsigned int low_value){
    switch (clk_name){
        case pclk:
            DUMMY_PERIPHERAL.CLKH_REG0.LONG = high_value;
            DUMMY_PERIPHERAL.CLKL_REG0.LONG = low_value;
            break;
        case cntclk:
            DUMMY_PERIPHERAL.CLKH_REG1.LONG = high_value;
            DUMMY_PERIPHERAL.CLKL_REG1.LONG = low_value;
            break;
        default:
            break;
    }
}

/*********************************
Function: DPeripheral_SetResetValue
Description: Assert/De-assert reset
Parameter:
    res_name
          Name of reset port
          (preset_n, cntclk_preset_n, erroutresz, cntclk_erroutresz, resstg1z, pclkin_resstg1z)
    value
          0: Assert reset (active low)/Negate reset (active high)
          1: Negate reset (active low)/Assert reset (active low)
**********************************/
void DPeripheral_SetResetValue(unsigned int res_name, unsigned int value){
    unsigned int tmp = DUMMY_PERIPHERAL.RESET_REG.LONG;
    if(value){ DUMMY_PERIPHERAL.RESET_REG.LONG = tmp | (1 << res_name); }
    else { DUMMY_PERIPHERAL.RESET_REG.LONG = tmp & (~((unsigned int)1 << res_name)); }
}

/*********************************
Function: DPeripheral_IssueSignal
Description: Issue signal to PSEQ model
Parameter:
    port_name
          Name of port
    value
          Value of port
**********************************/
void DPeripheral_IssueSignal(unsigned int port_name, unsigned int value){
    unsigned int n = 0;
    if(value){
        if      (port_name == ecmterrlbz_m) { DUMMY_PERIPHERAL.OBOOL_REG9.LONG = DUMMY_PERIPHERAL.OBOOL_REG9.LONG | (1 << 21); } //309
        else if (port_name == ecmterrlbz_c) { DUMMY_PERIPHERAL.OBOOL_REG9.LONG = DUMMY_PERIPHERAL.OBOOL_REG9.LONG | (1 << 22); } //310
        else if (port_name == ecmttin)      { DUMMY_PERIPHERAL.OBOOL_REG9.LONG = DUMMY_PERIPHERAL.OBOOL_REG9.LONG | (1 << 23); } //311
        else {
            for (n = 0; n < 32; n++){ //0 -> 308
                if      (port_name == ecmterrin(n))    { DUMMY_PERIPHERAL.OBOOL_REG0.LONG = DUMMY_PERIPHERAL.OBOOL_REG0.LONG | (1 << n); break; }
                else if (port_name == ecmterrin(n+32)) { DUMMY_PERIPHERAL.OBOOL_REG1.LONG = DUMMY_PERIPHERAL.OBOOL_REG1.LONG | (1 << n); break; }
                else if (port_name == ecmterrin(n+64)) { DUMMY_PERIPHERAL.OBOOL_REG2.LONG = DUMMY_PERIPHERAL.OBOOL_REG2.LONG | (1 << n); break; }
                else if (port_name == ecmterrin(n+96)) { DUMMY_PERIPHERAL.OBOOL_REG3.LONG = DUMMY_PERIPHERAL.OBOOL_REG3.LONG | (1 << n); break; }
                else if (port_name == ecmterrin(n+128)){ DUMMY_PERIPHERAL.OBOOL_REG4.LONG = DUMMY_PERIPHERAL.OBOOL_REG4.LONG | (1 << n); break; }
                else if (port_name == ecmterrin(n+160)){ DUMMY_PERIPHERAL.OBOOL_REG5.LONG = DUMMY_PERIPHERAL.OBOOL_REG5.LONG | (1 << n); break; }
                else if (port_name == ecmterrin(n+192)){ DUMMY_PERIPHERAL.OBOOL_REG6.LONG = DUMMY_PERIPHERAL.OBOOL_REG6.LONG | (1 << n); break; }
                else if (port_name == ecmterrin(n+224)){ DUMMY_PERIPHERAL.OBOOL_REG7.LONG = DUMMY_PERIPHERAL.OBOOL_REG7.LONG | (1 << n); break; }
                else if (port_name == ecmterrin(n+256)){ DUMMY_PERIPHERAL.OBOOL_REG8.LONG = DUMMY_PERIPHERAL.OBOOL_REG8.LONG | (1 << n); break; }
                else if (port_name == ecmterrin(n+288) && (n < 21)){ DUMMY_PERIPHERAL.OBOOL_REG9.LONG = DUMMY_PERIPHERAL.OBOOL_REG9.LONG | (1 << n); break; }
            }
        }
    } else {
        if      (port_name == ecmterrlbz_m) { DUMMY_PERIPHERAL.OBOOL_REG9.LONG = DUMMY_PERIPHERAL.OBOOL_REG9.LONG & (~((unsigned int)1 << 21)); } //309
        else if (port_name == ecmterrlbz_c) { DUMMY_PERIPHERAL.OBOOL_REG9.LONG = DUMMY_PERIPHERAL.OBOOL_REG9.LONG & (~((unsigned int)1 << 22)); } //310
        else if (port_name == ecmttin)      { DUMMY_PERIPHERAL.OBOOL_REG9.LONG = DUMMY_PERIPHERAL.OBOOL_REG9.LONG & (~((unsigned int)1 << 23)); } //311
        else {
            for (n = 0; n < 32; n++){ //0 -> 308
                if      (port_name == ecmterrin(n))    { DUMMY_PERIPHERAL.OBOOL_REG0.LONG = DUMMY_PERIPHERAL.OBOOL_REG0.LONG & (~((unsigned int)1 << n)); break; }
                else if (port_name == ecmterrin(n+32)) { DUMMY_PERIPHERAL.OBOOL_REG1.LONG = DUMMY_PERIPHERAL.OBOOL_REG1.LONG & (~((unsigned int)1 << n)); break; }
                else if (port_name == ecmterrin(n+64)) { DUMMY_PERIPHERAL.OBOOL_REG2.LONG = DUMMY_PERIPHERAL.OBOOL_REG2.LONG & (~((unsigned int)1 << n)); break; }
                else if (port_name == ecmterrin(n+96)) { DUMMY_PERIPHERAL.OBOOL_REG3.LONG = DUMMY_PERIPHERAL.OBOOL_REG3.LONG & (~((unsigned int)1 << n)); break; }
                else if (port_name == ecmterrin(n+128)){ DUMMY_PERIPHERAL.OBOOL_REG4.LONG = DUMMY_PERIPHERAL.OBOOL_REG4.LONG & (~((unsigned int)1 << n)); break; }
                else if (port_name == ecmterrin(n+160)){ DUMMY_PERIPHERAL.OBOOL_REG5.LONG = DUMMY_PERIPHERAL.OBOOL_REG5.LONG & (~((unsigned int)1 << n)); break; }
                else if (port_name == ecmterrin(n+192)){ DUMMY_PERIPHERAL.OBOOL_REG6.LONG = DUMMY_PERIPHERAL.OBOOL_REG6.LONG & (~((unsigned int)1 << n)); break; }
                else if (port_name == ecmterrin(n+224)){ DUMMY_PERIPHERAL.OBOOL_REG7.LONG = DUMMY_PERIPHERAL.OBOOL_REG7.LONG & (~((unsigned int)1 << n)); break; }
                else if (port_name == ecmterrin(n+256)){ DUMMY_PERIPHERAL.OBOOL_REG8.LONG = DUMMY_PERIPHERAL.OBOOL_REG8.LONG & (~((unsigned int)1 << n)); break; }
                else if (port_name == ecmterrin(n+288) && (n < 21)){ DUMMY_PERIPHERAL.OBOOL_REG9.LONG = DUMMY_PERIPHERAL.OBOOL_REG9.LONG & (~((unsigned int)1 << n)); break; }
            }
        }
    }
}

/*********************************
Function: DPeripheral_ReceiveSignal
Description: Check returned value of signal received from target model
(0: returned value != expected value;
1: returned value == expected value)
Parameter:
    port_name
          Name of port
    exp_val
          Expected raising times of port (for interrupt) or port's value
IBOOL_REG0[0 -> 20] (ecmterroz, ecmterroutz_m, ecmterroutz_c, ecmtresz, ecmtnmi, ecmti_pe[][8], ecmdclsint[][8])
IINTCNT_REG0[7:0] (number ecmtnmi interrupt occurs)
IINTCNT_REG2-1[31:0] (number ecmti_pe[7:0] interrupt occurs)
IINTCNT_REG4-3[31:0] (number ecmdclsint[7:0] interrupt occurs)
**********************************/
unsigned int DPeripheral_ReceiveSignal(unsigned int port_name, unsigned int exp_val){
    unsigned int ret = 0;
    //unsigned int n = 0;
    if      ((port_name == ecmterroz)     && (((DUMMY_PERIPHERAL.IBOOL_REG0.LONG)&0x1)      == (exp_val&0x1))) { ret = 1; }
    else if ((port_name == ecmterroutz_m) && (((DUMMY_PERIPHERAL.IBOOL_REG0.LONG >> 1)&0x1) == (exp_val&0x1))) { ret = 1; }
    else if ((port_name == ecmterroutz_c) && (((DUMMY_PERIPHERAL.IBOOL_REG0.LONG >> 2)&0x1) == (exp_val&0x1))) { ret = 1; }
    else if ((port_name == ecmtresz)      && (((DUMMY_PERIPHERAL.IBOOL_REG0.LONG >> 3)&0x1) == (exp_val&0x1))) { ret = 1; }
    else if ((port_name == ecmtnmi)       && ((DUMMY_PERIPHERAL.IINTCNT_REG0.LONG)          == exp_val))       { ret = 1; }
    else if ((port_name == ecmti_pe(0))   && ((DUMMY_PERIPHERAL.IINTCNT_REG1.LONG)          == exp_val))       { ret = 1; }
    else if ((port_name == ecmti_pe(1))   && ((DUMMY_PERIPHERAL.IINTCNT_REG2.LONG)          == exp_val))       { ret = 1; }
    else if ((port_name == ecmti_pe(2))   && ((DUMMY_PERIPHERAL.IINTCNT_REG3.LONG)          == exp_val))       { ret = 1; }
    else if ((port_name == ecmti_pe(3))   && ((DUMMY_PERIPHERAL.IINTCNT_REG4.LONG)          == exp_val))       { ret = 1; }
    else if ((port_name == ecmti_pe(4))   && ((DUMMY_PERIPHERAL.IINTCNT_REG5.LONG)          == exp_val))       { ret = 1; }
    else if ((port_name == ecmti_pe(5))   && ((DUMMY_PERIPHERAL.IINTCNT_REG6.LONG)          == exp_val))       { ret = 1; }
    else if ((port_name == ecmti_pe(6))   && ((DUMMY_PERIPHERAL.IINTCNT_REG7.LONG)          == exp_val))       { ret = 1; }
    else if ((port_name == ecmti_pe(7))   && ((DUMMY_PERIPHERAL.IINTCNT_REG8.LONG)          == exp_val))       { ret = 1; }
    else if ((port_name == ecmdclsint(0)) && ((DUMMY_PERIPHERAL.IINTCNT_REG9.LONG)          == exp_val))       { ret = 1; }
    else if ((port_name == ecmdclsint(1)) && ((DUMMY_PERIPHERAL.IINTCNT_REG10.LONG)         == exp_val))       { ret = 1; }
    else if ((port_name == ecmdclsint(2)) && ((DUMMY_PERIPHERAL.IINTCNT_REG11.LONG)         == exp_val))       { ret = 1; }
    else if ((port_name == ecmdclsint(3)) && ((DUMMY_PERIPHERAL.IINTCNT_REG12.LONG)         == exp_val))       { ret = 1; }
    else if ((port_name == ecmdclsint(4)) && ((DUMMY_PERIPHERAL.IINTCNT_REG13.LONG)         == exp_val))       { ret = 1; }
    else if ((port_name == ecmdclsint(5)) && ((DUMMY_PERIPHERAL.IINTCNT_REG14.LONG)         == exp_val))       { ret = 1; }
    else if ((port_name == ecmdclsint(6)) && ((DUMMY_PERIPHERAL.IINTCNT_REG15.LONG)         == exp_val))       { ret = 1; }
    else if ((port_name == ecmdclsint(7)) && ((DUMMY_PERIPHERAL.IINTCNT_REG16.LONG)         == exp_val))       { ret = 1; }
    else if (port_name == OPORTS_LIST){
        if (exp_val == OPORTS_INITVAL) { //Initialize value
            if (((DUMMY_PERIPHERAL.IBOOL_REG0.LONG)&0x1FFFFF) == 0x8) { ret = 1; }//(ecmterroz, ecmterroutz_m, ecmterroutz_c, ecmtresz, ecmtnmi, ecmti_pe[][8], ecmdclsint[][8])=(0001_0000_0000_0000_0000_0 = 0x8)
        } else if (exp_val == RESVAL) { //Reset value ~ Initialize value
            if (((DUMMY_PERIPHERAL.IBOOL_REG0.LONG)&0x1FFFFF) == 0x8) { ret = 1; }//(0001_0000_0000_0000_0000_0 = 0x8)
        } else if (exp_val == RES1VAL) { //Reset by presetn: Reset output ports (ecmtresz, ecmtnmi, ecmti_pe*, ecmdclsint*)
            if (((DUMMY_PERIPHERAL.IBOOL_REG0.LONG >> 3)&0x3FFFF) == 1) { ret = 1; }//(xxx1_0000_0000_0000_0000_0)
        } else if (exp_val == RES2VAL) { //Reset by cntclk_preset_n: Reset output ports: ecmterroz, ecmterroutz_m/c
            if (((DUMMY_PERIPHERAL.IBOOL_REG0.LONG)&0x7) == 0) { ret = 1; }//(000x_xxxx_xxxx_xxxx_xxxx_x)
        } else if (exp_val == RES3VAL) { //Reset by erroutresz: Reset output ports: ecmterroz, ecmterroutz_m/c
            if (((DUMMY_PERIPHERAL.IBOOL_REG0.LONG)&0x7) == 0) { ret = 1; }//(000x_xxxx_xxxx_xxxx_xxxx_x)
        } else if (exp_val == RES4VAL) { //Reset by cntclk_erroutresz: Reset output ports: ecmterroz, ecmterroutz_m/c
            if (((DUMMY_PERIPHERAL.IBOOL_REG0.LONG)&0x7) == 0) { ret = 1; }//(000x_xxxx_xxxx_xxxx_xxxx_x)
        } else if (exp_val == RES5VAL) { //Reset by resstg1z: not effect to output port
            ret = 1; //not effect to output port
        } else if (exp_val == RES6VAL) { //Reset by pclkin_resstg1z: not effect to output port
            ret = 1; //not effect to output port
        } else if (exp_val == RES7VAL) { //Reset by pclkin_resstg1z: Reset output ports: ecmterroz, ecmterroutz_m/c
            if (((DUMMY_PERIPHERAL.IBOOL_REG0.LONG)&0x7) == 0) { ret = 1; }//(000x_xxxx_xxxx_xxxx_xxxx_x)
        } else if (exp_val == CAPALLVAL) { //Captured value
            if (((DUMMY_PERIPHERAL.IBOOL_REG0.LONG)&0xF) == 0) { ret = 1; }//(0000_xxxx_xxxx_xxxx_xxxx_x)
            // if ((DUMMY_PERIPHERAL.IINTCNT_REG0.BYTES.BYTE0) == ERR_ACTIVE_NUM) { ret = 1; } //ecmtnmi = ERR_ACTIVE_NUM
            // for (n = 0; n < 4; n++){
                // if      (((DUMMY_PERIPHERAL.IINTCNT_REG1.LONG >> (n*8))&0xFF) == (ERR_ACTIVE_NUM - 1)) { ret = 1; }//ecmti_pe = ERR_ACTIVE_NUM - 1
                // else if (((DUMMY_PERIPHERAL.IINTCNT_REG2.LONG >> (n*8))&0xFF) == (ERR_ACTIVE_NUM - 1)) { ret = 1; }//ecmti_pe = ERR_ACTIVE_NUM - 1
                // else if (((DUMMY_PERIPHERAL.IINTCNT_REG3.LONG >> (n*8))&0xFF) == 1) { ret = 1; }//ecmdclsint = 1
                // else if (((DUMMY_PERIPHERAL.IINTCNT_REG4.LONG >> (n*8))&0xFF) == 1) { ret = 1; }//ecmdclsint = 1
            // }
            if ((DUMMY_PERIPHERAL.IINTCNT_REG0.LONG) == ERR_ACTIVE_NUM) { ret = 1; } //ecmtnmi = ERR_ACTIVE_NUM
            if ((DUMMY_PERIPHERAL.IINTCNT_REG1.LONG) == (ERR_ACTIVE_NUM - 1)) { ret = 1; } //ecmti_pe = ERR_ACTIVE_NUM - 1
            if ((DUMMY_PERIPHERAL.IINTCNT_REG2.LONG) == (ERR_ACTIVE_NUM - 1)) { ret = 1; } //ecmti_pe = ERR_ACTIVE_NUM - 1
            if ((DUMMY_PERIPHERAL.IINTCNT_REG3.LONG) == (ERR_ACTIVE_NUM - 1)) { ret = 1; } //ecmti_pe = ERR_ACTIVE_NUM - 1
            if ((DUMMY_PERIPHERAL.IINTCNT_REG4.LONG) == (ERR_ACTIVE_NUM - 1)) { ret = 1; } //ecmti_pe = ERR_ACTIVE_NUM - 1
            if ((DUMMY_PERIPHERAL.IINTCNT_REG5.LONG) == (ERR_ACTIVE_NUM - 1)) { ret = 1; } //ecmti_pe = ERR_ACTIVE_NUM - 1
            if ((DUMMY_PERIPHERAL.IINTCNT_REG6.LONG) == (ERR_ACTIVE_NUM - 1)) { ret = 1; } //ecmti_pe = ERR_ACTIVE_NUM - 1
            if ((DUMMY_PERIPHERAL.IINTCNT_REG7.LONG) == (ERR_ACTIVE_NUM - 1)) { ret = 1; } //ecmti_pe = ERR_ACTIVE_NUM - 1
            if ((DUMMY_PERIPHERAL.IINTCNT_REG8.LONG) == (ERR_ACTIVE_NUM - 1)) { ret = 1; } //ecmti_pe = ERR_ACTIVE_NUM - 1
            if ((DUMMY_PERIPHERAL.IINTCNT_REG9.LONG) == 1) { ret = 1; } //ecmdclsint = 1
            if ((DUMMY_PERIPHERAL.IINTCNT_REG10.LONG) == 1) { ret = 1; } //ecmdclsint = 1
            if ((DUMMY_PERIPHERAL.IINTCNT_REG11.LONG) == 1) { ret = 1; } //ecmdclsint = 1
            if ((DUMMY_PERIPHERAL.IINTCNT_REG12.LONG) == 1) { ret = 1; } //ecmdclsint = 1
            if ((DUMMY_PERIPHERAL.IINTCNT_REG13.LONG) == 1) { ret = 1; } //ecmdclsint = 1
            if ((DUMMY_PERIPHERAL.IINTCNT_REG14.LONG) == 1) { ret = 1; } //ecmdclsint = 1
            if ((DUMMY_PERIPHERAL.IINTCNT_REG15.LONG) == 1) { ret = 1; } //ecmdclsint = 1
            if ((DUMMY_PERIPHERAL.IINTCNT_REG16.LONG) == 1) { ret = 1; } //ecmdclsint = 1
        }
    }
    return ret;
}

// void delay(unsigned int time){
    // unsigned int i = 0;
    // for(i = 0;i < time;i++);
// }
//////}}}
#endif
