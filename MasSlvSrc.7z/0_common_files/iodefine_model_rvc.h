#ifndef __IODEFINE_MODELRVC_H__
#define __IODEFINE_MODELRVC_H__

struct st_modelRVC_reg {
    union {
        unsigned long LONG;
        struct {
            unsigned short WORD0;
            unsigned short WORD1;
        } WORDS;
        struct {
            unsigned char BYTE0;
            unsigned char BYTE1;
            unsigned char BYTE2;
            unsigned char BYTE3;
        } BYTES;
    } MODEL_REG;
};
#endif // __IODEFINE_MODELRVC_H__
