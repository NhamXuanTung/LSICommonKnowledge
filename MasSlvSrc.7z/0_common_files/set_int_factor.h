// $Id: set_int_factor.h,v 1.1.1.1 2013/05/13 13:41:24 trongtruong Exp $
/*****************************************************************************
 *	Modules Register 
 *	Copyright(C) 2008/07/03 Renesas Viet Nam Co.,Ltd
 *****************************************************************************/


typedef enum 
{
     SIM,
     DMAC,
     CEU2,
     BEU2,
     VEU2,
     VOU2,
     VPU4WM,
     KEYSC,
     SCIF,
     I2C,
     SIU,
     TMU,
     LCDC,
     CMT,
     SGT,
     DDM,
     TDDMAC
}mod_name;

typedef enum
{
     ECMTI,
     ECMTNMI,
     DEI0,
     DEI1,
     DEI2,
     DEI3,
     CEU2I,
     BEU2I,
     VEU2I,
     VOU2I,
     VPU4WMI,
     KEYI,
     SCIF0_ERI,
     SCIF0_RXI,
     SCIF0_BRI,
     SCIF0_TXI,
     SCIF1_ERI,
     SCIF1_RXI,
     SCIF1_BRI,
     SCIF1_TXI,
     SCIF2_ERI,
     SCIF2_RXI,
     SCIF2_BRI,
     SCIF2_TXI,
     ALI0,
     TACK0,
     WAIT0,
     DTEI0,
     SIUI,
     TUNI0,
     TUNI1,
     TUNI2,
     TUNI3,
     TUNI4,
     TUNI5,
     TUNI6,
     TUNI7,
     TUNI8,
     LCDCI,
     CMTI,
     SGTI,
     DDM1,
     TDDMAC_CH0,
     TDDMAC_CH1,
     TDDMAC_CH2,
     TDDMAC_CH3,
     TDDMAC_CH4,
     TDDMAC_CH5,
     TDDMAC_CH6,
     TDDMAC_CH7
}int_name;

extern "C"
void set_int_factor(mod_name mname, int_name iname, int mask, int prio);
