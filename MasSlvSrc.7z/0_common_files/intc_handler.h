//$Id: intc_handler.h,v 1.1.1.1 2013/05/13 13:41:24 trongtruong Exp $
/****************************************************************************
*
*                        RVC confidential
*
*   (C) Copyright by Renesas Viet Nam Company, Ltd., 2006 All Rights Reserved.
*
***************************************************************************/

#ifndef __INTC_HANDLER_H__
#define __INTC_HANDLER_H__


extern unsigned int field;

extern "C"
{

    void DU_DU_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_DU_DU = 0x00000001;
    }

    void TMU_TMU00_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_TMU_TMU00 = 0x00000001;
    }

    void TMU_TMU10_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_TMU_TMU10 = 0x00000001;
    }

    void TMU_TMU20_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_TMU_TMU20 = 0x00000001;
    }

    void TMU_TMU21_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_TMU_TMU21 = 0x00000001;
    }

    void TMU_TMU30_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_TMU_TMU30 = 0x00000001;
    }

    void TMU_TMU40_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_TMU_TMU40 = 0x00000001;
    }

    void TMU_TMU50_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_TMU_TMU50 = 0x00000001;
    }

    void TMU_TMU51_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_TMU_TMU51 = 0x00000001;
    }

    void TMU_TMU60_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_TMU_TMU60 = 0x00000001;
    }

    void TMU_TMU70_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_TMU_TMU70 = 0x00000001;
    }

    void TMU_TMU80_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_TMU_TMU80 = 0x00000001;
    }

    void WDT_RESET_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_WDT_RESET = 0x00000001;
    }

    void USB2_USB2_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_USB2_USB2 = 0x00000001;
    }

    void SIU2_SIU2_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_SIU2_SIU2 = 0x00000001;
    }

    void FM_DARC_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_FM_DARC = 0x00000001;
    }

    void DEBUG_HUDI_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_DEBUG_HUDI = 0x00000001;
    }

    void SHWY_DMAC01_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_SHWY_DMAC01 = 0x00000001;
    }

    void TSIF_TSIF_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_TSIF_TSIF = 0x00000001;
    }

    void REMOCON_REMOCON_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_REMOCON_REMOCON = 0x00000001;
    }

    void SSI_SSI0_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_SSI_SSI0 = 0x00000001;
    }

    void SSI_SSI1_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_SSI_SSI1 = 0x00000001;
    }

    void SSI_SSI2_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_SSI_SSI2 = 0x00000001;
    }

    void SSI_SSI3_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_SSI_SSI3 = 0x00000001;
    }

    void VIN_VIN_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_VIN_VIN = 0x00000001;
    }

    void RGP1_RGP1_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_RGP1_RGP1 = 0x00000001;
    }

    void HSPI_HSPI_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_HSPI_HSPI = 0x00000001;
    }

    void LSBC_ATA_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_LSBC_ATA = 0x00000001;
    }

    void I2C_I2C0_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_I2C_I2C0 = 0x00000001;
    }

    void RCAN_RCAN_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_RCAN_RCAN = 0x00000001;
    }

    // customized for ECM model
//    void ECM_ECMTI_func(void);
//    void ECM_ECMTNMI_func(void);

    void TAB_II_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_TAB_II = 0x00000001;
    }

    void SDIF_SDIF_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_SDIF_SDIF = 0x00000001;
    }

    void IE_BUS_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_IE_BUS = 0x00000001;
    }

    void HPB_DMAC0_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_HPB_DMAC0 = 0x00000001;
    }

    void HPB_DMAC1_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_HPB_DMAC1 = 0x00000001;
    }

    void HPB_DMAC2_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_HPB_DMAC2 = 0x00000001;
    }

    void HPB_DMAC3_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_HPB_DMAC3 = 0x00000001;
    }

    void HPB_DMAC4_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_HPB_DMAC4 = 0x00000001;
    }

    void HPB_DMAC5_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_HPB_DMAC5 = 0x00000001;
    }

    void HPB_DMAC6_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_HPB_DMAC6 = 0x00000001;
    }

    void HPB_DMAC7_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_HPB_DMAC7 = 0x00000001;
    }

    void HPB_DMAC8_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_HPB_DMAC8 = 0x00000001;
    }

    void HPB_DMAC9_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_HPB_DMAC9 = 0x00000001;
    }

    void HPB_DMAC10_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_HPB_DMAC10 = 0x00000001;
    }

    void HPB_DMAC11_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_HPB_DMAC11 = 0x00000001;
    }

    void GPIO_GPIO0_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_GPIO_GPIO0 = 0x00000001;
    }

    void GPIO_GPIO1_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_GPIO_GPIO1 = 0x00000001;
    }

    void GPIO_GPIO2_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_GPIO_GPIO2 = 0x00000001;
    }

    void GPIO_GPIO3_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_GPIO_GPIO3 = 0x00000001;
    }

    void GPS_GPS_func(void)
    {
       set_cr (get_cr() | 0x10000000);
       *INT_GPS_GPS = 0x00000001;
    }

    void DMAC_IRQ0_func(void)
    {
    }
    void DMAC_IRQ1_func(void)
    {
    }
    void DMAC_IRQ2_func(void)
    {
    }
    void DMAC_IRQ3_func(void)
    {
    }
    void DMAC_IRQ4_func(void)
    {
    }
    void DMAC_IRQ5_func(void)
    {
    }
    void DMAC_IRQ6_func(void)
    {
    }
    void DMAC_IRQ7_func(void)
    {
    }
    void DMAC_IRQ8_func(void)
    {
    }
    void DMAC_IRQ9_func(void)
    {
    }
    void DMAC_IRQ10_func(void)
    {
    }
    void DMAC_IRQ11_func(void)
    {
    }
    void DMAC_IRQ12_func(void)
    {
    }
    void MPUD_IRQ_func(void)
    {
    }
}

#endif // __INTC_HANDLER_H__
