#! /usr/bin/perl
# ----------------------------------------------------------------------
#     Status   : $
#     $Source  : $
#     $Revision: 1.3 $
#     $Date    : $
#     $Author  : $
#     $Id: gen_mot.pl,v 1.3 2013/11/25 08:24:33 uyenle Exp $
#     $Locker:  $
#     $State: Exp $
# ----------------------------------------------------------------------
#   (C) Copyright 2009   RVC (Renesas Design Viet Nam Co., Ltd.)
#       All rights reserved. RVC Confidential Proprietary
#   (C) Copyright 2009   RENESAS Technology Corp.  All rights reserved.
# ----------------------------------------------------------------------*/


#==================================================#
#                variables declaration             #
#==================================================#
# variables for replacing
$PRG_SECTION  = "";
$TOOL_PATH    = "/common/appl/Renesas/shc/SHCV90200";
$DEST         = "./";
$PATH_INC     = "./";
$SRC          = "./";
$SRC_PATH     = "./";
$TM_NAME      = "./";
$MODE         = 0;
# variables for openning
$SCRIPT_PATH        = "../";
$ADDRESS_MAP_FN     = "$SCRIPT_PATH/Address_map_info.txt";
$MAKEFILE_SKL_PATH  = "./";
$TOOL_PATH_SOURCE   = "/common/appl/Renesas/shc/SHCV90200/shc.CSHRC_9.02.00";

#==================================================#
#                 main declaration                 #
#==================================================#

#{{{
if ( $#ARGV < 0 || $ARGV[0] =~ "-help" || $ARGV[0] =~ "-h") {
    &print_help();
}
elsif ( $#ARGV < 1 ){
    printf ("<error> lacking of arguments, please use -help for usage.\n\n");
    exit;
}
#}}}

#==================================================#
#                 sub routine calling              #
#==================================================#

# get input parameter 
&get_input_argument();

# get Address_map_info.txt file content
#&address_map_info_read();

# judge calling build file or directory
if($MODE == 1){     # input directory
   &compile_directory($SRC_PATH);
}
elsif($MODE == 2){  # input file
   &compile_TM();
}

#&compile_TM();

#==================================================#
#             sub routine declaration              #
#==================================================#

#==================================================#
# function: print_help                             #
# input   : none                                   #
# ouput   : none                                   #
# date    : 03/10/09                               #
# content : display helping                        #
#==================================================#
sub print_help{
    #{{{
    print ("=====================================================\n");
    print ("=               GEN_MOT.PL script                   =\n");
    print ("=====================================================\n");
    print ("+ This script used to convert cpp file to mot file \n\n");
    print ("+ Usage: gen_mot.pl <input_option> <input> [option]\n");
    print ("\t* <input_option> : -f -> <input> is file, -r -> <input> is directory\n");
    print ("\t* <input>        : input path to cpp file or directory\n\n");
    print ("\t* [option]\n");
    print ("\t  + -o <output>      : option for output path to mot file - defaut value = <input> directory\n");
    print ("\t  + -t <tool_chain>  : path to SH compiler tool chain - default value = \".\/\"\n");
    print ("\t  + -i <include>     : path to included file - default value = <input> directory\n\n");
    exit;
    #}}}
}

#==================================================#
# function: get_input_argument                     #
# input   : none                                   #
# ouput   : none                                   #
# date    : 03/10/09                               #
# content : argument parsing                       #
#==================================================#
sub get_input_argument{
   #{{{
   if($ARGV[0] =~ "-r"){      #input is directory
       $MODE = 1;
   }
   elsif($ARGV[0] =~ "-f"){   #input is file
       $MODE = 2;
   } 
   else{
       $MODE = 0;
   }
   if( $MODE > 0 ){
      if($#ARGV > 0 && $#ARGV % 2 != 0){
         for($i=0;$i<$#ARGV;$i++){
            if($ARGV[$i] =~ "-r"){
               $SRC  = $ARGV[++$i];
               $DEST = $SRC;               
               $SRC_PATH = $SRC;
               $PATH_INC = $SRC_PATH;
            }
            elsif($ARGV[$i] =~ "-f"){
               $SRC          = $ARGV[++$i];
               my $name      = "";
               my @path_list;
               my @name_list = split(/\//,$SRC);
               $name         = $name_list[$#name_list];
               @path_list    = split(/$name/,$SRC);
               @name_list    = split(/\./,$name);
               $TM_NAME      = $name_list[0];
               $DEST         = $path_list[0];
               $SRC_PATH     = $DEST;
               $PATH_INC     = $SRC_PATH;
               print "TM NAME $TM_NAME\n";
            }
            elsif($ARGV[$i] =~ "-o"){
               $DEST = $ARGV[++$i];  
            }
            elsif(@ARGV[$i] =~ "-t"){
               $TOOL_PATH = @ARGV[++$i];
            }
            elsif(@ARGV[$i] =~ "-i"){
               $PATH_INC = @ARGV[++$i];
            }
         }
      }
      else{
         print "<error> lacking argument for option !\n"; 
         exit;
      }
   }
   else{ # $MODE == 0
       print "<error> option is not legal !\n";
       exit;
   }
   #}}}
}

#==================================================#
# function: get_address_map_info                   #
# input   : none                                   #
# output  : program section info                   #
# date    : 03/10/09                               #
# content : get program section info               #
#==================================================#
sub address_map_info_read{
   #{{{
   unless( open (ADDRESS_INPUT, $ADDRESS_MAP_FN)){
      die("\n<error> can not open Address_map_info.txt file !");
   }
   my @content  = <ADDRESS_INPUT>;
   my $str_line;
   for($i=0;$i<$#content;$i++){
      $str_line = $content[$i];
      if($str_line =~/^ *\%\%PRG_SECTION *$/){
         $str_line = $content[++$i];
         $str_line =~ s/\n//g;
         while($str_line !~ /\%\%END/){
            $str_line =~ s/\t/ /g;
            @line_arr = split(/ +/,$str_line);
            if( @line_arr[0] =~ /\S/ && @line_arr[0] !~ /##+/){
                $PRG_SECTION = $PRG_SECTION.@line_arr[0]."\/".@line_arr[1];
            }
            $str_line = $content[++$i];
            $str_line =~ s/\n//g;
            if(@line_arr[0] =~ /\S/ && $str_line =~ /\S/ && $str_line !~ /%%END/){
                $PRG_SECTION = $PRG_SECTION.",";
            }
         }
      }
   }
   if($PRG_SECTION eq ""){
      die("<error> PROGRAM SECTION in Address_map_info.txt is illegal !\n");
   }
   #}}}
}

#==================================================#
# function: create_makefile                        #
# input   : path to generated Makefile file        #
# output  : Makefile content                       #
# date    : 03/10/09                               #
# content : create make_file from makefile.skl     #
#==================================================#
sub create_makefile{
   #{{{
   my $interrupt_enable = 0;   
   my $mk_file_skl     = "";
   $mk_file = shift;
   # Interrupt detecting ...
   unless(open(COMMON,"$PATH_INC/common.h")){
      die("<error> can not open common.h file !\n");
      exit;
   }
   my @common_content = <COMMON>;
   #for($i=0;$i<$#common_content;$i++){
   #   if($common_content[$i] =~ /^ *#include *\"intc_handler.h\"/){
   #       $interrupt_enable = 1;
   #       print ("-->Interrupt detected ...\n");
   #       break;
   #   }
   #}
   #if($interrupt_enable == 1){  # loading makefile skeleton with interrupt
      $mk_file_skl = $MAKEFILE_SKL_PATH."\/imakefile.skl";
   #}
   #else{                        # loading makefile skeleton without interrupt
   #   $mk_file_skl = $MAKEFILE_SKL_PATH."\/makefile.skl";
   #   print ("-->Loading makefile skeleton without interrupt ...\n");
   #}
   unless(open(MK_SKL,$mk_file_skl)){
      die("<error> can not open $mk_file_skl file !\n");
      exit;
   }
   unless(open(MK,">$mk_file")){
      die("Can not create new makefile file !\n");
      exit;
   }

   my @content = <MK_SKL>;
   for($i=0;$i<$#content;$i++){
      if($content[$i] =~ /\%\%TOOL_PATH/){     #tool path replace
         $content[$i] =~ s/\%\%TOOL_PATH/$TOOL_PATH/g;
      }
      if($content[$i] =~ /\%\%SRC/){           #src replace
         $content[$i] =~ s/\%\%SRC/$SRC/g;
      }
      if($content[$i] =~ /\%\%PATH_INC/){      #included path replace
         $content[$i] =~ s/\%\%PATH_INC/$PATH_INC/g;
      }
      if($content[$i] =~ /\%\%DEST/){          #destination path replace
         $content[$i] =~ s/\%\%DEST/$DEST/g;
      }
      if($content[$i] =~ /\%\%TM_NAME/){       #destination path replace
         $content[$i] =~ s/\%\%TM_NAME/$TM_NAME/g;
      }
      if($content[$i] =~ /\%\%PRG_SECTION/){   #destination path replace
         $content[$i] =~ s/\%\%PRG_SECTION/$PRG_SECTION/g;
      }
      if($content[$i] =~ /\/\//){ 
         $content[$i] =~ s/\/\//\//g;
      }
      print MK $content[$i];
   }
   close(COMMON);
   close(MK);
   close(MK_SKL);
   #}}}
}

#==================================================#
# function: compile_directory                      #
# input   : path to test pattern directory         #
# ouput   : mot files of test patterns             #
# date    : 03/11/09                               #
# content : compile test pattern                   #
#==================================================#
sub compile_directory{
   #{{{
   my $dir = shift;
   my $file_name;
   my @file_list;
   my @name_list;
   if(substr(($dir,length($dir)-1,length($dir)-1)) =~ "/"){
      $dir    = substr($dir,0,length($dir)-1);
   }
   if(opendir(MYDIR,$dir) || die ("<error> can not open $dir directory !\n")){
      @file_list = readdir(MYDIR);
      closedir(MYDIR);
      foreach $file_name (sort @file_list){
         next if($file_name eq "." || $file_name eq "..");
         if(-d $dir."\/".$file_name){   #sub directory
             &compile_directory($dir."\/".$file_name."\/");
         }
         else{                 #file
             if($file_name =~ /\.cpp$/ || $file_name =~ /\.c$/){
                 $SRC       = $dir."/".$file_name;
                 $SRC_PATH  = $dir."\/";
                 $DEST      = $dir;
                 if($file_name =~ /\.cpp/){
                     @name_list = split(/.cpp/,$file_name);
                 }
                 else{
                     @name_list = split(/.c/,$file_name);
                 }
                 $TM_NAME   = $name_list[0];
                 &compile_TM();
                  
             }
         }
      }
   }
   return 1;
   #}}}
}

#==================================================#
# function: compile_TM                             #
# input   : path to test pattern                   #
# output  : mot file of test pattern               #
# date    : 03/11/09                               #
# content : compile test pattern                   #
#==================================================#
sub compile_TM{
   #{{{
   if(!(-e $SRC )){
       die("<error> can not open $SRC file !\n");
   }
#   if(!(-e $SRC_PATH."/tmp")){
#      system("mkdir $SRC_PATH/tmp");
#   }
   # generate Makefile file path 
   my $mk_file = $SRC_PATH."Makefile";
   # generate Makefile content 
   &create_makefile($mk_file);
   # build test pattern by calling gmake
   system("cp -f $PATH_INC/*.h $SRC_PATH");
   system("gmake clean -C $SRC_PATH");
   system("rm -rf $SRC_PATH/*.obj $SRC_PATH/tpldir");
   system("gmake -C $SRC_PATH");
   # remove tmp data
   system("rm -rf $SRC_PATH/Makefile $SRC_PATH/*.obj $SRC_PATH/tpldir $SRC_PATH/*.lis");
   system("rm -rf $SRC_PATH/*.h");

   &create_ssc();
#   system("rm -rf $SRC_PATH/tmp");
   #}}} 
}

#==================================================#
# function: create_ssc                             #
# input   : ssc skeleton file                      #
# output  : ssc file of test pattern               #
# date    : 11/24/09                               #
# content : create ssc file                        #
#==================================================#
sub create_ssc {
    unless(open(SSC_SKL,"<tm.ssc.skl")){
        die("<error> can not open skeleton for ssc file !\n");
        exit;
    }

    unless(open(SSC_NEW,">$SRC_PATH/$TM_NAME.ssc")){
        die("<error> can not create ssc file for TM $TM_NAME!\n");
        exit;
    }

    my @ssc_skl_content = <SSC_SKL>;
    close (SSC_SKL);

    for($i = 0; $i <= $#ssc_skl_content; $i++) {
        if ($ssc_skl_content[$i] =~ /\%\%TM_NAME/) {
            $ssc_skl_content[$i] =~ s/\%\%TM_NAME/$TM_NAME\.elf/g;
        }

        if ($ssc_skl_content[$i] =~ /GO/) {
            if ($TM_NAME =~ /tp01/) {
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMmESET       MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMmECLR       MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMmESSTR0     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMmESSTR1     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMmESSTR2     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMmESSTR3     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMEPCFG       MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMMICFG0      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMMICFG1      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMMICFG2      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMMICFG3      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMNMICFG0     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMNMICFG1     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMNMICFG2     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMNMICFG3     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMIRCFG0      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMIRCFG1      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMIRCFG2      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMIRCFG3      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMEMK0        MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMEMK1        MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMEMK2        MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMEMK3        MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMESSTC0      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMESSTC1      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMESSTC2      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMESSTC3      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMKCPROT      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMPE0         MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMPE1         MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMPE2         MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMPE3         MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMDTMCTL      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMDTMR        MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMDTMCMP      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMDTMCFG0     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMDTMCFG1     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMDTMCFG2     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMDTMCFG3     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMDTMCFG4     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMDTMCFG5     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMDTMCFG6     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMDTMCFG7     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg  ECMEOCCFG      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMmESET       MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMmECLR       MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMmESSTR0     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMmESSTR1     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMmESSTR2     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMmESSTR3     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMEPCFG       MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMMICFG0      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMMICFG1      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMMICFG2      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMMICFG3      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMNMICFG0     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMNMICFG1     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMNMICFG2     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMNMICFG3     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMIRCFG0      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMIRCFG1      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMIRCFG2      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMIRCFG3      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMEMK0        MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMEMK1        MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMEMK2        MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMEMK3        MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMESSTC0      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMESSTC1      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMESSTC2      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMESSTC3      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMKCPROT      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMPE0         MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMPE1         MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMPE2         MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMPE3         MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMDTMCTL      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMDTMR        MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMDTMCMP      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMDTMCFG0     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMDTMCFG1     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMDTMCFG2     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMDTMCFG3     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMDTMCFG4     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMDTMCFG5     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMDTMCFG6     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMDTMCFG7     MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg  ECMEOCCFG      MessageLevel        fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg     DumpRegisterRW      true\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg     DumpRegisterRW      true\n";
            }
#            if ($TM_NAME =~ /tp03/ || $TM_NAME =~ /tp04/ || $TM_NAME =~ /tp03_03/) {
#                print SSC_NEW "reslx.control_port      reg     DumpRegisterRW      true\n";
#                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster     reg     DumpRegisterRW      true\n";
#                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker    reg     DumpRegisterRW      true\n";
#            }
            if ($TM_NAME !~ /tp07_02_02/ && $TM_NAME !~ /tp07_04_03/) {
                print SSC_NEW "reslx.ecm_wp_fcc1      MessageLevel    fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      MessageLevel    fatal|error|info|warning\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     MessageLevel    fatal|error|info|warning\n";     
            }
            if ($TM_NAME !~ /tp07_03_002/ && $TM_NAME !~ /tp03_07/ && $TM_NAME !~ /tp04_11/ && $TM_NAME !~ /tp05_10/) {
                print SSC_NEW "reslx.ecm_wp_fcc1      command SetCLKfreq pclk 100000000\n";
                print SSC_NEW "reslx.ecm_wp_fcc1      command SetCLKfreq cntclk 100000000\n";
            }
            if ($TM_NAME =~ /tp07_03_001/) {
                print SSC_NEW "reslx.cpu       GO\n";
                print SSC_NEW "reslx.ecm_wp_fcc1      command DumpInterrupt true\n";
                print SSC_NEW "reslx.ecm_wp_fcc1      command DumpInterrupt\n";
                print SSC_NEW "reslx.cpu       set_cpu         REGSET        PC      0x0C400000\n";
            }
            if ($TM_NAME =~ /tp07_03_003/) {
                print SSC_NEW "reslx.cpu       GO\n";
                print SSC_NEW "reslx.ecm_wp_fcc1      command EnableTransInfo true\n";
                print SSC_NEW "reslx.ecm_wp_fcc1      command EnableTransInfo\n";
                print SSC_NEW "reslx.cpu       set_cpu         REGSET        PC      0x0C400000\n";
            }
            if ($TM_NAME =~ /tp07_04_003/) {
                print SSC_NEW "reslx.cpu       GO\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg             ECMDTMCMP          release\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg             ECMDTMCMP          release\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mMaster      reg     DumpRegisterRW      false\n";
                print SSC_NEW "reslx.ecm_wp_fcc1.mChecker     reg     DumpRegisterRW      false\n";
                print SSC_NEW "reslx.cpu       set_cpu         REGSET        PC      0x0C400000\n";
            }
            if ($TM_NAME !~ /tp07_03_001/) {
                print SSC_NEW "reslx.ecm_wp_fcc1      DumpInterrupt   true\n";
                print SSC_NEW "reslx.ecm_wp_fcc1      DumpInterrupt\n";
            }
        }

        print SSC_NEW $ssc_skl_content[$i];
    }

    close (SSC_NEW);

}
# vim600: set foldmethod=marker :
