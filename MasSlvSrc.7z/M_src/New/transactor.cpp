/*************************************************************************
 *
 * Copyright(c) 2013 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 *
*************************************************************************/

#include "transactor.h"
#include "commandHandler.h"

/// Constructor of transactor class
/// @return None
Ctransactor::Ctransactor(sc_module_name name): 
                                       vpcl::tlm_ini_if<64>(name)
{//{{{
    // Initialize handleCommand  
    CommandInit();

    mIsStopRequest = false;
    #ifdef CWR_SYSTEMC
    //handle command
    SCML_COMMAND_PROCESSOR(handleCommand);
    SCML_ADD_COMMAND("ini", 1, 8, "ini <cmd> <arg0> <arg1> <arg2> ...", "prefix of tlm initiator if command");

    #endif
    SC_METHOD(StartTransactor);
    SC_THREAD(IssueTransFromFile);
    dont_initialize();
    sensitive << mTransEvent;

}//}}}

/// Destructor of Cgbethermac class
/// @return None
Ctransactor::~Ctransactor()
{//{{{
}//}}}
void Ctransactor::StartTransactor(void)
{
    mTransEvent.notify();
}
void Ctransactor::GO(void)
{
    if(cmd_handler != NULL)  cmd_handler->setContinue();
    mWakeupEvent.notify(SC_ZERO_TIME);
}
void Ctransactor::QUIT(void)
{
    mIsStopRequest = true;
    sc_stop();
}
void Ctransactor::BREAK(void)
{
    if(cmd_handler != NULL)  cmd_handler->handleCommand();
    wait(mWakeupEvent);
}
void Ctransactor::RESET(void)
{
    if(mInputStream.is_open()){
        mInputStream.close();
    }
    mInputStream.open(TransFileName.c_str());
    if(!mInputStream.is_open()){
        re_printf("error", "Can not open transaction log file: %s\n", TransFileName.c_str());
        return;
    }else{
        // do nothing;
    }
}

void Ctransactor::add_breakpoint(const unsigned int address)
{
    mBreakTable[address] = true;
}

void Ctransactor::setCommandHandler(vpcl::commandHandler * handler)
{
    if (handler != NULL) {
        cmd_handler = handler;
    }
    else {
        re_printf("Error", "handler parameter(at setCommandHandler) is NULL pointer.\n");
    }
}
void Ctransactor::IssueTransFromFile(void)
{
    std::string cur_line;
    if(!mInputStream.is_open()) {
        mInputStream.open(TransFileName.c_str());
        if(!mInputStream.is_open()){
            re_printf("error", "Can not open transaction log file: %s\n", TransFileName.c_str());
            return;
        }else{
//            do nothing;
        }
    }    
    std::string sim_time;
    std::string resolution;
    std::string action;
    unsigned int addr = 0;
    unsigned int size = 0;
    double sim_time_double = 0;
    while(1){
        if(mIsStopRequest) break;
        while(getline(mInputStream, cur_line)){
            std::istringstream sin(cur_line);
            sin >> sim_time;
            std::stringstream temp(sim_time);
            temp >> sim_time_double;
            sin >> resolution;
            sin >> action;
            sin >> std::hex >> addr;
            sin >> std::dec >> size;
    
            unsigned int num_loop = (size/4) + (((size%4) == 0)? 0:1);
            unsigned int *tempdata = new unsigned int[num_loop];
            for(unsigned int i = 0 ; i < num_loop; i++){
                    sin >> std::hex >> tempdata[i]; 
            }

            char unsigned * p_data = new unsigned char[size];
            memcpy(p_data, tempdata, size);
//printf("DEBUG_RVC: ([%20.0f %s] action %s, addr 0x%X, size %d,  data 0x%X)\n", sim_time_double, resolution.c_str(), action.c_str(), addr, size, tempdata);
            ProcessTransaction(sim_time_double, resolution, action, addr, size,  p_data);
            if((mBreakTable.find(addr) != mBreakTable.end()) && (action == "RD" || action == "DR")) {
                printf("<Transactor breaks at H'0%X>\n", addr); fflush(stdout); 
                BREAK();
            }
            delete [] tempdata;
            delete [] p_data;
            if(mIsStopRequest) {
                return;
            }
        }
        QUIT();
    }
}
void Ctransactor::ProcessTransaction(double sim_time, std::string resolution, std::string action, unsigned int addr, unsigned char size, unsigned char* p_data)
{
    tlm::tlm_command command = tlm::TLM_IGNORE_COMMAND;
    sc_dt::uint64 address = 0;
    unsigned int data_size = 0;
    address = (sc_dt::uint64)addr;
    data_size = size;
    tlm::tlm_generic_payload* trans = this->acquire();
    unsigned char* expectedReadData = new unsigned char [size];
    unsigned char* readData = new unsigned char [size];
    bool sim_continue = true;
    if(action == "WR" || action == "DW"){
        command = tlm::TLM_WRITE_COMMAND;
        trans->set_data_ptr(p_data);
    }else if (action == "RD" || action == "DR"){
        command = tlm::TLM_READ_COMMAND;
        memcpy(expectedReadData, p_data, size);
        trans->set_data_ptr(readData);
    }
    trans->set_command(command);
    trans->set_address(address);
    trans->set_data_length(data_size);
    trans->set_streaming_width(data_size);
    sc_time wait_time = SC_ZERO_TIME;

    if(resolution == "fs"){
        wait_time = sc_time(sim_time, SC_FS) - sc_time_stamp();
    } else if (resolution == "ns"){
        wait_time = sc_time(sim_time, SC_NS) - sc_time_stamp();
    } else if (resolution == "ps"){
        wait_time = sc_time(sim_time, SC_PS) - sc_time_stamp();
    } else if (resolution == "ms"){
        wait_time = sc_time(sim_time, SC_MS) - sc_time_stamp();
    } else if (resolution == "us"){
        wait_time = sc_time(sim_time, SC_US) - sc_time_stamp();
    } else{
        wait_time = sc_time(sim_time, SC_SEC) - sc_time_stamp();
    }
    if (wait_time != SC_ZERO_TIME) {
        wait(wait_time);
    } else {
        // do nothing
    }
    if(action == "RD" || action == "WR"){
        ini_acc(*trans);
    } else{
        ini_acc_dbg(*trans); 
    }
    if (trans->get_response_status() == tlm::TLM_OK_RESPONSE) {
        if(action == "RD" || action == "DR"){
            for(unsigned int i = 0 ; i < size; i++){
                if(*(expectedReadData+i) != *(readData+i)){
                    re_printf("error", "Transactor does not operate correctly because read value differs from expected one \n");
                    sim_continue = false;
                }
                sc_assert(sim_continue != false);
            }
       }
       if(EnableDumpMsg){
            printf("info [%s] [%20.0f %s] Issue transaction:[%s] %08X :%d ", this->name(), sim_time, resolution.c_str(), action.c_str(), addr, size);
            unsigned int loop = (size/4) + (size%4 ? 1:0);
            unsigned int* p_temp = new unsigned int [loop];
            memcpy(p_temp, p_data, size);
            for(unsigned int i = 0; i< loop; i++){
                printf("\t0x%08X",*(p_temp+i));
            }
            printf("\n");
            delete [] p_temp;
       } else{
           //do nothing
       }
    } else {
        //do nothing
    }
    delete [] expectedReadData;
    delete [] readData;
}
// vim600: set foldmethod=marker :
