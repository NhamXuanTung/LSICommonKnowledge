//$Id: gen_master.h, v1.0 2017/08/30 14:50:52 watanama Exp $
/****************************************************************************
* File name : gen_master.h
****************************************************************************/
#ifndef  __GEN_MASTER_H__
#define  __GEN_MASTER_H__

#include <stdint.h>
#include "systemc.h"
#include "tlm_tgt_if.h"
#include "tlm_ini_if.h"
#include "gen_master_regif.h"

#define BUS_WIDTH_INI 64
#define BUS_WIDTH_TGT 32

//===============Cgen_master class=======================
class Cgen_master : public Cgen_master_regif
                  , public vpcl::tlm_tgt_if<BUS_WIDTH_TGT>
                  , public vpcl::tlm_ini_if<BUS_WIDTH_INI>
{//{{{ 
#include "gen_master_cmdif.h"    
public:
    //Construct and Destruct
    SC_HAS_PROCESS(Cgen_master);
    Cgen_master(sc_module_name name);
    ~Cgen_master();    

private:
    //Read/Write transaction
    bool read (const bool is_rd_dbg, unsigned int addr, unsigned char *p_data, unsigned int size);
    bool write (const bool is_wr_dbg, unsigned int addr, unsigned char *p_data, unsigned int size);
    void preTrans (tlm::tlm_command cmd, unsigned int mod, unsigned int addr, unsigned char *p_data, unsigned int size);
    void issueTrans (void);
    
    void SetLatency_TLM(const bool is_constructor);
    
    //Virtual function of tlm_tgt_if
    void tgt_acc(unsigned int id, tlm::tlm_generic_payload &trans, sc_time &t);
    void tgt_acc( tlm::tlm_generic_payload &trans, sc_time &t);
    unsigned int tgt_acc_dbg(unsigned int id, tlm::tlm_generic_payload &trans);
    unsigned int tgt_acc_dbg( tlm::tlm_generic_payload &trans);
};//}}}
#endif //__GEN_MASTER_H__
