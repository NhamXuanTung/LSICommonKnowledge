// ---------------------------------------------------------------------
// $Id: transactor.h,v 1.1.1.1 2013/11/28 11:50:49 honglam Exp $
//
// Copyright(c) 2012 Renesas Electronics Corporation
// Copyright(c) 2012 Renesas Design Vietnam Co., Ltd.
// RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
// This program must be used solely for the purpose for which
// it was furnished by Renesas Electronics Corporation. No part of this
// program may be reproduced or disclosed to others, in any
// form, without the prior written permission of Renesas Electronics
// Corporation.
// ---------------------------------------------------------------------

#ifndef __TRANSACTOR_H__
#define __TRANSACTOR_H__
#include "systemc.h"
#include "tlm_ini_if.h"
#include "commandHandler.h"
#include "format_info.h"

#define RAM_MAX_ADDR 0xFFFFFFFF
#define MEMACCESS_LONGWORD 0x04
/// TRANSACTOR model class
class Ctransactor: public sc_module
                   , public vpcl::tlm_ini_if<64>
{
#include "transactor_cmdif.h"
private:
    vpcl::commandHandler * cmd_handler;
    sc_event mTransEvent;
    sc_event mWakeupEvent;
    std::ifstream mInputStream;
    std::map<unsigned int,bool> mBreakTable;
    bool mIsStopRequest;
public:    
    // declare method
    SC_HAS_PROCESS(Ctransactor);
    Ctransactor(sc_module_name name);
    ~Ctransactor();

    void StartTransactor(void);
    void add_breakpoint(const unsigned int address);
    void GO(void);
    void QUIT(void);
    void BREAK(void);
    void RESET(void);
    void setCommandHandler(vpcl::commandHandler * handler);
    void IssueTransFromFile(void);
    void ProcessTransaction(double sim_time, std::string resolution, std::string action, unsigned int addr, unsigned char size, unsigned char* p_data);
};

#endif //__TRANSACTOR_H__
