//$Id: gen_master.cpp,v1.0 2017/31/08 10:00:07 watanama Exp $
/****************************************************************************
* File name : gen_master.cpp
****************************************************************************/
#include <iostream>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>

#include "gen_master.h"
//================================Cgen_master class===================================
Cgen_master::Cgen_master(sc_module_name name): Cgen_master_regif((std::string)name,32)
                          , vpcl::tlm_tgt_if<BUS_WIDTH_TGT> (name)
                          , vpcl::tlm_ini_if<BUS_WIDTH_INI> (name)                     
{//{{{
    CommandInit(this->name());
    Cgen_master_regif::set_instance_name(this->name());//set hierarchy name
    SC_THREAD(issueTrans);
    SC_THREAD(issueTrans);
    SetLatency_TLM(true);
}//}}}

Cgen_master::~Cgen_master()
{//{{{
}//}}}

bool Cgen_master::read (const bool is_rd_dbg, unsigned int addr, unsigned char *p_data, unsigned int size)
{//{{{
    assert(p_data != NULL);
    memset(p_data, 0, size);
    if (is_rd_dbg == false) {
        return reg_rd(addr,p_data,size);
    } else {
        return reg_rd_dbg(addr,p_data,size);
    }
}//}}}

bool Cgen_master::write (const bool is_wr_dbg, unsigned int addr, unsigned char *p_data, unsigned int size)
{//{{{
    bool ret = false;
    assert(p_data != NULL);
    if (is_wr_dbg == false) {
        ret = reg_wr(addr,p_data,size);
    } else {
        ret = reg_wr_dbg(addr,p_data,size);
    }
    return ret;
}//}}}

void Cgen_master::tgt_acc(unsigned int id, tlm::tlm_generic_payload &trans, sc_time &t)
{//{{{
    // This function is not used because there are 1 TLM target socket
    // It is implemented to fix 1Team issue
    tgt_acc(trans, t);
}//}}}

void Cgen_master::tgt_acc(tlm::tlm_generic_payload &trans, sc_time &t)
{//{{{
    //Get information
    tlm::tlm_command command;
    sc_dt::uint64 addr    = 0;
    unsigned char *p_data  = NULL;
    unsigned int size = 0; 
    bool status = this->tgt_get_gp_attribute(command, addr, p_data, size, trans, false);
    if (!status) {
        trans.set_response_status(tlm::TLM_BYTE_ENABLE_ERROR_RESPONSE);
        return;
    }
    sc_assert(p_data != NULL);

    //Read access
    if (command == tlm::TLM_READ_COMMAND) {
        memset(p_data, 0, size);
        status = read(false, (unsigned int)addr, p_data, size);
    //Write access 
    } else if (command == tlm::TLM_WRITE_COMMAND) {
        status = write(false, (unsigned int)addr, p_data, size);
    //No write/read access    
    } else {
        status = true;
    }
    trans.set_response_status(tlm::TLM_OK_RESPONSE); 
}//}}}

unsigned int Cgen_master::tgt_acc_dbg(unsigned int id, tlm::tlm_generic_payload &trans)
{//{{{
    // This function is not used because there are 1 TLM target socket
    // It is implemented to fix 1Team issue
    return tgt_acc_dbg(trans);
}//}}}

unsigned int Cgen_master::tgt_acc_dbg(tlm::tlm_generic_payload &trans)
{//{{{
    //Get information
    tlm::tlm_command command;
    sc_dt::uint64 addr = 0;
    unsigned char *p_data = NULL;
    unsigned int size = 0;
    bool status = this->tgt_get_gp_attribute(command, addr, p_data, size, trans, true);
    sc_assert(p_data != NULL);

    //Read access
    if (command == tlm::TLM_READ_COMMAND) {
        memset(p_data, 0, size);
        status = read(true, (unsigned int)addr, p_data, size);
    //Write access    
    } else if (command == tlm::TLM_WRITE_COMMAND) {
        status = write(true, (unsigned int)addr, p_data, size);
    //No read/write access    
    } else {
        status = true;
        size = 0;
    }
    trans.set_response_status(tlm::TLM_OK_RESPONSE); 
    if (status){
        return size;
    } else {
        return 0;
    }
}//}}}

void Cgen_master::SetLatency_TLM(const bool is_constructor)
{//{{{
    vpcl::tlm_if_tgt_parameter tgt_param = vpcl::tlm_tgt_if<32>::tgt_get_param();
    if(is_constructor){
        tgt_param.fw_req_phase = tlm::END_REQ;
    }
    sc_time new_clock(25,SC_NS);
    tgt_param.bus_clk = new_clock;
    tgt_param.rd_latency = tgt_param.rd_req_latency + 2 * tgt_param.bus_clk;
    tgt_param.wr_latency = tgt_param.wr_req_latency + 2 * tgt_param.bus_clk;
    vpcl::tlm_tgt_if<32>::tgt_set_param(&tgt_param);
}//}}}

void preTrans (tlm::tlm_command cmd, unsigned int mod, unsigned int addr, unsigned char *p_data, unsigned int size)
{//{{{
    //Set initial value
    tlm::tlm_command command = tlm::TLM_IGNORE_COMMAND;
    sc_dt::uint64 address = 0; 
    unsigned int data_size = 0;
    unsigned int mode = 0;
    
    //Get value
    command = cmd;
    address = (sc_dt::uint64)addr;
    data_size = size;
    mode = mod;
    unsigned char* data = new unsigned char [data_size];
    data = p_data;
    
    //Prepare transaction
    tlm::tlm_generic_payload* trans = this->acquire();
    trans->set_command(command);
    trans->set_address(address);
    trans->set_data_length(data_size);
    trans->set_byte_enable_length(mode); //Set Mode: normal or debug
    trans->set_data_ptr(data);
    //Start issuing transaction
    if(!mode) {
        ini_acc(*trans);    //Normal mode
    }
    else {
        ini_acc_dbg(*trans);    //Debug mode
    }   
    //Wait until get response OK
    for (int i = 0; i < 100; i++) {
        if (trans->get_response_status() == tlm::TLM_INCOMPLETE_RESPONSE) {
            (*TRANS_ST) = 0;
        }
        else {
            break;
        }
    }
    //If response still not OK after waiting. Repeat issuing transaction
    if (trans->get_response_status() == tlm::TLM_INCOMPLETE_RESPONSE) {
        bool status = false;
        while (!status) {
            if(!mode) {
                ini_acc(*trans);    //Normal mode
            }
            else {
                ini_acc_dbg(*trans);    //Debug mode
            }  
            //Wait until get response OK
            for (int i = 0; i < 100; i++) {
                if (trans->get_response_status() == tlm::TLM_INCOMPLETE_RESPONSE) {
                    status = false;
                }
                else {
                    status = true;
                    break;
                }
            }
        }
    }  
    //After issuing completely. Write status into register
    if (trans->get_response_status() == tlm::TLM_OK_RESPONSE) {
        (*TRANS_ST) = 1;
    }
    else if (trans->get_response_status() == tlm::TLM_GENERIC_ERROR_RESPONSE) {
        (*TRANS_ST) = 2;
    }
    else if (trans->get_response_status() == tlm::TLM_ADDRESS_ERROR_RESPONSE) {
        (*TRANS_ST) = 3;
    }
    else if (trans->get_response_status() == tlm::TLM_COMMAND_ERROR_RESPONSE) {
        (*TRANS_ST) = 4;
    }
    else if (trans->get_response_status() == tlm::TLM_BURST_ERROR_RESPONSE) {
        (*TRANS_ST) = 5;
    }
    else if (trans->get_response_status() == tlm::TLM_BYTE_ENABLE_ERROR_RESPONSE){
        (*TRANS_ST) = 6;
    }
    else {
        //Do nothing
    }
}//}}}

void issueTrans (void)
{//{{{   
    unsigned int is_issue = (*TRANS_ST)["CTR"];
    tlm::tlm_command cmd;
    unsigned int mod;
    unsigned int addr;
    unsigned int size;
    unsigned int *p_temp;
    if (is_issue) {
        //Get command
        if ((*TRANS_CMD) == 0) {
            cmd = tlm::TLM_IGNORE_COMMAND;
        }
        else if ((*TRANS_CMD) == 1) {
            cmd = tlm::TLM_READ_COMMAND;
        }
        else {
            cmd = tlm::TLM_WRITE_COMMAND;
        }
        //Get address
        addr = unsigned int (*TRANS_ADR);
        //Get mode
        mod = unsigned int (*TRANS_MOD)["MOD"];
        //Get size
        size = unsigned int (*TRANS_LEN);
        //Get data
        *p_temp = new unsigned int [size];
        memcpy(p_temp, p_data, size);
        //Start issuing transaction
        preTrans (cmd, mod, addr, p_data, size);  
    }
    else {
        //Do nothing
    }
}//}}}

void issueTransUsr (const char* description, tlm::tlm_command cmd, unsigned int mod, unsigned int addr, unsigned char *p_data, unsigned int size)
{//{{{   
    printf ("%s\n", description); 
    preTrans (cmd, mod, addr, p_data, size);
}//}}}

void UsrCommand (void) {
    issueTransUsr ("Check debug transaction with TRANS_CMD", 0x1, 0x0, 0x0, 0x1, 0x1);
}






















