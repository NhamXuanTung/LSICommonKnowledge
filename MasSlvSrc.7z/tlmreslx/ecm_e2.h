// ----------------------------------------------------------------------
// $Id: $
//
// Copyright(c) 2015 Renesas System Design Co., Ltd.
// Copyright(c) 2015 Renesas Design Vietnam Co., Ltd.
// RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
// This program must be used solely for the purpose for which
// it was furnished by Renesas Electronics Corporation. No part of this
// program may be reproduced or disclosed to others, in any
// form, without the prior written permission of Renesas Electronics
// Corporation.
// ----------------------------------------------------------------------

#ifndef __ECM_E2_H__
#define __ECM_E2_H__
#include "systemc.h"
#include <sstream>
#include "tlm.h"
#include "tlm_tgt_if.h"
#include "Cgeneral_timer.h"
#include "ecm_e2_regif.h"
#include "re_define.h"
#include <iterator>
#include <string>

enum eECM {
    emNumErrorFactor    = 309       //The number of factor
    ,emOffsetDCLS       = 0         //Beginning DCLS error is sgaterr002
    ,emNumStatusReg     = 10
    ,emNumPE            = 8
};
class Cecm_e2_wp;
//===============Cecm_e2 class=======================
class Cecm_e2: public Cecm_e2_regif
           ,public Cgeneral_timer
{
#include "ecm_e2_cmdif.h"
friend class Cecm_e2_wp;

private:
    //Declare enum type
    enum eRegisterArea {
        emMasterArea        = 0         //The register area of Master block
        ,emCheckerArea      = 1         //The register area of Checker block
        ,emCommonArea       = 2         //The common register area
        ,emNoneArea         = 3         //None area is chosen
    };
    enum eDelayTimer {
        emClkDivide         = 1         //The clock divide - a parameter need to set into StartStopCounter
    };
    enum eECMErrorOutputLevel {
        emECMErrorOutputActiveLevel         = 0
        ,emECMErrorOutputInactiveLevel      = 1
    };
    enum eECMInterruptLevel {
        emECMInterruptActiveLevel           = 1
        ,emECMInterruptInactiveLevel        = 0
    };
    enum eECMInternalResetLevel {
        emECMInternalResetActiveLevel       = 0
        ,emECMInternalResetInactiveLevel    = 1
    };

    Cecm_e2_wp* mWrapper;

    //Structure
    struct ECMErrorInputElement {
        sc_in<bool>*    errorin;            //The sgaterrin signal
        sc_out<bool>*   pseudo_error_out;   //The sgatpe signal
        bool            errorin_pre;        //The previous value of errorin
        unsigned int    error_count;        //The count of error input
        vpcl::bit_info* esstr;              //The corresponding ESSTR bit
        vpcl::bit_info* micfg;              //The corresponding MICFG bit
        vpcl::bit_info* nmicfg;             //The corresponding NMICFG bit
        vpcl::bit_info* ircfg;              //The corresponding IRCFG bit
        vpcl::bit_info* emk;                //The corresponding EMK bit
        vpcl::bit_info* esstc;              //The corresponding clear status bit
        vpcl::bit_info* pe;                 //The corresponding PE bit
        vpcl::bit_info* midtmcfg;           //The corresponding maskable interrupt DTMCFG bit
        vpcl::bit_info* nmidtmcfg;          //The corresponding non-maskable interrupt DTMCFG bit
        ECMErrorInputElement(sc_in<bool>* errorin, sc_out<bool>* pseudo_error_out, bool errorin_pre, unsigned int error_count,
        vpcl::bit_info* esstr, vpcl::bit_info* micfg, vpcl::bit_info* nmicfg, vpcl::bit_info* ircfg,
        vpcl::bit_info* emk, vpcl::bit_info* esstc, vpcl::bit_info* pe, vpcl::bit_info* midtmcfg, vpcl::bit_info* nmidtmcfg){
            if ((errorin != NULL) && (pseudo_error_out != NULL)   
            && (esstr != NULL) && (micfg != NULL) && (nmicfg != NULL) && (ircfg != NULL) && (emk != NULL) && (esstc != NULL) && (pe != NULL)
            && (midtmcfg != NULL) && (nmidtmcfg != NULL)){
                this->errorin = errorin;
                this->pseudo_error_out = pseudo_error_out;
                this->errorin_pre = errorin_pre;
                this->error_count = error_count;
                this->esstr = esstr;
                this->micfg = micfg;
                this->nmicfg = nmicfg;
                this->ircfg = ircfg;
                this->emk = emk;
                this->esstc = esstc;
                this->pe = pe;
                this->midtmcfg = midtmcfg;
                this->nmidtmcfg = nmidtmcfg;
            }
        }
    };
    std::vector<ECMErrorInputElement> mErrorInputTable;

    std::vector<sc_out<bool>* > mForcedPortArray;

    struct ProtectedRegisterElement {
        std::string register_name;      //The register name
        unsigned int addr;              //The address of this register
        eRegisterArea register_area;    //The register area
        ProtectedRegisterElement(std::string register_name, unsigned int addr, eRegisterArea register_area){
            this->register_name = register_name;
            this->addr = addr;
            this->register_area = register_area;
        }
    };
    std::vector<ProtectedRegisterElement> mProtectedRegisterTable;

    //Declare event
    sc_event mWriteSGATERROZPortEvent;
    sc_event mWriteSGATERROUTZPortEvent;
    sc_event mWriteSGATRESZPortEvent;
    sc_event mCombineSGATIPEPortEvent;
    sc_event mWriteSGATIPEPortEvent;
    sc_event mWriteSGATNMIPortEvent;
    sc_event mWriteDTMTRGOUTPortEvent[2];
    sc_event mNegateInterruptEvent;
    sc_event mWriteErrOutMskClrPortEvent;
    sc_event mCombineSignalEvent;
    sc_event mECMInitializeEvent;
    sc_event mEnableClearOutputErrEvent;
    sc_event mWritePseudoErrorOutEvent;
    sc_event mUpdateDTMSTACNTCLKBitEvent;
    sc_event mWriteDCLSErrorPortEvent;
    sc_event mUnlockECMEOCCFGEvent;
    sc_event mProcessECMmECTBitEvent;
    sc_event mDelayTimerStopEvent;

    //Declare internal variable
    bool            mSGATI;                 //The value of sgati
    bool            mSGATIPEArray[emNumPE]; //The value of sgati_pe1..8
    bool            mSGATNMI;               //The value of sgatnmi
    bool            mSGATRESZ;              //The value of sgatresz port
    bool            mSGATERROZ;             //The value of sgaterroz port
    bool            mSGATERROUTZ;           //The value of sgaterroutz port
    bool            mSyncSignal;            //The value of 'sync' signal
    bool            mIsECMReset;            //Indicate ECM (Master/Checker) is in reset period
    bool            mHoldSignal;            //Variable shows status of enabling clear error output signal
    double          mCountClock;            //Store value of cntclk
    double          mPCLKClock;             //Store value of pclk
    double          mRetartCounterTime;     //Time when one error occurs 
    unsigned int    mECMEOCCFG;
    unsigned int    mECMmESSTR[emNumStatusReg];         //Store values of status register (ECMmESSTRn)
    bool            mPseudoErrorArray[emNumErrorFactor];   //Store value to write pseudo-error signal
    bool            mIsLockReg;             //Indicate protection registers are lock or not
    bool            mERROUTPEArray[emNumPE];//Store value to write to errout_pe1..8
    bool            mStartSimulation;

    //ECM inherited virtual functions
    void cmpMatchOutputHandling (bool value);

    //ECM Method
    void ECMReceiveErrorInputMethod(void);
    void LoopBackSignalProcessingMethod(void);
    void ClearBreakInfoMethod(void);
    void ECMInitializeMethod(void);
    void WriteSGATERROZPortMethod(void);
    void WriteSGATERROUTZPortMethod(void);
    void WriteSGATRESZPortMethod(void);
    void WriteSGATNMIPortMethod(void);
    void WriteDTMTRGOUTPortMethod(bool dtmtrgout_val);
    void WriteErrOutMskClrPortMethod(void);
    void resstg1zMethod(void);
    void resstg1z_pclkinMethod(void);
    void sgattinMethod(void);
    void sgatpsinMethod(void);
    void DelayTimerConfigureMethod(void);
    void DelayTimerStopMethod(void);
    void EnableClearOutputErrMethod(void);
    void ResetForErrpinMethod(void); 
    void WritePseudoErrorOutMethod(void);
    void CombineSGATIPEPortMethod(void);
    void WriteSGATIPEPortMethod(void);
    void WriteDCLSErrorPortMethod(void);
    void NegateInterruptMethod(void);
    void UpdateDTMSTACNTCLKBitMethod(void);
    void ProcessECMmECTBitMethod(void);
    void ClearGlobalErrorMethod(void);


    //ECM internal functions
    void start_of_simulation(void);
    bool CheckProtectedRegister(unsigned int addr);
    std::string GetProtectedRegisterName(unsigned int addr);
    bool WriteProtectedRegister(unsigned int addr, unsigned int data, unsigned int size);
    bool CheckBreakProtectionSequence(unsigned int addr, unsigned int data, unsigned int size);
    bool CheckNormalProtectionSequence(unsigned int addr, unsigned int data, unsigned int size);
    bool ProtectionErrorProcess(const bool is_break, unsigned int data);
    void IssueErrorOutput(void);
    void CalculateErrorOutput(void);
    void IssueInterrupt(void);
    void IssueInternalReset(void);
    void StartStopCounter(const bool start);
    void InitializeGeneralTimer(void);
    void InitializeRegistersMethod(void);
    void ErrorInputTableConstruction(void);
    void ProtectedRegisterTableConstruction(void);
    void UpdateErrorStatus(void);
    void ECMEnableReset(const bool is_active);
    void ECMSetZeroClock(const std::string clk_name);
    bool ECMCheckZeroClock(const std::string clk_name);
    bool ECM_common_tgt_rd(const bool is_rd_dbg, unsigned int addr, unsigned char *p_data, unsigned int size);
    bool ECM_common_tgt_wr(const bool is_wr_dbg, unsigned int addr, unsigned char *p_data, unsigned int size);
    unsigned int GetRegisterIndex(unsigned int factor_index);
    std::string GetBitName( const char name[], unsigned int bit_index, unsigned int reg_index);
    double GetCurTime(void);
    //Register IF callback functions
    void cb_ECMmESET_ECMmEST(RegCBstr str);
    void cb_ECMmECLR_ECMmECT(RegCBstr str);
    void cb_ECMEMK0_ECMEMK00100(RegCBstr str);
    void cb_ECMEMK_ECMEMK00(RegCBstr str);
    void cb_ECMEMK9_ECMEMK900(RegCBstr str);
    void cb_ECMESSTC0_ECMCLSSE00100(RegCBstr str);
    void cb_ECMESSTC_ECMCLSSE00(RegCBstr str);
    void cb_ECMESSTC9_ECMCLSSE900(RegCBstr str);
    void cb_ECMKCPROT_KCE(RegCBstr str);
    void cb_ECMPE0_ECMPE00100(RegCBstr str);
    void cb_ECMPE_ECMPE00(RegCBstr str);
    void cb_ECMPE9_ECMPE900(RegCBstr str);
    void cb_ECMDTMCTL_DTMSTP(RegCBstr str);
    void cb_ECMDTMR_ECMDTMR(RegCBstr str);
    void cb_ECMDTMCMP_ECMDTMCMP(RegCBstr str);
    void cb_ECMEOCCFG_ECMEOUTCLRT(RegCBstr str);
    void cb_ECMPEM_MSKC(RegCBstr str);

public:
    //Declare input ports
    sc_in<bool>             erroutresz;
    //sgaterrinN (N = 00 .. 308)
    sc_in<bool>             *sgaterrin[emNumErrorFactor];
    sc_in<bool>             sgaterrlbz;
    sc_in<bool>             sgattin;
    sc_in<bool>             dtmtrgin;
    sc_in<bool>             resstg1z;
    sc_in<bool>             resstg1z_pclkin;
    sc_in<bool>             erroutresz_for_sync;
    sc_in<bool>             errout_clear_mask_in; 

    //Declare output ports
    //sgatpeN (N = 000 .. 308)
    sc_out<bool>    *sgatpe[emNumErrorFactor];
    sc_out<bool>    sgaterroz;
    sc_out<bool>    sgaterroutz;
    sc_out<bool>    *sgati_pe[emNumPE];
    sc_out<bool>    sgatnmi;
    sc_out<bool>    sgatresz;
    sc_out<bool>    dtmtrgout;
    sc_out<bool>    errout_clear_mask_out;
    sc_out<bool>    *errout_pe[emNumPE];
    sc_out<bool>    pseudo_compare_msk_m; 
    sc_out<bool>    pseudo_compare_msk_c; 

    //Construct and Destruct
    SC_HAS_PROCESS(Cecm_e2);
    Cecm_e2(sc_module_name name, Cecm_e2_wp* wrapper);
    ~Cecm_e2();
};

//===============Cecm_e2_wp class=======================
class Cecm_e2_wp: public sc_module 
              ,public vpcl::tlm_tgt_if<32, tlm::tlm_base_protocol_types, 3>
{
#include "ecm_e2_wp_cmdif.h"
private:
    //Declare enum type
    enum eECM_WP {
        emOffsetOfCommon    = 256   //The offset of common from based of each M/C
        ,emNumOfState       = 5     //The number of state
        ,emNanoSecond       = 1000000000
    };
    enum eState {
         emIdleState                    = 0
        ,emErrorInputProcessingState    = 1
        ,emECMProcessingState           = 2
        ,emOutputSignalCombinationState = 3
        ,emResettingState               = 4
    };
    enum eECMId {
        emCommonId = 0
       ,emMasterId = 1
       ,emSlaveId  = 2
       ,emMaxId    = 3
    };

    //Structures
    struct ExternalErrorInputElement {
        sc_in<bool>* external_error;
        std::string error_name;
        bool pre_value;
        ExternalErrorInputElement(sc_in<bool>* external_error, std::string error_name, bool pre_value){
            if (external_error != NULL){
                this->external_error = external_error;
            }
            this->error_name = error_name;
            this->pre_value = pre_value;
        }
    };
    std::vector<ExternalErrorInputElement> mExternalErrorInputTable;

    std::string mStateArray[emNumOfState];

    //Declare event
    sc_event    mCmdResetEvent;
    sc_event    mCancelCmdResetEvent;
    sc_event    mAssertResetEvent;
    sc_event    mWriteOutputPortEvent;
    sc_event    mReceiveExternalErrorEvent;
    sc_event    mComparatorTestEvent;

    //Declare internal variable
    eState      mState;             // State of ECM_WP  
    bool        mPortReset;         // Indicate ECM_WP is resetting by preset_n port
    bool        mCmdReset;          // Indicate ECM_WP is resetting by handleCommand
    bool        mIsCmdResetStatus;  // Indicate handleCommand reset status
    double      mResetPeriod;       // handleCommand reset period time
    bool        mECMTI_PE[emNumPE];     // store the value of ecmti_pe1..8 ports
    bool        mECMDCLSINT[emNumPE];   // store the value of ecmdclsint1..8 ports
    bool        mECMTNMI;           // store the value of ecmtnmi port
    bool        mECMTERROZ;         // store the value of ecmterroz port
    bool        mECMTRESZ;          // store the value of ecmtresz port
    bool        mIsInitialize;
    double      mFreqPCLK;
    double      mFreqCNTCLK;
    bool        mSgoterrin;          // The internal error of ECM_WP
    //sgaterrinN_sig (N = 00 .. 308)
    sc_signal<bool, SC_UNCHECKED_WRITERS> *sgaterrin_sig[emNumErrorFactor - 1]; // 0-307
    sc_signal<bool, SC_UNCHECKED_WRITERS> master_sgaterrin308_sig;// counted 8 PE to 308
    sc_signal<bool, SC_UNCHECKED_WRITERS> checker_sgaterrin308_sig;  

    sc_signal<bool, SC_UNCHECKED_WRITERS> master_sgaterroz_sig;
    sc_signal<bool, SC_UNCHECKED_WRITERS> master_sgatnmi_sig;
    sc_signal<bool, SC_UNCHECKED_WRITERS> master_sgatresz_sig;
    sc_signal<bool, SC_UNCHECKED_WRITERS> checker_sgaterroz_sig;
    sc_signal<bool, SC_UNCHECKED_WRITERS> checker_sgatnmi_sig;
    sc_signal<bool, SC_UNCHECKED_WRITERS> checker_sgatresz_sig;
    sc_signal<bool, SC_UNCHECKED_WRITERS> errout_clear_mask_sig;
    sc_signal<bool, SC_UNCHECKED_WRITERS> errout_clear_mask_checker;
    sc_signal<bool, SC_UNCHECKED_WRITERS> master_ecmterrin308msk_m;
    sc_signal<bool, SC_UNCHECKED_WRITERS> master_ecmterrin308msk_c;
    sc_signal<bool, SC_UNCHECKED_WRITERS> checker_ecmterrin308msk_m;
    sc_signal<bool, SC_UNCHECKED_WRITERS> checker_ecmterrin308msk_c;

    //master_sgatpeN_sig (N = 000 .. 308)
    sc_signal<bool, SC_UNCHECKED_WRITERS> *master_sgatpe_sig[emNumErrorFactor];

    //checker_sgatpeN_sig (N = 000 .. 308)
    sc_signal<bool, SC_UNCHECKED_WRITERS> *checker_sgatpe_sig[emNumErrorFactor];

    sc_signal<bool, SC_UNCHECKED_WRITERS> checker_trgout_sig;
    sc_signal<bool, SC_UNCHECKED_WRITERS> master_trgout_sig;
    sc_signal<bool, SC_UNCHECKED_WRITERS> dtmtrgout_sig;

    sc_signal<bool, SC_UNCHECKED_WRITERS> *master_dclsint_sig[emNumPE];
    sc_signal<bool, SC_UNCHECKED_WRITERS> *checker_dclsint_sig[emNumPE];

    sc_signal<bool, SC_UNCHECKED_WRITERS> *master_sgati_pe_sig[emNumPE];
    sc_signal<bool, SC_UNCHECKED_WRITERS> *checker_sgati_pe_sig[emNumPE];

    //ECM_WP Method
    void ReceiveExternalErrorMethod(void);
    void ResetMethod(void);
    void WriteOutputPortMethod(void);
    void CmdResetMethod(void);
    void CancelCmdResetMethod(void);
    void PCLKPeriodMethod(void);
    void CounterPeriodMethod(void);
    void CombineSignalMethod(void);
    void ComparatorTestMethod(void);

    //ECM_WP internal functions
    void SetLatency_TLM(const unsigned int id, const double PCLK_period, const bool is_constructor);
    double GetTimeResolution(void);
    void ExternalErrorInputTableConstruction(void);
    void AssertReset(double delay, double period);
    void SetCLKfreq(std::string clk_name, double clk_freq);
    void DumpStatInfo(void);
    void DumpEnableTransInfo(void);
    void UpdateState(eState prev_state, eState next_state);
    void EnableReset(const bool is_active);
    void ConnectPort(void);
    void InitializeInternalSignal(void);
    void DumpInfo(const char *type, const char *message,...);

    //tlm_tgt_if api functions
    void tgt_acc(unsigned int id, tlm::tlm_generic_payload &trans, sc_time &t);
    unsigned int tgt_acc_dbg(unsigned int id, tlm::tlm_generic_payload &trans);

public:
    //Declare input ports
    sc_in<sc_dt::uint64 >   pclk;
    sc_in<sc_dt::uint64 >   cntclk; 
    sc_in<bool>             preset_n;
    sc_in<bool>             cntclk_preset_n;
    sc_in<bool>             erroutresz;
    sc_in<bool>             cntclk_erroutresz;
    sc_in<bool>             erroutresz_for_sync;
    sc_in<bool>             resstg1z;
    sc_in<bool>             pclkin_resstg1z;
    //ecmterrinN (N = 00 .. 307)
    sc_in<bool>             *ecmterrin[emNumErrorFactor - 1]; // 308 -1 = 307

    sc_in<bool>             ecmterrlbz_m;
    sc_in<bool>             ecmterrlbz_c;
    sc_in<bool>             ecmttin;
    sc_in<bool>             svaccess;

    //Declare output ports
    sc_out<bool>            ecmterroz;
    sc_out<bool>            ecmterroutz;
    sc_out<bool>            *ecmti_pe[emNumPE];
    sc_out<bool>            ecmtnmi;
    sc_out<bool>            ecmtresz;
    sc_out<bool>            *ecmdclsint[emNumPE];
    sc_out<bool>            ecmterroutz_m;
    sc_out<bool>            ecmterroutz_c;

    //Declare Master, Checker
    Cecm_e2            *mMaster;
    Cecm_e2            *mChecker;

    sc_core::sc_attribute<std::string> TARGET_PRODUCT;

    //Public functions
    std::string GetMasterCheckerName(const bool is_master) const;

    //Construct and Destruct
    SC_HAS_PROCESS(Cecm_e2_wp);
    Cecm_e2_wp(sc_module_name name);
    ~Cecm_e2_wp();
};
#endif //__ECM_E2_H__

// vim600: set foldmethod=marker :
