// ---------------------------------------------------------------------
// $Id: control_port.h,v 1.3 2014/01/24 02:33:10 uyenle Exp $
//
// Copyright(c) 2012 Renesas Electronics Corporation
// Copyright(c) 2012 Renesas Design Vietnam Co., Ltd.
// RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
// This program must be used solely for the purpose for which
// it was furnished by Renesas Electronics Corporation. No part of this
// program may be reproduced or disclosed to others, in any
// form, without the prior written permission of Renesas Electronics
// Corporation.
// ---------------------------------------------------------------------

#ifndef  __CONTROL_PORT_H__
#define  __CONTROL_PORT_H__

#include "systemc.h"
#include "ecm_e2.h"
#include "control_port_regif.h"
#include "tlm_tgt_if.h"
#include "cpu.h"

//using namespace vpcl;

class Ccontrol_port: public sc_module
                   , public Ccontrol_port_regif
                   , public vpcl::tlm_tgt_if<32>
{
private:
    enum eControlPortParam {
        emNUM_PORT = 308
        ,emNumPE            = 8
    };
public:
    //Delacre pointers
    Cecm_e2_wp *ecm_wp;

    // Port declaration
    sc_out<sc_dt::uint64 >   pclk;
    sc_out<sc_dt::uint64 >   cntclk; 
    sc_out<bool>             preset_n;
    sc_out<bool>             cntclk_preset_n;
    sc_out<bool>             erroutresz ;
    sc_out<bool>             cntclk_erroutresz;
    sc_out<bool>             resstg1z;
    sc_out<bool>             pclkin_resstg1z;
    sc_out<bool>             svaccess;
    //ecmterrinN (N = 00 .. 115)
    //{{{ 
    sc_out<bool>             *ecmterrin[emNUM_PORT];
    //}}}
    sc_out<bool>             ecmterrlbz_m;
    sc_out<bool>             ecmterrlbz_c;
    sc_out<bool>             ecmttin;

    //Declare input ports
    sc_in<bool>            ecmterroz;
    sc_in<bool>            ecmterroutz;
    sc_in<bool>            *ecmti_pe[emNumPE];
    sc_in<bool>            ecmtnmi;
    sc_in<bool>            ecmtresz;
    sc_in<bool>            *ecmdclsint[emNumPE];
    sc_in<bool>            ecmterroutz_m;
    sc_in<bool>            ecmterroutz_c;
    Ccpu *p_cpu;
    sc_event AccDebugEvent;

    SC_HAS_PROCESS (Ccontrol_port);
    Ccontrol_port(sc_module_name name);
    ~Ccontrol_port();

    void set_ecm_pointer(Cecm_e2_wp *ecm_wp);
    std::string handleCommand(const std::vector<std::string> &args);
    void AccDebug_Thread ();
    void set_cpu_pointer(Ccpu *cpu);

private:
    bool           m_ecmti_pe[8];

    sc_event mWriteErrorPortEvent;
    bool mOldErrorStatus[emNUM_PORT];
    std::string mPortname[emNUM_PORT];

    void tgt_acc(tlm::tlm_generic_payload &trans, sc_time &t);
    unsigned int tgt_acc_dbg(tlm::tlm_generic_payload &trans);    

    void ERROUTZ_Method(void);
    void ERROUTZ_M_Method(void);
    void ERROUTZ_C_Method(void);
    void ERROZ_Method(void);
    void RESZ_Method(void);
    void WriteError0_Method(void);
    void WriteError1_Method(void);
    void ECMTIPE1_Method(void);
    void ECMTIPE2_Method(void);
    void ECMTIPE3_Method(void);
    void ECMTIPE4_Method(void);
    void ECMTIPE5_Method(void);
    void ECMTIPE6_Method(void);
    void ECMTIPE7_Method(void);
    void ECMTIPE8_Method(void);
    void NMI_Method(void);
    void PortRead(void);
    void DumpCommandInfo(std::vector<std::string> cmd, std::string target = "");
    void ECMDCLSINT1_Method(void);
    void ECMDCLSINT2_Method(void);
    void ECMDCLSINT3_Method(void);
    void ECMDCLSINT4_Method(void);
    void ECMDCLSINT5_Method(void);
    void ECMDCLSINT6_Method(void);
    void ECMDCLSINT7_Method(void);
    void ECMDCLSINT8_Method(void);

    bool mPCLKupdate;
    bool mERRINupdate;
    bool mERRLBZUpdate;
    bool mMSKERRINupdate;

    // Register IF callback functions
    void cb_PCLK0_PCLK0(RegCBstr str);
    void cb_PCLK1_PCLK1(RegCBstr str);
    void cb_CNTCLK0_CNTCLK0(RegCBstr str);
    void cb_CNTCLK1_CNTCLK1(RegCBstr str);
    void cb_PRESETN_PRESETN(RegCBstr str);
    void cb_ERROUTRESZ_ERROUTRESZ(RegCBstr str);
    void cb_RESSTG1Z_RESSTG1Z(RegCBstr str);
    void cb_ERRIN0_ERRIN0(RegCBstr str);
    void cb_ERRIN1_ERRIN1(RegCBstr str);
    void cb_ERRIN2_ERRIN2(RegCBstr str);
    void cb_ERRIN3_ERRIN3(RegCBstr str);
    void cb_MSKERRIN_MSKERRIN124_C(RegCBstr str);
    void cb_ERRLBZ_M_ERRLBZ_M(RegCBstr str);
    void cb_TIN_ECMTTIN(RegCBstr str);
    void cb_TIPE1_TIPE1(RegCBstr str);
    void cb_TIPE2_TIPE2(RegCBstr str);
    void cb_TIPE3_TIPE3(RegCBstr str);
    void cb_TIPE4_TIPE4(RegCBstr str);
    void cb_TIPE5_TIPE5(RegCBstr str);
    void cb_TIPE6_TIPE6(RegCBstr str);
    void cb_TIPE7_TIPE7(RegCBstr str);
    void cb_TIPE8_TIPE8(RegCBstr str);
    void cb_CTRL_CTRL(RegCBstr str);
    void cb_HDLECOMM_FREQ_PCLK_SET(RegCBstr str);
    void cb_ERRIN4_ERRIN4(RegCBstr str);
    void cb_ERRIN5_ERRIN5(RegCBstr str);
    void cb_ERRIN6_ERRIN6(RegCBstr str);
    void cb_ERRIN7_ERRIN7(RegCBstr str);
    void cb_ERRIN8_ERRIN8(RegCBstr str);
    void cb_ERRIN9_ERRIN9(RegCBstr str);
    void cb_ERRLBZ_C_ERRLBZ_C(RegCBstr str);
    void cb_GLOBAL_ERRCLR_GLOBAL_ERRCLR(RegCBstr str);

   void issue_dbg_trans (bool check, const char* description, unsigned long data, unsigned long expected_value, unsigned int addr, unsigned int size);
   void issue_dbg_trans (bool check, const char* description, unsigned long data, unsigned long expected_value, unsigned long dbg_expected_value, unsigned int addr, unsigned int size);
   void issue_dbg_trans_read (bool check, const char* description, unsigned long data, unsigned long expected_8, unsigned long expected_16, unsigned long expected_32, unsigned int addr, unsigned int size);
};

#endif //__CONTROL_PORT_H__
// vim600: set foldmethod=marker :
