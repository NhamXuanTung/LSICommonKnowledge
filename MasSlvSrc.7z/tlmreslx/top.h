// ----------------------------------------------------------------------
//   $Id: top.h.skl,v 1.1.1.1 2013/05/13 13:41:47 trongtruong Exp $
// ----------------------------------------------------------------------
//   (C) Copyright 2010   RVC (Renesas Design Vietnam Co., Ltd.)
//   All rights reserved. RVC Confidential Proprietary
//   (C) Copyright 2010   RENESAS Electronics Corp.  All rights reserved.
// ----------------------------------------------------------------------

#ifndef __TOP_H__
#define __TOP_H__

#include <systemc.h>
#include "commandHandler.h"

extern char* trace_file_namep;

#define SDRAM_2G_ENABLE 
#define SHWY64_ENABLE 
#define SBSC_1PORT_ENABLE 
#define BUSWIDTH_1 64
#define BUSWIDTH_2 32

#include "simple_memory.h"
#include "Shwy.h"
#include "cpu.h"
#include "tlm_dconv.h"
#include "ecm_e2.h"
#include "control_port.h"
#include "control_port_regif.h"
#include "clk_gen.h"
#include "general_io.h"
#include "general_io_regif.h"

// =====  %%GEN_SPECIFIC_INCLUDE_HEADERS_POST_START  ===== >>>
// any additional code here
// =====  %%GEN_SPECIFIC_INCLUDE_HEADERS_POST_END  ===== >>>

class Creslx: public sc_module
{
public:
    sc_signal<bool>	ecmterrlbz_ma;
    sc_signal<bool>	preset_na;
    sc_signal<bool>	ecmterroutza;
    sc_signal<bool>	ecmtnmia;
    sc_signal<bool>	ecmterrina[308];
    sc_signal<bool>	ecmterroutz;
    sc_signal<bool>	svaccessa;
    sc_signal<bool>	pclkin_resstg1za;
    sc_signal<bool>	cntclk_erroutresza;
    sc_signal<bool>	ecmterrlbz_ca;
    sc_signal<sc_dt::uint64>	pclk;
    sc_signal<bool>	erroutresz_for_sync;
    sc_signal<bool>	ecmterroutz_ca;
    sc_signal<bool>	ecmterrin[308];
    sc_signal<bool>	ecmti_pea[8];
    sc_signal<bool>	ecmterroutz_ma;
    sc_signal<bool>	ecmdclsint[8];
    sc_signal<bool>	erroutresz;
    sc_signal<bool>	ecmterrlbz_c;
    sc_signal<bool>	erroutresza;
    sc_signal<bool>	cntclk_erroutresz;
    sc_signal<bool>	ecmterroutz_m;
    sc_signal<bool>	ecmttin;
    sc_signal<bool>	pclkin_resstg1z;
    sc_signal<bool>	ecmtresz;
    sc_signal<bool>	preset_n;
    sc_signal<bool>	cntclk_preset_na;
    sc_signal<bool>	ecmtresza;
    sc_signal<bool>	gated_iclk;
    sc_signal<bool>	resstg1za;
    sc_signal<bool>	ecmterroza;
    sc_signal<bool>	ecmterroutz_c;
    sc_inout<bool>	reset;
    sc_signal<bool>	ecmti_pe[8];
    sc_signal<bool>	ecmtnmi;
    sc_signal<bool>	ecmttina;
    sc_signal<sc_dt::uint64>	cntclk;
    sc_signal<sc_dt::uint64>	cntclka;
    sc_signal<bool>	ecmterrlbz_m;
    sc_signal<bool>	ecmterroz;
    sc_signal<bool>	resstg1z;
    sc_signal<bool>	ecmdclsinta[8];
    sc_signal<bool>	svaccess;
    sc_signal<sc_dt::uint64>	pclka;
    sc_signal<bool>	cntclk_preset_n;
    //sc_signal<bool>	stub_Cgeneral_oresetL_port[][7];
    //sc_signal<bool>	stub_Cgeneral_ibool_port[][21];
    //sc_signal<bool>	stub_Cgeneral_obool_port[][312];
    //sc_signal<sc_dt::uint64>	stub_Cgeneral_oclk_port[][2];
    sc_signal<bool>	stub_cpu_irq_out;
    sc_signal<sc_uint<9> >	stub_cpu_inpt_int_evt;
    sc_signal<bool>	stub_cpu_irq_in;
    sc_signal<sc_uint<4> >	stub_cpu_inpt_int_priority;

    // pointer for module instance
    Csimple_memory<BUSWIDTH_1> *simple_memory;
    Shwy<1,2,BUSWIDTH_1> *bus_shwy_64;
    Ccpu *cpu;
    tlm_dconv<BUSWIDTH_1,BUSWIDTH_2> *dconv;
    Shwy<1,10,BUSWIDTH_2> *bus_shwy_32;
    Cecm_e2_wp *ecm_wp_fcc1;
    Cecm_e2_wp *ecm_wp;
    Ccontrol_port *control_port;
    Cclk_gen *iclk_gated;
    CgeneralIO *Cgeneral;

    // =====  %%GEN_SPECIFIC_MODULE_POINTERS_POST_START  ===== >>>
    // any additional code here
    // =====  %%GEN_SPECIFIC_MODULE_POINTERS_POST_END  ===== <<<

    vpcl::commandHandler *cmd_handler;   

    SC_HAS_PROCESS (Creslx);
    Creslx (sc_module_name name) :
    sc_module (name)
        ,ecmterrlbz_ma("ecmterrlbz_ma")
        ,preset_na("preset_na")
        ,ecmterroutza("ecmterroutza")
        ,ecmtnmia("ecmtnmia")
        ,cntclk_preset_na("cntclk_preset_na")
        ,ecmterroutz("ecmterroutz")
        ,svaccessa("svaccessa")
        ,pclkin_resstg1za("pclkin_resstg1za")
        ,cntclk_erroutresza("cntclk_erroutresza")
        ,ecmterrlbz_ca("ecmterrlbz_ca")
        ,ecmterroutz_ca("ecmterroutz_ca")
        ,ecmterroutz_ma("ecmterroutz_ma")
        ,pclk("pclk")
        ,erroutresz("erroutresz")
        ,ecmterrlbz_c("ecmterrlbz_c")
        ,erroutresza("erroutresza")
        ,cntclk_erroutresz("cntclk_erroutresz")
        ,ecmterroutz_m("ecmterroutz_m")
        ,ecmttin("ecmttin")
        ,pclkin_resstg1z("pclkin_resstg1z")
        ,ecmtresz("ecmtresz")
        ,preset_n("preset_n")
        ,ecmtresza("ecmtresza")
        ,gated_iclk("gated_iclk")
        ,resstg1za("resstg1za")
        ,ecmterroza("ecmterroza")
        ,ecmterroutz_c("ecmterroutz_c")
        ,reset("reset")
        ,ecmtnmi("ecmtnmi")
        ,ecmttina("ecmttina")
        ,cntclk("cntclk")
        ,cntclka("cntclka")
        ,ecmterrlbz_m("ecmterrlbz_m")
        ,ecmterroz("ecmterroz")
        ,resstg1z("resstg1z")
        ,svaccess("svaccess")
        ,pclka("pclka")
        ,cntclk_preset_n("cntclk_preset_n")
        ,erroutresz_for_sync("erroutresz_for_sync")
        ,stub_cpu_irq_out("stub_cpu_irq_out")
        ,stub_cpu_inpt_int_evt("stub_cpu_inpt_int_evt")
        ,stub_cpu_irq_in("stub_cpu_irq_in")
        ,stub_cpu_inpt_int_priority("stub_cpu_inpt_int_priority")
    {
        // module instantiation
        simple_memory = new Csimple_memory<BUSWIDTH_1>("simple_memory");
        bus_shwy_64 = new Shwy<1,2,BUSWIDTH_1>("bus_shwy_64");
        cpu = new Ccpu("cpu",0,0);
        dconv = new tlm_dconv<BUSWIDTH_1,BUSWIDTH_2>("dconv");
        bus_shwy_32 = new Shwy<1,10,BUSWIDTH_2>("bus_shwy_32");
        ecm_wp_fcc1 = new Cecm_e2_wp("ecm_wp_fcc1");
        ecm_wp = new Cecm_e2_wp("ecm_wp");
        control_port = new Ccontrol_port("control_port");
        iclk_gated = new Cclk_gen("iclk_gated");
        Cgeneral = new CgeneralIO("Cgeneral");
        // =====  %%GEN_SPECIFIC_MODULE_INSTANTIATION_POST_START  ===== >>>
        // any additional code here
        control_port->set_ecm_pointer(ecm_wp);
        control_port->set_ecm_pointer(ecm_wp_fcc1);
        // =====  %%GEN_SPECIFIC_MODULE_INSTANTIATION_POST_END  ===== <<<

        //connect modules
        //cpu->m_ini_socket(bus_shwy_64->target_socket[0]);
        //bus_shwy_64->initiator_socket[0](*simple_memory->m_mem_sockets[0]);
        //bus_shwy_64->initiator_socket[1](dconv->m_tgt_socket);
        //dconv->m_ini_socket(bus_shwy_32->target_socket[0]);
        //bus_shwy_32->initiator_socket[0](*cpu->m_tgt_sockets[0]);
        //bus_shwy_32->initiator_socket[1](*ecm_wp->m_tgt_sockets[0]);
        //bus_shwy_32->initiator_socket[2](*ecm_wp->m_tgt_sockets[1]);
        //bus_shwy_32->initiator_socket[3](*ecm_wp->m_tgt_sockets[2]);
        //bus_shwy_32->initiator_socket[4](*ecm_wp_fcc1->m_tgt_sockets[0]);
        //bus_shwy_32->initiator_socket[5](*ecm_wp_fcc1->m_tgt_sockets[1]);
        //bus_shwy_32->initiator_socket[6](*ecm_wp_fcc1->m_tgt_sockets[2]);
        //bus_shwy_32->initiator_socket[7](*control_port->m_tgt_sockets[0]);
        //bus_shwy_32->initiator_socket[8](*iclk_gated->m_tgt_sockets[0]);
        //bus_shwy_32->initiator_socket[9](*Cgeneral->m_tgt_sockets[0]);

        cpu->clk_in(gated_iclk);
        cpu->rst_in(reset);
        iclk_gated->clk(gated_iclk);
        //FCC2
        ecm_wp->pclk(pclk);
        ecm_wp->preset_n(preset_n);
        ecm_wp->cntclk(cntclk);
        ecm_wp->cntclk_preset_n(cntclk_preset_n);
        ecm_wp->erroutresz(erroutresz);
        ecm_wp->erroutresz_for_sync(erroutresz_for_sync);
        ecm_wp->cntclk_erroutresz(cntclk_erroutresz);
        ecm_wp->resstg1z(resstg1z);
        ecm_wp->pclkin_resstg1z(pclkin_resstg1z);
        ecm_wp->svaccess(svaccess);
        ecm_wp->ecmterrlbz_m(ecmterrlbz_m);
        ecm_wp->ecmterrlbz_c(ecmterrlbz_c);
        for (unsigned int port_id = 0; port_id < 308 ; port_id ++) {
            ecm_wp->ecmterrin[port_id]->bind(ecmterrin[port_id]);
        }
        ecm_wp->ecmttin(ecmttin);
        ecm_wp->ecmterroz(ecmterroz);
        ecm_wp->ecmterroutz(ecmterroutz);
        for (unsigned int port_id = 0; port_id < 8 ; port_id ++) {
            ecm_wp->ecmti_pe[port_id]->bind(ecmti_pe[port_id]);
        }
        ecm_wp->ecmtnmi(ecmtnmi);
        ecm_wp->ecmtresz(ecmtresz);
        for (unsigned int port_id = 0; port_id < 8 ; port_id ++) {
            ecm_wp->ecmdclsint[port_id]->bind(ecmdclsint[port_id]);
        }
        ecm_wp->ecmterroutz_m(ecmterroutz_m);
        ecm_wp->ecmterroutz_c(ecmterroutz_c);
        //FCC1
        ecm_wp_fcc1->pclk(pclka);
        ecm_wp_fcc1->preset_n(preset_na);
        ecm_wp_fcc1->cntclk(cntclka);
        ecm_wp_fcc1->cntclk_preset_n(cntclk_preset_na);
        ecm_wp_fcc1->erroutresz(erroutresza);
        ecm_wp_fcc1->erroutresz_for_sync(erroutresz_for_sync);
        ecm_wp_fcc1->cntclk_erroutresz(cntclk_erroutresza);
        ecm_wp_fcc1->resstg1z(resstg1za);
        ecm_wp_fcc1->pclkin_resstg1z(pclkin_resstg1za);
        ecm_wp_fcc1->svaccess(svaccessa);
        ecm_wp_fcc1->ecmterrlbz_m(ecmterrlbz_ma);
        ecm_wp_fcc1->ecmterrlbz_c(ecmterrlbz_ca);
        for (unsigned int port_id = 0; port_id < 308 ; port_id ++) {
            ecm_wp_fcc1->ecmterrin[port_id]->bind(ecmterrina[port_id]);
        }
        ecm_wp_fcc1->ecmttin(ecmttina);
        ecm_wp_fcc1->ecmterroz(ecmterroza);
        ecm_wp_fcc1->ecmterroutz(ecmterroutza);
        for (unsigned int port_id = 0; port_id < 8 ; port_id ++) {
            ecm_wp_fcc1->ecmti_pe[port_id]->bind(ecmti_pea[port_id]);
        }
        ecm_wp_fcc1->ecmtnmi(ecmtnmia);
        ecm_wp_fcc1->ecmtresz(ecmtresza);
        for (unsigned int port_id = 0; port_id < 8 ; port_id ++) {
            ecm_wp_fcc1->ecmdclsint[port_id]->bind(ecmdclsinta[port_id]);
        }
        ecm_wp_fcc1->ecmterroutz_m(ecmterroutz_ma);
        ecm_wp_fcc1->ecmterroutz_c(ecmterroutz_ca);
        //CONTROL_PORT
        control_port->pclk(pclka);
        control_port->preset_n(preset_na);
        control_port->cntclk(cntclka);
        control_port->cntclk_preset_n(cntclk_preset_na);
        control_port->erroutresz(erroutresza);
        control_port->cntclk_erroutresz(cntclk_erroutresza);
        control_port->resstg1z(resstg1za);
        control_port->pclkin_resstg1z(pclkin_resstg1za);
        control_port->svaccess(svaccessa);
        control_port->ecmterrlbz_m(ecmterrlbz_ma);
        control_port->ecmterrlbz_c(ecmterrlbz_ca);
        for (unsigned int port_id = 0; port_id < 308 ; port_id ++) {
            control_port->ecmterrin[port_id]->bind(ecmterrina[port_id]);
        }
        control_port->ecmttin(ecmttina);
        control_port->ecmterroz(ecmterroza);
        control_port->ecmterroutz(ecmterroutza);
        for (unsigned int port_id = 0; port_id < 8 ; port_id ++) {
            control_port->ecmti_pe[port_id]->bind(ecmti_pea[port_id]);
        }
        control_port->ecmtnmi(ecmtnmia);
        control_port->ecmtresz(ecmtresza);
        for (unsigned int port_id = 0; port_id < 8 ; port_id ++) {
            control_port->ecmdclsint[port_id]->bind(ecmdclsinta[port_id]);
        }
        control_port->ecmterroutz_m(ecmterroutz_ma);
        control_port->ecmterroutz_c(ecmterroutz_ca);

        //GENERAL_IO
        Cgeneral->oclk_port[0]->bind(pclk);
        Cgeneral->oclk_port[1]->bind(cntclk);
       
        Cgeneral->oresetL_port[0]->bind(preset_n);
        Cgeneral->oresetL_port[1]->bind(cntclk_preset_n);
        Cgeneral->oresetL_port[2]->bind(erroutresz);
        Cgeneral->oresetL_port[3]->bind(cntclk_erroutresz);
        Cgeneral->oresetL_port[4]->bind(resstg1z);
        Cgeneral->oresetL_port[5]->bind(pclkin_resstg1z);
        Cgeneral->oresetL_port[6]->bind(erroutresz_for_sync);

        for (unsigned int port_id = 0; port_id < 308 ; port_id ++) {
            Cgeneral->obool_port[port_id]->bind(ecmterrin[port_id]);
        }
        Cgeneral->obool_port[308]->bind(svaccess);
        Cgeneral->obool_port[309]->bind(ecmterrlbz_m);
        Cgeneral->obool_port[310]->bind(ecmterrlbz_c);
        Cgeneral->obool_port[311]->bind(ecmttin);      
        Cgeneral->ibool_port[0]->bind(ecmterroz);
        Cgeneral->ibool_port[1]->bind(ecmterroutz_m);
        Cgeneral->ibool_port[2]->bind(ecmterroutz_c);
        Cgeneral->ibool_port[3]->bind(ecmtresz);
        Cgeneral->ibool_port[4]->bind(ecmtnmi);
        Cgeneral->ibool_port[5]->bind(ecmti_pe[0]);
        Cgeneral->ibool_port[6]->bind(ecmti_pe[1]);
        Cgeneral->ibool_port[7]->bind(ecmti_pe[2]);
        Cgeneral->ibool_port[8]->bind(ecmti_pe[3]);
        Cgeneral->ibool_port[9]->bind(ecmti_pe[4]);
        Cgeneral->ibool_port[10]->bind(ecmti_pe[5]);
        Cgeneral->ibool_port[11]->bind(ecmti_pe[6]);
        Cgeneral->ibool_port[12]->bind(ecmti_pe[7]);
        Cgeneral->ibool_port[13]->bind(ecmdclsint[0]);
        Cgeneral->ibool_port[14]->bind(ecmdclsint[1]);
        Cgeneral->ibool_port[15]->bind(ecmdclsint[2]);
        Cgeneral->ibool_port[16]->bind(ecmdclsint[3]);
        Cgeneral->ibool_port[17]->bind(ecmdclsint[4]);
        Cgeneral->ibool_port[18]->bind(ecmdclsint[5]);
        Cgeneral->ibool_port[19]->bind(ecmdclsint[6]);
        Cgeneral->ibool_port[20]->bind(ecmdclsint[7]);

        stub_cpu_irq_out = 1;
        stub_cpu_inpt_int_evt = 0;
        stub_cpu_irq_in = 0;
        stub_cpu_inpt_int_priority = 0;
        cpu->irq_out(stub_cpu_irq_out);
        cpu->inpt_int_evt(stub_cpu_inpt_int_evt);
        cpu->irq_in(stub_cpu_irq_in);
        cpu->inpt_int_priority(stub_cpu_inpt_int_priority);
        cpu->m_ini_socket(bus_shwy_64->target_socket[0]);        
        bus_shwy_64->initiator_socket[0](*simple_memory->m_mem_sockets[0]);
        bus_shwy_64->initiator_socket[1](dconv->m_tgt_socket);
        dconv->m_ini_socket(bus_shwy_32->target_socket[0]);
        bus_shwy_32->initiator_socket[0](*cpu->m_tgt_sockets[0]);
        bus_shwy_32->initiator_socket[1](*ecm_wp->m_tgt_sockets[0]);
        bus_shwy_32->initiator_socket[2](*ecm_wp->m_tgt_sockets[1]);
        bus_shwy_32->initiator_socket[3](*ecm_wp->m_tgt_sockets[2]);
        bus_shwy_32->initiator_socket[4](*ecm_wp_fcc1->m_tgt_sockets[0]);
        bus_shwy_32->initiator_socket[5](*ecm_wp_fcc1->m_tgt_sockets[1]);
        bus_shwy_32->initiator_socket[6](*ecm_wp_fcc1->m_tgt_sockets[2]);
        bus_shwy_32->initiator_socket[7](*control_port->m_tgt_sockets[0]);
        bus_shwy_32->initiator_socket[8](*iclk_gated->m_tgt_sockets[0]);
        bus_shwy_32->initiator_socket[9](*Cgeneral->m_tgt_sockets[0]);
        
        // =====  %%GEN_SPECIFIC_CONNECT_MODULES_POST_START  ===== >>>
        control_port->set_cpu_pointer(cpu);
        // any additional code here
        // =====  %%GEN_SPECIFIC_CONNECT_MODULES_POST_END  ===== <<<

        // handleCommand
        cmd_handler = new vpcl::commandHandler("handleCommand");
        cmd_handler->register_command_processor(ecm_wp->GetMasterCheckerName(true),ecm_wp->mMaster,&Cecm_e2::handleCommand);
        cmd_handler->register_command_processor(ecm_wp->GetMasterCheckerName(false),ecm_wp->mChecker,&Cecm_e2::handleCommand);
        cmd_handler->register_command_processor(simple_memory->name(),simple_memory,&Csimple_memory<BUSWIDTH_1>::handleCommand);
        cmd_handler->register_command_processor(bus_shwy_64->name(),bus_shwy_64,&Shwy<1,2,BUSWIDTH_1>::handleCommand);
        cmd_handler->register_command_processor(cpu->name(),cpu,&Ccpu::handleCommand);
        cmd_handler->register_command_processor(dconv->name(),dconv,&tlm_dconv<BUSWIDTH_1,BUSWIDTH_2>::handleCommand);
        cmd_handler->register_command_processor(bus_shwy_32->name(),bus_shwy_32,&Shwy<1,10,BUSWIDTH_2>::handleCommand);
        cmd_handler->register_command_processor(ecm_wp_fcc1->name(),ecm_wp_fcc1,&Cecm_e2_wp::handleCommand);
        cmd_handler->register_command_processor(ecm_wp->name(),ecm_wp,&Cecm_e2_wp::handleCommand);
        cmd_handler->register_command_processor(control_port->name(),control_port,&Ccontrol_port::handleCommand);
        cmd_handler->register_command_processor(iclk_gated->name(),iclk_gated,&Cclk_gen::handleCommand);
        cmd_handler->handleCommand();

        // =====  %%GEN_SPECIFIC_COMMAND_HANDLER_POST_START  ===== >>>
        // any additional code here
        std::vector<std::string> cmd_line;
        cmd_line.clear();
        cmd_line.push_back("gm");
        cmd_line.push_back("AddAreaConfig");
        cmd_line.push_back("AREA0");
        cmd_line.push_back("0x00000000");
        cmd_line.push_back("0x1000000");     // allocate 16MB RAM 
        cmd_line.push_back("true");
        simple_memory->handleCommand(cmd_line);
        cmd_line.clear();
        cmd_line.push_back("gm");
        cmd_line.push_back("AddAreaConfig");
        cmd_line.push_back("AREA1");
        cmd_line.push_back("0x0C000000");
        cmd_line.push_back("0x1000000");     // allocate 16MB RAM
        cmd_line.push_back("true");
        simple_memory->handleCommand(cmd_line);
        cmd_line.clear();
        cmd_line.push_back("gm");
        cmd_line.push_back("AddAreaConfig");
        cmd_line.push_back("AREA2");
        cmd_line.push_back("0x0D000000");
        cmd_line.push_back("0x00900000");     // allocate 16MB RAM
        cmd_line.push_back("true");
        simple_memory->handleCommand(cmd_line);
        cmd_line.clear();
        cmd_line.push_back("gm");
        cmd_line.push_back("AddAreaConfig");
        cmd_line.push_back("AREA3");
        cmd_line.push_back("0x0E200000");
        cmd_line.push_back("0x00800000");     // allocate 16MB RAM
        cmd_line.push_back("true");
        simple_memory->handleCommand(cmd_line);
        cmd_line.clear();
        cmd_line.clear();
        // =====  %%GEN_SPECIFIC_CONNECT_HANDLER_POST_END  ===== <<<

        // trace all signal
        #ifdef __WAVE_DUMP_DEBUG__
        if (trace_file_namep != NULL) {
            sc_trace_file *tf = sc_create_vcd_trace_file(trace_file_namep);
            // =====  %%GEN_SPECIFIC_TRACE_POST_START  ===== >>>
            // any additional code here
            // =====  %%GEN_SPECIFIC_TRACE_POST_END    ===== <<<
        }
        #endif
    }

    ~Creslx() {
        // =====  %%GEN_SPECIFIC_DELETE_MODULE_POINTERS_POST_START  ===== >>>
        // any additional code here
        delete simple_memory;
        simple_memory = NULL;
        // =====  %%GEN_SPECIFIC_DELETE_MODULE_POINTERS_POST_END  ===== <<<
        delete simple_memory;
        delete bus_shwy_64;
        delete cpu;
        delete dconv;
        delete bus_shwy_32;
        delete ecm_wp_fcc1;
        delete ecm_wp;
        delete control_port;
        delete iclk_gated;
        delete Cgeneral;
        delete cmd_handler;
    }
};

#endif // __TOP_H__

