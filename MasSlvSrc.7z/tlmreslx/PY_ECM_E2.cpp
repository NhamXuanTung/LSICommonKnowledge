// -----------------------------------------------------------------------------
// $Id: PY_ECM_E2.cpp,v 1.2 2013/09/09 07:43:35 uyenle Exp $
//
// Copyright(c) 2010-2013 Renesas Electronics Corporation
// Copyright(c) 2013 Renesas Design Vietnam Co., Ltd.
// RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
// This program must be used solely for the purpose for which
// it was furnished by Renesas Electronics Corporation. No part of this
// program may be reproduced or disclosed to others, in any
// form, without the prior written permission of Renesas Electronics
// Corporation.
// -----------------------------------------------------------------------------
#include "PY_ECM_E2.h"
namespace PY_ECM_E2
{
    PyMethodDef mShApiDef[] = {
        {"ECM_E2_DumpInterrupt", DumpInterruptPy, METH_VARARGS, ""},
        {"ECM_E2_EnableTransInfo", EnableTransInfoPy, METH_VARARGS, ""},
        {"ECM_E2_DumpStatInfo", DumpStatInfoPy, METH_VARARGS, ""},
        {"ECM_E2_SetCLKfreq", SetCLKfreqPy, METH_VARARGS, ""},
        {"ECM_E2_tgt", tgtPy, METH_VARARGS, ""},
        {"ECM_E2_port", portPy, METH_VARARGS, ""},
        {"ECM_E2_reg", regPy, METH_VARARGS, ""},
        {"ECM_E2_MessageLevel", MessageLevelPy, METH_VARARGS, ""},
        {"ECM_E2_help", helpPy, METH_VARARGS, ""},
        {"ECM_E2_AssertReset", AssertResetPy, METH_VARARGS, ""},
        {NULL, NULL, 0, NULL}
    };

    void SetPyExtCmd(void)
    {//{{{
        Py_InitModule(PY_INITMODULE_NAME, mShApiDef);
    }//}}}

    void SeparateString(std::vector<std::string> &vtr, const std::string msg)
    {//{{{
        std::istringstream cmd;
        cmd.str(msg);
        std::string temp = "a"; // this operation makes temp to be not empty
        while (temp != "") {
            std::string temp1;
            cmd >> temp1;
            if (temp1 != "") {
                vtr.push_back(temp1);
            }
            temp = temp1;
        }
    }//}}}

    void ProcessCommand(const std::string cmd_id, const std::string cmd_name, char* token, char* input_arg)
    {//{{{
        sc_assert(token != NULL);
        std::vector<std::string> str_arg;
        str_arg.push_back(cmd_id);
        if (cmd_name != "") {
            str_arg.push_back(cmd_name);
        }
        if (input_arg != NULL) {
            SeparateString(str_arg, input_arg);
        }

        std::string ret;
        if ((cmd_name == "port") || (cmd_id == "reg")) { // "port" and "reg" command: token should contain "mMaster" or "mChecker"
            Cecm_e2* obj = dynamic_cast<Cecm_e2*>(sc_find_object(token));
            if (obj != NULL) {
                ret = obj->handleCommand(str_arg);
            }
        } else {
            Cecm_e2_wp* obj = dynamic_cast<Cecm_e2_wp*>(sc_find_object(token));
            if (obj != NULL) {
                ret = obj->handleCommand(str_arg);
            }
        }
        if (ret != "") {
            printf ("%s",ret.c_str());
        }
    }//}}}

    void ProcessCommand_ECM_E2(const std::string cmd_id, const std::string cmd_name, char* token, char* input_arg)
    {//{{{
        sc_assert(token != NULL);
        char token_master[255];
        char token_checker[255];
        strcpy(token_master, token);
        strcat(token_master, ".mMaster");
        strcpy(token_checker, token);
        strcat(token_checker, ".mChecker");
        Cecm_e2* obj_master  = dynamic_cast<Cecm_e2*>(sc_find_object(token_master));
        Cecm_e2* obj_checker = dynamic_cast<Cecm_e2*>(sc_find_object(token_checker));
        if ((obj_master != NULL) && (obj_checker != NULL)) {
            std::vector<std::string> str_arg;
            str_arg.push_back(cmd_id);
            if (cmd_name != "") {
                str_arg.push_back(cmd_name);
            }
            if (input_arg != NULL) {
                SeparateString(str_arg, input_arg);
            }
            std::string ret;
            ret = obj_master->handleCommand(str_arg); // ECM master
            if (ret != "") {
                printf ("%s",ret.c_str());
            }
            ret = obj_checker->handleCommand(str_arg); // ECM checker
            if (ret != "") {
                printf ("%s",ret.c_str());
            }
        }
    }//}}}

    PyObject* DumpInterruptPy(PyObject* self, PyObject* args)
    {//{{{
        sc_assert((self != NULL) && (args != NULL));
        char* input_arg;
        char* token;
        if (PyArg_ParseTuple(args, "ss", &token, &input_arg) == true) {
            ProcessCommand("command", "DumpInterrupt", token, input_arg);
        } else {
            printf ("Wrong number of argurment for ECM_E2_DumpInterrupt command.\n");
        }
        return Py_BuildValue("");
    }//}}}

    PyObject* EnableTransInfoPy(PyObject* self, PyObject* args)
    {//{{{
        sc_assert((self != NULL) && (args != NULL));
        char* input_arg;
        char* token;
        if (PyArg_ParseTuple(args, "ss", &token, &input_arg) == true) {
            ProcessCommand("command", "EnableTransInfo", token, input_arg);
        } else {
            printf ("Wrong number of argurment for ECM_E2_EnableTransInfo command.\n");
        }
        return Py_BuildValue("");
    }//}}}

    PyObject* DumpStatInfoPy(PyObject* self, PyObject* args)
    {//{{{
        sc_assert((self != NULL) && (args != NULL));
        char* token;
        if (PyArg_ParseTuple(args, "s", &token) == true) {
            ProcessCommand("command", "DumpStatInfo", token, NULL);
        } else {
            printf ("Wrong number of argurment for ECM_E2_DumpStatInfo command.\n");
        }
        return Py_BuildValue("");
    }//}}}

    PyObject* SetCLKfreqPy(PyObject* self, PyObject* args)
    {//{{{
        sc_assert((self != NULL) && (args != NULL));
        char* input_arg;
        char* token;
        if (PyArg_ParseTuple(args, "ss", &token, &input_arg) == true) {
            ProcessCommand("command", "SetCLKfreq", token, input_arg);
        } else {
            printf ("Wrong number of argurment for ECM_E2_SetCLKfreq command.\n");
        }
        return Py_BuildValue("");
    }//}}}

    PyObject* tgtPy(PyObject* self, PyObject* args)
    {//{{{
        sc_assert((self != NULL) && (args != NULL));
        char* input_arg;
        char* token;
        if (PyArg_ParseTuple(args, "ss", &token, &input_arg) == true) {
            ProcessCommand("tgt", "", token, input_arg);
        } else {
            printf ("Wrong number of argurment for ECM_E2_tgt command.\n");
        }
        return Py_BuildValue("");
    }//}}}

    PyObject* portPy(PyObject* self, PyObject* args)
    {//{{{
        sc_assert((self != NULL) && (args != NULL));
        char* input_arg;
        char* token;
        if (PyArg_ParseTuple(args, "ss", &token, &input_arg) == true) {
            ProcessCommand("command", "port", token, input_arg);
        } else {
            printf ("Wrong number of argurment for ECM_E2_port command.\n");
        }
        return Py_BuildValue("");
    }//}}}

    PyObject* regPy(PyObject* self, PyObject* args)
    {//{{{
        sc_assert((self != NULL) && (args != NULL));
        char* input_arg;
        char* token;
        if (PyArg_ParseTuple(args, "ss", &token, &input_arg) == true) {
            ProcessCommand("reg", "", token, input_arg);
        } else {
            printf ("Wrong number of argurment for ECM_E2_reg command.\n");
        }
        return Py_BuildValue("");
    }//}}}

    PyObject* MessageLevelPy(PyObject* self, PyObject* args)
    {//{{{
        sc_assert((self != NULL) && (args != NULL));
        char* input_arg;
        char* token;
        if (PyArg_ParseTuple(args, "ss", &token, &input_arg) == true) {
            ProcessCommand("command", "MessageLevel", token, input_arg);
            ProcessCommand_ECM_E2("command", "MessageLevel", token, input_arg);
        } else {
            printf ("Wrong number of argurment for ECM_E2_MessageLevel command.\n");
        }
        return Py_BuildValue("");
    }//}}}

    PyObject* helpPy(PyObject* self, PyObject* args)
    {//{{{
        sc_assert((self != NULL) && (args != NULL));
        char* token;
        if (PyArg_ParseTuple(args, "s", &token) == true) {
            ProcessCommand("command", "help", token, NULL);
            ProcessCommand_ECM_E2("command", "help", token, NULL);
        } else {
            printf ("Wrong number of argurment for ECM_E2_help command.\n");
        }
        return Py_BuildValue("");
    }//}}}

    PyObject* AssertResetPy(PyObject* self, PyObject* args)
    {//{{{
        sc_assert((self != NULL) && (args != NULL));
        char* input_arg;
        char* token;
        if (PyArg_ParseTuple(args, "ss", &token, &input_arg) == true) {
            ProcessCommand("command", "AssertReset", token, input_arg);
        } else {
            printf ("Wrong number of argurment for ECM_E2_AssertReset command.\n");
        }
        return Py_BuildValue("");
    }//}}}

}
// vim600: set foldmethod=marker :
