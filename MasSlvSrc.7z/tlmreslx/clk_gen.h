//$Id$
// *****************************************************************************
// File : clk_gen.h
//
// Copyright (c) 2011 Renesas Electronics Corp.
// 20-1, Josuihon-cho, 5chome, Kodaira-shi, Tokyo
// Japan
// All right reserverd.
//
// Author     : Masashi Watanabe @ Renesas
// Description: Clock generation model with stop/start control
// *****************************************************************************
#ifndef __CLK_GEN_H
#define __CLK_GEN_H
#include <list>
#include <systemc.h>
#ifdef CWR_SYSTEMC
#include "scml.h"
#endif
#include "tlm_tgt_if.h"
#include "clk_gen_regif.h"

class Cclk_gen : public sc_core::sc_module
               , public vpcl::tlm_tgt_if<32>
               , public Cclk_gen_regif
{
#include "clk_gen_cmdif.h"
public:
    sc_out<bool> clk;

    SC_HAS_PROCESS(Cclk_gen);
    Cclk_gen(sc_module_name name) : sc_module(name)
    , vpcl::tlm_tgt_if<32>(name)
    , Cclk_gen_regif((std::string)name,32)
    , clk("clk")
    , mClkEnable("mClkEnable")
    {
        CommandInit(this->name());
        Cclk_gen_regif::set_instance_name(this->name());

        clk.initialize(false);
        mClkEnable = true; // clock is generated at start point

        SC_METHOD(UpdateEnableMethod);
        dont_initialize();
        sensitive << mClkCtrlEvent;

        SC_THREAD(ClkGenerateThread);

        #ifdef CWR_SYSTEMC
        //handle command
        SCML_COMMAND_PROCESSOR(handleCommand);
        SCML_ADD_COMMAND("command", 1, 5, "command <param> <arg> <1/->", "prefix of setting module parameters");
        #endif
    }

private:
    sc_signal<bool> mClkEnable;      // Clock enable
    std::list<bool> mClkEnablePlan;  // Enable control plan
    sc_event_queue  mClkCtrlEvent;   // Change signal event

    // Control clock enable
    void UpdateEnableMethod() {
        bool enable = mClkEnablePlan.front();
        mClkEnablePlan.pop_front();

        printf("[%s] %s is %s\n", sc_time_stamp().to_string().c_str(), this->basename(), enable? "enable" : "disable");
        mClkEnable = enable;
    }

    void ClkGenerateThread() {
        while (true) {
            // stop clock event completely
            if (!mClkEnable) {
                wait(mClkEnable.posedge_event());
            }
            sc_time_unit resolution_unit = SC_NS;
            if (sc_get_time_resolution() < sc_time(1, SC_PS)) {
                resolution_unit = SC_FS;
            } else if (sc_get_time_resolution() < sc_time(1, SC_NS)) {
                resolution_unit = SC_PS;
            } else if (sc_get_time_resolution() < sc_time(1, SC_US)) {
                resolution_unit = SC_NS;
            } else if (sc_get_time_resolution() < sc_time(1, SC_MS)) {
                resolution_unit = SC_US;
            } else if (sc_get_time_resolution() < sc_time(1, SC_SEC)) {
                resolution_unit = SC_MS;
            } else {
                resolution_unit = SC_SEC;
            }

            wait(ClkPeriod/2, resolution_unit);
            clk = 1 - clk.read();
        }
    }

    // Reserve reset signal control plan from command IF
    void ReserveEnableActivity(const double delay_time, const bool is_active) {
        mClkEnablePlan.push_back(is_active);
        mClkCtrlEvent.notify(delay_time, SC_NS);
    }
    void tgt_acc(tlm::tlm_generic_payload &trans,sc_time &t)
    {
        vpcl::tlm_tgt_if_parameter tgt_param = vpcl::tlm_tgt_if<32>::tgt_get_param();
        tlm::tlm_command command;
        sc_dt::uint64 address = 0;
        unsigned char *data_ptr = NULL;
        unsigned int data_length = 0;
        bool status = this -> tgt_get_gp_attribute(command, address, data_ptr, data_length, trans, false);
 
        sc_assert(data_ptr != NULL);
        if(!status){
            trans.set_response_status(tlm::TLM_BYTE_ENABLE_ERROR_RESPONSE);
            return;
        }
        /*callback method*/
        if(command == tlm::TLM_READ_COMMAND){
            status = reg_rd((unsigned int)address, data_ptr, data_length);
        }else if(command == tlm::TLM_WRITE_COMMAND){
            status = reg_wr((unsigned int)address, data_ptr, data_length);
        }else{  //be necessarily TLM_IGNORE_COMMAND
            status = true;
        }
        trans.set_response_status(status ? tlm::TLM_OK_RESPONSE : tlm::TLM_GENERIC_ERROR_RESPONSE);
    }
    void cb_WAITUS_WAITUS(RegCBstr str)
    {
        mClkEnablePlan.push_back(false);
        mClkCtrlEvent.notify(0, SC_US);
        mClkEnablePlan.push_back(true);
        mClkCtrlEvent.notify((unsigned int)(*WAITUS), SC_US);
    }
    void cb_WAITNS_WAITNS(RegCBstr str)
    {
        mClkEnablePlan.push_back(false);
        mClkCtrlEvent.notify(0, SC_NS);
        mClkEnablePlan.push_back(true);
        mClkCtrlEvent.notify((unsigned int)(*WAITNS), SC_NS);
    }
};
#endif//__CLK_GEN_H
