// ---------------------------------------------------------------------
// $Id: control_port.cpp,v 1.5 2014/01/24 02:33:16 uyenle Exp $
//
// Copyright(c) 2012 Renesas Electronics Corporation
// Copyright(c) 2012 Renesas Design Vietnam Co., Ltd.
// RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
// This program must be used solely for the purpose for which
// it was furnished by Renesas Electronics Corporation. No part of this
// program may be reproduced or disclosed to others, in any
// form, without the prior written permission of Renesas Electronics
// Corporation.
// ---------------------------------------------------------------------

#include "control_port.h"
#include "re_define.h"

Ccontrol_port::Ccontrol_port(sc_module_name name): sc_module(name)
        , Ccontrol_port_regif((std::string)name,32)
        , vpcl::tlm_tgt_if<32>(name)
        , pclk("pclk")
        , cntclk        ("cntclk")
        , preset_n("preset_n")
        , cntclk_preset_n ("cntclk_preset_n")
        , erroutresz    ("erroutresz")
        , cntclk_erroutresz ("cntclk_erroutresz")
        , resstg1z      ("resstg1z")
        , pclkin_resstg1z ("pclkin_resstg1z")
        , svaccess ("svaccess")
        , ecmterrlbz_m    ("ecmterrlbz_m")
        , ecmterrlbz_c    ("ecmterrlbz_c")
        , ecmttin       ("ecmttin")
        , ecmterroz     ("ecmterroz")
        , ecmterroutz   ("ecmterroutz")
        , ecmtnmi       ("ecmtnmi")
        , ecmtresz      ("ecmtresz")
        , ecmterroutz_m   ("ecmterroutz_m")
        , ecmterroutz_c   ("ecmterroutz_c")

{//{{{
    Ccontrol_port_regif::set_instance_name(this->name());
    mPCLKupdate = false;
    mERRINupdate = false;
    mERRLBZUpdate = false;
    mMSKERRINupdate = false;
    for (unsigned int index = 0; index < emNUM_PORT; index++){// 308 error out
        std::ostringstream str_ecmterrin;
        str_ecmterrin<<"ecmterrin"<<index;
        ecmterrin[index] = new sc_out<bool>(str_ecmterrin.str().c_str());
        ecmterrin[index]->initialize(0);
        mOldErrorStatus[index] = false;
        mPortname[index] = str_ecmterrin.str();
    }
    for (unsigned int index = 0; index < emNumPE; index++){
        std::ostringstream str_ecmti_pe;
        std::ostringstream str_ecmdclsint;

        str_ecmti_pe<<"ecmti_pe"<<(index+1);// start from 1, not from 0
        str_ecmdclsint<<"ecmdclsint"<<(index+1);// start from 1, not from 0

        ecmti_pe[index] = new sc_in<bool>(str_ecmti_pe.str().c_str());
        ecmdclsint[index] = new sc_in<bool>(str_ecmdclsint.str().c_str());
        m_ecmti_pe[index] = 0;
    }

    //initial value of the ports
    pclk.initialize(0x0);
    cntclk.initialize(0);
    preset_n.initialize(true);
    cntclk_preset_n.initialize(true);
    erroutresz.initialize(true);
    cntclk_erroutresz.initialize(true);
    resstg1z.initialize(true);
    pclkin_resstg1z.initialize(true);
    svaccess.initialize(0);
    ecmterrlbz_m.initialize(false);
    ecmterrlbz_c.initialize(false);
    ecmttin.initialize(false);
//    ecmterrin124msk_m.initialize(false);//remove this port
//    ecmterrin124msk_c.initialize(false);//remove this port

    p_cpu = NULL;

    SC_METHOD(ERROUTZ_Method);
    dont_initialize();
    sensitive << ecmterroutz;

    SC_METHOD(ERROUTZ_M_Method);
    dont_initialize();
    sensitive << ecmterroutz_m;

    SC_METHOD(ERROUTZ_C_Method);
    dont_initialize();
    sensitive << ecmterroutz_c;

    SC_METHOD(ERROZ_Method);
    dont_initialize();
    sensitive << ecmterroz;

    SC_METHOD(RESZ_Method);
    dont_initialize();
    sensitive << ecmtresz;

    SC_METHOD(WriteError0_Method);
    dont_initialize();
    sensitive << mWriteErrorPortEvent;

    SC_METHOD(WriteError1_Method);
    dont_initialize();
    sensitive << mWriteErrorPortEvent;

    SC_METHOD(ECMTIPE1_Method);
    dont_initialize();
    sensitive << *ecmti_pe[0];

    SC_METHOD(ECMTIPE2_Method);
    dont_initialize();
    sensitive << *ecmti_pe[1];

    SC_METHOD(ECMTIPE3_Method);
    dont_initialize();
    sensitive << *ecmti_pe[2];

    SC_METHOD(ECMTIPE4_Method);
    dont_initialize();
    sensitive << *ecmti_pe[3];

    SC_METHOD(ECMTIPE5_Method);
    dont_initialize();
    sensitive << *ecmti_pe[4];

    SC_METHOD(ECMTIPE6_Method);
    dont_initialize();
    sensitive << *ecmti_pe[5];

    SC_METHOD(ECMTIPE7_Method);
    dont_initialize();
    sensitive << *ecmti_pe[6];

    SC_METHOD(ECMTIPE8_Method);
    dont_initialize();
    sensitive << *ecmti_pe[7];

    SC_METHOD(NMI_Method);
    dont_initialize();
    sensitive << ecmtnmi;

    SC_METHOD(ECMDCLSINT1_Method);
    dont_initialize();
    sensitive << *ecmdclsint[0];
    
    SC_METHOD(ECMDCLSINT2_Method);
    dont_initialize();
    sensitive << *ecmdclsint[1];

    SC_METHOD(ECMDCLSINT3_Method);
    dont_initialize();
    sensitive << *ecmdclsint[2];

    SC_METHOD(ECMDCLSINT4_Method);
    dont_initialize();
    sensitive << *ecmdclsint[3];

    SC_METHOD(ECMDCLSINT5_Method);
    dont_initialize();
    sensitive << *ecmdclsint[4];

    SC_METHOD(ECMDCLSINT6_Method);
    dont_initialize();
    sensitive << *ecmdclsint[5];

    SC_METHOD(ECMDCLSINT7_Method);
    dont_initialize();
    sensitive << *ecmdclsint[6];

    SC_METHOD(ECMDCLSINT8_Method);
    dont_initialize();
    sensitive << *ecmdclsint[7];

    SC_THREAD (AccDebug_Thread);
    dont_initialize();
    sensitive << AccDebugEvent;

}//}}} 

Ccontrol_port::~Ccontrol_port(void)
{//{{{
}//}}}

void Ccontrol_port::set_ecm_pointer(Cecm_e2_wp *ecm_wp)
{//{{{
    if (ecm_wp != NULL) {
        this->ecm_wp = ecm_wp;
    }
}//}}}

std::string Ccontrol_port::handleCommand(const std::vector<std::string> &args)
{//{{{
    if (args[0] == "reg") {
      return this->reg_handle_command(args);
    }
    if (args.size() == 1 && args[0] == "start_dbg_trans") {
        AccDebugEvent.notify(10, SC_NS);
    }
    return "";
}//}}}

void Ccontrol_port::tgt_acc(tlm::tlm_generic_payload &trans,sc_time &t)
{//{{{
    /* get transaction attributes */
    tlm::tlm_command command;
    sc_dt::uint64 address = 0;        //Address
    unsigned char *data_ptr = NULL;   //Data pointer
    unsigned int data_length = 0;     //Data length
    bool status = this -> tgt_get_gp_attribute(command, address, data_ptr, data_length, trans, false);//Status of transaction
    fflush(stdout);

    if(!status){
        trans.set_response_status(tlm::TLM_BYTE_ENABLE_ERROR_RESPONSE);
        return;
    }
    sc_assert(data_ptr != NULL);
    if(command == tlm::TLM_READ_COMMAND){
        status = reg_rd((unsigned int)address, data_ptr, data_length);
    }
    else if(command == tlm::TLM_WRITE_COMMAND){
        status = reg_wr((unsigned int)address, data_ptr, data_length);
    }
    else{
        //be necessarily TLM_IGNORE_COMMAND
        status = true;
    }
    trans.set_response_status(status ? tlm::TLM_OK_RESPONSE : tlm::TLM_GENERIC_ERROR_RESPONSE);
}//}}}

unsigned int Ccontrol_port::tgt_acc_dbg(tlm::tlm_generic_payload &trans)
{//{{{
    return 0;
}//}}}

//control operation of Ccontrol_port class
void Ccontrol_port::ERROUTZ_Method(void)
{//{{{
    bool erroutz = ecmterroutz.read();
    (*ERROUTZ) = (unsigned int) erroutz;
    printf("info [%s] (%s) Error terminal output (ecmterroutz) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), erroutz);
}//}}} 

void Ccontrol_port::ERROUTZ_M_Method(void)
{//{{{
    bool erroutz_m = ecmterroutz_m.read();
    (*ERROUTZ_M) = (unsigned int)erroutz_m;
    printf("info [%s] (%s) Error terminal output (ecmterroutz_m) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), erroutz_m);
}//}}} 

void Ccontrol_port::ERROUTZ_C_Method(void)
{//{{{
    bool erroutz_c = ecmterroutz_c.read();
    (*ERROUTZ_C) = (unsigned int)erroutz_c;
    printf("info [%s] (%s) Error terminal output (ecmterroutz_c) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), erroutz_c);
}//}}} 

void Ccontrol_port::ERROZ_Method(void)
{//{{{
    bool erroz = ecmterroz.read();
    (*ERROZ)["ERROZ"] = erroz;
    printf("info [%s] (%s) Error comparing output (ecmterroz) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), erroz);
}//}}}

void Ccontrol_port::RESZ_Method(void)
{//{{{
    bool resz = ecmtresz.read();
    (*RESZ)["ECMTRESZ"] = resz;
    printf("info [%s] (%s) Internal reset output (ecmtresz) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), resz);
}//}}} 

void Ccontrol_port::ECMTIPE1_Method(void)
{//{{{
    bool input_val = ecmti_pe[0]->read();

    if (input_val){
        (*TIPE1) = (unsigned int)(*TIPE1) + 1;
    }
    printf("info [%s] (%s) Maskable interrupt output (ecmti_pe1) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)input_val);
}//}}} 

void Ccontrol_port::ECMTIPE2_Method(void)
{//{{{
    bool input_val = ecmti_pe[1]->read();

    if (input_val){
        (*TIPE2) = (unsigned int)(*TIPE2) + 1;
    }
    printf("info [%s] (%s) Maskable interrupt output (ecmti_pe[2) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)input_val);
}//}}} 

void Ccontrol_port::ECMTIPE3_Method(void)
{//{{{
    bool input_val = ecmti_pe[2]->read();

    if (input_val){
        (*TIPE3) = (unsigned int)(*TIPE3) + 1;
    }
    printf("info [%s] (%s) Maskable interrupt output (ecmti_pe[3) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)input_val);
}//}}} 

void Ccontrol_port::ECMTIPE4_Method(void)
{//{{{
    bool input_val = ecmti_pe[3]->read();

    if (input_val){
        (*TIPE4) = (unsigned int)(*TIPE4) + 1;
    }
    printf("info [%s] (%s) Maskable interrupt output (ecmti_pe[4) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)input_val);
}//}}} 

void Ccontrol_port::ECMTIPE5_Method(void)
{//{{{
    bool input_val = ecmti_pe[4]->read();

    if (input_val){
        (*TIPE5) = (unsigned int)(*TIPE5) + 1;
    }
    printf("info [%s] (%s) Maskable interrupt output (ecmti_pe[5) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)input_val);
}//}}} 

void Ccontrol_port::ECMTIPE6_Method(void)
{//{{{
    bool input_val = ecmti_pe[5]->read();

    if (input_val){
        (*TIPE6) = (unsigned int)(*TIPE6) + 1;
    }
    printf("info [%s] (%s) Maskable interrupt output (ecmti_pe[6) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)input_val);
}//}}} 

void Ccontrol_port::ECMTIPE7_Method(void)
{//{{{
    bool input_val = ecmti_pe[6]->read();

    if (input_val){
        (*TIPE7) = (unsigned int)(*TIPE7) + 1;
    }
    printf("info [%s] (%s) Maskable interrupt output (ecmti_pe[7) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)input_val);
}//}}} 

void Ccontrol_port::ECMTIPE8_Method(void)
{//{{{
    bool input_val = ecmti_pe[7]->read();

    if (input_val){
        (*TIPE8) = (unsigned int)(*TIPE8) + 1;
    }
    printf("info [%s] (%s) Maskable interrupt output (ecmti_pe[8) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)input_val);
}//}}} 

void Ccontrol_port::NMI_Method(void)
{//{{{
    bool nmi = ecmtnmi.read();
    if (nmi){
        (*NMI) = (unsigned int)(*NMI) + 1;
    }
    printf("info [%s] (%s) Nonmaskable interupt (ecmtnmi) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), nmi);
}//}}} 

void Ccontrol_port::ECMDCLSINT1_Method(void)
 {//{{{
    bool input_val = ecmdclsint[0]->read();

    if (input_val){
        (*DCLSINT1) = (unsigned int)(*DCLSINT1) + 1;
    }
    printf("info [%s] (%s) DCLS error output (ecmdclsint[1) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)input_val);
}//}}} 

void Ccontrol_port::ECMDCLSINT2_Method(void)
{//{{{
    bool input_val = ecmdclsint[1]->read();

    if (input_val){
        (*DCLSINT2) = (unsigned int)(*DCLSINT2) + 1;
    }
    printf("info [%s] (%s) DCLS error output (ecmdclsint[2) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)input_val);
}//}}} 

void Ccontrol_port::ECMDCLSINT3_Method(void)
{//{{{
    bool input_val = ecmdclsint[2]->read();

    if (input_val){
        (*DCLSINT3) = (unsigned int)(*DCLSINT3) + 1;
    }
    printf("info [%s] (%s) DCLS error output (ecmdclsint[3) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)input_val);
}//}}} 

void Ccontrol_port::ECMDCLSINT4_Method(void)
{//{{{
    bool input_val = ecmdclsint[3]->read();

    if (input_val){
        (*DCLSINT4) = (unsigned int)(*DCLSINT4) + 1;
    }
    printf("info [%s] (%s) DCLS error output (ecmdclsint[4) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)input_val);
}//}}} 

void Ccontrol_port::ECMDCLSINT5_Method(void)
{//{{{
    bool input_val = ecmdclsint[4]->read();

    if (input_val){
        (*DCLSINT5) = (unsigned int)(*DCLSINT5) + 1;
    }
    printf("info [%s] (%s) DCLS error output (ecmdclsint[5) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)input_val);
}//}}} 

void Ccontrol_port::ECMDCLSINT6_Method(void)
{//{{{
    bool input_val = ecmdclsint[5]->read();

    if (input_val){
        (*DCLSINT6) = (unsigned int)(*DCLSINT6) + 1;
    }
    printf("info [%s] (%s) DCLS error output (ecmdclsint[6) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)input_val);
}//}}} 

void Ccontrol_port::ECMDCLSINT7_Method(void)
{//{{{
    bool input_val = ecmdclsint[6]->read();

    if (input_val){
        (*DCLSINT7) = (unsigned int)(*DCLSINT7) + 1;
    }
    printf("info [%s] (%s) Maskable interrupt output (ecmdclsint[7) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)input_val);
}//}}} 

void Ccontrol_port::ECMDCLSINT8_Method(void)
{//{{{
    bool input_val = ecmdclsint[7]->read();

    if (input_val){
        (*DCLSINT8) = (unsigned int)(*DCLSINT8) + 1;
    }
    printf("info [%s] (%s) Maskable interrupt output (ecmdclsint[8) sent from ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)input_val);
}//}}} 

void Ccontrol_port::PortRead(void)
{//{{{
    bool erroz     = ecmterroz.read();
    bool erroutz = ecmterroutz.read();
    //bool mi        = ecmti.read();
    bool nmi       = ecmtnmi.read();
    bool resz      = ecmtresz.read();
    (*ERROZ)["ERROZ"] = erroz;
    (*ERROUTZ)["ERROUTZ"] = erroutz;
    (*RESZ)["ECMTRESZ"] = resz;
    printf("info [%s] (%s) Value of ecmterroz    : %d\n", sc_time_stamp().to_string().c_str(), this->name(), erroz    );
    printf("info [%s] (%s) Value of ecmterroutz: %d\n", sc_time_stamp().to_string().c_str(), this->name(), erroutz);
    printf("info [%s] (%s) Value of ecmtnmi      : %d\n", sc_time_stamp().to_string().c_str(), this->name(), nmi      );
    printf("info [%s] (%s) Value of ecmtresz     : %d\n", sc_time_stamp().to_string().c_str(), this->name(), resz     );
    for(unsigned int i = 0; i< 8; i++){
        printf("info [%s] (%s) Value of ecmti_pe%d        : %d\n", sc_time_stamp().to_string().c_str(), this->name(), i+1, m_ecmti_pe[i]);
    }
}//}}} 

void Ccontrol_port::WriteError0_Method(void)
{//{{{
    unsigned int value = (unsigned int)(*ERRIN0)&0x1;
    ecmterrin[0]->write(value);
}//}}}

void Ccontrol_port::WriteError1_Method(void)
{//{{{
    unsigned int value = ((unsigned int)(*ERRIN0) >> 1)&0x1;
    ecmterrin[1]->write(value);
}//}}}

void Ccontrol_port::cb_HDLECOMM_FREQ_PCLK_SET(RegCBstr str)
{//{{{
    std::vector<std::string> cmd;
    if ((*HDLECOMM)["FREQ_PCLK_SET"] == 0x1) { // Set value to freq_PCLK
        sc_dt::uint64 pclk0 = (*PCLK0);
        sc_dt::uint64 pclk1 = (*PCLK1);
        sc_dt::uint64 pclk = (pclk1 << 32) | pclk0;
        char tmp[255];
        sprintf(tmp, "%f", (double)pclk);
        cmd.push_back("SetCLKfreq");
        cmd.push_back("pclk");
        cmd.push_back(tmp);
        DumpCommandInfo(cmd);
        ecm_wp->handleCommand(cmd);
    }
    if ((*HDLECOMM)["FREQ_PCLK_GET"] == 0x1) { // Get value of freq_PCLK
        cmd.push_back("tgt");
        cmd.push_back("get_param");
        cmd.push_back("m_bus_clk");
        DumpCommandInfo(cmd);
        std::string str = ecm_wp->handleCommand(cmd);
        printf("pclk frequency = %s\n", str.c_str());
    }
    if ((*HDLECOMM)["ASSERTRESET"] == 0x1) { // command AssertReset
        char start_str[255], period_str[255];
        unsigned int start  = (unsigned int)(*RESET)["START"];
        unsigned int period = (unsigned int)(*RESET)["PERIOD"];
        sprintf(start_str , "%d", start);
        sprintf(period_str, "%d", period);
        cmd.push_back("AssertReset");
        cmd.push_back(start_str);
        cmd.push_back(period_str);
        DumpCommandInfo(cmd);
        ecm_wp->handleCommand(cmd);
    }
    if ((*HDLECOMM)["DUMPSTATINFO"] == 0x1) { // command DumpStatInfo
        cmd.push_back("DumpStatInfo");
        DumpCommandInfo(cmd);
        ecm_wp->handleCommand(cmd);
    }
    if (((*HDLECOMM)["PORT_SET"] == 0x1) || ((*HDLECOMM)["PORT_GET"] == 0x1)) { // set/get value of an ECM port
        char port_name[255], port_val[255];
        unsigned int target  = (unsigned int) (*PORT)["TARGET"];
        unsigned int port_id = (unsigned int) (*PORT)["PORT_SEL"];
        switch (port_id) {
            case 0:
                strcpy(port_name, "sgati_pe1");
		break;
            case 1:
                strcpy(port_name, "sgati_pe2");
		break;
            case 2:
                strcpy(port_name, "sgati_pe3");
		break;
            case 3:
                strcpy(port_name, "sgati_pe4");
		break;
            case 4:
                strcpy(port_name, "sgati_pe5");
		break;
            case 5:
                strcpy(port_name, "sgati_pe6");
		break;
            case 6:
                strcpy(port_name, "sgati_pe7");
		break;
            case 7:
                strcpy(port_name, "sgati_pe8");
		break;
            case 8:
                strcpy(port_name, "sgatnmi");
		break;
            case 9:
                strcpy(port_name, "sgaterroz");
		break;
            case 10:
                strcpy(port_name, "sgatresz");
		break;
            case 11:
                strcpy(port_name, "errout_pe1");
		break;
            case 12:
                strcpy(port_name, "errout_pe2");
		break;
            case 13:
                strcpy(port_name, "errout_pe3");
		break;
            case 14:
                strcpy(port_name, "errout_pe4");
		break;
            case 15:
                strcpy(port_name, "errout_pe5");
		break;
            case 16:
                strcpy(port_name, "errout_pe6");
		break;
            case 17:
                strcpy(port_name, "errout_pe7");
		break;
            case 18:
                strcpy(port_name, "errout_pe8");
		break;
            case 19:
                strcpy(port_name, "dtmtrgout");
		break;
            default:
                break;
        }
        cmd.push_back("port");
        cmd.push_back(port_name);
        if ((*HDLECOMM)["PORT_SET"] == 0x1) {
            unsigned int value   = (unsigned int) (*PORT)["PORT_VAL"];
            if (value == 1) {
                strcpy(port_val,"true");
            } else {
                strcpy(port_val,"false");
            }
            cmd.push_back(port_val);
        }
        std::string str;
        if (target == 0) {
            DumpCommandInfo(cmd, " (mMaster)");
            str = ecm_wp->mMaster->handleCommand(cmd);
        } else {
            DumpCommandInfo(cmd, " (mChecker)");
            str = ecm_wp->mChecker->handleCommand(cmd);
        }
        if ((*HDLECOMM)["PORT_GET"] == 0x1) {
            printf("%s = %s\n", port_name, str.c_str());
        }
    }
    if ((*HDLECOMM)["FORCE_ESS"] == 0x1) { // force value to ECMmESSTR* register
        char reg_name[255], reg_letter[255], reg_val[255];
        unsigned int target  = (*FORCE_ESS_SEL)["TARGET"];
        unsigned int reg_num = (unsigned int) (*FORCE_ESS_SEL)["ESS_REG_NUM"];
        unsigned int reg_id  = (unsigned int) (*FORCE_ESS_SEL)["ESS_REG_LETTER"];
        unsigned int value   = (unsigned int) (*FORCE_ESS_VAL);
        switch (reg_id) {
            case 0:
                strcpy(reg_letter,"A");
                break;
            case 1:
                strcpy(reg_letter,"B");
                break;
            case 2:
                strcpy(reg_letter,"C");
                break;
            default:
                break;
        }
        sprintf(reg_name, "ECMmESSTR%d%s", reg_num, reg_letter);
        sprintf(reg_val, "%d", value);
        cmd.push_back("reg");
        cmd.push_back(reg_name);
        cmd.push_back("force");
        cmd.push_back(reg_val);
        if (target == 0) {
            DumpCommandInfo(cmd, " (mMaster)");
            ecm_wp->mMaster->handleCommand(cmd);
        } else {
            DumpCommandInfo(cmd, " (mChecker)");
            ecm_wp->mChecker->handleCommand(cmd);
        }
    }
    *HDLECOMM = 0x0;
}//}}}

void Ccontrol_port::cb_PCLK0_PCLK0(RegCBstr str)
{//{{{
    mPCLKupdate = true;
}//}}}

void Ccontrol_port::cb_PCLK1_PCLK1(RegCBstr str)
{//{{{
}//}}}

void Ccontrol_port::cb_CNTCLK0_CNTCLK0(RegCBstr str)
{//{{{
    unsigned int counterclock = (unsigned int)str.data;
    cntclk.write(counterclock);
    printf("info [%s] (%s) Issue CNTCLK signal to ECM_WP = 0x%08X.\n", sc_time_stamp().to_string().c_str(), this->name(), counterclock);
}//}}}

void Ccontrol_port::cb_CNTCLK1_CNTCLK1(RegCBstr str)
{//{{{
}//}}}

void Ccontrol_port::cb_PRESETN_PRESETN(RegCBstr str)
{//{{{
    bool preset = str.data & 0x1;
    bool cnt_preset = str.data & 0x2;
    preset_n.write(preset);
    cntclk_preset_n.write(cnt_preset);
    if (!preset){
        printf("info [%s] (%s) Issue PRESETN signal to ECM_WP = %1d.\n", sc_time_stamp().to_string().c_str(), this->name(), preset);
    }else{
        printf("info [%s] (%s)  PRESETN signal is negated = %1d.\n", sc_time_stamp().to_string().c_str(), this->name(), preset);
    }
    if (!cnt_preset){
        printf("info [%s] (%s) Issue CNTCLK_PRESETN signal to ECM_WP = %1d.\n", sc_time_stamp().to_string().c_str(), this->name(), cnt_preset);
    }else{
        printf("info [%s] (%s)  CNTCLK_PRESETN signal is negated = %1d.\n", sc_time_stamp().to_string().c_str(), this->name(), cnt_preset);
    }
}//}}}

void Ccontrol_port::cb_RESSTG1Z_RESSTG1Z(RegCBstr str)
{//{{{
    bool resstg1z_pre_value = resstg1z.read();
    bool pclkin_resstg1z_pre_value = pclkin_resstg1z.read();
    bool resstg1z_value = str.data & 0x1;
    bool pclkin_resstg1z_value = str.data & 0x2;
    if(resstg1z_value != resstg1z_pre_value){
        resstg1z.write(resstg1z_value);
        printf("info [%s] (%s) Issue RESSTG1Z signal to ECM_WP = %1d.\n", sc_time_stamp().to_string().c_str(), this->name(), resstg1z_value);
    }
    if(pclkin_resstg1z_value != pclkin_resstg1z_pre_value){
        pclkin_resstg1z.write(pclkin_resstg1z_value);
        printf("info [%s] (%s) Issue PCLKIN_RESSTG1Z signal to ECM_WP = %1d.\n", sc_time_stamp().to_string().c_str(), this->name(), pclkin_resstg1z_value);
    }
}//}}}

void Ccontrol_port::cb_TIPE1_TIPE1(RegCBstr str)
{//{{{
    if ((unsigned int)(*TIPE1) == 0){
        ECMTIPE1_Method();
    }
}//}}}

void Ccontrol_port::cb_TIPE2_TIPE2(RegCBstr str)
{//{{{
    if ((unsigned int)(*TIPE2) == 0){
        ECMTIPE2_Method();
    }
}//}}}

void Ccontrol_port::cb_TIPE3_TIPE3(RegCBstr str)
{//{{{
    if ((unsigned int)(*TIPE3) == 0){
        ECMTIPE3_Method();
    }
}//}}}

void Ccontrol_port::cb_TIPE4_TIPE4(RegCBstr str)
{//{{{
    if ((unsigned int)(*TIPE4) == 0){
        ECMTIPE4_Method();
    }
}//}}}

void Ccontrol_port::cb_TIPE5_TIPE5(RegCBstr str)
{//{{{
    if ((unsigned int)(*TIPE5) == 0){
        ECMTIPE5_Method();
    }
}//}}}

void Ccontrol_port::cb_TIPE6_TIPE6(RegCBstr str)
{//{{{
    if ((unsigned int)(*TIPE6) == 0){
        ECMTIPE6_Method();
    }
}//}}}

void Ccontrol_port::cb_TIPE7_TIPE7(RegCBstr str)
{//{{{
    if ((unsigned int)(*TIPE7) == 0){
        ECMTIPE7_Method();
    }
}//}}}

void Ccontrol_port::cb_TIPE8_TIPE8(RegCBstr str)
{//{{{
    if ((unsigned int)(*TIPE8) == 0){
        ECMTIPE8_Method();
    }
}//}}}

/*void Ccontrol_port::cb_DCLSINT1_DCLSINT1(RegCBstr str)
{//{{{
    if ((unsigned int)(*DCLSINT1) == 0){
        ECMDCLSINT1_Method();
    }
}//}}}

void Ccontrol_port::cb_DCLSINT2_DCLSINT2(RegCBstr str)
{//{{{
    if ((unsigned int)(*DCLSINT2) == 0){
        ECMDCLSINT2_Method();
    }
}//}}}

void Ccontrol_port::cb_DCLSINT3_DCLSINT3(RegCBstr str)
{//{{{
    if ((unsigned int)(*DCLSINT3) == 0){
        ECMDCLSINT3_Method();
    }
}//}}}

void Ccontrol_port::cb_DCLSINT4_DCLSINT4(RegCBstr str)
{//{{{
    if ((unsigned int)(*DCLSINT4) == 0){
        ECMDCLSINT4_Method();
    }
}//}}}

void Ccontrol_port::cb_DCLSINT5_DCLSINT5(RegCBstr str)
{//{{{
    if ((unsigned int)(*DCLSINT5) == 0){
        ECMDCLSINT5_Method();
    }
}//}}}

void Ccontrol_port::cb_DCLSINT6_DCLSINT6(RegCBstr str)
{//{{{
    if ((unsigned int)(*DCLSINT6) == 0){
        ECMDCLSINT6_Method();
    }
}//}}}

void Ccontrol_port::cb_DCLSINT7_DCLSINT7(RegCBstr str)
{//{{{
    if ((unsigned int)(*DCLSINT7) == 0){
        ECMDCLSINT7_Method();
    }
}//}}}

void Ccontrol_port::cb_DCLSINT8_DCLSINT8(RegCBstr str)
{//{{{
    if ((unsigned int)(*DCLSINT8) == 0){
        ECMDCLSINT8_Method();
    }
}//}}}
*/

void Ccontrol_port::cb_ERRIN0_ERRIN0(RegCBstr str)
{//{{{
    mERRINupdate = true;
}//}}}

void Ccontrol_port::cb_ERRIN1_ERRIN1(RegCBstr str)
{//{{{
    mERRINupdate = true;
}//}}}

void Ccontrol_port::cb_ERRIN2_ERRIN2(RegCBstr str)
{//{{{
    mERRINupdate = true;

}//}}}

void Ccontrol_port::cb_ERRIN3_ERRIN3(RegCBstr str)
{//{{{
    mERRINupdate = true;

}//}}}

void Ccontrol_port::cb_ERRIN4_ERRIN4(RegCBstr str)
{//{{{
    mERRINupdate = true;

}//}}}

void Ccontrol_port::cb_ERRIN5_ERRIN5(RegCBstr str)
{//{{{
    mERRINupdate = true;

}//}}}

void Ccontrol_port::cb_ERRIN6_ERRIN6(RegCBstr str)
{//{{{
    mERRINupdate = true;

}//}}}

void Ccontrol_port::cb_ERRIN7_ERRIN7(RegCBstr str)
{//{{{
    mERRINupdate = true;

}//}}}

void Ccontrol_port::cb_ERRIN8_ERRIN8(RegCBstr str)
{//{{{
    mERRINupdate = true;

}//}}}

void Ccontrol_port::cb_ERRIN9_ERRIN9(RegCBstr str)
{//{{{
    mERRINupdate = true;

}//}}}

void Ccontrol_port::cb_MSKERRIN_MSKERRIN124_C(RegCBstr str)
{//{{{
//    mMSKERRINupdate = true;

}//}}}

void Ccontrol_port::cb_ERRLBZ_M_ERRLBZ_M(RegCBstr str)
{//{{{
    mERRLBZUpdate = true;
}//}}}

void Ccontrol_port::cb_ERRLBZ_C_ERRLBZ_C(RegCBstr str)
{//{{{
    mERRLBZUpdate = true;
}//}}}

void Ccontrol_port::cb_GLOBAL_ERRCLR_GLOBAL_ERRCLR(RegCBstr str)
{//{{{
}//}}}

void Ccontrol_port::cb_TIN_ECMTTIN(RegCBstr str)
{//{{{
    bool value = (bool)(str.data & 0x1);
    ecmttin.write(value);
    printf("info [%s] (%s) Issue timer input signal (for dynamic mode) to ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)value);
}//}}}

void Ccontrol_port::cb_ERROUTRESZ_ERROUTRESZ(RegCBstr str)
{//{{{
    erroutresz.write((bool)(*ERROUTRESZ)["ERROUTRESZ"]);
    cntclk_erroutresz.write((bool)(*ERROUTRESZ)["CNTCLK_ERROUTRESZ"]);
    printf("info [%s] (%s) Write erroutresz = %d\n", sc_time_stamp().to_string().c_str(), this->name(),(unsigned int)(*ERROUTRESZ)["ERROUTRESZ"]);
    printf("info [%s] (%s) Write cntclk_erroutresz = %d\n", sc_time_stamp().to_string().c_str(), this->name(),(unsigned int)(*ERROUTRESZ)["CNTCLK_ERROUTRESZ"]);
}//}}}

//void Ccontrol_port::cb_DCLSINT_ecmdclsint[7](RegCBstr str)
//{
//
//}
void Ccontrol_port::cb_CTRL_CTRL(RegCBstr str)
{//{{{
    if (str.data == 0x0) {
        return;
    }
    bool update = false;
    if (mPCLKupdate == true) {
        unsigned int pclk0 = (*PCLK0);
        unsigned int pclk1 = (*PCLK1);
        sc_dt::uint64 freq_pclk = ((sc_dt::uint64)pclk1 << 32) | pclk0;
        pclk.write(freq_pclk);
        printf("info [%s] (%s) Issue PCLK signal to ECM_WP = 0x%08X%08X.\n", sc_time_stamp().to_string().c_str(), this->name(), pclk1, pclk0);
        mPCLKupdate = false;
        update = true;
    }
    if (mERRLBZUpdate){
        if (str.data == 0x1) {
            bool val_m = (bool)(*ERRLBZ_M);
            ecmterrlbz_m.write(val_m);
            printf("info [%s] (%s) Issue loop-back-Master signal to ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)val_m);

            bool val_c = (bool)(*ERRLBZ_C);
            ecmterrlbz_c.write(val_c);
            printf("info [%s] (%s) Issue loop-back-Checker signal to ECM_WP: %1d\n", sc_time_stamp().to_string().c_str(), this->name(), (unsigned int)val_c);

            mERRLBZUpdate = false;
        }
    }
    if (mERRINupdate == true) {
        if (str.data == 0x1) {
            printf("info [%s] (%s) Error signals to ECM_WP changes:\n", sc_time_stamp().to_string().c_str(), this->name());
            for (unsigned int i=0; i<emNUM_PORT; i++) {
                unsigned char reg_index, bit_index;
                reg_index = i/32;
                bit_index = i%32;

                unsigned int reg_value;
                switch (reg_index) {
                    case 0:
                        reg_value = (*ERRIN0);
                        break;
                    case 1:
                        reg_value = (*ERRIN1);
                        break;
                    case 2:
                        reg_value = (*ERRIN2);
                        break;
                    case 3:
                        reg_value = (*ERRIN3);
                        break;
                    case 4:
                        reg_value = (*ERRIN4);
                        break;
                    case 5:
                        reg_value = (*ERRIN5);
                        break;
                    case 6:
                        reg_value = (*ERRIN6);
                        break;
                    case 7:
                        reg_value = (*ERRIN7);
                        break;
                    case 8:
                        reg_value = (*ERRIN8);
                        break;
                    case 9:
                        reg_value = (*ERRIN9);
                        break;

                    default:
                        break;
                }
                bool bit_value = (reg_value >> bit_index) & 0x1;
                if (bit_value != mOldErrorStatus[i]) {
                    ecmterrin[i]->write(bit_value);
                    printf("       ecmterrin[%2d] (%s) : %1d -> %1d\n", i, mPortname[i].c_str(), mOldErrorStatus[i], bit_value);
                    mOldErrorStatus[i] = bit_value;
                }
            }
            mERRINupdate = false;
            update = true;
        } else {
            mWriteErrorPortEvent.notify();
            mERRINupdate = false;
            update = true;
        }
    }
    if (mMSKERRINupdate){
        /*if (str.data == 0x1) {
            ecmterrin124msk_m.write((bool)(*MSKERRIN)["MSKERRIN124_M"]);
            ecmterrin124msk_c.write((bool)(*MSKERRIN)["MSKERRIN124_C"]);
            printf("info [%s] (%s) Write ecmterrin124msk_m = %d\n", sc_time_stamp().to_string().c_str(), this->name(),(unsigned int)(*MSKERRIN)["MSKERRIN124_M"]);
            printf("info [%s] (%s) Write ecmterrin124msk_c = %d\n", sc_time_stamp().to_string().c_str(), this->name(),(unsigned int)(*MSKERRIN)["MSKERRIN124_C"]);
            mMSKERRINupdate = false;
            update = true;
        }*/ // not use due to ECMPEM register (has MSKM, MSKC)
    }
    if (update == false) { // Read & dump port value
        PortRead();
    }
}//}}}


void Ccontrol_port::DumpCommandInfo(std::vector<std::string> cmd, std::string target)
{//{{{
    printf("info [%s] (%s) Send command to ECM:%s", sc_time_stamp().to_string().c_str(), this->name(), target.c_str());
    for (unsigned int i=0; i<cmd.size(); i++) {
        printf(" %s", cmd[i].c_str());
    }
    printf("\n");
}//}}}

void Ccontrol_port::set_cpu_pointer(Ccpu *cpu)
{//{{{
    p_cpu = cpu;
}//}}} 

void Ccontrol_port::AccDebug_Thread ()
{//{{{
    while (true) {
        // Check debug transaction
		////{{{E2x_FCC1
        issue_dbg_trans(0,"Check debug transaction with ECMMESET ..."   , 0xFFFFFFFF, 0, 0xFF6B0000, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMECLR ..."   , 0xFF, 0, 0xFF6B0004, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR0 ..." , 0xFFFFFFFF, 0, 0xFF6B0008, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR1 ..." , 0xFFFFFFFF, 0, 0xFF6B000C, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR2 ..." , 0xFFFFFFFF, 0x00000000, 0xFF6B0010, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR3 ..." , 0xFFFFFFFF, 0x00000000, 0xFF6B0014, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR4 ..." , 0xFFFFFFFF, 0x00000000, 0xFF6B0018, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR5 ..." , 0xFFFFFFFF, 0x00000000, 0xFF6B001C, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR6 ..." , 0xFFFFFFFF, 0x00000000, 0xFF6B0020, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR7 ..." , 0xFFFFFFFF, 0x00000000, 0xFF6B0024, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR8 ..." , 0xFFFFFFFF, 0x00000000, 0xFF6B0028, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR9 ..." , 0xFFFFFFFF, 0x40000000, 0xFF6B002C, 4);

        issue_dbg_trans(0,"Check debug transaction with ECMCESET ..."   , 0xFF, 0, 0xFF6B1000, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCECLR ..."   , 0xFF, 0, 0xFF6B1004, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR0 ..." , 0xFFFFFFFF, 0, 0xFF6B1008, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR1 ..." , 0xFFFFFFFF, 0, 0xFF6B100C, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR2 ..." , 0xFFFFFFFF, 0, 0xFF6B1010, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR3 ..." , 0xFFFFFFFF, 0, 0xFF6B1014, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR4 ..." , 0xFFFFFFFF, 0, 0xFF6B1018, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR5 ..." , 0xFFFFFFFF, 0, 0xFF6B101C, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR6 ..." , 0xFFFFFFFF, 0, 0xFF6B1020, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR7 ..." , 0xFFFFFFFF, 0, 0xFF6B1024, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR8 ..." , 0xFFFFFFFF, 0, 0xFF6B1028, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR9 ..." , 0xFFFFFFFF, 0x40000000, 0xFF6B102C, 4);

        issue_dbg_trans(0,"Check debug transaction with ECMEPCFG ..."          , 0xFF      , 0x01      , 0xFF6B2000, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B2004, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B2005, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B2006, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B2007, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG1 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B2008, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG1 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B2009, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG1 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B200A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG1 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B200B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG2 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B200C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG2 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B200D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG2 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B200E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG2 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B200F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG3 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B2010, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG3 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B2011, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG3 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B2012, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG3 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B2013, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG4 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B2014, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG4 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B2015, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG4 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B2016, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG4 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B2017, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG5 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B2018, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG5 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B2019, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG5 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B201A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG5 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B201B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG6 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B201C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG6 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B201D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG6 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B201E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG6 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B201F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG7 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B2020, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG7 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B2021, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG7 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B2022, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG7 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B2023, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG8 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B2024, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG8 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B2025, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG8 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B2026, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG8 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B2027, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG9 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B2028, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG9 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B2029, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG9 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B202A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG9 - BYTE3 ..." , 0xFF      , 0x1B      , 0xFF6B202B, 1);

        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG0 - BYTE0 ...", 0xFF      , 0xFF      , 0xFF6B202C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG0 - BYTE1 ...", 0xFF      , 0xFF      , 0xFF6B202D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG0 - BYTE2 ...", 0xFF      , 0xFF      , 0xFF6B202E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG0 - BYTE3 ...", 0xFF      , 0xFF      , 0xFF6B202F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG1 - BYTE0 ...", 0xFF      , 0xFF      , 0xFF6B2030, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG1 - BYTE1 ...", 0xFF      , 0xFF      , 0xFF6B2031, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG1 - BYTE2 ...", 0xFF      , 0xFF      , 0xFF6B2032, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG1 - BYTE3 ...", 0xFF      , 0xFF      , 0xFF6B2033, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG2 - BYTE0 ...", 0xFF      , 0xFF      , 0xFF6B2034, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG2 - BYTE1 ...", 0xFF      , 0xFF      , 0xFF6B2035, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG2 - BYTE2 ...", 0xFF      , 0xFF      , 0xFF6B2036, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG2 - BYTE3 ...", 0xFF      , 0xFF      , 0xFF6B2037, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG3 - BYTE0 ...", 0xFF      , 0xFF      , 0xFF6B2038, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG3 - BYTE1 ...", 0xFF      , 0xFF      , 0xFF6B2039, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG3 - BYTE2 ...", 0xFF      , 0xFF      , 0xFF6B203A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG3 - BYTE3 ...", 0xFF      , 0xFF      , 0xFF6B203B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG4 - BYTE0 ...", 0xFF      , 0xFF      , 0xFF6B203C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG4 - BYTE1 ...", 0xFF      , 0xFF      , 0xFF6B203D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG4 - BYTE2 ...", 0xFF      , 0xFF      , 0xFF6B203E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG4 - BYTE3 ...", 0xFF      , 0xFF      , 0xFF6B203F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG5 - BYTE0 ...", 0xFF      , 0xFF      , 0xFF6B2040, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG5 - BYTE1 ...", 0xFF      , 0xFF      , 0xFF6B2041, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG5 - BYTE2 ...", 0xFF      , 0xFF      , 0xFF6B2042, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG5 - BYTE3 ...", 0xFF      , 0xFF      , 0xFF6B2043, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG6 - BYTE0 ...", 0xFF      , 0xFF      , 0xFF6B2044, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG6 - BYTE1 ...", 0xFF      , 0xFF      , 0xFF6B2045, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG6 - BYTE2 ...", 0xFF      , 0xFF      , 0xFF6B2046, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG6 - BYTE3 ...", 0xFF      , 0xFF      , 0xFF6B2047, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG7 - BYTE0 ...", 0xFF      , 0xFF      , 0xFF6B2048, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG7 - BYTE1 ...", 0xFF      , 0xFF      , 0xFF6B2049, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG7 - BYTE2 ...", 0xFF      , 0xFF      , 0xFF6B204A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG7 - BYTE3 ...", 0xFF      , 0xFF      , 0xFF6B204B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG8 - BYTE0 ...", 0xFF      , 0xFF      , 0xFF6B204C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG8 - BYTE1 ...", 0xFF      , 0xFF      , 0xFF6B204D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG8 - BYTE2 ...", 0xFF      , 0xFF      , 0xFF6B204E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG8 - BYTE3 ...", 0xFF      , 0xFF      , 0xFF6B204F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG9 - BYTE0 ...", 0xFF      , 0xFF      , 0xFF6B2050, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG9 - BYTE1 ...", 0xFF      , 0xFF      , 0xFF6B2051, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG9 - BYTE2 ...", 0xFF      , 0xFF      , 0xFF6B2052, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG9 - BYTE3 ...", 0xFF      , 0x1B      , 0xFF6B2053, 1);

        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG0 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B2054, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG0 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B2055, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG0 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B2056, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG0 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B2057, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG1 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B2058, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG1 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B2059, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG1 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B205A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG1 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B205B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG2 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B205C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG2 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B205D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG2 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B205E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG2 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B205F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG3 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B2060, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG3 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B2061, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG3 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B2062, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG3 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B2063, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG4 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B2064, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG4 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B2065, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG4 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B2066, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG4 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B2067, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG5 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B2068, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG5 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B2069, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG5 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B206A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG5 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B206B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG6 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B206C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG6 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B206D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG6 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B206E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG6 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B206F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG7 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B2070, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG7 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B2071, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG7 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B2072, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG7 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B2073, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG8 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B2074, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG8 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B2075, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG8 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B2076, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG8 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFF6B2077, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG9 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFF6B2078, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG9 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFF6B2079, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG9 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFF6B207A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG9 - BYTE3 ..." , 0xFF      , 0x3B      , 0xFF6B207B, 1);

        issue_dbg_trans(0,"Check debug transaction with ECMEMK0 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFF6B207C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK0 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFF6B207D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK0 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFF6B207E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK0 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFF6B207F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK1 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFF6B2080, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK1 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFF6B2081, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK1 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFF6B2082, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK1 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFF6B2083, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK2 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFF6B2084, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK2 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFF6B2085, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK2 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFF6B2086, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK2 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFF6B2087, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK3 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFF6B2088, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK3 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFF6B2089, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK3 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFF6B208A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK3 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFF6B208B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK4 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFF6B208C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK4 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFF6B208D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK4 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFF6B208E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK4 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFF6B208F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK5 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFF6B2090, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK5 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFF6B2091, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK5 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFF6B2092, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK5 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFF6B2093, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK6 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFF6B2094, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK6 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFF6B2095, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK6 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFF6B2096, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK6 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFF6B2097, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK7 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFF6B2098, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK7 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFF6B2099, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK7 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFF6B209A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK7 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFF6B209B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK8 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFF6B209C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK8 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFF6B209D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK8 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFF6B209E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK8 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFF6B209F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK9 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFF6B20A0, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK9 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFF6B20A1, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK9 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFF6B20A2, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK9 - BYTE3 ..."   , 0xFF      , 0x3B      , 0xFF6B20A3, 1);

        issue_dbg_trans(0,"Check debug transaction with ECMESSTC0 ..."         , 0xFFFFFFFF, 0         , 0xFF6B20A4, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC1 ..."         , 0xFFFFFFFF, 0         , 0xFF6B20A8, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC2 ..."         , 0xFFFFFFFF, 0         , 0xFF6B20AC, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC3 ..."         , 0xFFFFFFFF, 0         , 0xFF6B20B0, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC4 ..."         , 0xFFFFFFFF, 0         , 0xFF6B20B4, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC5 ..."         , 0xFFFFFFFF, 0         , 0xFF6B20B8, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC6 ..."         , 0xFFFFFFFF, 0         , 0xFF6B20BC, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC7 ..."         , 0xFFFFFFFF, 0         , 0xFF6B20C0, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC8 ..."         , 0xFFFFFFFF, 0         , 0xFF6B20C4, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC9 ..."         , 0xFFFFFFFF, 0         , 0xFF6B20C8, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMKCPROT ..."         , 0xFFFFFFFF, 0xFFFFFF01         , 0xFF6B20CC, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE0 ..."            , 0xFFFFFFFF, 0         , 0xFF6B20D0, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE1 ..."            , 0xFFFFFFFF, 0         , 0xFF6B20D4, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE2 ..."            , 0xFFFFFFFF, 0         , 0xFF6B20D8, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE3 ..."            , 0xFFFFFFFF, 0         , 0xFF6B20DC, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE4 ..."            , 0xFFFFFFFF, 0         , 0xFF6B20E0, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE5 ..."            , 0xFFFFFFFF, 0         , 0xFF6B20E4, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE6 ..."            , 0xFFFFFFFF, 0         , 0xFF6B20E8, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE7 ..."            , 0xFFFFFFFF, 0         , 0xFF6B20EC, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE8 ..."            , 0xFFFFFFFF, 0         , 0xFF6B20F0, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE9 ..."            , 0xFFFFFFFF, 0         , 0xFF6B20F4, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMDTMCTL ..."         , 0xFF      , 0         , 0xFF6B20F8, 1);
        // When call tgt_acc of ECMDTMR, the counting value in general timer will be updated into ECMDTMR
        // So the read value of this register will be 0x0 (because no counting in general timer)
        issue_dbg_trans(0,"Check debug transaction with ECMDTMR ..."           , 0xFFFF    , 0x0000    , 0xFF6B20FC, 2);
        issue_dbg_trans(0,"Check debug transaction with ECMDTMCMP ..."         , 0xFFFF    , 0xFFFF    , 0xFF6B2100, 2);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG0 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B2104, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG0 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B2105, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG0 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B2106, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG0 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B2107, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG1 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B2108, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG1 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B2109, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG1 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B210A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG1 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B210B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG2 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B210C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG2 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B210D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG2 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B210E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG2 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B210F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG3 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B2110, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG3 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B2111, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG3 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B2112, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG3 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B2113, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG4 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B2114, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG4 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B2115, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG4 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B2116, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG4 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B2117, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG5 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B2118, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG5 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B2119, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG5 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B211A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG5 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B211B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG6 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B211C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG6 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B211D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG6 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B211E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG6 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B211F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG7 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B2120, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG7 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B2121, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG7 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B2122, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG7 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B2123, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG8 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B2124, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG8 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B2125, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG8 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B2126, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG8 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B2127, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG9 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B2128, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG9 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B2129, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG9 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B212A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG9 - BYTE3 ..."        , 0xFF, 0x1B, 0xFF6B212B, 1);

        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG0 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B212C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG0 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B212D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG0 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B212E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG0 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B212F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG1 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B2130, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG1 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B2131, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG1 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B2132, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG1 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B2133, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG2 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B2134, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG2 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B2135, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG2 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B2136, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG2 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B2137, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG3 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B2138, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG3 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B2139, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG3 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B213A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG3 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B213B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG4 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B213C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG4 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B213D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG4 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B213E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG4 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B213F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG5 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B2140, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG5 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B2141, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG5 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B2142, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG5 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B2143, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG6 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B2144, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG6 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B2145, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG6 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B2146, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG6 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B2147, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG7 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B2148, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG7 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B2149, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG7 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B214A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG7 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B214B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG8 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B214C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG8 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B214D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG8 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B214E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG8 - BYTE3 ..."        , 0xFF, 0xFF, 0xFF6B214F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG9 - BYTE0 ..."        , 0xFF, 0xFF, 0xFF6B2150, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG9 - BYTE1 ..."        , 0xFF, 0xFF, 0xFF6B2151, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG9 - BYTE2 ..."        , 0xFF, 0xFF, 0xFF6B2152, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG9 - BYTE3 ..."        , 0xFF, 0x1B, 0xFF6B2153, 1);

        issue_dbg_trans(0,"Check debug transaction with ECMEOCCFG..."      , 0xFFFF    , 0xFFFF    , 0xFF6B2154, 2);
        issue_dbg_trans(0,"Check debug transaction with ECMPEM..."      , 0xFFFF    , 0x3    , 0xFF6B2158, 4);

        // Check wrong size
        issue_dbg_trans(0,"Check debug transaction with wrong size of ECMMESET ..."   , 0xFFFF    , 0x0 , 0xFF6B0000, 2);
        issue_dbg_trans(0,"Check debug transaction with wrong size of ECMCECLR ..."   , 0xFFFF    , 0x0 , 0xFF6B1004, 2);
        issue_dbg_trans(0,"Check debug transaction with wrong size of ECMDTMR ..."    , 0xFF      , 0x0 , 0xFF6B20FC, 1);
        issue_dbg_trans(0,"Check debug transaction with wrong size of ECMDTMCMP ..."  , 0xFFFFFFFF, 0xFF , 0xFF6B2100, 1);
        issue_dbg_trans(0,"Check debug transaction with wrong size of ECMMIDTMCFG9 ..." , 0xFF      , 0xFF , 0xFF6B2128, 2);

        // Check wrong address
        issue_dbg_trans(0,"Check debug transaction with wrong address ...", 0x0, 0x0, 0xFF6B0001, 1);
        issue_dbg_trans(0,"Check debug transaction with wrong address ...", 0x0, 0x0, 0xFF6B0001, 2);
        issue_dbg_trans(0,"Check debug transaction with wrong address ...", 0x0, 0x0, 0x00555500, 0xFF6B0007, 3);
        issue_dbg_trans(0,"Check debug transaction with wrong address ...", 0x0, 0x0, 0xFF6B0060, 4);
        
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 - WORD0" , 0xAAAA , 0x0000AAAA, 0xFF6B2004, 2);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 - WORD1" , 0xBBBB , 0x0000BBBB, 0xFF6B2006, 2);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 - 4-bytes access" , 0xCCCCCCCC , 0xCCCCCCCC, 0xFF6B2004, 4);

        // Check READ access 8|16|32     
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR1 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFF6B100C,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR2 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFF6B1010,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR3 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFF6B1014,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR4 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFF6B1018,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR5 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFF6B101C,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR6 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFF6B1020,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR7 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFF6B1024,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR8 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFF6B1028,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR9 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0x13FFFFFF,  0xFF6B102C,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEPCFG ..."           , 0xFF      ,  0x01 ,   0x01  ,  0x01      ,  0xFF6B2000,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG0 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2004,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG0 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2005,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG0 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2006,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG0 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2007,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG1 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2008,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG1 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2009,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG1 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B200A,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG1 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B200B,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG2 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B200C,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG2 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B200D,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG2 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B200E,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG2 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B200F,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG3 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2010,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG3 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2011,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG3 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2012,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG3 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2013,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG4 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2014,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG4 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2015,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG4 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2016,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG4 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2017,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG5 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2018,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG5 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2019,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG5 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B201A,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG5 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B201B,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG6 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B201C,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG6 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B201D,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG6 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B201E,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG6 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B201F,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG7 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2020,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG7 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2021,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG7 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2022,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG7 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2023,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG8 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2024,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG8 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2025,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG8 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2026,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG8 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2027,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG9 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2028,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG9 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2029,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG9 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B202A,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMICFG9 - BYTE3 ..."  , 0xFF      ,  0x1B ,   0x1B  ,  0x1B      ,  0xFF6B202B,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG0 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B202C,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG0 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B202D,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG0 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B202E,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG0 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B202F,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG1 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2030,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG1 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2031,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG1 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2032,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG1 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2033,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG2 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2034,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG2 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2035,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG2 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2036,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG2 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2037,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG3 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2038,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG3 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2039,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG3 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B203A,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG3 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B203B,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG4 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B203C,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG4 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B203D,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG4 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B203E,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG4 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B203F,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG5 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2040,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG5 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2041,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG5 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2042,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG5 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2043,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG6 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2044,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG6 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2045,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG6 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2046,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG6 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2047,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG7 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2048,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG7 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2049,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG7 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B204A,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG7 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B204B,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG8 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B204C,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG8 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B204D,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG8 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B204E,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG8 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B204F,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG9 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2050,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG9 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2051,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG9 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2052,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMICFG9 - BYTE3 ..." , 0xFF      ,  0x1B ,   0x1B  ,  0x1B      ,  0xFF6B2053,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG0 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2054,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG0 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2055,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG0 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2056,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG0 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2057,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG1 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2058,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG1 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2059,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG1 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B205A,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG1 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B205B,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG2 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B205C,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG2 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B205D,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG2 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B205E,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG2 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B205F,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG3 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2060,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG3 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2061,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG3 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2062,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG3 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2063,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG4 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2064,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG4 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2065,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG4 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2066,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG4 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2067,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG5 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2068,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG5 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2069,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG5 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B206A,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG5 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B206B,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG6 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B206C,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG6 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B206D,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG6 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B206E,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG6 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B206F,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG7 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2070,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG7 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2071,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG7 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2072,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG7 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2073,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG8 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2074,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG8 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2075,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG8 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2076,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG8 - BYTE3 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2077,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG9 - BYTE0 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2078,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG9 - BYTE1 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2079,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG9 - BYTE2 ..."  , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B207A,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMIRCFG9 - BYTE3 ..."  , 0xFF      ,  0x3B ,   0x3B  ,  0x3B      ,  0xFF6B207B,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK0 - BYTE0 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B207C,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK0 - BYTE1 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B207D,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK0 - BYTE2 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B207E,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK0 - BYTE3 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B207F,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK1 - BYTE0 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2080,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK1 - BYTE1 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2081,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK1 - BYTE2 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2082,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK1 - BYTE3 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2083,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK2 - BYTE0 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2084,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK2 - BYTE1 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2085,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK2 - BYTE2 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2086,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK2 - BYTE3 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2087,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK3 - BYTE0 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2088,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK3 - BYTE1 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2089,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK3 - BYTE2 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B208A,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK3 - BYTE3 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B208B,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK4 - BYTE0 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B208C,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK4 - BYTE1 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B208D,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK4 - BYTE2 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B208E,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK4 - BYTE3 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B208F,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK5 - BYTE0 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2090,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK5 - BYTE1 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2091,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK5 - BYTE2 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2092,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK5 - BYTE3 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2093,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK6 - BYTE0 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2094,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK6 - BYTE1 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2095,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK6 - BYTE2 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2096,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK6 - BYTE3 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2097,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK7 - BYTE0 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2098,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK7 - BYTE1 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B2099,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK7 - BYTE2 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B209A,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK7 - BYTE3 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B209B,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK8 - BYTE0 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B209C,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK8 - BYTE1 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B209D,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK8 - BYTE2 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B209E,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK8 - BYTE3 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B209F,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK9 - BYTE0 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B20A0,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK9 - BYTE1 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B20A1,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK9 - BYTE2 ..."    , 0xFF      ,  0xFF ,   0xFF  ,  0xFF      ,  0xFF6B20A2,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEMK9 - BYTE3 ..."    , 0xFF      ,  0x3B ,   0x3F  ,  0x3F      ,  0xFF6B20A3,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMESSTC0 ..."          , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20A4,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMESSTC1 ..."          , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20A8,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMESSTC2 ..."          , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20AC,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMESSTC3 ..."          , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20B0,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMESSTC4 ..."          , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20B4,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMESSTC5 ..."          , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20B8,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMESSTC6 ..."          , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20BC,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMESSTC7 ..."          , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20C0,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMESSTC8 ..."          , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20C4,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMESSTC9 ..."          , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20C8,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMKCPROT ..."          , 0xFFFFFFFF,  0    ,   0     ,  0xFFFFFF01 ,          0xFF6B20CC,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMPE0 ..."             , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20D0,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMPE1 ..."             , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20D4,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMPE2 ..."             , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20D8,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMPE3 ..."             , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20DC,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMPE4 ..."             , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20E0,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMPE5 ..."             , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20E4,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMPE6 ..."             , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20E8,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMPE7 ..."             , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20EC,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMPE8 ..."             , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20F0,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMPE9 ..."             , 0xFFFFFFFF,  0    ,   0     ,  0 ,          0xFF6B20F4,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMDTMCTL ..."          , 0xFF      ,  0    ,   0     ,  0 ,          0xFF6B20F8,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMDTMR ..."            , 0xFFFF    ,  0x00 ,   0x00  ,  0x00  ,      0xFF6B20FC , 2);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMDTMCMP ..."          , 0xFFFF    ,  0xFF ,   0xFFFF,  0xFFFF,      0xFF6B2100 , 2);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG0 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2104,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG0 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2105,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG0 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2106,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG0 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2107,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG1 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2108,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG1 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2109,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG1 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B210A,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG1 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B210B,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG2 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B210C,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG2 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B210D,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG2 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B210E,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG2 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B210F,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG3 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2110,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG3 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2111,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG3 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2112,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG3 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2113,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG4 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2114,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG4 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2115,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG4 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2116,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG4 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2117,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG5 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2118,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG5 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2119,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG5 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B211A,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG5 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B211B,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG6 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B211C,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG6 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B211D,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG6 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B211E,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG6 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B211F,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG7 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2120,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG7 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2121,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG7 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2122,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG7 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2123,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG8 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2124,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG8 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2125,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG8 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2126,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG8 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2127,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG9 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2128,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG9 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2129,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG9 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B212A,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMMIDTMCFG9 - BYTE3 ..." , 0xFF      ,  0x1B ,   0xFF  ,  0xFF  ,   0xFF6B212B,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG0 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B212C,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG0 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B212D,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG0 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B212E,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG0 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B212F,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG1 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2130,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG1 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2131,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG1 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2132,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG1 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2133,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG2 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2134,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG2 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2135,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG2 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2136,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG2 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2137,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG3 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2138,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG3 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2139,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG3 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B213A,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG3 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B213B,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG4 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B213C,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG4 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B213D,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG4 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B213E,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG4 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B213F,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG5 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2140,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG5 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2141,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG5 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2142,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG5 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2143,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG6 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2144,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG6 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2145,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG6 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2146,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG6 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2147,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG7 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2148,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG7 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2149,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG7 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B214A,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG7 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B214B,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG8 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B214C,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG8 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B214D,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG8 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B214E,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG8 - BYTE3 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B214F,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG9 - BYTE0 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2150,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG9 - BYTE1 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2151,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG9 - BYTE2 ..." , 0xFF      ,  0xFF ,   0xFF  ,  0xFF  ,   0xFF6B2152,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMNMIDTMCFG9 - BYTE3 ..." , 0xFF      ,  0x1B ,   0xFF  ,  0xFF  ,   0xFF6B2153,  1);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEOCCFG..."           , 0xFFFF    ,  0xFF ,   0xFFFF,  0xFFFF,   0xFF6B2154,  2);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEPEM..."           , 0xFFFF    ,  0x0 ,   0x0,  0x3,   0xFF6B2158,  4);


        // access reserved area
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 - 4-bytes access" , 0xCCCCCCCC , 0xCCCCCCCC, 0xFF6B2004, 4);
		
		//}}}
		////{{{E2x-FCC2
        issue_dbg_trans(0,"Check debug transaction with ECMMESET ..."   , 0xFF, 0x0, 0xFFCB0000, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMECLR ..."   , 0xFF, 0x0, 0xFFCB0004, 1);
		
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR0 ..." , 0xFFFFFFFF, 0x0, 0xFFCB0008, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR1 ..." , 0xFFFFFFFF, 0x0, 0xFFCB000C, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR2 ..." , 0xFFFFFFFF, 0x0, 0xFFCB0010, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR3 ..." , 0xFFFFFFFF, 0x0, 0xFFCB0014, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR4 ..." , 0xFFFFFFFF, 0x0, 0xFFCB0018, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR5 ..." , 0xFFFFFFFF, 0x0, 0xFFCB001C, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR6 ..." , 0xFFFFFFFF, 0x0, 0xFFCB0020, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR7 ..." , 0xFFFFFFFF, 0x0, 0xFFCB0024, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR8 ..." , 0xFFFFFFFF, 0x0, 0xFFCB0028, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMESSTR9 ..." , 0xFFFFFFFF, 0x0, 0xFFCB002C, 4);

        issue_dbg_trans(0,"Check debug transaction with ECMCESET ..."   , 0xFF, 0x0, 0xFFCB1000, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMCECLR ..."   , 0xFF, 0x0, 0xFFCB1004, 1);
		
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR0 ..." , 0xFFFFFFFF, 0x0, 0xFFCB1008, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR1 ..." , 0xFFFFFFFF, 0x0, 0xFFCB100C, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR2 ..." , 0xFFFFFFFF, 0x0, 0xFFCB1010, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR3 ..." , 0xFFFFFFFF, 0x0, 0xFFCB1014, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR4 ..." , 0xFFFFFFFF, 0x0, 0xFFCB1018, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR5 ..." , 0xFFFFFFFF, 0x0, 0xFFCB101C, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR6 ..." , 0xFFFFFFFF, 0x0, 0xFFCB1020, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR7 ..." , 0xFFFFFFFF, 0x0, 0xFFCB1024, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR8 ..." , 0xFFFFFFFF, 0x0, 0xFFCB1028, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMCESSTR9 ..." , 0xFFFFFFFF, 0x0, 0xFFCB102C, 4);

        issue_dbg_trans(0,"Check debug transaction with ECMEPCFG ..."  , 0xFF      , 0x01      , 0xFFCB2000, 1);
		
		issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2004, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG1 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2008, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG2 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB200C, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG3 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2010, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG4 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2014, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG5 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2018, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG6 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB201C, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG7 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2020, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG8 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2024, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG9 ..." , 0xFFFFFFFF      , 0x1BFFFFFF      , 0xFFCB2028, 4);
		
		issue_dbg_trans(0,"Check debug transaction with ECMNMICFG0 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB202C, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG1 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2030, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG2 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2034, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG3 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2038, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG4 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB203C, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG5 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2040, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG6 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2044, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG7 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2048, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG8 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB204C, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG9 ..." , 0xFFFFFFFF      , 0x1BFFFFFF      , 0xFFCB2050, 4);
		
		issue_dbg_trans(0,"Check debug transaction with ECMIRCFG0 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2054, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMIRCFG1 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2058, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMIRCFG2 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB205C, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMIRCFG3 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2060, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMIRCFG4 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2064, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMIRCFG5 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2068, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMIRCFG6 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB206C, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMIRCFG7 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2070, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMIRCFG8 ..." , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2074, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMIRCFG9 ..." , 0xFFFFFFFF      , 0x3BFFFFFF      , 0xFFCB2078, 4);

		issue_dbg_trans(0,"Check debug transaction with ECMEMK0 ..."   , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB207C, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMEMK1 ..."   , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2080, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMEMK2 ..."   , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2084, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMEMK3 ..."   , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2088, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMEMK4 ..."   , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB208C, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMEMK5 ..."   , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2090, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMEMK6 ..."   , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2094, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMEMK7 ..."   , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB2098, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMEMK8 ..."   , 0xFFFFFFFF      , 0xFFFFFFFF      , 0xFFCB209C, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMEMK9 ..."   , 0xFFFFFFFF      , 0x3BFFFFFF      , 0xFFCB20A0, 4);

        issue_dbg_trans(0,"Check debug transaction with ECMESSTC0 ..."         , 0xFFFFFFFF, 0xFFFFFFFF , 0xFFCB20A4, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC1 ..."         , 0xFFFFFFFF, 0xFFFFFFFF	, 0xFFCB20A8, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC2 ..."         , 0xFFFFFFFF, 0xFFFFFFFF , 0xFFCB20AC, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC3 ..."         , 0xFFFFFFFF, 0xFFFFFFFF , 0xFFCB20B0, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC4 ..."         , 0xFFFFFFFF, 0xFFFFFFFF , 0xFFCB20B4, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC5 ..."         , 0xFFFFFFFF, 0xFFFFFFFF , 0xFFCB20B8, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC6 ..."         , 0xFFFFFFFF, 0xFFFFFFFF , 0xFFCB20BC, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC7 ..."         , 0xFFFFFFFF, 0xFFFFFFFF , 0xFFCB20C0, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC8 ..."         , 0xFFFFFFFF, 0xFFFFFFFF , 0xFFCB20C4, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMESSTC9 ..."         , 0xFFFFFFFF, 0x7FFFFFFF , 0xFFCB20C8, 4);
		
        issue_dbg_trans(0,"Check debug transaction with ECMKCPROT ..."         , 0xFFFFFFFF, 0x0        , 0xFFCB20CC, 4);
		
        issue_dbg_trans(0,"Check debug transaction with ECMPE0 ..."            , 0xFFFFFFFF, 0x0         , 0xFFCB20D0, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE1 ..."            , 0xFFFFFFFF, 0x0         , 0xFFCB20D4, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE2 ..."            , 0xFFFFFFFF, 0x0         , 0xFFCB20D8, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE3 ..."            , 0xFFFFFFFF, 0x0         , 0xFFCB20DC, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE4 ..."            , 0xFFFFFFFF, 0x0         , 0xFFCB20E0, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE5 ..."            , 0xFFFFFFFF, 0x0         , 0xFFCB20E4, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE6 ..."            , 0xFFFFFFFF, 0x0         , 0xFFCB20E8, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE7 ..."            , 0xFFFFFFFF, 0x0         , 0xFFCB20EC, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE8 ..."            , 0xFFFFFFFF, 0x0         , 0xFFCB20F0, 4);
        issue_dbg_trans(0,"Check debug transaction with ECMPE9 ..."            , 0xFFFFFFFF, 0x0         , 0xFFCB20F4, 4);
		
        issue_dbg_trans(0,"Check debug transaction with ECMDTMCTL ..."         , 0xFF      , 0x0         , 0xFFCB20F8, 1);
		
        // When call tgt_acc of ECMDTMR, the counting value in general timer will be updated into ECMDTMR
        // So the read value of this register will be 0x0 (because no counting in general timer)
        issue_dbg_trans(0,"Check debug transaction with ECMDTMR ..."           , 0xFFFF    , 0x0    , 0xFFCB20FC, 2);
		
        issue_dbg_trans(0,"Check debug transaction with ECMDTMCMP ..."         , 0xFFFFFFFF    , 0x0000FFFF    , 0xFFCB2100, 4);
		
		issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG0 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB2104, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG1 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB2108, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG2 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB210C, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG3 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB2110, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG4 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB2114, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG5 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB2118, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG6 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB211C, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG7 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB2120, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG8 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB2124, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG9 ..."        , 0xFFFFFFFF, 0x1BFFFFFF, 0xFFCB2128, 4);
		
		issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG0 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB212C, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG1 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB2130, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG2 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB2134, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG3 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB2138, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG4 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB213C, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG5 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB2140, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG6 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB2144, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG7 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB2148, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG8 ..."        , 0xFFFFFFFF, 0xFFFFFFFF, 0xFFCB214C, 4);
		issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG9 ..."        , 0xFFFFFFFF, 0x1BFFFFFF, 0xFFCB2150, 4);		

        issue_dbg_trans(0,"Check debug transaction with ECMEOCCFG..."      , 0xFFFFFFFF    , 0x8000FFFF    , 0xFFCB2154, 4);
		
        issue_dbg_trans(0,"Check debug transaction with ECMPEM..."      , 0xFFFFFFFF    , 0x3    , 0xFFCB2158, 4);

        // Check wrong size
        issue_dbg_trans(0,"Check debug transaction with wrong size of ECMMESET ..."   , 0xFFFF    , 0x0 , 0xFFCB0000, 2);
        issue_dbg_trans(0,"Check debug transaction with wrong size of ECMCECLR ..."   , 0xFFFF    , 0x0 , 0xFFCB1004, 2);
        issue_dbg_trans(0,"Check debug transaction with wrong size of ECMDTMR ..."    , 0xFF      , 0x0 , 0xFFCB20FC, 1);
        issue_dbg_trans(0,"Check debug transaction with wrong size of ECMDTMCMP ..."  , 0xFFFFFFFF, 0xFF , 0xFFCB2100, 1);
        issue_dbg_trans(0,"Check debug transaction with wrong size of ECMMIDTMCFG9 ..." , 0xFF      , 0xFF , 0xFFCB2128, 2);
		
		issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB2004, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB2005, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB2006, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB2007, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG1 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB2008, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG1 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB2009, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG1 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB200A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG1 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB200B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG2 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB200C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG2 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB200D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG2 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB200E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG2 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB200F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG3 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB2010, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG3 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB2011, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG3 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB2012, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG3 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB2013, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG4 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB2014, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG4 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB2015, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG4 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB2016, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG4 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB2017, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG5 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB2018, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG5 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB2019, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG5 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB201A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG5 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB201B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG6 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB201C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG6 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB201D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG6 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB201E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG6 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB201F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG7 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB2020, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG7 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB2021, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG7 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB2022, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG7 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB2023, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG8 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB2024, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG8 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB2025, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG8 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB2026, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG8 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB2027, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG9 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB2028, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG9 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB2029, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG9 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB202A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG9 - BYTE3 ..." , 0xFF      , 0x1B      , 0xFFCB202B, 1);
		
		issue_dbg_trans(0,"Check debug transaction with ECMNMICFG0 - BYTE0 ...", 0xFF      , 0xFF      , 0xFFCB202C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG0 - BYTE1 ...", 0xFF      , 0xFF      , 0xFFCB202D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG0 - BYTE2 ...", 0xFF      , 0xFF      , 0xFFCB202E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG0 - BYTE3 ...", 0xFF      , 0xFF      , 0xFFCB202F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG1 - BYTE0 ...", 0xFF      , 0xFF      , 0xFFCB2030, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG1 - BYTE1 ...", 0xFF      , 0xFF      , 0xFFCB2031, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG1 - BYTE2 ...", 0xFF      , 0xFF      , 0xFFCB2032, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG1 - BYTE3 ...", 0xFF      , 0xFF      , 0xFFCB2033, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG2 - BYTE0 ...", 0xFF      , 0xFF      , 0xFFCB2034, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG2 - BYTE1 ...", 0xFF      , 0xFF      , 0xFFCB2035, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG2 - BYTE2 ...", 0xFF      , 0xFF      , 0xFFCB2036, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG2 - BYTE3 ...", 0xFF      , 0xFF      , 0xFFCB2037, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG3 - BYTE0 ...", 0xFF      , 0xFF      , 0xFFCB2038, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG3 - BYTE1 ...", 0xFF      , 0xFF      , 0xFFCB2039, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG3 - BYTE2 ...", 0xFF      , 0xFF      , 0xFFCB203A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG3 - BYTE3 ...", 0xFF      , 0xFF      , 0xFFCB203B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG4 - BYTE0 ...", 0xFF      , 0xFF      , 0xFFCB203C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG4 - BYTE1 ...", 0xFF      , 0xFF      , 0xFFCB203D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG4 - BYTE2 ...", 0xFF      , 0xFF      , 0xFFCB203E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG4 - BYTE3 ...", 0xFF      , 0xFF      , 0xFFCB203F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG5 - BYTE0 ...", 0xFF      , 0xFF      , 0xFFCB2040, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG5 - BYTE1 ...", 0xFF      , 0xFF      , 0xFFCB2041, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG5 - BYTE2 ...", 0xFF      , 0xFF      , 0xFFCB2042, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG5 - BYTE3 ...", 0xFF      , 0xFF      , 0xFFCB2043, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG6 - BYTE0 ...", 0xFF      , 0xFF      , 0xFFCB2044, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG6 - BYTE1 ...", 0xFF      , 0xFF      , 0xFFCB2045, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG6 - BYTE2 ...", 0xFF      , 0xFF      , 0xFFCB2046, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG6 - BYTE3 ...", 0xFF      , 0xFF      , 0xFFCB2047, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG7 - BYTE0 ...", 0xFF      , 0xFF      , 0xFFCB2048, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG7 - BYTE1 ...", 0xFF      , 0xFF      , 0xFFCB2049, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG7 - BYTE2 ...", 0xFF      , 0xFF      , 0xFFCB204A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG7 - BYTE3 ...", 0xFF      , 0xFF      , 0xFFCB204B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG8 - BYTE0 ...", 0xFF      , 0xFF      , 0xFFCB204C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG8 - BYTE1 ...", 0xFF      , 0xFF      , 0xFFCB204D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG8 - BYTE2 ...", 0xFF      , 0xFF      , 0xFFCB204E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG8 - BYTE3 ...", 0xFF      , 0xFF      , 0xFFCB204F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG9 - BYTE0 ...", 0xFF      , 0xFF      , 0xFFCB2050, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG9 - BYTE1 ...", 0xFF      , 0xFF      , 0xFFCB2051, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG9 - BYTE2 ...", 0xFF      , 0xFF      , 0xFFCB2052, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMICFG9 - BYTE3 ...", 0xFF      , 0x1B      , 0xFFCB2053, 1);
		
		issue_dbg_trans(0,"Check debug transaction with ECMIRCFG0 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB2054, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG0 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB2055, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG0 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB2056, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG0 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB2057, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG1 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB2058, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG1 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB2059, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG1 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB205A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG1 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB205B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG2 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB205C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG2 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB205D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG2 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB205E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG2 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB205F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG3 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB2060, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG3 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB2061, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG3 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB2062, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG3 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB2063, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG4 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB2064, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG4 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB2065, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG4 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB2066, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG4 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB2067, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG5 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB2068, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG5 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB2069, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG5 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB206A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG5 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB206B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG6 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB206C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG6 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB206D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG6 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB206E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG6 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB206F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG7 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB2070, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG7 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB2071, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG7 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB2072, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG7 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB2073, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG8 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB2074, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG8 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB2075, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG8 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB2076, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG8 - BYTE3 ..." , 0xFF      , 0xFF      , 0xFFCB2077, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG9 - BYTE0 ..." , 0xFF      , 0xFF      , 0xFFCB2078, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG9 - BYTE1 ..." , 0xFF      , 0xFF      , 0xFFCB2079, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG9 - BYTE2 ..." , 0xFF      , 0xFF      , 0xFFCB207A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMIRCFG9 - BYTE3 ..." , 0xFF      , 0x3B      , 0xFFCB207B, 1);
		
		issue_dbg_trans(0,"Check debug transaction with ECMEMK0 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFFCB207C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK0 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFFCB207D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK0 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFFCB207E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK0 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFFCB207F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK1 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFFCB2080, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK1 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFFCB2081, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK1 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFFCB2082, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK1 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFFCB2083, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK2 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFFCB2084, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK2 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFFCB2085, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK2 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFFCB2086, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK2 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFFCB2087, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK3 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFFCB2088, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK3 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFFCB2089, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK3 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFFCB208A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK3 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFFCB208B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK4 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFFCB208C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK4 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFFCB208D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK4 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFFCB208E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK4 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFFCB208F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK5 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFFCB2090, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK5 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFFCB2091, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK5 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFFCB2092, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK5 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFFCB2093, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK6 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFFCB2094, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK6 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFFCB2095, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK6 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFFCB2096, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK6 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFFCB2097, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK7 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFFCB2098, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK7 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFFCB2099, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK7 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFFCB209A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK7 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFFCB209B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK8 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFFCB209C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK8 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFFCB209D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK8 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFFCB209E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK8 - BYTE3 ..."   , 0xFF      , 0xFF      , 0xFFCB209F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK9 - BYTE0 ..."   , 0xFF      , 0xFF      , 0xFFCB20A0, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK9 - BYTE1 ..."   , 0xFF      , 0xFF      , 0xFFCB20A1, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK9 - BYTE2 ..."   , 0xFF      , 0xFF      , 0xFFCB20A2, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMEMK9 - BYTE3 ..."   , 0xFF      , 0x3B      , 0xFFCB20A3, 1);
		
		issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG0 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB2104, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG0 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB2105, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG0 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB2106, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG0 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB2107, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG1 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB2108, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG1 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB2109, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG1 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB210A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG1 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB210B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG2 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB210C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG2 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB210D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG2 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB210E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG2 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB210F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG3 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB2110, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG3 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB2111, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG3 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB2112, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG3 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB2113, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG4 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB2114, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG4 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB2115, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG4 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB2116, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG4 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB2117, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG5 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB2118, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG5 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB2119, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG5 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB211A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG5 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB211B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG6 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB211C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG6 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB211D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG6 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB211E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG6 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB211F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG7 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB2120, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG7 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB2121, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG7 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB2122, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG7 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB2123, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG8 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB2124, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG8 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB2125, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG8 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB2126, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG8 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB2127, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG9 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB2128, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG9 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB2129, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG9 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB212A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMMIDTMCFG9 - BYTE3 ..."        , 0xFF, 0x1B, 0xFFCB212B, 1);
		
		issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG0 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB212C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG0 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB212D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG0 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB212E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG0 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB212F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG1 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB2130, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG1 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB2131, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG1 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB2132, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG1 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB2133, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG2 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB2134, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG2 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB2135, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG2 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB2136, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG2 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB2137, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG3 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB2138, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG3 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB2139, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG3 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB213A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG3 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB213B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG4 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB213C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG4 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB213D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG4 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB213E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG4 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB213F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG5 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB2140, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG5 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB2141, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG5 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB2142, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG5 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB2143, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG6 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB2144, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG6 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB2145, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG6 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB2146, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG6 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB2147, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG7 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB2148, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG7 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB2149, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG7 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB214A, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG7 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB214B, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG8 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB214C, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG8 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB214D, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG8 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB214E, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG8 - BYTE3 ..."        , 0xFF, 0xFF, 0xFFCB214F, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG9 - BYTE0 ..."        , 0xFF, 0xFF, 0xFFCB2150, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG9 - BYTE1 ..."        , 0xFF, 0xFF, 0xFFCB2151, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG9 - BYTE2 ..."        , 0xFF, 0xFF, 0xFFCB2152, 1);
        issue_dbg_trans(0,"Check debug transaction with ECMNMIDTMCFG9 - BYTE3 ..."        , 0xFF, 0x1B, 0xFFCB2153, 1);

        // Check wrong address
        issue_dbg_trans(0,"Check debug transaction with wrong address ...", 0x0, 0x0, 0xFFCB0001, 1);
        issue_dbg_trans(0,"Check debug transaction with wrong address ...", 0x0, 0x0, 0xFFCB0001, 2);
        issue_dbg_trans(0,"Check debug transaction with wrong address ...", 0x0, 0x0, 0xFFCB0007, 3);
        issue_dbg_trans(0,"Check debug transaction with wrong address ...", 0x0, 0x0, 0xFFCB0060, 4);
        
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 - WORD0" , 0xAAAA , 0x0000AAAA, 0xFFCB2003, 2);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 - WORD1" , 0xBBBB , 0x0000BBBB, 0xFFCB2006, 2);
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 - 4-bytes access" , 0xCCCCCCCC , 0xCCCCCCCC, 0xFFCB2012, 4);
		
		issue_dbg_trans_read(0,"Check debug transaction with ECMKCPROT ..."         , 0xFFFFFFFF, 0x0, 0x0, 0x0        , 0xFFCB20CA, 4);

        // Check READ access 8|16|32     
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR1 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFFCB100C,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR2 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFFCB1010,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR3 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFFCB1014,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR4 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFFCB1018,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR5 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFFCB101C,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR6 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFFCB1020,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR7 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFFCB1024,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR8 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFFCB1028,  4);
        issue_dbg_trans_read(0,  "Check debug transaction with ECMCESSTR9 ..."         , 0xFFFFFFFF,  0xFF ,   0xFFFF,  0xFFFFFFFF,  0xFFCB102C,  4);
		
        issue_dbg_trans_read(0,  "Check debug transaction with ECMEPCFG ..."           , 0xFF      ,  0x01 ,   0x01  ,  0x01      ,  0xFFCB2000,  1);
		
		issue_dbg_trans_read(0,"Check debug transaction with ECMMICFG0 ..." , 0xFFFFFFFF      ,  0xFF ,   0xFFFF, 0xFFFFFFFF      , 0xFFCB2004, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMMICFG1 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2008, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMMICFG2 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB200C, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMMICFG3 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2010, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMMICFG4 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2014, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMMICFG5 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2018, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMMICFG6 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB201C, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMMICFG7 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2020, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMMICFG8 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2024, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMMICFG9 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0x1BFFFFFF      , 0xFFCB2028, 4);
		
		issue_dbg_trans_read(0,"Check debug transaction with ECMNMICFG0 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB202C, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMNMICFG1 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2030, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMNMICFG2 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2034, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMNMICFG3 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2038, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMNMICFG4 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB203C, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMNMICFG5 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2040, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMNMICFG6 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2044, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMNMICFG7 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2048, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMNMICFG8 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB204C, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMNMICFG9 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0x1BFFFFFF      , 0xFFCB2050, 4);
		
		issue_dbg_trans_read(0,"Check debug transaction with ECMIRCFG0 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2054, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMIRCFG1 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2058, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMIRCFG2 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB205C, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMIRCFG3 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2060, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMIRCFG4 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2064, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMIRCFG5 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2068, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMIRCFG6 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB206C, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMIRCFG7 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2070, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMIRCFG8 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2074, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMIRCFG9 ..." , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0x3BFFFFFF      , 0xFFCB2078, 4);

		issue_dbg_trans_read(0,"Check debug transaction with ECMEMK0 ..."   , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB207C, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMEMK1 ..."   , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2080, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMEMK2 ..."   , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2084, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMEMK3 ..."   , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2088, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMEMK4 ..."   , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB208C, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMEMK5 ..."   , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2090, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMEMK6 ..."   , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2094, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMEMK7 ..."   , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB2098, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMEMK8 ..."   , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0xFFFFFFFF      , 0xFFCB209C, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMEMK9 ..."   , 0xFFFFFFFF      ,   0xFF ,   0xFFFF,0x3BFFFFFF      , 0xFFCB20A0, 4);

        issue_dbg_trans_read(0,"Check debug transaction with ECMESSTC0 ..."         , 0xFFFFFFFF,   0xFF ,   0xFFFF,0xFFFFFFFF , 0xFFCB20A4, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMESSTC1 ..."         , 0xFFFFFFFF,   0xFF ,   0xFFFF,0xFFFFFFFF	, 0xFFCB20A8, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMESSTC2 ..."         , 0xFFFFFFFF,   0xFF ,   0xFFFF,0xFFFFFFFF , 0xFFCB20AC, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMESSTC3 ..."         , 0xFFFFFFFF,   0xFF ,   0xFFFF,0xFFFFFFFF , 0xFFCB20B0, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMESSTC4 ..."         , 0xFFFFFFFF,   0xFF ,   0xFFFF,0xFFFFFFFF , 0xFFCB20B4, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMESSTC5 ..."         , 0xFFFFFFFF,   0xFF ,   0xFFFF,0xFFFFFFFF , 0xFFCB20B8, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMESSTC6 ..."         , 0xFFFFFFFF,   0xFF ,   0xFFFF,0xFFFFFFFF , 0xFFCB20BC, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMESSTC7 ..."         , 0xFFFFFFFF,   0xFF ,   0xFFFF,0xFFFFFFFF , 0xFFCB20C0, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMESSTC8 ..."         , 0xFFFFFFFF,   0xFF ,   0xFFFF,0xFFFFFFFF , 0xFFCB20C4, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMESSTC9 ..."         , 0xFFFFFFFF,   0xFF ,   0xFFFF,0x7FFFFFFF , 0xFFCB20C8, 4);
		
        issue_dbg_trans_read(0,"Check debug transaction with ECMKCPROT ..."         , 0xFFFFFFFF, 0x0, 0x0, 0x0        , 0xFFCB20CC, 4);
		
        issue_dbg_trans_read(0,"Check debug transaction with ECMPE0 ..."            , 0xFFFFFFFF, 0x0, 0x0, 0x0         , 0xFFCB20D0, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMPE1 ..."            , 0xFFFFFFFF, 0x0 , 0x0, 0x0        , 0xFFCB20D4, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMPE2 ..."            , 0xFFFFFFFF, 0x0 , 0x0, 0x0        , 0xFFCB20D8, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMPE3 ..."            , 0xFFFFFFFF, 0x0 , 0x0, 0x0        , 0xFFCB20DC, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMPE4 ..."            , 0xFFFFFFFF, 0x0 , 0x0, 0x0        , 0xFFCB20E0, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMPE5 ..."            , 0xFFFFFFFF, 0x0  , 0x0, 0x0       , 0xFFCB20E4, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMPE6 ..."            , 0xFFFFFFFF, 0x0  , 0x0, 0x0       , 0xFFCB20E8, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMPE7 ..."            , 0xFFFFFFFF, 0x0  , 0x0, 0x0       , 0xFFCB20EC, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMPE8 ..."            , 0xFFFFFFFF, 0x0   , 0x0, 0x0      , 0xFFCB20F0, 4);
        issue_dbg_trans_read(0,"Check debug transaction with ECMPE9 ..."            , 0xFFFFFFFF, 0x0    , 0x0, 0x0     , 0xFFCB20F4, 4);
		
        issue_dbg_trans_read(0,"Check debug transaction with ECMDTMCTL ..."         , 0xFF      , 0x0 , 0x0, 0x0        , 0xFFCB20F8, 1);
		
        // When call tgt_acc of ECMDTMR, the counting value in general timer will be updated into ECMDTMR
        // So the read value of this register will be 0x0 (because no counting in general timer)
        issue_dbg_trans_read(0,"Check debug transaction with ECMDTMR ..."           , 0xFFFF    , 0x0 , 0x0, 0x0   , 0xFFCB20FC, 2);
		
        issue_dbg_trans_read(0,"Check debug transaction with ECMDTMCMP ..."         , 0xFFFFFFFF,   0xFF ,   0xFFFF    , 0x0000FFFF    , 0xFFCB2100, 4);
		
		issue_dbg_trans_read(0,"Check debug transaction with ECMMIDTMCFG0 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB2104, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMMIDTMCFG1 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB2108, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMMIDTMCFG2 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB210C, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMMIDTMCFG3 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB2110, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMMIDTMCFG4 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB2114, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMMIDTMCFG5 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB2118, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMMIDTMCFG6 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB211C, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMMIDTMCFG7 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB2120, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMMIDTMCFG8 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB2124, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMMIDTMCFG9 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0x1BFFFFFF, 0xFFCB2128, 4);
		
		issue_dbg_trans_read(0,"Check debug transaction with ECMNMIDTMCFG0 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB212C, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMNMIDTMCFG1 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB2130, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMNMIDTMCFG2 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB2134, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMNMIDTMCFG3 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB2138, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMNMIDTMCFG4 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB213C, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMNMIDTMCFG5 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB2140, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMNMIDTMCFG6 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB2144, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMNMIDTMCFG7 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB2148, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMNMIDTMCFG8 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0xFFFFFFFF, 0xFFCB214C, 4);
		issue_dbg_trans_read(0,"Check debug transaction with ECMNMIDTMCFG9 ..."        , 0xFFFFFFFF,   0xFF ,   0xFFFF, 0x1BFFFFFF, 0xFFCB2150, 4);		

        issue_dbg_trans_read(0,"Check debug transaction with ECMEOCCFG..."      , 0xFFFFFFFF    ,   0xFF ,   0xFFFF, 0x8000FFFF    , 0xFFCB2154, 4);
		
        issue_dbg_trans_read(0,"Check debug transaction with ECMPEM..."      , 0xFFFFFFFF    , 0x3 , 0x3 , 0x3   , 0xFFCB2158, 4);

        // access reserved area
        issue_dbg_trans(0,"Check debug transaction with ECMMICFG0 - 4-bytes access" , 0xCCCCCCCC , 0xCCCCCCCC, 0xFFCB2004, 4);
        //}}}
        wait();
    }
}//}}}

void Ccontrol_port::issue_dbg_trans (bool check, const char* description, unsigned long data, unsigned long expected_value, unsigned int addr, unsigned int size)
{//{{{
    bool ret = 1;
    unsigned long dbg_exp_val = (check == 1) ? data : expected_value;
    unsigned long tmp_data[4] = {0};
    memcpy(tmp_data,&data,4);
    unsigned int wait_time = 100;

    wait(wait_time,SC_NS);

    printf ("%s\n", description);
    if (size == 8) {
        p_cpu->BusAccWrite(addr, &tmp_data[0], size);
        wait(wait_time,SC_NS);
        p_cpu->BusAccWriteDebug(addr, &tmp_data[0], size);
        wait(wait_time,SC_NS);
        tmp_data[0] = 0;
        p_cpu->BusAccReadDebug(addr, &tmp_data[0], size);
        wait(wait_time,SC_NS);
        if (tmp_data[0] != dbg_exp_val) { ret = 0; }
        p_cpu->BusAccRead(addr, &tmp_data[0], size);
        wait(wait_time,SC_NS);
        if (tmp_data[0] != expected_value) { ret = 0; }
    } else {
        p_cpu->BusAccWrite(addr, &data, size);
        wait(wait_time,SC_NS);
        p_cpu->BusAccWriteDebug(addr, &data, size);
        wait(wait_time,SC_NS);
        data = 0;
        p_cpu->BusAccReadDebug(addr, &data, size);
        wait(wait_time,SC_NS);
        if (data != dbg_exp_val) { ret = 0; }
        p_cpu->BusAccRead(addr, &data, size);
        wait(wait_time,SC_NS);
        if (data != expected_value) { ret = 0; }
    }
    if (ret ==  0) {
        printf("[%s] Debug Transaction Read 0x%X = %lX FAIL!\n", this->name(), addr, data);
    } else {
        printf("[%s] Debug Transaction Read 0x%X = %lX PASS!\n", this->name(), addr, data);
    }
}//}}}

void Ccontrol_port::issue_dbg_trans (bool check, const char* description, unsigned long data, unsigned long expected_value, unsigned long dbg_expected_value, unsigned int addr, unsigned int size)
{//{{{
    bool ret = 1;
    unsigned long tmp_data[4] = {0};
    memcpy(tmp_data,&data,4);
    unsigned int wait_time = 100;

    wait(wait_time,SC_NS);

    printf ("%s\n", description);
    if (size == 8) {
        p_cpu->BusAccWrite(addr, &tmp_data[0], size);
        wait(wait_time,SC_NS);
        p_cpu->BusAccWriteDebug(addr, &tmp_data[0], size);
        wait(wait_time,SC_NS);
        tmp_data[0] = 0;
        p_cpu->BusAccReadDebug(addr, &tmp_data[0], size);
        wait(wait_time,SC_NS);
        if (tmp_data[0] != dbg_expected_value) { ret = 0; }
        p_cpu->BusAccRead(addr, &tmp_data[0], size);
        wait(wait_time,SC_NS);
        if (tmp_data[0] != expected_value) { ret = 0; }
    } else {
        p_cpu->BusAccWrite(addr, &data, size);
        wait(wait_time,SC_NS);
        p_cpu->BusAccWriteDebug(addr, &data, size);
        wait(wait_time,SC_NS);
        data = 0;
        p_cpu->BusAccReadDebug(addr, &data, size);
        wait(wait_time,SC_NS);
        if (data != dbg_expected_value) { ret = 0; }
        p_cpu->BusAccRead(addr, &data, size);
        wait(wait_time,SC_NS);
        if (data != expected_value) { ret = 0; }
    }
    if (ret ==  0) {
        printf("[%s] Debug Transaction Read 0x%X = %lX FAIL!\n", this->name(), addr, data);
    } else {
        printf("[%s] Debug Transaction Read 0x%X = %lX PASS!\n", this->name(), addr, data);
    }
}//}}}

void Ccontrol_port::issue_dbg_trans_read (bool check, const char* description, unsigned long data, unsigned long expected_8, unsigned long expected_16, unsigned long expected_32, unsigned int addr, unsigned int size)
{//{{{
    bool ret = 1;
    unsigned int wait_time = 100;
    wait(wait_time,SC_NS);
    p_cpu->BusAccWrite(addr, &data, size);
    wait(wait_time,SC_NS);
    p_cpu->BusAccWriteDebug(addr, &data, size);
    wait(wait_time,SC_NS);

    data = 0;
    p_cpu->BusAccRead(addr, &data, 1);
    if (data != expected_8) { ret = 0; }
    if (ret ==  0) {
        printf("[%s] Transaction Read 8 0x%X = %lX FAIL!\n", this->name(), addr, data);
    } else {
        printf("[%s] Transaction Read 8 0x%X = %lX PASS!\n", this->name(), addr, data);
    }
    wait(wait_time,SC_NS);
    data = 0;
    ret = 1;
    if (size%2 == 0) {
        p_cpu->BusAccRead(addr, &data, 2);
        if (data != expected_16) { ret = 0; }
        if (ret ==  0) {
            printf("[%s] Transaction Read 16 0x%X = %lX FAIL!\n", this->name(), addr, data);
        } else {
            printf("[%s] Transaction Read 16 0x%X = %lX PASS!\n", this->name(), addr, data);
        }
    }
    wait(wait_time,SC_NS);
    data = 0;
    ret = 1;
    if (size%4 == 0) {
        p_cpu->BusAccRead(addr, &data, 4);
        if (data != expected_32) { ret = 0; }
        if (ret ==  0) {
            printf("[%s] Transaction Read 32 0x%X = %lX FAIL!\n", this->name(), addr, data);
        } else {
            printf("[%s] Transaction Read 32 0x%X = %lX PASS!\n", this->name(), addr, data);
        }
    }
}//}}}

// vim600: set foldmethod=marker : 
