// -----------------------------------------------------------------------------
// $Id: PY_ECM_E2.h,v 1.2 2013/09/09 07:43:28 uyenle Exp $
//
// Copyright(c) 2010-2013 Renesas Electronics Corporation
// Copyright(c) 2013 Renesas Design Vietnam Co., Ltd.
// RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
// This program must be used solely for the purpose for which
// it was furnished by Renesas Electronics Corporation. No part of this
// program may be reproduced or disclosed to others, in any
// form, without the prior written permission of Renesas Electronics
// Corporation.
// -----------------------------------------------------------------------------
#ifndef __PY_ECM_E2_H__
#define __PY_ECM_E2_H__

#ifndef PY_INITMODULE_NAME
#define PY_INITMODULE_NAME "SCHEAP"
#endif

#include <Python.h>
#include "ecm_e2.h"
namespace PY_ECM_E2
{
    static PyObject* DumpInterruptPy (PyObject* self, PyObject* args);
    static PyObject* EnableTransInfoPy (PyObject* self, PyObject* args);
    static PyObject* DumpStatInfoPy (PyObject* self, PyObject* args);
    static PyObject* SetCLKfreqPy (PyObject* self, PyObject* args);
    static PyObject* tgtPy (PyObject* self, PyObject* args);
    static PyObject* portPy (PyObject* self, PyObject* args);
    static PyObject* regPy (PyObject* self, PyObject* args);
    static PyObject* MessageLevelPy (PyObject* self, PyObject* args);
    static PyObject* helpPy (PyObject* self, PyObject* args);
    static PyObject* AssertResetPy (PyObject* self, PyObject* args);
    void SetPyExtCmd(void);
    void SeparateString(std::vector<std::string> &vtr, const std::string msg);
    void ProcessCommand(const std::string cmd_id, const std::string cmd_name, char* token, char* input_arg);
    void ProcessCommand_ECM_E2(const std::string cmd_id, const std::string cmd_name, char* token, char* input_arg);
}
#endif //__PY_ECM_E2_H__
