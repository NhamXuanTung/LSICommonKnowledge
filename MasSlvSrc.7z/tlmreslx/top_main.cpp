// ----------------------------------------------------------------------
//   $Id: top_main.cpp.skl,v 1.1.1.1 2013/05/13 13:41:47 trongtruong Exp $
// ----------------------------------------------------------------------
//   (C) Copyright 2010   RVC (Renesas Design Vietnam Co., Ltd.)
//   All rights reserved. RVC Confidential Proprietary
//   (C) Copyright 2010   RENESAS Electronics Corp.  All rights reserved.
// ----------------------------------------------------------------------

#include "top.h"
char *trace_file_namep;

int sc_main(int argc, char *argv[])
{
    sc_report_handler::set_actions("/IEEE_Std_1666/deprecated", SC_DO_NOTHING);
    sc_report_handler::set_actions(SC_ERROR, SC_DEFAULT_WARNING_ACTIONS);
    
    //get trace file name and ssc file name
    trace_file_namep = NULL;
    char* ssc_file_namep = NULL;
    bool set_time_resolution_flag = false;
    for (int i = 1; i < argc; i++) {
        if (strcmp (argv[i], "-help") == 0) {
            printf ("\nUsage: %s [options]\n\n",argv[0]);
            printf ("Options:\n");
            printf ("  -help       show this help message and exit\n");
            printf ("  -simtime    input finish time of simulation\n");
            printf ("  -restime    input time of resolution\n");
            printf ("  -vcd        name of vcd file\n");
            printf ("  -src        path of ssc file\n\n");
            return 0;
        } else if (strcmp (argv[i], "-vcd") == 0) {
            if (i+1 < argc) {
                trace_file_namep = argv [i+1];
                i++;
            }
        } else if (strcmp (argv[i], "-src") == 0) {
            if (i+1 < argc) {
                ssc_file_namep = argv [i+1];
                i++;
            }
        } else if (strcmp (argv[i], "-restime") == 0) {
            if (i+1 < argc) {
                std::string time_resolution = argv[i+1];
                i++;
                if(time_resolution == "SC_FS"){
                    sc_set_time_resolution (1, SC_FS);
                    set_time_resolution_flag = true;
                }else if(time_resolution == "SC_PS"){
                    sc_set_time_resolution (1, SC_PS);
                    set_time_resolution_flag = true;
                }else if(time_resolution == "SC_NS"){
                    sc_set_time_resolution (1, SC_NS);
                    set_time_resolution_flag = true;
                }else if(time_resolution == "SC_US"){
                    sc_set_time_resolution (1, SC_US);
                    set_time_resolution_flag = true;
                }else if(time_resolution == "SC_MS"){
                    sc_set_time_resolution (1, SC_MS);
                    set_time_resolution_flag = true;
                }else if(time_resolution == "SC_SEC"){
                    sc_set_time_resolution (1, SC_SEC);
                    set_time_resolution_flag = true;
                }    
            }
        }
    }
    if(set_time_resolution_flag == false){
        sc_set_time_resolution (1, SC_NS);
    }

    Creslx *reslx = new Creslx ("reslx");
    if (reslx != NULL) {
        reslx->ecm_wp->TARGET_PRODUCT.value = "E2x-FCC2";
        reslx->ecm_wp_fcc1->TARGET_PRODUCT.value = "E2x-FCC1";
        // System Signals Generation
        sc_signal <bool>	reset;

        // Modules Connection
        reslx->reset(reset);

        vpcl::commandHandler *cmd_handler_ssc;
        //set handler
        cmd_handler_ssc = new vpcl::commandHandler(ssc_file_namep);
        cmd_handler_ssc->register_command_processor(reslx->cpu->name(),reslx->cpu, &Ccpu::handleCommand);
        cmd_handler_ssc->register_command_processor(reslx->ecm_wp->name(),reslx->ecm_wp, &Cecm_e2_wp::handleCommand);
        cmd_handler_ssc->register_command_processor(reslx->ecm_wp->GetMasterCheckerName(true),reslx->ecm_wp->mMaster, &Cecm_e2::handleCommand);
        cmd_handler_ssc->register_command_processor(reslx->ecm_wp->GetMasterCheckerName(false),reslx->ecm_wp->mChecker, &Cecm_e2::handleCommand);
        cmd_handler_ssc->register_command_processor(reslx->ecm_wp_fcc1->name(),reslx->ecm_wp_fcc1, &Cecm_e2_wp::handleCommand);
        cmd_handler_ssc->register_command_processor(reslx->ecm_wp_fcc1->GetMasterCheckerName(true),reslx->ecm_wp_fcc1->mMaster, &Cecm_e2::handleCommand);
        cmd_handler_ssc->register_command_processor(reslx->ecm_wp_fcc1->GetMasterCheckerName(false),reslx->ecm_wp_fcc1->mChecker, &Cecm_e2::handleCommand);
        cmd_handler_ssc->register_command_processor(reslx->control_port->name(),reslx->control_port,&Ccontrol_port::handleCommand);
        reslx->cpu->setCommandHandler(cmd_handler_ssc);
        //cmd_handler_ssc->set_msg_lvl(0);
        cmd_handler_ssc->handleCommand();

        // Start SystemC
        sc_start ();
        //sc_stop ();
        delete reslx;
        return 0;
    }
    else {
        printf ("\n\n[sc_main] Error: Cannot allocate memory for reslx instance!!!\n\n");
        return 0;
    }
}
