// ---------------------------------------------------------------------
// $Id: $
//
// Copyright(c) 2017 Renesas Electronics Corporation
// Copyright(c) 2017 Renesas Design Vietnam Co., Ltd.
// RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
// This program must be used solely for the purpose for which
// it was furnished by Renesas Electronics Corporation. No part of this
// program may be reproduced or disclosed to others, in any
// form, without the prior written permission of Renesas Electronics
// Corporation.
// ---------------------------------------------------------------------
#include <string>
#include "general_io.h"

/*********************************
// Function     : CgeneralIO
// Description  : Constructor of CgeneralIO class
// Parameter    :
//      name            Module name
// Return value : None
**********************************/
CgeneralIO::CgeneralIO(sc_module_name name, std::string target_product): sc_module(name)
                   , vpcl::tlm_tgt_if<32> (name), Cgeneral_io_regif((std::string)name,32)
{//{{{
    if (target_product == "Gen1" || target_product == "Gen2") {
        mTargetProduct = target_product;
    } else {
        printf("Info [%s] (%s) The target product (%s) is invalid. (Gen1) is set as default.\n", sc_time_stamp().to_string().c_str(), this->name(),target_product.c_str());
        mTargetProduct = "Gen1";
    }
    this->InitPort();
    this->ConnectPorts();
    Cgeneral_io_regif::set_instance_name((std::string)name);
    //Initial variables-------------------------
    this->Initialize();
    this->ConstructPortInfoTable();
    //------------------------------------------
    for (unsigned int i = 0; i < emIBOOL; i++) {
        sc_core::sc_spawn_options opt;
        opt.spawn_method();
        opt.set_sensitivity(ibool_port[i]);
        opt.dont_initialize();
        sc_core::sc_spawn(sc_bind(&CgeneralIO::HandleIBOOLInputMethod, this, i), sc_core::sc_gen_unique_name("HandleIBOOLInputMethod"), &opt);
    }
    for (unsigned int i = 0; i < emIUINT32; i++) {
        sc_core::sc_spawn_options opt;
        opt.spawn_method();
        opt.set_sensitivity(iuint32_port[i]);
        opt.dont_initialize();
        sc_core::sc_spawn(sc_bind(&CgeneralIO::HandleIUINT32InputMethod, this, i), sc_core::sc_gen_unique_name("HandleIUINT32InputMethod"), &opt);
    }
    for (unsigned int i = 0; i < emIUINT64; i++) {
        sc_core::sc_spawn_options opt;
        opt.spawn_method();
        opt.set_sensitivity(iuint64_port[i]);
        opt.dont_initialize();
        sc_core::sc_spawn(sc_bind(&CgeneralIO::HandleIUINT64InputMethod, this, i), sc_core::sc_gen_unique_name("HandleIUINT64InputMethod"), &opt);
    }

    SC_METHOD(HandleOBOOLOutputMethod);
    sensitive << mWriteOBOOLEvent;

    SC_METHOD(HandleOUINT32OutputMethod);
    sensitive << mWriteOUINT32Event;

    SC_METHOD(HandleOUINT64OutputMethod);
    sensitive << mWriteOUINT64Event;

    SC_METHOD(HandleORESETOutputMethod);
    sensitive << mWriteORESETEvent;

    SC_METHOD(HandleOCLKOutputMethod);
    sensitive << mWriteOCLKEvent;

    SetLatency_TLM(true);
}//}}}

/*********************************
// Function     : ~CgeneralIO
// Description  : Destructor of CgeneralIO class
// Parameter    : None
// Return value : None
**********************************/
CgeneralIO::~CgeneralIO(void)
{//{{{
    for (unsigned int i = 0; i < emOClock; i++) {
        delete oclk_port[i];
        delete oclk_sig[i];
    }
    for (unsigned int i = 0; i < emOResetH; i++) {
        delete oresetH_port[i];
        delete oresetH_sig[i];
    }
    for (unsigned int i = 0; i < emOResetL; i++) {
        delete oresetL_port[i];
        delete oresetL_sig[i];
    }
    for (unsigned int i = 0; i < emOUINT64; i++) {
        delete ouint64_port[i];
        delete ouint64_sig[i];
    }
    for (unsigned int i = 0; i < emOUINT32; i++) {
        delete ouint32_port[i];
        delete ouint32_sig[i];
    }
    for (unsigned int i = 0; i < emOBOOL; i++) {
        delete obool_port[i];
        delete obool_sig[i];
    }
    for (unsigned int i = 0; i < emIUINT64; i++) {
        delete iuint64_port[i];
        delete iuint64_sig[i];
    }
    for (unsigned int i = 0; i < emIUINT32; i++) {
        delete iuint32_port[i];
        delete iuint32_sig[i];
    }
    for (unsigned int i = 0; i < emIBOOL; i++) {
        delete ibool_port[i];
        delete ibool_sig[i];
    }
}//}}}

/*********************************
// Function     : read
// Description  : Access to read value of registers
// Parameter    :
//      is_rd_dbg           Debug access mode
//      addr                Register's address offset
//      p_data              Memory pointer
//      size                Access size
// Return value : true if reading transaction is finished normally
**********************************/
bool CgeneralIO::read (const bool is_rd_dbg, unsigned int addr, unsigned char *p_data, unsigned int size)
{//{{{
    assert(p_data != NULL);
    memset(p_data, 0, size);
    if (is_rd_dbg == false) {
        return reg_rd(addr,p_data,size);
    } else {
        return reg_rd_dbg(addr,p_data,size);
    }
}//}}}

/*********************************
// Function     : write
// Description  : Access to write value to registers
// Parameter    :
//      is_wr_dbg           Debug access mode
//      addr                Register's address offset
//      p_data              Memory pointer
//      size                Access size
// Return value : true if writing transaction is finished normally
**********************************/
bool CgeneralIO::write (const bool is_wr_dbg, unsigned int addr, unsigned char *p_data, unsigned int size)
{//{{{
    bool ret = false;
    assert(p_data != NULL);
    if (is_wr_dbg == false) {
        ret = reg_wr(addr,p_data,size);
    } else {
        ret = reg_wr_dbg(addr,p_data,size);
    }
    return ret;
}//}}}

/*********************************
// Function     : tgt_acc_dbg
// Description  : Access memory in debug mode via TLM target socket
//                This is virtual function of tlm_tgt_if
// Parameter    :
//      id                  TLM target socket ID
//      trans               Transaction
// Return value : None
**********************************/
unsigned int CgeneralIO::tgt_acc_dbg(unsigned int id, tlm::tlm_generic_payload &trans)
{//{{{
    // This function is not used because there are 1 TLM target socket
    // It is implemented to fix 1Team issue
    return tgt_acc_dbg(trans);
}//}}}
unsigned int CgeneralIO::tgt_acc_dbg(tlm::tlm_generic_payload &trans)
{//{{{
    //Get information
    tlm::tlm_command command;
    sc_dt::uint64 addr = 0;
    unsigned char *p_data = NULL;
    unsigned int size = 0;
    bool status = this->tgt_get_gp_attribute(command, addr, p_data, size, trans, true);
    sc_assert(p_data != NULL);

    //Read access
    if (command == tlm::TLM_READ_COMMAND) {
        memset(p_data, 0, size);
        status = read(true, (unsigned int)addr, p_data, size);
    //Write access    
    } else if (command == tlm::TLM_WRITE_COMMAND) {
        status = write(true, (unsigned int)addr, p_data, size);
    //No read/write access    
    } else {
        status = true;
        size = 0;
    }
    trans.set_response_status(tlm::TLM_OK_RESPONSE); 
    if (status){
        return size;
    } else {
        return 0;
    }
}//}}}

/*********************************
// Function     : tgt_acc
// Description  : Access memory in normal mode via TLM target socket
//                This is virtual function of tlm_tgt_if
// Parameter    :
//      id                  TLM target socket ID
//      trans               Transaction
// Return value : None
**********************************/
void CgeneralIO::tgt_acc(unsigned int id, tlm::tlm_generic_payload &trans, sc_time &t)
{//{{{
    // This function is not used because there are 1 TLM target socket
    // It is implemented to fix 1Team issue
    tgt_acc(trans, t);
}//}}}
void CgeneralIO::tgt_acc(tlm::tlm_generic_payload &trans, sc_time &t)
{//{{{
    //Get information
    tlm::tlm_command command;
    sc_dt::uint64 addr    = 0;
    unsigned char *p_data  = NULL;
    unsigned int size = 0; 
    bool status = this->tgt_get_gp_attribute(command, addr, p_data, size, trans, false);
    if (!status) {
        trans.set_response_status(tlm::TLM_BYTE_ENABLE_ERROR_RESPONSE);
        return;
    }
    sc_assert(p_data != NULL);

    //Read access
    if (command == tlm::TLM_READ_COMMAND) {
        memset(p_data, 0, size);
        status = read(false, (unsigned int)addr, p_data, size);
    //Write access 
    } else if (command == tlm::TLM_WRITE_COMMAND) {
        status = write(false, (unsigned int)addr, p_data, size);
    //No write/read access    
    } else {
        status = true;
    }
    trans.set_response_status(tlm::TLM_OK_RESPONSE); 
}//}}}

/*********************************
// Function     : ConnectPorts
// Description  : Connect ports with internal signals
// Parameter    : None
// Return value : None
**********************************/
void CgeneralIO::ConnectPorts(void)
{//{{{
    for (unsigned int i = 0; i < emIBOOL; i++) {
        if (i >= emUsedIBOOL) ibool_port[i]->bind(*ibool_sig[i]);
    }
    for (unsigned int i = 0; i < emIUINT32; i++) {
        if (i >= emUsedIUINT32) iuint32_port[i]->bind(*iuint32_sig[i]);
    }
    for (unsigned int i = 0; i < emIUINT64; i++) {
        if (i >= emUsedIUINT64) iuint64_port[i]->bind(*iuint64_sig[i]);
    }
    for (unsigned int i = 0; i < emOBOOL; i++) {
        if (i >= emUsedOBOOL) obool_port[i]->bind(*obool_sig[i]);
    }
    for (unsigned int i = 0; i < emOUINT32; i++) {
        if (i >= emUsedOUINT32) ouint32_port[i]->bind(*ouint32_sig[i]);
    }
    for (unsigned int i = 0; i < emOUINT64; i++) {
        if (i >= emUsedOUINT64) ouint64_port[i]->bind(*ouint64_sig[i]);
    }
    for (unsigned int i = 0; i < emOResetL; i++) {
        if (i >= emUsedOResetL) oresetL_port[i]->bind(*oresetL_sig[i]);
    }
    for (unsigned int i = 0; i < emOResetH; i++) {
        if (i >= emUsedOResetH) oresetH_port[i]->bind(*oresetH_sig[i]);
    }
    for (unsigned int i = 0; i < emOClock; i++) {
        if (i >= emUsedOClock) oclk_port[i]->bind(*oclk_sig[i]);
    }
}//}}}

/*********************************
// Function     : InitPort
// Description  : Initialize port list
// Parameter    : None
// Return value : None
**********************************/
void CgeneralIO::InitPort(void)
{//{{{
    std::ostringstream port_name;
    for (unsigned int i = 0; i < emIBOOL; i++) {
        port_name.str(""); port_name << "ibool_sig" << i;
        ibool_sig[i] = new sc_signal<bool, SC_UNCHECKED_WRITERS>(port_name.str().c_str());
        sc_assert(ibool_sig[i] != NULL);
        port_name.str(""); port_name << "ibool_port" << i;
        ibool_port[i] = new sc_in<bool>(port_name.str().c_str());
        sc_assert(ibool_port[i] != NULL);
    }
    for (unsigned int i = 0; i < emIUINT32; i++) {
        port_name.str(""); port_name << "iuint32_sig" << i;
        iuint32_sig[i] = new sc_signal<unsigned int, SC_UNCHECKED_WRITERS>(port_name.str().c_str());
        sc_assert(iuint32_sig[i] != NULL);
        port_name.str(""); port_name << "iuint32_port" << i;
        iuint32_port[i] = new sc_in<unsigned int>(port_name.str().c_str());
        sc_assert(iuint32_port[i] != NULL);
    }
    for (unsigned int i = 0; i < emIUINT64; i++) {
        port_name.str(""); port_name << "iuint64_sig" << i;
        iuint64_sig[i] = new sc_signal<uint64, SC_UNCHECKED_WRITERS>(port_name.str().c_str());
        sc_assert(iuint64_sig[i] != NULL);
        port_name.str(""); port_name << "iuint64_port" << i;
        iuint64_port[i] = new sc_in<uint64>(port_name.str().c_str());
        sc_assert(iuint64_port[i] != NULL);
    }
    for (unsigned int i = 0; i < emOBOOL; i++) {
        port_name.str(""); port_name << "obool_sig" << i;
        obool_sig[i] = new sc_signal<bool, SC_UNCHECKED_WRITERS>(port_name.str().c_str());
        sc_assert(obool_sig[i] != NULL);
        port_name.str(""); port_name << "obool_port" << i;
        obool_port[i] = new sc_out<bool>(port_name.str().c_str());
        sc_assert(obool_port[i] != NULL);
        obool_port[i]->initialize(false);
    }
    for (unsigned int i = 0; i < emOUINT32; i++) {
        port_name.str(""); port_name << "ouint32_sig" << i;
        ouint32_sig[i] = new sc_signal<unsigned int, SC_UNCHECKED_WRITERS>(port_name.str().c_str());
        sc_assert(ouint32_sig[i] != NULL);
        port_name.str(""); port_name << "ouint32_port" << i;
        ouint32_port[i] = new sc_out<unsigned int>(port_name.str().c_str());
        sc_assert(ouint32_port[i] != NULL);
        ouint32_port[i]->initialize(0x0);
    }
    for (unsigned int i = 0; i < emOUINT64; i++) {
        port_name.str(""); port_name << "ouint64_sig" << i;
        ouint64_sig[i] = new sc_signal<uint64, SC_UNCHECKED_WRITERS>(port_name.str().c_str());
        sc_assert(ouint64_sig[i] != NULL);
        port_name.str(""); port_name << "ouint64_port" << i;
        ouint64_port[i] = new sc_out<uint64>(port_name.str().c_str());
        sc_assert(ouint64_port[i] != NULL);
        ouint64_port[i]->initialize(0x0);
    }
    for (unsigned int i = 0; i < emOResetL; i++) {
        port_name.str(""); port_name << "oresetL_sig" << i;
        oresetL_sig[i] = new sc_signal<bool, SC_UNCHECKED_WRITERS>(port_name.str().c_str());
        sc_assert(oresetL_sig[i] != NULL);
        port_name.str(""); port_name << "oresetL_port" << i;
        oresetL_port[i] = new sc_out<bool>(port_name.str().c_str());
        sc_assert(oresetL_port[i] != NULL);
        oresetL_port[i]->initialize(true);
    }
    for (unsigned int i = 0; i < emOResetH; i++) {
        port_name.str(""); port_name << "oresetH_sig" << i;
        oresetH_sig[i] = new sc_signal<bool, SC_UNCHECKED_WRITERS>(port_name.str().c_str());
        sc_assert(oresetH_sig[i] != NULL);
        port_name.str(""); port_name << "oresetH_port" << i;
        oresetH_port[i] = new sc_out<bool>(port_name.str().c_str());
        sc_assert(oresetH_port[i] != NULL);
        oresetH_port[i]->initialize(false);
    }
    for (unsigned int i = 0; i < emOClock; i++) {
        port_name.str(""); port_name << "oclk_sig" << i;
        oclk_sig[i] = new sc_signal<uint64, SC_UNCHECKED_WRITERS>(port_name.str().c_str());
        sc_assert(oclk_sig[i] != NULL);
        port_name.str(""); port_name << "oclk_port" << i;
        oclk_port[i] = new sc_out<uint64>(port_name.str().c_str());
        sc_assert(oclk_port[i] != NULL);
        oclk_port[i]->initialize(0x0);
    }
}//}}}

/*********************************
// Function     : Initialize
// Description  : Initializes internal variables
// Parameter    : None
// Return value : None
**********************************/
void CgeneralIO::Initialize(void)
{//{{{
}//}}}

/*********************************
// Function     : CancelEvents
// Description  : Cancel all operation events
// Parameter    : None
// Return value : None
**********************************/
void CgeneralIO::CancelEvents(void)
{//{{{
    mWriteOBOOLEvent.cancel();
    mWriteOUINT32Event.cancel();
    mWriteOUINT64Event.cancel();
    mWriteORESETEvent.cancel();
    mWriteOCLKEvent.cancel();
}//}}}

/*********************************
// Function     : ConstructPortInfoTable
// Description  : Construct mPortInfo
// Parameter    : None
// Return value : None
**********************************/
void CgeneralIO::ConstructPortInfoTable(void)
{//{{{
    std::ostringstream port_name;
    unsigned int increase_id = 0;
    for (unsigned int i = 0; i < emIBOOL; i++) {
        increase_id = emMinIBOOL + i;
        mPortInfo.push_back(PortInfo(increase_id, GetPortName(i,emIBOOL_type)));
    }
    for (unsigned int i = 0; i < emIUINT32; i++) {
        increase_id = emMinIUINT32 + i;
        mPortInfo.push_back(PortInfo(increase_id, GetPortName(i,emIUINT32_type)));
    }
    for (unsigned int i = 0; i < emIUINT64; i++) {
        increase_id = emMinIUINT64 + i;
        mPortInfo.push_back(PortInfo(increase_id, GetPortName(i,emIUINT64_type)));
    }
    for (unsigned int i = 0; i < emOBOOL; i++) {
        increase_id = emMinOBOOL + i;
        mPortInfo.push_back(PortInfo(increase_id, GetPortName(i,emOBOOL_type)));
    }
    for (unsigned int i = 0; i < emOUINT32; i++) {
        increase_id = emMinOUINT32 + i;
        mPortInfo.push_back(PortInfo(increase_id, GetPortName(i,emOUINT32_type)));
    }
    for (unsigned int i = 0; i < emOUINT64; i++) {
        increase_id = emMinOUINT64 + i;
        mPortInfo.push_back(PortInfo(increase_id, GetPortName(i,emOUINT64_type)));
    }
    for (unsigned int i = 0; i < emOResetL; i++) {
        increase_id = emMinOResetL + i;
        mPortInfo.push_back(PortInfo(increase_id, GetPortName(i,emOResetL_type)));
    }
    for (unsigned int i = 0; i < emOResetH; i++) {
        increase_id = emMinOResetH + i;
        mPortInfo.push_back(PortInfo(increase_id, GetPortName(i,emOResetH_type)));
    }
    for (unsigned int i = 0; i < emOClock; i++) {
        increase_id = emMinOClock + i;
        mPortInfo.push_back(PortInfo(increase_id, GetPortName(i,emOClock_type)));
    }
#ifdef DEBUG_SIM_MESSAGE_RVC
    for (unsigned int i = 0; i < mPortInfo.size(); i++){
        printf("DEBUG: mPortInfo[%d][port_no: %d][port_name: %s]\n",i, mPortInfo[i].port_no, mPortInfo[i].port_name.c_str());
    }
#endif
}//}}}

/*********************************
// Function     : Handle<n>InputMethod
// Description  : Handle the change in input port
// Parameter    :
//      id                  Port index
// Return value : None
**********************************/
void CgeneralIO::HandleIBOOLInputMethod(const unsigned int id)
{//{{{
    std::string port_name = "";
    for (unsigned int i = 0; i < mPortInfo.size(); i++){
        if ((id+emMinIBOOL) == mPortInfo[i].port_no){
            port_name = mPortInfo[i].port_name;
            break;
        }
    }
    unsigned int reg_id = (unsigned int)(id/32);
    std::ostringstream strname;
    strname.str(""); strname << "IB" << (id - (reg_id*32));
    bool val_b = (bool)(*IBOOL_REG[reg_id])[strname.str().c_str()];
    if (val_b != ibool_port[id]->read()){
        (*IBOOL_REG[reg_id])[strname.str().c_str()] = ibool_port[id]->read();
        printf("Info [%s] (%s) Receive %s signal: 0x%X\n", sc_time_stamp().to_string().c_str(), this->name(), port_name.c_str(), ibool_port[id]->read());
#ifdef DEBUG_SIM_MESSAGE_RVC
        printf("DEBUG: IBOOL_REG[%d][%s] = 0x%X - 0x%X\n",reg_id, strname.str().c_str(), (unsigned int)(*IBOOL_REG[reg_id])[strname.str().c_str()], ibool_port[id]->read());
#endif
#ifdef COUNT_INTERRUPT_PULSE
        if (ibool_port[id]->read()) {
            CountUpINT(id);
        }
#endif
    }
}//}}}
void CgeneralIO::HandleIUINT32InputMethod(const unsigned int id)
{//{{{
    std::string port_name = "";
    for (unsigned int i = 0; i < mPortInfo.size(); i++){
        if ((id+emMinIUINT32) == mPortInfo[i].port_no){
            port_name = mPortInfo[i].port_name;
            break;
        }
    }
    unsigned int reg_id = id;
    unsigned int val_ui = (unsigned int)(*IUINT32_REG[reg_id]);
    if (val_ui != iuint32_port[id]->read()){
        (*IUINT32_REG[reg_id]) = iuint32_port[id]->read();
        printf("Info [%s] (%s) Receive %s signal: 0x%X\n", sc_time_stamp().to_string().c_str(), this->name(), port_name.c_str(), iuint32_port[id]->read());
#ifdef DEBUG_SIM_MESSAGE_RVC
        printf("DEBUG: IUINT32_REG[%d] = 0x%X - 0x%X\n",reg_id, (unsigned int)(*IUINT32_REG[reg_id]), iuint32_port[id]->read());
#endif
    }
}//}}}
void CgeneralIO::HandleIUINT64InputMethod(const unsigned int id)
{//{{{
    std::string port_name = "";
    for (unsigned int i = 0; i < mPortInfo.size(); i++){
        if ((id+emMinIUINT64) == mPortInfo[i].port_no){
            port_name = mPortInfo[i].port_name;
            break;
        }
    }
    unsigned int reg_id = id;
    unsigned int val1_ui = (unsigned int)(*IUINT64L_REG[reg_id]);
    unsigned int val2_ui = (unsigned int)(*IUINT64H_REG[reg_id]);
    uint64 val_ui64 = (val2_ui&0xFFFFFFFF00000000ULL) | (sc_dt::uint64)val1_ui&0xFFFFFFFF;
    if (val_ui64 != iuint64_port[id]->read()){
        (*IUINT64L_REG[reg_id]) = (unsigned int)(0xFFFFFFFF & iuint64_port[id]->read());
        (*IUINT64H_REG[reg_id]) = (unsigned int)(iuint64_port[id]->read() >> 32);
        printf("Info [%s] (%s) Receive %s signal: 0x%llX\n", sc_time_stamp().to_string().c_str(), this->name(), port_name.c_str(), iuint64_port[id]->read());
#ifdef DEBUG_SIM_MESSAGE_RVC
        printf("DEBUG: IUINT64_REG[%d] = 0x%X%X - 0x%llX\n",reg_id, (unsigned int)(*IUINT64H_REG[reg_id]), (unsigned int)(*IUINT64L_REG[reg_id]), iuint64_port[id]->read());
#endif
    }
}//}}}

/*********************************
// Function     : Handle<n>OutputMethod
// Description  : Handle the change in output port
// Parameter    : None
// Return value : None
**********************************/
void CgeneralIO::HandleOBOOLOutputMethod(void)
{//{{{
    std::string port_name = "";
    for (unsigned int i = 0; i < emOBOOL; i++) {
        for (unsigned int j = 0; j < mPortInfo.size(); j++){
            if ((i+emMinOBOOL) == mPortInfo[j].port_no){
                port_name = mPortInfo[j].port_name;
                break;
            }
        }
        unsigned int reg_id = (unsigned int)(i/32);
        std::ostringstream strname;
        strname.str(""); strname << "OB" << (i - (reg_id*32));
        bool val_b = (bool)(*OBOOL_REG[reg_id])[strname.str().c_str()];
        if (val_b != obool_port[i]->read()){
            printf("Info [%s] (%s) Issue %s signal: 0x%X\n", sc_time_stamp().to_string().c_str(), this->name(), port_name.c_str(), val_b);
            obool_port[i]->write(val_b);
        }
    }
}//}}}
void CgeneralIO::HandleOUINT32OutputMethod(void)
{//{{{
    std::string port_name = "";
    for (unsigned int i = 0; i < emOUINT32; i++) {
        for (unsigned int j = 0; j < mPortInfo.size(); j++){
            if ((i+emMinOUINT32) == mPortInfo[j].port_no){
                port_name = mPortInfo[j].port_name;
                break;
            }
        }
        unsigned int val_ui = (unsigned int)(*OUINT32_REG[i]);
        if (val_ui != ouint32_port[i]->read()){
            printf("Info [%s] (%s) Issue %s signal: 0x%X\n", sc_time_stamp().to_string().c_str(), this->name(), port_name.c_str(), val_ui);
            ouint32_port[i]->write(val_ui);
        }
    }
}//}}}
void CgeneralIO::HandleOUINT64OutputMethod(void)
{//{{{
    std::string port_name = "";
    for (unsigned int i = 0; i < emOUINT64; i++) {
        for (unsigned int j = 0; j < mPortInfo.size(); j++){
            if ((i+emMinOUINT64) == mPortInfo[j].port_no){
                port_name = mPortInfo[j].port_name;
                break;
            }
        }
        unsigned int val1_ui = (unsigned int)(*OUINT64L_REG[i]);
        unsigned int val2_ui = (unsigned int)(*OUINT64H_REG[i]);
        uint64 val_ui64 = (val2_ui&0xFFFFFFFF00000000ULL) | (sc_dt::uint64)val1_ui&0xFFFFFFFF;
        if (val_ui64 != ouint64_port[i]->read()){
            printf("Info [%s] (%s) Issue %s signal: 0x%llX\n", sc_time_stamp().to_string().c_str(), this->name(), port_name.c_str(), val_ui64);
            ouint64_port[i]->write(val_ui64);
        }
    }
}//}}}
void CgeneralIO::HandleORESETOutputMethod(void)
{//{{{
    std::string port_name = "";
    for (unsigned int i = 0; i < emOResetL; i++) {
        for (unsigned int j = 0; j < mPortInfo.size(); j++){
            if ((i+emMinOResetL) == mPortInfo[j].port_no){
                port_name = mPortInfo[j].port_name;
                break;
            }
        }
        bool val_b = (bool)(((*RESET_REG)["ACTL"] >> i)&0x1);
        if (val_b != oresetL_port[i]->read()){
            printf("Info [%s] (%s) Issue reset %s signal: %d\n", sc_time_stamp().to_string().c_str(), this->name(), port_name.c_str(), val_b);
            oresetL_port[i]->write(val_b);
        }
    }
    for (unsigned int i = 0; i < emOResetH; i++) {
        for (unsigned int j = 0; j < mPortInfo.size(); j++){
            if ((i+emMinOResetH) == mPortInfo[j].port_no){
                port_name = mPortInfo[j].port_name;
                break;
            }
        }
        bool val_b = (bool)(((*RESET_REG)["ACTH"] >> i)&0x1);
        if (val_b != oresetH_port[i]->read()){
            printf("Info [%s] (%s) Issue reset %s signal: %d\n", sc_time_stamp().to_string().c_str(), this->name(), port_name.c_str(), val_b);
            oresetH_port[i]->write(val_b);
        }
    }
}//}}}
void CgeneralIO::HandleOCLKOutputMethod(void)
{//{{{
    std::string port_name = "";
    for (unsigned int i = 0; i < emOClock; i++) {
        for (unsigned int j = 0; j < mPortInfo.size(); j++){
            if ((i+emMinOClock) == mPortInfo[j].port_no){
                port_name = mPortInfo[j].port_name;
                break;
            }
        }
        unsigned int val1_ui = (unsigned int)(*CLKL_REG[i]);
        unsigned int val2_ui = (unsigned int)(*CLKH_REG[i]);
        uint64 val_ui64 = (((sc_dt::uint64)val2_ui<<32)&0xFFFFFFFF00000000ULL) | (sc_dt::uint64)val1_ui&0xFFFFFFFF;
        if (val_ui64 != oclk_port[i]->read()){
            printf("Info [%s] (%s) Issue clock %s frequency signal: %llu (Hz)\n", sc_time_stamp().to_string().c_str(), this->name(), port_name.c_str(), val_ui64);
            oclk_port[i]->write(val_ui64);
        }
    }
}//}}}

/*********************************
// Function     : cb_<reg_name>_<bit_name>
// Description  : Callback function when register is written
// Parameter    :
//      str                 Register's callback string (0: Fail; 1: Pass; Others: Ignored)
// Return value : None
**********************************/
void CgeneralIO::cb_JUDGE_REG_JUDGE(RegCBstr str)
{//{{{
    if (str.data == 0) {
        printf("--------------------------------\n");
        printf("-          TM is FAIL          -\n");
        printf("--------------------------------\n");
    } else if (str.data == 1) {
        printf("--------------------------------\n");
        printf("-          TM is PASS          -\n");
        printf("--------------------------------\n");
    }
}//}}}
void CgeneralIO::cb_RESET_REG_ACTL(RegCBstr str)
{//{{{
    mWriteORESETEvent.notify(SC_ZERO_TIME);
}//}}}
void CgeneralIO::cb_CLKL_REG_CLKL(RegCBstr str)
{//{{{
    mWriteOCLKEvent.notify(SC_ZERO_TIME);
}//}}}
void CgeneralIO::cb_OBOOL_REG_OB0(RegCBstr str)
{//{{{
    mWriteOBOOLEvent.notify(SC_ZERO_TIME);
}//}}}
void CgeneralIO::cb_OUINT32_REG_OUINT(RegCBstr str)
{//{{{
    mWriteOUINT32Event.notify(SC_ZERO_TIME);
}//}}}
void CgeneralIO::cb_OUINT64L_REG_OUINTL(RegCBstr str)
{//{{{
    mWriteOUINT64Event.notify(SC_ZERO_TIME);
}//}}}

void CgeneralIO::SetLatency_TLM(const bool is_constructor)
{//{{{
    vpcl::tlm_if_tgt_parameter tgt_param = vpcl::tlm_tgt_if<32>::tgt_get_param();
    if(is_constructor){
        tgt_param.fw_req_phase = tlm::END_REQ;
    }
    sc_time new_clock(25,SC_NS);
    tgt_param.bus_clk = new_clock;
    tgt_param.rd_latency = tgt_param.rd_req_latency + 2 * tgt_param.bus_clk;
    tgt_param.wr_latency = tgt_param.wr_req_latency + 2 * tgt_param.bus_clk;
    vpcl::tlm_tgt_if<32>::tgt_set_param(&tgt_param);
}//}}}

