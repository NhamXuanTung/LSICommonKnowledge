// ---------------------------------------------------------------------
// $Id$
//
// Copyright(c) 2012 Renesas Electronics Corporation
// Copyright(c) 2012 Renesas Design Vietnam Co., Ltd.
// RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
// This program must be used solely for the purpose for which
// it was furnished by Renesas Electronics Corporation. No part of this
// program may be reproduced or disclosed to others, in any
// form, without the prior written permission of Renesas Electronics
// Corporation.
// ---------------------------------------------------------------------

#ifndef __SIMPLE_MEMORY_H__
#define __SIMPLE_MEMORY_H__
#include "systemc.h"
#include "tlm.h"
#include "general_memory.h"
#include <iterator>

/// SIMPLE_BSC model class
template <unsigned int BUSWIDTH = 64>
class Csimple_memory: public sc_module
                 , public gm::Cgeneral_memory<BUSWIDTH, 1, BUSWIDTH, 1>
                 , public tlm::tlm_bw_transport_if<>
{
#include "simple_memory_cmdif.h"
public:
    // member variables
    tlm::tlm_initiator_socket<BUSWIDTH, tlm::tlm_base_protocol_types, 1, sc_core::SC_ONE_OR_MORE_BOUND> m_ini_socket;
    // member methods
    Csimple_memory(sc_module_name name, unsigned int mem_address_width=32):sc_module(name)
                                   , gm::Cgeneral_memory<BUSWIDTH, 1,BUSWIDTH, 1>(name, mem_address_width)
                                   , m_ini_socket(((std::string)name + "_ini_socket").c_str())
    {//{{{
        // initialize command if
        this->CommandInit(this->name());
 
        // initialize member variables
        num_area = 0x0;
        m_ini_socket(*this);
        m_ini_socket(*gm::Cgeneral_memory<BUSWIDTH, 1,BUSWIDTH, 1>::m_reg_sockets[0]);      // internal connect reg_socket
    }//}}}
    ~Csimple_memory()
    {//{{{
      
    }//}}}

private:
    // member variables
    unsigned int num_area;  // number of allocated memory area
    // member methods
    void set_mem(unsigned int mem_offset, std::string mem_size)
    {
        std::istringstream str_size(mem_size.substr(0,mem_size.size()-1));
        std::string str_unit = mem_size.substr(mem_size.size()-1);
        unsigned int size = 0x0;
        unsigned int unit = 0x1;
        if(str_unit == "K"){         // for Kilobyte unit allocation
            unit *= 0x400;
        }else if(str_unit == "M"){   // for Megabyte unit allocation
            unit *= 0x100000;
        }else if(str_unit == "G"){   // for Gigabyte unit allocation
            unit *= 0x4000000;
        }else{
            re_printf("error","Setting unit other than \"K\" or \"M\" or \"G\" is not supported\n");
            return; 
        }
        str_size >> std::dec >> size; 
        if (str_size.fail() || !str_size.eof()) {
            re_printf("error","Invalid setting of memory size %s",str_size.str().c_str());
            return;
        }
        size = size*unit;
        
        std::ostringstream str_area;
        str_area << "AREA" << num_area++;
        
        bool chk_result = gm::Cgeneral_memory<BUSWIDTH, 1, BUSWIDTH, 1>::AddAreaConfig(str_area.str(), mem_offset, size, true);
        if(chk_result){
            printf("\nMemory allocation info: Area:%10s{0x%08X-0x%08X}, size = %sB\n",str_area.str().c_str(), mem_offset, mem_offset+size-1, mem_size.c_str());
        }else{ 
            printf("\nMemory allocation is fail: Area:%10s{0x%08X-0x%08X}, size = %sB\n",str_area.str().c_str(), mem_offset, mem_offset+size-1,mem_size.c_str());
        }
    }
    void reg_acc(unsigned int id, tlm::tlm_generic_payload &trans, sc_time &t) {;} // there is no reg part in this model
    unsigned int reg_acc_dbg(unsigned int id, tlm::tlm_generic_payload &trans) {return 0;} // there is no reg part in this model
    tlm::tlm_sync_enum nb_transport_bw(tlm::tlm_generic_payload &trans, tlm::tlm_phase &phase, sc_time &t)
    {
        return tlm::TLM_COMPLETED;
    }
    void invalidate_direct_mem_ptr(sc_dt::uint64 start_range, sc_dt::uint64 end_range)
    {
        ;  // do nothing
    }
};

#endif //__SIMPLE_MEMORY_H__
