// ---------------------------------------------------------------------
// $Id: $
//
// Copyright(c) 2017 Renesas Electronics Corporation
// Copyright(c) 2017 Renesas Design Vietnam Co., Ltd.
// RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
// This program must be used solely for the purpose for which
// it was furnished by Renesas Electronics Corporation. No part of this
// program may be reproduced or disclosed to others, in any
// form, without the prior written permission of Renesas Electronics
// Corporation.
// ---------------------------------------------------------------------
#ifndef __GENERAL_IO_H__
#define __GENERAL_IO_H__

#include <stdint.h>
#include "tlm_tgt_if.h"
#include "general_io_regif.h"

class CgeneralIO: public sc_module
                , public vpcl::tlm_tgt_if<32>
                , public Cgeneral_io_regif
{
// #define DEBUG_SIM_MESSAGE_RVC   //used to print DEBUG message in this model
#define COUNT_INTERRUPT_PULSE
// #define DUMP_DEBUG_COUNT_INTERRUPT
public:
    enum ePortNumber {
          emIBOOL           =960
        , emIUINT32         =30
        , emIUINT64         =10
        , emOBOOL           =960
        , emOUINT32         =30
        , emOUINT64         =10
        , emOResetL         =15
        , emOResetH         =15
        , emOClock          =10
        , emMinIBOOL        =0
        , emMinIUINT32      =emMinIBOOL   + emIBOOL
        , emMinIUINT64      =emMinIUINT32 + emIUINT32
        , emMinOBOOL        =emMinIUINT64 + emIUINT64
        , emMinOUINT32      =emMinOBOOL   + emOBOOL
        , emMinOUINT64      =emMinOUINT32 + emOUINT32
        , emMinOResetL      =emMinOUINT64 + emOUINT64
        , emMinOResetH      =emMinOResetL + emOResetL
        , emMinOClock       =emMinOResetH + emOResetH
        ////Define used port number //<=== Users modify here
        , emUsedIBOOL       =21
        , emUsedIUINT32     =0
        , emUsedIUINT64     =0
        , emUsedOBOOL       =312
        , emUsedOUINT32     =0
        , emUsedOUINT64     =0
        , emUsedOResetL     =7
        , emUsedOResetH     =0
        , emUsedOClock      =2
    };
    enum ePortType {
          emIBOOL_type      =0
        , emIUINT32_type    =1
        , emIUINT64_type    =2
        , emOBOOL_type      =3
        , emOUINT32_type    =4
        , emOUINT64_type    =5
        , emOResetL_type    =6
        , emOResetH_type    =7
        , emOClock_type     =8
    };

    //Declare ports
    sc_in<bool>                     *ibool_port[emIBOOL];
    sc_in<unsigned int>             *iuint32_port[emIUINT32];
    sc_in<uint64>                   *iuint64_port[emIUINT64];
    sc_out<bool>                    *obool_port[emOBOOL];
    sc_out<unsigned int>            *ouint32_port[emOUINT32];
    sc_out<uint64>                  *ouint64_port[emOUINT64];
    sc_out<bool>                    *oresetL_port[emOResetL];
    sc_out<bool>                    *oresetH_port[emOResetH];
    sc_out<uint64>                  *oclk_port[emOClock];

private:
    struct PortInfo {
        unsigned int port_no;
        std::string port_name;
        PortInfo(unsigned int port_no, std::string port_name){
            this->port_no = port_no;
            this->port_name = port_name;
        }
    };
    std::vector<PortInfo>           mPortInfo;

    //Control unbound ports
    sc_signal<bool, SC_UNCHECKED_WRITERS>                 *ibool_sig[emIBOOL];
    sc_signal<unsigned int, SC_UNCHECKED_WRITERS>         *iuint32_sig[emIUINT32];
    sc_signal<uint64, SC_UNCHECKED_WRITERS>               *iuint64_sig[emIUINT64];
    sc_signal<bool, SC_UNCHECKED_WRITERS>                 *obool_sig[emOBOOL];
    sc_signal<unsigned int, SC_UNCHECKED_WRITERS>         *ouint32_sig[emOUINT32];
    sc_signal<uint64, SC_UNCHECKED_WRITERS>               *ouint64_sig[emOUINT64];
    sc_signal<bool, SC_UNCHECKED_WRITERS>                 *oresetL_sig[emOResetL];
    sc_signal<bool, SC_UNCHECKED_WRITERS>                 *oresetH_sig[emOResetH];
    sc_signal<uint64, SC_UNCHECKED_WRITERS>               *oclk_sig[emOClock];

    //Declare variables
    //Not initialized when reset active
    std::string                     mTargetProduct;  //Products: Gen1, Gen2
    //Initialized when reset active

    //Declare events
    //Not canceled when reset is active
    //Canceled when reset is active
    sc_event                        mWriteOBOOLEvent;
    sc_event                        mWriteOUINT32Event;
    sc_event                        mWriteOUINT64Event;
    sc_event                        mWriteORESETEvent;
    sc_event                        mWriteOCLKEvent;

public:
    SC_HAS_PROCESS(CgeneralIO);
    CgeneralIO(sc_module_name name, std::string target_product = "Gen1");
    ~CgeneralIO (void);
    //Read/Write transaction
    bool read (const bool is_rd_dbg, unsigned int addr, unsigned char *p_data, unsigned int size);
    bool write (const bool is_wr_dbg, unsigned int addr, unsigned char *p_data, unsigned int size);

private:
    //Allow modification
    std::string GetPortName (const unsigned int i, const unsigned int port_type){ //<=== Users modify here
        std::ostringstream port_name;
        if (port_type == emIBOOL_type){
            port_name.str(""); port_name << "ibool_port" << i;
            if (i < emUsedIBOOL){ //<=== Users modify here
//////{{{ECM_FCC2: 0 -> 20 (ecmterroz, ecmterroutz_m, ecmterroutz_c, ecmtresz, ecmtnmi, ecmti_pe[][8], ecmdclsint[][8])
                if (i == 0) {
                    port_name.str(""); port_name << "ecmterroz";
                } else if (i == 1) {
                    port_name.str(""); port_name << "ecmterroutz_m";
                } else if (i == 2) {
                    port_name.str(""); port_name << "ecmterroutz_c";
                } else if (i == 3) {
                    port_name.str(""); port_name << "ecmtresz";
                } else if (i == 4) {
                    port_name.str(""); port_name << "ecmtnmi";
                } else if (i <= 12 && i > 4) {
                    port_name.str(""); port_name << "ecmti_pe" << i-5;
                } else if (i <= 20 && i > 12) {
                    port_name.str(""); port_name << "ecmdclsint" << i-13;
                }
//////}}}
            }
        } else if (port_type == emIUINT32_type){
            port_name.str(""); port_name << "iuint32_port" << i;
            if (i < emUsedIUINT32){ //<=== Users modify here
                //TODO
            }
        } else if (port_type == emIUINT64_type){
            port_name.str(""); port_name << "iuint64_port" << i;
            if (i < emUsedIUINT64){ //<=== Users modify here
                //TODO
            }
        } else if (port_type == emOBOOL_type){
            port_name.str(""); port_name << "obool_port" << i;
            if (i < emUsedOBOOL){ //<=== Users modify here
//////{{{ECM_FCC2: 0 -> 311 (ecmterrin[][308], ecmterrlbz_m, ecmterrlbz_c, ecmttin)
                if (i < 308) {
                    port_name.str(""); port_name << "ecmterrin" << i;
                } else if (i == 309) {
                    port_name.str(""); port_name << "ecmterrlbz_m";
                } else if (i == 310) {
                    port_name.str(""); port_name << "ecmterrlbz_c";
                } else if (i == 311) {
                    port_name.str(""); port_name << "ecmttin";
                }
//////}}}
            }
        } else if (port_type == emOUINT32_type){
            port_name.str(""); port_name << "ouint32_port" << i;
            if (i < emUsedOUINT32){ //<=== Users modify here
                //TODO
            }
        } else if (port_type == emOUINT64_type){
            port_name.str(""); port_name << "ouint64_port" << i;
            if (i < emUsedOUINT64){ //<=== Users modify here
                //TODO
            }
        } else if (port_type == emOResetL_type){
            port_name.str(""); port_name << "oresetL_port" << i;
            if (i < emUsedOResetL){ //<=== Users modify here
//////{{{ECM_FCC2: 0 -> 6 (preset_n, cntclk_preset_n, erroutresz, cntclk_erroutresz, resstg1z, pclkin_resstg1z, erroutresz_for_sync)
                if (i == 0) {
                    port_name.str(""); port_name << "preset_n";
                } else if (i == 1) {
                    port_name.str(""); port_name << "cntclk_preset_n";
                } else if (i == 2) {
                    port_name.str(""); port_name << "erroutresz";
                } else if (i == 3) {
                    port_name.str(""); port_name << "cntclk_erroutresz";
                } else if (i == 4) {
                    port_name.str(""); port_name << "resstg1z";
                } else if (i == 5) {
                    port_name.str(""); port_name << "pclkin_resstg1z";
                } else if (i == 6) {
                    port_name.str(""); port_name << "erroutresz_for_sync";
                }
//////}}}
            }
        } else if (port_type == emOResetH_type){
            port_name.str(""); port_name << "oresetH_port" << i;
            if (i < emUsedOResetH){ //<=== Users modify here
                //TODO
            }
        } else {//port_type == emOClock_type
            port_name.str(""); port_name << "oclk_port" << i;
            if (i < emUsedOClock){ //<=== Users modify here
//////{{{ECM_FCC2: 0 -> 1 (pclk, cntclk)
                if (i == 0) {
                    port_name.str(""); port_name << "pclk";
                } else if (i == 1) {
                    port_name.str(""); port_name << "cntclk";
                }
//////}}}
            }
        }
        return port_name.str().c_str();
    }
    void CountUpINT(const unsigned int ibool_id){
        unsigned int reg_id = 0;
        std::ostringstream strname;
//////{{{ECM_FCC2: IINTCNT_REG[0] -> IINTCNT_REG[16] are used
        if (ibool_id == 4) {//ecmtnmi
            unsigned int reg_val = (unsigned int)(*IINTCNT_REG[0]);
            (*IINTCNT_REG[0]) = reg_val + 1;
        } else if (ibool_id <= 12 && ibool_id > 4) {//ecmti_pe
            reg_id = (unsigned int)(1+ibool_id-5);
            unsigned int reg_val = (unsigned int)(*IINTCNT_REG[reg_id]);
            (*IINTCNT_REG[reg_id]) = reg_val + 1;
        } else if (ibool_id <= 20 && ibool_id > 12) {//ecmdclsint
            reg_id = (unsigned int)(9+ibool_id-13);
            unsigned int reg_val = (unsigned int)(*IINTCNT_REG[reg_id]);
            (*IINTCNT_REG[reg_id]) = reg_val + 1;
        }
        // if (ibool_id == 4) {//ecmtnmi
            // unsigned int reg_val = (unsigned int)(*IINTCNT_REG[0])["INT0"];
            // (*IINTCNT_REG[0])["INT0"] = reg_val + 1;
        // } else if (ibool_id <= 12 && ibool_id > 4) {//ecmti_pe
            // reg_id = (unsigned int)((ibool_id-5)/4);
            // strname.str(""); strname << "INT" << (ibool_id - 5 - (reg_id*4));
            // unsigned int reg_val = (unsigned int)(*IINTCNT_REG[reg_id+1])[strname.str().c_str()];
            // (*IINTCNT_REG[reg_id+1])[strname.str().c_str()] = reg_val + 1;
        // } else if (ibool_id <= 20 && ibool_id > 12) {//ecmdclsint
            // reg_id = (unsigned int)((ibool_id-13)/4);
            // strname.str(""); strname << "INT" << (ibool_id - 13 - (reg_id*4));
            // unsigned int reg_val = (unsigned int)(*IINTCNT_REG[reg_id+3])[strname.str().c_str()];
            // (*IINTCNT_REG[reg_id+3])[strname.str().c_str()] = reg_val + 1;
        // }
#ifdef DUMP_DEBUG_COUNT_INTERRUPT
        if (ibool_id >= 4 && ibool_id <= 20) printf("DEBUG: CountUpINT 2[%d] - ecmtnmi: %d\n \
                                              - ecmti_pe[0]: %d - ecmti_pe[1]: %d - ecmti_pe[2]: %d - ecmti_pe[3]: %d\n \
                                              - ecmti_pe[4]: %d - ecmti_pe[5]: %d - ecmti_pe[6]: %d - ecmti_pe[7]: %d\n \
                                              - ecmdclsint[0]: %d - ecmdclsint[1]: %d - ecmdclsint[2]: %d - ecmdclsint[3]: %d\n \
                                              - ecmdclsint[4]: %d - ecmdclsint[5]: %d - ecmdclsint[6]: %d - ecmdclsint[7]: %d\n",ibool_id,
                    (unsigned int)(*IINTCNT_REG[0]),
                    (unsigned int)(*IINTCNT_REG[1]),(unsigned int)(*IINTCNT_REG[2]),(unsigned int)(*IINTCNT_REG[3]),(unsigned int)(*IINTCNT_REG[4]),
                    (unsigned int)(*IINTCNT_REG[5]),(unsigned int)(*IINTCNT_REG[6]),(unsigned int)(*IINTCNT_REG[7]),(unsigned int)(*IINTCNT_REG[8]),
                    (unsigned int)(*IINTCNT_REG[9]),(unsigned int)(*IINTCNT_REG[10]),(unsigned int)(*IINTCNT_REG[11]),(unsigned int)(*IINTCNT_REG[12]),
                    (unsigned int)(*IINTCNT_REG[13]),(unsigned int)(*IINTCNT_REG[14]),(unsigned int)(*IINTCNT_REG[15]),(unsigned int)(*IINTCNT_REG[16]));
#endif
//////}}}
    }
    ////////////////////////////////////////
    //Virtual function of tlm_tgt_if
    void tgt_acc(unsigned int id, tlm::tlm_generic_payload &trans, sc_time &t);
    void tgt_acc( tlm::tlm_generic_payload &trans, sc_time &t);
    unsigned int tgt_acc_dbg(unsigned int id, tlm::tlm_generic_payload &trans);
    unsigned int tgt_acc_dbg( tlm::tlm_generic_payload &trans);

    void cb_JUDGE_REG_JUDGE(RegCBstr str);
    void cb_RESET_REG_ACTL(RegCBstr str);
    void cb_CLKL_REG_CLKL(RegCBstr str);
    void cb_OBOOL_REG_OB0(RegCBstr str);
    void cb_OUINT32_REG_OUINT(RegCBstr str);
    void cb_OUINT64L_REG_OUINTL(RegCBstr str);

    void ConnectPorts(void);
    void InitPort(void);
    void Initialize(void);                                                                 //Initializes internal variables & output ports
    void CancelEvents(void);                                                               //Cancel all operation events
    void ConstructPortInfoTable(void);

    void HandleIBOOLInputMethod(const unsigned int id);
    void HandleIUINT32InputMethod(const unsigned int id);
    void HandleIUINT64InputMethod(const unsigned int id);
    void HandleOBOOLOutputMethod(void);
    void HandleOUINT32OutputMethod(void);
    void HandleOUINT64OutputMethod(void);
    void HandleORESETOutputMethod(void);
    void HandleOCLKOutputMethod(void);

    void SetLatency_TLM(const bool is_constructor);
};
#endif
