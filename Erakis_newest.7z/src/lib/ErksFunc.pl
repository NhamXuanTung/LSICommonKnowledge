#!/bin/perl
use strict;
use warnings;
package ErksFunc;

sub ParseOptions{ # arguments is all
  my @out=("-100") x 23;
  ## @out:[0]$xls [1]$pg [2]$assertion [3]$testbench [4]$check_table [5]$test_vector [6]split pattern
  ##      [7]$pcheck [8]$max_error [9] Real Number model [10] generate all test pattern [11]: FSM assertion [12]:ok"*"list [13]:exclude assertion
  ##      [14]:completeness [15]FSM check [16]FSM test vector [17]blank error [18]message [19]:exclude patterns [20]_lfo [21]:no_back [22]:sdf
  my $is_fmt_err="-100"; # input format error
  if(@ARGV == 0){
    PrintUsage();
  }else{
    foreach my $opt(@_){
      if($opt =~ /^-/ && $opt !~ /-1/){ # option
        if($opt =~ /^-err$/){
          check_before(-1, $opt, @out);#check case: no argument for option which must have following argument. Ex: -err -vpd
          check_duplicated_option($opt, 8, @out);
          $out[8]="-20"; # flag
        }elsif($opt =~ /^-ex_ast$/){ # exclude assertion
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 13, @out);
          $out[13]="1";
        }elsif($opt =~ /^(-h|-help)$/){
          PrintUsage();
        }elsif($opt =~ /^-pg$/){
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 1, @out);
          $out[1]="1";
        }elsif($opt =~ /^(-ta|-assertion)$/){
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 2, @out);
          $out[2]="1";
        }elsif($opt =~ /^(-tb|-testbench)$/){
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 3, @out);
          $out[3]="1";
        }elsif($opt =~ /^(-tc|-tablecheck|-check)$/){
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 4, @out);
          $out[4]="1";
        }elsif($opt =~ /^(-tv|-ptn|-testvector)$/){
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 5, @out);
          $out[5]="1";
        }elsif($opt =~ /^-split$/){
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 6, @out);
          $out[6]="-20";
        }elsif($opt =~ /^(-p|-pcheck)$/){
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 7, @out);
          $out[7]="1";
        }elsif($opt =~ /^-rnm$/){
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 9, @out);
          $out[9]="1";
        }elsif($opt =~ /^-all_ptn$/){
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 10, @out);
          $out[10]="1";
        }elsif($opt =~ /^-fsmast$/){
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 11, @out);
          $out[11]="1";
        }elsif($opt =~ /^(-compression|-cr)$/){
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 12, @out);
          $out[12]="-20"; # flag
        }elsif($opt =~ /^-cpl$/){
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 14, @out);
          $out[14]="1";
        }elsif($opt =~ /^-fsmc$/){
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 15, @out);
          $out[15]="1";
        }elsif($opt =~ /^-fsmtv$/){
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 16, @out);
          $out[16]="1";
        }elsif($opt =~ /^-blank_error$/){
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 17, @out);
          $out[17]="-20";
        }elsif($opt =~ /^-message$/){
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 18, @out);
          $out[18]="-20";
        }elsif($opt =~ /^-ex_ptn$/){ # exclude pattern
            check_before(-1, $opt, @out);
            check_duplicated_option($opt, 19, @out);
            $out[19]="1";
        }elsif($opt =~ /^-lfo$/){ # exclude pattern
            check_before(-1, $opt, @out);
            check_duplicated_option($opt, 20, @out);
            $out[20]="1";
        }elsif($opt =~ /^-no_back$/){ # exclude pattern
            check_before(-1, $opt, @out);
            check_duplicated_option($opt, 21, @out);
            $out[21]="1";
        }elsif($opt =~ /^-sdf$/){ # exclude pattern
            check_before(-1, $opt, @out);
            check_duplicated_option($opt, 22, @out);
            $out[22]="1";
        }else{
          check_before(-1, $opt, @out);
          print("ERROR ::: Unknown option $opt.\n");
          return(1);
        }
      }elsif($opt =~ /^.*\.[^\/\.]+$/){ # excel file
        if($opt =~ /\.xls$/){ # excel file
          check_before(-1, $opt, @out);
          check_duplicated_option($opt, 0, @out);
          $out[0]=$opt;
        }else{
          $is_fmt_err=$opt;
        }
      }else{
        if($opt =~ /^[0-9]+$|-1/){ # number
          if($out[6] eq "-20"){
            check_before(6, $opt, @out);
            $out[6]=$opt;
            if ($out[6] < 1){
              print("ERROR ::: Invalid split number $opt.\n");
              return(1);
            }
          }else{
            check_before(8, $opt, @out);
            if($out[8] eq "-20"){ # max_err
              $out[8]=$opt;
            }else{
              print("ERROR ::: Unknown option $opt.\n");
              return(1);
            }
          }
        }elsif($out[17] eq "-20"){
          check_before(17, $opt, @out);
          $out[17]=$opt;
          if ($out[17] !~ /^(on|off)$/){
            print("ERROR ::: Invalid option $opt.\n");
            return(1);
          }
        }elsif($out[12] eq "-20" || $out[12] =~ /,/){
          check_before(12, $opt, @out);
          if($out[12] eq "-20"){
            $out[12]="";
          }
          $out[12]=$out[12]."$opt,";
        }elsif($out[18] eq "-20"){
          check_before(18, $opt, @out);
          if ($opt !~ /^(mode_change|all)$/){
            print("ERROR ::: Invalid option $opt.\n");
            return(1);
          }
          $out[18]=$opt;
        }else{
          print("ERROR ::: Unknown option $opt.\n");
          return(1);
        }
      }
    }
  }
  if($out[21] eq "1"){
    if($out[20] ne "1"){
      print("ERROR ::: \"-no_back\" option should be defined when \"-lfo\" option is defined.\n");
      return(1);
    }
  }
  if($out[0] eq "-100"){ # xls
    print("ERROR ::: Please include Excel file.\n");
    return(1);
  }elsif($is_fmt_err ne "-100"){
    print("ERROR ::: Unknown input format file $is_fmt_err.\n");
    return(1);
  }
  foreach my $p(1..5,7,11,15..16){
    if($out[$p] eq "-100"){
      $out[$p]="0";
    }
  }
  # check -tc/check and -cpl/completeness not specified same
  if ($out[4] eq "1" && $out[14] eq "1"){
    print("ERROR ::: Do not set both checking truth table and completeness lack pattern.\n");
    exit(1);
  }

  if($out[8] eq "-100"){ # max error
    $out[8]=100;
  }
  if($out[6] eq "-20"){
    print("ERROR ::: Set number of split pattern after -split option.\n");
    exit(1);
  }

  if($out[17] eq "-20"){
    print("ERROR ::: Set \"on/off\" after -blank_error option.\n");
    exit(1);
  }

  if($out[6] eq "-100"){ # no split option
    $out[6]=1;
  }
  if($out[17] eq "-100"){ # no blank_error option
    $out[17]="on";
  }
  if($out[18] eq "-100"){ # no message option
    $out[18]="mode_change";
  }
  if($out[20] eq "-100"){
      $out[20]="0";
  }
  return(@out);
}

sub PrintUsage{
  print("info :  $ENV{'ERAKIS_VER'}\n");
  print("Usage:  erks [Excel File] [OPTION]...\n");
  print("OPTION details\n");
  print("  -err               : Set max error number which checked.(-1:Output all error)\n");
  print("  -ex_ast            : Make assertion file with \"Exclude\" sheet.(check input)\n");
  print("  -ex_ptn            : Make test pattern file with \"Exclude\" sheet.\n");
  print("  -h | -help         : Reference help.\n");
  print("  -p | -pcheck       : Make test vector a part of truth table.\n");
  print("  -pg                : Use when verilog model with pg.\n");
  print("  -tc | -check       : Execute to check truth table.\n");
  print("  -tv | -ptn         : Execute to make test vector.\n");
  print("  -tb | -testbench   : Execute to make testbench.\n");
  print("  -ta | -assert      : Execute to make assertion file.\n");
  print("  -compression | -cr : Port allows \"*\".(unrecommend option)\n");
  print("  -cpl               : Control generating assertions for all lack patterns (not use with -tc| -check option)\n");
  print("  -fsmc              : Execute to check tables related to FSM.\n");
  print("  -fsmtv             : Execute to make test vectors for FSM.\n");
  print("  -fsmast            : Execute to make assertions for FSM.\n");
  print("  -all_ptn           : Generate test pattern without truth table.\n");
  print("  -rnm               : Generate test pattern with Real Number Model.\n");
  print("  -lfo               : Generate latch force output test patterns in case HOLD is defined in truth table and Latch port is defined.\n");
  print("  -no_back           : Define this option when -lfo is defined so that back to hold patterns are not generated.\n");
  print("  -sdf               : Make Simulation environment for SDF annotation.\n");
  print("  -split             : Split test pattern in to specified number. (Default: 1).\n");
  print("  -blank_error       : Dump error message if there is blank cell in truth table (on/off). (Default: on).\n");
  print("  -message           : Enable to check message of mode change or all test patterns after each test pattern (mode_change/all). (Default: mode_change).\n");
  print("\n");
  print("Exit states:\n");
  print("0 : OK,\n");
  print("1 : ERROR(Detail is in standard output).\n");
  print("3 : ERROR(Relating to input information, detail is in standard output).\n");
  exit(0);
}

# check before option
sub check_before{ # out array
  my ($index, $opt, @out)=@_;
  my @print=("ERROR") x 23;
  $print[8]="ERROR ::: Set max err number after -err option.\n";
  $print[9]="ERROR ::: Unknown option $opt.\n";
  $print[12]="ERROR ::: Set Port name after -cr or -compression option.\n";
  $print[6]="ERROR ::: Set number of split pattern after -split option.\n";
  $print[17]="ERROR ::: Set \"on/off\" after -blank_error option.\n";
  $print[18]="ERROR ::: Set \"mode_change/all\" after -message option.\n";
#  $print[18]="ERROR ::: Set value after -message option.\n";
  if($index eq "-1"){# check define option but no following argument (-err, -cr)
    for(my $i=0;$i<scalar(@out);$i++){
      if($out[$i] eq "-20"){
        print($print[$i]);#XXX consider the content
        exit(1);
      }
    }
  }
  return(0);
}

#check duplicated option
sub check_duplicated_option{
  my ($opt, $index, @out)=@_;
  my $duplicated=0;

  if ($out[$index] ne "-100"){
    $duplicated=1;
  }

  if ($duplicated==1){
    if ($opt =~ /\.xls$/){
      print("ERROR ::: Cannot define Excel file more than one time.\n");
    }else{
      print("ERROR ::: Cannot define \"$opt\" option more than one time.\n");
    }
    exit(1);
  }
}

### Exclude table fusion
sub TableInEx{ #[0]:truth table [1]:exclude ptn [2]:port table [3]:pg
  my $tbl=$_[0];
  my $ptn=$_[1];
  my $port=$_[2];
  my @PG=Ex2Tbl::PGExtract($ptn,$port,$_[3],0);
  my @out=@$tbl;
  my $row=scalar(@out);
  for(my $rowpg=4;$rowpg<scalar(@PG);$rowpg++){# for each ptn line of pg
    $out[$row][0]=$PG[$rowpg][0];# copy sheet, line info
    $out[$row][1]=$PG[$rowpg][1];

    for (my $col=2;$col<scalar(@{$out[0]});$col++){
      my $port_match=0;
      if ($out[0][$col] eq "message" || $out[0][$col] eq "action" || $out[0][$col] eq ""){
        next;
      }
      for (my $colpg=2;$colpg<scalar(@{$PG[0]});$colpg++){
        if ($PG[2][$colpg] eq $out[2][$col]){# match port name
          if ((defined $PG[$rowpg][$colpg]) && ($PG[$rowpg][$colpg]!~ /^[ ]*$/)){# define value of port
            $port_match=1;
            $out[$row][$col]=$PG[$rowpg][$colpg];
            $out[$row][$col] = "_*" if(($PG[$rowpg][$colpg]=~/^\/$/)&&($out[0][$col]eq"inout"));
          }
          last;# break to next port in @out
        }
      }
      if ($port_match==0){ # not match INPUT port name or not defined.
        if ($out[0][$col] =~ /inout/i){ # not match INPUT port name or not defined.
          $out[$row][$col]="_*"; # don't care
        }else{
          $out[$row][$col]="*"; # don't care output
        }
      }
    }
    $row++;

  }
  return(@out);
}

1;
