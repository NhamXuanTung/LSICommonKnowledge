#!/bin/perl
use strict;
use warnings;
use Spreadsheet::ParseExcel;  # for processing Excel sheets
package Ex2Tbl;

sub MakePortTable{ ## [0]:Excel file path [1]:ams [2]:def_step
  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$parser->parse($_[0]) or die "ERROR ::: $_[0] is not found.\n";
  my $worksheet=$workbook->worksheet("Port info") or die "ERROR ::: \"Port info\" is not found in \"$_[0]\".\n";
  my ($row_min, $row_max)=$worksheet->row_range(); # Excel effective row range
  my ($col_min, $col_max)=$worksheet->col_range(); # Excel effective col range
  my $def_step=$_[2];
  my $pref_unit = $_[3]; # frequency unit
  my $timescale = $_[4]; # timescale
  my @port=(); ## [0]:name [1]:inout [2]:D/A [3]:bit [4]:Level [5]:care range [6] clock period [7]:MSB [8]:LSB [9]: port width [10] port name [11] msb:lsb [12] oscillation port [13] min real range [14] max real range [15] def_step [16] input timming sequence [17] latch port [18] FB
  my $col=0;
  my $row=0;
  my $pname=-1;
  my $io=-1;
  my $bit=-1;
  my $msb=-1;
  my $lsb=-1;
  my $da=-1;
  my $sa=-1;
  my $cr=-1;
  my $rr=-1;
  my $clkf=-1;
  my $func=-1;
  my $checked=-1;
  my $mpw=-1; # multi port width
  my $is_clock = -1;
  my $is_latch = -1;

  my @ignored_row_list=get_ignored_row_list($worksheet);
  for (my $i=$row_min;$i<$row_max+1;$i++){
    if(grep(/^$i$/,@ignored_row_list) > 0){
        next;
    }
    for (my $j=$col_min;$j<$col_max+1;$j++){
      my $cell=&get_cell_val($i,$j,$worksheet);
      if(!(defined $cell) || $cell =~ /^#/ || $cell eq ""){
        if($j==$rr){
          $port[13][$row]="-";
          $port[14][$row]="-";
          $port[15][$row]="-";
          $port[16][$row]="-";
        }
        if($j==$cr){
          $port[12][$row]="";
        }
        if($j==$sa){
          $port[4][$row]="-";
        }
        next;
      }elsif($checked==-1){
        if($cell =~ /[Pp][Ii][Nn]/ || $cell =~ /[Pp][Oo][Rr][Tt]/ || $cell =~ /[Nn][Aa][Mm][Ee]/){
          $pname=$j;
        }elsif($cell =~ /I(\/*)O/){
          $io=$j;
        }elsif($cell =~ /D\/A/){
          $da=$j;
        }elsif($cell =~ /MSB/i){
          $msb=$j;
        }elsif($cell =~ /LSB/i){
          $lsb=$j;
        }elsif($cell =~ /SA|[Ss][Ii][Gg][Nn][Aa][Ll] [Aa][Mm][Pp][Ll][Ii][Tt][Uu][Dd][Ee]|[Ll]evel/){
          $sa=$j;
        }elsif($cell =~ /care\srange/){
          $cr=$j;
        }elsif($cell =~ /real\srange/){
          $rr=$j;
        }elsif($cell =~ /freq|frequency/i){
          $clkf=$j;
        }elsif($cell =~ /Function/i){
          $func=$j;  
        }
      }else{
        if($j == $pname){
          $port[0][$row]=$cell;
#          $port[6][$row]="-";
          $port[10][$row]=$cell;
        }elsif($j == $io){
          $port[17][$row]="-";
          $port[18][$row]="-";
          if($cell =~ /^inout$/i){# inout port
            $port[1][$row]="inout";
          }elsif($cell =~ /^clock$/i){
          # XXX temp remove
#            if ($is_clock == -1) {
#              $is_clock = 1;
#            } else {
#              printf("ERROR ::: [Port info] Multiple clock source specified in %s.\n",$cell, &get_cell_pos($i,$j));
#              exit(3);
#            }
            $port[1][$row]="clock";
            $port[5][$row]="-";
            $port[2][$row]="D";
          }elsif($cell =~ /^(in|input|latch)$/i){
            $port[1][$row]="input";
            if ($cell =~ /latch/i){
              $port[17][$row]="1" ;
              if ($is_latch == -1) {
                $is_latch = 1;
              } else {
                printf("ERROR ::: [Port info] Multiple latch port specified in %s.\n",$cell, &get_cell_pos($i,$j));
                exit(3);
              }
            }
          }elsif($cell =~ /^(out|output)$/i){
            $port[1][$row]="output";
            $port[5][$row]="-";
          }elsif($cell =~ /^(power|ground)$/i){
            $port[1][$row]=lc($cell);
          }else{
            printf("ERROR ::: [Port info] Invalid port i/o description \"%s\" in %s.\n",$cell, &get_cell_pos($i,$j));
            exit(3);
          }
        }elsif($j == $da){
          if($cell =~ /A|[Aa]nalog/){
            $port[2][$row]="A";
          }elsif($cell =~ /D|[Dd]igital/){
            $port[2][$row]="D";
          }else{
            printf("WARNING ::: [Port info] Invalid D/A description \"%s\" in %s. Please specify \"A|Analog|analog\" for analog signal or \"D|Digital|digital\" for digital signal. Otherwise \"Digital\" is set as default.\n",$cell, &get_cell_pos($i,$j));
            $port[2][$row]="D";
          }
          if(!defined($port[5][$row])){ # def:A->z D->x
            if($port[2][$row] eq "A"){
              $port[5][$row]="z";
            }else{
              $port[5][$row]="x";
            }
          }
        }elsif($j == $msb){
          if ($cell =~ /^\d+$/){
            $port[7][$row]=$cell;
          }else{
            printf("ERROR ::: [Port info] Invalid msb value \"%s\" in %s.\n",$cell, &get_cell_pos($i,$j));
            exit(3);
          }
        }elsif($j == $lsb){
          if ($cell =~ /^\d+$/){
            $port[8][$row]=$cell;
          }else{
            printf("ERROR ::: [Port info] Invalid lsb value \"%s\" in %s.\n",$cell, &get_cell_pos($i,$j));
            exit(3);
          }
        }elsif($j == $sa){
          if($cell=~/[0123456789]V$/){
            $cell=~s/V$//;
          }
          $port[4][$row]=$cell;
        }elsif($j == $cr){
          if($cell !~ /\%/){
            $port[12][$row]=-1;
            if ($cell =~ /^\s*-\s*$/||$cell=~/^\s*x\s*$/i||$cell=~/^\s*z\s*$/i){
              $port[5][$row]=$cell;
            }else{
              printf("ERROR ::: [Port info] Invalid care range value \"%s\" in %s.\n",$cell, &get_cell_pos($i,$j));
              exit(3);
            }
          }else{
            $port[12][$row]=1;
            if($cell=~/\+\-/ || $cell!~/\+|\-/){
              $cell=~s/\+\-//;
              $cell=~s/\%//;
              $cell =~ s/\s//g;
              $port[5][$row]=$cell/100;
              $port[5][$row]=$port[5][$row]."-".$port[5][$row];
            }elsif(($cell!~/\+/ && $cell=~/\-/)||($cell=~/\+/ && $cell!~/\-/)){
              printf("ERROR ::: [Port info] Invalid care range value \"%s\" in %s.\n",$cell, &get_cell_pos($i,$j));
              exit(3);
            }else{
              $cell =~ s/\s//g;
              my $plus=$cell;
              my $minus=$cell;
              $plus=~s/\+(\d+)\%\-\d+\%/$1/;
              $minus=~s/\+\d+\%\-(\d+)\%/$1/;
              $cell=($minus/100)."-".($plus/100);
              $port[5][$row]=$cell;
            }
          }
        }elsif($j == $rr){
          if($cell eq "-"){
            $port[13][$row]="-";
            $port[14][$row]="-";
            $port[15][$row]="-";
            $port[16][$row]="-";
          }elsif($cell =~ /^\s*\d*\.?\d+\s*\/\s*\d*\.?\d+\s*$/){
            $port[13][$row]=(split(/\//,$cell))[0];
            $port[13][$row]=~s/\s//g;
            $port[14][$row]=(split(/\//,$cell))[1];
            $port[14][$row]=~s/\s//g;
            $port[15][$row]=$def_step;
            $port[16][$row]="-";
            if (eval($port[13][$row]) > eval($port[14][$row])){
              printf("ERROR ::: [Port info] %s is invalid value.\n",&get_cell_pos($i,$j));
              exit(3);
            }
          }elsif($cell =~ /\s*on\s*/i){
            $port[13][$row]=0;
            $port[14][$row]="SA";
            $port[15][$row]=$def_step;
            $port[16][$row]="-";
          }else{
            printf("ERROR ::: [Port info] %s is invalid value.\n",&get_cell_pos($i,$j));
            exit(3);
          }
        }elsif($j == $clkf){
          if(!(defined $cell) || $cell =~ /^#/ || $cell eq "" || $cell eq "-"){
            $port[6][$row]="-";
          }elsif($cell =~ /^\s*\d*\.?\d+\s*$/ and $cell ne "0" and  $cell !~ /rise|fall/){   ## support real value in clock port
            $port[6][$row]=calc_period($cell,$pref_unit,$timescale);
            if ($port[6][$row] == 0) {
              printf("ERROR ::: [Port info] The period of clock port \"%s\" is less than 1 unit time of system.\n", $port[0][$row]);
              exit(3);
            }
          }else{
            printf("ERROR ::: [Port info] %s is invalid value.\n",&get_cell_pos($i,$j));
            exit(3);
          }
        }elsif($j == $func){
           if($cell eq "FB"){
               $port[18][$row] = $cell;
           }else{
               $port[18][$row] = "-";
           }
        }
      }
    }
    if(defined $port[0][$row]){
      if($cr==-1){ # care range column is not defined
        $port[12][$row]="-";
      }
      if($rr==-1){ # real range column is not defined
        $port[13][$row]="-";
        $port[14][$row]="-";
        $port[15][$row]="-";
        $port[16][$row]="-";
      }
      if(($msb == -1) || (!defined($port[7][$row]))){
        $port[7][$row]=0;
      }
      if(($lsb == -1) || (!defined($port[8][$row]))){
        $port[8][$row]=0;
      }
      $port[3][$row] = $port[7][$row] - $port[8][$row];
      if ($port[3][$row] < 0){
        printf("ERROR ::: [Port info] Invalid port range $port[0][$row]"."[$port[7][$row]:$port[8][$row]].\n");
        exit(3);
      }
      $port[3][$row]=1; # for separate multiple bitwidth port
      if($sa == -1){
        $port[4][$row]="vdd";
      }
      if($cr == -1){
        $port[5][$row]=($port[2][$row] eq "D") ? "x" :
                       ($port[2][$row] eq "A") ? "z" : "-";
      }
      if ($clkf == -1){
        $port[6][$row]="100";
      }
      if($port[7][$row] !=0 || $port[8][$row] != 0){
        $mpw = 0;
        $port[9][$row] = $port[7][$row] - $port[8][$row] + 1; # Bit with of port
        $port[11][$row] = $port[7][$row].":".$port[8][$row];
      } else {
        $port[9][$row] = -1;
        $port[11][$row] = "-";
      }
      if ($port[9][$row] != -1 and $port[9][$row] != 1 and $port[17][$row] eq "1") {
        printf("WARNING ::: [Port info] Latch port $port[0][$row] should be single bitwidth.\n");
      }
      $row++;
    }
    if($pname!=-1 || $io!=-1 || $da!=-1 || $bit!=-1 || $sa!=-1){
      if($pname==-1){
        print("ERROR ::: Port Name info is not in $_[0] - port info.\n");
        exit(3);
      }elsif($io==-1){
        print("ERROR ::: I/O info is not in $_[0] - port info.\n");
        exit(3);
      }elsif($da==-1){
        print("ERROR ::: D/A info is not in $_[0] - port info.\n");
        exit(3);
      }else{
        $checked=0;
      }
    }
  }
  for(my $i=0;$i<scalar(@{$port[4]});$i++){
    for(my $j=0;$j<scalar(@{$port[0]});$j++){
#      if ($port[4][$i] eq "-" && $port[1][$i] =~ /power|ground/ && defined($port[0][$i])){
#        printf("ERROR ::: [Port info] SA value is not defined for supply port %s.\n", $port[0][$i]);
#        exit(3);
#      }
      if ($port[4][$i] eq "-" && defined($port[0][$i]) && ($port[2][$i] eq "A" || $port[1][$i] =~/power/)){
        $port[4][$i] = "5"; 
        print("WARNING ::: The default SA value (5) is set for port $port[0][$i].\n");
      }
      $port[4][$i] = "0" if ($port[4][$i] eq "-" && defined($port[0][$i]) &&  $port[1][$i] =~/ground/);
      if($port[4][$i] eq $port[0][$j]){
        $port[4][$i]=$port[4][$j];
        if (defined $port[14][$i] && $port[14][$i] eq "SA"){
          $port[14][$i]=$port[4][$j];
        }
        last;
      }
    }
  }
  # Check real port
  for(my $j=0;$j<scalar(@{$port[0]});$j++){
    if ($port[14][$j] ne "-"){
       if (!defined $port[4][$j] || $port[4][$j] !~ /^\d*\.?\d+$/){
         printf("WARNING ::: [Port info] SA value is not defined for real port %s.\n", $port[0][$j]);
       }else{
         if ($port[14][$j] > $port[4][$j]){
           printf("WARNING ::: [Port info] Real range of %s port %s exceed the supply value.\n",&get_port_type($port[0][$j],@port), $port[0][$j]);
         }
       }
    }
  }
  if($_[1]eq"ams"){
    for(my $i=0;$i<scalar(@{$port[1]});$i++){
      if($port[2][$i] eq "A"){
        $port[1][$i]=($port[1][$i] eq "input") ? "electrical_in" :
                      ($port[1][$i] eq "output") ? "electrical_out" : $port[1][$i];
      }
    }
  }
  if ($mpw == 0) {
    @port = &separate_port(@port);
  }
  undef $parser;
  undef $workbook;
  undef $worksheet;
  return(@port);
}

sub MakeTimingTable{ ## [0]:Excel file path [1] port table
  my ($xls,$sheet,@port)=@_;
  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$parser->parse($xls) or die "ERROR ::: $xls is not found.\n";
  my $worksheet=$workbook->worksheet("$sheet") or die "ERROR ::: \"$sheet\" is not found in \"$xls\".\n";
  my ($row_min, $row_max)=$worksheet->row_range(); # Excel effective row range
  my ($col_min, $col_max)=$worksheet->col_range(); # Excel effective col range
  my @rfseq=();
  my @inseq=();
  my @outseq=();
  my $rfrow = 1;
  my $irow = 1;
  my $orow = 1;
  my $fc=-1; #"from" column
  my $lc=-1; #"to" column
  my $tc=-1; #"constraint" time column
  my $cc=-1; #"constraint" clock column
  my $vc=-1; #"constraint" value column
  my @inf_list=(); #input from port list
  my @inl_list=(); #input to port list
  my @dup_list=(); #check duplicate definition
  my $des_row=-1; # description row
  my %clock_source;
  my $clock_num = 0;
  for(my $i=0;$i<scalar(@{$port[0]});$i++){
    if ($port[1][$i] eq "clock") {
      $clock_source{"$port[0][$i]"}=$port[6][$i];# clock_period
      $clock_num++;
    }
  }
  for (my $i=$row_min;$i<$row_max+1;$i++){
    if(!defined $inseq[0][0] && !defined $outseq[0][0]){ # process header
      for (my $j=$col_min;$j<$col_max+1;$j++){
        my $cell=&get_cell_val($i,$j,$worksheet);
        if(!(defined $cell) || $cell eq ""){
          next;
        } elsif($cell =~ /^#/){
          last;
        }elsif($cell =~ /^from$/i or $cell =~ /^front$/i){
          $rfseq[0][2]="port";
          $inseq[0][2]="from";
          $outseq[0][2]="from";
          $fc=$j;
          $des_row=$i;
        }elsif($cell =~ /^to$/i or $cell =~ /^later$/i){
          $inseq[0][3]="from";
          $inseq[0][3]="to";
          $outseq[0][3]="to";
          $lc=$j;
          $des_row=$i;
        }elsif($cell =~ /constraint|time|clock|value/i){
          $rfseq[0][3]="rise";
          $rfseq[0][4]="fall";
          $inseq[0][4]="constraint";
          $outseq[0][4]="constraint";
          $outseq[0][5]="row_pos";
          $outseq[0][6]="clock_source";
          $outseq[0][7]="period";
          $outseq[0][8]="value";
          if ($cell =~ /time|constraint/i) { # "time" column
            $tc=$j;
          } elsif ($cell =~ /value/i) { # "value" column
            $vc=$j;
          }else{  # "clock" column
            $cc=$j;
            if ($clock_num == 0) {
              print("ERROR ::: [$sheet] Clock source is not defined for clock timing constraint.\n");
              exit(3);
            }
          }
          $des_row=$i;
        }
      }
      if(($des_row!=-1) && (($fc==-1) || ($lc==-1) || (($cc==-1)&&($tc==-1)))){
        if($fc==-1){
          print("ERROR ::: [$sheet] Lack \"from/front\" column description in row $des_row.\n");
        }
        if($lc==-1){
          print("ERROR ::: [$sheet] Lack \"to/later\" column description in row $des_row.\n");
        }
        if($cc==-1 && $tc==-1){
          print("ERROR ::: [$sheet] Lack \"constraint/time/clock/value\" column description in row $des_row.\n");
        }
        exit(3);
      }elsif ($des_row != -1){
        $rfseq[0][0]="Sheet";
        $rfseq[0][1]="row";
        $inseq[0][0]="Sheet";
        $inseq[0][1]="row";
        $outseq[0][0]="Sheet";
        $outseq[0][1]="row";
        if ($clock_num != 0 && $cc==-1) {
          print("WARNING ::: [$sheet] Clock source is defined but there is no clock timing constraint.\n");
        }
      }
    }else{ # process timing sequence define
      my $fvar=""; #from value
      my $lvar=""; #to value
      my $tcvar=""; # time constraint value
      my $ccvar=""; # clock constraint value
      my $vcvar=""; # value constraint value
      my $row_pos=""; # constraint cell position
      my $ignore=0; # ignore output sequence in Exclude_Constraint sheet
      for (my $j=$col_min;$j<$col_max+1;$j++){
        my $cell=&get_cell_val($i,$j,$worksheet);
        my $check_exclude_cell = $cell;
        $cell =~ s/\(\s*(in|out|rise|fall|osc)\s*\)/\($1\)/g if (defined $cell and $cell =~ /\(\s*(in|out|rise|fall|osc)\s*\)/);
        my $port_name = $cell;
        if(!(defined $cell) || $cell eq ""){
          next;
        } elsif($cell =~ /^#/){
          last;
        }elsif($j==$fc or $j==$lc){
          $port_name =~ s/^\(.*\)\s*//g;
          if($check_exclude_cell =~ /\(out\)/ && $sheet eq "Exclude_Constraint"){
            printf("WARNING ::: [$sheet] Erakis does not support output port %s at %s.\n",$port_name, &get_cell_pos($i,$j));
            $ignore = 1;
          }

          if ($cell !~ /^\((in|fall|rise|osc)\) *[a-zA-Z_0-9]+|^\(out\)\s*[a-zA-Z_0-9]+|^[a-zA-Z_0-9]+$/i){
            printf("ERROR ::: [$sheet] Invalid port format \"$cell\" at %s.\n",&get_cell_pos($i,$j));
            exit(3);
          }
          if (&get_port_type($port_name,@port) eq "") {
            printf("ERROR ::: [$sheet] Invalid port name at %s.\n",&get_cell_pos($i,$j));
            exit(3);
          }
          if (($cell =~ /^[a-zA-Z_0-9]+$/i) && (&get_port_type($port_name,@port) eq "inout")){
            printf("WARNING ::: [$sheet] Inout port %s must be defined with prefix (in) or (out) at %s.\n",$port_name, &get_cell_pos($i,$j));
            if($sheet ne "Exclude_Constraint"){
              $cell="(out)".$cell;
            }
          }
          if (($cell =~ /^[a-zA-Z_0-9]+$/i) && (&get_port_type($port_name,@port) eq "output")){
            if($sheet eq "Exclude_Constraint"){
              printf("WARNING ::: [$sheet] Erakis does not support output port %s at %s.\n",$port_name, &get_cell_pos($i,$j));
              $ignore = 1;
            }else{
              $cell="(out)".$cell;
            }
          }
          if($ignore ==0){
            if($j==$fc){
              $fvar=$cell;
              $fvar=~s/\) */\)/;
            } else {
              $lvar=$cell;
              $lvar=~s/\) */\)/;
            }
          }
        }elsif($j==$tc){
          if ($cell !~ /^\d+$|^\d+-\d+$/i){ # time format [num]/[num-num]
            printf("ERROR ::: [$sheet] Invalid constraint format at %s.\n",&get_cell_pos($i,$j));
            exit(3);
          }
          $tcvar=$cell;
          $tcvar=~s/\s+/ /g;
        }elsif($j==$cc){ # clock format [(clock name)][pos/neg num]
          if ($cell !~ /^(\(.*\))?\s*pos\s*\d+$|^(\(.*\))?\s*neg\s*\d+$/i){ # clock format [pos/neg num]
            printf("ERROR ::: [$sheet] Invalid constraint format at %s.\n",&get_cell_pos($i,$j));
            exit(3);
          }
          $ccvar=$cell;
          $ccvar=~s/\s+/ /g;
        }elsif($j==$vc){ # value format [num]
          if($cell !~ /^(\d*'+)b[01xzXZ]+$/ and $cell !~ /^(\d*'+)d\d+$/ and $cell !~ /^(\d*'+)h[\dABCDEFXZabcdefxz]+$/ and $cell !~ /^(\d+|x|z)$/i){
            printf("ERROR ::: [$sheet] Invalid constraint format at %s.\n",&get_cell_pos($i,$j));
            exit(3);
          } else {
            $vcvar = $cell;
            $vcvar =~ s/^(0|1|x|z)$/1'b$1/;
          }
        }
        $row_pos = $i+1;
      }
      if ($fvar eq "" || $lvar eq "" || ($tcvar eq "" && $ccvar eq "")){
        if(!(($fvar eq "" && $lvar eq "" && ($tcvar eq "" || $ccvar eq "")))){
          if($ignore == 0){
            printf("WARNING ::: [$sheet] Lack constraint information at row %s.\n",$i+1);
          }
        }
      }else{
        if ($fvar =~ /^\(out\)\s*[a-zA-Z_0-9]+/i || $lvar =~ /^\((out|osc)\)\s*[a-zA-Z_0-9]+/i){
          if(grep(/^\Q$fvar$lvar\E$/,@dup_list)>0){
            printf("WARNING ::: [$sheet] Duplicate constraint definition at row %s.\n",$i+1);
          }else{
            if (($fvar !~ /^(\((in|out|fall|rise|osc)\))?\s*[a-zA-Z_0-9]+/i)
            || ($lvar !~ /^(\((out|osc)\))?\s*[a-zA-Z_0-9]+/i)){
#            || (($fvar =~ /^\(osc\)/i || $lvar =~ /^\(osc\)/i) and $tcvar =~ /\d+-\d+/)) { # XXX check osc and "$time-$time" sequence
              my $time_constraint = $tcvar;
              $time_constraint = $ccvar if ($ccvar ne "");
              printf("ERROR ::: [$sheet] Invalid output sequence format \"$fvar - $lvar: %s\" at %s.\n", $time_constraint,&get_cell_pos($i,$lc));
              exit(3);
            }
            if ($fvar =~ /\(osc\)/ || $lvar =~ /\(osc\)/) {
              my %osc_port_name;
              $osc_port_name{$fc} = $fvar if $fvar =~ /\(osc\)/;
              $osc_port_name{$lc} = $lvar if $lvar =~ /\(osc\)/;
              foreach my $key (keys %osc_port_name) {
                my $port_name = $osc_port_name{$key};
                $port_name =~ s/\(.*\)\s*//;
                if (check_oscillation_port($port_name,@port) ne "1") {
                  printf("ERROR ::: [$sheet] Invalid output sequence format at %s. \"(osc)\" is used for oscillation output port only.\n",&get_cell_pos($i,$key));
                  exit(3);
                }
              }
            }
            if ($ccvar !~ /^\(.*\)\s*(pos|neg)\s*\d+$/ and $tcvar eq "" and $clock_num > 1){
              printf("ERROR ::: [$sheet] Lack clock name reference at %s.\n",&get_cell_pos($i,$cc));
              exit(3);
            }
            if ($tcvar ne "" and $tcvar =~ /^\d+-\d+$/) {
              my ($min, $max)=split(/-/,$tcvar);
              if ($min > $max) {
                printf("ERROR ::: [$sheet] Invalid constraint format at %s.\n",&get_cell_pos($i,$tc));
                exit(3);
              }
            }
            if ($tcvar ne "" and $ccvar ne "") {
              printf("ERROR ::: [$sheet] Do not support defining 2 kinds of constraint format at %s and %s at the same time.\n",&get_cell_pos($i,$tc),&get_cell_pos($i,$cc));
              exit(3);
            }
            if ($ccvar =~ /^\(.*\)\s*(pos|neg)\s*\d+$/){ 
              my $clock_name = $ccvar;
              $clock_name =~ s/^\(//;
              $clock_name =~ s/\).*$//;
              if (get_port_type($clock_name,@port) eq "") {
                printf("ERROR ::: [$sheet] Invalid clock name \"$clock_name\" at %s.\n",&get_cell_pos($i,$cc));
                exit(3);
              }
              $ccvar =~ s/^\(.*\)\s*//;
              $outseq[$orow][6]=$clock_name;
              $outseq[$orow][7]=$clock_source{"$clock_name"};
            } elsif ($ccvar =~ /^(pos|neg)\s*\d+$/){
              my $clock_name = (keys %clock_source)[0];
              $outseq[$orow][6]=$clock_name;
              $outseq[$orow][7]=$clock_source{"$clock_name"};
            } else {
              $outseq[$orow][6]="-";
              $outseq[$orow][7]="-";
            }
            if ($vcvar ne "") {
              $outseq[$orow][8]=$vcvar;
            } else {
              $outseq[$orow][8]="-";
            }
            push(@dup_list,"$fvar$lvar");
            $outseq[$orow][0]=$sheet;
            $outseq[$orow][1]=$i;
            $fvar=~s/\s//g;
            $lvar=~s/\s//g;
            $tcvar=~s/\s//g;
            $outseq[$orow][2]=$fvar;
            $outseq[$orow][3]=$lvar;
            if ($tcvar ne "") {
              $outseq[$orow][4]=$tcvar;
            } else {
              $outseq[$orow][4]=$ccvar;
            }
            $outseq[$orow][5]=$row_pos;
            $orow++;
          }
        }else{
          if($sheet eq "Exclude_Constraint"){
            if(grep(/^\Q$fvar$lvar\E$/,@dup_list)>0){
              printf("WARNING ::: [$sheet] Duplicate constraint definition at row %s.\n",$i+1);
            }else{
              if ($vcvar ne "") {
                printf("WARNING ::: [$sheet] Input sequence does not support value constraint at %s.\n",&get_cell_pos($i,$vc));
              }
              if ($ccvar ne "") {
                printf("ERROR ::: [$sheet] Input sequence does not support clock timing constraint \"$ccvar\" at %s.\n",&get_cell_pos($i,$cc));
                exit(3);
              }
              if ($tcvar ne "" && $tcvar !~ /^\d+$/i) {
                printf("ERROR ::: [$sheet] Invalid constraint format at %s.\n",&get_cell_pos($i,$tc));
                exit(3);
              }
              push(@dup_list,"$fvar$lvar");
              my $ftmp = $fvar;
              my $ltmp = $lvar;
              $ftmp=~s/\(.*\)//g;
              $ltmp=~s/\(.*\)//g;
              if ($ftmp eq $ltmp and $fvar =~ /^\((rise|fall)\)[a-zA-Z_0-9]+/i){
                printf("ERROR ::: [$sheet] Rising/falling can not be defined in \"from\" column at %s.\n",&get_cell_pos($i,$fc));
                exit(3);
              }
              if ($ftmp ne $ltmp and $lvar =~ /^\((rise|fall)\)[a-zA-Z_0-9]+/i){
                printf("ERROR ::: [$sheet] Invalid sequence format at %s and %s.\n",&get_cell_pos($i,$fc),&get_cell_pos($i,$lc));
                exit(3);
              }
              if ($ftmp eq $ltmp and $lvar =~ /^\((rise|fall)\)[a-zA-Z_0-9]+/i){
                # rise/fall timing definition
                $rfseq[$rfrow][0]=$sheet;
                $rfseq[$rfrow][1]=$i;
                $rfseq[$rfrow][2]=$ftmp;
                $rfseq[$rfrow][3]=0;
                $rfseq[$rfrow][4]=0;
                my $var_col = 3;
                $var_col = 4 if ($lvar =~ /^\(fall\)[a-zA-Z_0-9]+/i);
                  $rfseq[$rfrow][$var_col]=$tcvar;
                $rfrow++;
              } 
              # input timing sequence
              $inseq[$irow][0]=$sheet;
              $inseq[$irow][1]=$i;
              $fvar=~s/\(in\)//g;
              $lvar=~s/\(in\)//g;
              $fvar=~s/\(rise\)/ERKSRISE_/g;
              $lvar=~s/\(rise\)/ERKSRISE_/g;
              $fvar=~s/\(fall\)/ERKSFALL_/g;
              $lvar=~s/\(fall\)/ERKSFALL_/g;
              $inseq[$irow][2]=$fvar;
              $inseq[$irow][3]=$lvar;
                $inseq[$irow][4]=$tcvar;
              $irow++;
            }
          }else{
            printf("WARNING ::: [$sheet] Erakis does not support define input-input constraint in Constraint sheet at line %s. Please define it in \"delay\" sheet\n",$i+1);
          }
        }
      }
    }
  }
  @rfseq = () if (scalar(@rfseq) == 1);
  @inseq = () if (scalar(@inseq) == 1);
  @outseq = () if (scalar(@outseq) == 1);
  return(\@inseq,\@outseq,\@rfseq);
}

sub MakeDelayTable{ ## [0]:Excel file path [1] port table
  my ($xls,$sheet,@port)=@_;
  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$parser->parse($xls) or die "ERROR ::: $xls is not found.\n";
  my $worksheet=$workbook->worksheet("$sheet") or die "ERROR ::: \"$sheet\" is not found in \"$xls\".\n";
  my ($row_min, $row_max)=$worksheet->row_range(); # Excel effective row range
  my ($col_min, $col_max)=$worksheet->col_range(); # Excel effective col range
  my @rfseq=();
  my @inseq=();
  my $rfrow = 1;
  my $irow = 1;
  my $orow = 1;
  my $grp=-1; #"group" column
  my @num_grp_inseq  = ();
  my $fc=-1; #"from" column
  my $lc=-1; #"to" column
  my $tc=-1; #"constraint" time column
  my $cc=-1; #"constraint" clock column
  my $vc=-1; #"constraint" value column
  my @inf_list=(); #input from port list
  my @inl_list=(); #input to port list
  my @dup_list=(); #check duplicate definition
  my $des_row=-1; # description row
  my %clock_source;
  my $clock_num = 0;
  for(my $i=0;$i<scalar(@{$port[0]});$i++){
    if ($port[1][$i] eq "clock") {
      $clock_source{"$port[0][$i]"}=$port[6][$i];# clock_period
      $clock_num++;
    }
  }
  for (my $i=$row_min;$i<$row_max+1;$i++){
    if(!defined $inseq[0][0]){ # process header
      for (my $j=$col_min;$j<$col_max+1;$j++){
        my $cell=&get_cell_val($i,$j,$worksheet);
        if(!(defined $cell) || $cell eq ""){
          next;
        } elsif($cell =~ /^#/){
          last;
        }elsif($cell =~ /^group$/i){
          $inseq[0][5]="group";
          $grp = $j;
        }elsif($cell =~ /^from$/i or $cell =~ /^front$/i){
          $rfseq[0][2]="port";
          $inseq[0][2]="from";
          $fc=$j;
          $des_row=$i;
        }elsif($cell =~ /^to$/i or $cell =~ /^later$/i){
          $inseq[0][3]="from";
          $inseq[0][3]="to";
          $lc=$j;
          $des_row=$i;
        }elsif($cell =~ /constraint|time|clock|value/i){
          $rfseq[0][3]="rise";
          $rfseq[0][4]="fall";
          $inseq[0][4]="constraint";
          if ($cell =~ /time|constraint/i) { # "time" column
            $tc=$j;
          } elsif ($cell =~ /value/i) { # "value" column
            $vc=$j;
          }else{  # "clock" column
            $cc=$j;
            if ($clock_num == 0) {
              print("ERROR ::: [$sheet] Clock source is not defined for clock timing constraint.\n");
              exit(3);
            }
          }
          $des_row=$i;
        }
      };
      if(($des_row!=-1) && (($fc==-1) || ($lc==-1) || (($cc==-1)&&($tc==-1)))){
        if($fc==-1){
          print("ERROR ::: [$sheet] Lack \"from/front\" column description in row $des_row.\n");
        }
        if($lc==-1){
          print("ERROR ::: [$sheet] Lack \"to/later\" column description in row $des_row.\n");
        }
        if($cc==-1 && $tc==-1){
          print("ERROR ::: [$sheet] Lack \"constraint/time/clock/value\" column description in row $des_row.\n");
        }
        exit(3);
      }elsif ($des_row != -1){
        $rfseq[0][0]="Sheet";
        $rfseq[0][1]="row";
        $inseq[0][0]="Sheet";
        $inseq[0][1]="row";
        if ($clock_num != 0 && $cc==-1 && $sheet ne "delay") {
          print("WARNING ::: [$sheet] Clock source is defined but there is no clock timing constraint.\n");
        }
      }
    }else{ # process timing sequence define
      my $fvar=""; #from value
      my $lvar=""; #to value
      my $tcvar=""; # time constraint value
      my $ccvar=""; # clock constraint value
      my $vcvar=""; # value constraint value
      my $row_pos=""; # constraint cell position
      my $ignore=0; # ignore output sequence in Exclude_Constraint sheet
      my $grp_tmp="";
      for (my $j=$col_min;$j<$col_max+1;$j++){
        my $cell=&get_cell_val($i,$j,$worksheet);
        my $check_exclude_cell = $cell;
        $cell =~ s/\(\s*(in|out|rise|fall|osc)\s*\)/\($1\)/g if (defined $cell and $cell =~ /\(\s*(in|out|rise|fall|osc)\s*\)/);
        my $port_name = $cell;

        if(!(defined $cell) || $cell eq ""){
          next;
        }elsif($cell =~ /^#/){
          $ignore = 1;
          last;
        }elsif($j==$fc or $j==$lc){
          $port_name =~ s/^\(.*\)\s*//g;
          if($check_exclude_cell =~ /\(out\)/){
            printf("WARNING ::: [$sheet] Erakis does not support output port %s at %s.\n",$port_name, &get_cell_pos($i,$j));
            $ignore = 1;
          }

          if ($cell !~ /^\((in|fall|rise|osc)\) *[a-zA-Z_0-9]+|^\(out\)\s*[a-zA-Z_0-9]+|^[a-zA-Z_0-9]+$/i){
            printf("ERROR ::: [$sheet] Invalid port format \"$cell\" at %s.\n",&get_cell_pos($i,$j));
            exit(3);
          }
          if (&get_port_type($port_name,@port) eq "") {
            printf("ERROR ::: [$sheet] Invalid port name at %s.\n",&get_cell_pos($i,$j));
            exit(3);
          }
          if (($cell =~ /^[a-zA-Z_0-9]+$/i) && (&get_port_type($port_name,@port) eq "inout")){
            printf("WARNING ::: [$sheet] Inout port %s must be defined with prefix (in) or (out) at %s.\n",$port_name, &get_cell_pos($i,$j));
            if($sheet ne "Exclude_Constraint"){
              $cell="(out)".$cell;
            }
          }
          if (($cell =~ /^[a-zA-Z_0-9]+$/i) && (&get_port_type($port_name,@port) eq "output")){
            if($sheet eq "delay"){
              printf("WARNING ::: [$sheet] Erakis does not support output port %s at %s.\n",$port_name, &get_cell_pos($i,$j));
              $ignore = 1;
            }else{
              $cell="(out)".$cell;
            }
          }
          if($ignore ==0){
            if($j==$fc){
              $fvar=$cell;
              $fvar=~s/\) */\)/;
            } else {
              $lvar=$cell;
              $lvar=~s/\) */\)/;
            }
          }
        }elsif($j==$tc){
          if ($cell !~ /^\d+$|^\d+-\d+$/i){ # time format [num]/[num-num]
            printf("ERROR ::: [$sheet] Invalid constraint format at %s.\n",&get_cell_pos($i,$j));
            exit(3);
          }
          $tcvar=$cell;
          $tcvar=~s/\s+/ /g;
        }elsif($j==$cc){ # clock format [(clock name)][pos/neg num]
          if ($cell !~ /^(\(.*\))?\s*pos\s*\d+$|^(\(.*\))?\s*neg\s*\d+$/i){ # clock format [pos/neg num]
            printf("ERROR ::: [$sheet] Invalid constraint format at %s.\n",&get_cell_pos($i,$j));
            exit(3);
          }
          $ccvar=$cell;
          $ccvar=~s/\s+/ /g;
        }elsif($j==$vc){ # value format [num]
          if($cell !~ /^(\d*'+)b[01xzXZ]+$/ and $cell !~ /^(\d*'+)d\d+$/ and $cell !~ /^(\d*'+)h[\dABCDEFXZabcdefxz]+$/ and $cell !~ /^(\d+|x|z)$/i){
            printf("ERROR ::: [$sheet] Invalid constraint format at %s.\n",&get_cell_pos($i,$j));
            exit(3);
          } else {
            $vcvar = $cell;
            $vcvar =~ s/^(0|1|x|z)$/1'b$1/;
          }
        }elsif($j == $grp){
          if(!(defined $cell) || $cell eq ""){
              $grp_tmp = $inseq[$irow-1][5];
          }else{
              $grp_tmp = $cell;
          }
        }
        $row_pos = $i+1;
      }
      if ($fvar eq "" || $lvar eq "" || ($tcvar eq "" && $ccvar eq "")){
        if(!(($fvar eq "" && $lvar eq "" && ($tcvar eq "" || $ccvar eq "")))){
          if($ignore == 0){
            printf("WARNING ::: [$sheet] Lack constraint information at row %s.\n",$i+1);
          }
        }
      }else{
        if ($fvar =~ /^\(out\)\s*[a-zA-Z_0-9]+/i || $lvar =~ /^\((out|osc)\)\s*[a-zA-Z_0-9]+/i){  # process output port in from colum and to colum
          printf("WARNING ::: [$sheet] Erakis does not support define constraint of output port in \"delay\" sheet at line %s. Please define it in \"Constraint\" sheet.\n",$i+1);
          $ignore = 1;
        }else{
          if ($vcvar ne "") {
            printf("WARNING ::: [$sheet] Input sequence does not support value constraint at %s.\n",&get_cell_pos($i,$vc));
          }
          if ($ccvar ne "") {
            printf("ERROR ::: [$sheet] Input sequence does not support clock timing constraint \"$ccvar\" at %s.\n",&get_cell_pos($i,$cc));
            exit(3);
          }
          if ($tcvar ne "" && $tcvar !~ /^\d+$/i) {
            printf("ERROR ::: [$sheet] Invalid constraint format at %s.\n",&get_cell_pos($i,$tc));
            exit(3);
          }
          push(@dup_list,"$fvar$lvar");
          my $ftmp = $fvar;
          my $ltmp = $lvar;
          $ftmp=~s/\(.*\)//g;
          $ltmp=~s/\(.*\)//g;
          if ($ftmp eq $ltmp and $fvar =~ /^\((rise|fall)\)[a-zA-Z_0-9]+/i){
            printf("ERROR ::: [$sheet] Rising/falling can not be defined in \"from\" column at %s.\n",&get_cell_pos($i,$fc));
            exit(3);
          }
          if ($ftmp ne $ltmp and $lvar =~ /^\((rise|fall)\)[a-zA-Z_0-9]+/i){
            printf("ERROR ::: [$sheet] Invalid sequence format at %s and %s.\n",&get_cell_pos($i,$fc),&get_cell_pos($i,$lc));
            exit(3);
          }
          if($ignore == 0){
            if ($ftmp eq $ltmp and $lvar =~ /^\((rise|fall)\)[a-zA-Z_0-9]+/i){
              # rise/fall timing definition
              $rfseq[$rfrow][0]=$sheet;
              $rfseq[$rfrow][1]=$i;
              $rfseq[$rfrow][2]=$ftmp;
              $rfseq[$rfrow][3]=0;
              $rfseq[$rfrow][4]=0;
              my $var_col = 3;
              $var_col = 4 if ($lvar =~ /^\(fall\)[a-zA-Z_0-9]+/i);
#              if ($tcvar ne "") {
                $rfseq[$rfrow][$var_col]=$tcvar;
#              }else{
#                $ccvar =~ s/(p|n).* *(\d+)/$1$2/;
#                $rfseq[$rfrow][$var_col]=$ccvar;
#              }
              $rfrow++;
            } 
            # input timing sequence
            $inseq[$irow][0]=$sheet;
            $inseq[$irow][1]=$i;
            $fvar=~s/\(in\)//g;
            $lvar=~s/\(in\)//g;
            $fvar=~s/\(rise\)/ERKSRISE_/g;
            $lvar=~s/\(rise\)/ERKSRISE_/g;
            $fvar=~s/\(fall\)/ERKSFALL_/g;
            $lvar=~s/\(fall\)/ERKSFALL_/g;
            $inseq[$irow][2]=$fvar;
            $inseq[$irow][3]=$lvar;
#            if ($tcvar ne "") {
              $inseq[$irow][4]=$tcvar;
#            }else{
#              $ccvar =~ s/(p|n).* *(\d+)/$1$2/;
#              $inseq[$irow][4]=$ccvar;
#            }
            if($grp != -1){
                $grp_tmp =~ s/\s+/_/g;
                $inseq[$irow][5] = $grp_tmp;
                if($grp_tmp ne ""){
                    push(@num_grp_inseq, $grp_tmp);
                }else{
                    $inseq[$irow][5] = $inseq[$irow-1][5];
                }
            }
            $irow++;
          }
        }
      }
    }
  }
  @rfseq = () if (scalar(@rfseq) == 1);
  @inseq = () if (scalar(@inseq) == 1);
  if(scalar(@inseq) > 1 && $grp != -1){
    for(my $i=1; $i< scalar(@inseq);$i++){
        if(!defined $inseq[$i][5]){
            $inseq[$i][5] = $inseq[$i-1][5];
        }
    }
  }
  my @in = ();
  my @ref = ();
  my @in_table = ();
  my $cont = 1;
  my $row = 1;
  my $i= 0;
  if(scalar(@num_grp_inseq) < 2) {
      @{$in_table[0]}=@inseq;
  }else{
      my @in_tmp = ();
      my @rf_tmp = ();
      my $sub_row = 1;
      while($cont == 1){ # for input sequence
          @{$in_tmp[0]}=@{$inseq[0]};
          if($row > 1){
              if($inseq[$row][5] ne $inseq[$row-1][5]){
                  @{$in_table[$i]} = @in_tmp;
                  @in_tmp = ();
                  @{$in_tmp[0]}=@{$inseq[0]};
                  $sub_row = 1;
                  $i++;
              }
          }
          @{$in_tmp[$sub_row]} = @{$inseq[$row]};
          if($row == (scalar(@inseq)-1)){
              @{$in_tmp[$sub_row]} = @{$inseq[$row]};
              @{$in_table[$i]} = @in_tmp;
              $cont = 0;
          }
          $sub_row++;
          $row++;
      }
  }
  return(\@num_grp_inseq, \@in_table,\@rfseq);
}

sub GetTimingSeq{
  my ($inseq_,$tbl_,$ptbl_,$rfseq_)=@_;
  my @inseq=();
  if(ref($inseq_)){
   @inseq = @$inseq_;   
  }
  my @tbl=@$tbl_;
  my @timing_seq=();
  my @inf_list=();
  my @inl_list=();
  my @row_list=();
  my @out=();
  my @port=@$ptbl_;
  my $clock_period = 0;
  for(my $i=0;$i<scalar(@{$port[0]});$i++){
    if ($port[1][$i] eq "clock") {
      $clock_period=$port[6][$i];# clock_period
      last;
    }
  }
  
  # remove output port in inseq (inout port act as output port);
  if (@inseq != 0){
    my @output_list=();
    for (my $j=1;$j<scalar(@{$tbl[0]});$j++){
      if(!defined $tbl[0][$j] || ($tbl[0][$j] ne "input" && $tbl[0][$j] ne "output" && $tbl[0][$j] ne "inout")){
        next;
      }
      if(($tbl[0][$j] eq "output") || ($tbl[0][$j] eq "inout" && $tbl[4][$j] =~ /^_/)){
        push(@output_list,$tbl[2][$j]);
      }
    }
    my @new_inseq=();
    for (my $i=1;$i<scalar(@inseq);$i++){
      next if(grep(/^\Q$inseq[$i][2]\E$/,@output_list)>0 || grep(/^\Q$inseq[$i][3]\E$/,@output_list)>0);
      if(grep(/^\Q$inseq[$i][2]\E$/,@inf_list)<1){
        push(@inf_list,$inseq[$i][2]);
      }
      push(@inl_list,$inseq[$i][3]);
      push(@new_inseq,[@{$inseq[$i]}]);
    }
#    if(scalar(@new_inseq)>2){
      my ($timing_seq_,$row_list_)=&ProcessInputTimingSeq(\@new_inseq,\@inf_list,\@inl_list,$clock_period,$rfseq_);
      @timing_seq=@$timing_seq_;
      @row_list=@$row_list_;
#    }
    @tbl=SortTruthTable(\@tbl,\@timing_seq,$ptbl_);
  }
  return(\@tbl,\@row_list);
}

sub ProcessInputTimingSeq{
  my ($inseq_,$inf_list_,$inl_list_,$clock_period,$rfseq_) = @_;
  my @inseq=@$inseq_;
  my @inf_list=@$inf_list_;
  my @inl_list=@$inl_list_;
  my @seq_list=(); # initial port list;
  my @timing_seq=(); # timing sequence table
  my $row=0;
  for(my $i=0;$i<scalar(@inf_list);$i++){
    if(grep(/^\Q$inf_list[$i]\E$/,@inl_list)<1){
      $seq_list[$row][0] = $inf_list[$i];
      $row++
    }
  }
  if(scalar(@seq_list)==0){
    printf("ERROR ::: [Constraint] Invalid input timing sequence, no initial input port.\n");
    exit(3);
  }
  my $cont=0;
  ($cont,@seq_list)=&find_timing_sequence(\@inseq,\@seq_list);

  while ($cont!=0){
    ($cont,@seq_list)=&find_timing_sequence(\@inseq,\@seq_list);
  }
  # Calculate timing sequence
  my @row_list=();
  for (my $i=0;$i<scalar(@seq_list);$i++){
    my ($tm_seq,$rlist)=&calculate_timing_seq(\@{$seq_list[$i]},\@timing_seq,\@inseq,\@row_list,$clock_period,$rfseq_);
    @timing_seq=@$tm_seq;
    @row_list=@$rlist;
  }
  # Sort and check timing seq
  # buble sort
  $cont=1;
  while ($cont!=0){
    $cont=0;
    for (my $i=0;$i<scalar(@timing_seq);$i++){
      for (my $k=$i+1;$k<scalar(@timing_seq);$k++){
        if ($timing_seq[$i][0] eq $timing_seq[$k][0]) {
          if ($timing_seq[$i][1] != $timing_seq[$k][1]){
            print("ERROR ::: [Constraint] Conflict input timing constraint for port $timing_seq[$i][0] ($timing_seq[$i][1] and $timing_seq[$k][1] from initial).\n");
            exit(3);
          }else{
            next;
          }
        }
        if ($timing_seq[$i][1] > $timing_seq[$k][1]){
          $cont=1;
          my @tmp = ();
          $tmp[0]= $timing_seq[$k][0];
          $tmp[1]= $timing_seq[$k][1];
          $timing_seq[$k][0]=$timing_seq[$i][0];
          $timing_seq[$k][1]=$timing_seq[$i][1];
          $timing_seq[$i][0]=$tmp[0];
          $timing_seq[$i][1]=$tmp[1];
          next;
        }
      }
    }
  }
  # calibrate again the current timing sequence
  for (my $i=scalar(@timing_seq)-1;$i>=0;$i--){
    $timing_seq[$i][1] = $timing_seq[$i][1] + abs($timing_seq[0][1]);
  }
  # remove duplicate item
  my @out=();
  my @dup_list=();
  for (my $i=0;$i<scalar(@timing_seq);$i++){
    if (grep(/^\Q$timing_seq[$i][0]\E$/,@dup_list)<1){
      push(@dup_list,$timing_seq[$i][0]);
      push(@out,$timing_seq[$i]);
    }
  }
  return (\@out,\@row_list);
}


sub calculate_timing_seq{
  my ($seq_,$tm_seq_,$inseq_,$rlist_,$clock_period,$rfseq_)=@_;
  my @seq=@$seq_;
  my @timing_seq=@$tm_seq_;
  my @inseq=@$inseq_;
  my @rfseq=@$rfseq_;
  my @row_list=@$rlist_;
  my $row=0;
  my $delay = 0;
  my @cur_seq=();
  $cur_seq[$row][0]=$seq[0];
  $cur_seq[$row][1]=0;
  $row++;
  # get current timming sequence
  for (my $j=0;$j<scalar(@seq)-1;$j++){
    my ($tmp, $rep_row)=&get_time_constr($seq[$j],$seq[$j+1],@inseq);
#    if ($tmp =~ /^(p|n)/) {
#      $tmp = get_next_clock_edge($delay,$tmp,$clock_period);
#    }
    $delay = $delay + $tmp;
    $cur_seq[$row][0]=$seq[$j+1];
    $cur_seq[$row][1]=$delay;
    push(@row_list,$rep_row);
    $row++;
  }
  # calibrate for checking rising/falling
  for (my $i=0;$i<scalar(@cur_seq);$i++){
    if ($cur_seq[$i][0] =~ /^ERKS(RISE|FALL)_/){
      my $port_name = $cur_seq[$i][0];
      $port_name =~ s/^ERKS(RISE|FALL)_//;
      for (my $j=1;$j<scalar(@rfseq);$j++){
        if (cmp_port_name($port_name,$rfseq[$j][2]) eq "1"){
          $cur_seq[$i][1] = $cur_seq[$i][1] - $rfseq[$j][3] if $cur_seq[$i][0] =~ /^ERKSRISE_/;
          $cur_seq[$i][1] = $cur_seq[$i][1] - $rfseq[$j][4] if $cur_seq[$i][0] =~ /^ERKSFALL_/;
        }
      }
    }
  }
  # calculate the offset timing value
  my $offset = 0;
  for (my $i=0;$i<scalar(@cur_seq);$i++){
    for (my $k=0;$k<scalar(@timing_seq);$k++){
      if(cmp_port_name($cur_seq[$i][0],$timing_seq[$k][0]) == 1){
        $offset = $timing_seq[$k][1] - $cur_seq[$i][1];
        last;
      }
    }
  }
  # calibrate the current timing sequence
  for (my $i=0;$i<scalar(@cur_seq);$i++){
    $cur_seq[$i][1] = $cur_seq[$i][1] + $offset;
    push(@timing_seq, [@{$cur_seq[$i]}]);
  }
  return (\@timing_seq,\@row_list);
}

#sub get_next_clock_edge
#{
#  my ($delay,$num,$period) = @_;
#  my $cyc = $num;
#  my $ret_val = 0;
#  $cyc =~ s/^(p|n)//;
#  if ($num =~ /^p/) {
#    my $esl_time = $delay%($period);
#    my $next_time = $period - $esl_time;
#    $ret_val = $next_time + (int($cyc) - 1)*$period;
#  }else{
#    my $esl_time = ($delay+$period/2)%($period);
#    my $next_time = $period - $esl_time;
#    $ret_val = $next_time + (int($cyc) - 1)*$period;
#  }
#  return $ret_val;
#}
#
sub get_time_constr{
  my ($fvar,$lvar,@inseq)=@_;
  for (my $i=0;$i<scalar(@inseq);$i++){
    if(($fvar eq $inseq[$i][2]) && ($lvar eq $inseq[$i][3])){
      return ($inseq[$i][4],$inseq[$i][1]);
    }
  }
}

sub find_timing_sequence{
  my ($reftbl_,$seq_list_)=@_;
  my @reftbl=@$reftbl_;
  my @seq_list =@$seq_list_;
  my @out=();
  my $cont=0;
  for(my $i=0;$i<scalar(@seq_list);$i++){
    my $find=0;
    my @tmp=();
    my $row=0;
    for(my $l=0;$l<scalar(@reftbl);$l++){
      if($reftbl[$l][2] eq $seq_list[$i][scalar(@{$seq_list[$i]})-1]){
        for (my $k=0;$k<scalar(@{$seq_list[$i]});$k++){
          $tmp[$row][$k]=$seq_list[$i][$k];
        }
        $cont=1;
        $find=1;
        if(grep(/^\Q$reftbl[$l][3]\E$/,@{$seq_list[$i]})>0){
          printf("ERROR ::: [Constraint] Loop in input timing sequence.\n");
          exit(3);
        }else{
          $tmp[scalar(@tmp)-1][scalar(@{$tmp[scalar(@tmp)-1]})] = $reftbl[$l][3];
        }
        $row++;
      }
    }
    if($find==0){
      push(@out,$seq_list[$i]);
    }else{
      for (my $k=0;$k<scalar(@tmp);$k++){
        push(@out,$tmp[$k]);
      }
    }
  }
  return ($cont,@out);
}
sub MakeAllPatTable{ ## [0] Port Table
  my @ptb=@_; 
  my @table=();
  $table[0][0]="Sheet";
  $table[0][1]="line";
  $table[1][0]="name";
  $table[1][1]="number";
  $table[2][0]="AutoGen";
  $table[2][1]="-";
  my $col=2;
  my $total_inout=0;
  # Process for input/output port first
  for(my $j=0;$j<scalar(@{$ptb[0]});$j++){
    if(($ptb[1][$j] eq "input")||($ptb[1][$j] eq "output")){
      $table[0][$col]=$ptb[1][$j];
      $table[1][$col]=$ptb[0][$j];
      $table[2][$col]="*";
      $col++;
    }else{
      next;
    }
  }
  my $total_row = scalar(@table);
  my $total_col = scalar(@{$table[0]});
  my $cnt=0;
  for(my $j=0;$j<scalar(@{$ptb[0]});$j++){
    if($ptb[1][$j] eq "inout"){
      $table[0][$col]=$ptb[1][$j];
      $table[1][$col]=$ptb[0][$j];
      # Process for inout port by duplicated table
      $total_row = scalar(@table);
      if ($ptb[9][$j] eq "-1" || $ptb[11][$j] ne "-"){
        my $row=($total_row-2)*2-1+2;
        for(my $i=($total_row-1);$i>=2;$i--){
          for(my $tmp_col=0;$tmp_col<$total_col+$cnt;$tmp_col++){
            $table[$row][$tmp_col]=$table[$i][$tmp_col];
            $table[$row-1][$tmp_col]=$table[$i][$tmp_col];
            $table[$row][$col]="_*";
            $table[$row-1][$col]="*";
          }
          $row-=2;
        }
      }else{
        for(my $i=($total_row-1);$i>=2;$i--){
          $table[$i][$col]=$table[$i][$col-1];
        }
      }
      $cnt++;
      $total_inout++;
      $col++;
    }
  }

#  for(my $j=0;$j<scalar(@{$ptb[0]});$j++){ #check -all pattern , FB sginal
#    if($ptb[18][$j] =~ /FB/){
#      $table[0][$col]="FB";
#      $table[1][$col]="";
#      for(my $j=2;$j<scalar(@table);$j++){
#        $table[$j][$col]="*";
#      }
#      last;
#    }
#  }
  return @table;
}

sub MakeTruthTable{ ## [0]:Excel file path [1]:pcheck
  my $table_name = $_[1];
  my $pcheck=$_[2];
  my $pg=$_[3];
  my $refvar=$_[6];
  my $blank_error = $_[7];
  my $clock_info_=$_[8];
  my ($aa,@mtt)=make_truth_tbl($_[0],$table_name,$pcheck,$pg,$_[5],$_[4],$refvar,$blank_error,$clock_info_,""); # $aa : number of other sheet includes
  while($aa ne ""){
    ($aa,@mtt)=fusion_tbl($_[0],$aa,$pcheck,$pg,$_[4],\@mtt,$_[5],$blank_error,$clock_info_);
  }
  if ($table_name eq "Table0" || $table_name eq "Table_rnm"){
    # check port in Port table is not used in Truth Table;
    my @dup_check = ();
    for (my $j=0;$j<scalar(@{$_[5][0]});$j++){
      if ((${$_[5]}[1][$j] eq "input" && ${$_[5]}[18][$j] !~/FB/)|| ${$_[5]}[1][$j] eq "output" || ${$_[5]}[1][$j] eq "inout"){
        if (grep (/^${$_[5]}[10][$j](\[\d+\])?$/i, @{$mtt[1]}) < 1 && grep (/^\Q${$_[5]}[10][$j]\E$/,@dup_check) < 1){
          printf("WARNING ::: [Port info] Defined %s port %s is not used in truth table.\n",${$_[5]}[1][$j],${$_[5]}[10][$j]);
          push(@dup_check, ${$_[5]}[10][$j]);
        }
      }
    }
  }
  return(@mtt);
}

sub CheckTableValid{ ## [0]:truth table [1]:port table [2]: -rnm option 
  my ($tt, $pt, $pr)=@_;
  my @table=@$tt;
  my @port=@$pt;
  my @port_ref = @$pr;
  for(my $i=2;$i<scalar(@table);$i++){
    for(my $j=2;$j<scalar(@{$table[1]});$j++){
      if (defined $table[1][$j] && $table[1][$j] ne ""){
        if ($table[0][$j] !~ /input|output|inout/){ # not input/output/inout will not be checked
          next;
        }
        # check value
        $table[$i][$j] =~ s/\s//g;
        my $expr = $table[$i][$j];
        my $prefix = "";
        if ($expr =~ /^_/ || $expr =~ /^\/$/){
          $prefix = "_" if ($table[0][$j] eq "inout");
          $expr =~ s/^\/$/\*/;
          $expr =~ s/^_*//;
        }
        my $tmp_exp = $expr;
        if ($tmp_exp =~ /^b/){ # value of port must be valid value or 'bx or 'bz
          if ($table[$i][$j] !~ /^b((0|1)+|x+|z+)$/i){
            print("ERROR ::: Invalid port $table[1][$j] value \"$table[$i][$j]\" at $table[$i][0]/line $table[$i][1]\n");
            exit(3);
          }else{
            $tmp_exp =~ s/^b//;
            $table[$i][$j] = $prefix.bin2dec($tmp_exp) if ($table[$i][$j] =~ /^b(0|1)+$/i);
            $table[$i][$j] = $prefix."x" if ($table[$i][$j] =~ /^?bx+$/i);
            $table[$i][$j] = $prefix."z" if ($table[$i][$j] =~ /^bz+$/i);
            next;
          }
        }
        $tmp_exp =~ s/#/\(/g;
        $tmp_exp =~ s/\$/\)/g;
        if ($tmp_exp =~ /^(\d|\W)+$/){ # expression is all number and operator
          $table[$i][$j] = $prefix.$tmp_exp if ($table[$i][$j] =~ /^\/$/);
          next if ($table[$i][$j]=~/^_?(0|1|x|z|-|\*|\/)$/);
          my $val = eval($tmp_exp);
          my $port_width = 1;
          if($tmp_exp =~ /~/){
            for(my $k=0;$k<scalar(@{$port[10]});$k++)
            {
              if($table[1][$j] eq $port[10][$k]){
#                if($port[11][$k] =~ /\d/){ #cov
#                    $port_width = (split(/;/, $port[11][$k]))[1]+1;
#                }
              }
            }
            $val = $val & $port_width;
          }
          if (defined $val && $val ne ""){
            $table[$i][$j] = $prefix.$val; 
            if ($port_ref[2][$j] == 1){ # check value of real port
              my ($min,$max,$def_step)=split(",",$port_ref[6][$j]);
              print("WARNING ::: Port value \"$table[$i][$j]\" of real port $table[1][$j] at $table[$i][0]/line $table[$i][1] is out of range ($min,$max).\n") if ($val < $min || $val > $max);
            }
            if ($port_ref[3][$j] ne "1" && $port_ref[2][$j] == 0 && ($val !~ /^(0|1)$/)){ # osci port or real port will not be checked
              print("ERROR ::: Invalid port $table[1][$j] value \"$table[$i][$j]\" at $table[$i][0]/line $table[$i][1]\n");
              exit(3);
            }
          }else{
            printf("ERROR ::: Invalid expression \"%s\" at Table %s/line %s.\n",$expr,$table[$i][0],$table[$i][1]);
            exit(3);
          }
        }else{
          check_expr_valid($tmp_exp, $table[$i][0],$table[$i][1],0);
          if ($port_ref[2][$j] == 1 && $tmp_exp =~ /^EXP_NOT_/){ # real port do not support !@ (@=0/1/x/z) expression
            my $val = $tmp_exp;
            $val =~ s/^EXP_NOT_//;
            $val =~ s/_.*$//;
            print("ERROR ::: Expression [!$val] is not support for real port at $table[$i][0]/line $table[$i][1].\n");
            exit(3);
          }
          if ($port_ref[2][$j] == 1 && $tmp_exp =~ /^ramp\(\d*.?\d+,\d*.?\d+,\d*.?\d+\)$/){ # check value of real port
            my ($min,$max,$def_step)=split(",",$port_ref[6][$j]);
            my ($chk_min,$chk_max,$chk_def_step)=split(",",$tmp_exp);
            $chk_min =~ s/^.*\(//;
            $def_step=~ s/\).*$//;
            print("WARNING ::: Ramp wave \"$table[$i][$j]\" of real port $table[1][$j] at $table[$i][0]/line $table[$i][1] is out of range ($min,$max).\n") if (!($chk_min >= $min && $chk_min <= $max && $chk_max >= $min && $chk_max <= $max));
          }
          # replace real port name "<port>" in expression to "<port>.r"
          $tmp_exp = $expr;
          for (my $j=0;$j<scalar(@{$port_ref[0]});$j++){
            if ($port_ref[1][$j] ne "-1"){
              $tmp_exp =~ s/\b\Q$port_ref[0][$j]\E/$port_ref[7][$j]/g if ($port_ref[0][$j] =~ /^\w+\[\d+\]$/);
              $tmp_exp =~ s/\b\Q$port_ref[0][$j]\E\b/$port_ref[7][$j]/g if ($port_ref[0][$j] =~ /^\w+$/);
            }
          }
          $table[$i][$j] = $prefix.$tmp_exp; 
        }
      }
    }
  }
  return @table;
}

sub ProcessLatchCheck{
  my ($tt, $pt, $pr, $rnm,$blank_error,$clock_info_,$lfo)=@_;
  my @table = @$tt;
  my @table_temp = ();
  my @out = ();
  my @hold_pattern = ();
  @{$out[0]} = @{$table[0]};
  @{$out[1]} = @{$table[1]};
  @{$out[2]} = @{$table[2]};
  @{$out[3]} = @{$table[3]};
  @{$hold_pattern[0]} = @{$table[0]};
  @{$hold_pattern[1]} = @{$table[2]};
  @{$table_temp[0]} = @{$table[0]};
  @{$table_temp[1]} = @{$table[2]};
  for (my $i = 4; $i < scalar(@table);$i++) {
    @{$table_temp[$i-2]} = @{$table[$i]};
  }
  $hold_pattern[0][1] = "index";
  my $hold_index = 0;
  my $hold_pattern_index = 2;
  my $latch_port = get_latch_port(@$pt);
  my %latch_pat_row;
  my $is_mode_check = 0;
  my $force_check=0;
  for (my $j = 2; $j < scalar(@{$table[0]});$j++) {
    if ($table[0][$j] eq "Mode") {
      $is_mode_check = 1;
      last;
    }
  }
  for (my $i = 4; $i < scalar(@table);$i++) {
    @{$out[$i]} = @{$table[$i]};
    if (grep(/^_?HOLD$|^_?STRONG_HOLD$/,@{$table[$i]})>0) {
      for(my $j=2;$j<scalar(@{$table[$i]});$j++){
        if($table[$i][$j] =~ /^_?STRONG_HOLD$/ && $lfo eq "0"){
          print("WARNING ::: \"STRONG_HOLD\" keyword is defined without \"-lfo\" option. Erakis consider \"STRONG_HOLD\" as the same as \"HOLD\" keyword.\n");
          $out[$i][$j] =~ s/STRONG_HOLD/HOLD/g;
        }
      }
      if ($is_mode_check == 1) {
        print("ERROR ::: \"HOLD/STRONG_HOLD\" keyword and \"Mode\" column should not be used at the same time.\n");
        exit(3);
      }
      $hold_index += 1;
      if (grep(/STRONG_HOLD/,@{$out[$i]})>0) {
          $out[$i][1] = "ERKS_STRONG_HOLD"."_$out[$i][1]";
      }else{
          $out[$i][1] = "ERKS_HOLD"."_$out[$i][1]";
      }
      @{$hold_pattern[$hold_pattern_index]} = @{$out[$i]};
      $hold_pattern[$hold_pattern_index][1] = $hold_index;
      my ($ref_check, $ret_var, @rep_line)=&get_ref_line($hold_pattern[0],$hold_pattern[1],$hold_pattern[$hold_pattern_index],\@table_temp,"",$latch_port,"",$pt,$rnm,$blank_error,$clock_info_,1);
      $latch_pat_row{"$hold_index"} = (); 
      for (my $j = 2; $j < scalar(@rep_line); $j++) {
        push (@{$latch_pat_row{"$hold_index"}},$rep_line[$j][1]);
      }
      $hold_pattern_index += 1;
      $force_check = 1;
    }
  }
  foreach my $key (keys %latch_pat_row) {
    for (my $i = 4; $i < scalar(@out);$i++) {
      foreach my $line_index (@{$latch_pat_row{$key}}) {
        if ($line_index eq $out[$i][1]) {
          $out[$i][1] = "ERKS_SUBHOLD"."_$out[$i][1]";
          last;
        }
      }
    }
  }
  
  # Check force test pattern
  if($lfo eq "1"){
    check_force_pattern(\@out,\@hold_pattern);
  }
  return @out;
}

sub check_force_pattern{
  my ($tbl,$hold_ptn)=@_;
  my @table = @$tbl;
  my @hold_pattern = @$hold_ptn; 
  my $skip_line=0;
  ## Get port at HOLD keyword
  my $hold_port=0;
  if(scalar(@hold_pattern) > 2){
    for(my $i=0;$i<scalar(@{$hold_pattern[2]});$i++){
      if($hold_pattern[2][$i] =~ /^_?HOLD|^_?STRONG_HOLD/){
        $hold_port = $i;
      }
    }
    for(my $i=4;$i<scalar(@table);$i++){
      $skip_line = 0;
      if(grep(/HOLD/,@{$table[$i]})<1){
        for(my $j=2;$j<scalar(@{$table[0]});$j++){
          if($table[$i][$j] ne $hold_pattern[2][$j] && $skip_line==0){
            if($table[0][$j] eq "inout"){
              if($table[$i][$hold_port] !~ /^_/){
                $skip_line =1;;
              }
            }
          }
        }
        if($skip_line == 0){
          $table[$i][1] = "FORCE".$i;
        }
      }
    }
  }
}


sub SortTruthTable{
  my ($tbl_,$tm_seq_,$ptbl_)=@_;
  my @table=@$tbl_;
  my @timing_seq=@$tm_seq_;
  my @ptbl=@$ptbl_;
  my @out=();
  my $row=0;
  my $col=0;
  my @sorted_table=();
  my @port_list=();
  my @delay_list=();
  # mapping the timing sequence into the time line
  my $cur_time=0;
  for (my $i=0;$i<scalar(@timing_seq);$i++){
    push(@port_list,$timing_seq[$i][0]);
    if($timing_seq[$i][1] != 0 and $timing_seq[$i][0] !~ /^ERKS(RISE|FALL)_/){
      push(@delay_list,$timing_seq[$i][1] - $cur_time);
      $cur_time = $timing_seq[$i][1];
    }else{
      push(@delay_list,"-");
    }
  }
  #move all untiming into the left
  for (my $j=0;$j<scalar(@{$table[0]});$j++){
    my $find=0;
    if ($table[0][$j] =~ /action|message|disable|control|assert_control|control_n|assert_control_n/ ){
      next;
    }
    for (my $k=0;$k<scalar(@port_list);$k++){
      if (&cmp_port_name($table[2][$j],$port_list[$k])==1 && $delay_list[$k] ne "-"){
        $find=1;
        last;
      }
    }
    if($find==0){
      for (my $i=0;$i<scalar(@table);$i++){
        $out[$i][$col]=$table[$i][$j];
      }
      $col++;
    }
  }
  # get column as timing sequence
  my @dup_list=();
  for (my $k=0;$k<scalar(@port_list);$k++){
    for (my $j=0;$j<scalar(@{$table[0]});$j++){
      if ($table[0][$j] =~ /action|message|disable|control|assert_control|control_n|assert_control_n/ ){
        next;
      }
      if (&cmp_port_name($table[2][$j],$port_list[$k])==1 && $delay_list[$k] ne "-"){
        for (my $i=0;$i<scalar(@table);$i++){
          if (($i==4) &&(grep(/^\Q$port_list[$k]\E$/,@dup_list)<1)){ # insert delay time
            push(@dup_list,$port_list[$k]);
            $out[$i][$col]=$delay_list[$k];
          }else{
            $out[$i][$col]=$table[$i][$j];
          }
        }
        $col++;
      }
    }
  }
  # get remain column
  for (my $j=0;$j<scalar(@{$table[0]});$j++){
    if ($table[0][$j] =~ /action|message|disable|control|assert_control|control_n|assert_control_n/){
      for (my $i=0;$i<scalar(@table);$i++){
        $out[$i][$col]=$table[$i][$j];
      }
      $col++;
    }
  }

  return(@out);
}

sub SeparateMultiPortWidth{ ## [0]:Truth table
  my ($tbl_,$ptb_,$rnm)=@_;
  my @tbl= @$tbl_;
  my @port_ref = GetPortRefTable($tbl[1],\@tbl,$ptb_,$rnm);
  my @table=(); 
  my $sep_col = 0;
  for (my $i=0;$i<scalar(@tbl);$i++){
    $sep_col = 0;
    for (my $j=0;$j<scalar(@{$tbl[$i]});$j++){
      $table[$i][$sep_col] = $tbl[$i][$j];
      if(!(defined $tbl[1][$j])){
        next;
      }
      if($tbl[1][$j] =~ /^[a-zA-Z_0-9]+[[0-9]+:[0-9]+]$/){
        my @port_split = split(/:/,$tbl[1][$j]);
        my $port_name = (split(/\[/,$port_split[0]))[0]; # Get port name
        my $msb = (split(/\[/,$port_split[0]))[1]; # Get MSB
        my $lsb = (split(/\]/,$port_split[1]))[0]; # Get LSB
        my $bw  = int($msb)-int($lsb)+1; # Get bit width
        my @port_val = ();
        if ($i > 1){ # not table name 
          @port_val  = &str2listval($tbl[$i][$j],$bw,$port_ref[2][$j]); # Get port value list follow the bitwidth
        }
        for (my $k = $msb; $k >= $lsb;$k--) {
          $table[0][$sep_col] = $tbl[0][$j];
          if ($i == 1){ # table name 
            $table[$i][$sep_col] = $port_name."[$k]";
          } elsif ($i > 1) {
            $table[$i][$sep_col] = $port_val[$k-$lsb];
          }
          $sep_col++;
        }
      } else {
        $sep_col++;
      }
    }
  }
  return @table;
}

sub SeparateTruthTable{ ## [0]: -rnm option [1]:Truth table
  my ($rnm,@tt) = @_;
  my @separated_tt_list=();
  my @pre_string=();
  my @io_locate = ();
  my $cont = 0; 
  my @split_table = @tt;
  my @dup_check = ();
  for(my $i = 2; $i<scalar(@{$split_table[0]}); $i++){
    if ($split_table[0][$i] eq "inout"){
      my $port_name = $split_table[2][$i];
      $port_name =~ s/\[.*//;
      if (grep (/^$port_name$/,@dup_check)<1){
        $io_locate[scalar(@io_locate)]= $i;
        push(@dup_check,$port_name);
      }
    }
  }
  my $num_level = scalar(@io_locate);
  my $num_tables = 1 << $num_level;
  for(my $i = 0; $i < $num_tables; $i++){
    my @tmp_tt = ();
    foreach my $tmp (@split_table) {
      push (@tmp_tt, [@$tmp]);
    }
    for (my $k = 0; $k < $num_level; $k++){
      $tmp_tt[0][$io_locate[$k]] = ($i % (1<<($k+1)) < (1<<$k))?"output" : "input";
    }
    my @update_io_locate = @io_locate; # for multiple bitwidth inout port
    for (my $j = 2; $j < scalar(@{$tmp_tt[0]}); $j++){ # for multiple bitwidth inout port
      if ($tmp_tt[0][$j] eq "inout"){
        for (my $k = 2; $k < scalar(@{$tmp_tt[0]}); $k++){
          if (cmp_port_name($tmp_tt[2][$k], $tmp_tt[2][$j]) eq "1" && $j ne $k && $tmp_tt[0][$k] ne "inout"){
            $tmp_tt[0][$j] = $tmp_tt[0][$k];
            push (@update_io_locate,$j);
            last;
          }
        }
      }
    }
    @tmp_tt = FiltInOutLine(\@tmp_tt, \@update_io_locate);
    @{$separated_tt_list[$i]} = @tmp_tt;
  }
  return @separated_tt_list;
}

sub FiltInOutLine{# [1] temp table, [2] io locate
  my ($tt, $io) = @_;
  my @table = @$tt;
  my @io_locate = @$io;
  my @new_tt = @table[0..3];
  for (my $i = 4; $i < scalar(@table); $i++){
    my $check_ok = 1;
    for (my $k = 0; $k < scalar(@io_locate); $k++){
      if (($table[0][$io_locate[$k]] =~ /^(input|electrical_in)$/) && ($table[$i][$io_locate[$k]] !~ /^_/) && ($table[$i][$io_locate[$k]] !~ /^\/$/)){
      }elsif (($table[0][$io_locate[$k]] =~ /^(output|electrical_out)$/) && ($table[$i][$io_locate[$k]] =~ /^_/ || ($table[$i][$io_locate[$k]] =~ /^\/$/))){
        $table[$i][$io_locate[$k]] =~s/^_//;
        $table[$i][$io_locate[$k]] =~s/^\/$/*/ if ($table[$i][$io_locate[$k]] =~ /^\/$/);
      }else{
        $check_ok = 0;
        last;
      }
    }
    if ($check_ok){
      push(@new_tt, $table[$i]);
    }
  }
  return @new_tt;
}

sub PcheckPU{ ## [0]:truth table
  my @out=();
  my $col=0;
  my $row=4;
  my $pcheck=0;

  for(my $i=0;$i<scalar(@{$_[0]});$i++){
    if($_[0][$i] eq "pcheck"){
      $pcheck=$i;
    }else{
      $out[0][$col]=$_[0][$i];
      $out[1][$col]=$_[1][$i];
      $out[2][$col]=$_[2][$i];
      $out[3][$col]=$_[3][$i];
      $col++
    }
  }
  $col=0;
  for(my $i=4;$i<scalar(@_);$i++){
    if($_[$i][$pcheck] eq "1"){
      for(my $j=0;$j<scalar(@{$_[$i]});$j++){
        if($j != $pcheck){
          $out[$row][$col]=$_[$i][$j];
          $col++;
        }
      }
      $row++;
      $col=0;
    }
  }
  return(@out);
}

sub PGExtract{ ## [0]:truth table [1]:port table [2]:pg [3]:pcheck
  my($t, $p, $pg, $pcheck)=@_; # reference
  my @table=@$t;
  my @port=@$p;
  my @out=(); ## [0]:in/out [1]:care_range [2]:Pin name [3]:SA [4]-:val
  my $col=2;
  my $row=4;
  my $check=0;
  $out[0][0]="Sheet";
  $out[0][1]="line";
  $out[1][0]="-";
  $out[1][1]="-";
  $out[2][0]="-";
  $out[2][1]="-";
  $out[3][0]="-";
  $out[3][1]="-";
  for(my $i=2;$i<scalar(@{$table[1]});$i++){
      for(my $j=0;$j<scalar(@{$port[0]});$j++){
        if((defined $table[0][$i]) && ($table[0][$i] eq "pcheck")){
          if($pcheck==1){
              $out[0][$col]="pcheck";
              $out[1][$col]="ast_care_range";
              $out[2][$col]="port";
              $out[3][$col]="SA";
              $col++;
          }
          $check=1;
          last;
        }elsif((defined $table[1][$i]) && ($table[1][$i] eq $port[0][$j]) && $table[0][$i] ne "high pulse width"){
          $check=1;
          if($pg==1 || ($pg==0 && $port[1][$j] !~ /power|ground/)){
              $out[0][$col]=$port[1][$j]; # in/out
              $out[1][$col]=$port[5][$j]; # Valid range of ast
              $out[2][$col]=$table[1][$i]; # Pin name
              $out[3][$col]=$port[4][$j]; # SA
              $col++;
          }
          last;
        }
    }
    if($table[0][$i] =~ /action|message|Mode|reg|string_reg|high pulse width|FB|disable|control|assert_control|control_n|assert_control_n/){
        $check=1;
        $out[0][$col]=$table[0][$i];
        $out[1][$col]="-";
        $out[2][$col]=$table[1][$i];
        $out[3][$col]="-"; 
        $col++;
    }
    if($check==0){
        print("ERROR ::: Port info and truth table's port name differ: $table[1][$i]\n");
        exit(3);
    }else{
        $check=0;
    }
  }
  $check=0;
  if($pg==1 && $pcheck==1){
    for(my $i=2;$i<scalar(@table);$i++){
      $col=0;
      for(my $j=0;$j<scalar(@{$table[$i]});$j++){
        $out[$row][$col]=$table[$i][$j];
        $col++;
      }
      $row++;
    }
  }elsif($pg==1){
    for(my $i=2;$i<scalar(@table);$i++){
      $col=0;
      for(my $j=0;$j<scalar(@{$table[$i]});$j++){
        if($table[0][$j] ne "pcheck"){
          $out[$row][$col]=$table[$i][$j];
          $col++;
        }
      }
      $row++;
    }
  }elsif($pg==0 && $pcheck==1){
    for(my $i=2;$i<scalar(@table);$i++){
      $col=0;
      $check=OnPower(\@{$table[0]},\@{$table[1]},\@{$table[$i]});
      if($check==1){
        for(my $j=0;$j<scalar(@{$table[$i]});$j++){
          if($table[0][$j] !~ /power|ground/){
            $out[$row][$col]=$table[$i][$j];
            $col++;
          }
        }
        $row++;
      }else{
        next;
      }
    }
  }elsif($pg==0){
    for(my $i=2;$i<scalar(@table);$i++){
      $col=0;
      $check=OnPower(\@{$table[0]},\@{$table[1]},\@{$table[$i]});
      if($check==1){
        for(my $j=0;$j<scalar(@{$table[$i]});$j++){
          if($table[0][$j] !~ /power|ground/ && $table[0][$j] ne "pcheck"){
            $out[$row][$col]=$table[$i][$j];
            $col++;
          }
        }
        $row++;
      }else{
        next;
      }
    }
  }
  return(@out);
}

sub OnPower{
  my ($a, $b, $c)=@_;
  my @io=@$a;
  my @port=@$b;
  my @inp=@$c;
  my $po=0;
  my $max=0;
  
  for(my $i=0;$i<scalar(@io);$i++){
    if($io[$i] =~ /power|ground/){
      $max++;
    }
  }
  for(my $i=0;$i<scalar(@io);$i++){
    if($io[$i] eq "power" && ($inp[$i] eq "1" || $inp[$i]eq "\*")){
      $po++;
    }elsif($io[$i] eq "ground" && ($inp[$i]eq "0" || $inp[$i]eq "\*")){
      $po++;
    }
  }
  if($max==$po){
    return(1);
  }else{
    return(0);
  }
}

### include excel sheet ###
sub make_truth_tbl{ # [0]excel book [1]sheet name [2] pcheck [3] -pg option [4] port table [5] option -rnm [6] parse for reference table [7] blank_error// return table
  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$parser->parse($_[0]) or die "ERROR ::: $_[0] is not found.\n";
  my $worksheet=$workbook->worksheet($_[1]) or die "ERROR ::: \"$_[1]\" is not found in \"$_[0]\".\n";
  my $pg = $_[3];
  my @port_table = @{$_[4]};
  my $rnm =$_[5];
  my $ref_var=$_[6];
  my $blank_error=$_[7];
  my @clock_info = @{$_[8]};
  my @rfseq = @{$clock_info[3]};
  my $assert_ctrl = $_[9];
  my @table=();
  my $out="";
  my $row=2;
  my $col=2;
  my $des_row = -1;
  my $msg_find=0;
  my $fb=0;
  my @dup_check = ();
  my $valid_row=0;
  my $assert_ctrl_chk=0;
  my $ctrl_chk=0;
  my ($row_min, $row_max)=$worksheet->row_range();
  my ($col_min, $col_max)=$worksheet->col_range();
  my @ignored_row_list=get_ignored_row_list($worksheet);
  for (my $i=$row_min;$i<$row_max+1;$i++){
    $col=2;
    next if (grep(/^$i$/, @ignored_row_list)>0);
    if(!(defined $table[0][0]) || $table[0][0]eq""){  # inout type
      if($ref_var ne ""){ # Parse reference table
        for (my $j=$col_min;$j<$col_max+1;$j++){
          my $cell=&get_cell_val($i,$j,$worksheet);
          if(!(defined $cell) || $cell eq ""){
            next;
          }elsif($cell =~ /^#/){
            last;
          }else{
            $des_row = $i;
            if ($cell eq $ref_var){
              $table[0][$col]="ref_port";
              $table[1][$col]=$cell;
            }else{
              my $port_name = get_port_name($_[1],$cell,\@port_table,\@dup_check,$des_row,$j);
              if ($port_name eq -1){
                printf("ERROR ::: [$_[1]] Invalid port name \"%s\" at %s.\n",$cell, &get_cell_pos($des_row+1,$j));
                exit(3);
              }
              $table[0][$col]=&get_port_type($cell,@port_table);
              $table[1][$col]=$port_name;
            }
            $col++;
          }
        }
        if($des_row!=-1){
          $table[0][0]="Sheet";
          $table[0][1]="line";
          $table[1][0]="$_[1]";
          $table[1][1]="number";
        }
        next;
      }
      my $mp=0;
      my $sup=0;
      my $inp=0;
      my $oup=0;
      my $iop=0;
      my $pc=0;
      for (my $j=$col_min;$j<$col_max+1;$j++){
        my $cell=&get_cell_val($i,$j,$worksheet);
        if(!(defined $cell) || $cell eq ""){
          if (defined $table[0][$col-1] && $table[0][$col-1] eq "action"){
            $table[0][$col]="action";
            $des_row = $i;
          }else{
            if ($des_row != -1){
              $table[0][$col]="";
              $des_row = $i;
            }else{
              next;
            }
          }
        }elsif($cell =~ /^#/){
          last;
        }elsif($cell =~ /supply|power|ground/i){
          $table[0][$col]="supply";
          $sup++;
          $des_row = $i;
        }elsif($cell =~ /input/i){
          $valid_row = $i;
          $table[0][$col]="input";
          $inp++;
          $des_row = $i;
        }elsif($cell =~ /mode/i){
          $table[0][$col]="Mode";
          $mp++;
          $des_row = $i;
        }elsif($cell =~ /output/i){
          $valid_row = $i;
          $table[0][$col]="output";
          $oup++;
          $des_row = $i;
        }elsif($cell =~ /inout/i){
          $valid_row = $i;
          $table[0][$col]="inout";
          $iop++;
          $des_row = $i;
        }elsif($cell =~ /action/i){
          $table[0][$col]="action";
          $des_row = $i;
        }elsif($cell =~ /message/i){
          $table[0][$col]="message";
          $des_row = $i;
          if($msg_find==1){
            print("WARNING ::: [$_[1]] Duplicate message column, message check may be incorrect.\n");
          }else{
            $msg_find=1;
          }
        }elsif($cell =~ /pcheck/){
          $des_row = $i;
          $table[0][$col]="pcheck";
          $pc++;
        }elsif($cell =~ /^[Rr][Ee][Gg]/){   ## reg colum in truth table
          $table[0][$col]="reg";
          $des_row = $i;
        }elsif($cell =~ /^[Ss][Tt][Rr][Ii][Nn][Gg]_[Rr][Ee][Gg]/){   ## reg colum in truth table
          $table[0][$col]="string_reg";
          $des_row = $i;
        }elsif($cell =~ /high pulse width/){ ## high pulse width of clock port in truth table
           $table[0][$col]="high pulse width";
        }elsif($cell =~ /FB/){
            if($fb > 0){
                printf("ERROR ::: [$_[1]] More than one FB column are defined. Truth table only supports one FB loop.\n");
                exit(3);
            }
           $table[0][$col]="FB";
           $des_row = $i;
           $fb++;
        }elsif($cell =~ /^disable/){
           $table[0][$col]="disable";
           $des_row = $i;
        }elsif($cell =~ /^control$/){
           $table[0][$col]="control";
           $des_row = $i;
        }elsif($cell =~ /^control_n$/){
           $table[0][$col]="control_n";
           $des_row = $i;
        }elsif($cell =~ /^\*\*\*/){
        }elsif($cell =~ /^assert_control$/){
            $table[0][$col]="assert_control";
            $des_row = $i;
        }elsif($cell =~ /^assert_control_n$/){
            $table[0][$col]="assert_control_n";
            $des_row = $i;
        }else{
          printf("ERROR ::: [$_[1]] Invalid port i/o description \"%s\" in %s.\n",$cell, &get_cell_pos($i,$j));
          exit(3);
        }
        $col++;
      }
      if ($des_row!=-1){
        $table[0][0]="Sheet";
        $table[0][1]="line";
      }
      if(($_[1] eq "Table0" || $_[1] eq "Table_rnm") && $sup==0 && $pg == 1){
        print("ERROR ::: No supply column in $_[0] - $_[1].\n");
        exit(1);
      }elsif($_[2] == 1 && $pc==0){
        print("ERROR ::: When you use OPTION -p, truth table needs \"pcheck\" column.\nfile : $_[0] - $_[1].\n");
        exit(1);
      }
    }elsif(!(defined $table[1][0]) || $table[1][0]eq ""){  # port name
      $table[1][0]="$_[1]";
      $table[1][1]="number";
      for (my $j=$col_min;$j<$col_max+1;$j++){
        my $cell=&get_cell_val($i,$j,$worksheet);
        my $cell_first_line = &get_cell_val($valid_row,$j,$worksheet);
        if($cell eq "" && $cell_first_line eq ""){
            next;
        }
#        if($cell eq "-"){
#            my $cell_line_before = &get_cell_val($i-1,$j,$worksheet);
#            if($cell_line_before =~ /pcheck/){
#                next;
#            }
#        }
        if (defined $table[0][$col] && ($table[0][$col] =~ /pcheck|message|Mode|FB|disable|control|assert_control|control_n|assert_control_n/)){
          $table[1][$col]="";
        }elsif(!defined $table[0][$col] || !defined $cell || $cell eq ""){
          if(defined $table[0][$col]){
            if($table[0][$col] eq "high pulse width"){
              printf("ERROR ::: [$_[1]] Please specify clock port name at %s.\n", &get_cell_pos($des_row+1,$j));
              exit(1);
            }
          }
          next;
        }else{
          $table[1][$col]=$cell;
          if ($table[0][$col] !~ /action|Mode|high pulse width|disable|control|pcheck|assert_control|control_n|assert_control_n/){
            my $port_name = get_port_name($_[1],$table[1][$col],\@port_table,\@dup_check,$des_row+1,$j);
            my $port_type = get_port_type($table[1][$col],@port_table);
            if ($port_name eq -1 && $port_type eq "" && ($table[0][$col-1] eq "reg"|| $table[0][$col] eq "reg" || $table[0][$col-1] eq "string_reg"|| $table[0][$col] eq "string_reg")){
                $port_name = $cell;
                $port_type = $table[0][$col];
            } 
            if ($port_name eq -1){
              printf("ERROR ::: [$_[1]] Invalid port name \"%s\" at %s.\n",$table[1][$col], &get_cell_pos($des_row+1,$j));
              exit(3);
            }
            $port_type = "input" if $port_type eq "clock";
            if($table[0][$col] ne "" && (($table[0][$col] ne "supply" && $table[0][$col] ne $port_type) || ($table[0][$col] eq "supply" && $port_type !~ /power|ground/))){
              printf("WARNING ::: [$_[1]] Wrong port type description \"%s\" for %s port %s at %s.\n",$table[0][$col],&get_port_type($table[1][$col],@port_table),$table[1][$col],&get_cell_pos($des_row+1,$j));
            }
            if($port_type eq "reg" || $port_type eq "string_reg"){
              $table[0][$col]=$port_type;
            }else{
              $table[0][$col]=&get_port_type($table[1][$col],@port_table);
            }
            $table[1][$col]=$port_name;
            if(GetFBSignal($table[1][$col], @port_table) && $port_type eq "input"){
                printf("ERROR ::: [$_[1]] The input signal %s of FB loop should be defined by \"FB\" column.\n",$table[1][$col]);
                exit(3);
            }
          }
          if($table[0][$col] eq "high pulse width"){
            my $port_name = get_port_name($_[1],$table[1][$col],\@port_table,\@dup_check,$des_row+1,$j);
            my $port_type = get_port_type($table[1][$col],@port_table);
            if($port_name eq -1 || $port_type ne "clock"){
              printf("ERROR ::: [$_[1]] Invalid port name \"%s\" at %s. Please specify the name of clock port here.\n",$table[1][$col], &get_cell_pos($des_row+1,$j));
              exit(3);
            }
          }
          if($table[0][$col] eq "" &&  $table[0][$col-1] =~ /reg|string_reg/){
              $table[0][$col] = $table[0][$col-1];
          }
        }
        $col++;
      }
    }else{
      my $check=0;
      my $val="";
      my $row_has_data=0;
      for (my $j=$col_min;$j<$col_max+1;$j++){
        my $cell=&get_cell_val($i,$j,$worksheet);
        if(!(defined $cell) || $cell eq ""){
          next;
        }elsif($cell=~ /^\*\*\*/){
          next;
        }else{
          $row_has_data=1;
          if ($cell =~ /^#/){
            last;
          }
        }
      }
      if ($row_has_data==1){
        my @tmp_row = ();
        $tmp_row[0]="$_[1]";
        $tmp_row[1]=$i+1;
        for (my $j=$col_min;$j<$col_max+1;$j++){
          my $cell=&get_cell_val($i,$j,$worksheet);
          if(!(defined $table[0][$col]) || $table[0][$col] eq ""){
            next;
          }
          if ($cell =~ /^#/){
            if($table[0][$col] ne ""){ # "#" inside the table, row will be removed
              $row_has_data = 0;
              last;
            }
          }
          if($table[0][$col] eq "pcheck"){
            $tmp_row[$col]=(!defined($cell)||$cell eq "") ? 0 :
                                 $cell eq "1" ? 1 : 0;
            $col++;
          }else{
            if($cell eq ""){
              if (($table[0][$col] =~ /action|message|disable|control|assert_control|assert_control_n|control_n/)){
                $tmp_row[$col]="-";
              }elsif($table[0][$col] eq "Mode"){
                if ($row > 2 and $table[$row-1][$col] ne "-") {
                  my $mode = $table[$row-1][$col];
                  $mode =~ s/ERKS_SUB_MODE_// if ($mode =~ /^ERKS_SUB_MODE_/);
                  $tmp_row[$col] = "ERKS_SUB_MODE_".$mode;
                }else{
                  $tmp_row[$col] = "-";
                }
              }else{
                if($col != $j){
                    my $in_table_range=0;
                    for(my $temp_row=$row_min;$temp_row<$row_max;$temp_row++){
                      my $cell=&get_cell_val($temp_row,$j,$worksheet);
                      if($cell =~ /action|message|disable|control|string_reg|assert_control|control_n|assert_control_n|input|output|inout|electrical_in|electrical_out|power|ground|FB/i){
                        $in_table_range = 1;
                        last;
                      }
                      for (my $k=0;$k<scalar(@{$port_table[0]});$k++){
                        if (cmp_port_name($cell,$port_table[10][$k]) == 1){
                          $in_table_range = 1;
                          last;
                        }
                      }
                    }
                    if($in_table_range == 0){
#                      $col++;
                      next;
                    }
                }
                if ($row > 2) {
                  $tmp_row[$col]= $table[$row-1][$col];
                  if ($blank_error eq "on") {
                    printf("ERROR ::: [$_[1]] %s is blank.\n",&get_cell_pos($i,$j));
                    exit(3);
                  } else {
                    printf("WARNING ::: [$_[1]] %s is blank. This cell is considered same as upper cell value.\n",&get_cell_pos($i,$j));
                  }
                } else {
                  printf("ERROR ::: [$_[1]] Lack %s value at %s due to no upper cell value to refer.\n",$table[0][$col],&get_cell_pos($i,$j));
                  exit(3);
                }
              }
              $col++;
              next;
            }
            if ($table[0][$col] eq "Mode"){
              $check=1;
              $val = "ERKSMODE_".$cell;
              $tmp_row[2] = 1;
            }elsif($table[0][$col] eq "reg"){
                if( $cell =~ /[0-1]|S|x|z|\*/){
                   $val=$cell;
                }else{
                   printf("ERROR ::: [$_[1]] Invalid value \"$cell\" in \"reg\" column at %s.\n",&get_cell_pos($i,$j));
                   exit(3);
                }
            }elsif ($table[0][$col] !~ /action|message|ref_port|reg|string_reg|FB|disable|control|assert_control|control_n|assert_control_n/ && $table[0][$col] ne ""){
              ($check,$val)=check_tbl_val($_[1],$i,$j,$cell,$rnm,1,0,$table[1][$col],\@port_table,\@clock_info);
                if($cell eq "*"){
                }
              
              my $is_real_port=0;
              if ($rnm == 1){
                for (my $k=0;$k<scalar(@{$port_table[0]});$k++){
                  if (cmp_port_name($table[1][$col],$port_table[10][$k]) == 1){
                    if($port_table[13][$k] ne "-"){ # real port
                      $is_real_port=1;
                    }
                    last;
                  }
                }
              }
              if ($is_real_port == 0 && $cell =~ /ramp/){
                printf("WARNING ::: [$_[1]] Ramp wave at %s is only supported for real port with option -rnm.\n",&get_cell_pos($i,$j));
              }
            }elsif($table[0][$col] eq "FB"){
              if( $cell =~ /^[0-1]|S|[Xx]|[Zz]|\*/){
                 $val=$cell;
              }elsif ($cell =~ /;#\d+/){
                  my $delay = $cell;
                  $delay =~ s/;#//g;
                  if($delay > $clock_info[4]){
                    printf("ERROR ::: [$_[1]] The value \"$cell\" in \"FB\" column at %s should not be larger than max delay time %d.\n",&get_cell_pos($i,$j), $clock_info[4]);
                    exit(3);
                  }
                  $val = $cell;
              }else{
                 printf("ERROR ::: [$_[1]] Invalid value \"$cell\" in \"FB\" column at %s.\n",&get_cell_pos($i,$j));
                 exit(3);
              }
            }elsif($table[0][$col] eq "disable"){
              my $k=0;
              for ($k=0;$k<scalar(@{$port_table[0]});$k++){
                if (cmp_port_name($cell,$port_table[10][$k]) == 1){
                  $val = $cell;
                  last;
                }
              }
              if($k==scalar(@{$port_table[0]})){
                 printf("ERROR ::: [$_[1]] Signal \"$cell\" in \"disable\" column at %s is not defined in Port info sheet.\n",&get_cell_pos($i,$j));
                 exit(3);
              }
            }elsif($table[0][$col] eq "string_reg"){
                $val = $cell;
                $val =~ s/\"//g;
                $check=1;
            }else{
              ($check,$val)=check_tbl_val($_[1],$i,$j,$cell,$rnm,1,1,"",[()],\@clock_info) if ($table[0][$col] =~ /ref_port/);
              $check=1;
              $val=$cell if ($table[0][$col] !~ /ref_port/);
            }
            if($check==0){
              if ($out eq ""){
                $out=$val;
              }
              $tmp_row[$col]=$val;
              $col++;
            }else{
              if($table[0][$col] eq "high pulse width"){
                if(($cell >1 && $clock_info[0] eq "frequency") || $cell =~/^-\d+/){
                  printf("ERROR ::: [$_[1]] Invalid value \"$cell\" in \"high pulse width\" column at %s.\n",&get_cell_pos($i,$j));
                  exit(3);
                }
              }

              $tmp_row[$col]=$val;
              if ($table[0][$col] eq "action" && $tmp_row[$col] ne "-"){
                $tmp_row[$col]=$val." // ".$_[0]." ".$_[1]." ".&get_cell_pos($i,$j);
              }
              if ($table[0][$col] eq "message" && $tmp_row[$col] ne "-"){
                my @port_expr=();
                my $tmp_msg = $tmp_row[$col];
                while ($tmp_msg =~ /\$\{[^}]*\}/) {
                  $tmp_msg =~ s/(\$\{[^}]*\})//;
                  push(@port_expr,$1);
                }
                if (@port_expr!=0){
                  foreach my $expr (@port_expr){
                    $expr =~ s/^\$\{//;
                    $expr =~ s/\}//;
                    $expr =~ s/\s+//;
                    if ($expr !~ /^[^\[\]]+(\[\d+\]|\[\d+:\d+\])?$/) {
                      printf("WARNING ::: [$_[1]] Invalid regular expression \"\${$expr}\" in message at %s.\n",&get_cell_pos($i,$j));
                    } else {
                      my @tmp=();
                      my $found = 0;
                      my $exp = "";
                      if($expr=~/^\w+\[\d+\]$/){ # process single bitwidth port name (multiple bitwidth)
                        ($found, $exp)=found_variable($expr, \@tmp,$port_table[0]);
                      } elsif ($expr=~/^\w+\[\d+:\d+\]$/){ # process multiple bitwidth port name (multiple bitwidth))
                        my @tmp_split = split(/\W+/,(split(/\[/,$expr))[0]);
                        my $port_name = $tmp_split[scalar(@tmp_split)-1];
                        my $port_index = (split(/\[/,$expr))[1];
                        $port_index =~ s/].*$//;
                        my ($max, $min) = split(/:/,$port_index);
                        for (my $i=$min;$i<=$max;$i++){
                          my $tmp_name = $port_name."[".$i."]";
                          my $index = $i - $min;
                          ($found, $exp)=found_variable($tmp_name, \@tmp,$port_table[0]);
                        }
                      } else { # process port name without []
                        foreach my $port (@{$port_table[0]}) {
                          if (cmp_port_name($expr,$port)) {
                            $found = 1;
                            last;
                          }
                        }
                      }
                      if($found == 0){
                        printf("WARNING ::: [$_[1]] Invalid regular expression \"\${$expr}\" in message at %s.\n",&get_cell_pos($i,$j));
                      }
                    }
                  }
                }
              }
              $col++;
            }
          }
        }
        if($row_has_data == 1){
          if($clock_info[0] eq "period"){ ## Check high pulse width is not larger than clock period
            my $clock_value = 0;
            my $high_pulse_width_value = 0;
            for(my $m=0; $m < scalar(@{$table[0]});$m++){
              if(defined $table[0][$m] && defined $table[1][$m]){
                if(get_port_type($table[1][$m], @port_table) eq "clock" && $table[0][$m] eq "clock"){
                  $clock_value = $tmp_row[$m];
                }
                if($table[0][$m] eq "high pulse width"){
                  $high_pulse_width_value = $tmp_row[$m];
                }
              }
            }
            if(grep(/[Ff][Ii][Xx][Ee][Dd]/, $clock_value)> 0){
              if($high_pulse_width_value > 0){
                printf("ERROR ::: [$_[1]] Please specify 0 in \"high pulse width\" column in case \"clock\" is FIXED at row %d.\n", $i+1);
                exit(3);
              }
            } elsif((grep(/rise|fall/, $clock_value)< 1) && ($clock_value ne "-" && $clock_value !~ /^</)) {
              if($high_pulse_width_value > $clock_value){
                printf("ERROR ::: [$_[1]] \"high pulse width\" value is larger than \"clock\" value at row  %d.\n", $i+1);
                exit(3);
              }
            }
          }
          @{$table[$row]} = @tmp_row; 
          $row++;
        }
      }
    }
  }
  if($des_row==-1){
    print("WARNING ::: [$_[1]] Sheet does not contain header line for parsing table content.\n");
    @table=();
  }else{
    if($_[1] eq "Table0" || $_[1] eq "Table_rnm" || $_[1] eq "Exclude"){
      if($_[1] eq "Table0"){
        CheckCareRange($_[0],\@table,\@port_table); # Check the validity of care range in truth table
      }
      # remove column with blank row1(port_name)
      my @tmp=();
      for (my $i=0;$i<scalar(@table);$i++){
        my $tmp_col=0;
        for (my $j=0;$j<scalar(@{$table[0]});$j++){
          if (defined $table[0][$j] && $table[0][$j] ne ""){
            if (!defined $table[$i][$j]){
              $table[$i][$j] = "";
            }
            $tmp[$i][$tmp_col] = $table[$i][$j];
            $tmp_col++;
          }
        }
      }
      @table=@tmp;
    }
    @table=&ReplaceString(\@table,\@port_table,$rnm,0); # Replace "-","S"
    @table=&SeparateMultiPortWidth(\@table,\@port_table,$rnm);  # separate multi portwidth 
  }
  @table=&CheckSubModeVector(\@table);
  return($out,@table);
}

sub CheckSubModeVector{
  my ($tbl) = @_;
  my @table = @$tbl;
  for (my $i=2;$i<scalar(@table);$i++){
    for (my $j=0;$j<scalar(@{$table[0]});$j++){
      if($table[0][$j] eq "Mode"){
         if($table[$i][$j] =~ /^ERKS_SUB_MODE/){
            if($i == (scalar(@table)-1)){
              $table[$i][$j] =~ s/ERKS_SUB_MODE/ERKS_LAST_SUB_MODE/g;
            }else{
              if($table[$i+1][$j] =~/^ERKSMODE_/){
                $table[$i][$j] =~ s/ERKS_SUB_MODE/ERKS_LAST_SUB_MODE/g;
              }
            }
         }
      }
    }
  }
  return @table;
}

sub PeriodConvert{
  my ($tbl, $ptbl, $vtbl, $pr, $clk_inf, $rnm) = @_;
  my @table = @$tbl;
  my @port_table = @$ptbl;
  my @clock_info = @$clk_inf;
  my $clock_value = calc_period(100,$clock_info[1], $clock_info[2]);
  for (my $i=2;$i<scalar(@table);$i++){
    my @port_name = ();
    my @port_val = ();
    my @port_io = ();
    my $col = 0;
    for (my $j=0;$j<scalar(@{$table[0]});$j++){
      next if ($table[0][$j] !~ /power|ground|input|inout|electrical_in|output|electrical_out/); # next column if not input/output
      $port_name[$col] = $table[1][$j];
      $port_val[$col] = $table[$i][$j];
      $port_io[$col] = $table[0][$j];
      $col++;
    }
    for (my $j=0;$j<scalar(@{$table[0]});$j++){
      if ($table[0][$j] eq "clock"){
        if ($clock_info[0] eq "frequency") {
          if ($table[$i][$j] ne "0" and $table[$i][$j] !~ /^[Ff][Ii][Xx][Ee][Dd]/ and $table[$i][$j] !~ /rise|fall/) {
            $table[$i][$j] = calc_period($table[$i][$j],$clock_info[1],$clock_info[2]);
            $clock_value = $table[$i][$j];
          }
        }
      }
      if ($table[0][$j] eq "output") {
        if (check_oscillation_port($table[1][$j],@port_table) eq "1") {
          if($table[$i][$j] eq "*"){
            next;
          }
          if ($clock_info[0] eq "period") {
            my $port_value = $table[$i][$j];
            my %var;
            if ($port_value =~ /^_?\(.*\)$/){
              $port_value =~ s/^_//;
              my @input_pat = get_input_pattern(\@port_val,\@port_val,\@port_io,$pr);
              %var = get_expr_val($port_value,\@input_pat,$pr,$vtbl,$ptbl,$rnm,"off");
              foreach my $key(keys %var){
                if ($var{$key} eq "0"){
                  print("ERROR ::: Period value of expression \"$table[$i][$j]\" is 0 with pattern {",join(",",@port_name),"} = {",join(",",@port_val),"} at $table[$i][0]/line $table[$i][1].\n");
                  exit(3);
                }
                $table[$i][$j] = $var{$key};
              }
            }
            if ($table[$i][$j] eq "0") {
              print("ERROR ::: Period value must not be 0 at $table[$i][0]/line $table[$i][1].\n");
              exit(3);
            }
#            if ($table[$i][$j] =~ /^_?\(.*\)$/) {
            if ($table[$i][$j] !~ /^[Ff][Ii][Xx][Ee][Dd]_/) {
               my $prefix = "";
               $prefix = "_" if $table[$i][$j] =~ /^_/;
               $table[$i][$j] =~ s/^_?\(//; 
               $table[$i][$j] =~ s/\)$//;
#               $table[$i][$j] = "$prefix(".calc_frequency($table[$i][$j],$clock_info[1],$clock_info[2],1).")";
               $table[$i][$j] = eval(calc_frequency($table[$i][$j],$clock_info[1],$clock_info[2],1));
            }
          }
        }
      }
    }
    for (my $j=0;$j<scalar(@{$table[0]});$j++){
      if ($table[0][$j] eq "high pulse width"){
        if ($clock_info[0] eq "frequency") {
          if ($table[$i][$j] ne "0" and $table[$i][$j] !~ /^[Ff][Ii][Xx][Ee][Dd]_/) {
            $table[$i][$j] = int($table[$i][$j]*$clock_value);
          }
        }
      }
    }
  }
  return @table;
}

sub fusion_tbl{ # @table0 /return next_tag, @table
  my ($file, $sheet, $pcheck, $pg, $rnm, $tbl0_, $ptbl_, $blank_error, $clock_info_)=@_;
  my @tbl0 = @$tbl0_;
  my @filter_tbl0 = FilterTruthTable(@$tbl0_);
  my $row=2;
  my $col=0;
  my @out=();
  my $retag="";
   for(my $i=0;$i<scalar(@{$tbl0[0]});$i++){
    $out[0][$i]=$tbl0[0][$i];
    $out[1][$i]=$tbl0[1][$i];
    $col++;
  }
  my $is_sub_found=0;
  for(my $i=2;$i<scalar(@tbl0);$i++){
    $col=0;
    my $check="0";
    $check=cck($sheet,$tbl0[$i],$tbl0[0],$tbl0[1]);
    if($check eq "0"){
      for(my $j=0;$j<scalar(@{$tbl0[$i]});$j++){
        $out[$row][$col]=$tbl0[$i][$j];
        $col++;
      }
      $row++;
    }else{
      $is_sub_found = 1;
      $retag=$check;
      my $sub_sheet=$check;
      $sub_sheet=~s/^.*<//;
      $sub_sheet=~s/>.*$//;
      my ($aa, @tmp)=make_truth_tbl($file,$sub_sheet,$pcheck,$pg,$ptbl_,$rnm,"",$blank_error,$clock_info_,"");
      my $check_sub_sheet = 0;
      for(my $j=2;$j<scalar(@{$tbl0[$i]});$j++){
        if($tbl0[$i][$j] eq $check){
          for(my $k=0;$k<scalar(@{$tmp[1]});$k++){
            if($tmp[1][$k] eq $tbl0[1][$j]){
               $check_sub_sheet++;
            }
          }
        }
      }
      if($check_sub_sheet == 0){
        print("ERROR ::: Reference table in sheet \"$sub_sheet\" does not contain pattern in row $tbl0[$i][1] of sheet \"$tbl0[$i][0]\". Please check the input ports in sheet \"$tbl0[$i][0]\" and sheet \"$sub_sheet\".\n");
        exit(3);
      }
      if($aa ne ""){
        $retag=$aa;
      }
      @tmp=&ReplaceString(\@tmp,$ptbl_,$rnm,0); # Replace "-","S"
      @tmp=&SeparateMultiPortWidth(\@tmp,$ptbl_,$rnm);  # separate multi portwidth 
      my $ref_check = -1;
      my @rep_line=@tmp;
      my $ret_var="";
      ($ref_check, $ret_var, @rep_line)=&get_ref_line($tbl0[0],$tbl0[1],$tbl0[$i],\@rep_line,$sub_sheet,"",$file,$ptbl_,$rnm,$blank_error,$clock_info_);
      if(scalar(@rep_line)==2){
        print("WARNING ::: Reference table in sheet \"$sub_sheet\" does not contain pattern in row $tbl0[$i][1] of sheet \"$tbl0[$i][0]\".\n");
      }
      if($ref_check ne "-1"){
        for(my $l=2;$l<scalar(@rep_line);$l++){
          $col=0;
          for(my $j=0;$j<scalar(@{$tbl0[$i]});$j++){
            my $es=0;
            for(my $k=0;$k<scalar(@{$rep_line[$l]});$k++){
              if ($tbl0[0][$j] eq "Sheet" || $tbl0[0][$j] eq "line"){
                $out[$row][0]=$tbl0[$i][0];
                $out[$row][1]="$tbl0[$i][1]($rep_line[$l][0]/$rep_line[$l][1])";
              }
              if($tbl0[0][$j] =~ /action|Mode|disable|control|assert_control|message|control_n|assert_control_n/ && $tbl0[0][$j] eq $rep_line[0][$k]){
                $out[$row][$col]=$rep_line[$l][$k];
                $col++;
                $es=1;
                last;
              }
              if($tbl0[1][$j] eq $rep_line[1][$k] && $tbl0[1][$j] ne ""){
                if($col > 1){
                  $out[$row][$col]=$rep_line[$l][$k];
                }
                $col++;
                $es=1;
                last;
              }
            }
            if($es==0){
              $out[$row][$col]=$tbl0[$i][$j];
              $col++;
            }
          }
          $row++;
        }
        if ($ref_check ne ""){
          $retag=$ref_check;
        }
      }
    }
  }
  if($is_sub_found eq "0"){
    $retag = "";
  }
  return($retag, @out);
}

sub cck{
  my ($tag,$row,$type,$pname)=@_;
  my @tmp=@$row;
  my @port_type=@$type;
  my @port_name=@$pname;
  for(my $i=2;$i<scalar(@tmp);$i++){
    if($port_type[$i] =~ /input|output|inout|clock|supply|power|ground/ && defined $port_name[$i] && $port_name[$i] ne ""){
      if($tmp[$i] =~/^_?<.*>$/){
        return($tmp[$i]); # next sheet name
      }
    }
  }
  return(0);
}

#my ($ref_check, $ret_var, @rep_line)=&get_ref_line($hold_pattern[0],$hold_pattern[1],$hold_pattern[$hold_pattern_index],\@table_temp,"",$latch_port,"",$pt,$rnm,$blank_error,$clock_info_,1);
sub get_ref_line{
  my @p_info = @{$_[0]};
  my @p_name = @{$_[1]};
  my @p_var  = @{$_[2]};
  my @ref_table= @{$_[3]};
  my $sheet = $_[4];
  my $refvar = $_[5];  # search value in table
  my $xls = $_[6];
  my @port_table = @{$_[7]};
  my $rnm = $_[8];
  my $blank_error = $_[9];
  my $clock_info_ = $_[10];
  my $get_hold_pat = (defined $_[11])?$_[11]:"0";
  my @ret_table=();
  my @row_list=();
  my $tmp_ret_var=""; # value of reference variable
  my $ret_var=""; # return value for reference variable
  my @row_var_list=(); # row match ref_var
  my $check = "-1";
  my $retag = "";
  my $offset_check_cnt = 0;
  push(@ret_table,$ref_table[0]);
  push(@ret_table,$ref_table[1]);
  for(my $j=2;$j<scalar(@{$ref_table[0]});$j++){
      if ($ref_table[0][$j] =~ /action|message|Mode|disable|control|control_n|assert_control|assert_control_n/){
        $offset_check_cnt += 1;
      }
  }
  for(my $i=2;$i<scalar(@ref_table);$i++){  # row of truth table
    if ($get_hold_pat eq "1") {
      next if (grep(/^_?HOLD$|^_?STRONG_HOLD$/,@{$ref_table[$i]})>0);
    }
    my $check_cnt=scalar(@{$ref_table[$i]})-2;
    if($refvar ne ""){
      $check_cnt--;
      $check_cnt = $check_cnt - $offset_check_cnt;
    }
    my @temp_row = @{$ref_table[$i]};
    my @preserve_temp_row = @{$ref_table[$i]}; # incase row has variable
    my $row_has_expr=0;
    my @checked_name = ();
    for(my $k=2;$k<scalar(@p_name);$k++){  # port name in truth table
      if (($p_info[$k] =~ /action|message|Mode|disable|control|control_n|assert_control|assert_control_n/)){
        for(my $j=2;$j<scalar(@{$ref_table[0]});$j++){
          if($ref_table[0][$j] eq $p_info[$k]){
              $check_cnt--;
          }
        }
        next;
      }
      for(my $j=2;$j<scalar(@{$ref_table[0]});$j++){
        if(defined $ref_table[0][$j] && $ref_table[0][$j] eq "pcheck" && grep (/^pcheck$/,@checked_name) < 1){
          push(@checked_name,"pcheck");
          if((($p_var[$k]=~/^\*/) && ($ref_table[$i][$j]!~/^_/)) || (($p_var[$k]=~/^_\*/) && ($ref_table[$i][$j] =~ /^_/)) 
          || (($ref_table[$i][$j] =~ /^\*/) &&($p_var[$k]!~/^_/)) || (($ref_table[$i][$j] =~ /^_\*/) &&($p_var[$k]=~/^_/)) 
          || ($p_var[$k] eq $ref_table[$i][$j])){
            $check_cnt--;
            last;
          }
        }
        if((!defined $ref_table[1][$j])||($ref_table[1][$j] eq $refvar)||(grep(/^\Q$ref_table[1][$j]\E$/,@checked_name) > 0)){
          if (defined $ref_table[1][$j] && $ref_table[1][$j] eq $refvar){
            $tmp_ret_var = $ref_table[$i][$j]; 
          }
          next;
        }
        if($p_name[$k] eq $ref_table[1][$j]){
          if (($get_hold_pat eq "1")&&((($p_var[$k] eq "HOLD" or $p_var[$k] eq "STRONG_HOLD")&&($ref_table[$i][$j]=~/^[^_]/))||(($p_var[$k] =~ /^_+HOLD|^_+STRONG_HOLD/)&&($ref_table[$i][$j]=~/^_/)))) {
            $check_cnt--;
            next;
          }
#          if (($ref_table[$i][$j] =~ /^_/ && $p_var[$k] !~ /^_/) || ($ref_table[$i][$j] !~ /^_/ && $p_var[$k] =~ /^_/)){ # check "_" for reference table
#            last;
#          }
          my $is_match = 0;
          my $debug = 0;
          if ($ref_table[$i][$j] =~ /^_?\d*\.?\d+$/ && $p_var[$k]=~/^_?\d*\.?\d+$/){
            my $tmp_ref = $ref_table[$i][$j];
            my $tmp_var = $p_var[$k];
            $tmp_ref =~ s/^_//;
            $tmp_var =~ s/^_//;
            if ($ref_table[$i][$j] ne $p_var[$k]){
              last;
            }
          }
          push (@checked_name,$ref_table[1][$j]);
          if((($p_var[$k]=~/^\*|S$/) && ($ref_table[$i][$j]!~/^_/)) || (($p_var[$k]=~/^_\*|_S$/) && ($ref_table[$i][$j] =~ /^_/)) 
          || (($ref_table[$i][$j] =~ /^\*|S$/) &&($p_var[$k]!~/^_/)) || (($ref_table[$i][$j] =~ /^_\*|_S$/) &&($p_var[$k]=~/^_/)) 
          || ((cmp_ex_match_value($p_var[$k],$ref_table[$i][$j],$k,$p_name[$k],$rnm,\@p_info,\@p_name,\@port_table))[0] eq "1")){
            my $match_val = (cmp_ex_match_value($p_var[$k],$ref_table[$i][$j],$k,$p_name[$k],$rnm,\@p_info,\@p_name,\@port_table))[1];
            $temp_row[$j] = $match_val;
            $preserve_temp_row[$j] = $match_val;
            $is_match = 1;
            $debug = 1;
          }
          if($p_var[$k] =~ /^\s*_?<.*>\s*/){
            my $tmp_val = $p_var[$k];
            $tmp_val=~s/^\s*_?<//;
            $tmp_val=~s/>\s*$//;
            $is_match = 1;
            $debug = 2;
            if($tmp_val eq $sheet){
              $temp_row[$j] = $ref_table[$i][$j];
              $preserve_temp_row[$j] = $ref_table[$i][$j];
            }else{
              $retag = $p_var[$k];
              $temp_row[$j] = $p_var[$k];
              $preserve_temp_row[$j] = $p_var[$k];
            }
          }
          if ($p_var[$k] =~ /^\[.*\]$/){
            $is_match = 1;
            $debug = 3;
            $preserve_temp_row[$j] = $p_var[$k];
            $row_has_expr = 1;
          }
          if ($is_match){
            $check_cnt--;
          } 
          if ($ref_table[$i][$j] =~ /^_?\<.*\>/){
            my $ref_sheet = $ref_table[$i][$j];
            $ref_sheet =~ s/^.*<//;
            $ref_sheet =~ s/>.*$//;
            my ($aa,@tm)=make_truth_tbl($xls,$ref_sheet,0,0,\@port_table,0,"",$blank_error,$clock_info_,"");
            my ($check, $ret_var, @rep_line)=&get_ref_line($_[0],$_[1],$ref_table[$i],\@tm,$ref_sheet,"",$xls,\@port_table,$rnm,$blank_error,$clock_info_);
            for (my $l=0;$l<scalar(@rep_line);$l++){
              push (@ref_table, [@{$rep_line[$l]}]);
            }
          }
        }
      }
    }
    if(($check_cnt==0)&&(grep(/^$i$/,@row_list)<1)){
      $check="";
      $ret_var = $tmp_ret_var;
      push(@ret_table,\@temp_row);
      push(@ret_table,\@preserve_temp_row) if ($row_has_expr eq "1");
      push(@row_list,$i);
    }
  }
  if ($retag ne ""){
    $check = $retag;
  }
  return ($check,$ret_var,@ret_table);
}

sub cmp_ex_match_value {
  my ($ina,$inb,$index,$port_name,$rnm,$p_info,$p_name,$ptbl_) = @_;
  return (0,"") if (($ina =~ /^_/ and $inb !~ /^_/) or ($ina !~ /^_/ and $inb =~ /^_/));
  return (1,$ina) if ($inb =~ /^_?\*$/);
  return (1,$inb) if ($ina =~ /^_?\*$/);
  return (1,$ina) if ($ina eq $inb);
  my @table = (); 
  @{$table[0]} = @{$p_info};
  @{$table[1]} = @{$p_name};
  my @port_ref = GetPortRefTable($p_name,\@table,$ptbl_,$rnm);
  my %var   = get_pattern($ina,$index,0,@port_ref);
  my %check = get_pattern($inb,$index,0,@port_ref);
  foreach my $key (keys %var){
    if (!exists $check{"$key"}){
      return(0,"");
    }
  }
  return(1,$ina);
}

sub check_tbl_val{
  my ($sheet_name,$row,$col,$in,$rnm,$is_tt,$is_ref_port,$port_name,$ptbl_,$clock_info_)=@_;

  my @clock_info = @$clock_info_;
  my @rfseq = ();
  if(@clock_info != 0){
      @rfseq = @{$clock_info[3]};
  }
  my $is_freq = $clock_info[0];
  my $check=0;
  my $val="";
  my $has_=0;
  my @port_table=@$ptbl_;
  $in =~ s/^\s*//g;
  $in =~ s/\s*$//g;
  my $port_type = "";
  my $is_input = 0;
  my $is_inout = 0;
  my $is_output = 0;
  my $is_clock = 0;
  my $is_osci = 0;
  my $latch_port = "";
  # Check "_"
  if (@port_table != 0) {
    $port_type = get_port_type($port_name,@port_table);
    $is_input = 1 if ($port_type eq "input");
    $is_inout = 1 if ($port_type eq "inout");
    $is_output = 1 if ($port_type eq "output");
    $is_clock = 1 if ($port_type eq "clock");
    $is_osci = check_oscillation_port($port_name,@port_table);
    $latch_port = get_latch_port(@port_table);
  }
  if ($in =~ /^_/){
    $has_ = 1;
    $in =~ s/^_//g;
  }
  if($in eq "*"){
    if($is_clock){
      printf("ERROR ::: [$sheet_name] Erakis does not support keyword \"%s\" for clock signal at %s.\n",$in,&get_cell_pos($row,$col));
      exit(3);
    }else{
    $check=1;
    $val="*";
    }
  }elsif($in eq "VSS" || $in eq "GND" || $in eq "L" || $in eq "gnd" || $in eq "vss" || $in eq "0"){
    $check=1;
    $val="0";
  }elsif($in eq "VDD" || $in eq "VCC" || $in eq "H" || $in eq "vdd" || $in eq "vcc" || $in eq "1"){
    $check=1;
    $val="1";
  }elsif($in eq "Hiz" || $in eq "HiZ" || $in eq "z" || $in eq "Z"){
    $check=1;
    $val="Z";
  }elsif($in =~ /^(0|1|x|z)$/i){
    $check=1;
    $val=uc($in);
  }elsif(($in =~ /^\d*\.\d+/)&&($rnm == 1)){ # check real number when option "-rnm" is defined
    $check=1;
    $val=$in;
  }elsif(($in =~ /^\d*\.\d+/)&&(($is_clock eq "1")|| $is_osci)){ # check real number when it is clock port
    if($is_freq eq "frequency"){
      $check=1;
      $val=$in;
    }else{
      printf("ERROR ::: [$sheet_name] Can not specify real value \"%s\" for clock period in %s.\n",$in,&get_cell_pos($row,$col));
      exit(3);
    }
  }elsif($in =~ /^(\d*'+|'*)b[01xzXZ]+$/ or $in =~ /^(\d*'+d|'*d)\d+$/ or $in =~ /^(\d*'+|'*)h[\dABCDEFXZabcdefxz]+$/){
    $check=1;
    $in = str2dec($in, $is_tt);
    $val=$in;
  }elsif($in =~ /^\d+$/){
    $check=1;
    $val=$in;
  }elsif($in =~ /^<[a-zA-Z]+[\w_]*>$/){# referent table
    $check=0 if ($is_tt eq "1");
    $val=$in;
  }elsif($in =~ /^\[?ramp\(.*\)\]?$/){# ramp wave
    $in=~ s/^\[//;
    $in=~ s/\]$//;
    $in=~ s/\s//g;
    $val="[$in]";
    if ($rnm==1){
      if($in =~ /^\[?ramp\([^,]+,[^,]+,[^,]+\)\]?$/){
        printf("WARNING ::: [$sheet_name] String \"_\" should not use with ramp wave at %s because it causes overlap.\n",&get_cell_pos($row,$col)) if ($has_==1);
        $has_=0;
        $check=1;
      }else{
        printf("WARNING ::: [$sheet_name] Invalid format of ramp wave %s in %s.\n",$in,&get_cell_pos($row,$col));
        $check=1;
        $val=~s/\[?ramp\(.*\)\]?/\*/;
      }
    }else{
      printf("WARNING ::: [$sheet_name] Do not support %s in %s without \"-rnm\" option.\n",$in,&get_cell_pos($row,$col));
      $check=1;
      $val=~s/\[?ramp\(.*\)\]?/\*/;
    }
  }elsif($in =~ /^\[![0|1|x|z]\]$/i){# expression !@ (@ = 0,1,x,z)
    $check=1;
    my $exp = $in;
    $exp =~ s/^\[!//;
    $exp =~ s/\]//;
    $val="EXP_NOT_".uc($exp)."_VAL";
  }elsif($in =~ /^\[.*\]$/){# expression
    $check=1;
    $val=$in;
  }elsif($in =~ /^[Ff][Ii][Xx][Ee][Dd] *(0|1|x|z)$/i and ($is_clock eq "1" or $is_osci eq "1")){# fixed value for clock or oscillation port
    $check=1;
    $val=uc($in);
    $val=~s/fixed */FIXED_/i;
  }elsif($in =~ /^(rise|fall)$/i && ($is_input eq "1" || $is_clock eq "1")){# input port with rise or false check
    if($sheet_name ne "Exclude"){
      my $find = 0;
      if($is_input eq "1"){
        for (my $i=0;$i<scalar(@rfseq);$i++){
          if (cmp_port_name($port_name,$rfseq[$i][2])){
            $find = 1;
            $check=1;
            $val=uc($in);
            last;
          }
        }
        if ($find == 0){
          printf("ERROR ::: [$sheet_name] Lack rising/falling timing information of input port $port_name for expression at %s.\n",&get_cell_pos($row,$col));
          exit(1);
        }
      }elsif ($is_clock eq "1"){
        for (my $i=0;$i<scalar(@{$port_table[0]});$i++){
          if (cmp_port_name($port_name,$port_table[0][$i])){
            $check=1;
            $val=uc($port_table[6][$i]);
            last;
          }
        }
      }
      }else{
          for (my $i=0;$i<scalar(@{$port_table[0]});$i++){
              if (cmp_port_name($port_name,$port_table[0][$i])){
                  $check=1;
#                  if($is_clock){
#                      $val=uc($port_table[6][$i]);
#                  }else{
#                      $val= $in;
#                  }
                  $val = $in;
                  last;
              }
          }
      }
  }elsif($in =~ /^s$/i){# S character
    printf("WARNING ::: [$sheet_name] String \"_\" should not use with don't care value \"S\" at %s because it causes overlap.\n",&get_cell_pos($row,$col)) if ($has_==1);
    $has_=0;
    $check=1;
    $val="S";
  }elsif($in =~ /^-$/){# - character
    printf("WARNING ::: [$sheet_name] String \"_\" should not use with don't care value \"-\" at %s because it causes overlap.\n",&get_cell_pos($row,$col)) if ($has_==1);
    $has_=0;
    $check=1;
    $val="-";
  }elsif($in =~/^\/$/){# / character
#    printf("WARNING ::: [$sheet_name] String \"/\" should not use with input port %s at %s.\n",$port_name, &get_cell_pos($row,$col)) if ($is_output ne "1");
    $check=1;
    $val=$in;
  }elsif($in =~/^HOLD|STRONG_HOLD$/){# HOLD character
    if (($is_output ne "1" and $is_inout ne "1") || ($is_inout eq "1" and $has_ ne "1")) {
      printf("ERROR ::: [$sheet_name] String \"$in\" at %s should be used for output port only.\n", &get_cell_pos($row,$col));
      exit(3);
    }
    if ($latch_port eq "") {
      printf("ERROR ::: [$sheet_name] String \"HOLD/STRONG_HOLD\" should not be used without any predefined latch port at %s.\n", &get_cell_pos($row,$col));
      exit(3);
    }
    $check=1;
    $val=$in;
  }elsif($is_tt eq "1"){
    printf("ERROR ::: [$sheet_name] String \"%s\" in %s must be covered in <> in case of reference table or [] in case of expression.\n",$in,&get_cell_pos($row,$col));
    exit(3);
  }
  if (($is_ref_port eq "1") 
  and ((($in !~ /^(\[.*\]|\d*.?\d+|0|1|x|z)$/i) and (not ($in =~ /^(\d*'+|'*)b[01xzXZ]+$/ or $in =~ /^(\d*'+d|'*d)\d+$/ or $in =~ /^(\d*'+|'*)h[\dABCDEFXZabcdefxz]+$/)))
    or ($in =~ /^\[![0|1|x|z]\]$/i))) {
    printf("ERROR ::: [$sheet_name] Value of reference variable at %s cannot be \"%s\". It must be a single value or port reference.\n",&get_cell_pos($row,$col),$in);
    exit(3);
  }
  if ($is_output eq "1" and $in =~ /(^s$|^-$|ramp)/i) {
    printf("ERROR ::: [$sheet_name] Value of output port %s at %s should not be \"%s\" because it causes overlap.\n",$port_name, &get_cell_pos($row,$col),$in);
    exit(3);
  }
  if ($has_==1){
    $val="_".$val;
  }
  return($check,$val);
}

sub str2dec{
  my ($in, $is_tt) = @_;
  if($in=~/^\d*\'*b/){
    $in=~s/^\d*\'*b/b/;
    $in=bin2dec($in) if ($in=~/^b(0|1)+$/ && $is_tt eq "0");
    $in=~s/^b(x|z)+$/$1/i;
    $in=~s/^b(0|1|x|z)$/$1/i;
  }elsif($in=~/^\d*\'*d/){
    $in=~s/^\d*\'*d//;
    $in="b".dec2bin($in);
    $in=bin2dec($in) if ($in=~/^b(0|1)+$/ && $is_tt eq "0");
  }elsif($in=~/^\d*\'*h/){
    $in=~s/^\d*\'*h//;
    $in="b".hex2bin(uc($in));
    $in=bin2dec($in) if ($in=~/^b(0|1)+$/ && $is_tt eq "0");
    $in=~s/^b(x|z)+$/$1/i;
    $in=~s/^b(0|1|x|z)$/$1/i;
  }
  return $in;
}

sub get_header_comment{# [0] worksheet
#  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$_[0];
  my $worksheet=$workbook->worksheet($_[1]) or die "ERROR ::: \"$_[1]\" is not found in \"$_[0]\".\n";
  my @header;
  my ($row_min, $row_max)=$worksheet->row_range(); # Excel effective row range
  my ($col_min, $col_max)=$worksheet->col_range(); # Excel effective col range
  for (my $i=$row_min;$i<$row_max+1;$i++){
    my $row_has_data = 0;
    for (my $j=$col_min;$j<$col_max+1;$j++){
      my $cell=&get_cell_val($i,$j,$worksheet);
      if(defined $cell){
        if($cell =~ /^\*\*\*/){# if row includes a "***"
          $cell =~ s/\n/\n\/\/\*\*\* /g;
          if(grep(/\Q$cell\E/, @header) < 1){
            push(@header, $cell);
          }
        }
        $row_has_data = 1;
      }
    }
  }
 return @header;
}

sub get_ignored_row_list{# [0] worksheet
  my ($worksheet)=@_;
  my @list=();
  my ($row_min, $row_max)=$worksheet->row_range(); # Excel effective row range
  my ($col_min, $col_max)=$worksheet->col_range(); # Excel effective col range
  for (my $i=$row_min;$i<$row_max+1;$i++){
    my $row_has_data = 0;
    for (my $j=$col_min;$j<$col_max+1;$j++){
      my $cell=&get_cell_val($i,$j,$worksheet);
      if(defined $cell){
        if($cell =~ /^#/){# if row includes a "#"
          push(@list, $i) if ($row_has_data == 0);# add ignored row if # is at the first cell
          $row_has_data = 1;
          last;# next row
        }elsif($cell ne ""){
          $row_has_data = 1;
        }
      }
    }
    if ($row_has_data == 0){
      push(@list, $i);# add ignored row
    }
  }
  return @list;
}

sub CountTotalAssertion{# [0] truth table [1] port table [2] -rnm option
  my($tt, $pt, $rnm)=@_;
  my @truth_org=@$tt;
  my @port=@$pt;
  my $total=0;
  my @TruthTableList = SeparateTruthTable($rnm, @truth_org);
  for (my $tt=0;$tt<scalar(@TruthTableList);$tt++){
    my @truth = @{$TruthTableList[$tt]};
    my $sub_total=1;
    for(my $col=2;$col<scalar(@{$truth[0]});$col++){
      if($truth[0][$col] eq "input"){
        my ($lv, @care_range)=get_port_level($truth[2][$col], @port);
        $sub_total=$sub_total*$lv;
      }
    }
    $total=$total+$sub_total;
  }
  return $total;
}

sub MakeVariableTable{#[0] excel file
  my ($xls, $rnm, $tbl, $ptbl, $blank_error,$clock_info_)=@_;
  my @truth_table = @$tbl;
  my @port_table = @$ptbl;
  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$parser->parse($xls) or die "ERROR ::: $xls is not found.\n";
  my $worksheet=$workbook->worksheet("Variable") or die "ERROR ::: \"Variable\" is not found in \"$_[0]\".\n";
  my ($row_min, $row_max)=$worksheet->row_range(); # Excel effective row range
  my ($col_min, $col_max)=$worksheet->col_range(); # Excel effective col range
  my @sheet_name_list = &GetSheetNameList($xls);
  my $col=0;
  my $row=0;
  my @variable=();
  my $var_col=-1;
  my $exp_col=-1;
  my $checked=-1;
  my @var_list=();
  
  my @ignored_row_list=get_ignored_row_list($worksheet);
  for (my $i=$row_min;$i<$row_max+1;$i++){
    if (grep(/^$i$/, @ignored_row_list)>0){
      next;
    }
    for (my $j=$col_min;$j<$col_max+1;$j++){
      my $cell=&get_cell_val($i,$j,$worksheet);
      if(!(defined $cell) || $cell eq ""){
        next;
      }elsif($checked==-1){
        my $next=0;
        if($cell =~ /(variable|var)/i){
          if ($var_col==-1){
            $var_col=$j;
            $variable[0][0]="";
          }else{
            print("ERROR ::: [Variable] Duplicated variable column in.\n");
            exit(1);
          }
        }elsif($cell =~ /(expression|expr)/i){
          if ($exp_col==-1){
            $exp_col=$j;
            $variable[1][0]="";
          }else{
            print("ERROR ::: [Variable] Duplicated expression column.\n");
            exit(1);
          }
        }else{
          $next=1;
        }
      }else{
        if ($var_col>=$exp_col){
          print("ERROR ::: [Variable] \"variable\" column must be before \"expression\" column.\n");
          exit(1);
        }
        if($j == $var_col){
          $variable[0][$col]=$cell;
          if (grep(/^\Q$cell\E$/,@var_list) > 0) {
            printf("ERROR ::: [Variable] There are more than one \"%s\" exist at %s.\n", $cell, &get_cell_pos($i,$j));
            exit(1);
          }
          push(@var_list,$cell);
        }elsif($j==$exp_col){
          $cell=~s/\]$// if ($cell=~/^\[.*\]/); #remove [] if user put expression in bracket
          $cell=~s/^\[//  if ($cell=~/^\[/); #remove [] if user put expression in bracket
          my ($check,$val)=check_tbl_val($_[1],$i,$j,$cell,$rnm,0,0,"",[()],[()]);
          $variable[1][$col]=$val if ($check eq "1");
          if ($check eq "0"){
            check_expr_valid($cell,$i,$j,1);
            $variable[1][$col]=$cell;
          }
        }
      }
    }
    if ($var_col==-1 || $exp_col==-1){
        print("ERROR ::: [Variable] Invalid input.\nThe title of variable column must be \"var\" or \"variable\".The title of expression column must be \"expr\" or \"expression\".\n");
        exit(1);
    }else{
      $checked=0;
    }
    if (defined $variable[0][$col] && defined $variable[1][$col] && $variable[0][$col] ne "" && $variable[1][$col] ne ""){
      if($variable[1][$col]=~/<.*>/){ # format of reference table: <ref_sheet,ref_name>
        $variable[1][$col]=~s/>/,$variable[0][$col]>/g;
      }
      $col++;
    }
  }
  my %ref_tbl_list;
  my $cnt = 0;
  if (@variable != 0){
    my @port_ref = GetPortRefTable($truth_table[1],\@truth_table,\@port_table,$rnm);
    for (my $j=0;$j<scalar(@{$variable[0]});$j++){
      next if (check_pattern_exist_in_table(0,$variable[0][$j],"",\@truth_table,\@port_ref,0,0) != 1); # do not create varable reference table if variable is not used in truth table
      if($variable[1][$j]=~/<.*>/){ # format of reference table: <ref_sheet,ref_name>
        my $ref_sheet = $variable[1][$j];
        $ref_sheet =~ s/<//;
        $ref_sheet =~ s/,.*>//;

        my @tm=MakeTruthTable($xls,$ref_sheet,0,0,$rnm,\@port_table,$variable[0][$j],$blank_error,$clock_info_);  # fusion table
        @tm=ReplaceInputVariable($xls,\@tm,\@variable,\@port_table, $rnm, $blank_error,$clock_info_);
        @tm=ReplaceString(\@tm,\@port_table,$rnm,1); # Replace "-","S"
        @tm=SeparateMultiPortWidth(\@tm,\@port_table,$rnm);  # separate multi portwidth 
        @{$ref_tbl_list{$variable[0][$j]}} = @tm;
        $cnt++;
      }
    }
  }
  return(\@variable,\%ref_tbl_list);
}

sub check_expr_valid{
  my ($expr, $info0, $info1, $is_variable) = @_;
  my $exp = $expr;
  my $is_valid = 0;
  return(1) if ($exp =~ /^\[?ramp\([^)]+\).*\]?/); # ramp should not be used in output value -> overlap
  return(1) if ($is_variable eq "1" && $exp =~ /^<.*>$/); # reference variable sheet
  # replace all port/variable by value 0
  my @string = get_string_list($exp);
  for (my $i=0;$i<scalar(@string);$i++){
    $exp =~ s/\b\Q$string[$i]\E/0/g if ($string[$i] =~ /\[/);
    $exp =~ s/\b\Q$string[$i]\E\b/0/g if ($string[$i] !~ /\[/);
  }
  my $val = eval($exp);
  if (defined $val && $val ne ""){
    $is_valid = 1;
  }
  if ($is_valid == 0){
    $exp = $expr;
    # replace all port/variable by value 1
    for (my $i=0;$i<scalar(@string);$i++){
      $exp =~ s/\b\Q$string[$i]\E/1/g if ($string[$i] =~ /\[/);
      $exp =~ s/\b\Q$string[$i]\E\b/1/g if ($string[$i] !~ /\[/);
    }
    my $val = eval($exp);
    if (defined $val && $val ne ""){
      $is_valid = 1;
    }
  }
  if ($is_valid == 0){
    $exp = $expr;
    # replace port/variable by value 0 and 1
    my $rep_val = 0;
    for (my $i=0;$i<scalar(@string);$i++){
      $exp =~ s/\b\Q$string[$i]\E/$rep_val/g if ($string[$i] =~ /\[/);
      $exp =~ s/\b\Q$string[$i]\E\b/$rep_val/g if ($string[$i] !~ /\[/);
      $rep_val ++;
      $rep_val = 0 if ($rep_val > 1);
    }
    my $val = eval($exp);
    if (defined $val && $val ne "" && $val >= 0){
      $is_valid = 1;
    }
  }
  if ($is_valid == 0){
    $exp = $expr;
    # replace port/variable by value 1 and 0
    my $rep_val = 1;
    for (my $i=0;$i<scalar(@string);$i++){
      $exp =~ s/\b\Q$string[$i]\E/$rep_val/g if ($string[$i] =~ /\[/);
      $exp =~ s/\b\Q$string[$i]\E\b/$rep_val/g if ($string[$i] !~ /\[/);
      $rep_val --;
      $rep_val = 1 if ($rep_val < 0);
    }
    my $val = eval($exp);
    if (defined $val && $val ne "" && $val >= 0){
      $is_valid = 1;
    }
  }
  if($is_valid == 0){
    if($is_variable eq "1"){
      printf("ERROR ::: [Variable] Invalid expression \"%s\" at %s.\n",$expr,get_cell_pos($info0,$info1));
    }else{
      printf("ERROR ::: Invalid expression \"%s\" at Table %s/line %s.\n",$expr,$info0,$info1);
    }
    exit(1);
  }
}
sub MakeParamTable{#[0] excel file
  my ($xls)=@_;
  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$parser->parse($xls) or die "ERROR ::: $xls is not found.\n";
  my $worksheet=$workbook->worksheet("param") or die "ERROR ::: \"param\" is not found in \"$_[0]\".\n";
  my ($row_min, $row_max)=$worksheet->row_range(); # Excel effective row range
    my ($col_min, $col_max)=$worksheet->col_range(); # Excel effective col range
    my $col=0;
  my $row=0;
  my @param=();
  my $parameter_col=-1;
  my $initial_value_col=-1;
  my $checked=-1;
  my @param_list=();
  my @ignored_row_list=get_ignored_row_list($worksheet);
  for (my $i=$row_min;$i<$row_max+1;$i++){
    if (grep(/^$i$/, @ignored_row_list)>0){
      next;
    }
    for (my $j=$col_min;$j<$col_max+1;$j++){
      my $cell=&get_cell_val($i,$j,$worksheet);
      if(!(defined $cell) || $cell eq ""){
        next;
      }elsif($checked==-1){
        if($cell =~ /(parameter)/i){
          if ($parameter_col==-1){
            $parameter_col=$j;
            $param[0][0]="parameter";
          }else{
            print("ERROR ::: [param] Duplicated \"parameter\" column in.\n");
            exit(1);
          }
        }elsif($cell =~ /(initial value)/i){
          if ($initial_value_col==-1){
            $initial_value_col=$j;
            $param[1][0]="value";
          }else{
            print("ERROR ::: [param] Duplicated \"initial value\" column.\n");
            exit(1);
          }
        }else{
          print("WARNING ::: [param] Erakis does not care \"$cell\" column in param sheet. It is ignored.\n");
        }
      }else{
        if ($parameter_col>=$initial_value_col){
          print("ERROR ::: [param] \"parameter\" column must be before \"initial value\" column.\n");
          exit(1);
        }
        if($j == $parameter_col){
          $param[0][$col]=$cell;
          if (grep(/^\Q$cell\E$/,@param_list) > 0) {
            printf("ERROR ::: [param] There are more than one \"%s\" exist at %s.\n", $cell, &get_cell_pos($i,$j));
            exit(1);
          }
          push(@param_list,$cell);
        }elsif($j==$initial_value_col){
          if($cell =~ /^(\d*'+|'*)b[01xzXZ]+$/ or $cell =~ /^(\d*'+d|'*d)\d+$/ or $cell =~ /^(\d*'+|'*)h[\dABCDEFXZabcdefxz]+$/ or $cell =~ /^\d+.?\d*$/ or $cell =~/^\'\w+\'$/){
            $param[1][$col]=$cell;
          }else{
            printf("ERROR ::: [param] Invalid value of initial value column at %s.\n", &get_cell_pos($i,$j));
            exit(1);
          }
        }
      }
    }
    if ($parameter_col==-1 || $initial_value_col==-1){
      if($parameter_col==-1){
        print("ERROR ::: [param] Invalid input. The title of parameter column must be \"parameter\".\n");
      }
      if($initial_value_col==-1){
        print("ERROR ::: [param] Invalid input. The title of initial value column must be \"initial value\".\n");
      }
      exit(1);
    }else{
      $checked=0;
    }
    if (defined $param[0][$col] && defined $param[1][$col] && $param[0][$col] ne "" && $param[1][$col] ne ""){
      $col++;
    }else{
      printf("WARNING ::: [param] Wrong input at line %d.\n", $i+1);
    }
  }
  return(@param);
}

sub get_string_list{
  my $expr=$_[0];
  my @string=();
  # process ramp wave
  my $exp = $expr;
  $exp =~ s/^\[// if ($expr =~ /^\[.*\]$/);
  $exp =~ s/\]$// if ($expr =~ /^\[.*\]$/);

#  while ($exp =~ /<\w+>/ || $exp =~ /\[<\w+>\]/){
#    my $tmp = $exp;
#    $tmp =~ s/^.*</</;
#    $tmp =~ s/>.*$/>/;
#    push(@string,$tmp);
#    $exp=~s/\Q$tmp\E//g;
#  }

  while ($exp =~ /\b\w+\[\d+\]/){
    my $tmp = $exp;
    my @tmp_split = split(/\W+/,(split(/\[/,$tmp))[0]);
    my $port_name = $tmp_split[scalar(@tmp_split)-1];
    my $port_index = (split(/\[/,$tmp))[1];
    $port_index =~ s/\].*$//;
    $tmp = $port_name."[".$port_index."]";
    push(@string,$tmp);
    $exp=~s/\b\Q$tmp\E//g;
  }
  my @split_str = split (/\W+/,$exp);
  for (my $i=0;$i<scalar(@split_str);$i++){
    next if ($split_str[$i] =~ /^\d+$/ || $split_str[$i] eq "");
    push(@string,$split_str[$i]) if (grep (/\b\Q$split_str[$i]\E\b/,@string) < 1);
    $exp=~s/\b$split_str[$i]\b//g;
  }
  return @string;
}

sub calc_expr{
  my ($expr, $name, $value, $rv, $vtl, $ptbl, $rnm, $blank_error,$clock_info_)=@_;
  my $exp = $expr;
  my @port_name = @$name;
  my @port_value= @$value;
  my @ref_var=@$rv;
  my %var_table_list=%$vtl;
  return "X" if ($expr =~ /^(x|z)$/i);
  for (my $i=0;$i<scalar(@{$ref_var[0]});$i++){
    if ($ref_var[2][$i] eq "-1"){
      my @p_info = ("input") x (scalar(@port_name)+2);
      my @p_name = ("name","-",@port_name);
      my @p_value  = ("-","-",@port_value);
      my ($check, $ret_var, @rep_line)=get_ref_line(\@p_info,\@p_name,\@p_value,\@{$var_table_list{$ref_var[1][$i]}},"",$ref_var[0][$i],"",$ptbl,$rnm,$blank_error,$clock_info_);
      print("WARNING ::: Reference variable $ref_var[0][$i] got more than one result for one pattern {",join(",",@port_name),"} = {",join(",",@port_value),"}.\n") if (scalar(@rep_line > 3));
      $ret_var =~ s/^_*//; # remove "_" if existed.
      return "X" if ($ret_var =~ /^b?(x|z)+$/i);
      $exp =~ s/\b\Q$ref_var[0][$i]\E/$ret_var/g;
    }
  }
  for (my $i=0;$i<scalar(@port_name);$i++){
    return "X" if ($port_value[$i] =~ /^(x|z)$/i);
    $exp =~ s/\b\Q$port_name[$i]\E/$port_value[$i]/g;
  }
  my $val = eval($exp);
  if (!defined $val || $val eq ""){
    print("ERROR ::: Invalid expression $expr with input pattern {",join(",",@port_name),"} = {",join(",",@port_value),"}.\n");
    exit(1);
  }else{
    return $val;
  }
  
}

sub get_expr_val{
  my ($a,$pat,$pr,$vtl,$ptbl,$rnm,$blank_error,$clock_info_) = @_;
  my @input_pat = @$pat;
  my @port_ref = @$pr;
  my @ref_var = ();
  my $total_input = 0;
  my $input_cnt = 0;
  my %expr_result;
  if ($a =~ /^(.*)$/){
    $a =~ s/\.r\b//g; # remove ".r" of real port
    ($input_cnt,@ref_var)=get_ref_list($a, \@port_ref, \@ref_var, $vtl);
    $total_input+= $input_cnt;
  }
  my @loop_cnt_ctrl = ("0")x $total_input;
  my @port_loop_cnt = ("0")x $total_input;
  my @port_name     = ("") x $total_input;
  my @port_range    = ("0")x $total_input;
  my @port_value    = ("0")x $total_input;
  my @port_col      = ("") x $total_input;
  my @port_break    = ("0")x ($total_input+1);
  my $col = 0;
  $port_break[$total_input]  = "1";
  for (my $i=0;$i<scalar(@{$ref_var[0]});$i++){
    if ($ref_var[2][$i] ne "-1"){
      $port_range[$col] = scalar(@{$input_pat[$ref_var[1][$i]]});
      $port_name[$col]  = $ref_var[0][$i];
      $port_col[$col]   = $ref_var[1][$i];
      $port_value[$col] = $input_pat[$ref_var[1][$i]][0];
      $col++;
    }
  }
  my $loop_cont     = 1;
  $loop_cnt_ctrl[$total_input-1] = 1;
  while ($loop_cont == 1) {
    $loop_cont = 0;
    for (my $i1=$total_input-1;$i1>=0;$i1--){
      for(my $i2=0;$i2<$port_range[$i1];$i2++){
        if($port_loop_cnt[$i1]==$i2){
          $port_value[$i1] = $input_pat[$port_col[$i1]][$i2];
          last;
        }
      }
      if ($port_loop_cnt[$i1] >= ($port_range[$i1]-1)){
        $port_break[$i1] = 1;
      }else{
        if ($loop_cnt_ctrl[$i1] == 1) {
          $port_loop_cnt[$i1] = $port_loop_cnt[$i1] + 1;
        }
      }
    } # end for
    # calculate expression with input value
    my $vala = $a;
    if ($a =~ /^\(.*\)$/){
      $vala = calc_expr($a,\@port_name,\@port_value,\@ref_var,$vtl,$ptbl,$rnm,$blank_error,$clock_info_);
    }
    $expr_result{"$vala"} = $vala if (!exists $expr_result{"$vala"});
    my $next_flag = 1;
    for (my $i1=$total_input-1;$i1>=0;$i1--){
      $next_flag = $next_flag & $port_break[$i1];
    }
    if ($next_flag == 1){
      $loop_cont=0;
    } else{
      $loop_cont=1;
      my $disable_cnt=0;
      for (my $i1=$total_input-1;$i1>=0;$i1--){
        $next_flag = 1;
        my $disable_process_loop_ctrl = 0;
        for (my $i2=$total_input-1;$i2>=0;$i2--){
          if ($i2 >= $i1){
            $next_flag = $next_flag & $port_break[$i2];
          }
        }
        if ($port_break[$i1] == 1){
          if($next_flag == 1){
            for (my $i2=$i1-1;$i2>=0;$i2--){
              if ($port_break[$i2] == 1){
                $disable_process_loop_ctrl = 1;
                last;
              }else{
                if ($i1 == $total_input - 1){
                  $disable_cnt = 1;
                }
                last;
              }
            }
            if($disable_process_loop_ctrl eq "0"){
              for (my $i2=$total_input-1;$i2>=$i1;$i2--){
                $port_loop_cnt[$i2] = 0;
                $port_break[$i2] = 0;
              }
              for (my $i2=$i1;$i2>=0;$i2--){
                $loop_cnt_ctrl[$i2] = 0;
              }
              $loop_cnt_ctrl[$total_input-1] = 1;
              $port_loop_cnt[$i1-1]++;
            }
          } else{
            if ($loop_cnt_ctrl[$total_input-1] == 0 && $disable_cnt == 0){
              $port_loop_cnt[$total_input-1]++;
            }
            for (my $i2=$total_input-1;$i2>=0;$i2--){
              $loop_cnt_ctrl[$i2] = 0;
            }
            $port_break[$total_input-1] = 0;
            $loop_cnt_ctrl[$total_input-1] = 1;
          }
        }
      }
    }
  }
  return (%expr_result);
}

sub get_pattern{
  my ($exp, $idx, $en_char, @pr) = @_;
  my %pattern;
  my $key="";
  my $att = $pr[6][$idx]; # port real attribute
  my $cr = $pr[5][$idx]; # port care range
  $exp =~ s/^_*//; # remove "_" if existed
  if ($exp =~ /^\*$/){ # process *
    $pattern{"$exp"}=$exp if ($en_char eq "1");
    if ($pr[2][$idx] == 0){ # normal port
      $pattern{"0"}= "0";
      $pattern{"1"}= "1";
      $pattern{"x"} = "x" if ($cr == 3 || $cr == 4);
      $pattern{"z"} = "z" if ($cr == 4);
    }elsif ($pr[2][$idx] == 1){ # real port
      $att =~ s/^.*\(//;
      $att =~ s/\).*$//;
      my ($min, $max, $def_step)=split(",",$att);
      my $rval=$min;
      while ($rval<$max){
        $key = eval($rval);
        $pattern{"$key"} = $key;
        $rval=$rval+$def_step;
      }
      $pattern{"x"} = "x";
    }
  }elsif ($exp =~ /^(-|S)$/i){ # process - or S
    if ($pr[2][$idx] == 0){ # normal port
      $pattern{"$exp"}=$exp if ($en_char eq "1");
      $pattern{"0"}= "0";
      $pattern{"1"}= "1";
    }elsif ($pr[2][$idx] == 1){ # real port
      $att =~ s/^.*\(//;
      $att =~ s/\).*$//;
      my ($min, $max, $def_step)=split(",",$att);
      $pattern{"$exp"}=$exp if ($en_char eq "1");
      $key=eval($min);
      $pattern{"$key"}= $key;
      $key=eval($max);
      $pattern{"$key"}= $key;
      $pattern{"x"} = "x" if ($cr == 3 || $cr == 4);
      $pattern{"z"} = "z" if ($cr == 4);
    }
  }elsif ($exp =~ /^EXP_NOT_/i){ # process EXP_NOT_@_VAL (@=0/1/x/z)
    my $val = $exp;
    $val =~ s/EXP_NOT_//;
    $val =~ s/_.*$//;
    if ($val ne "0") {
      $pattern{"0"}= "0";
    }
    if ($val ne "1") {
      $pattern{"1"}= "1";
    }
    if ($val !~ /x/i) {
      $pattern{"x"} = "x" if ($cr == 3 || $cr == 4);
    }
    if ($val !~ /z/i) {
      $pattern{"z"} = "z" if ($cr == 4);
    }
  }elsif ($exp =~ /^ramp\(\s*\d*\.?\d+\s*,\s*\d*\.?\d+\s*,\s*\d*\.?\d+\s*\)$/ && $pr[2][$idx] == 1){ # process ramp wave in input
    $att = $exp;
    $att =~ s/^.*\(//;
    $att =~ s/\).*$//;
    my ($min, $max, $def_step)=split(",",$att);
    my $rval=$min;
    while ($rval<$max){
      $key = eval($rval);
      $pattern{"$key"} = $key;
      $rval=$rval+$def_step;
    }
  }elsif ($exp =~ /^(x|z)$/i){ # process x or z
    $key = lc($exp);
    $pattern{"$key"}=$key;
  }elsif ($exp =~ /^(\d*\.)?\d+/){ # process normal value
    $key = eval($exp);
    $pattern{"$key"}=$key;
  }else{ #expresion of output port
    $pattern{"$key"}=$exp;
  }
  return %pattern;
}

sub get_input_pattern{
  my ($a, $b, $c, $r)=@_;
  my @ina = @$a;
  my @inb = @$b;
  my @io  = @$c;
  my @port_ref=@$r;
  my @pattern=() x scalar(@ina);
  for (my $j=0;$j<scalar(@ina);$j++){
    if ($io[$j] !~ /power|ground|input|inout|electrical_in|output|electrical_out/){ # next column if not input/output
      @{$pattern[$j]} = ();
    }else{
      my %var   = get_pattern($ina[$j],$j,0,@port_ref);
      my %check = get_pattern($inb[$j],$j,0,@port_ref);
      foreach my $key (keys %var){
        push(@{$pattern[$j]},$key) if (exists $check{"$key"});
      }
    }
  }
  return @pattern;
}

sub found_variable{#[0] variable [1] variable table [2] port list
  my ($varname, $vt, $pl)=@_;
  my @variable=@$vt;
  my @port_list=@$pl;
  my $found =0;
  my $expression="";
  if (!(@variable == 0)){
    for(my $j=0;$j<scalar(@{$variable[0]});$j++){
      if ($variable[0][$j] eq $varname){
        $found++;
        $expression=$variable[1][$j];
      }
    }
  }
  foreach my $name (@port_list){
    if ($varname eq $name){
      $found++;
      $expression=$varname;
      last;
    }
  }
  return($found, $expression);
}
sub found_register{#[0] register [1] table info
  my ($regname, $tbl_info)=@_;
  my @table_info=@$tbl_info;
  my $found =0;
  my $expression="";
  if (!(@table_info == 0)){
    for(my $j=0;$j<scalar(@{$table_info[0]});$j++){
      if ($table_info[1][$j] eq $regname && $table_info[0][$j] eq "reg"){
        $found++;
        $expression=$table_info[1][$j];
      }
    }
  }
  return($found, $expression);
}

sub ReplaceString{ # [0] truth table [1] port table [2] option -rnm
  my ($tbl, $ptbl, $rnm, $extract_all) = @_;
  my @table=@$tbl;
  my @port_table=@$ptbl;
  my $continue=0;
  my $width_check = 1;
  if ($extract_all eq "1"){
    $width_check = 0;
  }
  my @port_ref = GetPortRefTable($table[1],\@table,\@port_table,$rnm);
  @table=extract_S_character(\@table,\@port_table,$rnm,$extract_all);
  while(check_pattern_exist_in_table($width_check,"S","",\@table,\@port_ref,0,1) == 1){ # do not check S for real port
    @table=extract_S_character(\@table,\@port_table,$rnm,$extract_all);
  }
  @table=extract_cross_character(\@table,\@port_table,$rnm,$extract_all);
  while(check_pattern_exist_in_table($width_check,"-","",\@table,\@port_ref,1,1) == 1){
    @table=extract_cross_character(\@table,\@port_table,$rnm,$extract_all);
  }
  return @table;
}

sub check_pattern_exist_in_table{
  my ($width_check, $pattern, $refrow, $tbl_,$pr_,$en_check_real, $exact_match)=@_;
  my @table=@$tbl_;
  my @port_ref=@$pr_;
  if ($refrow eq ""){
    $refrow=2;
  }
  for (my $col=2;$col<scalar(@{$table[1]});$col++){
    if ((defined $table[0][$col]) and ($table[0][$col] !~ /action|message|disable|control|assert_control|control_n|assert_control_n/) and ($table[0][$col] ne "")){
      for(my $row=$refrow;$row<scalar(@table);$row++){
        next if ($port_ref[2][$col] eq "1" && $en_check_real eq "0" && $exact_match eq "1");
        if (($table[$row][$col] =~ /^$pattern$/i and $exact_match eq "1")
         or ($table[$row][$col] =~ /$pattern/i and $exact_match eq "0")){
          if ($width_check eq "1") {
            return 1 if ($table[1][$col] =~ /\w+\[\d+:\d+\]/);
          } else{
            return 1;
          }
        }
      }
    }
  }
  return 0;
}

sub extract_S_character{
  my ($tbl, $ptbl,$rnm,$extract_all) = @_;
  my @table=@$tbl;
  my @port_table=@$ptbl;
  my @port_ref = GetPortRefTable($table[1],\@table,$ptbl,$rnm);
  my @new_table=();

  for (my $row=0;$row<scalar(@table);$row++){
    if ($row<2){# copy title lines
      push(@new_table, [@{$table[$row]}]);
    }else{ # check patterns
      my $is_found = 0;
      for (my $col=0;$col<scalar(@{$table[$row]});$col++){
        next if ((defined $port_ref[2][$col]) && ($port_ref[2][$col] eq 1));
        if ($table[$row][$col] eq "S"){
          my $width = &get_port_width($table[1][$col],@port_table);
          if ($width > 1 || $extract_all eq "1"){
            if($table[1][$col] =~ /\[\d+:\d+\]/ || $extract_all eq "1"){ # multiple bitwidth
              $is_found = 1;
              my $port_index = (split(/\[/,$table[1][$col]))[1];
              if ($table[1][$col] =~ /\[\d+:\d+\]/){
                $port_index =~ s/].*$//;
                my ($max,$min) = split(/:/,$port_index);
                $width = $max-$min+1;
              }else{
                $width = 1;
              }
              # copy 2 lines, and replace S by 0,1
              foreach my $num (0..((1<<$width)-1)){
                my @temp_row=();
                foreach my $tmp (@{$table[$row]}){
                  $temp_row[scalar(@temp_row)]=$tmp;
                }
                if($width>1){
                  $temp_row[$col]=sprintf("b%b",$num);
                }else{
                  $temp_row[$col]=$num;
                }
                push(@new_table, [@temp_row]);
              }
              last;#if there are 2 S in a row, replace former first, latter later.
            }
          }
        }
      }
      if($is_found==0){
       push(@new_table,[@{$table[$row]}]);
      }
    }
  }
  return @new_table;
}
sub extract_cross_character{
  my ($tbl, $ptbl, $rnm, $extract_all) = @_;
  my @table=@$tbl;
  my @port_table=@$ptbl;
  my @new_table=();
  for (my $row=0;$row<scalar(@table);$row++){
    if ($row<2){# copy title lines
      push(@new_table, [@{$table[$row]}]);
    }else{ # check patterns
      my $is_found = 0;
      for (my $col=0;$col<scalar(@{$table[1]});$col++){
        if ($table[$row][$col] =~ /^_?-$/){
          my $prefix = "";
          $prefix = "_" if ($table[$row][$col] =~ /^_/);
          my $is_real_port=0;
          my @threshold=();
          if ($rnm == 1){
            for (my $k=0;$k<scalar(@{$port_table[0]});$k++){
              if (&cmp_port_name($table[1][$col],$port_table[10][$k]) == 1){
                if($port_table[13][$k] ne "-"){ # real port
                  if($table[1][$col] =~ /\[\d+:\d+\]/ || $extract_all eq "1"){ # multiple bitwidth
                    $is_found = 1;
                    $is_real_port=1;
                    @threshold=($port_table[13][$k],$port_table[14][$k]);
                    @threshold=($port_table[13][$k],$port_table[14][$k],"X") if ($port_table[5][$k] =~ /^x$/i);
                    @threshold=($port_table[13][$k],$port_table[14][$k],"X","Z") if ($port_table[5][$k] =~ /^z$/i);
                    last;
                  }
                }
              }
            }
          }
          if($is_real_port==1){
            foreach my $num (@threshold){
              my @temp_row=();
              foreach my $tmp (@{$table[$row]}){
                $temp_row[scalar(@temp_row)]=$tmp;
              }
              $temp_row[$col]=$prefix.$num;
              push(@new_table, [@temp_row]);
            }
          }else{
            my $width = &get_port_width($table[1][$col],@port_table);
            if ($width > 1 || $extract_all eq "1"){
              if($table[1][$col] =~ /\[\d+:\d+\]/ || $extract_all eq "1"){ # multiple bitwidth
                $is_found = 1;
                if ($table[1][$col] =~ /\[\d+:\d+\]/ || $table[1][$col] =~ /\[\d+\]/) {
                  my $port_index = (split(/\[/,$table[1][$col]))[1];
                  $port_index =~ s/].*$//;
                  if ($table[1][$col] =~ /\[\d+:\d+\]/){
                    my ($max,$min) = split(/:/,$port_index);
                    $width = $max-$min+1;
                  }elsif($table[1][$col] =~ /\[\d+\]/){
                    $width = 1;  
                  }
                }
                # copy 2 lines, and replace - by 0,1
                foreach my $num (0..((1<<$width)-1)){
                  my @temp_row=();
                  if(($num==0)||($num==(1<<$width)-1)){
                    foreach my $tmp (@{$table[$row]}){
                      $temp_row[scalar(@temp_row)]=$tmp;
                    }
                    if($width>1){
                      $temp_row[$col]=sprintf("b%b",$num);
                      $temp_row[$col]=$prefix.$temp_row[$col];
                    }else{
                      $temp_row[$col]=sprintf("%b",$num);
                      $temp_row[$col]=$prefix.$temp_row[$col];
                    }
                    push(@new_table, [@temp_row]);
                  }
                }
                last;
              }
            }
          }
        }
      }
      if ($is_found == 0){
       push(@new_table,[@{$table[$row]}]);
      }
    }
  }
  return @new_table;
}

sub ReplaceInputVariable{#[0] truth table [1] variable table [2] port table
  my($xls, $tt, $vt, $pt, $rnm, $blank_error,$clock_info_)=@_;
  my @table=@$tt;
  my @variable=@$vt;
  my @port=@$pt;
  my $continue=0;
  my @port_ref = GetPortRefTable($table[1],\@table,\@port,$rnm);
  my @port_list=();
  for (my $j=2;$j<scalar(@{$port_ref[0]});$j++){
    if($port_ref[4][$j] !~ /^-2/){
      push(@port_list,$table[1][$j]);
    }
  }
  # replace value for variable
  ($continue,@table)=extract_dontcare_truth_table(\@table, \@variable, \@port, $rnm,\@port_ref,\@port_list);
  while($continue !=0){
    ($continue, @table)=extract_dontcare_truth_table(\@table, \@variable, \@port, $rnm,\@port_ref,\@port_list);
  }
  @table=calculate_variable_truth_table(\@table, \@variable, \@port_list, \@port_ref);
  while(check_pattern_exist_in_table(0,".*\{.*\}.*",2,\@table,\@port_ref,1,1) == 1){
    @table=get_ref_variable($xls,$rnm,\@table,\@port,$vt,\@port_ref, $blank_error,$clock_info_);
  }
  return @table;
}

sub get_ref_variable{
  my ($xls, $rnm, $tbl_, $ptbl_,$vt,$pr, $blank_error,$clock_info_)=@_;
  my @table=@$tbl_;
  my @port_table=@$ptbl_;
  my @port_ref=@$pr;
  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$parser->parse($xls) or die "ERROR ::: $xls is not found.\n";
  my @sheet_name_list = &GetSheetNameList($xls);
  my @out=();
  my $row=2;
  my $col=0;
  for(my $i=0;$i<scalar(@{$table[0]});$i++){
    $out[0][$col]=$table[0][$i];
    $out[1][$col]=$table[1][$i];
    $col++;
  }
  for(my $i=2;$i<scalar(@table);$i++){
    $col=0;
    if(grep(/\{/,@{$table[$i]})<1){
      for(my $j=0;$j<scalar(@{$table[$i]});$j++){
        $out[$row][$col]=$table[$i][$j];
        $col++;
      }
      $row++;
      next;
    }
    for(my $j=2;$j<scalar(@{$table[$i]});$j++){
      if($table[$i][$j]=~/{.*}/){
        my $exp = $table[$i][$j];
        $exp =~ s/{\s*/{/g;
        $exp =~ s/\s*}/}/g;
        my ($ref_sheet,$ref_var,$ref_exp) = &get_ref_sheet($exp);
        my @tm=MakeTruthTable($xls,$ref_sheet,0,0,$rnm,\@port_table,$ref_var,$blank_error,$clock_info_);  # fusion table
        @tm=ReplaceInputVariable($xls,\@tm,$vt,\@port_table, $rnm, $blank_error,$clock_info_);
        my ($check, $ret_var, @rep_line)=&get_ref_line($table[0],$table[1],$table[$i],\@tm,$xls,$ref_var,$xls,$ptbl_,$rnm,$blank_error,$clock_info_);
        if($check eq "-1"){
          print("WARNING ::: [$table[$i][0]] No reference value for row $table[$i][1].\n");
        }else{
          for(my $l=2;$l<scalar(@rep_line);$l++){
            $col=0;
            for(my $m=0;$m<scalar(@{$table[$i]});$m++){
              my $es=0;
              for(my $k=0;$k<scalar(@{$rep_line[$l]});$k++){
                next if(!defined $table[1][$m]);
                if ($table[0][$m] eq "Sheet" || $table[0][$m] eq "line"){
                  $out[$row][0]=$table[$i][0];
                  $out[$row][1]=$table[$i][1]."($rep_line[$l][0]/$rep_line[$l][1])";
                }
                if($table[1][$m] eq $rep_line[1][$k]){
                  if ($col > 1){
                    $out[$row][$col]=$rep_line[$l][$k];
                  }
                  $col++;
                  $es=1;
                  last;
                }
              }
              if($es==0){
                if ($table[$i][$m] =~ /\{$ref_exp\}/){
                  for(my $k=0;$k<scalar(@{$rep_line[$l]});$k++){
                    if($ref_var eq $rep_line[1][$k]){
                      $rep_line[$l][$k] =~ s/^_*//; # variable must not contain "_"
                      $out[$row][$col]=$table[$i][$m];
                      $out[$row][$col]=~s/\{$ref_exp\}/$rep_line[$l][$k]/g;
                      my $tmp_exp = $out[$row][$col];
                      if($tmp_exp !~ /\{.*\}/){
                        my $cal_exp=$tmp_exp;
                        $cal_exp=~s/^_//;
                        if ($cal_exp=~/^(x|z)$/i){
                          $out[$row][$col]=$cal_exp;
                        }else{
                          my $val=eval($cal_exp);
                          if ((!defined $val) || ($val eq "")){
                            printf("ERROR ::: Cannot calculate value of \"%s\" at Table $out[$row][0]/line $out[$row][1] because of invalid expression.\n",$tmp_exp);
                            exit(1);
                          }else{
                            $out[$row][$col]=$val;
                          }
                        }
                      }
                      last;
                    }
                  }
                }else{
                  $out[$row][$col]=$table[$i][$m];
                }
                $col++;
              }
            }
            $row++;
          }
        }
        last;
      }
    }
  }
  return @out;
}

sub get_ref_sheet{
  my $exp = $_[0];
  my $ref_sheet="";
  my $ref_var="";
  my $ref_exp="";
  if($exp=~/{.*}/){
    $ref_exp=$exp;
    $ref_exp=~s/^[^{]*{//;
    $ref_exp=(split("}",$ref_exp))[0];
    ($ref_sheet,$ref_var)=split(",",$ref_exp); #get ref sheet,ref variable
  }
  return ($ref_sheet,$ref_var,$ref_exp);
}

sub extract_dontcare_truth_table{#[0] truth table [1] variable table [2] port table
  my ($tt, $vt, $pt, $rnm, $pr, $pl)=@_;
  my @table=@$tt;
  my @variable=@$vt;
  my @port=@$pt;
  my @port_ref=@$pr;
  my @port_list=@$pl;
  my @new_table=();
  my $continue=0;
  for(my $row=0;$row<scalar(@table);$row++){
    if ($row <2){# copy first 4 lines
      push(@new_table,[@{$table[$row]}]);
    }else{# check patterns
      if (count_expression_inrow($table[$row],\@port_ref) ne "0"){#has []
        my $is_found = 0;
        my ($elm_list,$expr_list)=list_element_in_expr($table[$row],\@variable,\@port_list,\@port,$pr,\@new_table);
        my @ret_expr=@$expr_list;
        for(my $col=2;$col<scalar(@{$table[0]});$col++){
          for(my $i=0;$i<scalar(@ret_expr);$i++){
             if ($col == $ret_expr[$i][0]){
                $table[$row][$col] = $ret_expr[$i][1];
                last;
             }
          }
        }
        if (scalar(@{$elm_list}) > 0){
          for(my $col=2;$col<scalar(@{$table[1]});$col++){
            if($port_ref[2][$col] !~ /^0$|^1$/){
              next;
            }
            my @var_elm_list=@$elm_list;
            my $portname=$table[1][$col];
            if ($table[$row][$col] =~ /^_?(\*|-|S|\[?ramp.*)$/ && grep (/^\Q$portname\E$/,@var_elm_list)>0){
              my $prefix = "";
              my $val = $table[$row][$col];
              $prefix="_" if ($val =~ /^_/);
              $val =~ s/^_*// if ($val =~ /^_/);
              $is_found = 1;
              $continue=1;# continue extract at next time
              my $rmin="";
              my $rmax="";
              my $def_step="";
              if ($port_ref[2][$col] eq "1"){ # real port
                ($rmin,$rmax,$def_step)=split(/,/,$port_ref[6][$col]);
              }
              my @care_range=("0","1");
              push(@care_range,"x")       if($port_ref[5][$col] eq "3");
              push(@care_range,("x","z")) if($port_ref[5][$col] eq "4");
              if ($val eq "\*"){
                if ($port_ref[2][$col] eq "1"){ # real port
                  for(my $i=0;$i<scalar(@care_range);$i++){
                    if($care_range[$i] =~ "1"){
                      next;
                    }
                    my @temp_row=();
                    foreach my $tmp (@{$table[$row]}){
                      $temp_row[scalar(@temp_row)]=$tmp;
                    }
                    if($care_range[$i] eq "0"){
                      $temp_row[$col]=$prefix."ramp($rmin,$rmax,$def_step)";#replace * by ramp wave
                    }else{
                      $temp_row[$col]=$prefix.$care_range[$i];#replace * by x,or z
                    }
                    push(@new_table, [@temp_row]);
                  }
                }else{
                  for(my $i=0;$i<scalar(@care_range);$i++){
                    my @temp_row=();
                    foreach my $tmp (@{$table[$row]}){
                      $temp_row[scalar(@temp_row)]=$tmp;
                    }
                    $temp_row[$col]=$prefix.$care_range[$i];#replace * by 0,1,x,or z
                    push(@new_table, [@temp_row]);
                  }
                }
              }elsif ($val =~ /^(-|S)$/){
                if ($port_ref[2][$col] eq "1"){ # real port means threshold value
                  $care_range[0] = $rmin;
                  $care_range[1] = $rmax;
                }else{
                  @care_range=("0","1"); # normal port mean 0/1
                }
                for(my $i=0;$i<scalar(@care_range);$i++){
                  my @temp_row=();
                  foreach my $tmp (@{$table[$row]}){
                    $temp_row[scalar(@temp_row)]=$tmp;
                  }
                  $temp_row[$col]=$prefix.$care_range[$i];#replace * by 0,1,x,or z
                  push(@new_table, [@temp_row]);
                }
              }elsif(($table[$row][$col] =~ /ramp\(\s*\d*.?\d+\s*,\s*\d*.?\d+\s*,\s*\d*.?\d+\s*\)/) && ($rnm == 1)){
                my $exp = $table[$row][$col];
                $exp =~ s/^.*\(//;
                $exp =~ s/\).*$//;
                my ($min, $max, $def_step)=split(",",$exp);
                my $rval=$min;
                while ($rval<$max){
                  my @temp_row=();
                  foreach my $tmp (@{$table[$row]}){
                    $temp_row[scalar(@temp_row)]=$tmp;
                  }
                  $temp_row[$col]=$prefix.$rval;#replace ramp wave by value
                  push(@new_table, [@temp_row]);
                  $rval=$rval+$def_step;
                }
              }
              last; # break for next row
            }
          }
        }
        if ($is_found==0){# not need to replace
          push(@new_table,[@{$table[$row]}]);
        }
      }else{# no [] in row
        push(@new_table,[@{$table[$row]}]);
      }
    }
  }
  return ($continue, @new_table);
}

sub count_expression_inrow{# [0] row id [1] truth table
  my($data, $pr)=@_;
  my @row_data=@$data;
  my @port_ref=@$pr;
  for (my $j=0;$j<scalar(@{$port_ref[0]});$j++){
    if ($port_ref[2][$j] !~ /^-1$|^-2$/ && $row_data[$j] =~ /^_?\[.*\]$/){
      return 1;
    }
  }
  return 0;
}

sub list_element_in_expr{# [0] table row [1] variable table [1] port list [2] port table
  my($tr, $vt, $pl, $ptbl, $pr, $tbl_info)=@_;
  my @table_row=@$tr;
  my @variable=@$vt;
  my @port_list=@$pl;
  my @port_table=@$ptbl;
  my @port_ref = @$pr;
  my @table_info = @$tbl_info;
  my @list=();
  my @ret_expr=();
  my $final_exp="";
  my $row = 0;
  for(my $col=2;$col<scalar(@table_row);$col++){
    my $store_expr = $table_row[$col];
    my $found=1;
    my $exp="";
    my $expr=$table_row[$col];
    my $extract_en = 1;
    if ($table_row[$col]=~/^_?\[.+\]$/){ # detect expression by [.*] or _[.*]
      $final_exp=$expr;
    }
    if ($table_row[$col]=~/^_\[.+\]$/){
      $extract_en = 0;
    }
    while ($found==1){
      if ($expr=~/^_?\[.+\]$/){ # detect expression by [.*] or _[.*]
        $expr=~s/^_//;
        $expr=~s/^\[//;
        $expr=~s/\]$//;
        $expr=~s/\<[^<>]*>//g;
        $expr=~s/\{[^\}]*\}//g;
        if($expr=~/^\w+\[\d+\]$/){ # process single port name (multiple bitwidth)
          ($found, $exp)=found_variable($expr, \@variable,\@port_list);
          if ($port_ref[4][$col] ne "1" && $extract_en eq "1" && $exp =~ /^\w+(\[\d+\])?$/){
            push(@list, $exp);
          }
          if($found == 1){ # stop searching
            $found=0;
            $final_exp=~s/\b\Q$expr\E/$exp/g;
            $expr=~s/\b\Q$expr\E//g;
          }else{
            print("ERROR ::: Invalid expression \"$store_expr\" in Table $table_row[0]/line $table_row[1].\n");
            exit(1);
          }
        }else{ # process expression
          # process port name (multiple bitwidth) in expression
          while ($expr =~ /\w+\[(\d+:)?\d+\]/) { 
            my $tmp = $expr;
            # get first port name
            $tmp = (split(/\]/,$expr))[0];
            if ($tmp !~ /\w+\[(\d+:)?\d+$/){
              print("ERROR ::: Invalid expression \"$store_expr\" in Table $table_row[0]/line $table_row[1].\n");
              exit(1);
            }
            my $is_found=0;
            my $new_exp="";
            my @tmp_split = split(/\W+/,(split(/\[/,$tmp))[0]);
            my $port_name = $tmp_split[scalar(@tmp_split)-1];
            my $port_index = (split(/\[/,$tmp))[1];
            $tmp = $port_name."[".$port_index."]";
            if ($port_index =~ /^\d+:\d+$/) {
              my ($max, $min) = split(/:/,$port_index);
              for (my $i=$min;$i<=$max;$i++){
                my $tmp_name = $port_name."[".$i."]";
                my $index = $i - $min;
                ($found, $exp)=found_variable($tmp_name, \@variable,\@port_list);
                if ($port_ref[4][$col] ne "1" && $extract_en eq "1" && $exp =~ /^\w+(\[\d+\])?$/){
                  push(@list, $exp);
                }
                if($found == 1){
                  $is_found = 1;
                  if ($new_exp eq ""){
                    $new_exp = "($exp&1)";
                  }else{
                    $new_exp = "(($exp&1) << $index) | $new_exp";
                  }
                }
              }
              $new_exp = "($new_exp)";
            }else{
              ($found, $exp)=found_variable($tmp, \@variable,\@port_list);
              if ($port_ref[4][$col] ne "1" && $extract_en eq "1" && $exp =~ /^\w+(\[\d+\])?$/){
                push(@list, $exp);
              }
              if($found == 1){
                $is_found=1;
                $new_exp=$exp;
              }
            }
            if($is_found == 1){
              $final_exp=~s/\b\Q$tmp\E/$new_exp/g;
              $expr =~ s/\b\Q$tmp\E//g;
            }else{
              print("ERROR ::: Invalid expression \"$expr\" in Table $table_row[0]/line $table_row[1].\n");
              exit(1);
            }
          }
          # process other port name (single bitwidth), variable
          my @string=split(/\W+/,$expr);
          my @remain_string =();
          for (my $i=0; $i<scalar(@string);$i++){
            # process multiple port width but port index is not defined
            my $is_found=0;
            my $new_exp="";
            foreach my $port_name (@port_list){
              if (cmp_port_name($port_name,$string[$i])){
                if ($port_name ne $string[$i] and $port_name =~ /^\w+\[\d+\]$/){
                  for (my $k=0;$k<scalar(@{$port_table[0]});$k++){
                    if (cmp_port_name($string[$i],$port_table[0][$k]) == 1){
                      my $msb=(split(":",$port_table[11][$k]))[0];
                      my $lsb=(split(":",$port_table[11][$k]))[1];
                      for (my $l=$lsb;$l<=$msb;$l++){
                        my $tmp_name = $string[$i]."[".$l."]";
                        my $index = $l - $lsb;
                        ($found, $exp)=found_variable($tmp_name, \@variable,\@port_list);
                        if ($port_ref[4][$col] ne "1" && $extract_en eq "1" && $exp =~ /^\w+(\[\d+\])?$/){
                          push(@list, $exp);
                        }
                        if($found == 1){
                          $is_found = 1;
                          if ($new_exp eq ""){
                            $new_exp = "($exp&1)";
                          }else{
                            $new_exp = "(($exp&1) << $index) | $new_exp";
                          }
                        }else{
                          print("ERROR ::: Invalid expression \"$store_expr\" in Table $table_row[0]/line $table_row[1].\n");
                          exit(1);
                        }
                      }
                      $new_exp = "($new_exp)";
                      if($is_found == 1){
                        $final_exp=~s/\b\Q$string[$i]\E\b/$new_exp/g;
                        $expr=~s/\b\Q$string[$i]\E\b//g;
                      }
                      last;
                    }
                  }
                }
                last;
              }
            }
            if($is_found == 0){
              if ($string[$i] !~ /^\d*\.?\d+$/ && $string[$i] ne ""){
                push(@remain_string,$string[$i]);
              }else{
                $expr=~s/\b\Q$string[$i]\E\b//g;
              }
            }
          }
          @string = @remain_string;
          for (my $i=0; $i<scalar(@string);$i++){
            ($found, $exp)=found_variable($string[$i], \@variable,\@port_list);
#            ($found, $exp)=found_variable($string[$i], \@variable,\@port_table);
            if($found == 1){
              if ($port_ref[4][$col] ne "1" && $extract_en eq "1" && $exp =~ /^\w+(\[\d+\])?$/){
                push(@list, $exp);
              }
              if (grep (/^\Q$exp\E$/,@port_list)>0){
                $expr=~s/\b\Q$string[$i]\E\b//g;
              }else{
                if ($port_ref[4][$col] eq "1" || $extract_en eq "0"){
                  $exp =~ s/\]$/\$/ if ($exp =~ /^\[.*\]$/);
                  $exp =~ s/^\[/#/;
                  # Replace reference variable table by variable name
                  if ($exp =~ /^<.*>$/){
                    $exp =~ s/^<.*,//;
                    $exp =~ s/>$//;
                    $expr=~s/\Q$string[$i]\E//g;
                  }
                }else{
                  $exp =~ s/\]$// if ($exp =~ /^\[.*\]$/);
                  $exp =~ s/^\[//;
                  # Replace reference variable table by variable name
                  if ($exp =~ /^<.*>$/){
                    $exp =~ s/</{/;
                    $exp =~ s/>/}/;
                    $expr=~s/\Q$string[$i]\E//g;
                  }
                }
                if ($exp !~ /^\d*\.?\d+$/){
                  $expr=~s/\b\Q$string[$i]\E\b/$exp/g;
                }else{
                  $expr=~s/\b\Q$string[$i]\E\b//g;
                }
              }
              $final_exp=~s/\Q$string[$i]\E/$exp/;
            }elsif($string[$i] =~ /ramp/){ # process ramp wave expression
              $expr=~s/ramp\(\s*\d*\.?\d+\s*,\s*\d*\.?\d+\s*,\s*\d*\.?\d+\s*\)//;
            }elsif($string[$i]=~/^[xz]$/i){
              $expr="[".$expr."]";
            }else{
              ($found, $exp)=found_register($string[$i],\@table_info);
              if($found ==1){
                $expr=~s/\b\Q$string[$i]\E\b//g;
                push(@list, $exp);
              }else{
                print("ERROR ::: Invalid expression \"$store_expr\" in Table $table_row[0]/line $table_row[1].\n");
                exit(1);
              }
            }
          }
        }
        if($expr=~/\w+/){
          $expr="[".$expr."]";
        }
      }else{
        $found=0;
      }
    }
    if ($table_row[$col]=~/^_?\[.+\]$/){ # detect expression by [.*] or _[.*]
      if($final_exp ne ""){
        push(@ret_expr,[$col,$final_exp]);
      }
    }
  }
  return (\@list,\@ret_expr);
}

sub get_port_width{#[0] port name [1] port table
  my($portname, @port)=@_;
  my $lv=0;
  my @care_list=();
  for (my $i=0; $i<scalar(@{$port[0]});$i++){
    if ($portname=~/\[/ && $portname=~/\]/){
      if(&cmp_port_name($portname,$port[10][$i])==1){
        my $msb=(split(":",$port[11][$i]))[0];
        my $lsb=(split(":",$port[11][$i]))[1];
        return ($msb-$lsb+1);
      }
    }else{
      if ($port[10][$i] eq $portname){
        return 1;
      }
    }
  }
}

sub get_port_type{#[0] port name [1] port table
  my($portname, @port)=@_;
  if (!defined $portname){
      return "";
  }
  for (my $i=0; $i<scalar(@{$port[0]});$i++){
    my $tmp_name=$portname;
    if($tmp_name =~ /\[.*\]/){
      $tmp_name=~s/\[.*\]//;
      $tmp_name=~s/\s*//;
    }
    if ($port[10][$i] eq $tmp_name){
      if($port[1][$i] eq "power" || $port[1][$i] eq "ground"){
        return $port[1][$i];
      }else{
        if ($port[1][$i] eq "electrical_in"){
          return "input";
        }elsif($port[1][$i] eq "electrical_out"){
          return "output";
        }else{
          return $port[1][$i];
        }
      }
    }
  }
  return "";
}

sub get_port_name{#[0] port name [1] port table
  my($sheet, $portname, $port_, $dup_check,$row,$col)=@_;
  my @port = @$port_;
  my $p_check=-1;
  my $port_type = get_port_type($portname, @port);
  for (my $i=0; $i<scalar(@{$port[0]});$i++){
    my $tmp_name=$portname;
    if($tmp_name =~ /\[.*\]/){
      $tmp_name=~s/\[.*\]//;
      $tmp_name=~s/\s*//;
      if ($port[10][$i] eq $tmp_name){
        if(grep(/^\Q$portname\E$/,@$dup_check) > 0 && $port_type ne "clock"){
          printf("ERROR ::: [$sheet] Port name \"%s\" was defined more than one time at %s.\n",$portname, &get_cell_pos($row,$col));
          exit(3);
        }
        push(@$dup_check,$portname);
        return $portname;
      }
    }else{
      if ($port[10][$i] eq $tmp_name){
        if($port[9][$i] eq -1){
          if(grep(/^\Q$portname\E$/,@$dup_check) > 0 && $port_type ne "clock"){
            printf("ERROR ::: [$sheet] Port name \"%s\" was defined more than one time at %s.\n",$portname, &get_cell_pos($row,$col));
            exit(3);
          }
          push(@$dup_check,$port[10][$i]);   
          return $port[10][$i];
        }else{
          my ($max,$min)=split(/:/,$port[11][$i]);
          for (my $k=$min;$k<=$max;$k++){
            my $name = $tmp_name."[$k]";
            if(grep(/^\Q$name\E$/,@$dup_check) > 0 && $port_type ne "clock"){
              printf("ERROR ::: [$sheet] Port name \"%s\" was defined more than one time at %s.\n",$portname, &get_cell_pos($row,$col));
              exit(3);
            }
            push(@$dup_check,$name);   
          }
          return $port[10][$i]."[".$port[11][$i]."]";
        }
      }
    }
  }
  return $p_check;
}

sub get_port_level{#[0] port name [1] port table
  my($portname, @port)=@_;
  my $lv=0;
  my @care_list=();
  for (my $i=0; $i<scalar(@{$port[0]});$i++){
    if ($port[0][$i] eq $portname){
      if($port[5][$i] =~ /^z$/i){
        $lv=4;
      }elsif($port[5][$i] =~ /^x$/i){
        $lv=3;
      }elsif($port[5][$i] =~ /^-$/i){
        $lv=2;
      }else{# oscillation port
        $lv=3 if ($port[2][$i] eq "D"); # Set x for digital oscillation port
        $lv=4 if ($port[2][$i] eq "A"); # Set x for analog oscillation port
      }

      if($lv == 2){
        @care_list=("0", "1");
      }elsif($lv == 3){
        @care_list=("0", "1", "X");
      }else{
        @care_list=("0", "1", "X", "Z");
      }
      return ($lv, @care_list);
    }
  }
}

sub check_oscillation_port{#[0] port name [1] port table
  my($portname, @port)=@_;
  my $result = "";
  if(!defined $portname){
      return $result;
  }
  for (my $i=0; $i<scalar(@{$port[0]});$i++){
    my $tmp_name=$portname;
    if($tmp_name =~ /\[.*\]/){
      $tmp_name=~s/\[.*\]//;
      $tmp_name=~s/\s*//;
    }
    if ($port[10][$i] eq $tmp_name){
      if ($port[12][$i] eq "1") {
        $result = 1;
      } else {
        $result = 0;
      }
      last;
    }
  }
  return $result;
}

sub get_latch_port{#[0] port table
  my @port = @_;
  for (my $j=0; $j<scalar(@{$port[0]});$j++){
    if ($port[17][$j] eq "1") {
      return $port[0][$j];
    }
  }
  return "";
}

sub calculate_variable_truth_table{#[0] truth table [1] variable table
  my ($tt, $vt, $pl, $pr)=@_;
  my @table=@$tt;
  my @variable=@$vt;
  my @port_list=@$pl;
  my @port_ref=@$pr;
  for(my $row=0;$row<scalar(@table);$row++){
    for(my $col=0;$col<scalar(@{$table[0]});$col++){
      if (!defined $table[0][$col] || ($table[0][$col] =~ /action|message|disable|control|assert_control|control_n|assert_control_n|FB/) || $table[0][$col] eq ""){
        next;
      }
      my $variable=$table[$row][$col];
      $variable=~s/^_//;
      my $calc_en = 1; # enable calculating variable
      if ($table[0][$col] =~ /output|power|ground/ || $table[$row][$col]=~/^_/){
        $calc_en = 0;
      }
      if ($table[$row][$col]=~/^_?\[.+\]$/){ # detect expression by [.*] or _[.*]
        $variable=~s/^\[//;
        $variable=~s/\]$//;
        my $exp=fusion_var_exp($variable, $row, \@variable, \@table, \@port_list, $calc_en);
        my $rep_exp=$exp;
        if($table[$row][$col]=~/^_/){
          $rep_exp="_".$rep_exp;
        }
        if ($exp =~ /^\s*(x|z)\s*$/i){
          $table[$row][$col]=lc($rep_exp);
        }else{
          if($exp =~ /{[^}]+}/){
            $table[$row][$col]=$rep_exp ;# calculate value of expression
          } else {
            if ($exp =~ /^ramp\(\s*\d*\.?\d+\s*,\s*\d*\.?\d+\s*,\s*\d*\.?\d+\s*\)$/){
              if($calc_en == 1){ # do not replace in case output port or inout port acts as output port
                $table[$row][$col]=~s/\[.*\]/$exp/;# calculate value of expression
              }
              $table[$row][$col]=~s/\]$/\)/ if($table[$row][$col]=~/^\[.*\]$/);
              $table[$row][$col]=~s/^\[/\(/;
            } elsif($exp =~ /^\[.*\]$/){
              my $fus_var=$exp;
              $fus_var =~ s/^\[//;
              $fus_var =~ s/\]$//;
              my $fus_exp=fusion_var_exp($fus_var, $row, \@variable, \@table, \@port_list, $calc_en);
              if ($fus_exp =~ /^[ ]*(x|z)[ ]*$/i){
                $table[$row][$col]=~s/\[.*\]/X/;
              }else{
                if ($calc_en eq "0"){
                  if ($fus_exp !~ /{[^}]+}/){
                    $table[$row][$col]=~s/\[.*\]/($fus_exp)/;
                  }
                }else {
                  my $val=eval($fus_exp);
                  if (($fus_exp eq "")||(!defined $val)){
                    print("ERROR ::: Cannot calculate value of \""); print $table[$row][$col]; print "\" at Table $table[$row][0]/line $table[$row][1] because of invalid expression.\n";
                    exit(1);
                  }else{
                    print("WARNING ::: Expression \"$variable\" contains negative value at Table $table[$row][0]/line $table[$row][1].\n") if ($val =~ /^-\d*.?\d+$/);
                    $table[$row][$col]=~s/\[.*\]/$val/;
                  }
                }
              }
            } else {
              if ($calc_en eq "0"){
                $table[$row][$col]=~s/\[.*\]/($exp)/;
              }else {
                my $val=eval($exp);
                if ((!defined $val)|| ($val eq "")){
                  print("ERROR ::: Cannot calculate value of \""); print $table[$row][$col]; print "\" at Table $table[$row][0]/line $table[$row][1] because of invalid expression.\n";
                  exit(1);
                }else{
                  print("WARNING ::: Expression \"$variable\" contains negative value at Table $table[$row][0]/line $table[$row][1].\n") if ($val =~ /^-\d*.?\d+$/);
                  $table[$row][$col]=~s/\[.*\]/$val/;
                }
              }
            }
          }
        }
      }
    }
  }
  return @table;
}

sub get_ref_list{
  my ($exp, $pr, $rv, $vtl) = @_;
  my @port_ref = @$pr;
  my @ref_var=@$rv;
  my %var_table_list=%$vtl;
  my $total_input=0;
  $exp =~ s/\s//g;
  my $index = 0;
  if (@ref_var != 0){
    $index = scalar(@{$ref_var[0]});
  }
  while ($exp =~ /\w+\[\d+\]/) { # seach port with multiple bit width
    my $port_name = (split(/\[/,$exp))[0];
    my $port_index= (split(/\[/,$exp))[1];
    my @tmp_split = (split(/\W+/,$port_name));
    $port_name = $tmp_split[scalar(@tmp_split)-1];
    $port_index =~ s/].*$//;
    $port_name = $port_name."[$port_index]";
    if (grep (/^\Q$port_name\E$/,@{$ref_var[0]}) < 1){
      $ref_var[0][$index] = $port_name;
      $ref_var[1][$index] = (grep (/^\Q$ref_var[0][$index]\E$/,@{$port_ref[0]}) > 0) ? get_port_col($ref_var[0][$index],0,@port_ref):"0";
      $ref_var[2][$index] = "1";
      $total_input++;
      $index++;
    }
    $exp=~ s/\b\Q$port_name\E//g;
  }
  my @string = split(/\W+/,$exp);
  for (my $i=0;$i<scalar(@string);$i++) { # seach port with single bit width or variable
    if ($string[$i]=~/^(\d*\.?\d+|x|z)$/i || $string[$i] eq ""){
      next;
    }
    if (grep (/^\Q$string[$i]\E$/,@{$ref_var[0]}) < 1){
      $ref_var[0][$index] = $string[$i];
      $ref_var[1][$index] = (grep (/^\Q$ref_var[0][$index]\E$/,@{$port_ref[0]}) > 0) ? get_port_col($ref_var[0][$index],0,@port_ref):"0";
      $ref_var[2][$index] = "1";
      $index++;
      $total_input++;
    }
  }
  for (my $i=0;$i<scalar(@{$ref_var[0]});$i++){
    if ($ref_var[1][$i] eq "0"){
      foreach my $key (keys %var_table_list) {
        my @var_table = @{$var_table_list{$key}};
        if (grep (/^\Q$ref_var[0][$i]\E$/,@{$var_table[1]}) > 0){
          $ref_var[1][$i] = "$key"; # index of varable table 
          $ref_var[2][$i] = "-1"; # index of varable table 
          $total_input--;
          for (my $j=2;$j<scalar(@{$var_table[0]});$j++){
            if (grep (/^\Q$var_table[1][$j]\E$/,@{$ref_var[0]}) < 1){
              $ref_var[0][$index] = $var_table[1][$j];
              $ref_var[1][$index] = get_port_col($var_table[1][$j],0,@port_ref);
              $ref_var[2][$index] = "-2";
              $index++;
              $total_input++;
            }
          }
          last;
        }
      }
    }
  }
  return ($total_input,@ref_var);
}

sub fusion_var_exp{ #[0] variable [1] row [2] variable table [3] truth table [4] port list
  my ($expr, $row, $vt, $tt, $pl, $calc_en)=@_;
  my @var_table=@$vt;
  my @table=@$tt;
  my @port_list=@$pl;
  my $found="";
  my $exp ="";

  if (grep(/^\Q$expr\E$/,@port_list)==1){ # process [<port_name>]
    ($found, $exp)=found_variable($expr, \@var_table,\@port_list);
    my $port_value=$table[$row][get_port_col($expr, 1, @table)];#1 is index or row having port names in truth table
    $port_value=bin2dec($port_value) if ($port_value=~/^b(0|1)+$/);
    # check port value is X or Z
    $port_value =~ s/^_*//;
    if ($port_value =~ /^[ ]*(x|z)[ ]*$/i){
      return "X";
    }else{
      if ($port_value=~ /^\[\w+\]$/){
        my $sub_exp=fusion_var_exp($port_value, $row, \@var_table, \@table, \@port_list, $calc_en);
        if ($sub_exp eq "X"){
          return "X";
        }else{
          $exp=~s/\Q$exp\E/$sub_exp/ if ($calc_en eq "1" || $sub_exp !~ /ramp|{.*}/);
        }
      }else{
        if ($calc_en eq "1"){
          $exp=~s/\Q$exp\E/$port_value/;
        } else {
          if ($port_value !~ /^(-|\*|S)$/){
            $exp=~s/\Q$exp\E/$port_value/;
          }
        }
      }
    }
    $expr = $exp;
  } else {
    my @string=();
    # process port name (multiple bitwidth) in expression
    $exp = $expr;
    while ($exp =~ /\w+\[(\d+:)?\d+\]/) { 
      my $tmp = $exp;
      # get first port name
      $tmp = (split(/\]/,$exp))[0];
      my @tmp_split = split(/\[/,$tmp);
      my $port_index = $tmp_split[scalar(@tmp_split)-1];
      @tmp_split = split(/\W+/,$tmp_split[scalar(@tmp_split)-2]);
      my $port_name = $tmp_split[scalar(@tmp_split)-1];
      $tmp = $port_name."[".$port_index."]";
      push(@string,$tmp);
      $exp =~ s/\Q$tmp\E//;
    }
    push(@string,split(/\W+/,$exp));
    for (my $i=0;$i<scalar(@string);$i++){# replace all port name in expression
      if (grep(/^\Q$string[$i]\E$/,@port_list)==1){# $string[$i] is a port
        my $port_value=$table[$row][get_port_col($string[$i], 1, @table)];#1 is index or row having port names in truth table
        $port_value =~ s/^_*//;
        $port_value=bin2dec($port_value) if ($port_value=~/^b(0|1)+$/);
        # check port value is X or Z
        if ($port_value =~ /^\s*(x|z)\s*$/i){
          return "X";
        }else{
          if ($port_value=~ /\[\w+.*\]/){
            my $sub_exp=fusion_var_exp($port_value, $row, \@var_table, \@table, \@port_list, $calc_en);
            if ($sub_exp eq "X"){
              return "X";
            }else{
#              $expr=~s/\Q$string[$i]\E/$sub_exp/;
              $expr=~s/\Q$string[$i]\E/$sub_exp/ if ($calc_en eq "1" || $sub_exp !~ /ramp|{.*}/);
            }
          }else{
            if ($calc_en eq "1"){
              $expr=~s/\Q$string[$i]\E/$port_value/;
            } else {
              if ($port_value !~ /(^-$|^\*$|^(RISE|FALL)$|^S$|ramp|{.*})/i){
                $expr=~s/\Q$string[$i]\E/$port_value/;
              }
            }
          }
        }
      }
    }
  }
  $expr =~ s/^_*//;
  return ($expr);
}

sub get_port_col{# [0] port name [1] port row [2] truth table
  my ($portname, $portrow, @table)=@_;
  for(my $col=0;$col<scalar(@{$table[0]});$col++){
    if ($table[$portrow][$col] eq $portname){
      return $col;
    }
  }
}

sub dec2bin{
  my $out="";
  my $in=shift;
  while($in>1){
    $out=($in%2).$out;
    $in=($in-$in%2)/2;
  }
  $out=$in.$out;
  return($out);
}

sub bin2dec{
  my $out=0;
  my $in=shift;
  $in=~s/^b//;
  my @bin=split(//,$in);
  for (my $i=0;$i<scalar(@bin);$i++){
    $out += $bin[$i]*(1<<(scalar(@bin)-1-$i));
  }
  return($out);
}


sub hex2bin{
  my $out="";
  my $in=shift;
  my %hex=( "0"=>"0000", "1"=>"0001", "2"=>"0010", "3"=>"0011", "4"=>"0100", "5"=>"0101", "6"=>"0110", "7"=>"0111", 
            "8"=>"1000", "9"=>"1001", "A"=>"1010", "B"=>"1011", "C"=>"1100", "D"=>"1101", "E"=>"1110", "F"=>"1111",
            "X" => "XXXX", "Z" => "ZZZZ");
  foreach my $str(split(//,$in)){
    $out=$out.$hex{$str};
  }
  return($out);
}

sub str2listval{ #[0] input string [1] bit width
  my @out=();
  my ($in,$wd,$is_real_port)=@_;
  my $val = 0;
  my $prefix = "";
  if ($in =~ /^_+/){
    $in =~ s/^_+//;
    $prefix = "_";
  }
  if($in =~ /^\s*\d*\'*b[01xzXZ]+\s*$/){
    $val = (split(/b/,$in))[1];
    my @val_list = split(//,$val);
    for(my $i=0;$i<$wd;$i++){
      if($is_real_port eq "1"){
        $out[$i]=$in;
      }else{
        if ($i < scalar(@val_list)) {
          $out[$i]=$prefix.$val_list[scalar(@val_list)-$i-1];
        } else {
          $out[$i]=$prefix."0";
        }
      }
    } 
    return @out;
#  } elsif($in =~ /^\d*\'*d[0123456789]+$/){
#    $val = &dec2bin(int((split(/d/,$in))[1]));
  } elsif($in =~ /^\d+$/){
    $val = &dec2bin(int($in));
#  } elsif($in =~ /^\d*\'*h[0123456789ABCDEF]+$/){
#    $val = &hex2bin(hex($in));
  } elsif($in =~ /^\[ramp\(.*\)\]$/) {
    for(my $i=0;$i<$wd;$i++){
      $out[$i]=$in;
    }
    return @out;
  } elsif($in =~ /^\[.*\]$/) {
    for(my $i=0;$i<$wd;$i++){
      if($is_real_port eq "1"){
        $out[$i]=$in;
      }else{
        my $exp = $in;
        $exp =~ s/^\[//;
        $exp =~ s/\]$//;
        if($i == 0){
          $exp = "($exp)&1";
        }else{
          $exp = "(($exp) >> $i)&1";
        }
        $out[$i]=$prefix."[$exp]";
      }
    }
    return @out;
  } else{
    for(my $i=0;$i<$wd;$i++){
      $out[$i]=$prefix.$in;
    }
    return @out;
  }
  my @val_list = split(//,$val);
  for(my $i=0;$i<$wd;$i++){
    if($is_real_port eq "1"){
      $out[$i]=bin2dec($in);
    }else{
      if ($i < scalar(@val_list)) {
        $out[$i]=$prefix.$val_list[scalar(@val_list)-$i-1];
      } else {
        $out[$i]=$prefix."0";
      }
    }
  } 
  return @out;
}

### exclude ptn store ###
sub ExcludePTN{ #[0]:xls file [1] -pg option [2] port table [3] -rnm option
  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$parser->parse($_[0]) or die "ERROR ::: $_[0] is not found.\n";
  my $pg = $_[1];
  my $blank_error = $_[4];
  my $clock_info_ = $_[5];
  my $assert_ctrl = $_[6];
  my $ok=0;
  for my $worksheet($workbook->worksheets()){
    if($worksheet->get_name() eq "Exclude"){
      $ok=1;
      last;
    }
  }
  my $worksheet;
  if($ok!=1){
    return 0;
  }
  undef $parser;
  undef $workbook;
  undef $worksheet;
  my ($aa,@tm)=make_truth_tbl($_[0],"Exclude",0,$pg,$_[2],0,"",$blank_error,$clock_info_,$assert_ctrl);
  if (@tm==0){# case has Exclude sheet, not data in it
    return (-1);
  }
  while($aa ne ""){
    ($aa,@tm)=fusion_tbl($_[0],$aa,0,$pg,$_[3],\@tm, $_[2],$blank_error,$clock_info_);
  }
  return(@tm);
}

### excel file info check ###
sub CheckIncFile{ #[0]:Excelfile path
  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$parser->parse($_[0]) or die "ERROR ::: $_[0] is not found.\n";
  my $worksheet=$workbook->worksheet("Erakis info") or die "ERROR ::: \"Erakis info\" is not found in \"$_[0]\".\n";
  my $cell=$_[0];
  $cell=~s/(.*\/)*(.+)\.xls/$+/;
  my %hash;
  my ($row_min, $row_max)=$worksheet->row_range();
  my ($col_min, $col_max)=$worksheet->col_range();
  my $prev="";
  my $tag_col = $col_min;
  my @ignored_row_list=get_ignored_row_list($worksheet);
  for (my $i=$row_min;$i<$row_max+1;$i++){
    for (my $j=$col_min;$j<$col_max+1;$j++){
      my $val = get_cell_val($i,$j,$worksheet);
      if($val eq "tag"){
          $tag_col = $j;
      }
    }
  }
  for (my $i=$row_min;$i<$row_max+1;$i++){
    if (grep(/^$i$/, @ignored_row_list)>0){
      next;
    }
    my $key = &get_cell_val($i,$tag_col,$worksheet);
    my $def = &get_cell_val($i,$tag_col+1,$worksheet);
    my $val = &get_cell_val($i,$tag_col+2,$worksheet);
    if(!(defined $key) || $key eq ""){
      if(($prev eq "verilog" || $prev eq "include") && defined($val)){
        $key=$prev;
      }else{
        next;
      }
    }
    if($key =~ /cell|out_dir|tb_file|ptn_file|ast_file|lack_log|overlap_log|lib_name|view_name|max_delay|cds\.lib|Incisive|VCS|Verdi|virtuoso|ConnectRule|exclude_assertion|exclude_check_pattern|pref_unit|timescale|simulator|rnm_lib|wave_format|def_step|oscillation|option|SDF_file|SDF_INST|select_SDF|assert_control/){
      if(defined $hash{$key}){
        print("ERROR ::: $key is defined two or more.\n");
        exit(1);
      }elsif((!(defined $val) || $val eq "")&&($def ne "-")){
        $hash{$key}=
                     $key eq "cell" ? $cell :
                     $key eq "out_dir" ? "out_dir":
                     $key eq "tb_file" ? "testbench_".$hash{"cell"}.".sv" :
                     $key eq "ptn_file" ? "ptn_".$hash{"cell"}.".ptn" :
                     $key eq "ast_file" ? "ast_".$hash{"cell"}.".sv" :
                     $key eq "lack_log" ? "lack_".$hash{"cell"}.".log" :
                     $key eq "overlap_log" ? "overlap_".$hash{"cell"}.".log" : 
                     $key eq "exclude_assertion" ? "ex_ast_".$hash{"cell"}.".sv" :
                     $key eq "exclude_check_pattern" ? "ex_ptn_".$hash{"cell"}.".ptn" :
                     $key eq "simulator" ? "vcs" :
                     $key eq "rnm_lib" ? "" :
                     $key eq "def_step" ? "0.1" :
                     $key eq "wave_format" ? "no wave format" : 
                     $key eq "pref_unit" ? "MHz": 
                     $key eq "oscillation" ? "frequency" :
                     $key eq "max_delay" ? "20" :
                     $key eq "timescale" ? "1ns/1ns" : 
                     $key eq "SDF_INST" ? "TopInst" :
                     $key eq "select_SDF" ? "max":
                     $key eq "SDF_file" ? "" : 
                     $key eq "option" ? "" :
                     $key eq "assert_control" ? "" : "";
      }else{
        $hash{$key}=$val;
      }
    }elsif($key eq "verilog"){
      if(defined $hash{"verilog"}){
        $hash{"verilog"}=$hash{"verilog"}."\n$val";
      }elsif(defined $val){
        $hash{"verilog"}=$val;
      }
    }elsif($key eq "include"){
      if(defined $hash{"include"}){
            $hash{"include"}=$hash{"include"}."\n$val";
      }elsif(defined $val){
            $hash{"include"}=$val;
      }
    }elsif($key eq "tag" || $key eq "" || $key =~ /^#/){
      next;
    }else{
      print("WARNING ::: [Erakis info] $key will be ignored.\n");
    }
    $prev=$key;
  }
  # set the default for non-define key
  my @keyarray=("cell","out_dir","tb_file","ptn_file","ast_file","lack_log","overlap_log","lib_name","view_name","max_delay","cds\.lib","Incisive","VCS","Verdi","virtuoso","ConnectRule","exclude_assertion","exclude_check_pattern", "pref_unit","timescale","simulator","rnm_lib","wave_format","def_step", "oscillation", "option", "SDF_file", "SDF_INST", "select_SDF", "assert_control");
  my %def_hash;
  my $undef_key="";
  $def_hash{"cell"}=$cell;
  if (!defined $hash{"cell"}){
    $hash{"cell"} = $def_hash{"cell"};
  }
  $def_hash{"out_dir"}="out_dir";
  $def_hash{"tb_file"}="testbench_".$hash{"cell"}.".v";
  $def_hash{"ptn_file"}="ptn_".$hash{"cell"}.".ptn";
  $def_hash{"ast_file"}="ast_".$hash{"cell"}.".sv";
  $def_hash{"lack_log"}="lack_".$hash{"cell"}.".log";
  $def_hash{"overlap_log"}="overlap_".$hash{"cell"}.".log";
  $def_hash{"max_delay"}="20";
  $def_hash{"exclude_assertion"}="ex_ast_".$hash{"cell"}.".sv";
  $def_hash{"exclude_check_pattern"}="ex_ptn_".$hash{"cell"}.".ptn";
  $def_hash{"pref_unit"}="MHz";
  $def_hash{"timescale"}="1ns/1ns";
  $def_hash{"def_step"}="0.1";
  $def_hash{"simulator"}="1";
  $def_hash{"rnm_lib"}="";
  $def_hash{"wave_format"}="";
  $def_hash{"oscillation"}="frequency";
  $def_hash{"option"}="";
  $def_hash{"SDF_INST"}="TopInst";
  $def_hash{"select_SDF"}="max";
  $def_hash{"SDF_file"}="";
  $def_hash{"assert_control"}="";
  foreach $undef_key (@keyarray){
    if(!(defined $hash{$undef_key})){
      $hash{$undef_key}=$def_hash{$undef_key};
    }
  }
  if($hash{"wave_format"} eq "ams(PSF)"){ #incisive - circuite sim
    for my $key("view_name", "lib_name", "cds.lib", "Incisive", "virtuoso", "ConnectRule"){
      if(!defined($hash{$key}) || $hash{$key} eq ""){ # no defined
        print("ERROR ::: [Erakis info] Please define the \"$key\" tag.\n");
        exit(1);
      }
    }
    $hash{"wave_format"}="ams";
  }elsif($hash{"wave_format"} eq "VPD"){
    $hash{"wave_format"}="vpd";
  }elsif($hash{"wave_format"} eq "FSDB"){
    $hash{"wave_format"}="fsdb";
  }else{
    $hash{"wave_format"}="";
  }
  if($hash{"timescale"} !~ /^\d+(fs|ps|ns|us|ms|s)\/\d+(fs|ps|ns|us|ms|s)$/i){
    print("ERROR ::: [Erakis info] Invalid format of \"timescale\" tag.\n");
    exit(1);
  }
  if($hash{"pref_unit"} !~ /^(k|M|G)*Hz$/i){
    print("ERROR ::: [Erakis info] Invalid format of \"pref_unit\" tag.\n");
    exit(1);
  }
  my $unit=$hash{"pref_unit"};
  $unit=~s/Hz//;
  $unit=($unit =~ /k/i) ?       "1000" :
        ($unit =~ /M/ ) ?    "1000000" :
        ($unit =~ /G/ ) ? "1000000000" : "1";
  my $timescale = $hash{"timescale"};
  $timescale =~ s/\/.*$//;
  my $timescale_val = $timescale;
  $timescale_val =~ s/(fs|ps|ns|us|ms|s)//i;
  my $timescale_unit= $timescale;
  $timescale_unit =~ s/^\d+//;
  $timescale_unit = ($timescale_unit =~ /fs/i) ?  "1000000000000000":
                    ($timescale_unit =~ /ps/i) ?     "1000000000000":
                    ($timescale_unit =~ /ns/i) ?        "1000000000":
                    ($timescale_unit =~ /us/i) ?           "1000000":
                    ($timescale_unit =~ /ms/i) ?              "1000": "1";
  if (int($timescale_val)*int($unit) > int($timescale_unit)) {
    print("ERROR ::: [Erakis info] The defined tag \"pref_unit\" is less than 1 unit timescale of system.\n");
    exit(3);
  }
  if($hash{"oscillation"} !~ /^(frequency|period)$/i){
    print("ERROR ::: [Erakis info] Invalid format of \"oscillation\" tag.\n");
    exit(1);
  }
  if($hash{"def_step"} !~ /^\d*.?\d+$/){ #def step
    print("ERROR ::: [Erakis info] Invalid value of \"def_step\" tag.\n");
    exit(1);
  }
  if($hash{"simulator"} eq "vcs"){ #VCS
    $hash{"simulator"}=1;
    my @aa=("VCS", "verilog");
    if($hash{"wave_format"} eq "fsdb"){ #fsdb
      $aa[2]="Verdi";
    }
    for my $key(@aa){
      if(!defined($hash{$key}) || $hash{$key} eq ""){ # no defined
        print("ERROR ::: [Erakis info] Please define the \"$key\" tag.\n");
        exit(1);
      }
    }
  }elsif($hash{"simulator"} eq "irun"){ #incisive - verilog sim
    $hash{"simulator"}=2;
    my @aa=("Incisive");
    if($hash{"wave_format"} !~ /ams/){
      push(@aa, "verilog");
    }
    if($hash{"wave_format"} eq "fsdb"){ #fsdb
      push(@aa,"Verdi");
    }
    for my $key(@aa){
      if(!defined($hash{$key}) || $hash{$key} eq ""){ # no defined
        print("ERROR ::: [Erakis info] Please define the \"$key\" tag.\n");
        exit(1);
      }
    }    
  } else {
    $hash{"simulator"}="0";
  }
  if($hash{"simulator"} == 2 && $hash{"wave_format"} eq "vpd"){
     print("ERROR ::: [Erakis info] Incisive simulator does not support \"vpd\" wave format. Please select another wave format.\n");
     exit(1);
  }
  if($hash{"simulator"} == 2 && $hash{"wave_format"} eq "ams"){
    $hash{"tb_file"} =~ s/\.v/\.sv/;
    $hash{"ast_file"} =~ s/\.v/\.sv/;
    $hash{"exclude_assertion"} =~ s/\.v/\.sv/;
  }
  return(%hash);
}

sub MakeFSMTable{ ## [0]: Excel file path [1]: hash{"cell"} 
  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$parser->parse($_[0]) or die "ERROR ::: $_[0] is not found.\n";
  my $worksheet=$workbook->worksheet("FSM0") or die "ERROR ::: \"FSM0\" is not found in \"$_[0]\".\n";
  my ($row_min, $row_max)=$worksheet->row_range(); # Excel effective row range
  my ($col_min, $col_max)=$worksheet->col_range(); # Excel effective col range
  my @fsm=(); ## [0]:FSM [1]:EVENT [2]:STAT_TRAN [3]:STAT_DEF [4]:OUT [5]:CLK [6]:RESET
  my $col=0;
  my $row=0;
  my $fsmname=-1;
  my $ev=-1;
  my $st=-1;
  my $sd=-1;
  my $out=-1;
  my $clk=-1;
  my $rst=-1;
  my $checked = -1;

  my @ignored_row_list=get_ignored_row_list($worksheet);
  for (my $i=$row_min;$i<$row_max+1;$i++){
    if (grep(/^$i$/, @ignored_row_list)>0){
      next;
    }
    for (my $j=$col_min;$j<$col_max+1;$j++){
      my $cell=&get_cell_val($i,$j,$worksheet);
      if(!(defined $cell) || $cell eq ""){
        next;
      }elsif($checked==-1){
        my $next=0;
        if($cell =~ /^FSM$/){
          if ($fsmname==-1){
            $fsmname=$j;
            $fsm[0][$col] = "fsm";
          }else{
            print("ERROR ::: [FSM0] Duplicated \"FSM\" column.\n");
            exit(1);
          }
        }elsif($cell =~ /^EVENT$/){
          if($ev==-1){
            $ev=$j;
            $fsm[0][$col] = "event";
          }else{
            print("ERROR ::: [FSM0] Duplicated \"EVENT\" column.\n");
            exit(1);
          }
        }elsif($cell =~ /^STAT_TRAN$/){
          if ($st==-1){
            $st=$j;
            $fsm[0][$col] = "tran";
          }else{
            print("ERROR ::: [FSM0] Duplicated \"STAT_TRAN\" column.\n");
            exit(1);
          }
        }elsif($cell =~ /^STAT_DEF$/){
          if($sd==-1){
            $sd=$j;
            $fsm[0][$col] = "stat";
          }else{
            print("ERROR ::: [FSM0] Duplicated \"STAT_DEF\" column.\n");
            exit(1);
          }
        }elsif($cell =~ /^OUT$/){
          if($out==-1){
            $out=$j;
            $fsm[0][$col] = "out";
          }else{
            print("ERROR ::: [FSM0] Duplicated \"OUT\" column.\n");
            exit(1);
          }
        }elsif($cell =~ /^CLK$/){
          if($clk==-1){
            $clk=$j;
            $fsm[0][$col] = "clk";
          }else{
            print("ERROR ::: [FSM0] Duplicated \"CLK\" column.\n");
            exit(1);
          }
        }elsif($cell =~ /^RESET$/){
          if($rst==-1){
            $rst=$j;
            $fsm[0][$col] = "reset";
          }else{
            print("ERROR ::: [FSM0] Duplicated \"RESET\" column.\n");
            exit(1);
          }
        }else{
          $next=1;
        }
        if($next==0){
          $col++;
        }
      }else{
        if($j == $fsmname){
          $fsm[$row][0]=$cell;
        }elsif($j == $ev){
          if($cell =~ /^[ ]*-[ ]*$/){
            $fsm[$row][1]=$_[1] . "_EVENT"; #the default name of "event definition" sheet
          }else{
            $fsm[$row][1]=$cell;
          }
        }elsif($j == $st){
          if($cell =~ /^[ ]*-[ ]*$/){
            $fsm[$row][2]=$_[1] . "_TRAN"; #the default name of "state transition" sheet
          }else{
            $fsm[$row][2]=$cell;
          }
        }elsif($j == $sd){
          if($cell =~ /^[ ]*-[ ]*$/){
            $fsm[$row][3]=$_[1] . "_STAT"; #the default name of "state definition" sheet
          }else{
            $fsm[$row][3]=$cell;
          }
        }elsif($j == $out){
          if($cell =~ /^[ ]*-[ ]*$/){
            $fsm[$row][4]=$_[1] . "_OUT"; #the default name of "output definition" sheet
          }else{
            $fsm[$row][4]=$cell;
          }
        }elsif($j == $clk){
          $fsm[$row][5]=$cell;
        }elsif($j == $rst){
          $fsm[$row][6]=$cell;
        }
      }
    }
    $row++;
    if($checked == -1){
      if($fsmname==-1){
        print("ERROR ::: [FSM0] FSM name info is not defined.\n");
        exit(3);
      }elsif($ev==-1){
        print("ERROR ::: [FSM0] Event definition info is not defined.\n");
        exit(3);
      }elsif($st==-1){
        print("ERROR ::: [FSM0] State transition info is not defined.\n");
        exit(3);
      }elsif($sd==-1){
        print("ERROR ::: [FSM0] State definition info is not defined.\n");
        exit(3);
      }elsif($out==-1){
        print("ERROR ::: [FSM0] Output definition info is not defined.\n");
        exit(3);
      }else{
        $checked=0;
      }
    }
  }
  return(@fsm);
}

sub MakeEventTable{ ## [0]Excel file path [1] fsm index [2] fsm table
  my ($excel, $fsmindex, @fsm) = @_;
  my $event_sheet = $fsm[1+$fsmindex][1];
  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$parser->parse($_[0]) or die "ERROR ::: $_[0] is not found.\n";
  my $worksheet=$workbook->worksheet("$event_sheet") or die "ERROR ::: \"$event_sheet\" is not found in \"$_[0]\".\n";
  my ($row_min, $row_max)=$worksheet->row_range(); # Excel effective row range
  my ($col_min, $col_max)=$worksheet->col_range(); # Excel effective col range
  my @event=(); ## [0..n-1]:signals [n]:[Event]
  my $col=0;
  my $row=0;
  my $checked=-1;
  my $start_col=-1;
  my $num_col=0;
  my $ev_col=-1;
  my $ex=0;

  my @ignored_row_list=get_ignored_row_list($worksheet);
  for (my $i=$row_min;$i<$row_max+1;$i++){
    if (grep(/^$i$/, @ignored_row_list)>0){
      next;
    }
    $col=0;
    for (my $j=$col_min;$j<$col_max+1;$j++){
      my $cell=&get_cell_val($i,$j,$worksheet);
      if ($checked == -1){
        if (!(defined $cell) || $cell eq ""){
          next;
        }else{
          if($cell =~ /\[event\]/i){
            if($ev_col==-1){
              $ev_col=$j;
              $event[0][$col] = "[event]";
            }else{
              print("ERROR ::: [$event_sheet] Duplicated \"event\" column.\n");
              $ex=1;
            }
          }else{
            $event[0][$col] = $cell;
          }
          if ($start_col==-1){
            $start_col=$j;
          }
          $col++;
        }
      }else{
        if ($j < $start_col || $j > ($start_col+$num_col)){
          my $er_row=$i+1;
          my $er_col=$j+1;
          print("ERROR ::: [$event_sheet] Invalid at cell[$er_row,$er_col].\n");
          $ex=1;
        }
        if (!(defined $cell) || $cell eq ""){
          my $er_row=$i+1;
          my $er_col=$j+1;
          print("ERROR ::: [$event_sheet] Blank cell at [$er_row,$er_col].\n");
          $ex=1;
        }else{
          $event[$row][$col]=$cell;
        }
        $col++;
      }
    }
    if ($checked == -1){
      $num_col = $col;
      $checked = 0;
    }
    $row++;
  }
  return($ex, @event);
}

sub MakeStateTable{ ## [0] Excel file path, [1] fsm index [2] fsm table
  my ($excel, $fsmindex, @fsm) = @_;
  my $state_sheet = $fsm[1+$fsmindex][3];
  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$parser->parse($_[0]) or die "ERROR ::: $_[0] is not found.\n";
  my $worksheet=$workbook->worksheet("$state_sheet") or die "ERROR ::: \"$state_sheet\" is not found in \"$_[0]\".\n";
  my ($row_min, $row_max)=$worksheet->row_range(); # Excel effective row range
  my ($col_min, $col_max)=$worksheet->col_range(); # Excel effective col range
  my @state=(); ## [0..n-1]:signals [n]:[State]
  my $col=0;
  my $row=0;
  my $checked=-1;
  my $start_col=-1;
  my $num_col=0;
  my $st_col=-1;
  my $ex=0;

  my @ignored_row_list=get_ignored_row_list($worksheet);
  for (my $i=$row_min;$i<$row_max+1;$i++){
    if (grep(/^$i$/, @ignored_row_list)>0){
      next;
    }
    $col=0;
    for (my $j=$col_min;$j<$col_max+1;$j++){
      my $cell=&get_cell_val($i,$j,$worksheet);
      if ($checked == -1){
        if (!(defined $cell) || $cell eq ""){
          next;
        }else{
          if($cell =~ /\[state\]/i){
            if($st_col==-1){
              $st_col=$j;
              $state[0][$col] = "[state]";
            }else{
              print("ERROR ::: [$state_sheet] Duplicated \"state\" column.\n");
              $ex=1;
            }
          }else{
            $state[0][$col] = $cell;
          }
          if ($start_col==-1){
            $start_col=$j;
          }
          $col++;
        }
      }else{
        if ($j < $start_col || $j > ($start_col+$num_col)){
          my $er_row=$i+1;
          my $er_col=$j+1;
          print("ERROR ::: [$state_sheet] Invalid at cell[$er_row,$er_col].\n");
          $ex=1;
        }
        if (!(defined $cell) || $cell eq ""){
          my $er_row=$i+1;
          my $er_col=$j+1;
          print("ERROR ::: [$state_sheet] Blank cell at [$er_row,$er_col].\n");
          $ex=1;
        }else{
          $state[$row][$col]=$cell;
        }
        $col++;
      }
    }
    if ($checked == -1){
      $num_col = $col;
      $checked = 0;
    }
    $row++;
  }
  return($ex, @state);
}

sub MakeTransTable{ ## [0] Excel file path [1] fsm index [2] fsm table
  my ($excel, $fsmindex, @fsm) = @_;
  my $trans_sheet = $fsm[1+$fsmindex][2];
  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$parser->parse($_[0]) or die "ERROR ::: $_[0] is not found.\n";
  my $worksheet=$workbook->worksheet("$trans_sheet") or die "ERROR ::: \"$trans_sheet\" is not found in \"$_[0]\".\n";
  my ($row_min, $row_max)=$worksheet->row_range(); # Excel effective row range
  my ($col_min, $col_max)=$worksheet->col_range(); # Excel effective col range
  my @trans=(); ## [0..n-1]:signals [n]:[State]
  my $col=0;
  my $row=0;
  my $num_col=0;
  my $start_col=-1;
  my $checked=-1;
  my $ex=0;

  my @ignored_row_list=get_ignored_row_list($worksheet);
  for (my $i=$row_min;$i<$row_max+1;$i++){
    if (grep(/^$i$/, @ignored_row_list)>0){
      next;
    }
    $col=0;
    for (my $j=$col_min;$j<$col_max+1;$j++){
      my $cell=&get_cell_val($i,$j,$worksheet);
      if ($checked == -1){
        if (!(defined $cell) || $cell eq ""){
          next;
        }else{
          if($cell =~ /event/i){
            if ($start_col==-1){
              $trans[0][$col] = "[event]";
              $start_col = $j;
            }else{
              print("ERROR ::: [$trans_sheet] Duplicated \"event\" column.\n");
              $ex=1;
            }
          }else{
            $trans[0][$col] = $cell;
          }
          $col++;
        }
      }else{
        if ($j < $start_col || $j > ($start_col+$num_col)){
          my $er_row=$i+1;
          my $er_col=$j+1;
          print("ERROR ::: [$trans_sheet] Invalid at cell[$er_row,$er_col].\n");
          $ex=1;
        }
        if (!(defined $cell) || $cell eq ""){
          my $er_row=$i+1;
          my $er_col=$j+1;
          print("ERROR ::: [$trans_sheet] Blank cell at [$er_row,$er_col].\n");
          $ex=1;
        }else{
          $trans[$row][$col]=$cell;
        }
        $col++;
      }
    }
    if ($checked == -1){
      $num_col = $col;
      $checked = 0;
    }
    $row++;
  }
  return($ex, @trans);
}

sub GetSheetNameList {#[0] excel file
  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$parser->parse($_[0]) or die "ERROR ::: $_[0] is not found.\n";
  my @ret;
  foreach my $sheet (@{$workbook->{Worksheet}}) {
    push (@ret, $sheet->{Name});
  }
  return @ret;
}

sub MakeOutTable{ ## [0] Excel file path [1] fsm index [2] fsm table
  my ($excel, $fsmindex, @fsm) = @_;
  my $out_sheet = $fsm[1+$fsmindex][4];
  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$parser->parse($_[0]) or die "ERROR ::: $_[0] is not found.\n";
  my $worksheet=$workbook->worksheet("$out_sheet") or die "ERROR ::: \"$out_sheet\" is not found in \"$_[0]\".\n";
  my ($row_min, $row_max)=$worksheet->row_range(); # Excel effective row range
  my ($col_min, $col_max)=$worksheet->col_range(); # Excel effective col range
  my @out=(); ## [0..n-1]:signals [n]:[State]
  my $col=0;
  my $row=0;
  my $checked=-1;
  my $start_col=-1;
  my $num_col=0;
  my @sheet_name_list = &GetSheetNameList($excel);
  my $ex=0;

  my @ignored_row_list=get_ignored_row_list($worksheet);
  for (my $i=$row_min;$i<$row_max+1;$i++){
    if (grep(/^$i$/, @ignored_row_list)>0){
      next;
    }
    $col=0;
    for (my $j=$col_min;$j<$col_max+1;$j++){
      my $cell=&get_cell_val($i,$j,$worksheet);
      if ($checked == -1){
        if (!(defined $cell) || $cell eq ""){
          next;
        }else{
          if($cell =~ /\[state\]/i){
            if ($start_col==-1){
              $out[0][$col] = "[state]";
              $start_col=$j;
            }else{
              print("ERROR ::: [$out_sheet] Duplicated \"state\" column.\n");
              $ex=1;
            }
          }else{
            $out[0][$col] = $cell;
          }
          $col++;
        }
      }else{
        if ($j < $start_col || $j > ($start_col+$num_col)){
          my $er_row=$i+1;
          my $er_col=$j+1;
          print("ERROR ::: [$out_sheet] Invalid at cell[$er_row,$er_col].\n");
          $ex=1;
        }
        if (!(defined $cell) || $cell eq ""){
          my $er_row=$i+1;
          my $er_col=$j+1;
          print("ERROR ::: [$out_sheet] Blank cell at [$er_row,$er_col].\n");
          $ex=1;
        }else{
          $out[$row][$col]=$cell;
          if ($cell =~ /^<(\w+)>$/ and grep (/^$1$/i, @sheet_name_list) < 1){
            print("ERROR ::: [$out_sheet] Reference table '$1' is not existed in $excel.\n");
            $ex=1;
          }
        }
        $col++;
      }
    }
    if ($checked == -1){
      $num_col = $col;
      $checked = 0;
    }
    $row++;
  }
  return($ex, @out);
}

sub CheckCareRange{ # [0] truth table [1] port table
  my ($xls,$ttb,$ptb)=@_;
  my @table=@$ttb;
  my @port_table=@$ptb;
  my $cr="";
  my $io="";
  my $parser=Spreadsheet::ParseExcel->new();
  my $workbook=$parser->parse($xls) or die "ERROR ::: $_[0] is not found.\n";
  for (my $j=2;$j<scalar(@{$table[0]});$j++){
    for (my $k=0;$k<scalar(@{$port_table[1]});$k++){
      if ($table[0][$j] ne "input" && $table[0][$j] ne "inout" && $table[0][$j] ne "output"){
        next;
      }
      if (&cmp_port_name($table[1][$j],$port_table[10][$k]) == 1){
        $io=$port_table[1][$k];
        if($port_table[5][$k] eq "-" || $port_table[5][$k] eq "x" ||$port_table[5][$k] eq "z"){
          $cr=$port_table[5][$k];
          $cr=~s/^-/2/;
          $cr=~s/^x/3/;
          $cr=~s/^z/4/;
        }else{
          $cr=4; # Set z for oscillation port
        }
        last;
      }
    }
    for (my $i=2;$i<scalar(@table);$i++){
      if ($table[0][$j] eq "input" || $table[0][$j] eq "inout" || $table[0][$j] eq "output"){
        my $worksheet=$workbook->worksheet($table[$i][0]) or die "ERROR ::: \"$_[1]\" is not found in \"$_[0]\".\n";
        my ($col_min, $col_max)=$worksheet->col_range();
        if($table[$i][$j] =~ /^_/ && $io ne "inout"){
          printf("WARNING ::: [%s] Value \"%s\" in %s should be used for inout port only.\n",$table[$i][0],$table[$i][$j],&get_cell_pos($table[$i][1]-1,($j-2)+$col_min));
          $table[$i][$j] =~ s/^_*//;
        }elsif ((($table[$i][$j] =~ /^_?x$/i) && (int($cr)<3))||(($table[$i][$j] =~ /^_?z$/i) && (int($cr)<4))){
          printf("WARNING ::: [%s] Value \"%s\" in %s is not in care range.\n",$table[$i][0],$table[$i][$j],&get_cell_pos($table[$i][1]-1,($j-2)+$col_min));
        }
      }
    }
  }
}

sub FilterTruthTable{ # [0] truth table
  my @table=();
  for (my $i=0;$i<scalar(@_);$i++){
    for (my $j=0;$j<scalar(@{$_[$i]});$j++){
      if ((defined $_[0][$j]) and ($_[0][$j] !~ /action|message|disable|control|assert_control|control_n|assert_control_n/) and ($_[0][$j] ne "")){
        $table[$i][$j]=$_[$i][$j];
      }else{
        $table[$i][$j]="";
      }
    }
  }
  return @table;
}

sub SplitPatTable{ # [0]enable ouput port split [1] truth table
  my ($tbl_,$pr)=@_;
  my @table=@$tbl_;
  my @port_ref=@$pr;
  my $cont=0;
  my $row = 4;
  my @out=();
  @{$out[0]} = @{$table[0]}; #in/out
  @{$out[1]} = @{$table[1]}; #D/A 
  @{$out[2]} = @{$table[2]}; #port name
  @{$out[3]} = @{$table[3]}; #S/A
  for (my $i=4;$i<scalar(@table);$i++){
    my $is_found = 0;
    if ((grep (/^\*/,@{$table[$i]}) < 1) && (grep (/^_?ramp/,@{$table[$i]}) < 1)){
      @{$out[$row]} = @{$table[$i]};
      $row++;
      next;
    }
    for (my $j=2;$j<scalar(@{$table[$i]});$j++){
      if (!defined $table[0][$j] || ($table[0][$j] ne "input" && $table[0][$j] ne "inout")){
        next;
      }
      if ($table[$i][$j] =~ /^_?ramp.*/){
        $is_found = 1;
        $cont = 1;
        my $exp = $table[$i][$j];
        $exp =~ s/^.*\(//;
        $exp =~ s/\).*$//;
        my ($min, $max, $def_step)=split(",",$exp);
        my $rval=$min;
        while ($rval<$max){
          @{$out[$row]} = @{$table[$i]};
          $out[$row][$j] = $rval;
          $row++;
          $rval=$rval+$def_step;
        }
        last; # break for next row
      }
    }
    if($is_found == 0){
      @{$out[$row]} = @{$table[$i]};
      $row++;
    }
  }
  return ($cont,@out);
}

sub GetPortRefTable{
  my ($port_name_,$tbl_, $ptbl_, $rnm) = @_;
  my @port_name = @$port_name_;
  my @table=@$tbl_;
  my @port_table=@$ptbl_;
  my $total_port_num = 0;
  my @port_ref_table=();
  @{$port_ref_table[0]} = @port_name;  # port name
  @{$port_ref_table[1]} = ("-1")x scalar(@port_name); # indicate port index mapped with test bench
  @{$port_ref_table[2]} = ("-2")x scalar(@port_name); # -2: none, -1: supply, 0: normal, 1: real port
  @{$port_ref_table[3]} = ("-2")x scalar(@port_name); # -2: none, -1: supply, 0: not osci, 1: osci port
  @{$port_ref_table[4]} = ("-2")x scalar(@port_name); # -2: none, -1: supply, 0: input/electrical_in, 1: output/electrical_out, 2: inout, 3: ref_port
  @{$port_ref_table[5]} = ("-1")x scalar(@port_name); # care range
  @{$port_ref_table[6]} = ("")  x scalar(@port_name); # real port attribute
  @{$port_ref_table[7]} = @port_name; # port name with suffix ".r" for real port
  @{$port_ref_table[8]} = ("")  x scalar(@port_name); # port width
  @{$port_ref_table[9]} = ("0")  x scalar(@port_name); # latch port indicator
  for(my $j=scalar(@{$port_ref_table[0]})-1;$j>=0;$j--){
    my $tmp_str = "";
    if ($table[0][$j] =~ /input|electrical_in|output|electrical_out|inout|supply|power|ground|^reg/){
      if($table[0][$j] =~ /input|electrical_in|inout|supply|power|ground|^reg/){
        $port_ref_table[1][$j]=$total_port_num;
        $total_port_num++;
      }else{
        $port_ref_table[1][$j]=-1;
      }
      for(my $i=0;$i<scalar(@{$port_table[0]});$i++){
        if(cmp_port_name($port_ref_table[0][$j], $port_table[10][$i]) == 1){
          $port_ref_table[3][$j] = 0;
          if ($port_table[1][$i] =~ /input|electrical_in/){
            $port_ref_table[4][$j] = 0;
          }elsif($port_table[1][$i] =~ /output|electrical_out/){
            $port_ref_table[4][$j] = 1;
          }elsif($port_table[1][$i] =~ /supply|power|ground/){
            $port_ref_table[4][$j] = -1;
          }else{
            $port_ref_table[4][$j] = 2;
          }
          if($port_table[12][$i] eq "1"){
            $port_ref_table[3][$j] = 1;
          }
          my $cr=lc($port_table[5][$i]);
          if ($cr =~ /^(-|x|z)$/i){
            $cr=~s/^-/2/;
            $cr=~s/^x/3/;
            $cr=~s/^z/4/;
          }else{ # incase oscillation port
            $cr = 4;
          }
          $port_ref_table[5][$j] = $cr;
          if(($port_table[13][$i] ne "-")&&($rnm==1)){ # real port
            $port_ref_table[2][$j] = 1;
            $port_ref_table[2][$j] = 1;
            $port_ref_table[7][$j]=$port_ref_table[0][$j].".r";
            $port_ref_table[6][$j]="$port_table[13][$i],$port_table[14][$i],$port_table[15][$i]";
          }else{ # normal port
            $port_ref_table[2][$j] = 0;
            $port_ref_table[2][$j] = 0;
            $port_ref_table[7][$j]=$port_ref_table[0][$j];
          }
          last;
        }
      }
      for(my $i=0;$i<scalar(@{$port_table[0]});$i++){
        if($port_ref_table[0][$j] eq $port_table[0][$i] and $port_table[17][$i] eq "1"){
          $port_ref_table[9][$j] = 1;
          last;
        }
      }
      for(my $i=0;$i<scalar(@{$port_table[0]});$i++){
        if($port_ref_table[0][$j] eq $port_table[0][$i]){
          if($port_table[9][$i] eq "-1"){ # single port width port
            $port_ref_table[8][$j] = "";
          }else{
            if($port_table[11][$i] ne "-"){ # multiple port width port
              $port_ref_table[8][$j] = $port_table[11][$i];
            }else{
              $port_ref_table[8][$j] = "-";
            }
          }
          last;
        }
      }
    } elsif ($table[0][$j] =~ /ref_port/){ # for reference variable table
      $port_ref_table[2][$j]=0; # act as normal port
      $port_ref_table[4][$j]=3; # indicate ref port
    }
  }
  return @port_ref_table;
}

sub UpdateRefTable{
  my ($ex_pr, $pr) = @_;
  my @ex_port_ref_table = @$ex_pr;
  my @port_ref_table = @$pr;
  for(my $i=0; $i<scalar(@{$ex_port_ref_table[0]});$i++){
    next if ($ex_port_ref_table[1][$i] eq "-1");
    for(my $j=0; $j<scalar(@{$port_ref_table[0]});$j++){
      if ($ex_port_ref_table[0][$i] eq $port_ref_table[0][$j]) {
        $ex_port_ref_table[1][$i] = $port_ref_table[1][$j];
        last;
      }
    }
  }
  return @ex_port_ref_table;
}

sub separate_port{ #@_ port table
  my @ptbl= @_;
  my @port=(); ## [0]:name [1]:inout [2]:D/A [3]:bit [4]:Level [5]:care range [7]:MSB [8]:LSB [9]: port width
  my $sep_col = 0;
  for (my $i=0;$i<scalar(@_);$i++){
    $sep_col = 0;
    for (my $j=0;$j<scalar(@{$_[0]});$j++){
      $port[$i][$sep_col] = $ptbl[$i][$j];
      if($ptbl[9][$j] != -1){
        for (my $k = $ptbl[7][$j]; $k >= $ptbl[8][$j];$k--) {
          if ($i == 0){ # port name 
              $port[$i][$sep_col] = $ptbl[$i][$j]."[$k]";
          } elsif (($i == 7) || ($i == 8)) {
              $port[$i][$sep_col] = $k;
          } elsif ($i == 9) {
              $port[$i][$sep_col] = 1;
          } elsif (($i == 11)&&($k!=$ptbl[7][$j])){
              $port[$i][$sep_col] = "-";
          } else {
              $port[$i][$sep_col] = $ptbl[$i][$j];
          }
          $sep_col++;
        }
      } else {
        $sep_col++;
      }
    }
  }
  return @port;
}

sub cmp_port_name{ #[0] checked port name [1] expected port name
  my ($chn, $epn) = @_;
  if((!defined $chn) || (!defined $epn)){
      return 0;
  }
  if($chn=~/\[.*\]/){
    $chn=~s/\[.*\]//g;
  }
  if($epn=~/\[.*\]/){
    $epn=~s/\[.*\]//g;
  }
  $chn=~s/^\s*//g;
  $chn=~s/\s*$//g;
  $epn=~s/^\s*//g;
  $epn=~s/\s*$//g;
  if($chn eq $epn){
    return 1;
  }else{
    return 0;
  }
}

sub get_merged_cell_val { #[0] check row [1] column row [2] excel sheet [3] merged area
  my ($row, $col, $sheet, @MergedArea) = @_;
  foreach my $merged_cells (@MergedArea) {
    my ($Rs, $Cs, $Re, $Ce) = @$merged_cells;
    if (($row >= $Rs) && ($row <= $Re) && ($col >= $Cs) && ($col <= $Ce)) {
      return $sheet->{Cells}[$Rs][$Cs]->{Val};
    }
  }
}

sub get_cell_pos{  #[0] current row [1] current column
  my $row=$_[0]+1;
  my $col=$_[1]+1;
  my $cell_pos="Cell(";
  my %col_ref=("0" => "Z", "1"=>"A","2"=>"B","3"=>"C","4"=>"D","5"=>"E","6"=>"F","7"=>"G","8"=>"H","9"=>"I","10"=>"J",
               "11"=>"K","12"=>"L","13"=>"M","14"=>"N","15"=>"O","16"=>"P","17"=>"Q","18"=>"R","19"=>"S","20"=>"T",
               "21"=>"U","22"=>"V","23"=>"W","24"=>"X","25"=>"Y","26"=>"Z");
  if($col <= 26){
    $cell_pos=$cell_pos.$col_ref{$col%26};  
  }elsif(($col % 26) == 0){  
    $cell_pos=$cell_pos.$col_ref{int($col/26)-1};
    $cell_pos=$cell_pos.$col_ref{$col%26};
  }else{
    $cell_pos=$cell_pos.$col_ref{int($col/26)};
    $cell_pos=$cell_pos.$col_ref{$col%26};
  }
  $cell_pos=$cell_pos."$row)";
  return $cell_pos;
}

sub get_cell_val{ #[0] current row [1] current column [2] excel sheet
  my ($row,$col,$sheet)=@_;
  my $cur_cell = $sheet->{Cells}[$row][$col];
  my $cell = "";
  if ($cur_cell->{Merged}) {
    $cell=&get_merged_cell_val($row, $col, $sheet, @{$sheet->{MergedArea}});
  } else {
    $cell=Spreadsheet::ParseExcel::Cell::Value($sheet->get_cell($row,$col));
  }
  if(defined $cell){
    $cell=~s/^\s*//;
    $cell=~s/\s*$//;
    return $cell;
  }
  return"";
}

sub calc_period {
  my ($freq, $pref_unit, $timescale) = @_;
  my $unit = $pref_unit;
  $unit=~s/Hz//;
  $unit=($unit =~ /k/i) ?       "1000" :
        ($unit =~ /M/ ) ?    "1000000" :
        ($unit =~ /G/ ) ? "1000000000" : "1";
  $timescale =~ s/\/.*$//;
  my $timescale_val = $timescale;
  $timescale_val =~ s/(fs|ps|ns|us|ms|s)//i;
  my $timescale_unit= $timescale;
  $timescale_unit =~ s/^\d+//;
  $timescale_unit = ($timescale_unit =~ /fs/i) ?  "1000000000000000":
                    ($timescale_unit =~ /ps/i) ?     "1000000000000":
                    ($timescale_unit =~ /ns/i) ?        "1000000000":
                    ($timescale_unit =~ /us/i) ?           "1000000":
                    ($timescale_unit =~ /ms/i) ?              "1000": "1";
  return int($timescale_unit/($freq * $unit * $timescale_val));
}
sub calc_frequency {
  my ($period, $pref_unit, $timescale, $is_expr) = @_;
  my $unit = $pref_unit;
  $unit=~s/Hz//;
  $unit=($unit =~ /k/i) ?       "1000" :
        ($unit =~ /M/ ) ?    "1000000" :
        ($unit =~ /G/ ) ? "1000000000" : "1";
  $timescale =~ s/\/.*$//;
  my $timescale_val = $timescale;
  $timescale_val =~ s/(fs|ps|ns|us|ms|s)//i;
  my $timescale_unit= $timescale;
  $timescale_unit =~ s/^\d+//;
  $timescale_unit = ($timescale_unit =~ /fs/i) ?  "1000000000000000":
                    ($timescale_unit =~ /ps/i) ?     "1000000000000":
                    ($timescale_unit =~ /ns/i) ?        "1000000000":
                    ($timescale_unit =~ /us/i) ?           "1000000":
                    ($timescale_unit =~ /ms/i) ?              "1000": "1";
  my $result = "";
  $result = int($timescale_unit/($period * $unit * $timescale_val)) if $is_expr ne "1";;
  $result = "($timescale_unit/($period * $unit * $timescale_val))" if $is_expr eq "1";
  return $result;
}

sub CheckFBSignal{# [0] port table
  my (@port)=@_;
  my $inport=0;
  my $outport=0;
  my $check=0;
  for (my $col=0;$col<scalar(@{$port[0]});$col++){
    if($port[18][$col] eq "FB"){
       if($port[1][$col] eq "input"){
         $inport++;
         $check=1;
         $port[18][$col]="FB_INPUT"
       }elsif($port[1][$col] eq "output"){
         $outport++; 
         $check=1;
         $port[18][$col]="FB_OUTPUT"
       }
    }
  }
  if($check != 0){
    if(!($inport == 1 && $outport == 1)){
      printf("ERROR ::: [Port info] Erakis only supports one FB loop. Please check define FB signal again.\n");
      exit(3);
    }
  }
}

sub GetFBSignal{
  my ($port_name, @port)=@_;
  for (my $col=0;$col<scalar(@{$port[0]});$col++){
    if(($port_name eq $port[0][$col]) && ($port[18][$col] =~ /FB/) && ($port[1][$col] eq "input")){
          return 1; 
    }
  }
  return 0;
}
sub CheckPortMap{
  my ($tbl,$exclude_)=@_;
  my @table = @$tbl;
  my @exclude = @$exclude_;
  my @truth_port_name;
  my @exclude_port_name;
  for(my $i=2;$i<scalar(@{$table[0]});$i++){
    if($table[0][$i] =~ /input|electrical_in|inout/){
        push(@truth_port_name, $table[2][$i])
    }
  }
  if(scalar(@exclude) > 1){
    for(my $i=2;$i<scalar(@{$exclude[0]});$i++){
      if($exclude[0][$i] =~ /input|electrical_in|inout/){
        push(@exclude_port_name, $exclude[1][$i])
      }
    }
  }
  if(scalar(@truth_port_name) != scalar(@exclude_port_name)){
    print("ERROR ::: [Exclude] Can not generate test pattern or assertion of Exclude sheet the description of Truth Table and Exclude sheet are not matched about order of input port.\n");
    exit(3);
  }else{
    for(my $i=0;$i<scalar(@truth_port_name);$i++){
      if($truth_port_name[$i] ne $exclude_port_name[$i]){
        print("ERROR ::: [Exclude] Can not generate test pattern or assertion of Exclude sheet the description of Truth Table and Exclude sheet are not matched about order of input port.\n");
        exit(3);
      }
    }
  }
  return 0;
}
sub print_tableXXX{ # for debug
  for (my $i=0;$i<scalar(@_);$i++){
    for (my $j=0;$j<scalar(@{$_[$i]});$j++){
      if(!defined $_[$i][$j]){
        printf ("@@@\t");
      }else{
        printf ("%s\t",$_[$i][$j]);
      }
    }
    print "\n";
  }
}

1;
