#!/bin/perl
use strict;
use warnings;
use Spreadsheet::ParseExcel;  # for processing Excel sheets
require 'Ex2Tbl.pl';
require 'MakeOutFile.pl';
require 'ErksFunc.pl';

my $ex=0;  # exit states

### Info ###
my $version=$ENV{'ERAKIS_VER'};
my($se, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst)=localtime(time);
my $exe_date=sprintf("%04d\/%02d\/%02d %02d:%02d:%02d",$year+1900,$mon+1,$mday,$hour,$min,$se);
print("##  $version\n##  started at $exe_date\n");

### parse option ###
my ($xls, $pg, $assertion, $testbench, $check_table, $test_vector, $split, $pcheck, $max_error, $rnm, $all_ptn, $fsmast, $dcas, $ex_ast, $complete_lack, $fsmc, $fsmtv, $blank_error, $message_chk, $ex_ptn, $lfo, $no_back, $sdf)=ErksFunc::ParseOptions(@ARGV);

if($xls eq "1"){ # excel file isn't in arguments
  exit(1);
}
my @sheet_name_list = &Ex2Tbl::GetSheetNameList($xls);

### default setting include ###
my %hash=Ex2Tbl::CheckIncFile($xls);
if($hash{"rnm_lib"}eq"" && $rnm == 1){
  print("ERROR ::: [Erakis info] Please define the \"rnm_lib\" tag.\n");
  exit(1);
}
if($hash{"SDF_file"} eq "" && $sdf ==1){
    print("ERROR ::: [Erakis info] Please define the \"SDF_file\" tag.\n");
    exit(1);
}
my @sdf_info = ($sdf, $hash{"SDF_file"},$hash{"SDF_INST"},$hash{"select_SDF"});
if(!-d $hash{"out_dir"}){
  mkdir $hash{"out_dir"};
}else{
  printf("WARNING ::: Directory \"".$hash{"out_dir"}."\" already exist. If output file's name is same, the files will be overwritten.\n");
}
my @PortTable=Ex2Tbl::MakePortTable($xls,$hash{"wave_format"},$hash{"def_step"},$hash{"pref_unit"},$hash{"timescale"});       # port info check
MakeOutFile::CheckCompressionPort($dcas, @PortTable); # check port name in -cr
Ex2Tbl::CheckFBSignal(@PortTable);
my @RisingFallingSeq=();
my @InputSeq=();
my @OutputSeq=();
if (grep (/^Constraint$/, @sheet_name_list) == 1){
  my ($inseq,$outseq)=Ex2Tbl::MakeTimingTable($xls,"Constraint",@PortTable);
  @OutputSeq=@$outseq;
}

my @pattern_group = ();
if (grep (/^delay$/, @sheet_name_list) == 1){
    my ($num_grp, $inseq_,$rfseq_)=Ex2Tbl::MakeDelayTable($xls,"delay",@PortTable);
    @RisingFallingSeq=@$rfseq_;
    @pattern_group = @$num_grp;
    my @inseq = @$inseq_;
    my @rfsed = @$rfseq_;
    for(my $i=0;$i<scalar(@inseq);$i++){
        @{$InputSeq[$i]}=@{$inseq[$i]};
    }
}
my $total = 0;
for (my $i=0;$i<scalar(@InputSeq);$i++){
  my @input_tmp=();
  @input_tmp = @{$InputSeq[$i]};
  my $count_tmp = 0;
  if (@input_tmp != 0){
      for (my $j=1;$j<scalar(@input_tmp);$j++){
          $count_tmp = $count_tmp + int($input_tmp[$j][4]);
      }
  }
  if($count_tmp > $total ){
      $total = $count_tmp;
  }
}
if (@OutputSeq != 0) {
  for (my $i=1;$i<scalar(@OutputSeq);$i++){
    my $min;
    my $max;
    if ($OutputSeq[$i][4] =~ /^\d+-\d+$/) { # Ex: 10-50
      ($min, $max)=split(/-/,$OutputSeq[$i][4]);
    } elsif ($OutputSeq[$i][4] =~ /^\d+$/) { # Ex: 50
      $max = $OutputSeq[$i][4];
    } else { # Ex: pos 5, neg 10
      $max = $OutputSeq[$i][4];
      $max =~ s/(pos|neg)//;
      $max = int($max)*int($OutputSeq[$i][7]);
    }
    $total = $total + int($max);
  }
}
if ($hash{"max_delay"} < $total) {
  printf("WARNING ::: Max delay period (%d) is less than total timing sequence constraint (%d).\n",$hash{"max_delay"},$total);
  $hash{"max_delay"} = $total;
}

my @RisingFallingSeqExclude=();
my @InputSeqExclude=();
my @OutputSeqExclude=();
if (grep (/^Exclude_Constraint$/, @sheet_name_list) == 1){
  my ($inseqExclude,$outseqExclude,$rfseqExclude)=Ex2Tbl::MakeTimingTable($xls,"Exclude_Constraint",@PortTable);
  @RisingFallingSeqExclude=@$rfseqExclude;
  @InputSeqExclude=@$inseqExclude;
  @OutputSeqExclude=@$outseqExclude;

  # Process delay time <> output timing sequence
#  my $total = 0;
#  if (@InputSeqExclude != 0){
#    for (my $i=1;$i<scalar(@InputSeqExclude);$i++){
#        $total = $total + int($InputSeqExclude[$i][4]);
#    }
#  }
#  if (@OutputSeqExclude != 0) {
#    for (my $i=1;$i<scalar(@OutputSeqExclude);$i++){
#      my $min;
#      my $max;
#      if ($OutputSeqExclude[$i][4] =~ /^\d+-\d+$/) { # Ex: 10-50
#        ($min, $max)=split(/-/,$OutputSeqExclude[$i][4]);
#      } elsif ($OutputSeqExclude[$i][4] =~ /^\d+$/) { # Ex: 50
#        $max = $OutputSeqExclude[$i][4];
#      } else { # Ex: pos 5, neg 10
#        $max = $OutputSeq[$i][4];
#        $max =~ s/(pos|neg)//;
#        $max = int($max)*int($OutputSeqExclude[$i][7]);
#      }
#      $total = $total + int($max);
#    }
#  }
#  if ($hash{"max_delay"} < $total) {
#    printf("WARNING ::: Max delay period (%d) is less than total timing sequence constraint (%d).\n",$hash{"max_delay"},$total);
#    $hash{"max_delay"} = $total;
#  }
}
##################################
######## Check options ###########
##################################
my $default_opt=0;
if($testbench eq "0" &&  $check_table eq "0" &&  $test_vector eq "0" && $assertion eq "0" && ($complete_lack eq "-100" || $complete_lack eq "1")
    && $fsmc eq "0" && $fsmtv eq "0" && $fsmast eq "0"){
  $default_opt=1;

  $testbench=1;
  if ($complete_lack eq "-100"){
    $check_table=1;
  }
  $test_vector=1;
  $assertion=1;

  $fsmc=1;
  $fsmtv=1;
  $fsmast=1;
}
if ($all_ptn ne "1"){
  if($rnm!=1){
    if ((grep (/^Table0$/, @sheet_name_list) == 0) && (grep (/^FSM0$/, @sheet_name_list) == 0)){
      print ("ERROR ::: \"Table0\" sheet and \"FSM0\" sheet do not exist in $xls\n");
      exit(1);
    }
    if ((grep (/^Table0$/, @sheet_name_list) == 0) && ($default_opt == 0) && ($check_table || $test_vector || $assertion)){
      print "ERROR ::: Cannot run options above while \"Table0\" does not exist.\n";
      exit(1);
    }
    if ((grep (/^FSM0$/, @sheet_name_list) == 0) && ($default_opt == 0) && ($fsmc || $fsmtv || $fsmast)){
      print "ERROR ::: Cannot run options above while \"FSM0\" does not exist.\n";
      exit(1);
    }
  }else{
    if ((grep (/^Table_rnm$/, @sheet_name_list) == 0) && ($check_table || $test_vector || $assertion)){
      print "ERROR ::: Cannot run options above while \"Table_rnm\" does not exist.\n";
      exit(1);
    }
  }
}else{
  $test_vector=1;
}

my @TruthTable=();
my @FSMTable=();
my @header;
my $parser=Spreadsheet::ParseExcel->new();
my $workbook=$parser->parse($xls) or die "ERROR ::: $_[0] is not found.\n";

my @clock_info = ($hash{"oscillation"},$hash{"pref_unit"},$hash{"timescale"},\@RisingFallingSeq,$hash{"max_delay"});
if ((grep (/^Table0$/, @sheet_name_list) > 0)||((grep (/^Table_rnm$/, @sheet_name_list) > 0)&&($rnm==1))||($all_ptn eq "1")){
  if ($all_ptn eq "1"){
    @TruthTable=Ex2Tbl::MakeAllPatTable(@PortTable);  # fusion table
    @header=&Ex2Tbl::get_header_comment($workbook,"Port info");
  }elsif ($rnm == 1){
    @TruthTable=Ex2Tbl::MakeTruthTable($xls,"Table_rnm",$pcheck,$pg,$rnm,\@PortTable,"",$blank_error,\@clock_info);  # fusion table
    @header=&Ex2Tbl::get_header_comment($workbook,"Table_rnm");
  }else{
    @TruthTable=Ex2Tbl::MakeTruthTable($xls,"Table0",$pcheck,$pg,$rnm,\@PortTable,"",$blank_error,\@clock_info);  # fusion table
    @header=&Ex2Tbl::get_header_comment($workbook,"Table0");
  }
}

my @fsm_header;
if (grep (/^FSM0$/, @sheet_name_list) > 0){
  @FSMTable = Ex2Tbl::MakeFSMTable($xls, $hash{"cell"});
  @fsm_header=&Ex2Tbl::get_header_comment($workbook,"FSM0");
}
if (@FSMTable==0 && ($default_opt == 0) && ($fsmc || $fsmtv || $fsmast)){
  print "ERROR ::: Cannot run options above while \"FSM0\" has no data.\n";
  exit(1);
}# not check for @TruthTable because already been checked in MakeTruthTable()

##################################
######## Truth table   ###########
##################################
my @ActionTable=();
my @VariableTable=(); # variable table for replace in truth table
my @PortRefTable=();
my @ParamTable=();  # param table 
my %RefVarTableList;
if (@TruthTable != 0){ # replace variable, pg if Table0 valid
  if (grep (/^Variable$/, @sheet_name_list) == 1){
    my ($vt,$reftl)=Ex2Tbl::MakeVariableTable($xls, $rnm, \@TruthTable, \@PortTable, $blank_error,\@clock_info);
    @VariableTable=@$vt;
    %RefVarTableList=%$reftl;
  }
  ### Parse "param" sheet if it exist
  if (grep (/^param$/, @sheet_name_list) == 1){
    @ParamTable=Ex2Tbl::MakeParamTable($xls);
    if(@ParamTable == 0){
      print("WARNING ::: Param sheet is empty. Please specify parameter table.\n");
    }
  }
  @TruthTable=Ex2Tbl::ReplaceString(\@TruthTable,\@PortTable,$rnm,0); # Replace "-","S"
  @TruthTable=Ex2Tbl::SeparateMultiPortWidth(\@TruthTable,\@PortTable,$rnm);  # separate multi portwidth 
  @PortRefTable=Ex2Tbl::GetPortRefTable($TruthTable[1],\@TruthTable,\@PortTable,$rnm);
  @TruthTable=Ex2Tbl::ReplaceInputVariable($xls,\@TruthTable, \@VariableTable, \@PortTable, $rnm, $blank_error,\@clock_info);
  @TruthTable=Ex2Tbl::CheckTableValid(\@TruthTable,\@PortTable,\@PortRefTable);
  @TruthTable=Ex2Tbl::PeriodConvert(\@TruthTable,\@PortTable,\%RefVarTableList,\@PortRefTable,\@clock_info,$rnm);
  @TruthTable=Ex2Tbl::PGExtract(\@TruthTable,\@PortTable,$pg,$pcheck); # table pick up for pg
}
my @ExcludePTN=Ex2Tbl::ExcludePTN($xls,$pg,\@PortTable,$rnm,$blank_error,\@clock_info, $hash{"assert_control"});  # exlude ptn table
if(($ex_ast==1 || $ex_ptn==1 )&& $ExcludePTN[0]==0){# case no sheet
  print("ERROR ::: Please set Exclude sheet in $xls.\n");
  exit(1);
}
if ($ExcludePTN[0] ==-1){#case have sheet, not data
  $ExcludePTN[0] = 0;
}
if ($ExcludePTN[0] != 0){
  @ExcludePTN=Ex2Tbl::ReplaceString(\@ExcludePTN,\@PortTable,$rnm,0); # Replace "-","S"
  @ExcludePTN=Ex2Tbl::SeparateMultiPortWidth(\@ExcludePTN,\@PortTable,$rnm);  # separate multi portwidth 
  @ExcludePTN=Ex2Tbl::ReplaceInputVariable($xls,\@ExcludePTN, \@VariableTable, \@PortTable, $rnm, $blank_error,\@clock_info);
  my @ExPortRefTable=Ex2Tbl::GetPortRefTable($ExcludePTN[1],\@ExcludePTN,\@PortTable,$rnm);
  @ExcludePTN=Ex2Tbl::CheckTableValid(\@ExcludePTN,\@PortTable,\@ExPortRefTable);
  @ExcludePTN=Ex2Tbl::PeriodConvert(\@ExcludePTN,\@PortTable,\%RefVarTableList,\@ExPortRefTable,\@clock_info,$rnm);
}

if (@TruthTable != 0) {
  @TruthTable = Ex2Tbl::ProcessLatchCheck(\@TruthTable,\@PortTable,\@PortRefTable,$rnm,$blank_error,\@clock_info,$lfo);
}

##################################
######## FSM table ###############
##################################
my @EventTableList=();
my @OutTableList=();
my @StateTableList=();
my @TransTableList=();
my $num_fsm=0;
if (@FSMTable!=0){
  # create tables related FSM #
  $num_fsm=scalar(@FSMTable)-1;
  for (my $i=0;$i<$num_fsm;$i++){
    my @temp_event_table=();
    my @temp_state_table=();
    my @temp_trans_table=();
    my @temp_out_table=();
    my $event_ex=0;
    my $state_ex=0;
    my $trans_ex=0;
    my $out_ex=0;
    ($event_ex, @temp_event_table)=Ex2Tbl::MakeEventTable($xls, $i, @FSMTable);
    ($state_ex, @temp_state_table)=Ex2Tbl::MakeStateTable($xls, $i, @FSMTable);
    ($trans_ex, @temp_trans_table)=Ex2Tbl::MakeTransTable($xls, $i, @FSMTable);
    ($out_ex,   @temp_out_table)  =Ex2Tbl::MakeOutTable  ($xls, $i, @FSMTable);
    @{$EventTableList[$i]}=@temp_event_table;
    @{$StateTableList[$i]}=@temp_state_table;
    @{$TransTableList[$i]}=@temp_trans_table;
    @{$OutTableList[$i]}=@temp_out_table;
    if ($event_ex + $state_ex + $trans_ex + $out_ex > 0){
      $ex=1;
    }
  }
  if ($ex==1){
    print("*** Fix all ERROR above before generating test patterns and assertions for FSM.\n");
    exit(1);
  }
  
  # Check tables related FSM #
  if ($ex==0 && $fsmc ==1){
    for(my $i=0;$i<$num_fsm;$i++){ # each FSM
      my @EventTable=@{$EventTableList[$i]};
      my @StateTable=@{$StateTableList[$i]};
      my @TransTable=@{$TransTableList[$i]};
      my @OutTable=@{$OutTableList[$i]};
    
      my @event_list = MakeOutFile::GetColumnList(\@EventTable);
      my @state_list = MakeOutFile::GetColumnList(\@StateTable);
    
      $ex=$ex+MakeOutFile::CheckTransFromOther(\@TransTable);
      $ex=$ex+MakeOutFile::CheckTransToOther(\@TransTable); # check both to other and to itself
      $ex=$ex+MakeOutFile::CheckTranStateNotDefine(\@TransTable, \@StateTable); # check non-existed state
      $ex=$ex+MakeOutFile::CountInitialState($FSMTable[$i+1][2],@TransTable); # check initial state
      $ex=$ex+MakeOutFile::CheckDuplicatedEventName(\@EventTable,\@TransTable);
      $ex=$ex+MakeOutFile::CheckDuplicatedStateName(\@StateTable,\@OutTable);
      $ex=$ex+MakeOutFile::CheckDuplicatedConds(\@EventTable, "condition");
      $ex=$ex+MakeOutFile::CheckDuplicatedConds(\@StateTable, "state");
      $ex=$ex+MakeOutFile::CheckMatchSTTAndEDT($FSMTable[$i+1][2], $FSMTable[$i+1][1], \@TransTable, \@event_list);
      $ex=$ex+MakeOutFile::CheckMatchSTTAndSDT($FSMTable[$i+1][2], $FSMTable[$i+1][3], \@TransTable, \@state_list);
      $ex=$ex+MakeOutFile::CheckMatchSTTAndODT($FSMTable[$i+1][2], $FSMTable[$i+1][4], \@TransTable, \@OutTable);
    }
  }
  if ($ex!=0){
    print("*** Fix all ERROR above before generating test patterns and assertions for FSM.\n");
    exit(1);
  }
}
use Cwd;
my $work_dir=getcwd();
chdir $hash{"out_dir"};
### check truth table ###
my $gonext="no"; # go next or not in case of -cpl option
my @miss=("","","is lacked","has overlap");
my $fin_time=-1;
my @InExTbl=($ExcludePTN[0]==0)? @TruthTable : ErksFunc::TableInEx(\@TruthTable,\@ExcludePTN,\@PortTable,$pg);
if (@TruthTable!=0){
  @PortRefTable=Ex2Tbl::GetPortRefTable($TruthTable[2],\@TruthTable,\@PortTable,$rnm);
  if($ex==0 && $check_table==1){ # check truth table
    print("\n# Check the Truth Table #\n");
    ### overlap table check
    $ex=MakeOutFile::CheckOverlap($max_error,$dcas,$hash{"overlap_log"},$rnm,\@InExTbl,\@PortRefTable,\%RefVarTableList,\@PortTable,$blank_error,\@clock_info);
    if($ex==0){
      print("***Complete to check the truth table - Truth table no overlap!\n");
      ### lack table check
      print("*** Now checking for lack. Please wait a few minutes.\n");
      if($rnm==1){
         print("WARNING ::: Because you set \"-rnm\" option, Erakis skips lack checking.\n");
      }else{
        $ex=MakeOutFile::CreateLackLogFile(1, $max_error, $dcas, $hash{"lack_log"},$rnm,\@PortTable, \@InExTbl);
        if($ex==0){
          print("***Complete to check the truth table - Truth table no lack!\n");
        }elsif($ex==2){
          print("***Complete to check the truth table - Truth table has lack:\n            - ".$hash{"out_dir"}."/".$hash{"lack_log"}."\n");
        }elsif($ex==1){
          print("ERROR  ::: Checking the truth table(Lack) is missed.\n");
        }
      }
    }elsif($ex==3){
      print("***Complete to check the truth table - Truth table has overlap:\n            - ".$hash{"out_dir"}."/".$hash{"overlap_log"}."\n");
    }elsif($ex==1){
      print("ERROR  ::: Checking the truth table(Overlap) is missed.\n");
    }
  }
  

  ### file generation ###
  # Completeness assertion for lack pattern (in case -cpl option)
  if ($ex==0 && $complete_lack==1){
    my $total_ast=Ex2Tbl::CountTotalAssertion(\@TruthTable, \@PortTable, $rnm);
    my $estimated_lack_ast=$total_ast-(scalar(@TruthTable)-4);# remove 4 first line of Truth table.
    print"WARNING  ::: The truth table's lack patterns output X.\nAnd total assertions is $estimated_lack_ast.\nIs it really all right?\n";
    $gonext=<STDIN>;
    chop($gonext);
  }
}
 # testbench
my $freq_check = 0;
my $ex_ptn_num = 0;
if(scalar(@ExcludePTN)>2){
  $ex_ptn_num = scalar(@ExcludePTN) - 2;
}

if($ex==0 && $testbench==1){
  if($ex_ptn == 1){
    Ex2Tbl::CheckPortMap(\@TruthTable, \@ExcludePTN);
  }
  print("\n# Making Testbench #\n");
  my %option;
  $option{"tv"}=$test_vector;
  $option{"ex_tv"}=$ex_ptn;
  $option{"ta"}=$assertion;
  $option{"fsmtv"}=$fsmtv;
  $option{"fsmast"}=$fsmast;
  ### Add msg_chk and param table information in making test bench
  ($ex,$freq_check)=($hash{"wave_format"}eq"ams") ?
  MakeOutFile::MakeAmsTestBench($rnm,$hash{"tb_file"},$hash{"timescale"},$hash{"cell"},$hash{"ptn_file"},$hash{"ast_file"},$pg,$hash{"max_delay"},$hash{"pref_unit"},$hash{"simulator"},$hash{"wave_format"},$hash{"include"},$lfo,$no_back,\@sdf_info,\@PortTable,\@TruthTable,\@FSMTable,\@EventTableList,\@OutTableList,\@StateTableList,\%option,$split,\@InputSeq,\%RefVarTableList,\@OutputSeq,\@PortRefTable,\@RisingFallingSeq,\@ParamTable,$ex_ast,$ex_ptn,$hash{"exclude_assertion"},$hash{"exclude_check_pattern"},\@ExcludePTN,\@InputSeqExclude)
  :
  MakeOutFile::MakeTestBench($rnm,$hash{"tb_file"},$hash{"timescale"},$hash{"cell"},$hash{"ptn_file"},$hash{"ast_file"},$pg,$hash{"max_delay"},$hash{"pref_unit"},$hash{"simulator"},$hash{"wave_format"},$hash{"include"},$lfo,$no_back,\@sdf_info,\@PortTable,\@TruthTable,\@FSMTable,\@EventTableList,\@OutTableList,\@StateTableList,\%option,$split,\@InputSeq,\%RefVarTableList,\@OutputSeq,\@PortRefTable,\@RisingFallingSeq,\@ParamTable,$ex_ast,$ex_ptn,$hash{"exclude_assertion"},$hash{"exclude_check_pattern"},\@ExcludePTN,\@InputSeqExclude);
  if($ex==0){ # successful completion
    my $vfile = $hash{"tb_file"};
    my $svfile = $hash{"tb_file"};
    if($freq_check && $hash{"simulator"} == 2){
      $svfile =~ s/\.v/\.sv/g;
      $hash{"tb_file"} = $svfile;
      print("WARNING ::: The file name of test bench is changed from $vfile to $svfile to be compiled successfully by irun.\n");
      system("mv ./$vfile ./$svfile\n");
    }
    print("***Complete to make testbench file :\n            - ".$hash{"out_dir"}."/".$hash{"tb_file"}."\n");
    if($hash{"wave_format"}eq"ams"){
      print("            - ".$hash{"out_dir"}."/AmsTop.vams\n");
    }
  }elsif($ex==1){ # abnormal exit
    print("ERROR  ::: Making testbench is missed.\n");
  }
}elsif(($ex==2 || $ex==3)&& $testbench==1){ # checking table is missed
    print("WARNING ::: Making testbench is stopped because the truth table $miss[$ex].\n");
}
 # testvector
if (@TruthTable != 0){
  if($ex==0 && $test_vector==1){
    if($ex_ptn == 1){
      Ex2Tbl::CheckPortMap(\@TruthTable, \@ExcludePTN);
    }
    print("\n# Making Test Vector #\n");
    my @TVT=();
    if($pcheck==1){ # array only pcheck on
      @TVT=Ex2Tbl::PcheckPU(@TruthTable);
      @PortRefTable=Ex2Tbl::GetPortRefTable($TVT[2],\@TVT,\@PortTable,$rnm);
    }else{
      @TVT=@TruthTable;
    }
    my $last_ptn=(scalar(@FSMTable)==0)?1:0;
    my $number_pattern_file = (scalar(@InputSeq)==0)?1:scalar(@InputSeq);
    my @pattern_files =();
    for(my $i=0;$i<$number_pattern_file;$i++){
        my @inputSeqTable = ();
        @inputSeqTable = @{$InputSeq[$i]} if scalar(@InputSeq)>0;
        my $filename = $hash{"ptn_file"};
        if($number_pattern_file > 1){
            if(@inputSeqTable != 0){
                if(defined $inputSeqTable[1][5]){
                    $filename =~ s/\.ptn/_$inputSeqTable[1][5]\.ptn/g;
                    push(@pattern_files, $filename);
                }
            }
        }
        if ($gonext =~ /(yes|y)/i){# make completeness test vector if -cpl
            ($ex,$fin_time)=MakeOutFile::MakeCompleteTestVector($last_ptn, $filename,$hash{"max_delay"},\@TVT,\@PortTable,$rnm,\@inputSeqTable,$split,$hash{"tb_file"},$testbench,\@PortRefTable,\%RefVarTableList,\@RisingFallingSeq,$message_chk,0);
        }else{
            ($ex,$fin_time)=MakeOutFile::MakeTestVector($last_ptn, $filename,$hash{"max_delay"},\@TVT,\@PortTable,$rnm,\@inputSeqTable,$split,$hash{"tb_file"},$testbench,\@PortRefTable,1,\%RefVarTableList,\@RisingFallingSeq,$message_chk,0);
        }
    }
    if($ex==0){ # successful completion
      print("***Complete to make test vector file :\n");
      if ($split > 1){
        my $pat_name = $hash{"ptn_file"};
        my $ext = $hash{"ptn_file"};
        $pat_name =~ s/\.\w+//;
        $ext =~ s/$pat_name//;
        foreach my $num(0..($split-1)){
          print("            - ".$hash{"out_dir"}."/".$pat_name."_$num$ext\n");
        }
      }elsif($number_pattern_file > 1){
        foreach my $num(0..($number_pattern_file-1)){
          print("            - ".$hash{"out_dir"}."/".$pattern_files[$num]."\n");
        }
      }else{
        print("            - ".$hash{"out_dir"}."/".$hash{"ptn_file"}."\n");
      }
    }elsif($ex==1){ # abnormal exit
      print("ERROR  ::: Making test vector is missed.\n");
      exit(1);
    }
    undef(@TVT);

    # cal max finish time - because $fin_time above not correct in case many loop in ptn
    my $tt_fin_time=MakeOutFile::CalFinTimeTruthTbl($hash{"max_delay"}, \@TruthTable, \@PortTable);
    $fin_time=($fin_time>$tt_fin_time)?$fin_time:$tt_fin_time;

  }elsif(($ex==2 || $ex==3)&& $test_vector==1){ # checking table is missed
      print("WARNING ::: Making test vector is stopped because the truth table $miss[$ex].\n");
  }
  
   # assertion
  if($ex==0 && $assertion==1){
    print("\n# Making Assertion #\n");
    @PortRefTable=Ex2Tbl::GetPortRefTable($TruthTable[2],\@TruthTable,\@PortTable,$rnm);
    ### Add simulator environment information in making assertion
    $ex=MakeOutFile::MakeAssertion($hash{"ast_file"},$pg,$rnm,\@TruthTable,\@PortTable,\@OutputSeq,\@PortRefTable,0,$hash{"simulator"},$hash{"wave_format"},"",\@header, 0);
    if($ex==0){ # successful completion
      print("***Complete to make assertion file :\n            - ".$hash{"out_dir"}."/".$hash{"ast_file"}."\n");
    }elsif($ex==1){ # abnormal exit
      print("ERROR  ::: Making assertion is missed.\n");
    }
    # completeness assertion
    if ($gonext =~ /(yes|y)/i && $rnm != -1){
      $ex=MakeOutFile::MakeCompleteAssertion("-20", $hash{"ast_file"},$pg, $rnm, \@InExTbl, \@PortTable, \@PortRefTable,$hash{"simulator"},$hash{"wave_format"});# -20 = compress all port
      system("rm -f lacklog.txt\n");
    }
    if($hash{"wave_format"}eq"ams" && $rnm == 1){
      MakeOutFile::ReplaceAMSAssertion($hash{"ast_file"},\@PortTable);
    }
  }elsif(($ex==2 || $ex==3)&& $assertion==1){ # checking table is missed
    print("WARNING ::: Making assertion is stopped because the truth table $miss[$ex].\n");
  }
}

if($ex==0 && ($ex_ast==1 || $ex_ptn==1) && $ExcludePTN[0] != 0){
  @ExcludePTN=Ex2Tbl::PGExtract(\@ExcludePTN,\@PortTable,$pg,$pcheck); # table pick up for pg
  my @ExPortRefTable=Ex2Tbl::GetPortRefTable($ExcludePTN[2],\@ExcludePTN,\@PortTable,$rnm);
  @ExPortRefTable=Ex2Tbl::UpdateRefTable(\@ExPortRefTable,\@PortRefTable);
  # assertion for Exclude sheet
  my @dummy_outseq = ();
  if($ex_ast==1){
      my @ex_header;
      print("\n# Making Assertion for exclude input #\n");
#      if(@OutputSeqExclude!=0){
##      @dummy_outseq = @OutputSeqExclude;
#        print("WARNING  ::: Sequence of output port in Exclude_Constraint sheet will be ignored.\n");
#      }
      @ex_header = &Ex2Tbl::get_header_comment($workbook,"Exclude");
      $ex=MakeOutFile::MakeAssertion($hash{"exclude_assertion"},$pg,$rnm,\@ExcludePTN,\@PortTable,\@dummy_outseq,\@ExPortRefTable,1,$hash{"simulator"},$hash{"wave_format"},$hash{"assert_control"},\@ex_header,\@InputSeqExclude);
      if($ex==0){ # successful completion
          print("***Complete to make assertion file for exclude input :\n            - ".$hash{"out_dir"}."/".$hash{"exclude_assertion"}."\n");
      }elsif($ex==1){
          print("ERROR  ::: Making assertion for exclude input is missed.\n");
      }
      if($hash{"wave_format"}eq"ams" && $rnm == 1){
          MakeOutFile::ReplaceAMSAssertion($hash{"exclude_assertion"},\@PortTable);
      }
  }
#test vector for Exclude sheet
  if($ex_ptn==1){
    print("\n# Making Test Vector in Exclude sheet #\n");
    my $last_ptn=1;
    ($ex,$fin_time)=MakeOutFile::MakeTestVector($last_ptn, $hash{"exclude_check_pattern"},$hash{"max_delay"},\@ExcludePTN,\@PortTable,$rnm,\@InputSeqExclude,$split,$hash{"tb_file"},$testbench,\@ExPortRefTable,0,\%RefVarTableList,\@RisingFallingSeqExclude,$message_chk,$ex_ptn_num);
    if($ex==0){ # successful completion
      print("***Complete to make test vector file for exclude input :\n            - ".$hash{"out_dir"}."/".$hash{"exclude_check_pattern"}."\n");
    }
  }
}

### Generate test patterns and assertions for FSM (if having FSM)
if (@FSMTable !=0){
  if (($ex==0) && ($fsmtv==1 || $fsmast==1)){
    for(my $i=0;$i<$num_fsm;$i++){ # each FSM
      my @EventTable=@{$EventTableList[$i]};
      my @StateTable=@{$StateTableList[$i]};
      my @TransTable=@{$TransTableList[$i]};
      my @OutTable=@{$OutTableList[$i]};
  
      # Create input file
      MakeOutFile::CreateSTTInputFile("input.stt",\@TransTable, \@StateTable);
  
      # Run haskel script
      my $BS = $ENV{'BS'};
      if (defined($BS)) {
        system ("$BS run_fsm input &> /dev/null\n");
        system ("sleep 3");
      } else {
        system ("run_fsm input &> /dev/null\n");
      }
  
      # Read output of script
      my ($ex,@StatePaths)=MakeOutFile::CreateStatePath("input.stt.log");
      if ($ex==1){
        system("rm -f input.stt*\n");
        system("rm -f input.csp*\n");
        exit(1);
      }
      my @EventPaths=MakeOutFile::CreateEventPath(\@StatePaths, \@TransTable, \@StateTable);
  
      # Generate test pattern for FSM
      if ($fsmtv == 1){
        my @clock=MakeOutFile::create_clock_table(\@PortTable, \@FSMTable);
        $fin_time=MakeOutFile::GenerateFSMPatterns($fin_time, $i, \@clock, \@StatePaths, \@EventPaths, \@TransTable, \@StateTable, \@EventTable, \@FSMTable, \@PortTable, \@TruthTable);
        print("***Complete to make FSM test vectors file :\n            - ".$hash{"out_dir"}."/".$FSMTable[1+$i][0].".ptn\n");
      }
      # Generate assertion for FSM
      if ($fsmast ==1){
        MakeOutFile::GenerateFSMAssertion($work_dir,$xls, $i, \@StatePaths, \@StateTable, \@EventTable, \@TransTable, \@FSMTable, \@OutTable, \@PortTable, $rnm, \@clock_info,$hash{"wave_format"},\@fsm_header,$all_ptn);
        print("***Complete to make FSM assertions file :\n            - ".$hash{"out_dir"}."/".$FSMTable[1+$i][0]."_ast.sv\n");
      }
      system("rm -f input.stt*\n");
      system("rm -f input.csp*\n");
    }
  }
}

 # shell script
if($ex==0 && $hash{"simulator"}!=0){
  my $SIM=($hash{"simulator"}==1)?"VCS":
           ($hash{"simulator"}==2)?"incisive":"";
  $SIM = "incisive" if ($hash{"wave_format"}eq"ams");
  print("\n# Making Execution shell script for $SIM #\n");
  if($fin_time==-1){
    $fin_time=$hash{"max_delay"}*66536; # 2^16 ptn
  }
  $ex=($hash{"wave_format"}eq"ams")?MakeOutFile::MakeAMSScript($hash{"tb_file"},$hash{"Incisive"},$hash{"virtuoso"},$hash{"cell"},$hash{"cds.lib"},$hash{"lib_name"},$hash{"view_name"},$fin_time,$hash{"timescale"},$hash{"ConnectRule"},$hash{"option"},$rnm,$hash{"rnm_lib"}):
      ($hash{"simulator"}==1)?MakeOutFile::MakeVcsScript($hash{"tb_file"},$hash{"wave_format"},$hash{"VCS"},$hash{"Verdi"},$hash{"verilog"},$split,$hash{"ptn_file"},$rnm, $hash{"rnm_lib"}, $hash{"timescale"},$freq_check, $hash{"option"}, \@sdf_info,\@pattern_group,@TruthTable):
      ($hash{"simulator"}==2)?MakeOutFile::MakeIusScript($hash{"tb_file"},$hash{"wave_format"},$hash{"Incisive"},$hash{"Verdi"},$hash{"verilog"},$split,$hash{"ptn_file"},$rnm, $hash{"rnm_lib"}, $hash{"timescale"},$hash{"max_delay"},$freq_check,$hash{"option"},\@sdf_info,\@pattern_group,@TruthTable):1;
  $hash{"simulator"}=($hash{"wave_format"}eq"ams")?"            - ".$hash{"out_dir"}."/run_irun\n            - ".$hash{"out_dir"}."/".$hash{"cell"}.".ocn\n            - ".$hash{"out_dir"}."/probe.tcl\n            - ".$hash{"out_dir"}."/amsControlSpectre.scs\n":
                  ($hash{"simulator"}==1)?"            - ".$hash{"out_dir"}."/infile.f\n            - ".$hash{"out_dir"}."/run_vcs\n":
                  ($hash{"simulator"}==2)?"            - ".$hash{"out_dir"}."/infile.f\n            - ".$hash{"out_dir"}."/run_irun\n":$hash{"simulator"};
  if($ex==0){ # successful completion
    printf("***Complete to make execution shell script file for $SIM :\n%s",$hash{"simulator"});
  }elsif($ex==1){ # abnormal exit
    print("ERROR  ::: Making execution shell script for $SIM is missed.\n");
  }
}elsif(($ex==2 || $ex==3)&& $hash{"simulator"}!=0){ # checking table is missed
    print("WARNING ::: Making execution shell script is stopped because the truth table $miss[$ex].\n");
}

# table check has lack or overlap is clean:
if($ex==2 || $ex==3){
  $ex=0;
}

1;
exit($ex);
