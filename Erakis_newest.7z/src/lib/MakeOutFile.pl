#!/bin/perl
use strict;
use warnings;
require 'Ex2Tbl.pl';
package MakeOutFile;

my $global_test_size = 0;

### Make Testbench ###
sub MakeTestBench{ 
  my ($rnm, $file, $timescale, $cell, $vct, $ast, $pg, $delay, $unit, $sim, $wave, $include, $lfo, $no_back, $sdf, $p0rt, $tbl, $fsm, $evtl, $otl, $stl, $opth, $split, $insq, $reftl, $outseq_,$port_ref, $rfseq_,$param_tbl,$ex_ast,$ex_ptn,$ex_ast_file,$ex_ptn_file,$exclude,$inseqexclude)=@_;
  my @port=@$p0rt;
  my @org_table=@$tbl;
  my @table=Ex2Tbl::FilterTruthTable(@$tbl);
  my @fsmtable=@$fsm;
  my @eventlist=@$evtl;
  my @outlist=@$otl;
  my @statelist=@$stl;
  my %hashoption=%$opth;
  my @inseq=@$insq;
  my %ref_var_tbl_list=%$reftl;
  my $path=`pwd`;
  my $fix_num = 3;
  my @outseq=@$outseq_;
  my @port_ref_table = @$port_ref;
  my @ExcludePTN = @$exclude;
  my @InputSeqExclude = @$inseqexclude;
  my $freq_check = 0;
  my $check_point = 10000; # check point for check message
  my @param=@$param_tbl;
  my @sdf_info=@$sdf;
  my $inport_FB="";
  my $outport_FB="";
  my $is_fb_on=0;
  my @force_num_pat;
  my %force_index;
  my %force_value;
  my $condition_of_end_force=1;
  my $inc_index=5;
  ## Get the port name of FB
  for(my $i=0;$i<scalar(@{$port[0]});$i++){
     if($port[18][$i] =~ /FB_INPUT/){
        $inport_FB = $port[0][$i];   
     }elsif($port[18][$i] =~ /FB_OUTPUT/){
        $outport_FB = $port[0][$i];   
     }
  }
  $path=~s/\n//;
  open(my $TB,"> $file");
    return(1,0) if(!(fileno($TB)));
    my($se, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst)=localtime(time);
    my $exe_date=sprintf("%04d\/%02d\/%02d %02d:%02d:%02d",$year+1900,$mon+1,$mday,$hour,$min,$se);
    my $version=$ENV{'ERAKIS_VER'};
#    my $user=$ENV{'USERNAME'};
    my $user=$ENV{'USER'};

    # header
    print($TB "////////////////////////////////////////////////////////////////////////////\n");
    print($TB "/// DATE : $exe_date\n");
    print($TB "/// USER : $user\n");
    print($TB "/// TOOL : $version\n");
    print($TB "////////////////////////////////////////////////////////////////////////////\n");

    # Dump control message check
    my $num_of_clock_change = 0;
    my @clock_change = ();
    my %clock_change_list;
    my $msg_col = -1;
    my $pulse_width_col = -1;   ### check if there is pulse width in truth table to generate high pulse width in clock generation 
    if (@table != 0){
      for(my $j=2;$j<scalar(@{$org_table[1]});$j++){
        if($org_table[0][$j] eq "message"){
          $msg_col=$j;
        }
        if($org_table[0][$j] eq "clock"){
          if (not exists $clock_change_list{"$org_table[2][$j]"}) {
            $num_of_clock_change++;
            push (@clock_change,$org_table[2][$j]);
            $clock_change_list{"$org_table[2][$j]"} = $org_table[2][$j];
          }
        }
        if($org_table[0][$j] eq "high pulse width"){
            $pulse_width_col=1;
        }
      }
    }else{
#        print("ERROR ::: Table0 does not exist.\n"); #cov
#        exit(3);
    }

    # define parameter
    my $total_port_num = 0;
    my $freqchk_port_num = 0;
    my $mem_size = 0;
    my @port_type = ();
    my @assigndec = ();
    my @port_index_ref=(-1)x (scalar(@{$table[0]})-2);
    my @port_type_ref=(-1)x (scalar(@{$table[0]})-2);
    my $port_val_ref ="";
    my $port_name_list ="";
    my @port_list_truth =();
    my $max_sub_mode_num = CalMaxSubMode(\@table);
    if (@table != 0) {
      for(my $j=scalar(@{$table[2]})-1;$j>=0;$j--){
        my $tmp_str = "";
        if (($table[0][$j] =~ /power|ground|input|electrical_in|^reg/)||($table[0][$j] eq "inout")){
          $port_index_ref[$j]=$total_port_num;
          for(my $i=0;$i<scalar(@{$port[0]});$i++){
            if(Ex2Tbl::cmp_port_name($table[2][$j], $port[10][$i]) == 1){
              if(($port[13][$i] ne "-")&&($rnm==1)){ # real port
                $port_type[$total_port_num] = 1;
                $port_type_ref[$j] = 1;
                $port_val_ref="(%0.3f)".$port_val_ref;
                if (($wave eq "ams")&&($rnm == 1)&&($port[2][$i] eq "A")&&($port[1][$i] !~ /power|ground|clock/)) {
                  $port_name_list=$table[2][$j].",".$port_name_list;
                }else{
                  $port_name_list=$table[2][$j].".r,".$port_name_list;
                }
                if ($port[1][$i] eq "inout"){
                  if (($wave eq "ams")&&($rnm == 1)&&($port[2][$i] eq "A")&&($port[1][$i] !~ /power|ground|clock/)) {
                    push(@assigndec,"  assign $table[2][$j]\t= (port_dir[$total_port_num])?real_reg[$total_port_num].r:1'bz;\n");
                  } else {
                    push(@assigndec,"  assign $table[2][$j]\t= (port_dir[$total_port_num])?real_reg[$total_port_num]:'{'hz,`wrealZState};\n");
                  }
                }else{
                  if (($wave eq "ams")&&($rnm == 1)&&($port[2][$i] eq "A")&&($port[1][$i] !~ /power|ground|clock/)) {
                    push(@assigndec,"  assign $table[2][$j]\t= (sig_sel==0)?$table[2][$j]_erks:real_reg[$total_port_num].r;\n");
                  }else{
                    push(@assigndec,"  assign $table[2][$j]\t= (sig_sel==0)?$table[2][$j]_erks:real_reg[$total_port_num];\n");
                  }
                }
              }else{ # normal port
                $port_type[$total_port_num] = 0;
                $port_type_ref[$j] = 0;
                $port_val_ref="%0b".$port_val_ref;
                $port_name_list=$table[2][$j].",".$port_name_list;
                my $temp = $table[2][$j];
                if($table[2][$j] =~ /\[/){
                  my @tmp  = split(/\[/, $temp);
                  $temp =$tmp[0]."_erks[".$tmp[1];
                }else{
                  $temp =  $table[2][$j]."_erks";
                }
                if ($port[1][$i] eq "inout"){
                  push(@assigndec,"  assign $table[2][$j]\t= (port_dir[$total_port_num])?port_reg[$total_port_num]:1'bz;\n");
                }else{
                  if ($port[1][$i] !~ /power|ground/) {
                    push(@assigndec,"  assign $table[2][$j]\t= (sig_sel==0)?$temp:port_reg[$total_port_num];\n");
                  }else{
                    push(@assigndec,"  assign $table[2][$j]\t= port_reg[$total_port_num];\n");
                  }
                }
              }
              $mem_size += 64; # max value for each port (time sequence is set to 64 bit)
              if(grep(/$table[2][$j]/,@port_list_truth)<1){
                  push(@port_list_truth, $table[2][$j]);
              }
              last;
            }else{
              if($table[0][$j] eq "reg"){
                push(@assigndec,"  assign $table[2][$j]\t= port_reg[$total_port_num];\n");
                $mem_size += 64; # max value for register (time sequence is set to 64 bit)
                last;
              }
#              $port_index_ref[$j]=-1;
#              $port_type_ref[$j]=-1;
            }
          }
          $total_port_num++;
        }else{
          $port_index_ref[$j]=-1;
          $port_type_ref[$j]=-1;
        }
      }
    }
    for(my $i=0;$i<scalar(@{$table[0]});$i++){
        if($table[0][$i] eq "FB"){
          $mem_size = $mem_size + 64;
        }
    }
    # include file 
    if(defined $include){
        if($include ne ""){
            my @inc = split(/\n/,$include);
            for(my $i=0;$i<scalar(@inc);$i++){
                print($TB "\`include \"$inc[$i]\"\n");
            }
        }
    }
    # timescale and module declare
    print($TB "\n\`timescale $timescale\n\n");
    if ($rnm != 1){ 
      print($TB "FREQ_CHECK\n");
    }
    my $check_edge_cond = "";
    print($TB "parameter PORT_NUM       = $total_port_num;  // total port number\n");
    if ((@table !=0) && ($hashoption{"tv"} == 1 || $hashoption{"ex_tv"} == 1)){
        for (my $i=0;$i<scalar(@inseq);$i++) {
            my @inseq_tmp = @{$inseq[$i]};
            for (my $j=0;$j<scalar(@inseq_tmp);$j++) {
                if ($inseq_tmp[$j][3] =~ /^(ERKSRISE_|ERKSFALL_)/) {
                    $check_edge_cond = 1;
                    last;
                }
            }
        }
      print($TB "parameter DONTCARE_TYPE  = 4'b0000; // *(dont care) value test vector\n");
      print($TB "parameter CROSS_TYPE     = 4'b0001; // -(cross) value test vector\n");
      print($TB "parameter S_TYPE         = 4'b0010; // S value test vector\n");
      if($rnm == 1){
        print($TB "parameter RAMP_TYPE      = 4'b0011; // ramp wave test vector\n");
      }
      print($TB "parameter NORMAL_VALUE   = 4'b0100; // normal value test vector\n\n");
      print($TB "parameter EXP_NOT_0_VAL  = 4'b0101; // value not 0\n");
      print($TB "parameter EXP_NOT_1_VAL  = 4'b0110; // value not 1\n");
      print($TB "parameter EXP_NOT_X_VAL  = 4'b0111; // value not x\n");
      print($TB "parameter EXP_NOT_Z_VAL  = 4'b1000; // value not z\n");
      print($TB "parameter EXP_RISING     = 4'b1001; // rising (0 -> 1)\n");
      print($TB "parameter EXP_FALLING    = 4'b1010; // falling (1 -> 0)\n");
      print($TB "parameter FIXED_0        = 4'b0000; // value is fixed to 0\n");
      print($TB "parameter FIXED_1        = 4'b0001; // value is fixed to 1\n");
      print($TB "parameter FIXED_X        = 4'b0010; // value is fixed to x\n");
      print($TB "parameter FIXED_Z        = 4'b0011; // value is fixed to z\n");
      print($TB "parameter UNFIXED        = 4'b0100; // value is unfixed\n");
      my $max_mode = $max_sub_mode_num > 0 ? $max_sub_mode_num:1;
      print($TB "parameter MAX_SUB_MODE_NUM       = $max_mode;  // max sub mode number\n\n");
      print($TB "parameter GET_TVT_TYPE\t= 4'b0000;  // test vector type\n");
      print($TB "parameter GET_DELAY\t= 4'b0001;  // port delay\n");
      print($TB "parameter GET_ENABLE\t= 4'b0010;  // port enable\n");
      print($TB "parameter GET_MODE\t= 4'b0011;  // mode\n");
      print($TB "parameter GET_PORT_VALUE= 4'b0100;  // port value\n");
      if($num_of_clock_change ne "0") {
        my $num_of_param = $num_of_clock_change + 6;
        for (my $i=5;$i<$num_of_param-1;$i++) {
          printf($TB "parameter GET_".uc($clock_change[$i-5])."_PERIOD\t= 4'b%04b;  // clock period\n",$i);
          $inc_index++;
        }
      }
      if($pulse_width_col ==1){
        printf($TB "parameter GET_PULSE_WIDTH\t= 4'b%04b;  // high pulse width\n",$inc_index);
        $inc_index++;
      }
      printf($TB "parameter GET_PORT_SEQ\t= 4'b%04b;  // port sequence\n",$inc_index);
      $inc_index++;
      printf($TB "parameter GET_DATA_INDEX\t= %d;\n\n",$inc_index);
      $inc_index++;

      print($TB "parameter PORT_DISABLED  = 1'b0;    // port is disable as input port (for inout port only)\n");
      print($TB "parameter PORT_ENABLED   = 1'b1;    // port is enable as input port\n\n");
      if($rnm == 1){
        print($TB "parameter REAL_PORT_TYPE  =1'b1;    // real port\n");
      }
      print($TB "parameter NORMAL_PORT_TYPE=1'b0;    // normal port\n\n");
      print($TB "parameter MODE_GEN               = 0;\n");
#      print($TB "parameter SUB_MODE0_GEN               = 1;\n");
      my $val = 0;
      for(my $num_sub=0; $num_sub<$max_sub_mode_num; $num_sub++){
        $val = $num_sub+1;
        print($TB "parameter SUB_MODE$num_sub\_GEN               = $val;\n");
      }
      $val = $val+1;
      print($TB "parameter TEST_GEN               = $val;\n");
      $val = $val+1;
      print($TB "parameter RESERVED               = $val;\n");
      print($TB "parameter MAIN_MODE_VECTOR       = 4'b0001; // indicate mode vector pattern\n");
      print($TB "parameter LATCH_MODE_VECTOR      = 4'b0010; // indicate latch check test vector\n");
      print($TB "parameter SUB_MODE_VECTOR        = 4'b0001; // indicate sub mode test vector\n\n");
      print($TB "parameter LAST_SUB_MODE_VECTOR        = 4'b0010; // indicate last sub mode test vector\n\n");
      print($TB "parameter INITIAL                = 6'b000000; // Initial state\n");
      print($TB "parameter LOAD_MODE              = 6'b000001; // Mode is loaded\n");
      print($TB "parameter LOAD_SUB_MODE          = 6'b000010; // Sub mode is loaded\n");
      print($TB "parameter EXEC_MODE              = 6'b000011; // Execute loaded mode\n");
      print($TB "parameter EXEC_SUB_MODE          = 6'b000100; // Execute sub loaded mode\n");
      print($TB "parameter EXEC_PRE_MODE          = 6'b000101; // Execute previous loaded mode\n");
      print($TB "parameter EXEC_TEST_VECTOR       = 6'b000110; // Execute sub loaded mode\n");
      print($TB "parameter MODE_SET_VALUE         = 6'b000111; // Start latch check mode\n");
      print($TB "parameter MODE_HOLD_START        = 6'b001000; // Hold start\n");
      print($TB "parameter MODE_INPUT_CHANGE      = 6'b001001; // Input change\n");
      print($TB "parameter MODE_THROUGH           = 6'b001010; // Through\n");
      print($TB "parameter MODE_HOLD              = 6'b001011; // Hold\n");
      print($TB "parameter TEST_INPUT_CHANGE      = 6'b001100; // Input change\n");
      print($TB "parameter TEST_THROUGH           = 6'b001101; // Through\n");
      print($TB "parameter TEST_HOLD              = 6'b001110; // Hold\n");
      print($TB "parameter MODE_HOLD_START_SELF   = 6'b011000; // Hold start\n");
      print($TB "parameter MODE_INPUT_CHANGE_SELF = 6'b011001; // Input change to its value\n");
      print($TB "parameter MODE_THROUGH_SELF      = 6'b011010; // Through\n");
      print($TB "parameter MODE_HOLD_SELF         = 6'b011011; // Hold\n");
      print($TB "parameter TEST_INPUT_CHANGE_SELF = 6'b011100; // Input change to its value\n");
      print($TB "parameter TEST_THROUGH_SELF      = 6'b011101; // Through\n");
      print($TB "parameter TEST_HOLD_SELF         = 6'b011110; // Hold\n");
      if($lfo eq "1"){
        print($TB "parameter HOLD_FORCE             = 6'b100000; // Hold force\n");
        print($TB "parameter BACK_TO_HOLD           = 6'b100001; // Back to hold\n");
        my $index = 2;
        for(my $i=0;$i<scalar(@org_table);$i++){
          if($org_table[$i][1] =~ /FORCE/){
            my $force_state = 32+$index;
            printf($TB "parameter $org_table[$i][1]              = 6'b%b; // Force output\n",$force_state);
            $index++;
          }
       }
      }
      print($TB "parameter MEM_SIZE = $mem_size;\n");
      print($TB "parameter TEST_VECTOR_SIZE = <to_be_replaced>;\n");
      print($TB "`define CUR_SUB_MODE_GEN    (sub_mode_index+1)\n");
    }
    my $string_reg = 0;
    for (my $j=2;$j<scalar(@{$org_table[0]});$j++){
        if ($org_table[0][$j] eq "string_reg") {
            $string_reg = $j;
        }
    }

    print($TB "\nmodule TestBCover;\n");
    for(my $i=0; $i<scalar(@{$table[0]}); $i++){
      if($table[0][$i] eq "FB"){
        $is_fb_on = 1;
      }
    }
    # port declare
    my $print="";
    my @portname_list=();
    my $is_mbw=-1; # indicate multiple bitwidth
    my $msb=0;
    my $lsb=0;
    for(my $i=0;$i<scalar(@{$port[0]});$i++){
      if(($pg==1 || ($pg==0 && ($port[1][$i] !~ /power|ground/)))&&(grep(/^$port[10][$i]$/,@portname_list)<1)){
        if ($port[11][$i] eq "-"){
          if (($wave eq "ams")&&($rnm == 1)&&($port[2][$i] eq "A")&&($port[1][$i] !~ /power|ground/)) {
              $print=($port[1][$i] =~ /input|electrical_in|output|inout|electrical_out/) ? $print."  real ".wireg_bit($port[10][$i],0,0)."\;\n" :  $print;
          } else {
            if (($port[13][$i] ne "-")&&($rnm == 1)){
              $print=($port[1][$i] =~ /power|ground|input|electrical_in/) ? $print."  nt::Real ".wireg_bit($port[10][$i],0,0)."\;\n" :
                      ($port[1][$i] =~ /output|inout|electrical_out/) ? $print."  SVreal ".wireg_bit($port[10][$i],0,0)."\;\n" :  $print;
              if(($port[1][$i] =~ /input|electrical_in|inout/) && (grep(/$port[10][$i]/,@port_list_truth)>0)){
                $print=$print."  nt::Real $port[10][$i]_erks;\n";
              }
            }else{
              $print=($port[1][$i] =~ /power|ground|input|electrical_in/) ? $print."  reg ".wireg_bit($port[10][$i],0,0)."\;\n" :
                      ($port[1][$i] =~ /output|inout|electrical_out/) ? $print."  wire ".wireg_bit($port[10][$i],0,0)."\;\n" :  $print;
              if(($port[1][$i] =~ /input|electrical_in/) && (grep(/$port[10][$i]/,@port_list_truth)>0)){
                $print=$print."  reg  ".wireg_bit_inter_var($port[10][$i],0,0)."\;\n";
              }
            }
          }
          # real variable to covert SVreal before assertion in IES
          if(($port[13][$i] ne "-")&&($rnm == 1)&&($port[1][$i] =~/output|inout|electrical_out|input|electrical_in/)&&($sim ==2) && $wave ne "ams"){
            $print=$print."  real  ".wireg_bit($port[10][$i],0,0)."_c\;\n"
          }
        }else{
          $msb=(split(/:/,$port[11][$i]))[0];
          $lsb=(split(/:/,$port[11][$i]))[1];
          if (($wave eq "ams")&&($rnm == 1)&&($port[2][$i] eq "A")&&($port[1][$i] !~ /power|ground/)) {
                $print=($port[1][$i] =~ /input|electrical_in|output|inout|electrical_out/) ? $print."  wreal $port[10][$i] [$msb:$lsb];\n" :  $print;
          }else{
            if (($port[13][$i] ne "-")&&($rnm == 1)){
                $print=($port[1][$i] =~ /power|ground|input|electrical_in/) ? $print."  nt::Real $port[10][$i] [$msb:$lsb];\n" :
                        ($port[1][$i] =~ /output|inout|electrical_out/) ? $print."  SVreal $port[10][$i] [$msb:$lsb];\n" :  $print;
                if(($port[1][$i] =~ /input|electrical_in|inout/) && (grep(/$port[10][$i]/,@port_list_truth)>0)){
                    $print=$print."  nt::Real $port[10][$i]_erks;\n";
                }
            }else{
              $print=($port[1][$i] =~ /power|ground|input|electrical_in/) ? $print."  reg  ".wireg_bit($port[10][$i],$msb,$lsb)."\;\n" :
                ($port[1][$i] =~ /output|inout|electrical_out/) ? $print."  wire ".wireg_bit($port[10][$i],$msb,$lsb)."\;\n" :  $print;
              if(($port[1][$i] =~ /input|electrical_in/) && (grep(/$port[10][$i]/,@port_list_truth)>0)){
                $print=$print."  reg  ".wireg_bit_inter_var($port[10][$i],$msb,$lsb)."\;\n";
              }
            }
          }
          # real variable to covert SVreal before assertion in IES #cov
#          if(($port[13][$i] ne "-")&&($rnm == 1)&&($port[1][$i] =~/output|inout|electrical_out/)&&($sim ==2 ) && $wave ne "ams"){
#            $print=$print."  real $port[10][$i]_c [$msb:$lsb];\n";
#          }
        }
        push(@portname_list,$port[10][$i]);
      }
    }
    if ($rnm == 1) {
      print($TB "  nettype nt::SVreal SVreal;\n");
    }
    print($TB "$print");  
    for(my $i=0;$i<scalar(@{$table[0]});$i++){
      if($table[0][$i] eq "reg"){
        print($TB "  reg $table[2][$i];\n");
      }
    }
    print($TB "\n");  
    for (my $j=2;$j<scalar(@{$org_table[0]});$j++){
        if ($org_table[0][$j] eq "string_reg") {
            print($TB "  reg [1023:0] $org_table[2][$j];\n");
        }
    }
    # print parameters  from "param" sheet
    if(@param != 0){
      for(my $j=1;$j<scalar(@{$param[0]});$j++){
        if(defined $param[0][$j] && defined $param[1][$j] && $param[0][$j] ne "" && $param[1][$j] ne ""){
          print($TB "  parameter   $param[0][$j]    \t=  $param[1][$j];\n");
        }
      }
      print($TB "\n");
    }

    my $clock_source = "";
    my %clock_source_list;
    my $clock_period = 0;
    if (@table != 0){
      # print code generation clock for truth table if clock source is existed
      for(my $i=0;$i<scalar(@{$port[0]});$i++){
        if ($port[1][$i] eq "clock") {
          $clock_period=$port[6][$i];# clock_period
          $clock_source = $port[0][$i];
          if (not exists $clock_source_list{"$clock_source"}) {
            $clock_source_list{"$clock_source"} = $clock_period;
            print($TB "  reg $clock_source;\n");
          }
        }
      }
    }

    # declare port for FSM: clk, rst, event signal, output signal (if having FSM)
    my @clock=();
    my @reset=();
    if (@fsmtable != 0){
      @clock=create_clock_table(\@port, \@fsmtable);
      for (my $fsmid=0;$fsmid<scalar(@fsmtable)-1;$fsmid++){# for each fsm
        my $rst=get_rst_name($fsmid, \@fsmtable,0);
        if (grep(/^$rst$/, @reset)<1){# if not exist
          push(@reset, $rst);
        }
      }
    }

    # connection
    print($TB "  $cell TopInst\(");
    $print="";
    @portname_list=();
    for(my $i=0;$i<scalar(@{$port[0]});$i++){
      if(($pg==1 || ($pg==0 && ($port[1][$i] !~ /power|ground/)))&&(grep(/^$port[10][$i]$/,@portname_list)<1)){
        $print=$print.".$port[10][$i]\($port[10][$i]\), ";
        push(@portname_list,$port[10][$i]);
      }
    }
    $print=~s/,\s$//;
    print($TB "$print\);\n\n");

    # bind FSM
    if (@fsmtable != 0){
      for(my $fsmid=0;$fsmid<scalar(@fsmtable)-1;$fsmid++){
        my $fsmname=$fsmtable[$fsmid+1][0];
        my $bind="bind $fsmname ast_$fsmname ${fsmname}_assertion (";

        my $clk=get_clk_name($fsmid, @fsmtable);
        my $rst=get_rst_name($fsmid, \@fsmtable,0);

        # declare module of assertion FSM
        my $md="";
        my @event=@{$eventlist[$fsmid]};
        my @out=@{$outlist[$fsmid]};
        my @state=@{$statelist[$fsmid]};

        $bind=~s/$/ .$clk($clk),/;
        $bind=~s/$/ .$rst($rst),/;
        for (my $i=0;$i<scalar(@{$event[0]})-1;$i++){ # not get [event]
          $bind=~s/$/ .$event[0][$i]($event[0][$i]),/;
        }
        for (my $i=1;$i<scalar(@{$out[0]});$i++){ #not get [state]
          $bind=~s/$/ .$out[0][$i]($out[0][$i]),/;
        }
        for (my $i=0;$i<scalar(@{$state[0]})-1;$i++){ # not get [state]
          $bind=~s/$/ .$state[0][$i]($state[0][$i]),/;
        }
        $bind=~s/,$/);/;
        print($TB "  $bind\n");
      }
    }
    print($TB "\n");

    if (@fsmtable != 0 && @table == 0){
      # print code generation clock for FSM (if having FSM)
      for(my $row=0;$row<scalar(@clock);$row++){
        my $gen_clk="";
        my $half_cycle=$clock[$row][1]>>1;# half cycle
        my $clkname=$clock[$row][0];
        $gen_clk=$gen_clk."  always begin\n";
        $gen_clk=$gen_clk."    #$half_cycle $clkname <= ~$clkname;\n";
        $gen_clk=$gen_clk."  end\n\n";
        print($TB "$gen_clk");
      }
    }
    
    $port_name_list=~s/,$//;
    my $in_out_seq = -1;
    my $out_out_seq = -1;
    my %hash_in_out;
    my %hash_out_out;
    my $out_index_cnt = 0;
    my @rising_clock_cnt = ();
    my @falling_clock_cnt = ();
    my @fall_cond = ();
    my @rise_cond = ();
    my @change_cond = ();
    my @osc_cond = ();
    if (@outseq != 0){
      for (my $i=1;$i<scalar(@outseq);$i++){
        if ($outseq[$i][4] =~ /pos/) {
          next if(grep (/^\Q$outseq[$i][6]\E$/,@rising_clock_cnt) > 0);
          push (@rising_clock_cnt,$outseq[$i][6]);
        } elsif ($outseq[$i][4] =~ /neg/) {
          next if(grep (/^\Q$outseq[$i][6]\E$/,@falling_clock_cnt) > 0);
          push (@falling_clock_cnt,$outseq[$i][6]);
        }
      }
      for (my $i=1;$i<scalar(@outseq);$i++){
        my $from_port_name = $outseq[$i][2];
        my $to_port_name = $outseq[$i][3];
        $from_port_name =~ s/\(.*\)\s*//;
        $to_port_name =~ s/\(.*\)\s*//;
        if ($outseq[$i][2] =~ /\(fall\)/){
          push (@fall_cond,$from_port_name) if(grep (/^\Q$from_port_name\E$/,@fall_cond) == 0);
        }
        if ($outseq[$i][2] =~ /\(rise\)/){
          push (@rise_cond,$from_port_name) if(grep (/^\Q$from_port_name\E$/,@rise_cond) == 0);
        }
        if ($outseq[$i][2] =~ /\(osc\)/){
          push (@osc_cond,$from_port_name) if(grep (/^\Q$from_port_name\E$/,@osc_cond) == 0);
        }
        if ($outseq[$i][3] =~ /\(osc\)/){
          push (@osc_cond,$to_port_name) if(grep (/^\Q$to_port_name\E$/,@osc_cond) == 0);
        }
        if ($outseq[$i][4] =~ /^(pos|neg)?\s*\d+$/) {
          push (@change_cond,$from_port_name) if (grep (/^\Q$from_port_name\E$/,@change_cond) == 0 and $outseq[$i][2] !~ /\((fall|rise)\)/);
        }
      }
    }
    if (@InputSeqExclude != 0){
      for (my $i=1;$i<scalar(@InputSeqExclude);$i++){
        my $from_port_name = $InputSeqExclude[$i][2];
        my $to_port_name = $InputSeqExclude[$i][3];
        $from_port_name =~ s/\(.*\)\s*//;
        $to_port_name =~ s/\(.*\)\s*//;
#        if ($InputSeqExclude[$i][2] =~ /\(fall\)/){
#          push (@fall_cond,$from_port_name) if(grep (/^\Q$from_port_name\E$/,@fall_cond) == 0);
#        }
#        if ($InputSeqExclude[$i][2] =~ /\(rise\)/){
#          push (@rise_cond,$from_port_name) if(grep (/^\Q$from_port_name\E$/,@rise_cond) == 0);
#        }
#        if ($InputSeqExclude[$i][2] =~ /\(osc\)/){
#          push (@osc_cond,$from_port_name) if(grep (/^\Q$from_port_name\E$/,@osc_cond) == 0);
#        }
#        if ($InputSeqExclude[$i][3] =~ /\(osc\)/){
#          push (@osc_cond,$to_port_name) if(grep (/^\Q$to_port_name\E$/,@osc_cond) == 0);
#        }
        if ($InputSeqExclude[$i][4] =~ /^(pos|neg)?\s*\d+$/) {
          push (@change_cond,$from_port_name) if (grep (/^\Q$from_port_name\E$/,@change_cond) == 0 and $InputSeqExclude[$i][2] !~ /\((fall|rise)\)/);
        }
      }
    }

    if ((@table !=0) && ($hashoption{"tv"} == 1 || $hashoption{"ex_tv"} == 1)){
      if($rnm == 1){
        print($TB "  nt::Real real_reg[PORT_NUM-1:0];\n");
        print($TB "  nt::Real temp_real_reg[PORT_NUM-1:0];\n");
        print($TB "  nt::Real mode_real_pattern[PORT_NUM-1:0];\n");
        print($TB "  nt::Real test_real_pattern[PORT_NUM-1:0];\n");
      }
      if($is_fb_on == 1){
        print($TB "  reg fb_reg;\n");
        print($TB "  reg update_fb;\n");
        print($TB "  reg port_en_fb;\n");
        print($TB "  reg [63:0] port_delay_fb;\n");
        print($TB "  reg port_value_fb;\n");
        print($TB "  reg [1:0]  normal_value_fb;\n");
      }
      print($TB "  reg [MEM_SIZE:0] port_index_mem[MAX_SUB_MODE_NUM+1:0];   // indicate port index\n");
      print($TB "  reg test_gen_trigger[MAX_SUB_MODE_NUM+1:0]; // trigger the generation\n");
      print($TB "  reg update_enable[MAX_SUB_MODE_NUM+1:0];    // enable updating the test pattern\n");
      print($TB "  reg latch_enable[MAX_SUB_MODE_NUM+1:0];     // enable latch mode\n");
      print($TB "  reg enable[MAX_SUB_MODE_NUM+1:0];           // enable test generation module\n");
      print($TB "  reg erks_rst[MAX_SUB_MODE_NUM+1:0];         // reset the test generator\n");
      print($TB "  reg erks_rst_freq;         // reset the oscillator\n");
      print($TB "  wire test_gen_finish[MAX_SUB_MODE_NUM+1:0];\n");
      print($TB "  reg sub_mode_finish;\n");
      print($TB "  wire mode_vector[PORT_NUM-1:0];\n");
      print($TB "  wire test_vector[PORT_NUM-1:0];\n\n");
      if($max_sub_mode_num>0){
        print($TB "  wire sub_mode_vector[MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n\n");
        print($TB "  string sub_mode_pattern_str[MAX_SUB_MODE_NUM-1:0];\n");
        print($TB "  reg sub_mode_port_en                 [MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n");
        print($TB "  reg [63:0] sub_mode_port_delay       [MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n");
        print($TB "  reg [15:0] sub_mode_normal_port_val  [MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n");
        print($TB "  reg [3:0] sub_mode_port_care_range   [MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n");
        print($TB "  reg [3:0] sub_mode_port_test_type    [MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n");
        print($TB "  reg sub_mode_port_type               [MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n");
        print($TB "  reg [64:0] sub_mode_input_loop_cnt   [MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n");
        print($TB "  reg [64:0] sub_mode_output_loop_cnt  [MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n\n");
        print($TB "  reg sub_mode_rising_enb          [MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n");
        print($TB "  reg sub_mode_falling_enb         [MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n");
        if($rnm == 1){
          print($TB "  nt::Real sub_mode_real_pattern[MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n");
          print($TB "  nt::Real sub_mode_real_port_val    [MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n");
          print($TB "  real sub_mode_real_port_def_step   [MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n");
          print($TB "  real sub_mode_real_port_max_real   [MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n");
          print($TB "  nt::Real sub_mode_reserved_real_port_val    [MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n");
          print($TB "  real sub_mode_reserved_real_port_def_step   [MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n");
          print($TB "  real sub_mode_reserved_real_port_max_real   [MAX_SUB_MODE_NUM-1:0][PORT_NUM-1:0];\n");
        }
      }
      if($inport_FB ne ""){
         print($TB "  assign $inport_FB = fb_reg;\n");
      }

      $delay=$delay-1;
      print($TB "\n  parameter DELAY=$delay;\n\n");
      print($TB "  reg b_it[3:0];\n");
      print($TB "  reg [MEM_SIZE:0] mem [0:TEST_VECTOR_SIZE];\n");
      print($TB "  string pattern = \"\";\n");
      print($TB "  string tmp_pattern = \"\";\n");
      #print force pattern
      if($lfo eq "1"){
         for(my $i=4;$i<scalar(@table);$i++){
            if($table[$i][1] =~ /FORCE/){
              my $pattern="";
              for(my $j=2;$j<scalar(@{$table[$i]});$j++){
                if($table[0][$j] =~ /input|electrical_in/){
                  $pattern = $pattern.$table[$i][$j];
                }
                if($table[0][$j] =~ /inout/){
                  if($table[$i][$j] =~ /^_/){
                    $pattern = $pattern.".";
                  }else{
                    $pattern = $pattern.$table[$i][$j];
                  }
                }
              }
              print($TB "  string $table[$i][1]_pattern = \"$pattern\";\n");
              push(@force_num_pat,$table[$i][1]);
              for(my $j=2;$j<scalar(@{$table[0]}); $j++){
                  my $val = $table[$i][$j];
                  if($table[0][$j] eq "input" && $val =~ /\d+/){
                      push(@{$force_index{"$table[$i][1]"}},$total_port_num - $j + 1);
                      push(@{$force_value{"$table[$i][1]"}},$table[$i][$j]);
                  }
              }
#              if($table[$i][1] =~ /HOLD|STRONG_HOLD/){
#                for(my $j=2;$j<scalar(@{$table[0]}); $j++){
#                  if($table[$i][$j] eq "*"){
#                    my ($lv, @care_range) = Ex2Tbl::get_port_level($table[2][$j],@port);
#                    $condition_of_end_force=$condition_of_end_force*$lv;
#                  }
#                }
#              } #cov
            }
         }
      }
      $condition_of_end_force = $condition_of_end_force+1;
      print($TB "  string latch_disable_pattern = \"\";\n");
      print($TB "  string latch_enable_pattern = \"\";\n");
      print($TB "  string mode_pattern_str = \"\";\n");
      print($TB "  string test_pattern_str = \"\";\n");
      print($TB "  string reserved_pattern_str = \"\";\n");
      print($TB "  string port_val = \"\";\n");
      if($pulse_width_col==1){
        print($TB "  integer high_pulse_width, high_pulse_width_pre; \n");
      }
      if ($sim == 1) { # VCS with message check
        print($TB "  integer tmp, log_index, end_pat;\n");
      }
      print($TB "  integer state, next_state;\n");
      print($TB "  integer force_start;\n");
      if($lfo==1){
        my $num_force_ptn = scalar(@force_num_pat)-1;
        print($TB "  integer force_finish[".$num_force_ptn.":0];\n");
        print($TB "  integer force_state[".$num_force_ptn.":0];\n");
      }
      if($rnm == 1){
        print($TB "  real tmp_real_val, delta;\n");
        print($TB "  nt::Real real_b_it   [3:0];\n");
        print($TB "  integer ini_real, max_real, val_def_step;\n");
        print($TB "  nt::Real real_port_val    [PORT_NUM-1:0];\n");
        print($TB "  real real_port_def_step   [PORT_NUM-1:0];\n");
        print($TB "  real real_port_max_real   [PORT_NUM-1:0];\n");

      }
      print($TB "  reg port_en                      [PORT_NUM-1:0];\n");
      print($TB "  reg [63:0] port_delay            [PORT_NUM-1:0];\n");
      print($TB "  reg [15:0] normal_port_val       [PORT_NUM-1:0];\n");
      print($TB "  reg [3:0] port_care_range        [PORT_NUM-1:0];\n");
      print($TB "  reg [3:0] port_test_type         [PORT_NUM-1:0];\n");
      print($TB "  reg port_type                    [PORT_NUM-1:0];\n\n");
      if($rnm == 1){
        print($TB "  nt::Real mode_real_port_val    [PORT_NUM-1:0];\n");
        print($TB "  real mode_real_port_def_step   [PORT_NUM-1:0];\n");
        print($TB "  real mode_real_port_max_real   [PORT_NUM-1:0];\n");

      }
      print($TB "  reg mode_port_en                 [PORT_NUM-1:0];\n");
      print($TB "  reg [63:0] mode_port_delay       [PORT_NUM-1:0];\n");
      print($TB "  reg [15:0] mode_normal_port_val  [PORT_NUM-1:0];\n");
      print($TB "  reg [3:0] mode_port_care_range   [PORT_NUM-1:0];\n");
      print($TB "  reg [3:0] mode_port_test_type    [PORT_NUM-1:0];\n");
      print($TB "  reg mode_port_type               [PORT_NUM-1:0];\n");
      print($TB "  reg [64:0] mode_input_loop_cnt   [PORT_NUM-1:0];\n"); 
      print($TB "  reg [64:0] mode_output_loop_cnt  [PORT_NUM-1:0];\n");
      if($rnm == 1){
        print($TB "  nt::Real test_real_port_val    [PORT_NUM-1:0];\n");
        print($TB "  real test_real_port_def_step   [PORT_NUM-1:0];\n");
        print($TB "  real test_real_port_max_real   [PORT_NUM-1:0];\n");
      }
      print($TB "  reg test_port_en                 [PORT_NUM-1:0];\n");
      print($TB "  reg [63:0] test_port_delay       [PORT_NUM-1:0];\n");
      print($TB "  reg [15:0] test_normal_port_val  [PORT_NUM-1:0];\n");
      print($TB "  reg [3:0] test_port_care_range   [PORT_NUM-1:0];\n");
      print($TB "  reg [3:0] test_port_test_type    [PORT_NUM-1:0];\n");
      print($TB "  reg test_port_type               [PORT_NUM-1:0];\n");
      print($TB "  reg [64:0] test_input_loop_cnt   [PORT_NUM-1:0];\n"); 
      print($TB "  reg [64:0] test_output_loop_cnt  [PORT_NUM-1:0];\n");

      if($rnm == 1){
        print($TB "  nt::Real reserved_real_port_val    [PORT_NUM-1:0];\n");
        print($TB "  real reserved_real_port_def_step   [PORT_NUM-1:0];\n");
        print($TB "  real reserved_real_port_max_real   [PORT_NUM-1:0];\n");
      }
      print($TB "  reg reserved_port_en                 [PORT_NUM-1:0];\n");
      print($TB "  reg [63:0] reserved_port_delay       [PORT_NUM-1:0];\n");
      print($TB "  reg [15:0] reserved_normal_port_val  [PORT_NUM-1:0];\n");
      print($TB "  reg [3:0] reserved_port_care_range   [PORT_NUM-1:0];\n");
      print($TB "  reg [3:0] reserved_port_test_type    [PORT_NUM-1:0];\n");
      print($TB "  reg reserved_port_type               [PORT_NUM-1:0];\n");
      print($TB "  reg update_input_port            [PORT_NUM-1:0];\n");
      print($TB "  reg port_rising_enb              [PORT_NUM-1:0];\n");
      print($TB "  reg port_falling_enb             [PORT_NUM-1:0];\n");
      print($TB "  reg mode_rising_enb              [PORT_NUM-1:0];\n");
      print($TB "  reg mode_falling_enb             [PORT_NUM-1:0];\n");
      print($TB "  reg test_rising_enb              [PORT_NUM-1:0];\n");
      print($TB "  reg test_falling_enb             [PORT_NUM-1:0];\n");
      print($TB "  integer port_rising_period       [PORT_NUM-1:0];\n");
      print($TB "  integer port_falling_period      [PORT_NUM-1:0];\n");
    }
    if ($num_of_clock_change ne "0") {
      for (my $i=0;$i<$num_of_clock_change;$i++) {
        print($TB "  integer $clock_change[$i]_clk_period,start_$clock_change[$i]_clk_zero,$clock_change[$i]_clk_value;\n");
        print($TB "  integer $clock_change[$i]_clk_period_pre,$clock_change[$i]_clk_value_pre , $clock_change[$i]_pre;\n");
      }
    }
    print($TB "  reg port_dir     [PORT_NUM-1:0];\n");
    print($TB "  reg temp_port_reg[PORT_NUM-1:0];\n");
    print($TB "  reg port_reg     [PORT_NUM-1:0];\n\n");

    print($TB "  reg  sig_sel;\n\n");
    print($TB join("",@assigndec));
    print($TB "  integer i0, i1, i2, i3, i4,size, index, shift_index, port_index, latch_port_index,force_index, sub_mode_index, sub_mode_num;\n");
    print($TB "  initial begin\n"); 
    print($TB "    sig_sel = 1'b1;\n");
    print($TB "    i0 = 0;\n");
    print($TB "  end\n\n");

    my @dup_check = ();
    if (@outseq != 0 || @InputSeqExclude != 0){
      for (my $i=0;$i<scalar(@rising_clock_cnt);$i++){
        print($TB "  integer first_$rising_clock_cnt[$i]\_rising_time;\n");
      }
      for (my $i=0;$i<scalar(@falling_clock_cnt);$i++){
        print($TB "  integer first_$falling_clock_cnt[$i]\_falling_time;\n");
      }
      for (my $i=0;$i<scalar(@fall_cond);$i++){
        print($TB "  integer $fall_cond[$i]\_falling_time;\n");
      }
      for (my $i=0;$i<scalar(@rise_cond);$i++){
        print($TB "  integer $rise_cond[$i]\_rising_time;\n");
      }
      for (my $i=0;$i<scalar(@osc_cond);$i++){
        print($TB "  integer $osc_cond[$i]\_rising_time;\n");
        print($TB "  integer $osc_cond[$i]\_osc_chk_ctrl;\n");
      }
      for (my $i=0;$i<scalar(@change_cond);$i++){
        print($TB "  integer $change_cond[$i]\_update_time_pos;\n");
      }
      print($TB "  integer port_index_tmp;\n");
      for (my $i=1;$i<scalar(@outseq);$i++){
        my ($cond_name,$out_name,$port_ref_num,$in_port_name,$out_port_name)=get_port_timing_info($outseq[$i][2],$outseq[$i][3],@port_ref_table);
        my $prefix_osc = "";
        $prefix_osc = "osc_" if ($outseq[$i][2] =~ /^\(osc\)/i);
        my $suffix_osc = "";
        $suffix_osc = "osc_" if ($outseq[$i][3] =~ /^\(osc\)/i);
        if ($outseq[$i][4] =~ /^\d+-\d+$/) { # Ex: 10-50
          print($TB "  integer $prefix_osc$cond_name\_$suffix_osc$out_name\_stable_chk;\n");
        }
        if ($port_ref_num ne "-1"){ # input port -> output port
          my $tmp_name = $out_name."_update_time";
          next if(grep (/^\Q$tmp_name\E$/,@dup_check) > 0);
          push(@dup_check,$tmp_name);
          $in_out_seq = 1;
          $hash_in_out{"$out_name"} = 1;
          print($TB "  integer $tmp_name [PORT_NUM-1:0];\n");
        }else{ # output port -> output port
          $out_out_seq = 1;
          $hash_out_out{"$out_name"} = 1;
          my $tmp_name = $prefix_osc.$cond_name."_$suffix_osc$out_name"."_update_time";
          next if(grep (/^\Q$tmp_name\E$/,@dup_check) > 0);
          push(@dup_check,$tmp_name);
          print($TB "  integer $tmp_name;\n");
          print($TB "  integer $prefix_osc$cond_name\_$suffix_osc$out_name\_outseq_trg;\n");
          print($TB "  integer $prefix_osc$cond_name\_$suffix_osc$out_name\_update_ctrl;\n");
          print($TB "  integer $prefix_osc$cond_name\_$suffix_osc$out_name\_update_flag;\n");
          $tmp_name = "front_$cond_name"."_update_time";
          next if(grep (/^\Q$tmp_name\E$/,@dup_check) > 0);
          push(@dup_check,$tmp_name);
          print($TB "  integer $tmp_name;\n");
        }
      }
      for (my $i=1;$i<scalar(@outseq);$i++){
        my $check_type = "rising";
        $check_type = "falling" if ($outseq[$i][4] =~ /neg/);
        my $check_name = lc($outseq[$i][0])."_$outseq[$i][5]";
        if ($outseq[$i][4] =~ /^(pos|neg)/) { # Ex: pos/neg 5
          print($TB "  integer $check_type\_$check_name\_num;\n");
          print($TB "  integer check_$check_type\_$check_name;\n");
        }
      }
      @dup_check = ();
      for (my $i=1;$i<scalar(@outseq);$i++){
        my ($cond_name,$out_name,$port_ref_num,$in_port_name,$out_port_name)=get_port_timing_info($outseq[$i][2],$outseq[$i][3],@port_ref_table);
        next if(grep (/^\Q$out_name\E$/,@dup_check) > 0);
        push(@dup_check,"$out_name");
        if (exists $hash_in_out{"$out_name"}){
          print($TB "  integer $out_name\_outseq_trg[PORT_NUM-1:0];\n");
          print($TB "  integer $out_name\_update_flag[PORT_NUM-1:0];\n");
          print($TB "  integer $out_name\_input_update_time [PORT_NUM-1:0];\n");
          print($TB "  integer $out_name\_input_update_ctrl [PORT_NUM-1:0];\n");
        }
      }
    }
    if ((@table !=0) && ($hashoption{"tv"} == 1 || $hashoption{"ex_tv"}) == 1){
      print($TB "\n");
      print($TB "  wire port_dir_ctrl[PORT_NUM-1:0];\n");
      print($TB "  assign port_dir_ctrl=port_dir;\n");
      my @var_ref_dec = ();
      my @var_ref_inst= ();
      foreach my $key (keys %ref_var_tbl_list){
        my @ref_table = @{$ref_var_tbl_list{$key}};
        my @port_ref = Ex2Tbl::GetPortRefTable($ref_table[1],\@ref_table,\@port,$rnm);
        my $tmp_inst = "  $ref_table[1][0] $ref_table[1][0]_Ref(";
        my @input_list = ();
        for (my $j=0;$j<scalar(@{$port_ref[0]});$j++){
          if($port_ref[1][$j] ne "-1"){
            if($port_ref[8][$j] eq ""){
              next if (grep(/^$port_ref[0][$j]$/,@input_list) > 0);
              push(@input_list,$port_ref[0][$j]);
              $tmp_inst = $tmp_inst." .$port_ref[0][$j]"."($port_ref[0][$j]),";
            }elsif ($port_ref[8][$j] ne "-" or $port_ref[0][$j] =~ /.*\[(\d+|\d+:\d+)\]/){
              my $name = $port_ref[7][$j];
              $name =~ s/\[.*$//;
              next if (grep(/$name/,@input_list) > 0);
              push(@input_list,$name);
              $tmp_inst = $tmp_inst." .$name"."($name),";
            }
          }
        }
        for (my $j=0;$j<scalar(@{$port_ref[0]});$j++){
          if($port_ref[4][$j] eq "3"){ #ref port
            $tmp_inst = $tmp_inst." .$port_ref[0][$j]"."($port_ref[0][$j]), .port_en(port_en),";
            if($rnm == 1){
              push(@var_ref_dec,"  real $port_ref[0][$j];\n");
            }else{
              push(@var_ref_dec,"  reg [63:0] $port_ref[0][$j];\n");
            }
          }
        }
        $tmp_inst =~ s/,$/);/;
        push(@var_ref_inst,$tmp_inst);
      }
      print($TB join("",@var_ref_dec));
      print($TB join("\n",@var_ref_inst)."\n\n");
    }
    if($is_fb_on) {
      if ((@table !=0) && ($hashoption{"tv"} == 1 || $hashoption{"ex_tv"}  == 1)){
        print($TB "  always @($outport_FB or update_fb) begin\n");
        print($TB "    if(port_en_fb == PORT_ENABLED) begin\n");
        print($TB "       fb_reg = #port_delay_fb $outport_FB;\n");
        print($TB "    end else begin\n");
        print($TB "       fb_reg = port_value_fb;\n");
        print($TB "    end;\n");
        print($TB "  end\n\n");
      }else{
#        print($TB "  always @($outport_FB) begin\n"); # cov (only -ta -tb are defined)
#        print($TB "    $inport_FB = #1 $outport_FB;\n");
#        print($TB "  end\n\n");
      }
    }
# connection to test generator
    if ((@table !=0) && ($hashoption{"tv"} == 1 || $hashoption{"ex_tv"} == 1)){
      my @mode_name = ("MODE_GEN","TEST_GEN");  
      my @port_mode_name = ("mode","test");
      for (my $i=0;$i<scalar(@mode_name);$i++) {
        print($TB "  TestGenMod TGM_$mode_name[$i](.erks_rst(erks_rst[$mode_name[$i]]),.test_gen_trigger(test_gen_trigger[$mode_name[$i]]),");
        print($TB ".enable(enable[$mode_name[$i]]),.latch_enable(latch_enable[$mode_name[$i]]),.update_enable(update_enable[$mode_name[$i]]),");
        print($TB ".test_gen_finish(test_gen_finish[$mode_name[$i]]),.mem(port_index_mem[$mode_name[$i]]),\n");
        print($TB "    .port_en($port_mode_name[$i]\_port_en),\n");
        print($TB "    .normal_port_val($port_mode_name[$i]\_normal_port_val),\n");
        print($TB "    .port_test_type ($port_mode_name[$i]\_port_test_type),\n");
        print($TB "    .port_type($port_mode_name[$i]\_port_type),\n");
        print($TB "    .input_loop_cnt($port_mode_name[$i]\_input_loop_cnt),\n");
        print($TB "    .output_loop_cnt($port_mode_name[$i]\_output_loop_cnt),\n");
        if($rnm == 1){
          print($TB "    .real_reg(real_reg),\n");
          print($TB "    .real_port_val($port_mode_name[$i]\_real_port_val),\n");
          print($TB "    .real_port_def_step($port_mode_name[$i]\_real_port_def_step),\n");
          print($TB "    .real_port_max_real($port_mode_name[$i]\_real_port_max_real),\n");
        }
        print($TB "    .port_care_range($port_mode_name[$i]\_port_care_range),\n");
        print($TB "    .port_rising_enb($port_mode_name[$i]\_rising_enb),\n");
        print($TB "    .port_falling_enb($port_mode_name[$i]\_falling_enb),\n");
        if($rnm == 1){
          print($TB "    .real_test_pattern($port_mode_name[$i]\_real_pattern),\n");
        }
        print($TB "    .test_vector($port_mode_name[$i]\_vector));\n");
      }
      for (my $i=0;$i<$max_sub_mode_num;$i++) {
        print($TB "  TestGenMod TGM_SUB_MODE$i\_GEN(.erks_rst(erks_rst[SUB_MODE$i\_GEN]),.test_gen_trigger(test_gen_trigger[SUB_MODE$i\_GEN]),");
        print($TB ".enable(enable[SUB_MODE$i\_GEN]),.latch_enable(latch_enable[SUB_MODE$i\_GEN]),.update_enable(update_enable[SUB_MODE$i\_GEN]),");
        print($TB ".test_gen_finish(test_gen_finish[SUB_MODE$i\_GEN]),.mem(port_index_mem[SUB_MODE$i\_GEN]),\n");
        print($TB "    .port_en(sub_mode_port_en[$i]),\n");
        print($TB "    .normal_port_val(sub_mode_normal_port_val[$i]),\n");
        print($TB "    .port_test_type (sub_mode_port_test_type[$i]),\n");
        print($TB "    .port_type(sub_mode_port_type[$i]),\n");
        print($TB "    .input_loop_cnt(sub_mode_input_loop_cnt[$i]),\n");
        print($TB "    .output_loop_cnt(sub_mode_output_loop_cnt[$i]),\n");
        if($rnm == 1){
          print($TB "    .real_reg(real_reg),\n");
          print($TB "    .real_port_val(sub_mode_real_port_val[$i]),\n");
          print($TB "    .real_port_def_step(sub_mode_real_port_def_step[$i]),\n");
          print($TB "    .real_port_max_real(sub_mode_real_port_max_real[$i]),\n");
        }
        print($TB "    .port_care_range(sub_mode_port_care_range[$i]),\n");
        print($TB "    .port_rising_enb(sub_mode_rising_enb[$i]),\n");
        print($TB "    .port_falling_enb(sub_mode_falling_enb[$i]),\n");
        if($rnm == 1){
          print($TB "    .real_test_pattern(sub_mode_real_pattern[$i]),\n");
        }
        print($TB "    .test_vector(sub_mode_vector[$i]));\n");
      }
    }
    print($TB "\n");
# Module to covert SVreal to real port before assertion
    if($sim == 2 && $rnm == 1 && $wave ne "ams"){
      my $print="";
      my @portname_list=();
      for(my $i=0;$i<scalar(@{$port[0]});$i++){        
        if(($port[13][$i] ne "-")&&($port[1][$i] =~/output|inout|electrical_out|input|electrical_in/)){
          my $tmp_out =  $port[0][$i];
          if($tmp_out =~ /\[/){
#            $tmp_out =~ s/\[/_c\[/; #cov
          }else{
            $tmp_out = $tmp_out."_c";
          }
          print($TB "  assign $tmp_out = ConvertNetType\($port[0][$i]\)\;\n");
          push(@portname_list,$port[0][$i]);
        }
      }
    }

    print($TB "\n");
# include assertion of truth table
    if ((@table !=0) && ($hashoption{"ta"} == 1)){
      print($TB "  \`include \"$path/$ast\"\n"); # assertion
    }
    if($ex_ast eq "1" && $ex_ptn eq "1"){
      print($TB "  \`include \"$path/$ex_ast_file\"\n"); # Exclude sheet assertion
    }
    close($TB);
# Freq?
    if (@table !=0 && $rnm != 1){
      $freq_check = freq_mod($file, $pg, $delay, $unit, $timescale, \@table,\@port,$reftl,$rnm,$total_port_num);
    }
    open($TB, ">> $file");
    return(1,0) if(!(fileno($TB)));

    my $test_mod_gen;
# include test vector of truth table and FSM (if any)
    if ((@table !=0) && ($hashoption{"tv"} == 1 || $hashoption{"ex_tv"} == 1)){
      print($TB "  initial begin\n"); # ptn
      print($TB "    b_it[3]=1'bz;\n"); 
      print($TB "    b_it[2]=1'bx;\n");
      print($TB "    b_it[1]=1'b1;\n");
      print($TB "    b_it[0]=1'b0;\n");
      if($is_fb_on ==1){
        print($TB "    update_fb = 0;\n"); 
      }
      #initialize force flag
      if ($clock_source ne "") {
        foreach my $clock_name(keys %clock_source_list) {
          print($TB "    $clock_name = 0;\n");
        }
      }
      if ($num_of_clock_change ne "0") {
        for (my $i=0;$i<$num_of_clock_change;$i++) {
          print($TB "    ".$clock_change[$i]."_clk_value = 0;\n");
          print($TB "    ".$clock_change[$i]."_clk_period = 0;\n");
          print($TB "    start_".$clock_change[$i]."_clk_zero = 0;\n");
        }
      }
      if ($sim == 1) { # VCS with message check
        print($TB "    end_pat = 0;\n");
      }
      if($rnm == 1){
        print($TB "    delta=0.0001;\n"); 
        print($TB "    real_b_it[3]='{'hz, `wrealZState};\n"); 
        print($TB "    real_b_it[2]='{'hx, `wrealXState};\n");
        print($TB "    real_b_it[1]='{1,1};\n");
        print($TB "    real_b_it[0]='{0,0};\n");
      }
      for (my $i=0;$i<scalar(@fall_cond);$i++){
        print($TB "    $fall_cond[$i]\_falling_time = 0;\n");
      }
      for (my $i=0;$i<scalar(@rise_cond);$i++){
        print($TB "    $rise_cond[$i]\_rising_time = 0;\n");
      }
      for (my $i=0;$i<scalar(@osc_cond);$i++){
        print($TB "    $osc_cond[$i]\_rising_time = 0;\n");
        print($TB "    $osc_cond[$i]\_osc_chk_ctrl = 0;\n");
      }
      for (my $i=0;$i<scalar(@change_cond);$i++){
        print($TB "    $change_cond[$i]\_update_time_pos = 0;\n");
      }
      print($TB "    for (i3=0;i3<MAX_SUB_MODE_NUM+2;i3++) begin\n");
      print($TB "      test_gen_trigger[i3] = 0;\n");
      print($TB "      erks_rst[i3] = 1;\n");
      print($TB "    end\n");
      print($TB "    sub_mode_index = 0;\n");
      if($ex_ptn ne "1"){
        if($hashoption{"tv"} == 1){
          if ($split > 1 || scalar(@inseq) > 1){
            print($TB "    \$readmemb(\"./$vct\",mem);\n"); # ptn
          } else{
            print($TB "    \$readmemb(\"$path/$vct\",mem);\n"); # ptn
          }
        }
      }else{
        if($hashoption{"tv"} == 1){
          print($TB "    for (i4=0;i4<2;i4++) begin\n");
          print($TB "      if(i4==0)begin\n");
          if ($split > 1 || scalar(@inseq) > 1){
            print($TB "      \$readmemb(\"./$vct\",mem);\n"); # ptn
          } else{
            print($TB "      \$readmemb(\"$path/$vct\",mem);\n"); # ptn
          }

          print($TB "      end else begin\n");
          print($TB "       \$readmemb(\"$path/$ex_ptn_file\",mem);\n"); # ptn
            print($TB "      end\n");
        }else{
          print($TB "    \$readmemb(\"$path/$ex_ptn_file\",mem);\n"); # ptn
        }
      }
      print($TB "    size=mem[0]; // define size of test vector at mem[0]\n");
      my @dup_check=();
      if (@outseq != 0){
        print($TB "    port_index_tmp = 0;\n");
        for (my $i=1;$i<scalar(@outseq);$i++){
          my ($cond_name,$out_name,$port_ref_num,$in_port_name,$out_port_name)=get_port_timing_info($outseq[$i][2],$outseq[$i][3],@port_ref_table);
          my $prefix_osc = "";
          $prefix_osc = "osc_" if ($outseq[$i][2] =~ /^\(osc\)/i);
          my $suffix_osc = "";
          $suffix_osc = "osc_" if ($outseq[$i][3] =~ /^\(osc\)/i);
          if ($outseq[$i][4] =~ /^\d+-\d+$/) { # Ex: 10-50
            print($TB "    $prefix_osc$cond_name\_$suffix_osc$out_name\_stable_chk = 0;\n");
          }
          if ($port_ref_num eq "-1"){ # output port -> output port
            my $tmp_name = $prefix_osc.$cond_name."_$suffix_osc$out_name"."_update_time";
            next if(grep (/^\Q$tmp_name\E$/,@dup_check) > 0);
            push(@dup_check,$tmp_name);
            print($TB "    $prefix_osc$cond_name"."_$suffix_osc$out_name"."_update_time = 0;\n");
            print($TB "    $prefix_osc$cond_name"."_$suffix_osc$out_name"."_outseq_trg = 0;\n");
            print($TB "    $prefix_osc$cond_name"."_$suffix_osc$out_name"."_update_ctrl = 0;\n");
            print($TB "    $prefix_osc$cond_name"."_$suffix_osc$out_name"."_update_flag = 0;\n");
            $tmp_name = "front_$cond_name"."_update_time";
            next if(grep (/^\Q$tmp_name\E$/,@dup_check) > 0);
            print($TB "    front_$cond_name"."_update_time = 0;\n");
          }
          my $check_type = "rising";
          $check_type = "falling" if ($outseq[$i][4] =~ /neg/);
          my $check_name = lc($outseq[$i][0])."_$outseq[$i][5]";
          if ($outseq[$i][4] =~ /^(pos|neg)/) { # Ex: pos/neg 5
            print($TB "    $check_type\_$check_name\_num = 0;\n");
            print($TB "    check_$check_type\_$check_name = 0;\n");
          }
        }
      }
      for (my $i=0;$i<scalar(@rising_clock_cnt);$i++){
        print($TB "    first_$rising_clock_cnt[$i]\_rising_time = 0;\n");
      }
      for (my $i=0;$i<scalar(@falling_clock_cnt);$i++){
        print($TB "    first_$falling_clock_cnt[$i]\_falling_time = 0;\n");
      }
      print($TB "    test_gen_trigger[MODE_GEN] = 0;\n");
      print($TB "    test_gen_trigger[TEST_GEN] = 0;\n");
      print($TB "    erks_rst[MODE_GEN] = 1;\n");
      print($TB "    erks_rst[TEST_GEN] = 1;\n");
      print($TB "    erks_rst_freq = 1;\n");
      print($TB "    state = INITIAL;\n");
      print($TB "    next_state = INITIAL;\n");
      print($TB "    latch_port_index = PORT_NUM;\n");
      if($lfo eq "1"){
        for(my $i=0;$i<scalar(@force_num_pat);$i++){
             print($TB "    force_finish[$i] = 0;\n");
             print($TB "    force_state[$i] = $force_num_pat[$i];\n");
        }
      }
      print($TB "    begin // port care range\n");
      print($TB "      for (i1=0;i1<PORT_NUM;i1++) begin\n");
      print($TB "        port_care_range[i1] = (mem[1] >> (4*i1))&4'hF;\n");
      @dup_check=();
      if (@outseq != 0){
        for (my $i=1;$i<scalar(@outseq);$i++){
          my ($cond_name,$out_name,$port_ref_num,$in_port_name,$out_port_name)=get_port_timing_info($outseq[$i][2],$outseq[$i][3],@port_ref_table);
          if ($port_ref_num ne "-1"){ # input port -> output port
            next if(grep (/^\Q$out_name\E$/,@dup_check) > 0);
            push(@dup_check,$out_name);
            print($TB "        $out_name\_update_time[i1] = 0;\n");
            print($TB "        $out_name\_outseq_trg[i1] = 0;\n");
            print($TB "        $out_name\_update_flag[i1] = 0;\n");
            print($TB "        $out_name\_input_update_time[i1] = 0;\n");
            print($TB "        $out_name\_input_update_ctrl[i1] = 0;\n");
          }
        }
      }
      print($TB "      end\n");
      print($TB "    end\n");
      print($TB "    begin // port type \n");
      print($TB "      for (i1=0;i1<PORT_NUM;i1++) begin\n");
      print($TB "        port_type[i1] = (mem[2] >> (4*i1))&1'b1; // 0: normal, 1: real port\n");
      print($TB "      end\n");
      print($TB "    end\n");
      print($TB "    begin // rising period\n");
      print($TB "      for (i1=0;i1<PORT_NUM;i1++) begin\n");
      print($TB "        port_rising_period[i1] = (mem[3] >> (64*i1))&64'hFFFFFFFFFFFFFFFF;\n");
      print($TB "      end\n");
      print($TB "    end\n");
      print($TB "    begin // falling period\n");
      print($TB "      for (i1=0;i1<PORT_NUM;i1++) begin\n");
      print($TB "        port_falling_period[i1] = (mem[4] >> (64*i1))&64'hFFFFFFFFFFFFFFFF;\n");
      print($TB "      end\n");
      print($TB "    end\n");
      print($TB "    begin // latch port indicator\n");
      print($TB "      for (i1=0;i1<PORT_NUM;i1++) begin\n");
      print($TB "        if (((mem[5] >> i1)&1'h1) == 1) latch_port_index = i1;\n");
      print($TB "      end\n");
      print($TB "    end\n");
      print($TB "    for (index = GET_DATA_INDEX; index <size; index=index+1) begin\n");
      print($TB "      case(index % GET_DATA_INDEX)\n");
      print($TB "        GET_TVT_TYPE  : begin // test vector type\n");
      print($TB "                          for (i1=0;i1<PORT_NUM;i1++) begin\n");
      print($TB "                            port_test_type[i1] = (mem[index] >> (4*i1))&4'hF;\n");
      print($TB "                            update_input_port[i1] = 0;\n");
      print($TB "                          end\n");
      print($TB "                        end\n");
      print($TB "        GET_DELAY     : begin // delay value\n");
      print($TB "                          for (i1=0;i1<PORT_NUM;i1++) begin\n");
      print($TB "                            port_delay[i1] = (mem[index] >> (64*i1))&64'hFFFFFFFFFFFFFFFF;\n");
      print($TB "                          end\n");
      if($is_fb_on == 1){
        print($TB "                            port_delay_fb = (mem[index] >> (64*PORT_NUM))&64'hFFFFFFFFFFFFFFFF;\n");
      }
      print($TB "                        end\n");
      print($TB "        GET_ENABLE    : begin // enable value (always 1 incase input port)\n");
      print($TB "                          for (i1=0;i1<PORT_NUM;i1++) begin\n");
      print($TB "                            port_en[i1] = (mem[index] >> i1)&1'b1;\n");
      print($TB "                          end\n");
      if($is_fb_on == 1){
        print($TB "                    port_en_fb = (mem[index] >> PORT_NUM)&1'b1;\n");
      }
      print($TB "                        end\n");
      print($TB "        GET_MODE      : begin\n");
      print($TB "                          next_state = INITIAL;\n");
      print($TB "                          if (((mem[index] >> 4)&4'hF) == LATCH_MODE_VECTOR) begin // latch check test vector\n");
      print($TB "                            if (state == LOAD_MODE) begin // previous state is mode load --> execute latch check -> LOAD_MODE\n");
      print($TB "                              state = MODE_SET_VALUE;\n");
      print($TB "                              next_state = LOAD_MODE;\n");
      print($TB "                            end else begin // from INITIAL -> MODE_SET_VALUE\n");
      print($TB "                              state = MODE_SET_VALUE;\n");
      print($TB "                            end\n");
      print($TB "                          end else begin\n");
      print($TB "                            if (((mem[index] >> 4)&4'hF) == MAIN_MODE_VECTOR) begin // mode pattern definition\n");
      print($TB "                              if (state == LOAD_MODE) begin // previous state is mode load --> execute MODE (second mode is loaded to first) -> LOAD_MODE\n");
      print($TB "                                state = EXEC_PRE_MODE;\n");
      print($TB "                                next_state = LOAD_MODE;\n");
      print($TB "                              end else begin // from INITIAL -> LOAD_MODE\n");
      print($TB "                                state = LOAD_MODE;\n");
      print($TB "                              end\n");
      print($TB "                              sub_mode_num=0;\n");
      print($TB "                              sub_mode_index=0;\n");
      print($TB "                              sub_mode_finish=0;\n");
      print($TB "                            end else begin\n");
      print($TB "                              if ((mem[index]&4'hF) == SUB_MODE_VECTOR) begin // sub mode test vector\n");
      print($TB "                                // mode must be already loaded\n");
      print($TB "                                if (state == LOAD_MODE) sub_mode_index = 0;\n");
      print($TB "                                state = LOAD_SUB_MODE;\n");
      print($TB "                              end else if ((mem[index]&4'hF) == LAST_SUB_MODE_VECTOR) begin // sub mode test vector\n");
      print($TB "                                state = EXEC_MODE;\n");
      print($TB "                              end else begin // Non-mode\n");
      print($TB "                                state = EXEC_TEST_VECTOR;\n");
      print($TB "                              end \n");
      print($TB "                            end\n");
      print($TB "                          end\n");
      print($TB "                        end\n");
      print($TB "        GET_PORT_VALUE: begin // value of ports\n");
      print($TB "                          shift_index       = 0;\n");
      print($TB "                          // get port value\n");
      print($TB "                          for (i1=0;i1<PORT_NUM;i1++) begin\n");
      print($TB "                            if (port_type[i1] == NORMAL_PORT_TYPE) begin // normal port\n");
      print($TB "                              normal_port_val[i1] = (mem[index] >> (16*shift_index))&16'hFFFF;\n");
      print($TB "                              shift_index  = shift_index + 1;\n");
      if($rnm == 1){
        print($TB "                            end else begin // real port\n");
        print($TB "                              ini_real     =  (mem[index] >> (16*(shift_index+2)))&16'hFFFF;\n");
        print($TB "                              max_real     =  (mem[index] >> (16*(shift_index+1)))&16'hFFFF;\n");
        print($TB "                              val_def_step =  (mem[index] >> (16*(shift_index  )))&16'hFFFF;\n");
        print($TB "                              if ((ini_real == 16'hFFFF) || (ini_real == 16'hFFFE)) begin\n");
        print($TB "                                if (ini_real == 16'hFFFF) begin\n");
        print($TB "                                  real_port_val[i1].i = 'hz;\n");
        print($TB "                                  real_port_val[i1].r = `wrealZState;\n");
        print($TB "                                end else begin\n");
        print($TB "                                  real_port_val[i1].i = 'hx;\n");
        print($TB "                                  real_port_val[i1].r = `wrealXState;\n");
        print($TB "                                end\n");
        print($TB "                              end else begin\n");
        print($TB "                                real_port_val[i1].i    = 0;\n");
        print($TB "                                real_port_val[i1].r    = (ini_real >> 10)&6'h3F;\n");
        print($TB "                                tmp_real_val           = ini_real&10'h3FF;\n");
        print($TB "                                real_port_val[i1].r    = real_port_val[i1].r + tmp_real_val/1000;\n");
        print($TB "                                real_port_max_real[i1] = (max_real    >>10)&6'h3F;\n");
        print($TB "                                tmp_real_val           = max_real    &10'h3FF;\n");
        print($TB "                                real_port_max_real[i1] = real_port_max_real[i1] + tmp_real_val/1000;\n");
        print($TB "                                real_port_def_step[i1] = (val_def_step>>10)&6'h3F;\n");
        print($TB "                                tmp_real_val           = val_def_step&10'h3FF;\n");
        print($TB "                                real_port_def_step[i1] = real_port_def_step[i1] + tmp_real_val/1000;\n");
        print($TB "                              end\n");
        print($TB "                              shift_index = shift_index + 3;\n");
      }
      print($TB "                            end\n");
      if($is_fb_on == 1){
        print($TB "                            normal_value_fb = (mem[index] >> (16*shift_index))&2'b11;\n");
        print($TB "                            port_value_fb = b_it[normal_value_fb];\n");
      }
      print($TB "                          end\n");
      print($TB "                          // get ouput pattern\n");
      print($TB "                          pattern = \"\";\n");
      print($TB "                          latch_disable_pattern = \"\";\n");
      print($TB "                          latch_enable_pattern = \"\";\n");
      print($TB "                          for (i1=0;i1<PORT_NUM;i1++) begin\n");
      print($TB "                            if (port_en[i1] == PORT_DISABLED) begin // inout port act as output port\n");
      print($TB "                              if (port_type[i1] == NORMAL_PORT_TYPE) begin // normal port\n");
      print($TB "                                tmp_pattern = \".\";\n");
      if($rnm == 1){
        print($TB "                              end else begin\n");
        print($TB "                                tmp_pattern = \"(.)\";\n");
      }
      print($TB "                              end\n");
      print($TB "                            end else begin\n");
      print($TB "                              if (port_type[i1] == NORMAL_PORT_TYPE) begin // normal port\n");
      print($TB "                                case (port_test_type[i1])\n");
      print($TB "                                  DONTCARE_TYPE: begin\n");
      print($TB "                                                 tmp_pattern = \"*\";\n");
      print($TB "                                                 end\n");
      print($TB "                                  CROSS_TYPE   : begin\n");
      print($TB "                                                 tmp_pattern = \"-\";\n");
      print($TB "                                                 end\n");
      print($TB "                                  S_TYPE       : begin\n");
      print($TB "                                                 tmp_pattern = \"S\";\n");
      print($TB "                                                 end\n");
      print($TB "                                  EXP_NOT_0_VAL: begin\n");
      print($TB "                                                 tmp_pattern = \"!0\";\n");
      print($TB "                                                 end\n");
      print($TB "                                  EXP_NOT_1_VAL: begin\n");
      print($TB "                                                 tmp_pattern = \"!1\";\n");
      print($TB "                                                 end\n");
      print($TB "                                  EXP_NOT_X_VAL: begin\n");
      print($TB "                                                 tmp_pattern = \"!x\";\n");
      print($TB "                                                 end\n");
      print($TB "                                  EXP_NOT_Z_VAL: begin\n");
      print($TB "                                                 tmp_pattern = \"!z\";\n");
      print($TB "                                                 end\n");
      print($TB "                                  EXP_RISING   : begin\n");
      print($TB "                                                 tmp_pattern = \"R\";\n");
      print($TB "                                                 end\n");
      print($TB "                                  EXP_FALLING  : begin\n");
      print($TB "                                                 tmp_pattern = \"F\";\n");
      print($TB "                                                 end\n");
      print($TB "                                  default      : begin\n");
      print($TB "                                                 \$sformat(port_val,\"\%0b\",b_it[normal_port_val[i1]]);\n");
      print($TB "                                                 tmp_pattern = port_val;\n");
      print($TB "                                                 end\n");
      print($TB "                                endcase\n");
      if($rnm == 1){
        print($TB "                              end else begin // real port\n");
        print($TB "                                case (port_test_type[i1])\n");
        print($TB "                                  DONTCARE_TYPE: begin\n");
        print($TB "                                                 tmp_pattern = \"(*)\";\n");
        print($TB "                                                 end\n");
        print($TB "                                  CROSS_TYPE   : begin\n");
        print($TB "                                                 tmp_pattern = \"(-)\";\n");
        print($TB "                                                 end\n");
        print($TB "                                  S_TYPE       : begin\n");
        print($TB "                                                 tmp_pattern = \"(S)\";\n");
        print($TB "                                                 end\n");
        print($TB "                                  RAMP_TYPE    : begin\n");
        print($TB "                                                 \$sformat(port_val,\"(\%0.3f,\%0.3f,\%0.3f)\",real_port_val[i1].r, real_port_max_real[i1], real_port_def_step[i1]);\n");
        print($TB "                                                 tmp_pattern = port_val;\n");
        print($TB "                                                 end\n");
        print($TB "                                  default      : begin\n");
        print($TB "                                                 \$sformat(port_val,\"(\%0.3f)\",real_port_val[i1].r);\n");
        print($TB "                                                 tmp_pattern = port_val;\n");
        print($TB "                                                 end\n");
        print($TB "                                endcase\n");
      }
      print($TB "                              end\n");
      print($TB "                            end\n");
      print($TB "                            if ((state == MODE_SET_VALUE) && (i1 == latch_port_index)) begin\n");
      print($TB "                              latch_disable_pattern = {\"0\",latch_disable_pattern};\n");
      print($TB "                              latch_enable_pattern = {\"1\",latch_enable_pattern};\n");
      print($TB "                              pattern = {\"+\",pattern};\n");
      print($TB "                            end else begin\n");
      print($TB "                              latch_disable_pattern = {tmp_pattern,latch_disable_pattern};\n");
      print($TB "                              latch_enable_pattern = {tmp_pattern,latch_enable_pattern};\n");
      print($TB "                              pattern = {tmp_pattern,pattern};\n");
      print($TB "                            end\n");
      print($TB "                          end\n");
      my $bract = 0;
      my $aract = 0;
      for (my $j=2;$j<scalar(@{$org_table[0]});$j++){
        if ($org_table[0][$j] eq "action") {
          if ($org_table[2][$j] eq "before"){
            $bract = $j;
          }elsif($org_table[2][$j] eq "after"){
            $aract = $j;
          }
        }
        if ($aract != 0 && $bract != 0){
          last;
        }
      }
      print($TB "                        end\n");
      # print pattern parsing content
      if ($num_of_clock_change ne "0") {
        for (my $i=0;$i<$num_of_clock_change;$i++) {
          print($TB "        GET_".uc($clock_change[$i])."_PERIOD: begin // clock period\n");
          print($TB "                        if (state != EXEC_PRE_MODE) begin\n");
          print($TB "                          if (((mem[index] >> 64)&4'hF) == UNFIXED) begin\n");
          print($TB "                            $clock_change[$i] = 0;\n");
          print($TB "                            $clock_change[$i]_clk_value = 0;\n");
          print($TB "                            $clock_change[$i]\_clk_period = mem[index] & 64'hFFFFFFFFFFFFFFFF;\n");
          print($TB "                            $clock_change[$i]_pre = 0;\n");
          print($TB "                            $clock_change[$i]_clk_value_pre = 0;\n");
          print($TB "                            $clock_change[$i]\_clk_period_pre = mem[index] & 64'hFFFFFFFFFFFFFFFF;\n");
          print($TB "                          end else begin\n");
          print($TB "                            $clock_change[$i] = b_it[(mem[index] >> 64)&4'hF];\n");
          print($TB "                            $clock_change[$i]_clk_value = b_it[(mem[index] >> 64)&4'hF];\n");
          print($TB "                            $clock_change[$i]\_clk_period = 0;\n");
          print($TB "                            $clock_change[$i]_pre = b_it[(mem[index] >> 64)&4'hF];\n");
          print($TB "                            $clock_change[$i]_clk_value_pre = (mem[index] >> 64)&4'hF;\n");
          print($TB "                            $clock_change[$i]\_clk_period_pre = 0;\n");
          print($TB "                          end\n");
          print($TB "                        end else begin\n");
          print($TB "                            $clock_change[$i] = $clock_change[$i]_pre;\n");
          print($TB "                            $clock_change[$i]_clk_value = $clock_change[$i]_clk_value_pre;\n");
          print($TB "                            $clock_change[$i]\_clk_period = $clock_change[$i]_clk_period_pre;\n");
          print($TB "                        end\n");
          print($TB "                        if (((mem[index] >> 64)&4'hF) == UNFIXED) begin\n");
          print($TB "                          $clock_change[$i]_pre = 0;\n");
          print($TB "                          $clock_change[$i]_clk_value_pre = 0;\n");
          print($TB "                          $clock_change[$i]\_clk_period_pre = mem[index] & 64'hFFFFFFFFFFFFFFFF;\n");
          print($TB "                        end else begin\n");
          print($TB "                          $clock_change[$i]_pre = b_it[(mem[index] >> 64)&4'hF];\n");
          print($TB "                          $clock_change[$i]_clk_value_pre = b_it[(mem[index] >> 64)&4'hF];\n");
          print($TB "                          $clock_change[$i]\_clk_period_pre = 0;\n");
          print($TB "                        end\n");
          print($TB "                      end\n");
        }
      }
      if ($pulse_width_col==1) {  ##  parse high pulse width value included in test pattern
        print($TB "        GET_PULSE_WIDTH: begin // high pulse width\n");
        print($TB "                        if (state != EXEC_PRE_MODE) begin\n");
        print($TB "                            high_pulse_width = mem[index] & 64'hFFFFFFFFFFFFFFFF;\n");
        print($TB "                            high_pulse_width_pre = mem[index] & 64'hFFFFFFFFFFFFFFFF;\n");
        print($TB "                        end else begin\n");
        print($TB "                            high_pulse_width = high_pulse_width_pre;\n");
        print($TB "                        end\n");
        print($TB "                        high_pulse_width_pre = mem[index] & 64'hFFFFFFFFFFFFFFFF;\n");
        print($TB "                        end\n");
      }
      print($TB "        default       : begin // ports sequence\n");
      print($TB "                          // Reset mode/sub_mode generator\n");
      print($TB "                          for (i3=0;i3<MAX_SUB_MODE_NUM+2;i3++) begin\n");
      print($TB "                            erks_rst[i3] = 0;\n");
      print($TB "                          end\n");
      print($TB "                          #1\n");
      print($TB "                          for (i3=0;i3<MAX_SUB_MODE_NUM+2;i3++) begin\n");
      print($TB "                            erks_rst[i3] = 1;\n");
      print($TB "                          end\n");
      print($TB "                          if (state == LOAD_MODE) begin\n");
      print($TB "                            if (index == (size - 1)) begin\n");
      print($TB "                              // Generate last test vector\n");
      print($TB "                              state = EXEC_TEST_VECTOR;\n");
      print($TB "                              update_enable[TEST_GEN] = 1; // test generate is enabled for loading\n");
      print($TB "                              enable[TEST_GEN] = 1;\n");
      print($TB "                              latch_enable[TEST_GEN] = 0;\n");
      print($TB "                              // test vector is loaded to test generator\n");
      print($TB "                              test_pattern_str     = pattern;\n");
      print($TB "                              port_index_mem[TEST_GEN] = mem[index];\n");
      if ($rnm == 1){
        print($TB "                              update_test_vector(     port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,     real_port_val,     real_port_def_step,     real_port_max_real,\n");
        print($TB "                                                 test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay,test_real_port_val,test_real_port_def_step,test_real_port_max_real);\n");
      } else {
        print($TB "                              update_test_vector(     port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,\n");
        print($TB "                                                 test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay);\n");
      }
      print($TB "                            end else begin\n");
      print($TB "                              // Enable mode generator\n");
      print($TB "                              enable[MODE_GEN] = 0;\n");
      print($TB "                              latch_enable[MODE_GEN] = 0;\n");
      print($TB "                              update_enable[MODE_GEN] = 0; // test vector generate is not enabled for loading\n");
      print($TB "                              // test vector is loaded to mode generator\n");
      print($TB "                              mode_pattern_str     = pattern;\n");
      print($TB "                              port_index_mem[MODE_GEN] = mem[index];\n");
      if ($rnm == 1){
        print($TB "                              update_test_vector(     port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,     real_port_val,     real_port_def_step,     real_port_max_real,\n");
        print($TB "                                                 mode_port_en,mode_port_test_type,mode_port_type,mode_port_care_range,mode_normal_port_val,mode_port_delay,mode_real_port_val,mode_real_port_def_step,mode_real_port_max_real);\n");
      } else {
        print($TB "                              update_test_vector(     port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,\n");
        print($TB "                                                 mode_port_en,mode_port_test_type,mode_port_type,mode_port_care_range,mode_normal_port_val,mode_port_delay);\n");
      }
      print($TB "                            end\n");
      print($TB "                          end else if (state == EXEC_PRE_MODE) begin\n");
      print($TB "                            // Enable test generator\n");
      print($TB "                            enable[MODE_GEN] = 0;\n");
      print($TB "                            enable[TEST_GEN] = 1; // Enable for test generator\n");
      print($TB "                            latch_enable[MODE_GEN] = 0;\n");
      print($TB "                            latch_enable[TEST_GEN] = 0;\n");
      print($TB "                            update_enable[MODE_GEN] = 0; // mode generate is not enabled for loading\n");
      print($TB "                            update_enable[TEST_GEN] = 1; // test vector generate is enabled for loading\n");
      print($TB "                            // test vector in mode is loaded into test generator\n");
      print($TB "                            test_pattern_str = mode_pattern_str;\n");
      print($TB "                            mode_pattern_str = pattern;\n");
      print($TB "                            pattern = test_pattern_str;       // pattern is updated for previous mode\n");
      print($TB "                            port_index_mem[TEST_GEN] = port_index_mem[MODE_GEN];\n");
      if ($rnm == 1){
        print($TB "                            update_test_vector(mode_port_en,mode_port_test_type,mode_port_type,mode_port_care_range,mode_normal_port_val,mode_port_delay,mode_real_port_val,mode_real_port_def_step,mode_real_port_max_real,\n");
        print($TB "                                               test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay,test_real_port_val,test_real_port_def_step,test_real_port_max_real);\n");
      } else {
        print($TB "                            update_test_vector(mode_port_en,mode_port_test_type,mode_port_type,mode_port_care_range,mode_normal_port_val,mode_port_delay,\n");
        print($TB "                                               test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay);\n");
      }
      print($TB "                            // mode generator is reloaded with new mode\n");
      print($TB "                            port_index_mem[MODE_GEN] = mem[index];\n");
      if ($rnm == 1){
        print($TB "                            update_test_vector(     port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,     real_port_val,     real_port_def_step,     real_port_max_real,\n");
        print($TB "                                               mode_port_en,mode_port_test_type,mode_port_type,mode_port_care_range,mode_normal_port_val,mode_port_delay,mode_real_port_val,mode_real_port_def_step,mode_real_port_max_real);\n");
      } else {
        print($TB "                            update_test_vector(     port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,\n");
        print($TB "                                               mode_port_en,mode_port_test_type,mode_port_type,mode_port_care_range,mode_normal_port_val,mode_port_delay);\n");
      }
      print($TB "                          end else if (state == LOAD_SUB_MODE) begin\n");
      print($TB "                            for (i3=0;i3<MAX_SUB_MODE_NUM+2;i3++) begin\n");
      print($TB "                              enable[i3] = 0;\n");
      print($TB "                              latch_enable[i3] = 0;\n");
      print($TB "                              update_enable[i3] = 0;\n");
      print($TB "                            end\n");
      print($TB "                            port_index_mem[`CUR_SUB_MODE_GEN] = mem[index];\n");
      if($max_sub_mode_num>0){
        print($TB "                            sub_mode_pattern_str[sub_mode_index] = pattern;\n");
        if ($rnm == 1){
          print($TB "                            update_test_vector(         port_en                ,         port_test_type                ,         port_type                ,         port_care_range                ,         normal_port_val                ,         port_delay                ,     real_port_val,     real_port_def_step,     real_port_max_real,\n");
          print($TB "                                               sub_mode_port_en[sub_mode_index],sub_mode_port_test_type[sub_mode_index],sub_mode_port_type[sub_mode_index],sub_mode_port_care_range[sub_mode_index],sub_mode_normal_port_val[sub_mode_index],sub_mode_port_delay[sub_mode_index],sub_mode_real_port_val[sub_mode_index],sub_mode_real_port_def_step[sub_mode_index],sub_mode_real_port_max_real[sub_mode_index]);\n");
        }else{
          print($TB "                            update_test_vector(         port_en                ,         port_test_type                ,         port_type                ,         port_care_range                ,         normal_port_val                ,         port_delay                ,\n");
          print($TB "                                               sub_mode_port_en[sub_mode_index],sub_mode_port_test_type[sub_mode_index],sub_mode_port_type[sub_mode_index],sub_mode_port_care_range[sub_mode_index],sub_mode_normal_port_val[sub_mode_index],sub_mode_port_delay[sub_mode_index]);\n");
        }
      }
      print($TB "                            sub_mode_index++;\n");
      print($TB "                          end else if (state == EXEC_MODE) begin\n");
      print($TB "                            enable[MODE_GEN] = 1;\n");
      print($TB "                            latch_enable[MODE_GEN] = 0;\n");
      print($TB "                            update_enable[MODE_GEN] = 1;\n"); # Revise Feb16
      print($TB "                            // last sub mode test vector is loaded to sub mode generator\n");
      print($TB "                            enable[`CUR_SUB_MODE_GEN] = 0;\n");
      print($TB "                            latch_enable[`CUR_SUB_MODE_GEN] = 0;\n");
      print($TB "                            update_enable[`CUR_SUB_MODE_GEN] = 0;\n");
      print($TB "                            port_index_mem[`CUR_SUB_MODE_GEN] = mem[index];\n");
      if($max_sub_mode_num>0){
        print($TB "                            sub_mode_pattern_str[sub_mode_index] = pattern;\n");
        if ($rnm == 1){
          print($TB "                            update_test_vector(         port_en                ,         port_test_type                ,         port_type                ,         port_care_range                ,         normal_port_val                ,         port_delay                ,     real_port_val,     real_port_def_step,     real_port_max_real,\n");
          print($TB "                                               sub_mode_port_en[sub_mode_index],sub_mode_port_test_type[sub_mode_index],sub_mode_port_type[sub_mode_index],sub_mode_port_care_range[sub_mode_index],sub_mode_normal_port_val[sub_mode_index],sub_mode_port_delay[sub_mode_index],sub_mode_real_port_val[sub_mode_index],sub_mode_real_port_def_step[sub_mode_index],sub_mode_real_port_max_real[sub_mode_index]);\n");
        }else{
          print($TB "                            update_test_vector(         port_en                ,         port_test_type                ,         port_type                ,         port_care_range                ,         normal_port_val                ,         port_delay                ,\n");
          print($TB "                                               sub_mode_port_en[sub_mode_index],sub_mode_port_test_type[sub_mode_index],sub_mode_port_type[sub_mode_index],sub_mode_port_care_range[sub_mode_index],sub_mode_normal_port_val[sub_mode_index],sub_mode_port_delay[sub_mode_index]);\n");
        }
        print($TB "                            sub_mode_num = sub_mode_index + 1;\n");
        print($TB "                            sub_mode_index = 0;\n");
      } 
      print($TB "                          end else if (state == EXEC_SUB_MODE) begin\n");
      print($TB "                         // do nothing (never reach)\n");
      print($TB "                          end else if (state == MODE_SET_VALUE) begin\n");
      print($TB "                            // Enable mode generator\n");
      print($TB "                            enable[MODE_GEN] = 1;\n");
      print($TB "                            latch_enable[MODE_GEN] = 0;\n");
      print($TB "                            update_enable[MODE_GEN] = 1; // test vector generate is not enabled for loading\n");
      print($TB "                            // Reserve test vector for load mode\n");
      print($TB "                            if (next_state == LOAD_MODE) begin\n");
      if ($rnm == 1){
        print($TB "                              update_test_vector(    mode_port_en,    mode_port_test_type,    mode_port_type,    mode_port_care_range,    mode_normal_port_val,    mode_port_delay,    mode_real_port_val,    mode_real_port_def_step,    mode_real_port_max_real,\n");
        print($TB "                                                 reserved_port_en,reserved_port_test_type,reserved_port_type,reserved_port_care_range,reserved_normal_port_val,reserved_port_delay,reserved_real_port_val,reserved_real_port_def_step,reserved_real_port_max_real);\n");
      } else {
        print($TB "                              update_test_vector(    mode_port_en,    mode_port_test_type,    mode_port_type,    mode_port_care_range,    mode_normal_port_val,    mode_port_delay,\n");
        print($TB "                                                 reserved_port_en,reserved_port_test_type,reserved_port_type,reserved_port_care_range,reserved_normal_port_val,reserved_port_delay);\n");
      }
      print($TB "                              port_index_mem[RESERVED] = port_index_mem[MODE_GEN];\n");
      print($TB "                              reserved_pattern_str = mode_pattern_str;\n");
      print($TB "                            end\n");
      print($TB "                            // test vector is loaded to mode generator\n");
      print($TB "                            mode_pattern_str     = pattern;\n");
      print($TB "                            port_index_mem[MODE_GEN] = mem[index];\n");
      if ($rnm == 1){
        print($TB "                            update_test_vector(     port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,     real_port_val,     real_port_def_step,     real_port_max_real,\n");
        print($TB "                                               mode_port_en,mode_port_test_type,mode_port_type,mode_port_care_range,mode_normal_port_val,mode_port_delay,mode_real_port_val,mode_real_port_def_step,mode_real_port_max_real);\n");
      } else {
        print($TB "                            update_test_vector(     port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,\n");
        print($TB "                                               mode_port_en,mode_port_test_type,mode_port_type,mode_port_care_range,mode_normal_port_val,mode_port_delay);\n");
      }
      print($TB "                            // Enable test generator\n");
      print($TB "                            enable[TEST_GEN] = 1;\n");
      print($TB "                            latch_enable[TEST_GEN] = 1; // enable load test vector from mode\n");
      print($TB "                            update_enable[TEST_GEN] = 1; // test vector generate is enabled for loading 1 time\n");
      print($TB "                            // test vector is loaded to test generator\n");
      print($TB "                            port_index_mem[TEST_GEN] = mem[index];\n");
      if ($rnm == 1){
        print($TB "                            update_test_vector(     port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,     real_port_val,     real_port_def_step,     real_port_max_real,\n");
        print($TB "                                               test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay,test_real_port_val,test_real_port_def_step,test_real_port_max_real);\n");
      } else {
        print($TB "                            update_test_vector(     port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,\n");
        print($TB "                                               test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay);\n");
      }
      print($TB "                          end else begin // state == EXEC_TEST_VECTOR\n");
      print($TB "                            enable[TEST_GEN] = 1; // Enable for test generator\n");
      print($TB "                            latch_enable[TEST_GEN] = 0;\n");
      print($TB "                            update_enable[TEST_GEN] = 1; // test vector generate is enabled for loading\n");
      print($TB "                            enable[MODE_GEN] = 0; // Disable for mode generator\n");
      print($TB "                            latch_enable[MODE_GEN] = 0;\n");
      print($TB "                            update_enable[MODE_GEN] = 0;\n");
      print($TB "                            // test generator is loaded\n");
      print($TB "                            test_pattern_str = pattern;\n");
      print($TB "                            port_index_mem[TEST_GEN] = mem[index];\n");
      if ($rnm == 1){
        print($TB "                            update_test_vector(     port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,     real_port_val,     real_port_def_step,     real_port_max_real,\n");
        print($TB "                                               test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay,test_real_port_val,test_real_port_def_step,test_real_port_max_real);\n");
      } else {
        print($TB "                            update_test_vector(     port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,\n");
        print($TB "                                               test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay);\n");
      }
      print($TB "                          end\n");
      print($TB "                          begin: test_generate_block\n");
      print($TB "                          while ((enable[MODE_GEN] == 1 && test_gen_finish[MODE_GEN] == 0) || (enable[TEST_GEN] == 1 && test_gen_finish[TEST_GEN] == 0)\n");
      for(my $num_sub=0;$num_sub<$max_sub_mode_num;$num_sub++){
        print($TB "                          || (enable[SUB_MODE$num_sub\_GEN] == 1 && test_gen_finish[SUB_MODE$num_sub\_GEN] == 0)\n");
      }
      print($TB "                          )begin\n");
      if (@outseq != 0){
        for (my $i=0;$i<scalar(@rising_clock_cnt);$i++){
          print($TB "                            first_$rising_clock_cnt[$i]\_rising_time = 0;\n");
        }
        for (my $i=0;$i<scalar(@falling_clock_cnt);$i++){
          print($TB "                            first_$falling_clock_cnt[$i]\_falling_time = 0;\n");
        }
        for (my $i=1;$i<scalar(@outseq);$i++){
          my ($cond_name,$out_name,$port_ref_num,$in_port_name,$out_port_name)=get_port_timing_info($outseq[$i][2],$outseq[$i][3],@port_ref_table);
          my $check_type = "rising";
          $check_type = "falling" if ($outseq[$i][4] =~ /neg/);
          my $check_name = lc($outseq[$i][0])."_$outseq[$i][5]";
          if ($outseq[$i][4] =~ /^(pos|neg)/) { # Ex: pos/neg 5
            print($TB "                            $check_type\_$check_name\_num = 0;\n");
          }
        }
      }
      print($TB "                            if (state == MODE_SET_VALUE) begin\n");
      print($TB "                              pattern = latch_enable_pattern;\n");
      if ($rnm == 1){
        print($TB "                              update_test_vector(mode_port_en,mode_port_test_type,mode_port_type,mode_port_care_range,mode_normal_port_val,mode_port_delay,mode_real_port_val,mode_real_port_def_step,mode_real_port_max_real,\n");
        print($TB "                                                      port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,     real_port_val,     real_port_def_step,     real_port_max_real);\n");
      } else {
        print($TB "                              update_test_vector(mode_port_en,mode_port_test_type,mode_port_type,mode_port_care_range,mode_normal_port_val,mode_port_delay,\n");
        print($TB "                                                      port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay);\n");
      }
      print($TB "                              test_gen_trigger[MODE_GEN] <= ~test_gen_trigger[MODE_GEN]; // generate mode vector\n");
      print($TB "                              test_gen_trigger[TEST_GEN] <= ~test_gen_trigger[TEST_GEN]; // generate test vector for 1 time at first, this test vector is not used\n");
      print($TB "                              #1\n");
      print($TB "                              update_enable[MODE_GEN] = 0; // test vector generate is not enabled for loading\n");
      print($TB "                            end else if (state == MODE_HOLD_START || state == TEST_HOLD || state == MODE_HOLD || state == MODE_HOLD_START_SELF || state == TEST_HOLD_SELF || state == MODE_HOLD_SELF) begin\n");
      print($TB "                              pattern = latch_disable_pattern;\n");
      print($TB "                            end else if (state == TEST_THROUGH || state == MODE_THROUGH || state == TEST_THROUGH_SELF || state == MODE_THROUGH_SELF) begin\n");
      print($TB "                              pattern = latch_enable_pattern;\n");
      print($TB "                            end else if (state == TEST_INPUT_CHANGE) begin\n");
      print($TB "                              pattern = latch_disable_pattern;\n");
      if ($rnm == 1){
        print($TB "                              update_test_vector(test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay,test_real_port_val,test_real_port_def_step,test_real_port_max_real,\n");
        print($TB "                                                      port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,     real_port_val,     real_port_def_step,     real_port_max_real);\n");
      } else {
        print($TB "                              update_test_vector(test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay,\n");
        print($TB "                                                      port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay);\n");
      }
      print($TB "                              test_gen_trigger[TEST_GEN] <= ~test_gen_trigger[TEST_GEN]; // generate test vector\n");
      print($TB "                            end else if (state == TEST_INPUT_CHANGE_SELF) begin\n");
      print($TB "                              pattern = latch_disable_pattern;\n");
      print($TB "                            end else if (state == MODE_INPUT_CHANGE || state == MODE_INPUT_CHANGE_SELF) begin\n");
      print($TB "                              pattern = latch_disable_pattern;\n");
      if ($rnm == 1){
        print($TB "                              update_test_vector(mode_port_en,mode_port_test_type,mode_port_type,mode_port_care_range,mode_normal_port_val,mode_port_delay,mode_real_port_val,mode_real_port_def_step,mode_real_port_max_real,\n");
        print($TB "                                                      port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,     real_port_val,     real_port_def_step,     real_port_max_real);\n");
      } else {
        print($TB "                              update_test_vector(mode_port_en,mode_port_test_type,mode_port_type,mode_port_care_range,mode_normal_port_val,mode_port_delay,\n");
        print($TB "                                                      port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay);\n");
      }
      print($TB "                            end else if (state == EXEC_MODE || state == LOAD_MODE) begin\n");
      print($TB "                              pattern = mode_pattern_str;\n");
      if ($rnm == 1){
        print($TB "                              update_test_vector(mode_port_en,mode_port_test_type,mode_port_type,mode_port_care_range,mode_normal_port_val,mode_port_delay,mode_real_port_val,mode_real_port_def_step,mode_real_port_max_real,\n");
        print($TB "                                                      port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,     real_port_val,     real_port_def_step,     real_port_max_real);\n");
      } else {
        print($TB "                              update_test_vector(mode_port_en,mode_port_test_type,mode_port_type,mode_port_care_range,mode_normal_port_val,mode_port_delay,\n");
        print($TB "                                                      port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay);\n");
      }
      print($TB "                              test_gen_trigger[MODE_GEN] <= ~test_gen_trigger[MODE_GEN]; // generate mode pattern\n");
      if($max_sub_mode_num>0){
        print($TB "                            end else if (state == EXEC_SUB_MODE) begin\n");
        print($TB "                              pattern = sub_mode_pattern_str[sub_mode_index];\n");
        print($TB "                              test_gen_trigger[`CUR_SUB_MODE_GEN] <= ~test_gen_trigger[`CUR_SUB_MODE_GEN];\n");
      }
      if($lfo eq "1"){
        for(my $k=0;$k<scalar(@force_num_pat);$k++){
            print($TB "                            end else if (state == $force_num_pat[$k]) begin\n");
            print($TB "                              pattern = $force_num_pat[$k]_pattern;\n");
        }
        print($TB "                            end else if (state == BACK_TO_HOLD) begin\n");
        print($TB "                              pattern = latch_disable_pattern;\n");
        print($TB "                            end else if (state == HOLD_FORCE) begin\n");
        print($TB "                              pattern = latch_disable_pattern;\n");
      }
      print($TB "                            end else begin\n");
      print($TB "                              pattern = test_pattern_str;\n");
      if ($rnm == 1){
        print($TB "                              update_test_vector(test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay,test_real_port_val,test_real_port_def_step,test_real_port_max_real,\n");
        print($TB "                                                      port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,     real_port_val,     real_port_def_step,     real_port_max_real);\n");
      } else {
        print($TB "                              update_test_vector(test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay,\n");
        print($TB "                                                      port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay);\n");
      }
      print($TB "                              test_gen_trigger[TEST_GEN] <= ~test_gen_trigger[TEST_GEN]; // generate test pattern\n");
      print($TB "                            end\n");
      print($TB "                            erks_rst_freq = 0;\n");
      print($TB "                            #1\n");
      print($TB "                            if (state == MODE_SET_VALUE || state == MODE_HOLD_START) begin\n");
      print($TB "                              if (force_start == 0) begin\n");
      print($TB "                                temp_port_reg = mode_vector; // test is generated from mode gen\n");
      print($TB "                              end else begin\n");
      print($TB "                                temp_port_reg = test_vector; // test is generated from test gen\n");
      print($TB "                              end\n");
      print($TB "                              if (state == MODE_SET_VALUE) temp_port_reg[latch_port_index] = 1'b1; // latch port is set to 1\n");
      print($TB "                              else temp_port_reg[latch_port_index] = 1'b0; // latch port is set to 0\n");
      print($TB "                              port_rising_enb = mode_rising_enb;\n");
      print($TB "                              port_falling_enb = mode_falling_enb;\n");
      print($TB "                            end else if (state == TEST_INPUT_CHANGE || state == TEST_THROUGH || state == TEST_HOLD || state == TEST_INPUT_CHANGE_SELF || state == TEST_THROUGH_SELF || state == TEST_HOLD_SELF) begin\n");
      print($TB "                              temp_port_reg = test_vector; // test is generated from test gen\n");
      print($TB "                              if (state == TEST_THROUGH || state == TEST_THROUGH_SELF) temp_port_reg[latch_port_index] = 1'b1; // latch port is set to 1\n");
      print($TB "                              else temp_port_reg[latch_port_index] = 1'b0; // latch port is set to 0\n");
      print($TB "                              port_rising_enb = test_rising_enb;\n");
      print($TB "                              port_falling_enb = test_falling_enb;\n");
      print($TB "                            end else if (state == MODE_INPUT_CHANGE || state == MODE_THROUGH || state == MODE_HOLD || state == MODE_INPUT_CHANGE_SELF || state == MODE_THROUGH_SELF || state == MODE_HOLD_SELF) begin\n");
      print($TB "                              temp_port_reg = mode_vector; // test is generated from mode gen\n");
      print($TB "                              if (state == MODE_THROUGH || state == MODE_THROUGH_SELF) temp_port_reg[latch_port_index] = 1'b1; // latch port is set to 1\n");
      print($TB "                              else temp_port_reg[latch_port_index] = 1'b0; // latch port is set to 0\n");
      print($TB "                              port_rising_enb = test_rising_enb;\n");
      print($TB "                              port_falling_enb = test_falling_enb;\n");
      print($TB "                            end else if (state == EXEC_MODE || state == LOAD_MODE) begin\n");
      print($TB "                              temp_port_reg = mode_vector; // test is generated from mode gen\n");
      if ($rnm == 1){
        print($TB "                              temp_real_reg = mode_real_pattern; // test is generated from mode gen\n");
      }
      print($TB "                              port_rising_enb = mode_rising_enb;\n");
      print($TB "                              port_falling_enb = mode_falling_enb;\n");
      if($max_sub_mode_num > 0){
        print($TB "                            end else if (state == EXEC_SUB_MODE) begin\n");
        print($TB "                              temp_port_reg = sub_mode_vector[sub_mode_index]; // test is generated from sub mode gen\n");
        if ($rnm == 1){
          print($TB "                              temp_real_reg = sub_mode_real_pattern[sub_mode_index];\n");
        }
        print($TB "                              port_rising_enb = sub_mode_rising_enb[sub_mode_index];\n");
        print($TB "                              port_falling_enb = sub_mode_falling_enb[sub_mode_index];\n");
      }
      if($lfo eq "1"){
        if($no_back ne "1"){
          print($TB "                            end else if (state == BACK_TO_HOLD) begin\n");
          print($TB "                              temp_port_reg = test_vector; // test is generated from mode gen\n");
          print($TB "                              temp_port_reg[latch_port_index] = 1'b0; // latch port is set to 0\n");
          print($TB "                              port_rising_enb = mode_rising_enb;\n");
          print($TB "                              port_falling_enb = mode_falling_enb;\n");
        }
        foreach my $key (keys %force_index){
          print($TB "                            end else if (state == $key) begin\n");
          my @idx= @{$force_index{$key}}; 
          my @val= @{$force_value{$key}}; 
          for(my $z=0;$z<scalar(@idx);$z++){
            my $index = $idx[$z];
            my $value = $val[$z];
            print($TB "                              temp_port_reg[$index] = $value; // test is generated from mode gen\n");
          }
        }
      }
      print($TB "                            end else begin\n");
      print($TB "                              temp_port_reg = test_vector; // test is generated from test gen\n");
      if ($rnm == 1){
        print($TB "                              temp_real_reg = test_real_pattern; // test is generated from mode gen\n");
      }
      print($TB "                              port_rising_enb = test_rising_enb;\n");
      print($TB "                              port_falling_enb = test_falling_enb;\n");
      print($TB "                            end\n");
      $test_mod_gen .= "      loop_cont = 0;\n";
      $test_mod_gen .= "      for (i1=PORT_NUM-1;i1>=0;i1--) begin\n";
      $test_mod_gen .= "        port_index = (mem >> (16*i1))&16'hFFFF;\n";
      $test_mod_gen .= "        if(port_en[port_index] == PORT_ENABLED) begin\n";
      if($rnm == 1){
        $test_mod_gen .= "          if (port_type[port_index] == REAL_PORT_TYPE) begin\n";
        $test_mod_gen .= "            temp_real_reg[port_index] = '{real_port_val[port_index].i,real_port_val[port_index].r};\n";
        $test_mod_gen .= "          end\n";
      }
      $test_mod_gen .= "          case (port_test_type[port_index])\n";
      $test_mod_gen .= "            EXP_NOT_0_VAL: begin \n";
      $test_mod_gen .= "                             if(port_type[port_index] == NORMAL_PORT_TYPE) begin // normal port\n";
      $test_mod_gen .= "                               begin: block_not_0\n";
      $test_mod_gen .= "                               for(i2=0;i2<port_care_range[port_index]-1;i2=i2+1) begin\n";
      $test_mod_gen .= "                                 if(port_loop_cnt[port_index]==i2) begin\n";
      $test_mod_gen .= "                                   temp_port_reg[port_index] = b_it[i2+1]; // Do not set value 0\n";
      $test_mod_gen .= "                                   disable block_not_0;\n";
      $test_mod_gen .= "                                 end\n";
      $test_mod_gen .= "                               end\n";
      $test_mod_gen .= "                               end\n";
      $test_mod_gen .= "                               if (port_loop_cnt[port_index] == (port_care_range[port_index]-2)) begin\n";
      $test_mod_gen .= "                                 if (update_enable == 1) port_break[port_index] = 1;\n";
      $test_mod_gen .= "                               end else begin\n";
      $test_mod_gen .= "                                 if (loop_cnt_ctrl[i1] == 1 && update_enable == 1) begin\n";
      $test_mod_gen .= "                                   port_loop_cnt[port_index] = port_loop_cnt[port_index] + 1;\n";
      $test_mod_gen .= "                                 end\n";
      $test_mod_gen .= "                               end\n";
      $test_mod_gen .= "                             end\n";
      $test_mod_gen .= "                           end\n";
      $test_mod_gen .= "            EXP_NOT_1_VAL: begin \n";
      $test_mod_gen .= "                             if(port_type[port_index] == NORMAL_PORT_TYPE) begin // normal port\n";
      $test_mod_gen .= "                               begin: block_not_1\n";
      $test_mod_gen .= "                               for(i2=0;i2<port_care_range[port_index]-1;i2=i2+1) begin\n";
      $test_mod_gen .= "                                 if(port_loop_cnt[port_index]==i2) begin\n";
      $test_mod_gen .= "                                   if(i2==0) begin\n";
      $test_mod_gen .= "                                     temp_port_reg[port_index] = b_it[i2];\n";
      $test_mod_gen .= "                                   end else begin\n";
      $test_mod_gen .= "                                     temp_port_reg[port_index] = b_it[i2+1];\n";
      $test_mod_gen .= "                                   end\n";
      $test_mod_gen .= "                                   disable block_not_1;\n";
      $test_mod_gen .= "                                 end\n";
      $test_mod_gen .= "                               end\n";
      $test_mod_gen .= "                               end\n";
      $test_mod_gen .= "                               if (port_loop_cnt[port_index] == (port_care_range[port_index]-2)) begin\n";
      $test_mod_gen .= "                                 if (update_enable == 1) port_break[port_index] = 1;\n";
      $test_mod_gen .= "                               end else begin\n";
      $test_mod_gen .= "                                 if (loop_cnt_ctrl[i1] == 1 && update_enable == 1) begin\n";
      $test_mod_gen .= "                                   port_loop_cnt[port_index] = port_loop_cnt[port_index] + 1;\n";
      $test_mod_gen .= "                                 end\n";
      $test_mod_gen .= "                               end\n";
      $test_mod_gen .= "                             end\n";
      $test_mod_gen .= "                           end\n";
      $test_mod_gen .= "            EXP_NOT_X_VAL: begin \n";
      $test_mod_gen .= "                             if(port_type[port_index] == NORMAL_PORT_TYPE) begin // normal port\n";
      $test_mod_gen .= "                               begin: block_not_x\n";
      $test_mod_gen .= "                               for(i2=0;i2<port_care_range[port_index]-1;i2=i2+1) begin\n";
      $test_mod_gen .= "                                 if(port_loop_cnt[port_index]==i2) begin\n";
      $test_mod_gen .= "                                   if(i2<2) begin\n";
      $test_mod_gen .= "                                     temp_port_reg[port_index] = b_it[i2];\n";
      $test_mod_gen .= "                                   end else begin\n";
      $test_mod_gen .= "                                     temp_port_reg[port_index] = b_it[i2+1];\n";
      $test_mod_gen .= "                                   end\n";
      $test_mod_gen .= "                                   disable block_not_x;\n";
      $test_mod_gen .= "                                 end\n";
      $test_mod_gen .= "                               end\n";
      $test_mod_gen .= "                               end\n";
      $test_mod_gen .= "                               if (port_loop_cnt[port_index] == (port_care_range[port_index]-2)) begin\n";
      $test_mod_gen .= "                                 if (update_enable == 1) port_break[port_index] = 1;\n";
      $test_mod_gen .= "                               end else begin\n";
      $test_mod_gen .= "                                 if (loop_cnt_ctrl[i1] == 1 && update_enable == 1) begin\n";
      $test_mod_gen .= "                                   port_loop_cnt[port_index] = port_loop_cnt[port_index] + 1;\n";
      $test_mod_gen .= "                                 end\n";
      $test_mod_gen .= "                               end\n";
      $test_mod_gen .= "                             end\n";
      $test_mod_gen .= "                           end\n";
      $test_mod_gen .= "            EXP_NOT_Z_VAL: begin \n";
      $test_mod_gen .= "                             if(port_type[port_index] == NORMAL_PORT_TYPE) begin // normal port\n";
      $test_mod_gen .= "                               begin: block_not_z\n";
      $test_mod_gen .= "                               for(i2=0;i2<port_care_range[port_index]-1;i2=i2+1) begin\n";
      $test_mod_gen .= "                                 if(port_loop_cnt[port_index]==i2) begin\n";
      $test_mod_gen .= "                                   temp_port_reg[port_index] = b_it[i2];\n";
      $test_mod_gen .= "                                   disable block_not_z;\n";
      $test_mod_gen .= "                                 end\n";
      $test_mod_gen .= "                               end\n";
      $test_mod_gen .= "                               end\n";
      $test_mod_gen .= "                               if (port_loop_cnt[port_index] == (port_care_range[port_index]-2)) begin\n";
      $test_mod_gen .= "                                 if (update_enable == 1) port_break[port_index] = 1;\n";
      $test_mod_gen .= "                               end else begin\n";
      $test_mod_gen .= "                                 if (loop_cnt_ctrl[i1] == 1 && update_enable == 1) begin\n";
      $test_mod_gen .= "                                   port_loop_cnt[port_index] = port_loop_cnt[port_index] + 1;\n";
      $test_mod_gen .= "                                 end\n";
      $test_mod_gen .= "                               end\n";
      $test_mod_gen .= "                             end\n";
      $test_mod_gen .= "                           end\n";
      $test_mod_gen .= "            DONTCARE_TYPE: begin \n";
      $test_mod_gen .= "                             if(port_type[port_index] == NORMAL_PORT_TYPE) begin // normal port\n";
      $test_mod_gen .= "                               begin: block_dontcare\n";
      $test_mod_gen .= "                               for(i2=0;i2<port_care_range[port_index];i2=i2+1) begin\n";
      $test_mod_gen .= "                                 if(port_loop_cnt[port_index]==i2) begin\n";
      $test_mod_gen .= "                                   temp_port_reg[port_index] = b_it[i2];\n";
      $test_mod_gen .= "                                   disable block_dontcare;\n";
      $test_mod_gen .= "                                 end\n";
      $test_mod_gen .= "                               end\n";
      $test_mod_gen .= "                               end\n";
      $test_mod_gen .= "                               if (port_loop_cnt[port_index] == (port_care_range[port_index]-1)) begin\n";
      $test_mod_gen .= "                                 if (update_enable == 1) port_break[port_index] = 1;\n";
      $test_mod_gen .= "                               end else begin\n";
      $test_mod_gen .= "                                 if (loop_cnt_ctrl[i1] == 1 && update_enable == 1) begin\n";
      $test_mod_gen .= "                                   port_loop_cnt[port_index] = port_loop_cnt[port_index] + 1;\n";
      $test_mod_gen .= "                                 end\n";
      $test_mod_gen .= "                               end\n";
      if($rnm == 1){
        $test_mod_gen .= "                             end else begin // real port\n";
        $test_mod_gen .= "                               if(port_loop_cnt[port_index]==0 && port_care_range[port_index]==4) begin\n";
        $test_mod_gen .= "                                 temp_real_reg[port_index] = real_b_it[3];\n";
        $test_mod_gen .= "                               end else if(port_loop_cnt[port_index]==1 && port_care_range[port_index]>=3) begin\n";
        $test_mod_gen .= "                                 temp_real_reg[port_index] = real_b_it[2];\n";
        $test_mod_gen .= "                               end else if(port_loop_cnt[port_index]>1)begin\n";
        $test_mod_gen .= "                                 tmp_real_val = real_port_val[port_index].r + (port_loop_cnt[port_index] - 2)*real_port_def_step[port_index];\n";
        $test_mod_gen .= "                                 temp_real_reg[port_index].r = tmp_real_val;\n";
        $test_mod_gen .= "                                 if (temp_real_reg[port_index].r >= real_port_max_real[port_index]) begin\n";
        $test_mod_gen .= "                                     if (update_enable == 1) port_break[port_index] = 1;\n";
        $test_mod_gen .= "                                 end\n";
        $test_mod_gen .= "                               end\n";
        $test_mod_gen .= "                               if (loop_cnt_ctrl[i1] == 1 && update_enable == 1) begin\n";
        $test_mod_gen .= "                                 port_loop_cnt[port_index] = port_loop_cnt[port_index] + 1;\n";
        $test_mod_gen .= "                               end\n";
      }
      $test_mod_gen .= "                             end\n";
      $test_mod_gen .= "                           end\n";
      $test_mod_gen .= "            CROSS_TYPE   : begin\n";
      $test_mod_gen .= "                             if(port_type[port_index] == NORMAL_PORT_TYPE) begin // normal port\n";
      $test_mod_gen .= "                               if(port_loop_cnt[port_index]==0) begin\n";
      $test_mod_gen .= "                                 temp_port_reg[port_index] = b_it[0];\n";
      $test_mod_gen .= "                                 if (loop_cnt_ctrl[i1] == 1 && update_enable == 1) begin\n";
      $test_mod_gen .= "                                   port_loop_cnt[port_index] = port_loop_cnt[port_index] + 1;\n";
      $test_mod_gen .= "                                 end\n";
      $test_mod_gen .= "                               end else begin\n";
      $test_mod_gen .= "                                 temp_port_reg[port_index] = b_it[1];\n";
      $test_mod_gen .= "                                 if (update_enable == 1) port_break[port_index] = 1;\n";
      $test_mod_gen .= "                               end\n";
      if($rnm == 1){
        $test_mod_gen .= "                             end else begin //real port\n";
        $test_mod_gen .= "                               if (port_loop_cnt[port_index] == 0) begin // do nothing\n";
        $test_mod_gen .= "                               end else if (port_loop_cnt[port_index] == 1) begin\n";
        $test_mod_gen .= "                                 temp_real_reg[port_index].r = real_port_max_real[port_index];\n";
        $test_mod_gen .= "                               end else begin\n";
        $test_mod_gen .= "                                 temp_real_reg[port_index] = real_b_it[port_loop_cnt[port_index]];\n";
        $test_mod_gen .= "                               end\n";
        $test_mod_gen .= "                               if (loop_cnt_ctrl[i1] == 1 && update_enable == 1) begin\n";
        $test_mod_gen .= "                                 port_loop_cnt[port_index] = port_loop_cnt[port_index] + 1;\n";
        $test_mod_gen .= "                               end\n";
        $test_mod_gen .= "                               if (port_loop_cnt[port_index]>=port_care_range[port_index]) begin\n";
        $test_mod_gen .= "                                 if (update_enable == 1) port_break[port_index] = 1;\n";
        $test_mod_gen .= "                               end\n";
      }
      $test_mod_gen .= "                             end\n";
      $test_mod_gen .= "                           end\n";
      $test_mod_gen .= "            S_TYPE       : begin\n";
      $test_mod_gen .= "                             if(port_type[port_index] == NORMAL_PORT_TYPE) begin // normal port\n";
      $test_mod_gen .= "                               if(port_loop_cnt[port_index]==0) begin\n";
      $test_mod_gen .= "                                 temp_port_reg[port_index] = b_it[0];\n";
      $test_mod_gen .= "                                 if (loop_cnt_ctrl[i1] == 1 && update_enable == 1) begin\n";
      $test_mod_gen .= "                                   port_loop_cnt[port_index] = port_loop_cnt[port_index] + 1;\n";
      $test_mod_gen .= "                                 end\n";
      $test_mod_gen .= "                               end else begin\n";
      $test_mod_gen .= "                                 temp_port_reg[port_index] = b_it[1];\n";
      $test_mod_gen .= "                                 if (update_enable == 1) port_break[port_index] = 1;\n";
      $test_mod_gen .= "                               end\n";
      if($rnm == 1){
        $test_mod_gen .= "                             end else begin // real port\n";
        $test_mod_gen .= "                               if (port_loop_cnt[port_index] == 0) begin // do nothing\n";
        $test_mod_gen .= "                               end else if (port_loop_cnt[port_index] == 1) begin\n";
        $test_mod_gen .= "                                 temp_real_reg[port_index].r = real_port_max_real[port_index];\n";
        $test_mod_gen .= "                               end else begin\n";
        $test_mod_gen .= "                                 temp_real_reg[port_index] = real_b_it[port_loop_cnt[port_index]];\n";
        $test_mod_gen .= "                               end\n";
        $test_mod_gen .= "                               if (loop_cnt_ctrl[i1] == 1 && update_enable == 1) begin\n";
        $test_mod_gen .= "                                 port_loop_cnt[port_index] = port_loop_cnt[port_index] + 1;\n";
        $test_mod_gen .= "                               end\n";
        $test_mod_gen .= "                               if (port_loop_cnt[port_index]>=port_care_range[port_index]) begin\n";
        $test_mod_gen .= "                                 if (update_enable == 1) port_break[port_index] = 1;\n";
        $test_mod_gen .= "                               end\n";
      }
      $test_mod_gen .= "                             end\n";
      $test_mod_gen .= "                           end\n";
      if($rnm == 1){
        $test_mod_gen .= "            RAMP_TYPE    : begin // real port only\n";
        $test_mod_gen .= "                             if(port_loop_cnt[port_index]==0) begin\n";
        $test_mod_gen .= "                             end else begin\n";
        $test_mod_gen .= "                               temp_real_reg[port_index].r = real_reg[port_index].r + real_port_def_step[port_index];\n";
        $test_mod_gen .= "                               if (temp_real_reg[port_index].r >= real_port_max_real[port_index]) begin\n";
        $test_mod_gen .= "                                 if (update_enable == 1) port_break[port_index] = 1;\n";
        $test_mod_gen .= "                               end\n";
        $test_mod_gen .= "                             end\n";
        $test_mod_gen .= "                             if (loop_cnt_ctrl[i1] == 1 && update_enable == 1) begin\n";
        $test_mod_gen .= "                               port_loop_cnt[port_index] = port_loop_cnt[port_index] + 1;\n";
        $test_mod_gen .= "                             end\n";
        $test_mod_gen .= "                           end\n";
      }
      $test_mod_gen .= "            EXP_RISING   : begin\n";
      $test_mod_gen .= "                             if(port_type[port_index] == NORMAL_PORT_TYPE) begin // normal port\n";
      $test_mod_gen .= "                               temp_port_reg[port_index] = 1'b0;\n";
      $test_mod_gen .= "                               rising_enb[port_index] = 1;\n";
      $test_mod_gen .= "                             end\n";
      $test_mod_gen .= "                             if (update_enable == 1) port_break[port_index] = 1;\n";
      $test_mod_gen .= "                           end\n";
      $test_mod_gen .= "            EXP_FALLING  : begin\n";
      $test_mod_gen .= "                             if(port_type[port_index] == NORMAL_PORT_TYPE) begin // normal port\n";
      $test_mod_gen .= "                               temp_port_reg[port_index] = 1'b1;\n";
      $test_mod_gen .= "                               falling_enb[port_index] = 1;\n";
      $test_mod_gen .= "                             end\n";
      $test_mod_gen .= "                             if (update_enable == 1) port_break[port_index] = 1;\n";
      $test_mod_gen .= "                           end\n";
      $test_mod_gen .= "            default      : begin\n";
      $test_mod_gen .= "                             if(port_type[port_index] == NORMAL_PORT_TYPE) begin // normal port\n";
      $test_mod_gen .= "                               temp_port_reg[port_index] = b_it[normal_port_val[port_index]];\n";
      $test_mod_gen .= "                             end\n";
      $test_mod_gen .= "                             if (update_enable == 1) port_break[port_index] = 1;\n";
      $test_mod_gen .= "                           end\n";
      $test_mod_gen .= "          endcase\n";
      $test_mod_gen .= "        end else begin \n";
      $test_mod_gen .= "          port_break[port_index] = 1;\n";
      $test_mod_gen .= "        end\n";
      $test_mod_gen .= "      end // end for\n";
      if ($msg_col != -1){
        for (my $i=4;$i<scalar(@table);$i++){
          my $cond="";
          my $pattern = "";
          for (my $j=2;$j<scalar(@{$table[0]});$j++){
            if ($port_index_ref[$j] eq "-1"){
              next;
            }
            my $tmp_cond = "";
            my $prefix = "";
            my $cell = $table[$i][$j];
            my $edge_cond = "";
            if ($cell =~ /^_/) {
              if ($port_type_ref[$j] eq 1){ # real port
                $pattern=$pattern."(.)";
              }else{
                $pattern=$pattern.".";
              }
              $tmp_cond = "(port_en[$port_index_ref[$j]] == 0)" if ($port_ref_table[4][$j] eq "2");
            }else{
              if ($check_edge_cond eq "1") {
                if ($cell =~ /^RISE$/i) {
                  $edge_cond = "(port_rising_enb[$port_index_ref[$j]] === 1'b1)&&(port_falling_enb[$port_index_ref[$j]] === 1'b0)&&";
                } elsif ($cell =~ /^FALL$/i){
                  $edge_cond = "(port_rising_enb[$port_index_ref[$j]] === 1'b0)&&(port_falling_enb[$port_index_ref[$j]] === 1'b1)&&";
                } else {
                  $edge_cond = "(port_rising_enb[$port_index_ref[$j]] === 1'b0)&&(port_falling_enb[$port_index_ref[$j]] === 1'b0)&&";
                }
              }
              if ($cell =~ /ramp.*/){
                my $exp = $cell;
                $exp =~ s/^.*\(//;
                $exp =~ s/\).*$//;
                my ($min,$max,$def_step)=split(/,/,$exp);
                $tmp_cond = "((temp_real_reg[$port_index_ref[$j]].r >= $min)&&(temp_real_reg[$port_index_ref[$j]].r <= $max))";
                $pattern=$pattern."($min,$max,$def_step)";
              }elsif ($cell =~ /^\*$/) { # don't check condition for dont_care value
                if ($port_type_ref[$j] eq 1){ # real port
                  $pattern=$pattern."(*)";
                }else{
                  $pattern=$pattern."*";
                }
              }elsif (($cell =~ /^-$/) || ($cell =~ /^S$/i)){
                if ($port_type_ref[$j] eq 1){ # real port
                  my ($min,$max,$def_step)=split(/,/,$port_ref_table[6][$j]);
                  $tmp_cond = "((temp_real_reg[$port_index_ref[$j]] === $min) || (temp_real_reg[$port_index_ref[$j]] === $max)";
                  if ($port_ref_table[5][$j] eq "3"){
                    $tmp_cond = $tmp_cond."||($port_ref_table[7][$j] === `wrealXState)";
                  }elsif ($port_ref_table[5][$j] eq "4"){
                    $tmp_cond = $tmp_cond."||($port_ref_table[7][$j] === `wrealXState)||($port_ref_table[7][$j] === `wrealZState)";
                  }
                  $tmp_cond =$tmp_cond.")";
                  $pattern=$pattern."(".uc($cell).")";
                }else{
                  $tmp_cond = "((temp_port_reg[$port_index_ref[$j]] === 1'b0) || (temp_port_reg[$port_index_ref[$j]] === 1'b1))";
                  $pattern=$pattern.uc($cell);
                }
              }elsif ($cell =~ /^RISE$/i){
                $pattern=$pattern."R";
                $tmp_cond = "(port_test_type[$port_index_ref[$j]] == EXP_RISING)";
              }elsif ($cell =~ /^FALL$/i){
                $pattern=$pattern."F";
                $tmp_cond = "(port_test_type[$port_index_ref[$j]] == EXP_FALLING)";
              }elsif ($cell =~ /^EXP_NOT_/i){
                my $val = $cell;
                $val =~ s/EXP_NOT_//;
                $val =~ s/_.*$//;
                $pattern=$pattern."!$val";
                $tmp_cond = "(temp_port_reg[$port_index_ref[$j]] !== 1'b$val)";
              }else{
                if($table[0][$j] ne "reg"){
                  if ($port_type_ref[$j] eq 1){ # real port
                    if ($cell =~ /x/i){
                      $pattern=$pattern."(x)";
                      $tmp_cond = "(temp_real_reg[$port_index_ref[$j]].r === `wrealXState)";
                    }elsif ($cell =~ /z/i){
                      $pattern=$pattern."(z)";
                      $tmp_cond = "(temp_real_reg[$port_index_ref[$j]].r === `wrealZState)";
                    }else{
                      my $val = format_real_num($cell,$fix_num);
                      $pattern=$pattern."($val)";
                      $tmp_cond = "(temp_real_reg[$port_index_ref[$j]].r > ($val-delta))&&(temp_real_reg[$port_index_ref[$j]].r < ($val+delta))";
                    }
                  }else{ #normal port
                    $pattern=$pattern."$cell";
                    if ($cell =~ /x/i){
                      $tmp_cond = "(temp_port_reg[$port_index_ref[$j]] === 1'bx)";
                    }elsif ($cell =~ /z/i){
                      $tmp_cond = "(temp_port_reg[$port_index_ref[$j]] === 1'bz)";
                    }else{
                      $tmp_cond = "(temp_port_reg[$port_index_ref[$j]] === $cell)";
                    }
                  }
                }else{
                  $pattern=$pattern."$cell";
                  if ($cell =~ /x/i){
                    $tmp_cond = "(temp_port_reg[$port_index_ref[$j]] === 1'bx)";
                  }elsif ($cell =~ /z/i){
                    $tmp_cond = "(temp_port_reg[$port_index_ref[$j]] === 1'bz)";
                  }else{
                    $tmp_cond = "(temp_port_reg[$port_index_ref[$j]] === $cell)";
                  }
                }
              }
              if ($tmp_cond ne ""){
                $tmp_cond = $tmp_cond."&&(port_en[$port_index_ref[$j]] == 1)" if ($port_ref_table[4][$j] eq "2");
              }else{
                $tmp_cond = "(port_en[$port_index_ref[$j]] == 1)" if ($port_ref_table[4][$j] eq "2");
              }
            }
            if ($cond eq ""){
              $cond = $edge_cond.$tmp_cond;
            }else{
              $cond = $cond."&&".$edge_cond.$tmp_cond  if ($tmp_cond ne "");
            }
          }
          $cond = "1" if ($cond eq "");
          print($TB "                            if ($cond) begin\n");
          print($TB "                              \$display(\"MSG   ::: [$pattern]\");");
          print($TB "\n                            end\n");
        }
      }
      if ($bract != 0 || $string_reg !=0){
        for (my $i=4;$i<scalar(@table);$i++){
          if ($org_table[$i][$bract] eq "-"){
            next;
          }
          my $cond="";
          my $pattern = "";
          for (my $j=2;$j<scalar(@{$table[0]});$j++){
            if ($port_index_ref[$j] eq "-1"){
              next;
            }
            my $tmp_cond = "";
            my $prefix = "";
            my $cell = $table[$i][$j];
            $cell =~ s/^_//;
            my $edge_cond = "";
            if ($check_edge_cond eq "1") {
              if ($cell =~ /^RISE$/i) {
                $edge_cond = "(port_rising_enb[$port_index_ref[$j]] === 1'b1)&&(port_falling_enb[$port_index_ref[$j]] === 1'b0)&&";
              } elsif ($cell =~ /^FALL$/i){
                $edge_cond = "(port_rising_enb[$port_index_ref[$j]] === 1'b0)&&(port_falling_enb[$port_index_ref[$j]] === 1'b1)&&";
              } else {
                $edge_cond = "(port_rising_enb[$port_index_ref[$j]] === 1'b0)&&(port_falling_enb[$port_index_ref[$j]] === 1'b0)&&";
              }
            }
            if ($cell =~ /ramp.*/){
              my $exp = $cell;
              $exp =~ s/^.*\(//;
              $exp =~ s/\).*$//;
              my ($min, $max, $def_step)=split(",",$exp);
              $tmp_cond = "(port_test_type[$port_index_ref[$j]] == RAMP_TYPE) && (real_port_val[$port_index_ref[$j]].r > $min)&&(real_port_val[$port_index_ref[$j]].r < $max)";
              $pattern=$pattern."($min,$max,$def_step)";
            }elsif ($cell =~ /^-$/){
              $tmp_cond = "(port_test_type[$port_index_ref[$j]] == CROSS_TYPE)";
              if ($port_type_ref[$j] eq 1){ # real port
                $pattern=$pattern."(-)";
              }else{
                $pattern=$pattern."-";
              }
            }elsif ($cell =~ /^S$/i){
              $tmp_cond = "(port_test_type[$port_index_ref[$j]] == S_TYPE)";
              if ($port_type_ref[$j] eq 1){ # real port
                $pattern=$pattern."(S)";
              }else{
                $pattern=$pattern."S";
              }
            }elsif ($cell =~ /^FALL$/i){
              $tmp_cond = "(port_test_type[$port_index_ref[$j]] == EXP_FALLING)";
              $pattern=$pattern."F";
            }elsif ($cell =~ /^RISE$/i){
              $tmp_cond = "(port_test_type[$port_index_ref[$j]] == EXP_RISING)";
              $pattern=$pattern."R";
            }elsif ($cell =~ /^EXP_NOT_/i){
              $tmp_cond = "(port_test_type[$port_index_ref[$j]] == $cell)";
              my $val = $cell;
              $val =~ s/EXP_NOT_//;
              $val =~ s/_.*$//;
              $pattern=$pattern."!$val";
            }else{
              if($table[0][$j] ne "reg"){
                if ($port_type_ref[$j] eq 1){ # real port
                  if ($cell =~ /x/i){
                    $pattern=$pattern."(x)";
                    $tmp_cond = "(real_port_val[$port_index_ref[$j]].r === `wrealXState)";
                  }elsif ($cell =~ /z/i){
                    $pattern=$pattern."(z)";
                    $tmp_cond = "(real_port_val[$port_index_ref[$j]].r === `wrealZState)";
                  }else{
                    my $val = format_real_num($cell,$fix_num);
                    $pattern=$pattern."($val)";
                    $tmp_cond = "(real_port_val[$port_index_ref[$j]].r > ($val-delta))&&(real_port_val[$port_index_ref[$j]].r < ($val+delta))";
                  }
                }else{ #normal port
                  $pattern=$pattern."$cell";
                  if ($cell =~ /x/i){
                    $tmp_cond = "(normal_port_val[$port_index_ref[$j]] == 2)";
                  }elsif ($cell =~ /z/i){
                    $tmp_cond = "(normal_port_val[$port_index_ref[$j]] == 3)";
                  }else{
                    $tmp_cond = "(normal_port_val[$port_index_ref[$j]] == $cell)";
                  }
                }
              }else{
                $pattern=$pattern."$cell";
                if ($cell =~ /x/i){
                  $tmp_cond = "(normal_port_val[$port_index_ref[$j]] == 2)";
                }elsif ($cell =~ /z/i){
                  $tmp_cond = "(normal_port_val[$port_index_ref[$j]] == 3)";
                }else{
                  $tmp_cond = "(normal_port_val[$port_index_ref[$j]] == $cell)";
                }
              }
            }
            $tmp_cond = $tmp_cond."&&(port_en[$port_index_ref[$j]] == 0)" if ($table[$i][$j] =~ /^_/);
            next if ($cell =~ /\*/); # don't check condition for dont_care value
            if ($cond eq ""){
              $cond = $edge_cond.$tmp_cond; 
            }else{
              $cond = $cond."&&".$edge_cond.$tmp_cond;
            }
          }
          $cond = "1" if ($cond eq "");
          print($TB "                            // INPUT ::: [$pattern]\n");
          print($TB "                            if ($cond) begin\n");
          if ($string_reg != 0){
                  print($TB "                              $org_table[2][$string_reg] = \"$org_table[$i][$string_reg]\";\n");
          }
          if($bract != 0){
              if ($org_table[$i][$bract] ne "-"){
                  my @split_line = split(/\n/,$org_table[$i][$bract]);
                  print($TB "                              ",join("\n                              ",@split_line));
              }
          }
          print($TB "\n                            end\n");
        }
      }
      for (my $i=0;$i<scalar(@osc_cond);$i++){
        print($TB "                            $osc_cond[$i]\_osc_chk_ctrl = 1;\n");
      }
      print($TB "                            for (i1=PORT_NUM-1;i1>=0;i1--) begin\n");
      print($TB "                              port_index = (mem[index] >> (16*i1))&16'hFFFF;\n");
      print($TB "                              #(port_delay[port_index]);\n");
      my $pt = "";
      if ($in_out_seq eq "1"){
        print($TB "                              port_index_tmp = port_index;\n");
        @dup_check=();
        for (my $i=1;$i<scalar(@outseq);$i++){
          my ($cond_name,$out_name,$port_ref_num,$in_port_name,$out_port_name,@input_port_ref_num)=get_port_timing_info($outseq[$i][2],$outseq[$i][3],@port_ref_table);
          my $tmp = "";
          if (scalar(@input_port_ref_num) > 1){
            foreach my $num(@input_port_ref_num){
              $tmp = $tmp."(port_index == $num) || ";
            }
            $tmp =~ s/ \|\| $//;
            print($TB "                              if ($tmp) port_index_tmp = $port_ref_num;\n");
          }
        }
        for (my $i=1;$i<scalar(@outseq);$i++){
          my ($cond_name,$out_name,$port_ref_num,$in_port_name,$out_port_name,@input_port_ref_num)=get_port_timing_info($outseq[$i][2],$outseq[$i][3],@port_ref_table);
          next if(grep (/^\Q$out_name\E$/,@dup_check) > 0);
          push(@dup_check,"$out_name");
          if (exists $hash_in_out{"$out_name"}){
            print($TB "                              $out_name\_update_flag[port_index_tmp] = 0;\n");
            print($TB "                              $out_name\_input_update_time[port_index_tmp] = \$time;\n");
            print($TB "                              $out_name\_input_update_ctrl[port_index] = 0;\n");
            $pt = $pt."                                    $out_name\_input_update_ctrl[port_index_tmp] = 1;\n";
          }
        }
      }
      print($TB "                              port_dir[port_index] = port_en[port_index];\n");
      print($TB "                              if(port_en[port_index] == PORT_ENABLED) begin\n");
      print($TB "                                if(port_type[port_index] == NORMAL_PORT_TYPE) begin // normal port\n");
      if ($in_out_seq eq "1"){
        print($TB "                                  if(port_reg[port_index] !== temp_port_reg[port_index]) begin\n$pt");
        print($TB "                                  end\n");
      }
      print($TB "                                  port_reg[port_index] = temp_port_reg[port_index];\n");
      print($TB "                                  if ((port_rising_enb[port_index] == 1) || (port_falling_enb[port_index] == 1)) update_input_port[port_index]++;\n");
      if($rnm == 1){
        print($TB "                                end else begin\n");
        if ($in_out_seq eq "1"){
          print($TB "                                  if(real_reg[port_index] !== temp_real_reg[port_index]) begin\n$pt");
          print($TB "                                  end\n");
        }
        print($TB "                                  real_reg[port_index] = temp_real_reg[port_index];\n");
      }
      print($TB "                                end\n");
      print($TB "                              end\n");
      print($TB "                            end\n");
      if($is_fb_on == 1){
        print($TB "                           update_fb <= ~update_fb;\n");
      }
      if ($aract != 0 || $string_reg !=0){
        for (my $i=4;$i<scalar(@table);$i++){
          if ($org_table[$i][$aract] eq "-"){
            next;
          }
          my $cond="";
          my $pattern = "";
          for (my $j=2;$j<scalar(@{$table[0]});$j++){
            if ($port_index_ref[$j] eq "-1" && $table[0][$j] ne "reg"){
              next;
            }
            my $tmp_cond = "";
            my $prefix = "";
            my $cell = $table[$i][$j];
            $cell =~ s/^_//;
            my $edge_cond = "";
            if ($check_edge_cond eq "1") {
              if ($cell =~ /^RISE$/i) {
                $edge_cond = "(port_rising_enb[$port_index_ref[$j]] === 1'b1)&&(port_falling_enb[$port_index_ref[$j]] === 1'b0)&&";
              } elsif ($cell =~ /^FALL$/i){
                $edge_cond = "(port_rising_enb[$port_index_ref[$j]] === 1'b0)&&(port_falling_enb[$port_index_ref[$j]] === 1'b1)&&";
              } else {
                $edge_cond = "(port_rising_enb[$port_index_ref[$j]] === 1'b0)&&(port_falling_enb[$port_index_ref[$j]] === 1'b0)&&";
              }
            }
            if ($cell =~ /ramp.*/){
              my $exp = $cell;
              $exp =~ s/^.*\(//;
              $exp =~ s/\).*$//;
              my ($min, $max, $def_step)=split(",",$exp);
              $tmp_cond = "(port_test_type[$port_index_ref[$j]] == RAMP_TYPE) && (real_port_val[$port_index_ref[$j]].r > $min)&&(real_port_val[$port_index_ref[$j]].r < $max)";
              $pattern=$pattern."($min,$max,$def_step)";
            }elsif ($cell =~ /^-$/){
              $tmp_cond = "(port_test_type[$port_index_ref[$j]] == CROSS_TYPE)";
              if ($port_type_ref[$j] eq 1){ # real port
                $pattern=$pattern."(-)";
              }else{
                $pattern=$pattern."-";
              }
            }elsif ($cell =~ /^EXP_NOT_/i){
              $tmp_cond = "(port_test_type[$port_index_ref[$j]] == $cell)";
              my $val = $cell;
              $val =~ s/EXP_NOT_//;
              $val =~ s/_.*$//;
              $pattern=$pattern."!$val";
            }elsif ($cell =~ /^S$/i){
              $tmp_cond = "(port_test_type[$port_index_ref[$j]] == S_TYPE)";
              if ($port_type_ref[$j] eq 1){ # real port
                $pattern=$pattern."(S)";
              }else{
                $pattern=$pattern."S";
              }
            }elsif ($cell =~ /^FALL$/i){
              $tmp_cond = "(port_test_type[$port_index_ref[$j]] == EXP_FALLING)";
              $pattern=$pattern."F";
            }elsif ($cell =~ /^RISE$/i){
              $tmp_cond = "(port_test_type[$port_index_ref[$j]] == EXP_RISING)";
              $pattern=$pattern."R";
            }else{
              if($table[0][$j] ne "reg"){
                if ($port_type_ref[$j] eq 1){ # real port
                  $pattern=$pattern."($cell)";
                  if ($cell =~ /x/i){
                    $tmp_cond = "(real_port_val[$port_index_ref[$j]].r === `wrealXState)";
                  }elsif ($cell =~ /z/i){
                    $tmp_cond = "(real_port_val[$port_index_ref[$j]].r === `wrealZState)";
                  }else{
                    $tmp_cond = "(real_port_val[$port_index_ref[$j]].r > ($cell-delta))&&(real_port_val[$port_index_ref[$j]].r < ($cell+delta))";
                  }
                }else{ #normal port
                  $pattern=$pattern."$cell";
                  if ($cell =~ /x/i){
                    $tmp_cond = "(normal_port_val[$port_index_ref[$j]] == 2)";
                  }elsif ($cell =~ /z/i){
                    $tmp_cond = "(normal_port_val[$port_index_ref[$j]] == 3)";
                  }else{
                    $tmp_cond = "(normal_port_val[$port_index_ref[$j]] === $cell)";
                  }
                }
              }else{
                $pattern=$pattern.$cell;
                if ($cell =~ /x/i){
                  $tmp_cond = "(normal_port_val[$port_index_ref[$j]] == 2)";
                }elsif ($cell =~ /z/i){
                  $tmp_cond = "(normal_port_val[$port_index_ref[$j]] == 3)";
                }else{
                  $tmp_cond = "(normal_port_val[$port_index_ref[$j]] === $cell)";
                }
              }
            }
            $tmp_cond = $tmp_cond."&&(port_en[$port_index_ref[$j]] == 0)" if ($table[$i][$j] =~ /^_/);
            next if ($cell =~ /\*/); # don't check condition for dont_care value
            if ($cond eq ""){
              $cond = $edge_cond.$tmp_cond; 
            }else{
              $cond = $cond."&&".$edge_cond.$tmp_cond;
            }
          }
          $cond = "1" if ($cond eq "");
          print($TB "                            // INPUT ::: [$pattern]\n");
          print($TB "                            if ($cond) begin\n");
          if ($string_reg != 0){
                  print($TB "                              $org_table[2][$string_reg] = \"$org_table[$i][$string_reg]\";\n");
          }
          if($aract != 0){
              if ($org_table[$i][$aract] ne "-"){
                  my @split_line = split(/\n/,$org_table[$i][$aract]);
                  print($TB "                              ",join("\n                              ",@split_line));
              }
          }
          print($TB "\n                            end\n");

        }
      }
      print($TB "                            erks_rst_freq = 1;\n");
      print($TB "                            #(DELAY-1)\n");
      print($TB "                            \$display(\"INPUT ::: [\%s] $port_val_ref\",pattern,$port_name_list);\n");
      print($TB "                            i0=i0+1;\n");
      print($TB "                            #1;\n");
      print($TB "                            for (i1=0;i1<PORT_NUM;i1++) begin\n");
      print($TB "                              port_falling_enb[i1] = 0;\n");
      print($TB "                              port_rising_enb[i1] = 0;\n");
      print($TB "                            end;\n");
      $test_mod_gen .= "      next_flag = 1;\n";
      $test_mod_gen .= "      for (i1=PORT_NUM-1;i1>=0;i1--) begin\n";
      $test_mod_gen .= "        next_flag = next_flag&port_break[i1];\n";
      $test_mod_gen .= "      end\n";
      $test_mod_gen .= "      if (next_flag == 1) begin\n";
      $test_mod_gen .= "        loop_cont=0;\n";
      $test_mod_gen .= "      end else begin\n";
      $test_mod_gen .= "        loop_cont=1;\n";
      $test_mod_gen .= "        disable_cnt=0;\n";
      $test_mod_gen .= "        for (i1=PORT_NUM-1;i1>=0;i1--) begin\n";
      $test_mod_gen .= "          next_flag = 1;\n";
      $test_mod_gen .= "          for (i2=PORT_NUM-1;i2>=0;i2--) begin\n";
      $test_mod_gen .= "            if (i2 >= i1) begin\n";
      $test_mod_gen .= "              next_flag = next_flag&port_break[i2];\n";
      $test_mod_gen .= "            end\n";
      $test_mod_gen .= "          end\n";
      $test_mod_gen .= "          if (port_break[i1] == 1) begin\n";
      $test_mod_gen .= "            if(next_flag == 1) begin\n";
      $test_mod_gen .= "              begin: block_process_loop_ctrl\n";
      $test_mod_gen .= "              begin: block_check_next_port\n";
      $test_mod_gen .= "              for (i2=i1-1;i2>=0;i2--) begin\n";
      $test_mod_gen .= "                if (port_break[i2] == 1) begin\n";
      $test_mod_gen .= "                  disable block_process_loop_ctrl;\n";
      $test_mod_gen .= "                end else begin\n";
      $test_mod_gen .= "                  if (i1 == PORT_NUM - 1) begin\n";
      $test_mod_gen .= "                    disable_cnt = 1;\n";
      $test_mod_gen .= "                  end\n";
      $test_mod_gen .= "                  disable block_check_next_port;\n";
      $test_mod_gen .= "                end\n";
      $test_mod_gen .= "              end\n";
      $test_mod_gen .= "              end\n";
      $test_mod_gen .= "              for (i2=PORT_NUM-1;i2>=i1;i2--) begin\n";
      $test_mod_gen .= "                port_loop_cnt[i2] = 0;\n";
      $test_mod_gen .= "                port_break[i2] = 0;\n";
      $test_mod_gen .= "              end\n";
      $test_mod_gen .= "              for (i2=i1;i2>=0;i2--) begin\n";
      $test_mod_gen .= "                loop_cnt_ctrl[i2] = 0;\n";
      $test_mod_gen .= "              end\n";
      $test_mod_gen .= "              loop_cnt_ctrl[PORT_NUM-1] = 1;\n";
      $test_mod_gen .= "              port_loop_cnt[i1-1]++;\n";
      $test_mod_gen .= "              end\n";
      $test_mod_gen .= "            end else begin\n";
      $test_mod_gen .= "              if (loop_cnt_ctrl[PORT_NUM-1] == 0 && disable_cnt == 0) begin\n";
      $test_mod_gen .= "                port_loop_cnt[PORT_NUM-1]++;\n";
      $test_mod_gen .= "              end\n";
      $test_mod_gen .= "              for (i2=PORT_NUM-1;i2>=0;i2--) begin\n";
      $test_mod_gen .= "                loop_cnt_ctrl[i2] = 0;\n";
      $test_mod_gen .= "              end\n";
      $test_mod_gen .= "              port_break[PORT_NUM-1] = 0;\n";
      $test_mod_gen .= "              loop_cnt_ctrl[PORT_NUM-1] = 1;\n";
      $test_mod_gen .= "            end\n";
      $test_mod_gen .= "          end\n";
      $test_mod_gen .= "        end\n";
      $test_mod_gen .= "      end\n";
      print($TB "                            if (state == LOAD_MODE) begin\n");
      print($TB "                              if (index != (size - 1)) begin\n");
      print($TB "                                disable test_generate_block;\n");
      print($TB "                              end\n");
      print($TB "                            end else if (state == EXEC_PRE_MODE) begin\n");
      print($TB "                              if (test_gen_finish[TEST_GEN] == 1) begin\n");
      print($TB "                                if (index == (size - 1)) begin // last test vector is mode\n");
      print($TB "                                  state = EXEC_TEST_VECTOR; // state is changed into EXEC_TEST_VECTOR in case last test vector\n");
      print($TB "                                  erks_rst[TEST_GEN] = 0;\n");
      print($TB "                                  #1\n");
      print($TB "                                  erks_rst[TEST_GEN] = 1;\n");
      print($TB "                                  // Update clock value\n");
      for (my $i=0;$i<$num_of_clock_change;$i++) {
        print($TB "                                  $clock_change[$i] = $clock_change[$i]_pre;\n");
        print($TB "                                  $clock_change[$i]_clk_value = $clock_change[$i]_clk_value_pre;\n");
        print($TB "                                  $clock_change[$i]\_clk_period = $clock_change[$i]_clk_period_pre;\n");
      }
      if($pulse_width_col==1){
        print($TB "                                  high_pulse_width = high_pulse_width_pre;\n");
      }
      print($TB "                                  // Enable test generator\n");
      print($TB "                                  enable[TEST_GEN] = 1; // Enable for test generator\n");
      print($TB "                                  update_enable[TEST_GEN] = 1; // test vector generate is not enabled for loading\n");
      print($TB "                                  // test vector in mode is loaded into test generator\n");
      print($TB "                                  test_pattern_str = mode_pattern_str;       // last pattern is updated\n");
      print($TB "                                  port_index_mem[TEST_GEN] = port_index_mem[MODE_GEN];\n");
      if ($rnm == 1){
        print($TB "                                  update_test_vector(mode_port_en,mode_port_test_type,mode_port_type,mode_port_care_range,mode_normal_port_val,mode_port_delay,mode_real_port_val,mode_real_port_def_step,mode_real_port_max_real,\n");
        print($TB "                                                     test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay,test_real_port_val,test_real_port_def_step,test_real_port_max_real);\n");
      } else {
        print($TB "                                  update_test_vector(mode_port_en,mode_port_test_type,mode_port_type,mode_port_care_range,mode_normal_port_val,mode_port_delay,\n");
        print($TB "                                                     test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay);\n");
      }
      print($TB "                                end else begin\n");
      print($TB "                                  enable[TEST_GEN] = 0;\n");
      print($TB "                                  update_enable[TEST_GEN] = 0;\n");
      print($TB "                                  state = LOAD_MODE; // state is changed into LOAD_MODE after previous mode finish\n");
      print($TB "                                end\n");
      print($TB "                                enable[MODE_GEN] = 0;\n");
      print($TB "                                update_enable[MODE_GEN] = 0;\n");
      print($TB "                              end\n");
      print($TB  "                            end else if (state == EXEC_MODE) begin\n");
#      print($TB  "                              // Disable mode gen\n"); #revise Feb16
#      print($TB  "                              enable[MODE_GEN] = 1;\n"); #revise Feb16
#      print($TB  "                              update_enable[MODE_GEN] = 1;\n");
      if($max_sub_mode_num > 0){
        print($TB  "                              // Enable sub mode gen\n");
        print($TB  "                              state = EXEC_SUB_MODE;\n");
        print($TB  "                              enable[SUB_MODE0_GEN] = 1;\n");
#      print($TB  "                              if (sub_mode_num == 1) update_enable[SUB_MODE0_GEN] = 1;\n"); #revise Feb16
        print($TB  "                              update_enable[SUB_MODE0_GEN] = 1;\n");
        print($TB  "                              sub_mode_index = 0;\n");
        print($TB  "                            end else if (state == EXEC_SUB_MODE) begin\n");
        print($TB  "                              // Disable current sub mode generator\n");
        print($TB  "                              enable[`CUR_SUB_MODE_GEN] = 0;\n");
        print($TB  "                              update_enable[`CUR_SUB_MODE_GEN] = 0;                           \n");
        print($TB  "                              if (sub_mode_num == sub_mode_index+1) begin\n");
        print($TB  "                                // Check sub mode finish\n");
        print($TB  "                                sub_mode_finish = test_gen_finish[`CUR_SUB_MODE_GEN];\n");
        print($TB  "                                if (sub_mode_finish) begin\n");
        print($TB  "                                  begin: check_sub_mode_finish_block\n");
        print($TB  "                                    for (i3=1;i3<sub_mode_num-1;i3++) begin\n");
        print($TB  "                                      enable[`CUR_SUB_MODE_GEN-i3] = 1;\n");
        print($TB  "                                      update_enable[`CUR_SUB_MODE_GEN-i3] = 1;\n");
        print($TB  "                                      test_gen_trigger[`CUR_SUB_MODE_GEN-i3] = ~test_gen_trigger[`CUR_SUB_MODE_GEN-i3];\n");
        print($TB  "                                      #1;\n");
        print($TB  "                                      enable[`CUR_SUB_MODE_GEN-i3] = 0;\n");
        print($TB  "                                      update_enable[`CUR_SUB_MODE_GEN-i3] = 0;\n");
        print($TB  "                                      sub_mode_finish &= test_gen_finish[`CUR_SUB_MODE_GEN-i3];\n");
        print($TB  "                                      if (!sub_mode_finish) begin\n");
        print($TB  "                                        disable check_sub_mode_finish_block;\n");
        print($TB  "                                      end else begin\n");
        print($TB  "                                        // Reset finish sub mode gen\n");
        print($TB  "                                        erks_rst[`CUR_SUB_MODE_GEN-i3] = 0;\n");
        print($TB  "                                        #1;\n");
        print($TB  "                                        erks_rst[`CUR_SUB_MODE_GEN-i3] = 1;\n");
        print($TB  "                                      end\n");
        print($TB  "                                    end\n");
        print($TB  "                                  end\n");
        print($TB  "                                  // Check main mode finish\n");
        print($TB  "                                  if (sub_mode_finish) begin\n");
#      print($TB  "                                    enable[MODE_GEN] = 1;\n");
#      print($TB  "                                    update_enable[MODE_GEN] = 1;\n");
#      print($TB  "                                    test_gen_trigger[MODE_GEN] = ~test_gen_trigger[MODE_GEN];\n");
#      print($TB  "                                    #1;\n");
        print($TB  "                                    enable[MODE_GEN] = 0;\n");
        print($TB  "                                    update_enable[MODE_GEN] = 0;\n");
        print($TB  "                                    if (test_gen_finish[MODE_GEN]) begin\n");
        print($TB  "                                      //state = LOAD_MODE;\n");
        print($TB  "                                      state = INITIAL;\n");
        print($TB  "                                      disable test_generate_block;\n");
        print($TB  "                                    end else begin\n");
        print($TB  "          		               // Reset last sub mode gen\n");
        print($TB  "          		                erks_rst[`CUR_SUB_MODE_GEN] = 0;\n");
        print($TB  "          		                #1;\n");
        print($TB  "          		                erks_rst[`CUR_SUB_MODE_GEN] = 1;\n");
        print($TB  "                                      state = EXEC_MODE;\n");
        print($TB  "                                      enable[MODE_GEN] = 1;\n");
        print($TB  "                                      update_enable[MODE_GEN] = 1;\n");
        print($TB  "                                    end\n");
        print($TB  "                                  end else begin\n");
        print($TB  "          		              // Reset last sub mode gen\n");
        print($TB  "          		           	erks_rst[`CUR_SUB_MODE_GEN] = 0;\n");
        print($TB  "          		           	#1;\n");
        print($TB  "          		           	erks_rst[`CUR_SUB_MODE_GEN] = 1;\n");
        print($TB  "                                    // Enable main mode gen\n");
        print($TB  "                                    state = EXEC_MODE;\n");
        print($TB  "                                    enable[MODE_GEN] = 1;\n");
        print($TB  "                                    update_enable[MODE_GEN] = 1;\n");
        print($TB  "                                  end\n");
        print($TB  " 			          end else begin\n");
        print($TB  "                                   // Enable main mode gen\n");
        print($TB  "   		                     state = EXEC_MODE;\n");
        print($TB  "                                   enable[MODE_GEN] = 0;\n");
        print($TB  "                                   update_enable[MODE_GEN] = 0;\n");
        print($TB  "                                   enable[`CUR_SUB_MODE_GEN] = 1;\n");
        print($TB  "                                   update_enable[`CUR_SUB_MODE_GEN] = 1;\n"); 
        print($TB  "                                end // sub_mode_finish\n");
        print($TB  "                              end else begin // sub_mode_num != sub_mode_index+1\n");
        print($TB  "                                // Enable next sub mode gen\n");
        print($TB  "                                state = EXEC_SUB_MODE;\n");
        print($TB  "                                enable[`CUR_SUB_MODE_GEN+1] = 1;\n");
#      print($TB  "                                if (sub_mode_num == sub_mode_index+2) update_enable[`CUR_SUB_MODE_GEN+1] = 1;\n");
#      print($TB  "                                else                                  update_enable[`CUR_SUB_MODE_GEN+1] = 0;\n");
        print($TB  "                                update_enable[`CUR_SUB_MODE_GEN+1] = 1;\n"); #revise Feb16
        print($TB  "                                sub_mode_index++;\n");
        print($TB  "                                end\n");
      }
       print($TB  "                            end else if (state == MODE_SET_VALUE) begin\n");
      if($lfo == 1){
        print($TB "                                if(force_start==1) begin\n");
        print($TB "                                  state = HOLD_FORCE;\n");
        print($TB "                                end else begin;\n");
        print($TB "                                  state = MODE_HOLD_START;\n");
        print($TB "                                end\n");
        print($TB "                            end else if (state == HOLD_FORCE) begin\n");
        print($TB "                            for(force_index=0;force_index<".scalar(@force_num_pat).";force_index++) begin\n");
        print($TB "                              if(force_finish[force_index] != 1) begin\n");
        print($TB "                                state = force_state[force_index];\n");
        print($TB "                                break;\n");
        print($TB "                              end\n");
        print($TB "                            end\n");
      }else{
        print($TB "                              state = MODE_HOLD_START;\n");
      }
      print($TB "                            end else if (state == MODE_HOLD_START) begin\n");
      print($TB "                              state = TEST_INPUT_CHANGE;\n");
      print($TB "                            end else if (state == TEST_INPUT_CHANGE) begin\n");
      print($TB "                              state = TEST_THROUGH;\n");
      print($TB "                            end else if (state == TEST_THROUGH) begin\n");
      print($TB "                              state = TEST_HOLD;\n");
      print($TB "                            end else if (state == TEST_HOLD) begin\n");
      print($TB "                              state = TEST_INPUT_CHANGE_SELF;\n");
      print($TB "                            end else if (state == TEST_INPUT_CHANGE_SELF) begin\n");
      print($TB "                              state = TEST_THROUGH_SELF;\n");
      print($TB "                            end else if (state == TEST_THROUGH_SELF) begin\n");
      print($TB "                              state = TEST_HOLD_SELF;\n");
      print($TB "                            end else if (state == TEST_HOLD_SELF) begin\n");
      print($TB "                              state = MODE_INPUT_CHANGE;\n");
      print($TB "                            end else if (state == MODE_INPUT_CHANGE) begin\n");
      print($TB "                              state = MODE_THROUGH;\n");
      print($TB "                            end else if (state == MODE_THROUGH) begin\n");
      print($TB "                              state = MODE_HOLD;\n");
      print($TB "                            end else if (state == MODE_HOLD) begin\n");
      print($TB "                              state = MODE_INPUT_CHANGE_SELF;\n");
      print($TB "                            end else if (state == MODE_INPUT_CHANGE_SELF) begin\n");
      print($TB "                              state = MODE_THROUGH_SELF;\n");
      print($TB "                            end else if (state == MODE_THROUGH_SELF) begin\n");
      print($TB "                              state = MODE_HOLD_SELF;\n");
      print($TB "                            end else if (state == MODE_HOLD_SELF) begin\n");
      print($TB "                              // Enable mode generator\n");
      print($TB "                              if (test_gen_finish[TEST_GEN] == 1) begin // last of test gen\n");
      print($TB "                                state = MODE_INPUT_CHANGE; // temporary transition\n");
      print($TB "                                update_enable[MODE_GEN] = 1; // Enable to change to next mode at the last vector of test gen\n");
      print($TB "                                test_gen_trigger[MODE_GEN] <= ~test_gen_trigger[MODE_GEN]; // generate temporary test vector\n");
      print($TB "                                if (test_output_loop_cnt == mode_output_loop_cnt) begin // last of mode gen\n");
      print($TB "                                  // Load mode again to mode generator \n");
      print($TB "                                  if (next_state == LOAD_MODE) begin\n");
      print($TB "                                    state = LOAD_MODE; // change to LOAD_MODE in case mode is already loaded\n");
      print($TB "                                    // test vector is loaded to mode generator from reserved\n");
      print($TB "                                    mode_pattern_str     = reserved_pattern_str;\n");
      print($TB "                                    port_index_mem[MODE_GEN] = port_index_mem[RESERVED];\n");
      if ($rnm == 1){
        print($TB "                                    update_test_vector(reserved_port_en,reserved_port_test_type,reserved_port_type,reserved_port_care_range,reserved_normal_port_val,reserved_port_delay,reserved_real_port_val,reserved_real_port_def_step,reserved_real_port_max_real,\n");
        print($TB "                                                           mode_port_en,    mode_port_test_type,    mode_port_type,    mode_port_care_range,    mode_normal_port_val,    mode_port_delay,    mode_real_port_val,    mode_real_port_def_step,    mode_real_port_max_real);\n");
      } else {
        print($TB "                                    update_test_vector(reserved_port_en,reserved_port_test_type,reserved_port_type,reserved_port_care_range,reserved_normal_port_val,reserved_port_delay,\n");
        print($TB "                                                           mode_port_en,    mode_port_test_type,    mode_port_type,    mode_port_care_range,    mode_normal_port_val,    mode_port_delay);\n");
      }
      print($TB "                                  end\n");
      print($TB "                                  #1\n");
      if($lfo eq "0"){
        print($TB "                                  // Stop generation\n");
        print($TB "                                  disable test_generate_block;\n");
      }else{
        print($TB "                                  erks_rst[TEST_GEN] = 0;\n");
        print($TB "                                  erks_rst[MODE_GEN] = 0;\n");
        print($TB "                                  #1\n");
        print($TB "                                  erks_rst[TEST_GEN] = 1;\n");
        print($TB "                                  erks_rst[MODE_GEN] = 1;\n");
        print($TB "                                  enable[MODE_GEN] = 1;\n");
        print($TB "                                  enable[TEST_GEN] = 1;\n");
        print($TB "                                  latch_enable[MODE_GEN] = 0;\n");
        print($TB "                                  latch_enable[TEST_GEN] = 1;\n");
        print($TB "                                  update_enable[MODE_GEN] = 1;\n");
        print($TB "                                  update_enable[TEST_GEN] = 1;\n");
        print($TB "                                  update_test_vector(     port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,\n");
        print($TB "                                                 test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay);\n");
        print($TB "                                  force_start = 1;\n");
        print($TB "                                  state = MODE_SET_VALUE;\n");
      }
      print($TB "                                end else begin\n");
      print($TB "                                  // Reset the test gen\n");
      print($TB "                                  erks_rst[TEST_GEN] = 0;\n");
      print($TB "                                  #1\n");
      print($TB "                                  erks_rst[TEST_GEN] = 1;\n");
      print($TB "                                  // Load current mode test vector into test gen and omit 1st time test vector\n");
      print($TB "                                  test_input_loop_cnt = mode_output_loop_cnt;\n");
      print($TB "                                end\n");
      print($TB "                                update_enable[MODE_GEN] = 0;\n");
      print($TB "                              end else begin\n");
      print($TB "                                state = TEST_INPUT_CHANGE;\n");
      print($TB "                              end\n");
      if($lfo eq "1"){
        if($no_back ne "1"){
          for(my $k=0;$k<scalar(@force_num_pat);$k++){
            print($TB "                            end else if (state == $force_num_pat[$k]) begin\n");
            print($TB "                               if (test_gen_finish[TEST_GEN] == 1) begin // last of test gen\n");
            print($TB "                                 force_finish[$k] = 1;\n");
            print($TB "                               end\n");
            print($TB "                               state = BACK_TO_HOLD;\n");
          }
          print($TB "                            end else if (state == BACK_TO_HOLD) begin\n");
          print($TB "                              for(force_index=0;force_index<".scalar(@force_num_pat).";force_index++) begin\n");
          print($TB "                                if(force_finish[force_index] != 1) begin\n");
          print($TB "                                  if (test_gen_finish[TEST_GEN] == 1) begin // last of test gen\n");
          print($TB "                                    erks_rst[TEST_GEN] = 0;\n");
          print($TB "                                    erks_rst[MODE_GEN] = 0;\n");
          print($TB "                                    #1\n");
          print($TB "                                    erks_rst[TEST_GEN] = 1;\n");
          print($TB "                                    erks_rst[MODE_GEN] = 1;\n");
          print($TB "                                    enable[MODE_GEN] = 1;\n");
          print($TB "                                    enable[TEST_GEN] = 1;\n");
          print($TB "                                    latch_enable[MODE_GEN] = 0;\n");
          print($TB "                                    latch_enable[TEST_GEN] = 1;\n");
          print($TB "                                    update_enable[MODE_GEN] = 1;\n");
          print($TB "                                    update_enable[TEST_GEN] = 1;\n");
          print($TB "                                    update_test_vector(     port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,\n");
          print($TB "                                                   test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay);\n");
          print($TB "                                  end\n");
          print($TB "                                  break;\n");
          print($TB "                                end\n");
          print($TB "                              end\n");
          printf($TB "                             if (force_index == %d) begin\n", scalar(@force_num_pat));
          print($TB "                                disable test_generate_block;\n");
          print($TB "                              end else begin\n");
          print($TB "                                state = MODE_SET_VALUE;\n");
          print($TB "                              end\n");
        }else{
          for(my $k=0;$k<scalar(@force_num_pat);$k++){
            print($TB "                            end else if (state == $force_num_pat[$k]) begin\n");
            if($k == scalar(@force_num_pat)-1){
              print($TB "                               if (test_gen_finish[TEST_GEN] == 1) begin // last of test gen\n");
              print($TB "                                 disable test_generate_block;\n");
              print($TB "                               end\n");
            }else{
              print($TB "                               if (test_gen_finish[TEST_GEN] == 1) begin // last of test gen\n");
              print($TB "                                 force_finish[$k] = 1;\n");
              print($TB "                                  erks_rst[TEST_GEN] = 0;\n");
              print($TB "                                  erks_rst[MODE_GEN] = 0;\n");
              print($TB "                                  #1\n");
              print($TB "                                  erks_rst[TEST_GEN] = 1;\n");
              print($TB "                                  erks_rst[MODE_GEN] = 1;\n");
              print($TB "                                  enable[MODE_GEN] = 1;\n");
              print($TB "                                  enable[TEST_GEN] = 1;\n");
              print($TB "                                  latch_enable[MODE_GEN] = 0;\n");
              print($TB "                                  latch_enable[TEST_GEN] = 1;\n");
              print($TB "                                  update_enable[MODE_GEN] = 1;\n");
              print($TB "                                  update_enable[TEST_GEN] = 1;\n");
              print($TB "                                  update_test_vector(     port_en,     port_test_type,     port_type,     port_care_range,     normal_port_val,     port_delay,\n");
              print($TB "                                                 test_port_en,test_port_test_type,test_port_type,test_port_care_range,test_normal_port_val,test_port_delay);\n");
              print($TB "                               end\n");
            }
            print($TB "                               state = MODE_SET_VALUE;\n");
          }
        }
      }else{
        print($TB "                            end else if (state == EXEC_TEST_VECTOR) begin\n");
      }
      print($TB "                            end\n");
      print($TB "                          end // end while\n");
      print($TB "                        end // end block\n");
      print($TB "             end\n");
      print($TB "      endcase\n");
      print($TB "    end\n");
      if($ex_ptn eq "1" && $hashoption{"tv"} == 1){
        print($TB "    end\n");
      }
      if ($sim == 1) { # VCS with message check
        print($TB "    end_pat = 1;\n");
      }
      if(@fsmtable==0){
        print($TB "    #(DELAY+5) \$finish;\n");
      }
      print($TB "  end\n\n");
      # processing rising/falling for each port
      my %port_rf;
      for (my $i=4;$i<scalar(@table);$i++){
        for (my $j=2;$j<scalar(@{$table[0]});$j++){
          my $cell = $table[$i][$j];
          if ($cell =~ /^(RISE|FALL)$/i) {
            if (!exists $port_rf{"$table[2][$j]"}){
              $port_rf{"$table[2][$j]"}=$table[2][$j];
            }
          }
        }
      }
      for (my $i=2;$i<scalar(@ExcludePTN);$i++){
        for (my $j=2;$j<scalar(@{$ExcludePTN[0]});$j++){
          my $cell = $ExcludePTN[$i][$j];
          if ($cell =~ /^(RISE|FALL)$/i) {
            if (!exists $port_rf{"$ExcludePTN[1][$j]"}){
              $port_rf{"$ExcludePTN[1][$j]"}=$ExcludePTN[1][$j];
            }
          }
        }
      }
      foreach my $key (keys %port_rf){
        my $port_index = $port_ref_table[1][Ex2Tbl::get_port_col($key,0,@port_ref_table)];
        print($TB "  always @(update_input_port[$port_index]) begin\n");
        print($TB "    if (port_rising_enb[$port_index] == 1) begin\n");
        print($TB "      #(port_rising_period[$port_index]);\n");
        @dup_check=();
        for (my $i=1;$i<scalar(@outseq);$i++){
          my ($cond_name,$out_name,$port_ref_num,$in_port_name,$out_port_name)=get_port_timing_info($outseq[$i][2],$outseq[$i][3],@port_ref_table);
          next if(grep (/^\Q$out_name\E$/,@dup_check) > 0);
          push(@dup_check,"$out_name");
          if (exists $hash_in_out{"$out_name"}){
            print($TB "      $out_name\_input_update_time [$port_index] = \$time;\n");
          }
        }
        print($TB "      port_reg[$port_index] = 1'b1;\n");
        print($TB "    end\n");
        print($TB "    if (port_falling_enb[$port_index] == 1) begin\n");
#        print($TB "      port_falling_enb[$port_index] = 0;\n");
        print($TB "      #(port_falling_period[$port_index]);\n");
        @dup_check=();
        for (my $i=1;$i<scalar(@outseq);$i++){
          my ($cond_name,$out_name,$port_ref_num,$in_port_name,$out_port_name)=get_port_timing_info($outseq[$i][2],$outseq[$i][3],@port_ref_table);
          next if(grep (/^\Q$out_name\E$/,@dup_check) > 0);
          push(@dup_check,"$out_name");
          if (exists $hash_in_out{"$out_name"}){
            print($TB "      $out_name\_input_update_time [$port_index] = \$time;\n");
          }
        }
        print($TB "      port_reg[$port_index] = 1'b0;\n");
        print($TB "    end\n");
        print($TB "  end\n");
      }
    }
    if ((@fsmtable != 0) && ($hashoption{"fsmtv"}==1)){
      for(my $fsmid=0;$fsmid<scalar(@fsmtable)-1;$fsmid++){
        my $fsmvct=$fsmtable[1+$fsmid][0].".ptn";
        print($TB "  \`include \"$path/$fsmvct\"\n"); # ptn of FSM
      }
    }

    # enable only when out sequence is used
    @dup_check=();
    if (@outseq != 0 || @InputSeqExclude != 0){
      my $cnt = 3;
      for (my $i=1;$i<scalar(@outseq);$i++){
        my ($cond_name,$out_name,$port_ref_num,$in_port_name,$out_port_name)=get_port_timing_info($outseq[$i][2],$outseq[$i][3],@port_ref_table);
        next if(grep (/^\Q$out_name\E$/,@dup_check) > 0);
        push(@dup_check,$out_name);
        if ($rnm eq "1"){
          print($TB "\n  always @($out_port_name) begin\n");
        } else {
          print($TB "\n  always @($out_name) begin\n");
        }
        if (exists $hash_in_out{"$out_name"}){
          print($TB "    for (i3=PORT_NUM-1;i3>=0;i3--) begin\n");
          print($TB "      $out_name"."_update_time[i3] = \$time - $out_name\_input_update_time[i3];\n");
          print($TB "      if (($out_name\_input_update_ctrl[i3] == 1) && ($out_name\_update_time[i3] > 0)) begin\n");
          print($TB "        $out_name\_update_flag[i3] = 1;\n");
          print($TB "      end\n");
          print($TB "    end\n");
        }
        my $pt = "";
        my $pre_pt = "";
        if ($out_out_seq eq "1"){
          for (my $k=1;$k<scalar(@outseq);$k++){
            my ($cond_name_tmp,$out_name_tmp,$port_ref_num_tmp,$in_port_name,$out_port_name)=get_port_timing_info($outseq[$k][2],$outseq[$k][3],@port_ref_table);
            if ($out_name eq $out_name_tmp and $port_ref_num_tmp eq "-1"){
              my $prefix_osc = "";
              $prefix_osc = "osc_" if ($outseq[$k][2] =~ /^\(osc\)/i);
              my $suffix_osc = "";
              $suffix_osc = "osc_" if ($outseq[$k][3] =~ /^\(osc\)/i);
              if ($suffix_osc eq "") {
                if ($prefix_osc ne ""){
                  print($TB "    $prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_update_time = \$time - $cond_name_tmp"."_rising_time;\n");
                  $pre_pt = $pre_pt."    if (($prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_update_ctrl == 1)&&($prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_update_time > 0)) begin\n";
                  $pre_pt = $pre_pt."      $prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_update_flag = 1;\n";
                  $pre_pt = $pre_pt."    end\n";
                  $pt = $pt."    if (($prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_update_ctrl == 1)&&($prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_update_flag == 1)) begin\n";
                  $pt = $pt."      $prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_update_ctrl = 0;\n";
                  $pt = $pt."      $prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_outseq_trg = $prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_outseq_trg + 1;\n";
                  $pt = $pt."    end\n";
                } else {
                  print($TB "    $cond_name_tmp\_$out_name\_update_time = \$time - front_$cond_name_tmp"."_update_time;\n");
                  $pre_pt = $pre_pt."    if (($cond_name_tmp\_$out_name\_update_ctrl == 1)&&($cond_name_tmp\_$out_name\_update_time > 0)) begin\n";
                  $pre_pt = $pre_pt."      $cond_name_tmp\_$out_name\_update_flag = 1;\n";
                  $pre_pt = $pre_pt."    end\n";
                  $pt = $pt."    if (($cond_name_tmp\_$out_name\_update_ctrl == 1)&&($cond_name_tmp\_$out_name\_update_flag == 1)) begin\n";
                  $pt = $pt."      $cond_name_tmp\_$out_name\_update_ctrl = 0;\n";
                  $pt = $pt."      $cond_name_tmp\_$out_name\_outseq_trg = $cond_name_tmp\_$out_name\_outseq_trg + 1;\n";
                  $pt = $pt."    end\n";
                }
              }
            }
          }
          print($TB "$pre_pt    #1;\n") if ($pt ne "");
          print($TB "$pt") if ($pt ne "");
        }
        if (exists $hash_in_out{"$out_name"}) {
          print($TB "    #1;\n") if ($pt eq "");
          print($TB "    for (i3=PORT_NUM-1;i3>=0;i3--) begin\n");
#          print($TB "      if (input_update_ctrl[i3] == 1) $out_name\_outseq_trg[i3] = $out_name\_outseq_trg[i3] + 1;\n"); # reserved for ver 4.0
          print($TB "      if (($out_name\_input_update_ctrl[i3] == 1) && ($out_name\_update_flag[i3] == 1)) begin\n");
          print($TB "        $out_name\_input_update_ctrl[i3] = 0;\n");
          print($TB "        $out_name\_outseq_trg[i3] = $out_name\_outseq_trg[i3] + 1;\n");
          print($TB "      end\n");
          print($TB "    end\n");
        }
        print($TB "  end\n");
        $cnt += 1;
      }
       @dup_check=();
      for (my $i=1;$i<scalar(@outseq);$i++){
        my ($cond_name,$out_name,$port_ref_num,$in_port_name,$out_port_name)=get_port_timing_info($outseq[$i][2],$outseq[$i][3],@port_ref_table);
        next if(grep (/^\Q$out_name\E$/,@dup_check) > 0);
        next if($outseq[$i][3] !~ /^\(osc\)/i); # next if the "later" is not (osc)
        next if($outseq[$i][4] =~ /^(pos|neg)/);
        push(@dup_check,$out_name);
        print($TB "\n  always @(posedge $out_name) begin\n");
        my $pt = "";
        my $pre_pt = "";
        if ($out_out_seq eq "1"){
          for (my $k=1;$k<scalar(@outseq);$k++){
            my ($cond_name_tmp,$out_name_tmp,$port_ref_num_tmp,$in_port_name,$out_port_name)=get_port_timing_info($outseq[$k][2],$outseq[$k][3],@port_ref_table);
            if ($out_name eq $out_name_tmp and $port_ref_num_tmp eq "-1"){
              my $prefix_osc = "";
              $prefix_osc = "osc_" if ($outseq[$k][2] =~ /^\(osc\)/i);
              my $suffix_osc = "";
              $suffix_osc = "osc_" if ($outseq[$k][3] =~ /^\(osc\)/i);
              if ($suffix_osc ne "") {
                if ($prefix_osc ne ""){
                  print($TB "    $prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_update_time = \$time - $cond_name_tmp"."_rising_time;\n");
                  $pre_pt = $pre_pt."    if (($prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_update_ctrl == 1)&&($prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_update_time > 0)) begin\n";
                  $pre_pt = $pre_pt."      $prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_update_flag = 1;\n";
                  $pre_pt = $pre_pt."    end\n";
                  $pt = $pt."    if (($prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_update_ctrl == 1)&&($prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_update_flag == 1)) begin\n";
                  $pt = $pt."      $prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_update_ctrl = 0;\n";
                  $pt = $pt."      $prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_outseq_trg = $prefix_osc$cond_name_tmp\_$suffix_osc$out_name\_outseq_trg + 1;\n";
                  $pt = $pt."    end\n";
                } else {
                  print($TB "    $cond_name_tmp\_$suffix_osc$out_name\_update_time = \$time - front_$cond_name_tmp"."_update_time;\n");
                  $pre_pt = $pre_pt."    if (($cond_name_tmp\_$suffix_osc$out_name\_update_ctrl == 1)&&($cond_name_tmp\_$suffix_osc$out_name\_update_time > 0)) begin\n";
                  $pre_pt = $pre_pt."      $cond_name_tmp\_$suffix_osc$out_name\_update_flag = 1;\n";
                  $pre_pt = $pre_pt."    end\n";
                  $pt = $pt."    if (($cond_name_tmp\_$suffix_osc$out_name\_update_ctrl == 1)&&($cond_name_tmp\_$suffix_osc$out_name\_update_flag == 1)) begin\n";
                  $pt = $pt."      $cond_name_tmp\_$suffix_osc$out_name\_update_ctrl = 0;\n";
                  $pt = $pt."      $cond_name_tmp\_$suffix_osc$out_name\_outseq_trg = $cond_name_tmp\_$suffix_osc$out_name\_outseq_trg + 1;\n";
                  $pt = $pt."    end\n";
                }
              }
            }
          }
          print($TB "$pre_pt    #1;\n") if ($pt ne "");
          print($TB "$pt") if ($pt ne "");
        }
        print($TB "  end\n");
        $cnt += 1;
      }
      for (my $i=0;$i<scalar(@fall_cond);$i++){
        print($TB "\n  always @(negedge $fall_cond[$i]) begin\n");
        print($TB "    $fall_cond[$i]\_falling_time = \$time;\n");
        print($TB "  end\n");
      }
      for (my $i=0;$i<scalar(@rise_cond);$i++){
        print($TB "\n  always @(posedge $rise_cond[$i]) begin\n");
        print($TB "    $rise_cond[$i]\_rising_time = \$time;\n");
        print($TB "  end\n");
      }
      for (my $i=0;$i<scalar(@osc_cond);$i++){
        print($TB "\n  always @(posedge $osc_cond[$i]) begin\n");
        print($TB "    if ($osc_cond[$i]\_osc_chk_ctrl == 1) $osc_cond[$i]\_rising_time = \$time;\n");
        print($TB "    #2 $osc_cond[$i]\_osc_chk_ctrl = 0;\n");
        print($TB "  end\n");
      }
      for (my $i=0;$i<scalar(@change_cond);$i++){
        if ($rnm eq "1") {
           for (my $k=0;$k<scalar(@{$port[0]});$k++){
             if (Ex2Tbl::cmp_port_name($change_cond[$i],$port[10][$k]) == 1){
               if($port[13][$k] ne "-"){ # real port
                 print($TB "\n  always @($change_cond[$i].r) begin\n");
               } else {
                 print($TB "\n  always @($change_cond[$i]) begin\n");
               }
               last;
             }
           }
        } else {
          print($TB "\n  always @($change_cond[$i]) begin\n");
        }
        print($TB "    $change_cond[$i]\_update_time_pos = \$time;\n");
        print($TB "  end\n");
      }
    }
    
    @dup_check=();
    if ($out_out_seq eq "1"){
      for (my $i=1;$i<scalar(@outseq);$i++){
        my ($cond_name,$out_name,$port_ref_num,$in_port_name,$out_port_name)=get_port_timing_info($outseq[$i][2],$outseq[$i][3],@port_ref_table);
        if ($port_ref_num eq "-1"){
          next if(grep (/^\Q$cond_name\E$/,@dup_check) > 0);
          push(@dup_check,$cond_name);
          if ($rnm eq "1"){
            print($TB "\n  always @($in_port_name) begin\n");
          }else{
            print($TB "\n  always @($cond_name) begin\n");
          }
          print($TB "    front_$cond_name"."_update_time = \$time;\n");
          print($TB "    $cond_name\_$out_name"."_update_ctrl = 1;\n");
          print($TB "  end\n");
        }
      }
    }

    if (@outseq != 0){
      for (my $i=1;$i<scalar(@outseq);$i++){
        my ($cond_name,$out_name,$port_ref_num,$in_port_name,$out_port_name)=get_port_timing_info($outseq[$i][2],$outseq[$i][3],@port_ref_table);
        if ($outseq[$i][4] =~ /^\d+-\d+$/) { # Ex: 10-50
          my $prefix_osc = "";
          $prefix_osc = "osc_" if ($outseq[$i][2] =~ /^\(osc\)/i);
          my $suffix_osc = "";
          $suffix_osc = "osc_" if ($outseq[$i][3] =~ /^\(osc\)/i);
          my ($min, $max)=split(/-/,$outseq[$i][4]);
          if ($rnm eq "1"){
            print($TB "\n  always @($in_port_name) begin\n");
          }else{
            print($TB "\n  always @($cond_name) begin\n");
          }
          print($TB "    #($max+2);\n");
          my $ctrl_var = "$out_name\_input_update_ctrl[$port_ref_num]"; # input port -> output port 
          if ($port_ref_num eq "-1") { # output port -> output port
            $ctrl_var = "$prefix_osc$cond_name\_$suffix_osc$out_name\_update_ctrl";
          }
          print($TB "    $ctrl_var = 0;\n");
          print($TB "    $prefix_osc$cond_name\_$suffix_osc$out_name\_stable_chk = $prefix_osc$cond_name\_$suffix_osc$out_name\_stable_chk + 1;\n");
          print($TB "  end\n");
        } elsif ($outseq[$i][4] =~ /^(pos|neg)/) { # Ex: pos 5/neg 5
          my $clock_name = $outseq[$i][6];
          my $out_edge_cond = "";
          my $first_value = "";
          my $second_value = "";
          if ($outseq[$i][2] =~ /\(fall\)/) {
            $first_value = "$cond_name\_falling_time";
          } elsif ($outseq[$i][2] =~ /\(rise|osc\)/) {
            $first_value = "$cond_name\_rising_time";
          } else {
            $first_value = "$cond_name\_update_time_pos";
          }
          if ($outseq[$i][3] =~ /\(osc\)/) {
            $second_value = "$out_name\_rising_time";
            $out_edge_cond = "posedge ";
          } else {
            $second_value = "\$time";
          }
          my $clock_period = $outseq[$i][7];
          if (exists $clock_change_list{"$clock_name"}) {
            $clock_period = "$clock_name\_clk_period";
          }
          my $check_type = "rising";
          $check_type = "falling" if ($outseq[$i][4] =~ /neg/);
          my $check_name = lc($outseq[$i][0])."_$outseq[$i][5]";
          print($TB "\n  always @($out_edge_cond$out_port_name) begin\n");
          if ($outseq[$i][3] =~ /\(osc\)/) {
            print($TB "    if ($out_name\_osc_chk_ctrl == 1) begin\n");
          } else {
            print($TB "    if (i0 != 0) begin\n");
          }
          print($TB "      $check_type\_$check_name\_num = calc_num_of_edge(first_$clock_name\_$check_type\_time, $clock_period, $first_value,\$time);\n");
          print($TB "      #2 check_$check_type\_$check_name = check_$check_type\_$check_name + 1;\n");
          print($TB "    end\n");
          print($TB "  end\n");
        }
      }
    }
    # dump waveform
    if($wave eq "vpd"){ # if wave type is VPD
      print($TB "  \n  initial begin\n");
      print($TB "    \$vcdplusfile(\"wave.vpd\");\n    \$vcdpluson();\n");
      print($TB "  end\n");
    }
    # SDF annotation
    if($sdf_info[0] == 1){ # if sdf option is defined
      print($TB "  \n  initial begin\n");
      print($TB "    \$sdf_annotate(\"$sdf_info[1]\",$sdf_info[2]);\n"); 
      print($TB "  end\n");
    }
    if($wave eq "fsdb"){ # if wave type is FSDB
      print($TB "  \n  initial begin\n");
      print($TB "    \$fsdbDumpfile(\"wave.fsdb\");\n");
      print($TB "    \$fsdbDumpvars();\n");
      print($TB "  end\n");
    }

    if (@table != 0){
      # print code generation clock for truth table if clock source is existed
      if ($clock_source ne "") {
        my $gen_clk="";
        foreach my $clock_name(keys %clock_source_list) {
          $clock_period = $clock_source_list{"$clock_name"};
          my $half_cycle=$clock_period>>1;# half cycle
          $gen_clk=$gen_clk."\n  always begin\n";
          if (exists $clock_change_list{"$clock_name"}) {
            $gen_clk=$gen_clk."    if ($clock_name\_clk_period == 0) begin\n";
            $gen_clk=$gen_clk."      $clock_name = $clock_name\_clk_value;\n";
            $gen_clk=$gen_clk."      if (start_$clock_name\_clk_zero == 0) begin\n";
            $gen_clk=$gen_clk."        #1;\n";
            $gen_clk=$gen_clk."        start_$clock_name\_clk_zero = 1;\n";
            $gen_clk=$gen_clk."      end else begin\n";
            $gen_clk=$gen_clk."        #($half_cycle - 1);\n";
            $gen_clk=$gen_clk."        start_$clock_name\_clk_zero = 0;\n";
            $gen_clk=$gen_clk."      end\n";
            $gen_clk=$gen_clk."    end else begin\n";
            for (my $i=0;$i<scalar(@rising_clock_cnt);$i++){
              if ($clock_name eq $rising_clock_cnt[$i]) {
                $gen_clk=$gen_clk."      if (($clock_name == 1'b0) && (first_$clock_name\_rising_time == 0)) first_$clock_name\_rising_time = \$time;\n";
                last;
              }
            }
            for (my $i=0;$i<scalar(@falling_clock_cnt);$i++){
              if ($clock_name eq $falling_clock_cnt[$i]) {
                $gen_clk=$gen_clk."      if (($clock_name == 1'b1) && (first_$clock_name\_falling_time == 0)) first_$clock_name\_falling_time = \$time;\n";
                last;
              }
            }
            $gen_clk=$gen_clk."      start_$clock_name\_clk_zero = 0;\n";
            $gen_clk=$gen_clk."      $clock_name <= ~$clock_name;\n";
            if($pulse_width_col!=1){
              $gen_clk=$gen_clk."      #($clock_name\_clk_period/2)\n";
            }else{
              $gen_clk=$gen_clk."      #1;\n";
              $gen_clk=$gen_clk."      if($clock_name === 1)begin\n";
              $gen_clk=$gen_clk."       #(high_pulse_width - 1);\n";
              $gen_clk=$gen_clk."      end else begin\n";
              $gen_clk=$gen_clk."      #($clock_name\_clk_period - high_pulse_width - 1);\n";
              $gen_clk=$gen_clk."      end\n";
            }
            for (my $i=0;$i<scalar(@rising_clock_cnt);$i++){
              if ($clock_name eq $rising_clock_cnt[$i]) {
                $gen_clk=$gen_clk."      if (($clock_name == 1'b0) && (first_$clock_name\_rising_time == 0)) first_$clock_name\_rising_time = \$time;\n";
                last;
              }
            }
            for (my $i=0;$i<scalar(@falling_clock_cnt);$i++){
              if ($clock_name eq $falling_clock_cnt[$i]) {
                $gen_clk=$gen_clk."      if (($clock_name == 1'b1) && (first_$clock_name\_falling_time == 0)) first_$clock_name\_falling_time = \$time;\n";
                last;
              }
            }
            $gen_clk=$gen_clk."      if ($clock_name\_clk_period != 0) $clock_name <= ~$clock_name;\n";
            if($pulse_width_col ==1){
              $gen_clk=$gen_clk."      #1;\n";
              $gen_clk=$gen_clk."      if($clock_name === 1)begin\n";
              $gen_clk=$gen_clk."       #(high_pulse_width - 1);\n";
              $gen_clk=$gen_clk."      end else begin\n";
              $gen_clk=$gen_clk."      #($clock_name\_clk_period - high_pulse_width - 1);\n";
              $gen_clk=$gen_clk."      end\n";
            }
            $gen_clk=$gen_clk."    end\n";
          } else {
            for (my $i=0;$i<scalar(@rising_clock_cnt);$i++){
              if ($clock_name eq $rising_clock_cnt[$i]) {
                $gen_clk=$gen_clk."    if (($clock_name == 1'b0) && (first_$clock_name\_rising_time == 0)) first_$clock_name\_rising_time = \$time;\n";
                last;
              }
            }
            for (my $i=0;$i<scalar(@falling_clock_cnt);$i++){
              if ($clock_name eq $falling_clock_cnt[$i]) {
                $gen_clk=$gen_clk."    if (($clock_name == 1'b1) && (first_$clock_name\_falling_time == 0)) first_$clock_name\_falling_time = \$time;\n";
                last;
              }
            }
            $gen_clk=$gen_clk."    $clock_name <= ~$clock_name;\n";
            $gen_clk=$gen_clk."    #$half_cycle\n";
            for (my $i=0;$i<scalar(@rising_clock_cnt);$i++){
              if ($clock_name eq $rising_clock_cnt[$i]) {
                $gen_clk=$gen_clk."    if (($clock_name == 1'b0) && (first_$clock_name\_rising_time == 0)) first_$clock_name\_rising_time = \$time;\n";
                last;
              }
            }
            for (my $i=0;$i<scalar(@falling_clock_cnt);$i++){
              if ($clock_name eq $falling_clock_cnt[$i]) {
                $gen_clk=$gen_clk."    if (($clock_name == 1'b1) && (first_$clock_name\_falling_time == 0)) first_$clock_name\_falling_time = \$time;\n";
                last;
              }
            }
            $gen_clk=$gen_clk."    $clock_name <= ~$clock_name;\n";
          }
          $gen_clk=$gen_clk."  end\n";
        }
        print($TB "$gen_clk");
      }
    }

    # Dump control message check
    if (@table !=0 && $hashoption{"tv"} == 1 && $sim == 1) { # VCS with message check
      print($TB "  \n  initial begin\n");
      print($TB "    \$log(\"test.log\");\n");
      print($TB "    tmp = 0;\n");
      print($TB "    log_index = 0;\n");
      if ($msg_col != -1 && $split == 1){
        print($TB "    \$system(\"rm -rf msg_chk_log.erks\");\n");
        print($TB "    \$system(\"echo \\\"Summary for message\\\" > msg_chk_log.erks\");\n");
      }
      print($TB "    while (1) begin\n");
      print($TB "      #(DELAY)\n");
      print($TB "      if (((i0 > 0) && (i0\%$check_point == 0)) || (end_pat == 1)) begin\n");
      print($TB "        \$nolog;\n");
      print($TB "        log_index = log_index + 1;\n");
      if ($split > 1) {
        print($TB "        \$system(\"grep \\\"\\\" test.log | grep -v \\\"INPUT :::\\\" | grep -v \\\"MSG   :::\\\" > vcslog.erks\");\n");
        print($TB "        \$system(\"grep \\\"\\\" test.log | grep -v \\\"INPUT :::\\\" | grep -v \\\"MSG   :::\\\" >> ../vcslog.erks\");\n");
      }else{
        print($TB "        \$system(\"grep \\\"\\\" test.log | grep -v \\\"INPUT :::\\\" | grep -v \\\"MSG   :::\\\" >> vcslog.erks\");\n");
      }
      print($TB "        tmp = \$systemf(\"mv test.log \%d\",log_index);\n");
      print($TB "        if (end_pat == 1) begin\n");
      print($TB "          \$system(\"rm -rf test.log\");\n");
      if ($split > 1) {
        print($TB "          \$system(\"cat ../vcslog.erks > test.log\");\n");
        print($TB "          \$log(\"../vcslog_end.erks\");\n");
      }else{
        print($TB "          \$system(\"cat vcslog.erks > test.log\");\n");
        print($TB "          \$log(\"vcslog.erks\");\n");
      }
      print($TB "        end else begin\n");
      print($TB "          \$log(\"test.log\");\n");
      print($TB "        end\n");
      if ($msg_col != -1) {
        if ($split > 1) {
          print($TB "        tmp = \$systemf(\"perl ../../msg_chk.pl \%d ../msg_chk_log.erks\",log_index);\n");
        }else{
          print($TB "        tmp = \$systemf(\"perl ../msg_chk.pl \%d msg_chk_log.erks\",log_index);\n");
        }
      }
      print($TB "        tmp = \$systemf(\"rm -rf \%d\",log_index);\n");
      print($TB "      end\n");
      print($TB "    end\n");
      print($TB "  end\n");
    }
    if (scalar(@rising_clock_cnt) > 0 or scalar(@falling_clock_cnt) > 0) {
      print($TB "\n  function integer calc_num_of_edge (integer first_edge_time, period, start_time, check_time);\n");
      print($TB "    begin\n");
      print($TB "      if (period == 0) begin\n");
      print($TB "        calc_num_of_edge = 0;\n");
      print($TB "      end else begin\n");
      print($TB "        calc_num_of_edge = ((check_time-first_edge_time)/period) - ((start_time-first_edge_time)/period) + 1;\n");
      print($TB "      end\n");
      print($TB "    end\n");
      print($TB "  endfunction\n\n");
    }
    if ((@table !=0) && ($hashoption{"tv"} == 1 || $hashoption{"ex_tv"} == 1)){
      print($TB "  task update_test_vector;\n");
      print($TB "    input in_port_en                 [PORT_NUM-1:0];\n");
      print($TB "    input [3:0] in_port_test_type    [PORT_NUM-1:0];\n");
      print($TB "    input in_port_type               [PORT_NUM-1:0];\n");
      print($TB "    input [3:0] in_port_care_range   [PORT_NUM-1:0];\n");
      print($TB "    input [15:0] in_normal_port_val  [PORT_NUM-1:0];\n");
      print($TB "    input [63:0] in_port_delay       [PORT_NUM-1:0];\n");
      if($rnm == 1){
        print($TB "    input nt::Real in_real_port_val    [PORT_NUM-1:0];\n");
        print($TB "    input real in_real_port_def_step   [PORT_NUM-1:0];\n");
        print($TB "    input real in_real_port_max_real   [PORT_NUM-1:0];\n");
      }
      print($TB "    output out_port_en                 [PORT_NUM-1:0];\n");
      print($TB "    output [3:0] out_port_test_type    [PORT_NUM-1:0];\n");
      print($TB "    output out_port_type               [PORT_NUM-1:0];\n");
      print($TB "    output [3:0] out_port_care_range   [PORT_NUM-1:0];\n");
      print($TB "    output [15:0] out_normal_port_val  [PORT_NUM-1:0];\n");
      print($TB "    output [63:0] out_port_delay       [PORT_NUM-1:0];\n");
      if($rnm == 1){
        print($TB "    output nt::Real out_real_port_val    [PORT_NUM-1:0];\n");
        print($TB "    output real out_real_port_def_step   [PORT_NUM-1:0];\n");
        print($TB "    output real out_real_port_max_real   [PORT_NUM-1:0];\n");
      }
      print($TB "    begin\n");
      print($TB "      out_port_en         = in_port_en;\n");
      print($TB "      out_port_delay      = in_port_delay;\n");
      print($TB "      out_port_test_type  = in_port_test_type;\n");
      print($TB "      out_port_type       = in_port_type;\n");
      print($TB "      out_port_care_range = in_port_care_range;\n");
      print($TB "      out_normal_port_val = in_normal_port_val;\n");
      if($rnm == 1){
        print($TB "      out_real_port_val      = in_real_port_val;\n");
        print($TB "      out_real_port_def_step = in_real_port_def_step;\n");
        print($TB "      out_real_port_max_real = in_real_port_max_real;\n");
      }
      print($TB "    end\n");
      print($TB "  endtask\n");
    }
    # footer
    print($TB "\nendmodule\n\n");
   
    # generate TestGenMod module
    if ((@table !=0) && ($hashoption{"tv"} == 1 || $hashoption{"ex_tv"} ==1)){
      print($TB "module TestGenMod (\n");
      print($TB "  input [MEM_SIZE:0] mem,               // indicate port index -> input\n");
      print($TB "  input erks_rst,         // reset the counter for test generator\n");
      print($TB "  input test_gen_trigger, // trigger the generation\n");
      print($TB "  input enable,           // enable test generation module\n");
      print($TB "  input latch_enable,     // enable latch mode\n");
      print($TB "  input update_enable,    // enable updating the test pattern\n");
      print($TB "  input  port_en              [PORT_NUM-1:0], // port_en -> input\n");
      print($TB "  input [15:0] normal_port_val[PORT_NUM-1:0], // input\n");
      print($TB "  input [3:0] port_test_type  [PORT_NUM-1:0], // input\n");
      print($TB "  input [3:0] port_care_range [PORT_NUM-1:0], // input\n");
      print($TB "  input port_type             [PORT_NUM-1:0], // input\n");
      print($TB "  input [64:0] input_loop_cnt [PORT_NUM-1:0], // input\n");
      print($TB "  output [64:0] output_loop_cnt[PORT_NUM-1:0],\n");
      if($rnm == 1){
        print($TB "  input nt::Real real_reg         [PORT_NUM-1:0],\n");
        print($TB "  input nt::Real real_port_val    [PORT_NUM-1:0],\n");
        print($TB "  input real real_port_def_step   [PORT_NUM-1:0],\n");
        print($TB "  input real real_port_max_real   [PORT_NUM-1:0],\n");
      }
      print($TB "  output port_rising_enb      [PORT_NUM-1:0],\n");
      print($TB "  output port_falling_enb     [PORT_NUM-1:0],\n");
      if($rnm == 1){
        print($TB "  output nt::Real real_test_pattern   [PORT_NUM-1:0],\n");
      }
      print($TB "  output test_vector          [PORT_NUM-1:0],\n");
      print($TB "  output test_gen_finish // indicate the test pattern generating is ended\n");
      print($TB ");\n");
      print($TB "  reg port_break    [PORT_NUM  :0];         // internal\n");
      print($TB "  reg temp_port_reg [PORT_NUM-1:0];         // internal -> output\n");
      print($TB "  reg rising_enb    [PORT_NUM-1:0];\n");
      print($TB "  reg falling_enb   [PORT_NUM-1:0];\n");
      print($TB "  reg loop_cnt_ctrl [PORT_NUM-1:0];\n");
      if($rnm == 1){
        print($TB "  real tmp_real_val;\n");
        print($TB "  nt::Real real_b_it   [3:0];\n");
        print($TB "  nt::Real temp_real_reg[PORT_NUM-1:0];\n");
      }
      print($TB "  reg b_it[3:0];\n");
      print($TB "  reg test_finish;\n");
      print($TB "  integer i1, i2, port_index, loop_cont, next_flag, disable_cnt;\n");
      print($TB "  reg [64:0] port_loop_cnt [PORT_NUM-1:0];\n");
      print($TB "  assign test_gen_finish=test_finish;\n");
      print($TB "  assign test_vector = temp_port_reg;\n");
      if($rnm == 1){
        print($TB "  assign real_test_pattern = temp_real_reg;\n");
      }
      print($TB "  assign port_rising_enb = rising_enb;\n");
      print($TB "  assign port_falling_enb = falling_enb;\n");
      print($TB "  assign output_loop_cnt = port_loop_cnt;\n");
      print($TB "\n");
      print($TB "  initial begin\n");
      print($TB "    b_it[3]=1'bz;\n");
      print($TB "    b_it[2]=1'bx;\n");
      print($TB "    b_it[1]=1'b1;\n");
      print($TB "    b_it[0]=1'b0;\n");
      if($rnm == 1){
        print($TB "    real_b_it[3]='{'hz, `wrealZState};\n"); 
        print($TB "    real_b_it[2]='{'hx, `wrealXState};\n");
        print($TB "    real_b_it[1]='{1,1};\n");
        print($TB "    real_b_it[0]='{0,0};\n");
      }
      print($TB "    test_finish = 1'b0;\n");
      print($TB "    loop_cont=1'b1; // start test vector\n");
      print($TB "    port_break[PORT_NUM] = 1;\n");
      print($TB "    for (i1=0;i1<PORT_NUM;i1++) begin\n");
      print($TB "      port_break[i1] = 0;\n");
      print($TB "      temp_port_reg[i1] = 0;\n");
      print($TB "      port_loop_cnt[i1] = 0;\n");
      print($TB "      rising_enb[i1] = 0;\n");
      print($TB "      falling_enb[i1] = 0;\n");
      print($TB "      loop_cnt_ctrl[i1] = 0;\n");
      print($TB "    end\n");
      print($TB "    loop_cnt_ctrl[PORT_NUM-1] = 1;\n");
      print($TB "  end\n\n");
      print($TB "  always @(input_loop_cnt) begin\n");
      print($TB "    if (latch_enable == 1) begin\n");
      print($TB "      for (i1=0;i1<PORT_NUM;i1++) begin\n");
      print($TB "        port_loop_cnt [i1] = input_loop_cnt [i1];\n");
      print($TB "      end\n");
      print($TB "    end\n");
      print($TB "  end\n\n");
      print($TB "  always @(negedge erks_rst) begin\n");
      print($TB "    test_finish = 1'b0;\n");
      print($TB "    loop_cont=1'b1; // start test vector\n");
      print($TB "    port_break[PORT_NUM] = 1;\n");
      print($TB "    for (i1=0;i1<PORT_NUM;i1++) begin\n");
      print($TB "      port_break[i1] = 0;\n");
      print($TB "      temp_port_reg[i1] = 0;\n");
      print($TB "      port_loop_cnt[i1] = 0;\n");
      print($TB "      rising_enb[i1] = 0;\n");
      print($TB "      falling_enb[i1] = 0;\n");
      print($TB "      loop_cnt_ctrl[i1] = 0;\n");
      print($TB "    end\n");
      print($TB "    loop_cnt_ctrl[PORT_NUM-1] = 1;\n");
      print($TB "  end\n\n");
      print($TB "  always @(test_gen_trigger) begin\n");
      print($TB "    if (enable == 1'b1 && test_finish == 1'b0) begin\n");
      print($TB "$test_mod_gen");
      print($TB "      if (loop_cont == 0) test_finish = 1'b1;\n");
      print($TB "    end\n");
      print($TB "  end\n");
      print($TB "endmodule\n\n");
    }
    # generate reference table module
    if ((@table !=0) && ($hashoption{"tv"} == 1 || $hashoption{"ex_tv"} == 1) && scalar(%ref_var_tbl_list)){
      foreach my $var (keys %ref_var_tbl_list){
        my @ref_table = @{$ref_var_tbl_list{$var}};
        my @port_ref = Ex2Tbl::GetPortRefTable($ref_table[1],\@ref_table,\@port,$rnm);
        print($TB "module $ref_table[1][0](");
        my @input_list = ();
        my $total_input = 0;
        for (my $j=0;$j<scalar(@{$port_ref[0]});$j++){
          if ($port_ref[1][$j] ne "-1" and $port_ref[1][$j] ne "-2"){
            $total_input++;
            if ($port_ref[8][$j] eq ""){
              next if (grep(/^$port_ref[7][$j]$/,@input_list) > 0);
              push(@input_list,$port_ref[7][$j]);
              print($TB "$port_ref[0][$j], ");
            }elsif ($port_ref[8][$j] ne "-" or $port_ref[0][$j] =~ /.*\[(\d+|\d+:\d+)\]/){
              my $name = $port_ref[0][$j];
              $name =~ s/\[.*$//;
              next if (grep(/$name/,@input_list) > 0);
              push(@input_list,$name);
              print($TB "$name, ");
            }
          }
        }
        my $print = "";
        for (my $j=0;$j<scalar(@{$port_ref[0]});$j++){
          if($port_ref[4][$j] eq "3"){ #ref port
            if ($rnm == 1){
              print($TB "$port_ref[0][$j], port_en);\n");
              print($TB "  output real $port_ref[0][$j];\n");
              print($TB "  real out_val;\n");
            }else{
              print($TB "$port_ref[0][$j], port_en);\n");
              print($TB "  output [63:0] $port_ref[0][$j];\n");
              print($TB "  reg [63:0] out_val;\n");
            }
            print($TB "  assign $port_ref[0][$j] = out_val;\n");
          }
        }
        @portname_list = ();
        for (my $j=0;$j<scalar(@{$port_ref[0]});$j++){
          next if ($port_ref[4][$j] eq "-2" or $port_ref[4][$j] eq "1" or $port_ref[4][$j] eq "3");
          for(my $i=0;$i<scalar(@{$port[0]});$i++){
            if (Ex2Tbl::cmp_port_name($port[0][$i],$port_ref[0][$j]) and $port_ref[1][$j] ne "-2"){
              if(($pg==1 || ($pg==0 && ($port[1][$i] !~ /power|ground/))) && (grep(/^$port[10][$i]$/,@portname_list)<1)){
                my $port_ref_type = Ex2Tbl::get_port_type($port[10][$i],@port);
                $port_ref_type = "input" if $port_ref_type =~ /(power|ground)/i;
                if ($port[11][$i] eq "-"){
                  if (($wave eq "ams")&&($rnm == 1)&&($port[2][$i] eq "A")&&($port[1][$i] !~ /power|ground/)) {
                      $print=($port[1][$i] =~ /input|electrical_in/) ? $print."  $port_ref_type real ".wireg_bit($port[10][$i],0,0)."\;\n" :
                              ($port[1][$i] =~ /output|inout|electrical_out/) ? $print."  $port_ref_type wreal ".wireg_bit($port[10][$i],0,0)."\;\n" :  $print;
                  } else {
                    if (($port[13][$i] ne "-")&&($rnm == 1)){
                      $print=($port[1][$i] =~ /power|ground|input|electrical_in/) ? $print."  $port_ref_type nt::Real ".wireg_bit($port[10][$i],0,0)."\;\n" :
                              ($port[1][$i] =~ /output|inout|electrical_out/) ? $print."  $port_ref_type SVreal ".wireg_bit($port[10][$i],0,0)."\;\n" :  $print;
                    }else{
                      $print=($port[1][$i] =~ /power|ground|input|electrical_in/) ? $print."  $port_ref_type ".wireg_bit($port[10][$i],0,0)."\;\n" :
                              ($port[1][$i] =~ /output|inout|electrical_out/) ? $print."  $port_ref_type ".wireg_bit($port[10][$i],0,0)."\;\n" :  $print;
                    }
                  }
                }else{
                  my $msb=(split(/:/,$port[11][$i]))[0];
                  my $lsb=(split(/:/,$port[11][$i]))[1];
                  if (($wave eq "ams")&&($rnm == 1)&&($port[2][$i] eq "A")&&($port[1][$i] !~ /power|ground/)) {
#                        $print=($port[1][$i] =~ /input|electrical_in/) ? $print."  $port_ref_type real $port[10][$i] [$msb:$lsb];\n" :
#                                ($port[1][$i] =~ /output|inout|electrical_out/) ? $print."  $port_ref_type wreal $port[10][$i] [$msb:$lsb];\n" :  $print; #cov
                  }else{
                    if (($port[13][$i] ne "-")&&($rnm == 1)){
#                        $print=($port[1][$i] =~ /power|ground|input|electrical_in/) ? $print."  $port_ref_type nt::Real $port[10][$i] [$msb:$lsb];\n" : # cov
#                                ($port[1][$i] =~ /output|inout|electrical_out/) ? $print."  $port_ref_type SVreal $port[10][$i] [$msb:$lsb];\n" :  $print;
                    }else{
                      $print=($port[1][$i] =~ /power|ground|input|electrical_in/) ? $print."  $port_ref_type ".wireg_bit($port[10][$i],$msb,$lsb)."\;\n" :
                              ($port[1][$i] =~ /output|inout|electrical_out/) ? $print."  $port_ref_type ".wireg_bit($port[10][$i],$msb,$lsb)."\;\n" :  $print;
                    }
                  }
                }
                push(@portname_list,$port[10][$i]);
              }
              last;
            }
          }
        }
        print($TB "  input port_en [PORT_NUM-1:0];\n");
        if ($rnm == 1) {
          print($TB "  nettype nt::SVreal SVreal;\n");
        }
        print($TB "$print\n");
        print($TB "  always @(".join(" or ",@input_list).") begin\n");
        for (my $i=2;$i<scalar(@ref_table);$i++){
          my $err = "";
          ($err,$print) = print_ref_var(\@{$ref_table[1]},\@{$ref_table[$i]},\@input_list,\@port_ref,$rnm,1) if ($i == 2);
          ($err,$print) = print_ref_var(\@{$ref_table[1]},\@{$ref_table[$i]},\@input_list,\@port_ref,$rnm,0) if ($i > 2);
          return (1,0) if ($err == 1);
          print($TB "$print");
        }
        print($TB "  end\n");
        print($TB "\nendmodule\n\n");
      }
    }
    # Module to covert SVreal to real port before assertion
    if($sim == 2 && $rnm == 1 && $wave ne "ams"){
      my $print="";
      @portname_list=();
      print($TB "\nfunction real ConvertNetType;\n");
      print($TB "  input nt::Real inport;\n");
      print($TB "  if\(inport.i ===\'hx\)\n");
      print($TB "    ConvertNetType = \`wrealXState\;\n");
      print($TB "  else if\(inport.i ===\'hz\)\n");
      print($TB "    ConvertNetType = \`wrealZState\;\n");
      print($TB "  else\n");
      print($TB "    ConvertNetType = inport.r\;\n");
      print($TB "\nendfunction\n\n");
    }
    
    # include assertion of FSM (if any)
    if ((@fsmtable != 0) && ($hashoption{"fsmast"}==1)){
      for(my $fsmid=0;$fsmid<scalar(@fsmtable)-1;$fsmid++){
        my $fsmast=$fsmtable[1+$fsmid][0]."_ast.sv";
        print($TB "\`include \"$path/$fsmast\"\n"); # ptn of FSM
      }
    }

  close($TB);
  return(0,$freq_check);
}

sub print_ref_var{
  my ($pn,$rp,$inl,$pr,$rnm,$is_first_pat) = @_;
  my @p_name = @$pn;
  my @ref_pat = @$rp;
  my @input_list = @$inl;
  my @port_ref_table = @$pr;
  my $pt = "";
  my $print = "";
  for(my $j=2;$j<scalar(@ref_pat);$j++){
    next if ($port_ref_table[4][$j] eq "-2" or $port_ref_table[4][$j] eq "3"); # next if -2: none or 3: ref_port or 1: output
    if ($port_ref_table[4][$j] eq "1" ){
      print("ERROR ::: [$ref_pat[0]] Output port should not be used in variable reference table.\n"); 
      return(1,0);
    }
    $pt = $pt."(port_en[$port_ref_table[1][$j]] == 1)&&" if ($port_ref_table[4][$j] eq "2" and $ref_pat[$j] !~ /^_/);
    $pt = $pt."(port_en[$port_ref_table[1][$j]] == 0)&&" if ($port_ref_table[4][$j] eq "2" and $ref_pat[$j] =~ /^_/);
    if ($ref_pat[$j] =~ /^EXP_NOT_/i){
      my $val = $ref_pat[$j];
      $val =~ s/EXP_NOT_//;
      $val =~ s/_.*$//;
      $val = "1'b".$val;
      $pt = $pt."($port_ref_table[7][$j] !== $val)&&";
    }elsif ($ref_pat[$j] =~ /^\*$/i){
    }else{
      my %var = Ex2Tbl::get_pattern($ref_pat[$j],$j,0,@port_ref_table);
      if (scalar(%var)){
        my $print="";
        my $cnt = 0;
        foreach my $key (keys %var){
          my $cond = "";
          if ($port_ref_table[2][$j] eq 1){ # real port
            $cond= real_port_assertion($port_ref_table[7][$j],$key,3,0);
            $cond =~ s/&&$//g;
            $cond = "($cond)||";
          }else{
            $cond= "($port_ref_table[7][$j] === 1'b$key)||";
          }
          $print=$print.$cond;
          $cnt++;
        }
        $print =~ s/\|\|$//g;
        if ($cnt > 1) {
          $pt = $pt."($print)&&";
        } else {
          $pt = $pt."$print&&";
        }
      }
    }
  }
  $pt=~s/\&\&$//;
  $pt="1" if ($pt =~ /^\s*$/); # Care input (not all *)
  if ($is_first_pat eq "1"){
     $print = "    if ($pt) begin ";
  } else {
     $print = " else if ($pt) begin ";
  }
  $pt="";
  for(my $j=2;$j<scalar(@ref_pat);$j++){
    if($port_ref_table[1][$j] eq "-1" && $port_ref_table[2][$j] eq "0"){ #ref port
      my $val = $ref_pat[$j];
      $val =~ s/^_+//;
      if($val =~ /^\d*\.?\d+$/){
        $print = $print."\n      out_val=".lc($val).";\n";
      }elsif($val =~ /^(0|1|x|z)$/i){
        $print = $print."\n      out_val=1'b".lc($val).";\n";
      }
      last;
    }
  }
  $print = $print."    end";
  return (0,$print);
}

sub create_clock_table{#[0] Port table [1] FSM table
  my ($pt, $ft)=@_;
  my @port=@$pt;
  my @fsm=@$ft;
  my @clock=();
  my $row=0;
  my @push_items=();
  for (my $fsmid=0;$fsmid<scalar(@fsm)-1;$fsmid++){# for each fsm
    my $clk=get_clk_name($fsmid, @fsm);
    my $period=get_clk_period($clk, @port);
    if (grep(/^$clk$/, @push_items)==0){
      push(@push_items, $clk);
      $clock[$row][0]=$clk;
      $clock[$row][1]=$period;
      $row++;
    }
  }
  return @clock;
}

sub wireg_bit{ # portname, bitwidth
  my ($name, $msb, $lsb)=@_;
  my $pt=$name;
  if (($msb!=0)||($lsb!=0)){
    $pt = "[".$msb.":".$lsb."] ".$name;
  }
  return($pt);
}
sub wireg_bit_inter_var{ # portname, bitwidth
  my ($name, $msb, $lsb)=@_;
  my $pt=$name;
  if (($msb!=0)||($lsb!=0)){
    $pt = "[".$msb.":".$lsb."] ".$name."_erks";
  }else{
      $pt=$pt."_erks";
  }
  return($pt);
}
sub get_bit_width{
  my ($name, $pt, $ct)=@_;
  my @port = @$pt;
  my @curtable=@$ct;
  # search in port table first
  for(my $col=0;$col<scalar(@{$port[0]});$col++){
    if ((Ex2Tbl::cmp_port_name($port[0][$col],$name) == 1) && (($port[1][$col] =~ /inout/i) || ($port[1][$col] =~ /input/i) || ($port[1][$col] =~ /output/i))){
      if($port[11][$col] ne "-"){
        my ($max,$min)=split(/:/,$port[11][$col]);
        return ($max,$min);
      }else{
        return ($port[7][$col], $port[8][$col]);
      }
    }
  }
  # search in current table later
  for(my $col=0;$col<scalar(@{$curtable[0]});$col++){
    if ($curtable[0][$col] eq $name){
      my $msb = 0;
      for (my $row=1;$row<scalar(@curtable);$row++){
        my $msb_tmp=$curtable[$row][$col];
        if ($msb_tmp =~ /^(-|S|\*)$/){
          $msb_tmp = 1;
        } elsif ($curtable[$row][$col] =~ /.*'.*/) {
          $msb_tmp=~s/'.*$//;
        } else {
          $msb_tmp=length(Ex2Tbl::dec2bin(Ex2Tbl::str2dec($curtable[$row][$col],0))) ;
        }
        $msb_tmp = $msb_tmp - 1;
        $msb = $msb_tmp if ($msb < $msb_tmp);
      }
      return ($msb, 0);
    }
  }
}

sub freq_mod{ # top.vams pg @table
  my ($file_name, $pg, $delay, $unit, $timescale, $table,$port,$reftl,$rnm,$total_port_num)=@_;
  my @tbl=Ex2Tbl::FilterTruthTable(@$table);
  my @port_table=@$port;
  my $check=0;
  my @freq_port=();
  my $inp="";
  my @in=();
  my @in_d=();
  my @in_m=();
  my @in_clock=();
  my $freq_check = 0;
  my %ref_var_tbl_list=%$reftl;
  open(ROOT_FILE, ">> $file_name");
  my $fnom = "10000";
  my $orginal_unit = $unit;
  my $orginal_timescale = $timescale;
  $unit=~s/Hz//;
  $unit=($unit =~ /k/i) ?       "1000" :
        ($unit =~ /M/ ) ?    "1000000" :
        ($unit =~ /G/ ) ? "1000000000" : "1";
  $timescale =~ s/\/.*$//;
  my $timescale_val = $timescale;
  $timescale_val =~ s/(fs|ps|ns|us|ms|s)//i;
  my $timescale_unit= $timescale;
  $timescale_unit =~ s/^\d+//;
  $timescale_unit = ($timescale_unit =~ /fs/i) ?  "1000000000000000":
                    ($timescale_unit =~ /ps/i) ?     "1000000000000":
                    ($timescale_unit =~ /ns/i) ?        "1000000000":
                    ($timescale_unit =~ /us/i) ?           "1000000":
                    ($timescale_unit =~ /ms/i) ?              "1000": "1";
  $fnom = int($timescale_unit)/(int($timescale_val)*int($unit));
  my @portname_list=();
  my @freq_name_list=();
  my @input_list=();
  my $print="";
  my %osc_dec;
  my $tt_inw=0; # total port width
  for(my $i=2;$i<scalar(@{$tbl[1]});$i++){
    next if (!defined $tbl[2][$i] || $tbl[2][$i] eq "" || $tbl[0][$i] eq "reg");
    my $port_name=$tbl[2][$i];
    my $port_width="-";
    if($port_name=~/\[.*\]/){
      $port_name=~s/\[.*\]//g;
      for(my $k=0;$k<scalar(@{$port_table[0]});$k++){
        if($port_name eq $port_table[10][$k]){
          $port_width=$port_table[11][$k];
          last;
        }
      }
    }
    if($tbl[0][$i] eq "input" && $tbl[1][$i]=~/\d/){
       print("WARNING ::: Care range of input port $tbl[2][$i] is ignored.\n");
       $tbl[1][$i] =~s/\d//g;
       $tbl[1][$i] =~s/-//g;
       $tbl[1][$i] =~s/.//g;
    }
    if($tbl[1][$i]=~/\d/){
      $freq_port[0][$check]=$tbl[0][$i];
      $freq_port[1][$check]=$port_name;
      $freq_port[2][$check]=$tbl[1][$i]; #max
      $freq_port[3][$check]=$tbl[1][$i]; #min
      $freq_port[2][$check]=~s/^.+\-(.+)$/$1/;
      $freq_port[3][$check]=~s/^(.+)\-.+$/$1/;
      $freq_port[4][$check]=$port_width;
      $print=$print.".$port_name($port_name), ";
      if(grep(/^$port_name$/,@portname_list)<1){
        if($port_width ne "-"){
          $osc_dec{$port_name}="  input \[$port_width\] $port_name;\n";
        }else{
          $osc_dec{$port_name}="  input $port_name;\n";
        }
      }
      $check++;
      if(grep(/^$port_name$/,@freq_name_list)<1){
        push(@freq_name_list,$port_name);
      }
    }
    if($tbl[0][$i] =~ /input|electrical_in/){
      push(@input_list,$tbl[2][$i]);
    }
    if(grep(/^$port_name$/,@portname_list)>0){
      next;
    }
    push(@portname_list,$port_name);
    if($tbl[1][$i]!~/\d/){
      $inp=$inp.".$port_name($port_name), ";
      if($port_width ne "-"){
        push(@in, "$port_name\[$port_width\]");
        push(@in_d, "\[$port_width\] $port_name");
        my ($msb, $lsb)=split(/:/,$port_width);
#        $tt_inw = $tt_inw + $msb - $lsb + 1
      }else{
        push(@in, "$port_name");
        push(@in_d, "$port_name");
#        $tt_inw++;
      }
      push(@in_m, $port_name);
#    }
    }
  }
  for(my $i=2;$i<scalar(@{$tbl[1]});$i++){
    my $port_name=$tbl[2][$i];
    if($tbl[0][$i] eq "clock"){
      $inp=$inp.".$port_name\_clk_period(".$port_name."_clk_period), ";
      push(@in_clock, $port_name."_clk_period");
    }
    if($tbl[0][$i] eq "high pulse width"){
      $inp=$inp.".high_pulse_width(high_pulse_width), ";
      push(@in_clock, "high_pulse_width");
    }
  }
  $tt_inw = scalar(@input_list);
  $print=~s/,\s$//;
  my $freq_check_cont = "";
  if($check!=0){
    my $loop=0;
    open(OC,"> FreqCheckTop.vams");
      my($se, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst)=localtime(time);
      my $exe_date=sprintf("%04d\/%02d\/%02d %02d:%02d:%02d",$year+1900,$mon+1,$mday,$hour,$min,$se);
      my $version=$ENV{'ERAKIS_VER'};
      my $user=$ENV{'USER'};

      print(OC "////////////////////////////////////////////////////////////////////////////\n");
      print(OC "/// DATE : $exe_date\n");
      print(OC "/// USER : $user\n");
      print(OC "/// TOOL : $version\n");
      print(OC "////////////////////////////////////////////////////////////////////////////\n");

      print(OC "\n//`include \"disciplines.vams\"\n\nmodule CheckFreq\(");

      my $input_temp="";
      if(scalar(@in_m) > 0){
          $input_temp = $input_temp.join(', ',@in_m);
      }
      if(scalar(@in_clock)>0){
        $input_temp = $input_temp.", " if ($input_temp ne "");
        $input_temp = $input_temp.join(', ',@in_clock);
      }
      $input_temp =$input_temp.", " if ($input_temp ne "");
      print(OC "$input_temp".join(', ',@freq_name_list).", erks_rst_freq, check_trigger);\n\n");
      my $pp=""; my $p=0;
      print(OC "  parameter PORT_NUM = $total_port_num;  // total port number\n");
      for(my $i=0;$i<scalar(@in_d);$i++){
        print(OC "  input $in_d[$i];\n");
      }
      foreach my $key (keys %osc_dec){
        print(OC "$osc_dec{$key}");
      }
#      print(OC "  input port_dir [PORT_NUM-1:0]; // port direction control\n");
#      print(OC "  input port_rising_enb [PORT_NUM-1:0]; // port rising control\n");
#      print(OC "  input port_falling_enb [PORT_NUM-1:0]; // port falling control\n");
      print(OC "  input erks_rst_freq;\n");
      print(OC "  input [31:0] check_trigger;\n\n");
      for(my $k=0;$k<scalar(@in_clock);$k++){
        print(OC "  input [31:0] $in_clock[$k];\n\n");
      }
      my @dup_check=();
      my @instance = ();
      my $index = 0;
      for (my $j=0;$j<scalar(@{$freq_port[1]});$j++){
        next if((grep (/^$freq_port[1][$j]$/,@dup_check) > 0) || $freq_port[0][$j] eq "input");
        push(@dup_check,$freq_port[1][$j]);
        if($freq_port[4][$j] ne "-"){
          my ($msb,$lsb) = split(/:/,$freq_port[4][$j]);
          for(my $k=$lsb;$k<=$msb;$k++){
            print(OC "  wreal freq_$freq_port[1][$j]_$k;\n");
          }
          for(my $k=$lsb;$k<=$msb;$k++){
            push(@instance, "  L2F \#($fnom) L2F_$index (.In($freq_port[1][$j]"."[$k]), .Out(freq_$freq_port[1][$j]"."_$k), .Rst(erks_rst_freq));\n");
            push(@instance, "  check_freq_$freq_port[1][$j]_$index #(PORT_NUM) cfp_$index($inp .$freq_port[1][$j]($freq_port[1][$j]), .freq(freq_$freq_port[1][$j]"."_$k), .check_trigger(check_trigger));\n");
            $index++;
          }
        }else{
          print(OC "  wreal freq_$freq_port[1][$j];\n");
          push(@instance, "  L2F \#($fnom) L2F_$index (.In($freq_port[1][$j]), .Out(freq_$freq_port[1][$j]), .Rst(erks_rst_freq));\n");
          push(@instance, "  check_freq_$freq_port[1][$j] #(PORT_NUM) cfp_$index($inp .$freq_port[1][$j]($freq_port[1][$j]), .freq(freq_$freq_port[1][$j]), .check_trigger(check_trigger));\n");
          $index++;
        }
      }
      print(OC "\n");
      print(OC join("",@instance));
      print(OC "\nendmodule\n\n");
      for(my $i=2;$i<scalar(@{$tbl[1]});$i++){
        my $port_name = $tbl[2][$i];
        $port_name =~ s/\s*//;
        $port_name =~ s/\[/_/;
        $port_name =~ s/\]//;
        if($tbl[1][$i]=~/\d/ && $tbl[0][$i] ne "input"){
          my $input_temp = "";
          print(OC "\nmodule check_freq_$port_name (");
          if (scalar(@in_m) > 0){
              $input_temp = $input_temp.join(', ',@in_m);
              $input_temp = $input_temp.', ';
          }
          if(scalar(@in_clock) > 0){
              $input_temp = $input_temp. join(', ',@in_clock);
              $input_temp = $input_temp.', ';
          }
          $input_temp =~ s/, $//g;
          print(OC " $input_temp , $port_name, freq, check_trigger);\n");
          print(OC "  parameter PORT_NUM = $total_port_num;  // total port number\n");
          print(OC "  parameter FIXED_0  = 2'b00; // value is fixed to 0\n");
          print(OC "  parameter FIXED_1  = 2'b01; // value is fixed to 1\n");
          print(OC "  parameter FIXED_X  = 2'b10; // value is fixed to x\n");
          print(OC "  parameter FIXED_Z  = 2'b11; // value is fixed to z\n");
          for(my $i=0;$i<scalar(@in_d);$i++){
            print(OC "  input $in_d[$i];\n");
          }
          for(my $i=0;$i<scalar(@in_clock);$i++){
            print(OC "  input [31:0] $in_clock[$i];\n");
          }
          print(OC "  input $port_name;\n");
          print(OC "  input wreal freq;\n");
          foreach my $key (keys %osc_dec){
            print(OC "$osc_dec{$key}") if ($key eq $freq_port[0][$loop]);
          }
          print(OC "  reg port_dir [PORT_NUM-1:0]; // port direction control\n");
          print(OC "  reg port_rising_enb [PORT_NUM-1:0]; // port rising control\n");
          print(OC "  reg port_falling_enb [PORT_NUM-1:0]; // port falling control\n");
          print(OC "  input [31:0] check_trigger;\n");
          print(OC "\n  real target = 100;\n  real tgtup, tgtdn;\n  reg b_it[3:0];\n  integer fixed_check,fixed_check_val;\n  integer  check_enable;\n");
          print(OC "  reg check_result;\n");
          print(OC "  reg assert_trigger;\n");
#          print(OC "  assign tgtup = target*(1+$freq_port[2][$loop]);\n  assign tgtdn = target*(1-$freq_port[3][$loop]);\n\n");
          print(OC "  always @ (target) begin\n");
          print(OC "    tgtup = target*(1+$freq_port[2][$loop]);\n");
          print(OC "    tgtdn = target*(1-$freq_port[3][$loop]);\n");
          print(OC "  end\n");

          my @var_ref_dec = ();
          my @var_ref_inst= ();
          foreach my $key (keys %ref_var_tbl_list){
            my @ref_table = @{$ref_var_tbl_list{$key}};
            my @port_ref = Ex2Tbl::GetPortRefTable($ref_table[1],\@ref_table,\@port_table,$rnm);
            my $tmp_inst = "  $ref_table[1][0] $ref_table[1][0]_Ref(";
            for (my $j=0;$j<scalar(@{$port_ref[0]});$j++){
              if($port_ref[1][$j] ne "-1"){
                if($port_ref[8][$j] eq ""){
                  $tmp_inst = $tmp_inst." .$port_ref[7][$j]"."($port_ref[7][$j]),";
                }elsif($port_ref[8][$j] ne "-"){
                  my $name = $port_ref[7][$j];
                  $name =~ s/\[.*$//;
                  $tmp_inst = $tmp_inst." .$name"."($name),";
                }
              }
            }
            for (my $j=0;$j<scalar(@{$port_ref[0]});$j++){
              if($port_ref[1][$j] eq "-1" && $port_ref[2][$j] eq "0"){ #ref port
                $tmp_inst = $tmp_inst." .$port_ref[7][$j]"."($port_ref[7][$j]),";
                push(@var_ref_dec,"  reg [63:0] $port_ref[0][$j];\n");
              }
            }
            $tmp_inst =~ s/,$/);/;
            push(@var_ref_inst,$tmp_inst);
          }
          print(OC join("",@var_ref_dec));
          print(OC join("\n",@var_ref_inst)."\n\n");

          print(OC "  always\@(".join(' or ',@input_list).") begin\n");
          my @port_ref_table = Ex2Tbl::GetPortRefTable($tbl[2],\@tbl,\@port_table,$rnm);
          my $first_cond = 1;
          my $target_val = "";
          my $fixed_check = 0;
          for(my $l=4;$l<scalar(@tbl);$l++){
              next if ($tbl[$l][1] =~ /^_?ERKS_HOLD/);
              my $pt = "";
              for(my $j=2;$j<scalar(@{$tbl[$l]});$j++){
                  if($tbl[0][$j] eq "clock"){
                    if($tbl[$l][$j] =~ /^\d/){
                       $pt = $pt."($tbl[2][$j]_clk_period == $tbl[$l][$j])&&";
                    } elsif($tbl[$l][$j] =~ /FIXED_/){
                      my $fix_value = $tbl[$l][$j];
                      $fix_value =~ s/FIXED_/1'b/;
                      $fix_value =~ s/^(x|z)$/$1/i;
                      $pt = $pt."($tbl[2][$j] == $fix_value)&&";
                    }
                  }
                  if($tbl[0][$j] eq "high pulse width"){
                    if($tbl[$l][$j] ne ""){
                      $pt = $pt."(high_pulse_width == $tbl[$l][$j])&&";
                    }
                  }
                  $pt = $pt."(port_dir[$port_ref_table[1][$j]] === 1'b0)&&" if ($tbl[0][$j] =~ /inout/ && $tbl[$l][$j] =~ /^_/);
                  $pt = $pt."(port_dir[$port_ref_table[1][$j]] === 1'b1)&&" if ($tbl[0][$j] =~ /inout/ && $tbl[$l][$j] !~ /^_/);
                  if($port_ref_table[4][$j] eq "-2" || $port_ref_table[4][$j] eq "1" || $tbl[0][$j] =~ /output|electrical_out/ || $tbl[$l][$j] =~ /^\*$/ || $tbl[$l][$j] =~ /^_/){
                    next;
                  }
                  if ($tbl[$l][$j] =~ /^RISE$/i) {
                      $pt = $pt."(port_rising_enb[$port_ref_table[1][$j]] === 1'b1)&&(port_falling_enb[$port_ref_table[1][$j]] === 1'b0)&&";
                  } elsif ($tbl[$l][$j] =~ /^FALL$/i){
                      $pt = $pt."(port_rising_enb[$port_ref_table[1][$j]] === 1'b0)&&(port_falling_enb[$port_ref_table[1][$j]] === 1'b1)&&";
                  } else {
                      $pt = $pt."(port_rising_enb[$port_ref_table[1][$j]] === 1'b0)&&(port_falling_enb[$port_ref_table[1][$j]] === 1'b0)&&";
                  }
                  if ($tbl[$l][$j] =~ /^-$/ || $tbl[$l][$j] =~ /^S$/i){
                      $pt= $pt."(($port_ref_table[7][$j] === 1'b0)||($port_ref_table[7][$j] === 1'b1))&&";
                  }elsif ($tbl[$l][$j] =~ /^RISE$/i){
                      $pt= $pt."($port_ref_table[7][$j] === 1'b1)&&";
                  }elsif ($tbl[$l][$j] =~ /^FALL$/i){
                      $pt= $pt."($port_ref_table[7][$j] === 1'b0)&&";
                  }elsif ($tbl[$l][$j] =~ /^EXP_NOT_/i){
                      my $val = $tbl[$l][$j];
                      $val =~ s/EXP_NOT_//;
                      $val =~ s/_.*$//;
                      $val = "1'b".$val;
                      $pt = $pt."($port_ref_table[7][$j] !== $val)&&";
                  }else{
                      $pt= $pt."($port_ref_table[7][$j] === 1'b$tbl[$l][$j])&&";
                  }
              }
              $pt=~s/\&\&$//;
              $pt = "1" if ($pt =~ /^\s*$/); # Dont care input (all *)
              my $val = $tbl[$l][$i];
              if($first_cond == 1) {
                  print(OC "    if ($pt) ");
                  $first_cond = 0;
              } else {
                  print(OC "    else if ($pt) ");
              }
              $val =~ s/^_//;
              $val =~ s/^(x|z)$/1'b$1/i; ##'
                  if ($val =~ /^F?I?X?E?D?_?(0|1|X|Z)$/) {
                      $fixed_check = 1;
                      print(OC "begin target = b_it[$val]; fixed_check = 1; fixed_check_val = $val; end\n");
                  } elsif($val eq "*"){
                      print(OC "begin check_enable = 0; end\n");
                  }else{
                      print(OC "begin target = $val; fixed_check = 0; end\n");
                  }
          }

          print(OC "  end\n\n");

#          print(OC "  check_freq_$port_name: assert property (\n");
#          print(OC "    @(check_trigger) disable iff(check_trigger==0 || fixed_check == 1)\n");
#          print(OC "    (freq >= tgtdn && freq <= tgtup)\n");
#          print(OC "  ) \$display(\"PASS::: $tbl[2][$i] freq=\%0f, target freq=\%0f\",freq,target); else\n");
#          print(OC "    \$display(\"FAIL::: $tbl[2][$i] freq=\%0f, target freq=\%0f\",freq,target);\n\n");
#          if ($fixed_check eq "1") {
#            print(OC "  check_fixed_freq_$port_name: assert property (\n");
#            print(OC "    @(check_trigger) disable iff(check_trigger==0 || fixed_check == 0)\n");
#            print(OC "    ($tbl[2][$i] === b_it[fixed_check_val])\n");
#            print(OC "  ) \$display(\"PASS::: $tbl[2][$i] $tbl[2][$i]=\%0d, target fixed \%0d\",$tbl[2][$i],b_it[fixed_check_val]); else\n");
#            print(OC "    \$display(\"FAIL::: $tbl[2][$i] $tbl[2][$i]=\%0d, target fixed \%0d\",$tbl[2][$i],b_it[fixed_check_val]);\n\n");
#          }
          print(OC "  always @(check_trigger) begin\n");
          print(OC "    if(check_trigger>0 && check_enable==1) begin\n");
          print(OC "      if(fixed_check == 1)begin\n");
          print(OC "        if (($tbl[2][$i] === b_it[fixed_check_val]) && (freq === 0)) begin\n");
          print(OC "        \$display(\"PASS::: $tbl[2][$i] $tbl[2][$i]=%0d, target fixed %0d\",$tbl[2][$i],b_it[fixed_check_val]);\n");
          print(OC "        check_result  = 1;\n");
          print(OC "        end else begin\n");
          print(OC "        \$display(\"FAIL::: $tbl[2][$i] $tbl[2][$i]=%0d, target fixed %0d, freq=%0f\",$tbl[2][$i],b_it[fixed_check_val], freq);\n");
          print(OC "        check_result  = 0;\n");
          print(OC "        end\n");
          print(OC "      end else begin\n");
          print(OC "        if (freq >= tgtdn && freq <= tgtup) begin\n");
          print(OC "        \$display(\"PASS::: $tbl[2][$i] freq=%0f, target freq=%0f\",freq,target);\n");
          print(OC "        check_result  = 1;\n");
          print(OC "        end else begin\n");
          print(OC "        \$display(\"FAIL::: $tbl[2][$i] freq=%0f, target freq=%0f\",freq,target);\n");
          print(OC "        check_result  = 0;\n");
          print(OC "        end\n");
          print(OC "      end\n");
          print(OC "      #1\n");
          print(OC "      assert_trigger <= ~assert_trigger;\n");
          print(OC "      check_enable = 1;\n");
          print(OC "    end\n");
          print(OC "  end\n\n");
          print(OC "  initial begin\n");
          print(OC "    b_it[3]=1'bz;\n");
          print(OC "    b_it[2]=1'bx;\n");
          print(OC "    b_it[1]=1'b1;\n");
          print(OC "    b_it[0]=1'b0;\n");
          print(OC "    fixed_check = 0;\n");
          print(OC "    fixed_check_val = 0;\n");
          print(OC "    assert_trigger = 0;\n");
          print(OC "    check_result = 1;\n");
          print(OC "    check_enable = 1;\n");
          print(OC "  end\n");
          print(OC "endmodule\n\n");
          $loop++;
        }
      }
    close(OC);
    print(ROOT_FILE "  CheckFreq #(PORT_NUM) CF\(");
    $print="";
    foreach my $port(@in_m){
      $print .= ".$port($port), ";
    }
    foreach my $port(@in_clock){
      $print .= ".$port($port), ";
    }
    foreach my $port(@freq_name_list){
      $print .= ".$port($port), ";
    }
    $print=~ s/, $//;
    print(ROOT_FILE "$print, .erks_rst_freq(erks_rst_freq), .check_trigger(i0));\n\n");
    for(my $i=0;$i<scalar(@freq_name_list);$i++){
      print(ROOT_FILE "  reg check_result_$freq_name_list[$i];\n");
      print(ROOT_FILE "  reg assert_trigger_$freq_name_list[$i];\n");
      print(ROOT_FILE "  assign CF.cfp_$i.port_dir = port_dir_ctrl;\n");
      print(ROOT_FILE "  assign CF.cfp_$i.port_rising_enb = port_rising_enb;\n");
      print(ROOT_FILE "  assign CF.cfp_$i.port_falling_enb = port_falling_enb;\n");
      print(ROOT_FILE "  assign check_result_$freq_name_list[$i] = CF.cfp_$i.check_result ;\n");
      print(ROOT_FILE "  assign assert_trigger_$freq_name_list[$i] = CF.cfp_$i.assert_trigger;\n");
    }
    close(ROOT_FILE);
#    $freq_check_cont = "\`include \"".$ENV{'ERAKIS_LIB'}."/L2F.vams\"\n\`include \"../FreqCheckTop.vams\"\n\n";
    $freq_check_cont = "";  
    $freq_check = 1;
  } else {
    $freq_check_cont = "";  
  }
  my $file_tmp = $file_name."_tmp";
  open(TB, "< $file_name");
    return(1) if(!(fileno(TB)));
    open(TMP, "> $file_tmp");
      return(1) if(!(fileno(TMP)));
      foreach my $line(<TB>){
        if($line eq "FREQ_CHECK\n"){
          $line =~ s/FREQ_CHECK\n/$freq_check_cont/;
        }
        print(TMP "$line");
      }
    close(TMP);
  close(TB);
  open(TB, "> $file_name");
    return(1) if(!(fileno(TB)));
    # tmp file open
    open(TMP,"< $file_tmp");
      return(1) if(!(fileno(TMP)));
      foreach my $line(<TMP>){
        print(TB "$line");
      }
    close(TMP);
  close(TB);
  unlink($file_tmp);
  return $freq_check;
}

### make For AMS testbench ###
sub MakeAmsTestBench{ #[0]file name [1]timescale [2]cell name [3]vct file name [4]ast file name [5]pg [6]-port table 
  my ($rnm, $file, $timescale, $cell, $vct, $ast, $pg, $delay, $unit, $sim, $wave, $include, $lfo, $no_back, $sdf, $p0rt, $tbl, $opth, $split, $insq, $reftl,$outseq_,$port_ref,$rfseq_,$param_tbl,$ex_ast,$ex_ptn,$ex_ast_file,$ex_ptn_file,$exclude)=@_;
  my @port=@$p0rt;
  my ($ex,$freq_check)=MakeTestBench(@_);
  if($ex==1){
    return(1,0);
  }

  system("mv $file temp_ss\n");
  open(SV,"< temp_ss");
  open(OV,"> $file");
    return(1,0) if(!fileno(SV) || !fileno(OV));
    foreach my $line(<SV>){
      if($line =~ /$cell\sTopInst/){
        $line=~s/$cell\sTopInst/AMSTOP AmsTop/;
      }
      print(OV $line);
    }
  close(OV);
  close(SV);
  unlink("temp_ss");

  my $path=`pwd`;
  $path=~s/\n//;
  open(TB,"> AmsTop.vams");
    return(1,0) if(!(fileno(TB)));
    my($se, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst)=localtime(time);
    my $exe_date=sprintf("%04d\/%02d\/%02d %02d:%02d:%02d",$year+1900,$mon+1,$mday,$hour,$min,$se);
    my $version=$ENV{'ERAKIS_VER'};
#    my $user=$ENV{'USERNAME'};
    my $user=$ENV{'USER'};

    # header
    print(TB "////////////////////////////////////////////////////////////////////////////\n");
    print(TB "/// DATE : $exe_date\n");
    print(TB "/// USER : $user\n");
    print(TB "/// TOOL : $version\n");
    print(TB "////////////////////////////////////////////////////////////////////////////\n");

    # include discipline
    print(TB "\n`include \"disciplines.vams\"\n\nmodule AMSTOP\(");
    my $print="";
    my @portname_list=();
    for(my $i=0;$i<scalar(@{$port[0]});$i++){
      if(($pg==1 || ($pg==0 && ($port[1][$i] !~ /power|ground/)))&&(grep(/^$port[10][$i]$/,@portname_list)<1)){
        $print=$print."$port[10][$i], ";
        push(@portname_list,$port[10][$i]);
      }
    }
    $print=~s/,\s$//;
    print(TB "$print\)\;\n\n");

    # port declare
    $print="";
    @portname_list=();
    for(my $i=0;$i<scalar(@{$port[0]});$i++){
      if((grep(/^$port[10][$i]$/,@portname_list)<1)){
        if ($port[11][$i] eq "-"){
          if ($port[1][$i] =~/input|electrical_in|clock/){
            $print=$print."  input   ".wireg_bit($port[10][$i],0,0)."\;\n";
          }elsif($port[1][$i] =~ /output|electrical_out/){
            $print=$print."  output  ".wireg_bit($port[10][$i],0,0)."\;\n";
          }elsif($port[1][$i] =~ /inout/){
            $print=$print."  inout  ".wireg_bit($port[10][$i],0,0)."\;\n";
          }
        }else{
          my $msb=(split(/:/,$port[11][$i]))[0];
          my $lsb=(split(/:/,$port[11][$i]))[1];
          if ($port[1][$i] =~/input|electrical_in/){
            $print=$print."  input [$msb:$lsb] $port[10][$i]\;\n";
          }elsif($port[1][$i] =~ /output|electrical_out/){
            $print=$print."  output [$msb:$lsb] $port[10][$i]\;\n";
          }elsif($port[1][$i] =~ /inout/){
            $print=$print."  inout [$msb:$lsb] $port[10][$i]\;\n";
          }
        }
        push(@portname_list, $port[10][$i]);
      }
    }
    print(TB "$print\n");
    $print="";
    @portname_list=();
    for(my $i=0;$i<scalar(@{$port[0]});$i++){
      if(($pg==1 || ($pg==0 && ($port[1][$i] !~ /power|ground/))) && (grep(/^$port[10][$i]$/,@portname_list)<1)){
        if ($port[11][$i] eq "-"){
          if (($rnm == 1)&&($port[1][$i] !~ /power|ground/)) {
              $print=($port[1][$i] =~ /power|ground|electrical_in/) ? $print."  wreal ".wireg_bit($port[10][$i],0,0)."\;\n  electrical _".wireg_bit($port[10][$i],0,0)."\;\n" :
                     ($port[1][$i] =~ /input/) ? $print."  wire ".wireg_bit($port[10][$i],0,0)."_\;\n" :
                     ($port[1][$i] =~ /electrical_out/) ? $print."  wreal ".wireg_bit($port[10][$i],0,0)."\;\n" :  $print;
          } else {
              $print=($port[1][$i] =~ /power|ground|electrical_in/) ? $print."  real ".wireg_bit($port[10][$i],0,0)."_\;\n"."  electrical _".wireg_bit($port[10][$i],0,0)."\;\n" :
                     ($port[1][$i] =~ /input/) ? $print."  wire ".wireg_bit($port[10][$i],0,0)."_\;\n" : $print;
          }
        }else{
          my $msb=(split(/:/,$port[11][$i]))[0];
          my $lsb=(split(/:/,$port[11][$i]))[1];
          if (($rnm == 1)&&($port[1][$i] !~ /power|ground/)) {
                $print=($port[1][$i] =~ /power|ground|electrical_in/) ? $print."  wreal $port[10][$i]\[$msb:$lsb\]\;\n  electrical _".$port[10][$i]."\[$msb:$lsb\]"."\;\n" :
                       ($port[1][$i] =~ /input/) ? $print."  wire \[$msb:$lsb\] $port[10][$i]_\;\n" : $print;
          }else{
                $print=($port[1][$i] =~ /power|ground|electrical_in/) ? $print."  real $port[10][$i]\[$msb:$lsb\]"."_\;\n  electrical _$port[10][$i]\[$msb:$lsb\];\n" :
                       ($port[1][$i] =~ /input/) ? $print."  wire \[$msb:$lsb\] $port[10][$i]_\;\n" : $print;
          }
        }
        push(@portname_list,$port[10][$i]);
      }
    }
#    if ($rnm == 1) {
#      print(TB "  nettype nt::SVreal SVreal;\n");
#    }
    print(TB "$print\n");

    # analog block
    my $is_analog_on=0;
    $print="";
    for(my $i=0;$i<scalar(@{$port[0]});$i++){
      if($port[1][$i]=~/electrical_in/){
        if($is_analog_on==0){
          $print=$print."\n";
          $print="  analog begin\n";
          $is_analog_on=1;
        }
        if($rnm != 1){
          $print=$print."    @\(posedge $port[0][$i]\)\n      $port[0][$i]_ = $port[4][$i]\;\n";
          $print=$print."    @\(negedge $port[0][$i]\)\n      $port[0][$i]_ = 0.0\;\n    V\(_$port[0][$i]\) <+ $port[0][$i]_\;\n";
        }else{
          $print=$print."    V\(_$port[0][$i]\) <+ $port[0][$i]\;\n";
        }
      }
    }
    print(TB "$print");
    if($is_analog_on==1){
      print(TB "  end\n\n");
    }
    $print="";
  # print out digital block for output analog port
    @portname_list=();
    for(my $i=0;$i<scalar(@{$port[0]});$i++){
      if($port[1][$i] =~ /input/ && (grep(/^$port[10][$i]$/,@portname_list)<1)){
        $print=$print."  assign  $port[10][$i]_ = $port[10][$i]\;\n";  
      }
      push(@portname_list,$port[10][$i]);
    }

    print(TB "$print\n");

    # connection
    print(TB "  $cell TopInst\(");
    $print="";
    @portname_list=();
    for(my $i=0;$i<scalar(@{$port[0]});$i++){
      if($port[1][$i] =~ /electrical_in/){
        $print=$print.".$port[0][$i]\(_$port[0][$i]\), ";
      }elsif($port[1][$i] =~/input/ && grep(/$port[10][$i]/, @portname_list) < 1){
        $print=$print.".$port[10][$i]\($port[10][$i]_\), ";
      }elsif(($pg==1 || ($pg==0 && ($port[1][$i] !~ /power|ground/)))&&(grep(/^$port[10][$i]$/,@portname_list)<1)){
        $print=$print.".$port[10][$i]\($port[10][$i]\), ";
      }
      push(@portname_list,$port[10][$i]);
    }
    $print=~s/,\s$//;
    print(TB "$print\);\n");

    # footer
    print(TB "\nendmodule\n");

  close(TB);
  return(0,$freq_check);
}

### Make Test vector ### 
sub MakeTestVector{#[0] last ptn [1] file name [2] delay [3] ams [4] truth table [5] port table [6] option -rnm [7] input timing sequence [8] -split option [9] testbench file [10]option -tb
  my ($last_ptn, $file, $delay, $tbl,$ptbl,$rnm,$inseq_,$split, $tb_file, $testbench,$port_ref_table_,$en_msg,$vtbl,$rfseq_,$message_chk,$num_ex_ptn)=@_;
  my @table=@$tbl;
  my @port_table=@$ptbl;
  my @inseq=();
  if(ref($inseq_)){
   @inseq = @$inseq_;   
  }
  my @rfseq=@$rfseq_;
  my @port_ref_table=@$port_ref_table_;
  my $file_tmp="tmp.v"; 
  my $fin_time=0;
  # Put header
  my($se, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst)=localtime(time);
  my $exe_date=sprintf("%04d\/%02d\/%02d %02d:%02d:%02d",$year+1900,$mon+1,$mday,$hour,$min,$se);
  my $version=$ENV{'ERAKIS_VER'};
#  my $user=$ENV{'USERNAME'};
  my $user=$ENV{'USER'};
  # ptn write out
  my @in=();
  my @row_list=();
  my $msg_col=-1;
  my @port_list=();
  my $is_clock_ctrl = 0;
  my $is_pulse_width = 0;
  for(my $j=2;$j<scalar(@{$table[1]});$j++){
    if($table[0][$j] eq "input" || $table[0][$j] eq "inout"){
      push(@port_list,$table[2][$j]);
    }
    if ($table[0][$j] eq "clock") {
      $is_clock_ctrl++;
    }
    if ($table[0][$j] eq "high pulse width") {
      $is_pulse_width++;
    }
  }
  for(my $j=2;$j<scalar(@{$table[1]});$j++){
    if($table[0][$j] eq "message"){
      $msg_col=$j;
      last;
    }
  }
  my $start_index = 4;
  my $tvt_unit=6;
  $tvt_unit=$tvt_unit + $is_clock_ctrl + $is_pulse_width;
  my $end_index = scalar(@table);
  my $step = int((scalar(@table) - 4)/$split);
  $step = 1 if (int((scalar(@table) - 4)/$split) == 0);
  if ($split > 1){
     $end_index = $step + 4;
  }
  my $test_size = ($end_index - $start_index)*$tvt_unit + $tvt_unit;
  my $fix_num = 3; # number of digit after point
  my $omit_vector = 0;
  my @pat_array=();
  my @msg_array=();
  my @msg_array_org=();
  print("WARNING ::: Number of split patterns exceed number of lines in truth table.\n") if ($split > scalar(@table)-4);
  for (my $index = 0;$index<$split; $index++){
    my $PTN;
    if ($index == ($split - 1)){
      $end_index = scalar(@table);
    }else{
      $end_index = $start_index + $step;
    }
    $end_index = scalar(@table) if ($end_index > scalar(@table));

    # Open file to write
    open ($PTN, ">$file_tmp");
    # Check open successfully or not
    return(1) if (!(fileno($PTN)));
    # header
    print($PTN "////////////////////////////////////////////////////////////////////////////\n");
    print($PTN "/// DATE : $exe_date\n");
    print($PTN "/// USER : $user\n");
    print($PTN "/// TOOL : $version\n");
    print($PTN "////////////////////////////////////////////////////////////////////////////\n");
    # param, bit array, integer
    $delay=$delay-1;
#    if($num_ex_ptn == 0){
      print($PTN "TESTVECTORSIZE\n");
#    }
    for(my $i=$start_index;$i<$end_index;$i++){
      @{$in[0]}=@{$table[0]}; # in/out
      @{$in[1]}=@{$table[1]}; # D/A
      @{$in[2]}=@{$table[2]}; # port name
      @{$in[3]}=@{$table[3]}; # SA(level)
      @{$in[4]}=("-")x scalar(@{$table[$i]}); # value
      @{$in[5]}=@{$port_ref_table[1]}; # port_index mapped with test bench
      @{$in[6]}=@{$port_ref_table[2]}; # -2: none, -1: supply, 0: normal, 1: real port
      @{$in[7]}=@{$port_ref_table[4]}; # -2: none, -1: supply, 0: input/electrical_in, 1: output/electrical_out, 2: inout
      @{$in[8]}=@{$port_ref_table[6]}; # real port attribute
      @{$in[9]}=@{$table[$i]}; # value
      if ($table[$i][1] =~ /_?ERKS_SUBHOLD/) {
        $omit_vector += 1;
        next;
      }
      my $pat="";
      my $msg="";
      my $msg_org="";
      my $port_val="";
      ($pat,$msg,$msg_org,$port_val)=MakeMsgPattern($msg_col,$rnm,\@in,\@port_table,$fix_num,\@port_ref_table,$vtbl);
      if ($msg ne ""){
        push(@pat_array,$pat);
        push(@msg_array,$msg);
        push(@msg_array_org,$msg_org);
      }
      my ($in_,$row_list_) = Ex2Tbl::GetTimingSeq(\@inseq,\@in,\@port_table,$rfseq_);
      my @seq_tbl=@$in_;
      my @tmp_row=@$row_list_;
      if(defined $tmp_row[0]){
        for (my $j=0;$j<scalar(@tmp_row);$j++){
          if (grep(/$tmp_row[$j]/,@row_list) < 1){
            push(@row_list,$tmp_row[$j]);
          }
        }
      }
      print_ptn($PTN,$rnm,\@in,\@port_table,$port_val,\@port_list,\@seq_tbl);
      print($PTN "\n");
    }

    close($PTN);

    # for add editing
    if ($split > 1){
      my $pat_name = $file;
      my $ext = $file;
      $pat_name =~ s/\.\w+$//;
      $ext =~ s/$pat_name//;
      open(PTN,"> "."$pat_name"."_$index"."$ext");
    }else{
      open(PTN,"> $file");
    }
      return(1) if(!(fileno(PTN)));
      # tmp file open
      open(TMP,"< $file_tmp");
        return(1) if(!(fileno(TMP)));
        foreach my $line(<TMP>){
          if($line eq "TESTVECTORSIZE\n"){
            my $size = ($end_index - $start_index - $omit_vector)*$tvt_unit + $tvt_unit; # test vector + 4(size)
            printf(PTN "%b \/\/ size of test vector (%d*%d=%d) + %d(header)\n",$size,($size-$tvt_unit)/$tvt_unit,$tvt_unit,$size-$tvt_unit,$tvt_unit);
            # print care range corresponding to index in test bench
            for (my $i=0;$i<scalar(@{$port_ref_table[0]});$i++){
              if ($port_ref_table[1][$i] ne "-1"){
                if($table[0][$i] ne "reg"){
                  printf(PTN "%04b",$port_ref_table[5][$i]);
                }else{
                  printf(PTN "%04b",2);
                }
              }
            }
            print(PTN "\n");
            # print port type corresponding to index in test bench
            for (my $i=0;$i<scalar(@{$port_ref_table[0]});$i++){
              if ($port_ref_table[1][$i] ne "-1"){
                if($table[0][$i] ne "reg"){
                  printf(PTN "%04b",$port_ref_table[2][$i]);
                }else{
                  printf(PTN "%04b",0);
                }
              }
            }
            print(PTN "\n");
            # print port rising period
            for (my $i=0;$i<scalar(@{$port_ref_table[0]});$i++){
              if ($port_ref_table[1][$i] ne "-1"){
                my $period = 0;
                for (my $j=1;$j<scalar(@rfseq);$j++){
                  if ($rfseq[$j][0] !~ /^Exclude_Constraint/){
                    if (Ex2Tbl::cmp_port_name($port_ref_table[0][$i],$rfseq[$j][2]) eq "1"){
                      $period = $rfseq[$j][3];
                    }
                  }
                }
                printf(PTN "%064b",$period);
              }
            }
            print(PTN "\n");
            # print port falling period
            for (my $i=0;$i<scalar(@{$port_ref_table[0]});$i++){
              if ($port_ref_table[1][$i] ne "-1"){
                my $period = 0;
                for (my $j=1;$j<scalar(@rfseq);$j++){
                  if ($rfseq[$j][0] !~ /^Exclude_Constraint/){
                    if (Ex2Tbl::cmp_port_name($port_ref_table[0][$i],$rfseq[$j][2]) eq "1"){
                      $period = $rfseq[$j][4];
                    }
                  }
                }
                printf(PTN "%064b",$period);
              }
            }
            print(PTN "\n");
            # print latch port indicator
            for (my $i=0;$i<scalar(@{$port_ref_table[0]});$i++){
              if ($port_ref_table[1][$i] ne "-1"){
                printf(PTN "%01b",$port_ref_table[9][$i]);
              }
            }
            print(PTN "\n"."000\n"x($tvt_unit-6));
          }else{
            print(PTN "$line");
          }
        }
      close(TMP);
    close(PTN);
    $start_index = $end_index;
  }

  if ($testbench == 1){
    open(TB, "< $tb_file");
      return(1) if(!(fileno(TB)));
      open(TMP, "> $file_tmp");
        return(1) if(!(fileno(TMP)));
        foreach my $line(<TB>){
          if($line =~ "parameter TEST_VECTOR_SIZE"){
            $test_size = $test_size*2; # for backup, the test size is multiply to 2
            if ($test_size > $global_test_size) {
                $global_test_size = $test_size;
            }
            $line =~ s/=.*;/= $global_test_size;/;
          }
          print(TMP "$line");
        }
      close(TMP);
    close(TB);
    open(TB, "> $tb_file");
      return(1) if(!(fileno(TB)));
      # tmp file open
      open(TMP,"< $file_tmp");
        return(1) if(!(fileno(TMP)));
        foreach my $line(<TMP>){
          print(TB "$line");
        }
      close(TMP);
    close(TB);
  }

  # make DUV message check script
  if ($msg_col != -1 and $en_msg == 1){
    MakeDUVMsgChk(\@pat_array,\@msg_array,\@msg_array_org,$message_chk); 
  }

  #  correct the clock for next running (FSM test vector)

  unlink($file_tmp);
  $fin_time=$fin_time+$delay*2;
  my @re=(0,$fin_time);
  return(@re);
}

sub MakeCompleteTestVector{#[0] last ptn [1] file name [2] delay [3] ams [4] truth table [5] port table [6] option -rnm [7] input timing sequence [8] -split option [9] testbench file [10]option -tb
  my ($last_ptn, $file, $delay, $tbl_,$ptbl_,$rnm,$inseq_,$split,$tb_file,$testbench,$port_ref_table_,$vtbl,$rfseq_,$message_chk,$num_ex_ptn)=@_;
  my @table = @$tbl_;
  my @port_ref_table = @$port_ref_table_;
  my @list_io = ();
  my $fix_num = 3;
  for(my $i=2;$i<scalar(@{$table[0]});$i++){
    if($table[0][$i] eq "inout"){
      my $port_name = $table[2][$i];
      if ($port_name =~ /\[.*\]/){
        $port_name =~ s/\[.*$//g;
      }
      if (grep (/^$port_name$/,@list_io) < 1){
        push(@list_io,$port_name);
      }
    }
  }
  my @cpl_table=();
  my @row_list=();
  my @port = @$ptbl_;
  my $period = 0;
  my $port_type = 0;
  # find the clock period in case of -cpl
  for(my $i=2; $i<scalar(@{$port[0]});$i++){
    $port_type = Ex2Tbl::get_port_type($port[10][$i], @port);
    if( $port_type eq "clock"){
      $period = $port[6][$i];
    }
  }
  # Make copletion table:
  @{$cpl_table[0]}=@{$table[0]}; # in/out
  @{$cpl_table[1]}=@{$table[2]}; # port name
  @{$cpl_table[2]}=@{$table[3]}; # SA(level)
  my $row = 3;
  # inout port act as input port
  for(my $col=0;$col<scalar(@{$table[0]});$col++){
    if($table[0][$col] !~ /^(input|inout|output|power|ground|supply)$/){
      if ($table[0][$col] eq "message" || $table[0][$col] eq "action"){
        $cpl_table[$row][$col]="-";
      } elsif ($table[0][$col] eq "clock"){
        $cpl_table[$row][$col]=$period;  
      } elsif ($table[0][$col] eq "high pulse width"){
        $cpl_table[$row][$col]=$period/2;  
      } elsif ($table[0][$col] eq "FB"){
        $cpl_table[$row][$col]="*";
      }else{
        $cpl_table[$row][$col]="";
      }
      next;
    }
    $cpl_table[$row][$col]="*";
  }
  $row++;
  foreach my $io (@list_io){
    # inout port act as output port
    for(my $col=0;$col<scalar(@{$table[0]});$col++){
      if($table[0][$col] !~ /^(input|inout|output|power|ground|supply)$/){
#        $cpl_table[$row][$col]="";
        $cpl_table[$row][$col]=$cpl_table[$row-1][$col];
        next;
      }
      if (Ex2Tbl::cmp_port_name($table[2][$col],$io) == 1){
        $cpl_table[$row][$col]="_*";
      }else{
        $cpl_table[$row][$col]="*";
      }
    }
    $row++;
  }
  # add D/A row for test generation
  my @test_table = ();
  @{$test_table[0]}=@{$cpl_table[0]}; # in/out
  @{$test_table[1]}=@{$table[1]}; # D/A
  @{$test_table[2]}=@{$cpl_table[1]}; # port name
  @{$test_table[3]}=@{$cpl_table[2]}; # SA(level)
  $row = 4;

  for(my $i=3;$i<scalar(@cpl_table);$i++){
    @{$test_table[$row]}=@{$cpl_table[$i]};
    $row++;
  }

  # make DUV message check script
  my $msg_col=-1;
  my @pat_array=();
  my @msg_array=();
  my @msg_array_org=();
  my @in = ();
  for(my $j=2;$j<scalar(@{$table[1]});$j++){
    if($table[0][$j] eq "message"){
      $msg_col=$j;
      last;
    }
  }
  if ($msg_col != -1){
    for(my $i=4;$i<scalar(@table);$i++){
      @{$in[0]}=@{$table[0]}; # in/out
      @{$in[1]}=@{$table[1]}; # D/A
      @{$in[2]}=@{$table[2]}; # port name
      @{$in[3]}=@{$table[3]}; # SA(level)
      @{$in[4]}=("-")x scalar(@{$table[$i]}); # value
      @{$in[5]}=@{$port_ref_table[1]}; # port_index mapped with test bench
      @{$in[6]}=@{$port_ref_table[2]}; # -2: none, -1: supply, 0: normal, 1: real port
      @{$in[7]}=@{$port_ref_table[4]}; # -2: none, -1: supply, 0: input/electrical_in, 1: output/electrical_out, 2: inout
      @{$in[8]}=@{$port_ref_table[6]}; # real port attribute
      @{$in[9]}=@{$table[$i]}; # value
      my $pat="";
      my $msg="";
      my $msg_org="";
      my $port_val="";
      ($pat,$msg,$msg_org,$port_val)=MakeMsgPattern($msg_col,$rnm,\@in,$ptbl_,$fix_num,\@port_ref_table,$vtbl);
      if ($msg ne ""){
        push(@pat_array,$pat);
        push(@msg_array,$msg);
        push(@msg_array_org,$msg_org);
      }
    }
    MakeDUVMsgChk(\@pat_array,\@msg_array,\@msg_array_org,$message_chk); 
  }
  my @re=MakeTestVector($last_ptn, $file, $delay, \@test_table,$ptbl_,$rnm,$inseq_,$split,$tb_file,$testbench,$port_ref_table_,0,$vtbl,$rfseq_,$message_chk,$num_ex_ptn);
  return(@re);
}

### print ptn for loop ###
sub print_ptn{ # [0]:file handle [1] option -rnm [2]-:io/da/port/sa/val array
  my ($FILE,$rnm,$table_,$ptbl_,$port_val,$pl_,$seq_tbl_)=@_;
  my @table=@$table_;
  my @seq_table=@$seq_tbl_;
  my @port_table=@$ptbl_;
  my @port_list= @$pl_;
  my %dup_check;
  my @pattern=(); # [col0]: value, [col1]: delay, [col2] enable
  my $pat_row=0;
  my $pat_val = "";
  my $pat_delay = "";
  my $pat_en = "";
  $port_val =~ s/].*$//;
  print($FILE "// INPUT ::: $port_val]\n");
  # print test vector type  (4'hF)
  my %tvt_type;
  $tvt_type{"DONTCARE_TYPE"} = "0000"; # *(dont care) value test vector
  $tvt_type{"CROSS_TYPE"}    = "0001"; # -(cross) value test vector
  $tvt_type{"S_TYPE"}        = "0010"; # S value test vector
  $tvt_type{"RAMP_TYPE"}     = "0011"; # ramp wave test vector
  $tvt_type{"NORMAL_VALUE"}  = "0100"; # normal value test vector
  $tvt_type{"EXP_NOT_0_VAL"} = "0101"; # No 0 value
  $tvt_type{"EXP_NOT_1_VAL"} = "0110"; # No 1 value
  $tvt_type{"EXP_NOT_X_VAL"} = "0111"; # No x value
  $tvt_type{"EXP_NOT_Z_VAL"} = "1000"; # No z value
  $tvt_type{"EXP_RISING"}    = "1001"; # rising (0 -> 1)
  $tvt_type{"EXP_FALLING"}   = "1010"; # falling (1 -> 0)
  $tvt_type{"FIXED_0"}       = "0000"; # value is fixed to 0
  $tvt_type{"FIXED_1"}       = "0001"; # value is fixed to 1
  $tvt_type{"FIXED_X"}       = "0010"; # value is fixed to x
  $tvt_type{"FIXED_Z"}       = "0011"; # value is fixed to z
  $tvt_type{"UNFIXED"}       = "0100"; # value is unfixed
  my %mode_type;
  $mode_type{"NORMAL"} ="0000";#0 value
  $mode_type{"MAIN_MODE_VECTOR"} ="0001";#indicate mode vector pattern
  $mode_type{"LATCH_MODE_VECTOR"}="0010";#indicate latch check test vector
  $mode_type{"SUB_MODE_VECTOR"}  ="0001";#indicate sub mode test vector
  $mode_type{"LAST_SUB_MODE_VECTOR"}  ="0010";#indicate sub mode test vector
  my $index_ref_row = 5;
  my $pt_ref_row = 6;
  my $real_attr_ref_row = 8;
  my $data_row=9;
  my $total_port_num=0;
  for (my $j=0;$j<scalar(@{$table[0]});$j++){
    if($table[$index_ref_row][$j] ne "-1"){
      $total_port_num++;
      if ($table[$data_row][$j] !~ /^_/){
        if($table[$data_row][$j] =~ /\*/){
          printf($FILE "%s",$tvt_type{"DONTCARE_TYPE"});
        }elsif($table[$data_row][$j] =~ /^-$/){
          printf($FILE "%s",$tvt_type{"CROSS_TYPE"});
        }elsif($table[$data_row][$j] =~ /^S$/i){
          printf($FILE "%s",$tvt_type{"S_TYPE"});
        }elsif($table[$data_row][$j] =~ /^ramp/){
          printf($FILE "%s",$tvt_type{"RAMP_TYPE"});
        }elsif($table[$data_row][$j] =~ /^EXP_NOT_/){
          printf($FILE "%s",$tvt_type{$table[$data_row][$j]});
        }elsif($table[$data_row][$j] =~ /^RISE$/i){
          printf($FILE "%s",$tvt_type{"EXP_RISING"});
        }elsif($table[$data_row][$j] =~ /^FALL$/){
          printf($FILE "%s",$tvt_type{"EXP_FALLING"});
        }else{
          printf($FILE "%s",$tvt_type{"NORMAL_VALUE"});
        }
      }else{
        printf($FILE "%s",$tvt_type{"NORMAL_VALUE"});
      }
    }
  }
  print( $FILE "\n");
  #print delay time for FB
  for(my $f=0; $f<scalar(@{$table[0]}); $f++){
     if($table[0][$f] eq "FB") {
         if(grep(/^;#/,$table[$data_row][$f]) < 1 || $table[$data_row][$f] eq "*"){
           printf($FILE "%064b",0);
         }else{
           my $delaytime = $table[$data_row][$f];
           $delaytime =~ s/;#//g;
           printf($FILE "%064b", $delaytime);
         }
     }
  }
  # print delay time for input timing sequence
  for (my $index=$total_port_num-1;$index>=0;$index--){
    for(my $j=2;$j<scalar(@{$seq_table[0]});$j++){
      if($seq_table[$index_ref_row][$j] eq $index){
        if ($seq_table[4][$j] ne "-"){
          printf($FILE "%064b",$seq_table[4][$j]);
        }else{
          printf($FILE "%064b",0);
        }
        last;
      }
    }
  }
  print( $FILE "\n");
  # print ON/OFF for FB loop
  for(my $f=0; $f<scalar(@{$table[0]}); $f++){
     if($table[0][$f] eq "FB") {
         if(grep(/^;#/,$table[$data_row][$f]) > 0 || $table[$data_row][$f] eq "*"){
             print( $FILE "1");
         }else{
             print( $FILE "0");
         }
     }
  }
  # print enable for inout port (= 1 for all input or supply port)
  for (my $j=0;$j<scalar(@{$table[0]});$j++){
    if($table[$index_ref_row][$j] ne "-1" || $table[0][$j] =~ /supply|power|ground/){
      if ($table[0][$j] eq "input" || $table[0][$j] =~ /supply|power|ground/){
        print( $FILE "1");
      }else{
        if ($table[$data_row][$j] =~ /^_/){
          print( $FILE "0");
        }else{
          print( $FILE "1");
        }
      }
    }
  }
  print( $FILE "\n");
  # print mode
  my $mode_gen = -1;
  if ($table[$data_row][1] =~ /_?ERKS_HOLD|_?ERKS_STRONG_HOLD/) {
    printf($FILE "%s%s",$mode_type{"LATCH_MODE_VECTOR"},$mode_type{"NORMAL"});
  } else {
    for(my $j=2;$j<scalar(@{$table[0]});$j++){
      if ($table[0][$j] eq "Mode") {
        $mode_gen = 1;
        if ($table[$data_row][$j] =~ /^ERKS_SUB_MODE_/){
          printf($FILE "%s%s",$mode_type{"NORMAL"},$mode_type{"SUB_MODE_VECTOR"});
        } elsif($table[$data_row][$j] =~ /^ERKS_LAST_SUB_MODE_/){
          printf($FILE "%s%s",$mode_type{"NORMAL"},$mode_type{"LAST_SUB_MODE_VECTOR"});
        }elsif ($table[$data_row][$j] =~ /^-$/){
          printf($FILE "%s%s",$mode_type{"NORMAL"},$mode_type{"NORMAL"});
        } else {
          printf($FILE "%s%s",$mode_type{"MAIN_MODE_VECTOR"},$mode_type{"NORMAL"});
        }
        last;
      }
    }
    printf($FILE "%08b",0) if ($mode_gen eq "-1");
  }
  print( $FILE "\n");
  #print port value for FB OFF
  for(my $f=0; $f<scalar(@{$table[0]}); $f++){
    if($table[0][$f] eq "FB") {
      if(grep(/^;#/,$table[$data_row][$f]) > 0 || $table[$data_row][$f] eq "*"){
        printf($FILE "%016b",0);
      }else{
        if ($table[$data_row][$f]=~/^x$/i){ # X value
          printf($FILE "%016b",2);
        }elsif($table[$data_row][$f] =~/^z$/i){ # Z value
          printf($FILE "%016b",3);
        }else{
          printf($FILE "%016b", $table[$data_row][$f]);
        }
      }
    }
  }
  # print port value / initial port value
  for (my $j=0;$j<scalar(@{$table[0]});$j++){
    if($table[$index_ref_row][$j] ne "-1" || $table[0][$j] =~ /supply|power|ground/){
      if ($table[$data_row][$j]=~/^_/ && $table[7][$j] eq "2"){ #inout port act as output port
        if ($table[$pt_ref_row][$j] eq "1"){
          printf($FILE "%048b",0);
        }else{
          printf($FILE "%016b",0);
        }
        next;
      }
      if(($table[0][$j] =~ /^FB/ && $table[$data_row][$j] eq "*") || ($table[0][$j] eq "reg" && $table[$data_row][$j] eq "")){
        printf($FILE "%016b",0);
        next;
      }
      my $exp = $table[$real_attr_ref_row][$j];
      $exp =~ s/^.*\(//;
      $exp =~ s/\).*$//;
      my ($min, $max, $def_step)=split(",",$exp);
      if ($table[$pt_ref_row][$j] eq "1"){ # real number
        if ($table[$data_row][$j] =~ /^ramp/){ # ramp wave
          $exp = $table[$data_row][$j];
          $exp =~ s/^.*\(//;
          $exp =~ s/\).*$//;
          ($min, $max, $def_step)=split(",",$exp);
        }else{
          if ($table[$data_row][$j]=~/x/i){ # X value
            printf($FILE "%016b",0xFFFE);
            $min = -1;
          }elsif($table[$data_row][$j] =~/z/i){ # Z value
            printf($FILE "%016b",0xFFFF);
            $min = -1;
          }elsif ($table[$data_row][$j] =~ /^-$|^S$|^\*$/i){ # -|S|*
          }else{ # number
            $min = $table[$data_row][$j];
          }
        }
        # initial real value
        my $int_num = $min;
        my $real_num = 0;
        if ($min ne "-1"){
          if ($min =~ /^\d+\.\d+$/){
            ($int_num,$real_num)=split(/\./,$min);
          }
          printf($FILE "%06b",$int_num);
          printf($FILE "%010b",calc_fixed_point_value($real_num,3));# fixed point .000
        }
        # max real value
        $int_num = $max;
        $real_num = 0;
        if ($max =~ /^\d+\.\d+$/){
          ($int_num,$real_num)=split(/\./,$max);
        }
        printf($FILE "%06b",$int_num);
        printf($FILE "%010b",calc_fixed_point_value($real_num,3));# fixed point .000
        # def step value
        $int_num = $def_step;
        $real_num = 0;
        if ($def_step =~ /^\d+\.\d+$/){
          ($int_num,$real_num)=split(/\./,$def_step);
        }
        printf($FILE "%06b",$int_num);
        printf($FILE "%010b",calc_fixed_point_value($real_num,3));# fixed point .000
      }else{
        if ($table[$data_row][$j]=~/^x$/i){ # X value
          printf($FILE "%016b",2);
        }elsif($table[$data_row][$j] =~/^z$/i){ # Z value
          printf($FILE "%016b",3);
        }elsif ($table[$data_row][$j] =~ /^-$|^S$|^\*$|^(RISE|FALL)$/i){ # -|S|*
          printf($FILE "%016b",0); # initial value
        }elsif ($table[$data_row][$j] =~ /^EXP_NOT_0_VAL$/i){ # -|S|*
          printf($FILE "%016b",1);
        }elsif ($table[$data_row][$j] =~ /^EXP_NOT_/i){ # -|S|*
          printf($FILE "%016b",0); # initial value
        }else{ # number
          printf($FILE "%016b",$table[$data_row][$j]);
        }
      }
    }
  }
  print( $FILE "\n");
  # print clock period
  for(my $j=2;$j<scalar(@{$table[0]});$j++){
    if ($table[0][$j] eq "clock") {
      if ($table[$data_row][$j] =~ /^[Ff][Ii][Xx][Ee][Dd]/){
        $table[$data_row][$j]=~s/fixed[_] */FIXED_/i;
        printf($FILE "%s",$tvt_type{"$table[$data_row][$j]"});
        printf($FILE "%064b",0);
      }elsif($table[$data_row][$j] =~ /rise|fall/i){
        printf($FILE "%s",$tvt_type{"UNFIXED"});
        my $clock_value = 0;
        for(my $l=0; $l<scalar(@{$port_table[0]});$l++){
          if($table[2][$j] eq $port_table[0][$l] && $port_table[1][$l] eq "clock"){
            $clock_value = $port_table[6][$l];
          }
        }
        printf($FILE "%064b",$clock_value); #hong
      }else{
        printf($FILE "%s",$tvt_type{"UNFIXED"});
        printf($FILE "%064b",$table[$data_row][$j]);
      }
      print( $FILE "\n");
    }
  }
  for(my $j=2;$j<scalar(@{$table[0]});$j++){
    if ($table[0][$j] eq "high pulse width") {
      printf($FILE "%064b",$table[$data_row][$j]);
      print( $FILE "\n");
    }
  }
  # print sequence
  for(my $j=2;$j<scalar(@{$seq_table[0]});$j++){
    if($seq_table[$index_ref_row][$j] ne "-1"){
      printf($FILE "%016b",$seq_table[$index_ref_row][$j]);
    }
  }
  print( $FILE "\n");
}

sub MakeDUVMsgChk{
  my ($pat_array_,$msg_array_,$msg_array_org_,$message_chk) = @_;
  my @pat_array=@$pat_array_;
  my @msg_array=@$msg_array_;
  my @msg_array_org=@$msg_array_org_;
  open(MCHK,">msg_chk.pl");
  return(1) if(!(fileno(MCHK)));
  print(MCHK "#!/bin/perl\n");
  print(MCHK "use strict;\n");
  print(MCHK "use warnings;\n");
  print(MCHK "my \$header;\n");
  print(MCHK "my \$pass;\n");
  print(MCHK "my \$fail;\n");
  print(MCHK "my \$total;\n");
  print(MCHK "\n");
  print(MCHK "check_msg();\n");
  print(MCHK "sub check_msg{\n");
  print(MCHK "  my %msg;\n");
  print(MCHK "  my %msg_org;\n");
  print(MCHK "  my \@msg_chk_list=();\n");
  my $msg_len = 0;
  my @msg_line;
  my @msg_line_org;
  my $print = "";
  my $print_org = "";
  for (my $i=0;$i<scalar(@pat_array);$i++){
    @msg_line_org=split(/\n/,$msg_array_org[$i]);
    @msg_line=split(/\n/,$msg_array[$i]);
    for(my $j=0;$j<scalar(@msg_line);$j++){
      $print=$print."\"$msg_line[$j]\",";
      $print_org=$print_org."\"$msg_line_org[$j]\",";
    }
    splice(@msg_line,0,scalar(@msg_line),"");
    splice(@msg_line_org,0,scalar(@msg_line_org),"");
    $print =~ s/,$//;
    $print_org =~ s/,$//;
    if (length($msg_array[$i]) > $msg_len) {
        $msg_len = length($msg_array[$i]);
    }
    print(MCHK "  \$msg_org{\"$pat_array[$i]\"} = [$print_org]\;\n");
    print(MCHK "  \$msg    {\"$pat_array[$i]\"} = [$print]\;\n");
    $print="";
    $print_org="";
  }
  print(MCHK "  my \@msg_pat = ();\n");
  print(MCHK "  my \$cnt = 0;\n");
  print(MCHK "  my \%pass;\n");
  print(MCHK "  my \%fail;\n");
  print(MCHK "  my \$total_pass = 0;\n");
  print(MCHK "  my \$total_fail = 0;\n");
  print(MCHK "  foreach my \$pat (keys \%msg){\n");
  print(MCHK "    \$msg_pat[\$cnt] = \$pat;\n");
  print(MCHK "    \$pass{\$pat} = 0;\n");
  print(MCHK "    \$fail{\$pat} = 0;\n");
  print(MCHK "    \$cnt++;\n");
  print(MCHK "  }\n");
  print(MCHK "  if (\$ARGV[0] eq \"\" || \$ARGV[1] eq \"\"){\n");
  print(MCHK "    print(\"ERROR ::: Lack input option <input file> <result file>\\n\");\n");
  print(MCHK "    return;\n");
  print(MCHK "  }\n");
  print(MCHK "  if (-e \$ARGV[1]){\n");
  print(MCHK "    \$cnt = 0;\n");
  print(MCHK "    open(RP , \"< \$ARGV[1]\");\n");
  print(MCHK "    foreach my \$line (<RP>){\n");
  print(MCHK "      if (\$cnt < scalar(\@msg_pat)){\n");
  print(MCHK "        if (\$line =~ /:::/){\n");
  print(MCHK "          my \$msg_pat = \$line;\n");
  print(MCHK "          chomp(\$msg_pat);\n");
  print(MCHK "          my (\@msg_stat)= split(/ +/,\$msg_pat);\n");
  print(MCHK "          my \$total_num = pop(\@msg_stat);\n");
  print(MCHK "          my \$fail_num = pop(\@msg_stat);\n");
  print(MCHK "          my \$pass_num = pop(\@msg_stat);\n");
  print(MCHK "          if (\$cnt == scalar(\@msg_pat)){\n");
  print(MCHK "            \$total_pass = \$pass_num;\n");
  print(MCHK "            \$total_fail = \$fail_num;\n");
  print(MCHK "            \$total = \$total_num;\n");
  print(MCHK "          } else {\n");
  print(MCHK "            \$pass{\$msg_pat[\$cnt]} = \$pass_num;;\n");
  print(MCHK "            \$fail{\$msg_pat[\$cnt]} = \$fail_num;;\n");
  print(MCHK "          }\n");
  print(MCHK "          \$cnt++;\n");
  print(MCHK "        }\n");
  print(MCHK "      }\n");
  print(MCHK "    }\n");
  print(MCHK "    close(RP);\n");
  print(MCHK "  }\n");
  print(MCHK "  if (-e \$ARGV[0]){\n");
  print(MCHK "    my \$flag = 0;\n");
  print(MCHK "    my \$check_pat = \"\";\n");
  print(MCHK "    my \$tmp_line;\n");
  print(MCHK "    my \@message_of_pattern;\n");
  print(MCHK "    open(LOG, \"< \$ARGV[0]\");\n");
  print(MCHK "    open(RP , \"> \$ARGV[1]\");\n");
  print(MCHK "    return if (!(fileno(LOG)));\n");
  print(MCHK "    return if (!(fileno(RP)));\n");
  print(MCHK "    foreach my \$line (<LOG>){\n");
  print(MCHK "      if (\$line =~ /^MSG   ::: /){\n");
  print(MCHK "        if (\$flag == 1) {\n");
  print(MCHK "          my \@message = \@{\$msg{\$check_pat}};\n");
  print(MCHK "          for(my \$j=0;\$j<scalar(\@message);\$j++){\n");
  print(MCHK "            if(grep(/\$message[\$j]/,\@message_of_pattern) < 1){\n");
  print(MCHK "              \$fail{\$check_pat}  += 1;\n");
  print(MCHK "              \$total_fail  += 1;\n");
  print(MCHK "              last;\n");
  print(MCHK "            }\n");
  print(MCHK "          }\n");
  print(MCHK "          if(\$fail{\$check_pat} == 0){\n");
  print(MCHK "            \$pass{\$check_pat}  += 1;\n");
  print(MCHK "            \$total_pass  += 1;\n");
  print(MCHK "          }\n");
  print(MCHK "          \$flag = 0;\n");
  print(MCHK "          \$check_pat = \"\";\n");
  print(MCHK "        }\n");
  if($message_chk ne "all"){
    print(MCHK "        \$tmp_line = \$line;\n");
    print(MCHK "        if (grep(\/\\Q\$tmp_line\\E\/, \@msg_chk_list)<1){\n");
  }
  print(MCHK "          foreach my \$pat(keys \%msg){\n");
  print(MCHK "            if (\$line =~ /^\\Q\$pat\\E/){\n");
  print(MCHK "              \$flag = 1;\n");
  print(MCHK "              \$check_pat = \$pat;\n");
  print(MCHK "              \@message_of_pattern = \"\";\n");
  print(MCHK "              last;\n");
  print(MCHK "            }\n");
  print(MCHK "          }\n");
  if($message_chk ne "all"){
    print(MCHK "          push(\@msg_chk_list,\$tmp_line);\n");
    print(MCHK "        }\n");
  }
  print(MCHK "      }else{\n");
  print(MCHK "        if(\$check_pat ne \"\"){\n");
  print(MCHK "          if(grep(/\\Q\$line\\E/, \@message_of_pattern) < 1){\n");  
  print(MCHK "            push(\@message_of_pattern, \$line)\n");  
  print(MCHK "          }\n");
  print(MCHK "        }\n");
  print(MCHK "      }\n");
  print(MCHK "    }\n");
  print(MCHK "    if(\$check_pat ne \"\"){\n");
  print(MCHK "      my \@msg = \@{\$msg{\$check_pat}};\n");
  print(MCHK "      for(my \$k=0;\$k<scalar(\@msg);\$k++){\n");
  print(MCHK "        if(grep(/\$msg[\$k]/,\@message_of_pattern) < 1){\n");
  print(MCHK "          \$fail{\$check_pat}  += 1;\n");
  print(MCHK "          \$total_fail  += 1;\n");
  print(MCHK "          last;\n");
  print(MCHK "        }\n");
  print(MCHK "      }\n");
  print(MCHK "      if(\$fail{\$check_pat} == 0){\n");
  print(MCHK "        \$pass{\$check_pat}  += 1;\n");
  print(MCHK "        \$total_pass  += 1;\n");
  print(MCHK "      }\n");
  print(MCHK "    }\n");
  print(MCHK "    if (-e \$ARGV[1]){\n");
  print(MCHK "      print(RP \"Summary for message\\n\");\n");
  print(MCHK "    }\n");
  print(MCHK "    (\$header,\$pass,\$fail,\$total) = (\"TEST PATTERN           MESSAGE\",\"CORRECT DUMP\",\"MISSED DUMP\",\"TOTAL DUMP\");\n");
  print(MCHK "    select RP;\n");
  print(MCHK "    \$~ = \"MESSAGE_SUM\";\n");
  print(MCHK "    write;\n");
  print(MCHK "    foreach my \$msg_ptn(keys \%msg){\n");
  print(MCHK "      my \$report_message = \$msg_ptn;\n");
  print(MCHK "      my \$report_pattern = \$report_message;\n");
  print(MCHK "      \$report_pattern =~ s/MSG   :::/:::/;\n");
  print(MCHK "      (\$header,\$pass,\$fail,\$total) = (\$report_pattern,\$pass{\$report_message},\$fail{\$report_message},\$pass{\$report_message} + \$fail{\$report_message});\n");
  print(MCHK "      select RP;\n");
  print(MCHK "      \$~ = \"MESSAGE_SUM\";\n");
  print(MCHK "      write;\n");
  print(MCHK "      my \@msg_rpt = \@{\$msg_org{\$report_message}};\n");
  print(MCHK "      for(my \$m=0;\$m<scalar(\@msg_rpt);\$m++){\n");
  print(MCHK "        \$report_message = \"                       \".\$msg_rpt[\$m];\n");
  print(MCHK "        (\$header,\$pass,\$fail,\$total) = (\$report_message,\"\",\"\",\"\");\n");
  print(MCHK "        select RP;\n");
  print(MCHK "        \$~ = \"MESSAGE_SUM\";\n");
  print(MCHK "        write;\n");
  print(MCHK "      }\n");
  print(MCHK "    }\n");
  print(MCHK "    (\$header,\$pass,\$fail,\$total) = (\"TOTAL\",\$total_pass,\$total_fail,\$total_pass + \$total_fail);\n");
  print(MCHK "    select RP;\n");
  print(MCHK "    \$~ = \"MESSAGE_SUM\";\n");
  print(MCHK "    write;\n");
  print(MCHK "    close(LOG);\n");
  print(MCHK "    close(RP);\n");
  print(MCHK "  }\n");
  print(MCHK "}\n");
  print(MCHK "format MESSAGE_SUM =\n");
  my $msg_pat = "<"x($msg_len+24);
  printf(MCHK "@%s @>>>>>>>>>>>>>>> @>>>>>>>>>>>>>>> @>>>>>>>>>>>>>>>\n",$msg_pat);
  print(MCHK "\$header, \$pass, \$fail, \$total,\n");
  print(MCHK ".\n");
  close(MCHK);
}

sub format_real_num{
  my ($exp, $fix_num) = @_;
  $fix_num = int($fix_num);
  my $ret_val = "";
  if ($exp =~ /^\d*\.\d+$/){
    $exp =~ s/0*$//;
    my ($int,$point)=split(/\./,$exp);
    my @val = split(//,$point);
    if (scalar(@val)>$fix_num){
      my $min_val;
      my $max_val;
      my $tmp = "";
      for (my $i=0;$i<$fix_num;$i++){
        $tmp = $tmp."$val[$i]";
      }
      $ret_val ="$int.$tmp";
    }else{
      $ret_val = "$int.$point"."0"x($fix_num - scalar(@val));
    }
  }else{
    $ret_val = "$exp.000";
  }
  return $ret_val;
}

sub MakeMsgPattern{
  my ($msg_col,$rnm,$tbl_,$ptbl_,$fix_num,$pr,$vtbl)=@_;
  my @table = @$tbl_;
  my @port = @$ptbl_;
  my $port_val="";
  my $msg = "";
  my $msg_org = "";
  my $port_type_row = 6;
  my $io_type_row = 7;
  my $data_row = 9;
  if ($table[$data_row][$msg_col] ne "-"){
    $msg_org = $table[$data_row][$msg_col];
    $msg_org =~ s/\\/\\\\/g;
    $msg_org =~ s/\$/\\\$/g;
    $msg = ProcessMsgPattern($msg_col,$rnm,$tbl_,$ptbl_,$fix_num,$pr,$vtbl);
  }
  my $pat_val="";
  for (my $j=0;$j<scalar(@{$table[0]});$j++){
    if($table[$io_type_row][$j] eq "0" || $table[$io_type_row][$j] eq "-1" || ($table[0][$j] eq "inout" && $table[$data_row][$j] !~ /^\s*_/) || $table[0][$j] eq "reg"){
      my $exp = $table[$data_row][$j];
      $exp =~ s/\s//g;
      my $tmp = $exp;
      if ($table[$port_type_row][$j] eq "1"){ # real port
        $port_val=$port_val.'(%0.3f)';
        if ($exp =~ /^\*$/){
          $pat_val =$pat_val."(*)";
        }elsif ($exp =~ /^-$/){
          $pat_val =$pat_val."(-)";
        }elsif ($exp =~ /^S$/i){
          $pat_val =$pat_val."(S)";
        }elsif ($exp =~ /^z$/i){ # real z number
          $pat_val =$pat_val."(z)";
        }elsif ($exp =~ /^x$/i){ # real x number
          $pat_val =$pat_val."(x)";
        }elsif ($exp =~ /^ramp/){ # ramp wave
          $exp =~ s/^.*\(//;
          $exp =~ s/\).*$//;
          $pat_val =$pat_val."($exp)";
        }else{
          $pat_val =$pat_val."(".format_real_num($exp,$fix_num).")";
        }
      }else{ # normal port
        $port_val=$port_val.'(%0b)';
        if ($exp =~ /^\*$/){
          $pat_val =$pat_val."*";
        }elsif ($exp =~ /^-$/){
          $pat_val =$pat_val."-";
        }elsif ($exp =~ /^S$/i){
          $pat_val =$pat_val."S";
        }elsif ($exp =~ /^z$/i){ # real z number
          $pat_val =$pat_val."z";
        }elsif ($exp =~ /^x$/i){ # real x number
          $pat_val =$pat_val."x";
        }elsif ($exp =~ /^RISE$/i){ # rising
          $pat_val =$pat_val."R";
        }elsif ($exp =~ /^FALL$/i){ # falling
          $pat_val =$pat_val."F";
        }elsif ($exp =~ /^EXP_NOT_/i){ # not @ (@=0,1,x,z) value
          my $val = $exp;
          $val =~ s/^EXP_NOT_//;
          $val =~ s/_.*$//;
          $pat_val =$pat_val."!$val";
        }else{
          $pat_val =$pat_val.$exp;
        }
      }
    }elsif($table[0][$j] eq "inout"){
      if ($table[$port_type_row][$j] eq "1"){ # real port
        $pat_val =$pat_val."(.)";
        $port_val=$port_val."(.)";
      }else{
        $pat_val =$pat_val.".";
        $port_val=$port_val.".";
      }
    }
  }
  my $ret_pat= "MSG   ::: [".uc($pat_val)."]";
  $port_val = "[".uc($pat_val)."] $port_val";
  return($ret_pat,$msg,$msg_org,$port_val);
}

sub ProcessMsgPattern{
  my ($msg_col,$rnm,$tbl_,$ptbl_,$fix_num,$pr,$vtbl)=@_;
  my @table = @$tbl_;
  my @port = @$ptbl_;
  my @port_ref = @$pr;
  my $port_val="";
  my $msg = "";
  my $port_type_row = 6;
  my $io_type_row = 7;
  my $data_row = 9;
  if ($table[$data_row][$msg_col] ne "-"){
    $msg = $table[$data_row][$msg_col];
    $msg =~ s/\\/\\\\/g;
  }
  my @port_expr=();
  my $tmp_msg = $msg;
  while ($tmp_msg =~ /\$\{[^}]*\}/) {
    $tmp_msg =~ s/(\$\{[^}]*\})//;
    push(@port_expr,$1);
  }
  if (@port_expr!=0){
    foreach my $expr (@port_expr){
      my $rep_key = $expr;
      my $rep_val = "";
      $expr =~ s/^\$\{//;
      $expr =~ s/\}//;
      $expr =~ s/\s+//;
      my $found = 0;
      my $port_name = "";
      my $port_index = "";
      if ($expr =~ /^[^\[\]]+(\[\d+\]|\[\d+:\d+\])?$/) {
        my @tmp=();
        if($expr=~/^\w+\[\d+\]$/){ # process single bitwidth port name (multiple bitwidth)
          $port_index=$expr;
          $port_name = (split(/\[/,$expr))[0];
          $port_index = (split(/\[/,$expr))[1];
          $port_index =~ s/\].*$//;
          $found = (Ex2Tbl::found_variable($expr, \@tmp,$port[0]))[0];
        } elsif ($expr=~/^\w+\[\d+:\d+\]$/){ # process multiple bitwidth port name (multiple bitwidth))
          my @tmp_split = split(/\W+/,(split(/\[/,$expr))[0]);
          $port_name = $tmp_split[scalar(@tmp_split)-1];
          $port_index = (split(/\[/,$expr))[1];
          $port_index =~ s/].*$//;
          my ($max, $min) = split(/:/,$port_index);
          for (my $i=$min;$i<=$max;$i++){
            my $tmp_name = $port_name."[".$i."]";
            my $index = $i - $min;
            $found = (Ex2Tbl::found_variable($tmp_name, \@tmp,$port[0]))[0];
          }
        } else { # process port name without []
          $port_name = $expr;
          for (my $i=0;$i<scalar(@{$port[0]});$i++) {
            if (Ex2Tbl::cmp_port_name($expr,$port[0][$i])) {
              $found = 1;
              $port_index = $port[11][$i];
              last;
            }
          }
        }
        if ($found == 1) {
          if ($port_index =~ /^\d+:\d+$/) {
            my ($max, $min) = split(/:/,$port_index);
            for (my $i=$max;$i>=$min;$i--){
              my $tmp_name = $port_name."[".$i."]";
              my $index = $i - $min;
              my $col = Ex2Tbl::get_port_col($tmp_name, 2, @table);
              my $port_value = $table[$data_row][$col];
              my %var;
              if ($port_value =~ /^\(.*\)$/){
                my @input_pat = Ex2Tbl::get_input_pattern(\@{$table[$data_row]},\@{$table[$data_row]},\@{$table[0]},$pr);
                %var = Ex2Tbl::get_expr_val($port_value,\@input_pat,$pr,$vtbl,$ptbl_,$rnm,"off");
              } else {
                %var = Ex2Tbl::get_pattern($port_value,$col,0,@port_ref);
              }
              $rep_val = $rep_val."(";
              foreach my $key (keys %var) {
                $rep_val = $rep_val."$key|";
              }
              $rep_val =~ s/\|$/\)/;
            }
          } else {
            my $col = Ex2Tbl::get_port_col($expr, 2, @table);
            my $port_value = $table[$data_row][$col];
            my %var;
            if ($port_value =~ /^_?\(.*\)$/){
              $port_value =~ s/^_//;
              my @input_pat = Ex2Tbl::get_input_pattern(\@{$table[$data_row]},\@{$table[$data_row]},\@{$table[0]},$pr);
              %var = Ex2Tbl::get_expr_val($port_value,\@input_pat,$pr,$vtbl,$ptbl_,$rnm,"off");
            } else {
              %var = Ex2Tbl::get_pattern($port_value,$col,0,@port_ref);
            }
            $rep_val = "(";
            foreach my $key (keys %var) {
              $rep_val = $rep_val."$key|";
            }
            $rep_val =~ s/\|$/\)/;
          }
          $msg =~ s/\Q$rep_key\E/$rep_val/g;
        }
      }
    }
    $msg =~ s/\$/\\\$/g; # Replace $ -> \$ for invalid expression
  }
  return $msg;
}
sub CalMaxSubMode{
  my ($tbl)=@_;
  my @table = @$tbl;
  my $max_sub_mode=0;
  my $max_sub_mode_temp=0;
  my $is_update = 0;
  for(my $row=4;$row<scalar(@table);$row++){
    for(my $col=2;$col<scalar(@{$table[0]});$col++){
      if($table[0][$col] =~ /Mode/){
        if($table[$row][$col] =~ /^ERKSMODE/){
          if($max_sub_mode < $max_sub_mode_temp){
            $max_sub_mode = $max_sub_mode_temp;
            $is_update = 1;
          }
          $max_sub_mode_temp = 0;
        }
        if($table[$row][$col] =~ /SUB_MODE/){
          $is_update = 0;
          $max_sub_mode_temp++;
        }
      }
    }
  }
  if($is_update == 0){
    if($max_sub_mode < $max_sub_mode_temp){
      $max_sub_mode = $max_sub_mode_temp;
    }
  }
  return $max_sub_mode;
}

sub CalFinTimeTruthTbl{# [0] delay [1] truth table [2] port table
  my ($delay, $tt, $pt)=@_;
  my @truth=@$tt;
  my @port=@$pt;
  my $fin_time=1;
  for(my $col=2;$col<scalar(@{$truth[0]});$col++){
    if($truth[0][$col] =~ /input/i){ # for all input port
      my $portname=$truth[2][$col];# get input port name
      for(my $i=0;$i<scalar(@{$port[0]});$i++){
        if ($port[0][$i] eq $portname){
          my $bitnum=$port[3][$i];# get num bit
          $fin_time *= 2<<$bitnum;# cal fin time
          last;
        }
      }
    }
  }
  return $fin_time*$delay;
}

### Make assertion ###
sub MakeAssertion{ #[0]file name [1] pg [2] truth table [3] port table [4] output timing sequence
  my ($file, $pg, $rnm, $tbl_, $ptbl_,$outseq_,$port_ref_table_,$is_exclude_sheet,$sim,$wave,$ctrl_ex_message,$header_,$inseq_)=@_;
  my @table_org=@$tbl_;
  my @port_table=@$ptbl_;
  my @outseq=@$outseq_;
  my @port_ref_table = @$port_ref_table_;
  my @TruthTableList = Ex2Tbl::SeparateTruthTable($rnm, @table_org);
  my @header =@$header_;
  my @inseq = ();
  if(ref($inseq_)){
   @inseq = @$inseq_;   
  }
  my $ast=0;
  my %vector_list;
  
  if (scalar(@TruthTableList) > 0) {
    open(AST, ">$file");
    # Check open successfully or not
    return(1) if (!(fileno(AST)));
    for(my $i=0;$i<scalar(@header);$i++){
      print(AST "//$header[$i]\n");
    }

    for(my $tt=0;$tt<scalar(@TruthTableList);$tt++){
      my @table=@{$TruthTableList[$tt]};
      my $portsensisity="";
      $portsensisity = get_sensitive_port_string($pg, 2, \@port_ref_table, @table) if ($is_exclude_sheet eq "1");# 1 is row of port name used for assertion of Exclude sheet
      # Open file to write/append
      # Put header
      if ($tt==0){
        my($se, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst)=localtime(time);
        my $exe_date=sprintf("%04d\/%02d\/%02d %02d:%02d:%02d",$year+1900,$mon+1,$mday,$hour,$min,$se);
        my $version=$ENV{'ERAKIS_VER'};
#        my $user=$ENV{'USERNAME'};
        my $user=$ENV{'USER'};

        print(AST "////////////////////////////////////////////////////////////////////////////\n");
        print(AST "/// DATE : $exe_date\n");
        print(AST "/// USER : $user\n");
        print(AST "/// TOOL : $version\n");
        print(AST "////////////////////////////////////////////////////////////////////////////\n");
        print(AST "\n// SVA check\n\n");
#        print(AST "  integer i0=0;\n") if ($portsensisity eq "");
        close(AST);
      }
      # system verilog assertion
      my $start_row = 4; # start from row 4 of truth table
      if ($is_exclude_sheet eq "0") {
        $ast = print_ast($file,"check",\@table,\@port_ref_table, \%vector_list, $start_row, $ast, $portsensisity,$sim, $wave,$ctrl_ex_message);
      } else {
        $ast = print_ast($file,"exclude",\@table,\@port_ref_table, \%vector_list, $start_row, $ast, $portsensisity,$sim, $wave,$ctrl_ex_message);
      }
    }
    open(AST, ">>$file");
    for(my $i=0;$i<scalar(@{$table_org[0]});$i++){
      if($table_org[1][$i]=~/\d/ && $table_org[0][$i] ne "input"){
        print(AST "//------------check oscillation ports -------//\n");;
        print(AST "  check_$table_org[2][$i] : assert property (\n");
        print(AST "    @(assert_trigger_$table_org[2][$i]) disable iff(i0==0)\n");
        print(AST "    (check_result_$table_org[2][$i] === 1)\n");
        print(AST "  );\n");
      }
    }
    # Assertion for output timing sequence
    if (@outseq != 0){
      my %clock_source_list;
      if (@table_org != 0){
        for(my $j=2;$j<scalar(@{$table_org[0]});$j++){
          if ($table_org[0][$j] eq "clock") {
            my $clock_source = $table_org[2][$j];
            if (not exists $clock_source_list{"$clock_source"}) {
              $clock_source_list{"$clock_source"} = $clock_source;
            }
          }
        }
      }
      for (my $i=1;$i<scalar(@outseq);$i++){
        my $ast_name = "check_Constraint_".$outseq[$i][5];
        my ($cond_name,$out_name,$port_ref_num,$in_port_name,$out_port_name)=get_port_timing_info($outseq[$i][2],$outseq[$i][3],@port_ref_table);
        my $min;
        my $max;
        my $ast_str = "";
        my $print_msg = "INFO ::: Assertion of $ast_name ";
        if ($outseq[$i][4] =~ /^\d+-\d+$/) { # Ex: 10-50
          my $prefix_osc = "";
          $prefix_osc = "osc_" if ($outseq[$i][2] =~ /^\(osc\)/i);
          my $suffix_osc = "";
          $suffix_osc = "osc_" if ($outseq[$i][3] =~ /^\(osc\)/i);
          $print_msg = $print_msg."and $ast_name\_b ";
          ($min, $max)=split(/-/,$outseq[$i][4]);
          if ($port_ref_num ne "-1") { # input port -> output port 
            $ast_str="  $ast_name : assert property (\n    \@($out_name\_outseq_trg[$port_ref_num]) disable iff((i0==0)||($out_name\_outseq_trg[$port_ref_num]==0))\n"; # input port -> output port
          } else {
            $ast_str="  $ast_name : assert property (\n    \@($prefix_osc$cond_name\_$suffix_osc$out_name\_outseq_trg) disable iff((i0==0)||($prefix_osc$cond_name\_$suffix_osc$out_name\_outseq_trg==0))\n"; # input port -> output port
          }
          $ast_str=$ast_str."    // [Constraint]/row $outseq[$i][5]: $outseq[$i][2] $outseq[$i][3] $outseq[$i][4]\n";
          if ($port_ref_num ne "-1") { # input port -> output port 
            $ast_str=$ast_str."    (($out_name"."_update_time[$port_ref_num] >= $min) && ($out_name"."_update_time[$port_ref_num] <= $max))\n";
          } else { # output port -> output port 
            $ast_str=$ast_str."    (($prefix_osc$cond_name"."_$suffix_osc$out_name"."_update_time >= $min) && ($prefix_osc$cond_name"."_$suffix_osc$out_name"."_update_time <= $max))\n";
          }
          $ast_str=$ast_str."  );\n\n";

          $ast_str=$ast_str."  $ast_name\_b : assert property (\n    \@($prefix_osc$cond_name\_$out_name\_stable_chk) disable iff(i0==0)\n";
          $ast_str=$ast_str."    // [Constraint]/row $outseq[$i][5]: $outseq[$i][2] $outseq[$i][3] $outseq[$i][4]\n";
          if ($port_ref_num ne "-1") { # input port -> output port 
            $ast_str=$ast_str."    ($out_name"."_update_flag[$port_ref_num] == 1)\n";
          } else { # output port -> output port 
            $ast_str=$ast_str."    ($prefix_osc$cond_name\_$suffix_osc$out_name"."_update_flag == 1)\n";
          }
          $ast_str=$ast_str."  );\n\n";
        } elsif ($outseq[$i][4] =~ /^\d+$/) { # Ex: 50
          $min = $outseq[$i][4];
          my $osc_cond = "";
          my $cond_edge_cond = "";
          my $out_edge_cond = "";
          my $first_value = "";
          my $second_value = "";
          if ($outseq[$i][2] =~ /\(fall\)/) {
            $first_value = "$cond_name\_falling_time";
            $cond_edge_cond = "negedge ";
          } elsif ($outseq[$i][2] =~ /\(rise|osc\)/) {
            $first_value = "$cond_name\_rising_time";
            if ($outseq[$i][2] =~ /\(osc\)/) {
              $osc_cond = "($cond_name\_osc_chk_ctrl == 0)";
            }
            $cond_edge_cond = "posedge ";
          } else {
            $first_value = "$cond_name\_update_time_pos";
          }
          if ($outseq[$i][3] =~ /\(osc\)/) {
            $second_value = "$out_name\_rising_time";
            if ($outseq[$i][3] =~ /\(osc\)/) {
              $osc_cond = $osc_cond." && " if $osc_cond ne "";
              $osc_cond = $osc_cond."($out_name\_osc_chk_ctrl == 0)";
            }
            $out_edge_cond = "posedge ";
          } else {
            $second_value = "\$time";
          }
          if ($osc_cond eq "") {
            $ast_str="  $ast_name : assert property (\n    \@($out_edge_cond$out_port_name) disable iff(i0==0)\n";
          } else {
            $ast_str="  $ast_name : assert property (\n    \@($out_edge_cond$out_port_name) disable iff((i0==0) || $osc_cond)\n";
          }
          $ast_str=$ast_str."    // [Constraint]/row $outseq[$i][5]: $outseq[$i][2] $outseq[$i][3] $outseq[$i][4]\n";
          $ast_str=$ast_str."    (($second_value - $first_value) >= $min)\n";
          $ast_str=$ast_str."  );\n\n";
          if ($outseq[$i][8] ne "-") {
            $print_msg = $print_msg."and $ast_name\_b ";
            if ($osc_cond eq "") {
              $ast_str=$ast_str."  $ast_name\_b : assert property (\n    \@($cond_edge_cond$in_port_name) disable iff(i0==0)\n";
            } else {            
              $ast_str=$ast_str."  $ast_name\_b : assert property (\n    \@($cond_edge_cond$in_port_name) disable iff((i0==0) || $osc_cond)\n";
            }
            $ast_str=$ast_str."    // [Constraint]/row $outseq[$i][5]: $outseq[$i][2] $outseq[$i][3] $outseq[$i][4]\n";
            $ast_str=$ast_str."    ##1 ($out_name === $outseq[$i][8])\n";
            $ast_str=$ast_str."  );\n\n";
          }
        } else { # Ex: pos 5, neg 10
          my $clock_name = $outseq[$i][6];
          my $clock_period = $outseq[$i][7];
          if (exists $clock_source_list{"$clock_name"}) {
            $clock_period = "$clock_name\_clk_period";
          }
          $min = $outseq[$i][4];
          $min =~ s/(pos|neg)\s*//;
          my $osc_cond = "";
          my $cond_edge_cond = "";
          my $out_edge_cond = "";
          my $first_value = "";
          my $second_value = "";
          if ($outseq[$i][2] =~ /\(fall\)/) {
            $first_value = "$cond_name\_falling_time";
            $cond_edge_cond = "negedge ";
          } elsif ($outseq[$i][2] =~ /\(rise|osc\)/) {
            $first_value = "$cond_name\_rising_time";
            if ($outseq[$i][2] =~ /\(osc\)/) {
              $osc_cond = "($cond_name\_osc_chk_ctrl == 0)";
            }
            $cond_edge_cond = "posedge ";
          } else {
            $first_value = "$cond_name\_update_time_pos";
          }
          if ($outseq[$i][3] =~ /\(osc\)/) {
            $second_value = "$out_name\_rising_time";
            if ($outseq[$i][3] =~ /\(osc\)/) {
              $osc_cond = $osc_cond." && " if $osc_cond ne "";
              $osc_cond = $osc_cond."($out_name\_osc_chk_ctrl == 0)";
            }
            $out_edge_cond = "posedge ";
          } else {
            $second_value = "\$time";
          }
          my $check_type = "rising";
          $check_type = "falling" if ($outseq[$i][4] =~ /neg/);
          my $check_name = lc($outseq[$i][0])."_$outseq[$i][5]";
          if ($osc_cond eq "") {
            $ast_str="  $ast_name : assert property (\n    \@(check_$check_type\_$check_name) disable iff(check_$check_type\_$check_name==0)\n";
          } else {
            $ast_str="  $ast_name : assert property (\n    \@(check_$check_type\_$check_name) disable iff(check_$check_type\_$check_name==0 || $osc_cond)\n";
          }
          $ast_str=$ast_str."    // [Constraint]/row $outseq[$i][5]: $outseq[$i][2] $outseq[$i][3] $outseq[$i][4]\n";
          $ast_str=$ast_str."    ($check_type\_$check_name\_num >= $min)\n";
          $ast_str=$ast_str."  );\n\n";
          if ($outseq[$i][8] ne "-") {
            $print_msg = $print_msg."and $ast_name\_b ";
            if ($osc_cond eq "") {
              $ast_str=$ast_str."  $ast_name\_b : assert property (\n    \@($cond_edge_cond$in_port_name) disable iff(i0==0)\n";
            } else {            
              $ast_str=$ast_str."  $ast_name\_b : assert property (\n    \@($cond_edge_cond$in_port_name) disable iff((i0==0) || $osc_cond)\n";
            }
            $ast_str=$ast_str."    // [Constraint]/row $outseq[$i][5]: $outseq[$i][2] $outseq[$i][3] $outseq[$i][4]\n";
            $ast_str=$ast_str."    ##1 ($out_name === $outseq[$i][8])\n";
            $ast_str=$ast_str."  );\n\n";
          }
        }
        $print_msg = $print_msg."are made from [Constraint]/row $outseq[$i][5].\n";
        print("$print_msg");
        print(AST "$ast_str");
      }
    }
    # Assertion for input timing sequence
    if (@inseq != 0){
       my %clock_source_list;
       for (my $i=1;$i<scalar(@inseq);$i++){
        my $ast_name = "check_Exclude_Constraint_".$inseq[$i][1];
        my ($cond_name,$out_name,$port_ref_num,$in_port_name,$out_port_name)=get_port_timing_info($inseq[$i][2],$inseq[$i][3],@port_ref_table);
        my $min;
        my $max;
        my $ast_str = "";
        my $print_msg = "INFO ::: Assertion of $ast_name ";
        if ($inseq[$i][4] =~ /^\d+-\d+$/) { # Ex: 10-50
#          my $prefix_osc = "";
#          $prefix_osc = "osc_" if ($inseq[$i][2] =~ /^\(osc\)/i);
#          my $suffix_osc = "";
#          $suffix_osc = "osc_" if ($inseq[$i][3] =~ /^\(osc\)/i);
#          $print_msg = $print_msg."and $ast_name\_b ";
#          ($min, $max)=split(/-/,$inseq[$i][4]);
#          if ($port_ref_num ne "-1") { # input port -> output port 
#            $ast_str="  $ast_name : assert property (\n    \@($out_name\_inseq_trg[$port_ref_num]) disable iff((i0==0)||($out_name\_inseq_trg[$port_ref_num]==0))\n"; # input port -> output port
#          } else {
#            $ast_str="  $ast_name : assert property (\n    \@($prefix_osc$cond_name\_$suffix_osc$out_name\_inseq_trg) disable iff((i0==0)||($prefix_osc$cond_name\_$suffix_osc$out_name\_inseq_trg==0))\n"; # input port -> output port
#          }
#          $ast_str=$ast_str."    // [Exclude_Constraint]/row $inseq[$i][1]: $inseq[$i][2] $inseq[$i][3] $inseq[$i][4]\n";
#          if ($port_ref_num ne "-1") { # input port -> output port 
#            $ast_str=$ast_str."    not(($out_name"."_update_time[$port_ref_num] >= $min) && ($out_name"."_update_time[$port_ref_num] <= $max))\n";
#          } else { # output port -> output port 
#            $ast_str=$ast_str."    not(($prefix_osc$cond_name"."_$suffix_osc$out_name"."_update_time >= $min) && ($prefix_osc$cond_name"."_$suffix_osc$out_name"."_update_time <= $max))\n";
#          }
#          $ast_str=$ast_str."  );\n\n";
#
#          $ast_str=$ast_str."  $ast_name\_b : assert property (\n    \@($prefix_osc$cond_name\_$out_name\_stable_chk) disable iff(i0==0)\n";
#          $ast_str=$ast_str."    // [Exclude_Constraint]/row $inseq[$i][1]: $inseq[$i][2] $inseq[$i][3] $inseq[$i][4]\n";
#          if ($port_ref_num ne "-1") { # input port -> output port 
#            $ast_str=$ast_str."    not($out_name"."_update_flag[$port_ref_num] == 1)\n";
#          } else { # output port -> output port 
#            $ast_str=$ast_str."    not($prefix_osc$cond_name\_$suffix_osc$out_name"."_update_flag == 1)\n";
#          }
#          $ast_str=$ast_str."  );\n\n";
        } elsif ($inseq[$i][4] =~ /^\d+$/) { # Ex: 50
          $min = $inseq[$i][4];
          my $osc_cond = "";
          my $cond_edge_cond = "";
          my $out_edge_cond = "";
          my $first_value = "";
          my $second_value = "";
#          if ($inseq[$i][2] =~ /\(fall\)/) {
#            $first_value = "$cond_name\_falling_time";
#            $cond_edge_cond = "negedge ";
#          } elsif ($inseq[$i][2] =~ /\(rise|osc\)/) {
#            $first_value = "$cond_name\_rising_time";
#            if ($inseq[$i][2] =~ /\(osc\)/) {
#              $osc_cond = "($cond_name\_osc_chk_ctrl == 0)";
#            }
#            $cond_edge_cond = "posedge ";
#          } else {
            $first_value = "$cond_name\_update_time_pos";
#          }
          if ($inseq[$i][3] =~ /ERKSFALL/) {
            $out_edge_cond = "negedge ";
            $out_edge_cond .= $out_port_name;
            $out_edge_cond =~ s/ERKSFALL_//g;
            $second_value = "\$time";
          } elsif ($inseq[$i][3] =~ /ERKSRISE/) {
            $out_edge_cond = "posedge ";
            $out_edge_cond .= $out_port_name;
            $out_edge_cond =~ s/ERKSRISE_//g;
            $second_value = "\$time";
          }elsif ($inseq[$i][3] =~ /\(osc\)/) {
#            $second_value = "$out_name\_rising_time";
#            if ($inseq[$i][3] =~ /\(osc\)/) {
#              $osc_cond = $osc_cond." && " if $osc_cond ne "";
#              $osc_cond = $osc_cond."($out_name\_osc_chk_ctrl == 0)";
#            }
#            $out_edge_cond = "posedge ";
          }else{
            $out_edge_cond = $out_port_name;
            $out_edge_cond =~ s/\(*\)//g;
            $second_value = "\$time";
          }
          if ($osc_cond eq "") {
            $ast_str="  $ast_name : assert property (\n    \@($out_edge_cond) disable iff(i0==0)\n";
          } else {
            $ast_str="  $ast_name : assert property (\n    \@($out_edge_cond) disable iff((i0==0) || $osc_cond)\n";
          }
          $ast_str=$ast_str."    // [Exclude_Constraint]/row $inseq[$i][1]: $inseq[$i][2] $inseq[$i][3] $inseq[$i][4]\n";
          $ast_str=$ast_str."    not(($second_value - $first_value) >= $min)\n";
          $ast_str=$ast_str."  );\n\n";
#          if ($inseq[$i][8] ne "-") {
#            $print_msg = $print_msg."and $ast_name\_b ";
#            if ($osc_cond eq "") {
#              $ast_str=$ast_str."  $ast_name\_b : assert property (\n    \@($cond_edge_cond$in_port_name) disable iff(i0==0)\n";
#            } else {            
#              $ast_str=$ast_str."  $ast_name\_b : assert property (\n    \@($cond_edge_cond$in_port_name) disable iff((i0==0) || $osc_cond)\n";
#            }
#            $ast_str=$ast_str."    // [Exclude_Constraint]/row $inseq[$i][1]: $inseq[$i][2] $inseq[$i][3] $inseq[$i][4]\n";
#            $ast_str=$ast_str."    ##1 ($out_name === $inseq[$i][8])\n";
#            $ast_str=$ast_str."  );\n\n";
#          }
        } else { # Ex: pos 5, neg 10
#          my $clock_name = $inseq[$i][6];
#          my $clock_period = $inseq[$i][7];
#          if (exists $clock_source_list{"$clock_name"}) {
#            $clock_period = "$clock_name\_clk_period";
#          }
#          $min = $inseq[$i][4];
#          $min =~ s/(pos|neg)\s*//;
#          my $osc_cond = "";
#          my $cond_edge_cond = "";
#          my $out_edge_cond = "";
#          my $first_value = "";
#          my $second_value = "";
#          if ($inseq[$i][2] =~ /\(fall\)/) {
#            $first_value = "$cond_name\_falling_time";
#            $cond_edge_cond = "negedge ";
#          } elsif ($inseq[$i][2] =~ /\(rise|osc\)/) {
#            $first_value = "$cond_name\_rising_time";
#            if ($inseq[$i][2] =~ /\(osc\)/) {
#              $osc_cond = "($cond_name\_osc_chk_ctrl == 0)";
#            }
#            $cond_edge_cond = "posedge ";
#          } else {
#            $first_value = "$cond_name\_update_time_pos";
#          }
#          if ($inseq[$i][3] =~ /\(osc\)/) {
#            $second_value = "$out_name\_rising_time";
#            if ($inseq[$i][3] =~ /\(osc\)/) {
#              $osc_cond = $osc_cond." && " if $osc_cond ne "";
#              $osc_cond = $osc_cond."($out_name\_osc_chk_ctrl == 0)";
#            }
#            $out_edge_cond = "posedge ";
#          } else {
#            $second_value = "\$time";
#          }
#          my $check_type = "rising";
#          $check_type = "falling" if ($inseq[$i][4] =~ /neg/);
#          my $check_name = lc($inseq[$i][0])."_$inseq[$i][5]";
#          if ($osc_cond eq "") {
#            $ast_str="  $ast_name : assert property (\n    \@(check_$check_type\_$check_name) disable iff(check_$check_type\_$check_name==0)\n";
#          } else {
#            $ast_str="  $ast_name : assert property (\n    \@(check_$check_type\_$check_name) disable iff(check_$check_type\_$check_name==0 || $osc_cond)\n";
#          }
#          $ast_str=$ast_str."    // [Exclude_Constraint]/row $inseq[$i][1]: $inseq[$i][2] $inseq[$i][3] $inseq[$i][4]\n";
#          $ast_str=$ast_str."    not($check_type\_$check_name\_num >= $min)\n";
#          $ast_str=$ast_str."  );\n\n";
#          if ($inseq[$i][8] ne "-") {
#            $print_msg = $print_msg."and $ast_name\_b ";
#            if ($osc_cond eq "") {
#              $ast_str=$ast_str."  $ast_name\_b : assert property (\n    \@($cond_edge_cond$in_port_name) disable iff(i0==0)\n";
#            } else {            
#              $ast_str=$ast_str."  $ast_name\_b : assert property (\n    \@($cond_edge_cond$in_port_name) disable iff((i0==0) || $osc_cond)\n";
#            }
#            $ast_str=$ast_str."    // [Exclude_Constraint]/row $inseq[$i][1]: $inseq[$i][2] $inseq[$i][3] $inseq[$i][4]\n";
#            $ast_str=$ast_str."    ##1 ($out_name === $inseq[$i][8])\n";
#            $ast_str=$ast_str."  );\n\n";
#          }
        }
        $print_msg = $print_msg."are made from [Exclude_Constraint]/row $inseq[$i][1].\n";
        print("$print_msg");
        print(AST "$ast_str");
      }
    }
    close(AST);
  }
  return(0);
}

sub real_port_assertion{
  my ($name,$exp,$fix_num,$en_range)=@_;
  my $id = "";
  my $real = "";
  my $ret="";
  if ($exp =~ /^x$/i){ # x
    $ret=$ret."($name === `wrealXState)&&";
  }elsif($exp =~ /^z$/i){ # z
    $ret=$ret."($name === `wrealZState)&&";
  }elsif($exp =~ /^\d*\.?\d+$/){ # real number
    $fix_num = int($fix_num);
    $exp =~ s/0*$// if ($exp =~ /^\d*\.\d+$/);
    my $int = ($exp =~ /^\d*\.\d+$/)? "":$exp;
    my $point = "";
    ($int,$point)=split(/\./,$exp) if ($exp =~ /^\d*\.\d+$/);
    my @val = ();
    @val = split(//,$point) if ($exp =~ /^\d*\.\d+$/);
    if (scalar(@val)>$fix_num){
      my $min_val;
      my $max_val;
      my $tmp = "";
      for (my $i=0;$i<$fix_num;$i++){
        $tmp = $tmp."$val[$i]";
      }
      $min_val=$int.".$tmp";
      $tmp=int($tmp)+1;
      $max_val=$int.".$tmp";
      if($en_range == 1){
        $ret=$ret."($name > $min_val)&&($name < $max_val)&&";
      }else{
        $ret=$ret."($name > ($min_val-delta))&&($name < ($min_val+delta))&&";
      }
    }else{
      $ret=$ret."($name > ($int.$point"."0"x($fix_num - scalar(@val))."-delta))&&($name < ($int.$point"."0"x($fix_num - scalar(@val))."+delta))&&";
    }
  }else{
    $exp =~ s/#/\(/g;
    $exp =~ s/\$/\)/g;
    $ret=$ret."($name > ($exp-delta))&&($name < ($exp+delta))&&";
  }
  return $ret;
}

sub MakeCompleteAssertion{ #[0] dcas [1] file name [2] pg [3]truth table [4] Port table
  my ($dcas,$file,$pg,$rnm,$t,$p,$pr,$sim,$wave)=@_;
  my @port=@$p;
  my @table=@$t;
  my $lacklog="lacklog.txt";
  my $ret=CreateLackLogFile(0, -1, $dcas, $lacklog, $rnm, \@port, \@table);
  if ($ret!=2){# no lack or error in creating file
    return $ret;
  }else{
    return put_ast_for_lack_ptn($lacklog, $file, $pr,$sim,$wave);# 2 is row content port list
  }
}

sub ReplaceAMSAssertion
{
  my ($file,$ptbl_) = @_;    
  my @port = @$ptbl_;
  my $file_tmp = $file."_tmp";
  my @port_rep_list=();
  for(my $i=0;$i<scalar(@{$port[0]});$i++){
    if (($port[1][$i] !~ /power|ground/)) {
      push(@port_rep_list,$port[0][$i]);
    }
  }
  open(AST, "<$file");
  return(1) if(!(fileno(AST)));
    open(TMP, "> $file_tmp");
      return(1) if(!(fileno(TMP)));
      foreach my $line(<AST>){
        foreach my $port_name(@port_rep_list) {
          if ($line =~ /\Q$port_name\E/) {
            $line =~ s/\Q$port_name === `wrealXState\E/$port_name === 1'bx/g;
            $line =~ s/\Q$port_name === `wrealZState\E/$port_name === 1'bz/g;
            $line =~ s/\Q$port_name.r\E/$port_name/g;
          }
        }
        print(TMP "$line");
      }
    close(TMP);
  close(AST);
  open(AST, "> $file");
    return(1) if(!(fileno(AST)));
    # tmp file open
    open(TMP,"< $file_tmp");
      return(1) if(!(fileno(TMP)));
      foreach my $line(<TMP>){
        print(AST "$line");
      }
    close(TMP);
  close(AST);
  unlink($file_tmp);
}

sub get_sensitive_port_string{
  my ($pg, $rowport, $port_ref, @table)=@_;
  my @port_ref_table = @$port_ref;
  my $portsensisity="";
  for (my $col=2;$col<scalar(@{$table[0]});$col++){
    if (($table[0][$col] !~ /pcheck|message|control|disable/) && ($pg==1 || ($pg==0 && $table[0][$col]!~/power|ground/))){
      if ($port_ref_table[2][$col] eq 1){ # real port
       $portsensisity=$portsensisity." $port_ref_table[7][$col] or";
      }else{
        if ($port_ref_table[2][$col] eq 1){ # real port
          $portsensisity=$portsensisity." $port_ref_table[7][$col] or";
        }else{
          $portsensisity=$portsensisity." $table[$rowport][$col] or";
        }
      }
    }
  }
  $portsensisity=~s/or$//;
  return $portsensisity;
}

sub put_ast_for_lack_ptn{ #[0] lack log file [1] assertion file
  my ($lackfile,$file,$pr,$sim,$wave)=@_;
  my $para_idx=0;
  my @border_line=();
  my @port_ref_table=@$pr;
  # Open lack log file get info
  open(my $LACKLOG, $lackfile);
  my @log=<$LACKLOG>;
  # Get border line seperating truth table
  for(my $i=0;$i<scalar(@log);$i++){
    if ($log[$i]=~/\/\/[-]+next truth table/){
      $border_line[scalar(@border_line)]=$i;
    }
  }
  close($LACKLOG);

  # Print content of complete assertion
  open(AST, ">>$file");
  return(1) if (!(fileno(AST)));

  my $ast=0;
  my %vector_list;
  print(AST "\n\n//=============================================//\n");
  print(AST "//============Completeness lack patterns=======//\n");
  print(AST "//=============================================//\n");
  close(AST);
  for(my $bi=0;$bi<scalar(@border_line);$bi++){# for each part in lack log
    # Calculate start line and end line of each truth table
    my $start_line=$border_line[$bi]+3;#start line content value of lack pattern
    my $end_line=0;
    if ($bi==scalar(@border_line)-1){#last item
      $end_line=scalar(@log)-1; # end line of log file
    }else{
      $end_line=$border_line[$bi+1]-2; # 1 for previous, 1 for empty line
    }
    # Print content
    my @table = (); 
    @{$table[0]}=("Sheet","line",split_line($log[$start_line-2], "\t"));
    @{$table[1]}=("-","-",split_line($log[$start_line-1], "\t"));
    my $row = 2;
    for(my $li=$start_line;$li<=$end_line;$li++){# for each lack pattern
      @{$table[$row]} = ("-","-",split_line($log[$li], "\t"));
      $row++;
    }
    my $start_row = 2; # start from row 2 of truth table
    $ast = print_ast($file,"completeness",\@table,\@port_ref_table, \%vector_list, $start_row, $ast,"",$sim, $wave);
  }
  return(0);
}

sub print_ast{
  my ($file, $prefix, $tbl_,$pr, $vl, $start_row, $ast, $portsensisity, $sim, $wave, $ctrl_ex_message) = @_;
  my @table = @$tbl_;
  my @port_ref_table = @$pr;
  open(AST, ">>$file");
  return(1) if (!(fileno(AST)));
  my $print = "";
  my $mode_col = -1;
  my $ex_msg_col = -1;
  my $assert_ctrl_col = -1;
  my $assert_ctrl_n_col = -1;
  my $ex_disable_col = -1;
  my $ex_control_col = -1;
  my $ex_control_n_col = -1;
  my $ex_clock_col=-1;
  my $is_ctrl_ast = -1;
  # Get message and disable column in Exclude sheet
  for(my $i=0; $i<scalar(@{$table[0]});$i++){
    if($prefix eq "exclude"){
      if($table[0][$i] eq "message"){
        $ex_msg_col = $i;
      }
      if($table[0][$i] eq "disable"){
        $ex_disable_col = $i;
      }
      if($table[0][$i] eq "clock"){
        $ex_clock_col = $i;
      }
      if($table[0][$i] =~ /^assert_control$/){
        $assert_ctrl_col = $i;
      }
      if($table[0][$i] =~ /^assert_control_n$/){
        $assert_ctrl_n_col = $i;
      }
    }
    if($table[0][$i] =~ /^control$/){
      $ex_control_col = $i;
    }
    if($table[0][$i] =~ /^control_n$/){
      $ex_control_n_col = $i;
    }
  }
  for(my $j=2;$j<scalar(@{$table[0]});$j++){
    if (defined $table[0][$j] && $table[0][$j] eq "Mode"){
      $mode_col = $j;
      last;
    }
  }
  for(my $i=$start_row;$i<scalar(@table);$i++){
    my $pt="";
    my $hold_port="";
    my $ast_str = "";
    my $strong_hold_ast_str = "";
    my $row_num = $table[$i][1];
    my $mode = "";
    my $is_hold_row = 0;
    $is_ctrl_ast = -1;
    $row_num =~ s/\)\(/_/g;
    $row_num =~ s/\)$//g;
    $row_num =~ s/\W/_/g;
    my $second_index = "";
    $is_ctrl_ast = 0;
    if (exists $vl->{"$row_num"}) {
      $vl->{"$row_num"} = $vl->{"$row_num"} + 1;
    } else {
      $vl->{"$row_num"} = 0;
    }
    $second_index = "_".$vl->{"$row_num"} if ($vl->{"$row_num"} != 0);
    if ($row_num =~ /_?ERKS_HOLD/ || $row_num =~ /_?ERKS_STRONG_HOLD/) {
      $row_num =~ s/_?ERKS_HOLD_//;
      $mode = "_latch";
      $is_hold_row = 1;
    } elsif ($row_num =~ /_?ERKS_SUBHOLD/) {
      $row_num =~ s/_?ERKS_SUBHOLD\d*_//;
    } elsif ($mode_col ne "-1") {
      $mode = $table[$i][$mode_col];
      $mode =~ s/ERKS_SUB_MODE_// if ($mode =~ /^ERKS_SUB_MODE_/);
      $mode =~ s/\W/_/g;
      $mode = "_$mode";
    }
    if($ex_control_col != -1 && $ex_control_n_col != -1){
        if($table[$i][$ex_control_col] ne "-" && $table[$i][$ex_control_n_col] ne "-"){
            my $line_tmp = $table[$i][1];
            $line_tmp =~ s/(\W+)//g;
            print("ERROR ::: [$table[$i][0]] Erakis does not support define the value in both \"control\" and \"control_n\" columns at line $table[$i][1].\n");
            close(AST);
            system ("rm -f $file");
            exit(3);
        }
        if($table[$i][$ex_control_col] ne "-") {
            $ast_str=$ast_str."  `ifdef $table[$i][$ex_control_col]\n";
            $is_ctrl_ast = 1;
        }
        if($table[$i][$ex_control_n_col] ne "-"){
            $ast_str=$ast_str."  `ifndef $table[$i][$ex_control_n_col]\n";
            $is_ctrl_ast = 1;
        }
  }else{
        if($ex_control_col != -1  && $table[$i][$ex_control_col] ne "-"){
            $ast_str=$ast_str."  `ifdef $table[$i][$ex_control_col]\n";
            $is_ctrl_ast = 1;
        }
        if($ex_control_n_col != -1 && $table[$i][$ex_control_n_col] ne "-"){
            $ast_str=$ast_str."  `ifndef $table[$i][$ex_control_n_col]\n";
            $is_ctrl_ast = 1;
        }
    }
    if ($prefix eq "check") {
        $ast_str=$ast_str."  check_".$table[$i][0]."_".$row_num."$mode$second_index : assert property (\n";
    }else{
        $ast_str=$ast_str."  $prefix$ast : assert property (\n";
    }
    if($portsensisity eq ""){
        my $disable_str = "i0==0";
        if($ex_disable_col != -1){
            if($table[$i][$ex_disable_col] ne "-"){
                $disable_str = "i0==0 || $table[$i][$ex_disable_col])";
            }
        }
        $ast_str=$ast_str."    \@(i0) disable iff($disable_str)\n";
    }else{
        if($ex_clock_col == -1){
            $ast_str=$ast_str."    \@($portsensisity)";
        }else{
            if($table[$i][$ex_clock_col] =~ /rise/){
                $ast_str=$ast_str."    \@( posedge $table[2][$ex_clock_col])";
            }elsif($table[$i][$ex_clock_col] =~ /fall/){
            $ast_str=$ast_str."    \@( negedge $table[2][$ex_clock_col])";
          }else{
            $ast_str=$ast_str."    \@($table[2][$ex_clock_col])";
          }
        }
        if($ex_disable_col != -1){
            if($table[$i][$ex_disable_col] ne "-"){
                $ast_str=$ast_str." disable iff($table[$i][$ex_disable_col])";
            }
        }
        $ast_str=$ast_str."\n";
    }
    my $exist_cont = -1;
    for(my $j=2;$j<scalar(@{$table[$i]});$j++){
      $pt = $pt."(port_dir[$port_ref_table[1][$j]] === 1'b1)&&" if ($port_ref_table[4][$j] == "2" && $table[0][$j] =~ /input|electrical_in/);
      $pt = $pt."(port_dir[$port_ref_table[1][$j]] === 1'b0)&&" if ($port_ref_table[4][$j] == "2" && $table[0][$j] =~ /output|electrical_out/);
      if($port_ref_table[4][$j] eq "-2" || $port_ref_table[4][$j] eq "1" || $table[0][$j] =~ /output|electrical_out/ || $table[$i][$j] =~ /^\*$/){
        next;
      }
      if ($table[$i][$j] =~ /ramp.*/){
        my $exp = $table[$i][$j];
        $exp =~ s/^.*\(//;
        $exp =~ s/\).*$//;
        my ($min, $max, $def_step)=split(",",$exp);
        if($sim !=2){
          $pt = $pt."($port_ref_table[7][$j] > $min)&&($port_ref_table[7][$j] < $max)&&";
        }else{
          if($wave ne "ams"){
            $pt = $pt."($port_ref_table[0][$j]_c > $min)&&($port_ref_table[0][$j]_c < $max)&&";
          }else{
            $pt = $pt."($port_ref_table[0][$j] > $min)&&($port_ref_table[0][$j] < $max)&&";
          }
        }
      }elsif ($table[$i][$j] =~ /^-$/ || $table[$i][$j] =~ /^S$/i){
        if ($port_ref_table[2][$j] eq 1){ # real port
          my ($min,$max,$def_step)=split(/,/,$port_ref_table[6][$j]);
          if($sim !=2){
            $pt= $pt."(($port_ref_table[7][$j] === $min)||($port_ref_table[7][$j] === $max)";
            if ($port_ref_table[5][$j] eq "3"){
              $pt =$pt."||($port_ref_table[7][$j] === `wrealXState)";
            }elsif ($port_ref_table[5][$j] eq "4"){
              $pt =$pt."||($port_ref_table[7][$j] === `wrealXState)||($port_ref_table[7][$j] === `wrealZState)";
            }
          }else{ # IES simulation
            if($wave ne "ams"){
              $pt= $pt."(($port_ref_table[0][$j]_c === $min)||($port_ref_table[0][$j]_c === $max)";
              if ($port_ref_table[5][$j] eq "3"){
                $pt =$pt."||($port_ref_table[0][$j]_c === `wrealXState)";
              }elsif ($port_ref_table[5][$j] eq "4"){
                $pt =$pt."||($port_ref_table[0][$j]_c === `wrealXState)||($port_ref_table[0][$j]_c === `wrealZState)";
              }
            }else{
              $pt= $pt."(($port_ref_table[0][$j] === $min)||($port_ref_table[0][$j] === $max)";
              if ($port_ref_table[5][$j] eq "3"){
                $pt =$pt."||($port_ref_table[0][$j] === 1'bx)";
              }elsif ($port_ref_table[5][$j] eq "4"){
                $pt =$pt."||($port_ref_table[0][$j] === 1'bx)||($port_ref_table[0][$j] === 1'bz)";
              }
            }
          }
          $pt =$pt.")&&";
        }else{
          $pt= $pt."(($port_ref_table[7][$j] === 1'b0)||($port_ref_table[7][$j] === 1'b1))&&";
        }
      }elsif ($table[$i][$j] =~ /^RISE$/i){
        $pt = $pt."(\$rose($port_ref_table[7][$j]))&&";
      }elsif ($table[$i][$j] =~ /^FALL$/i){
        $pt = $pt."(\$fell($port_ref_table[7][$j]))&&";
      }elsif ($table[$i][$j] =~ /^EXP_NOT_/i){
        my $val = $table[$i][$j];
        $val =~ s/EXP_NOT_//;
        $val =~ s/_.*$//;
        $val = "1'b".$val;
        $pt = $pt."($port_ref_table[7][$j] !== $val)&&";
      }else{
        if ($port_ref_table[2][$j] eq 1){ # real port
          if($sim !=2){
            $pt= $pt.real_port_assertion($port_ref_table[7][$j],$table[$i][$j],3,0);
          }else{
            if($wave ne "ams"){
              $pt= $pt.real_port_assertion($port_ref_table[0][$j]."_c",$table[$i][$j],3,0);
            }else{
              $pt= $pt.real_port_assertion($port_ref_table[0][$j],$table[$i][$j],3,0);
            }
          }
        }else{
          $pt= $pt."($port_ref_table[7][$j] === 1'b$table[$i][$j])&&";
        }
      }
    }
    if($table[$i][1] =~ /STRONG_HOLD/ and $is_hold_row == 1){
        $pt = $pt." (state !== BACK_TO_HOLD)";
    }
    $pt=~s/\&\&$//;
    if ($pt !~ /^\s*$/){ # Care input (not all *)
      if ($portsensisity eq "") {
        $ast_str=$ast_str."    ($pt) |-> ";
      }else{
        $ast_str=$ast_str."    not($pt)";
      }
      $exist_cont = 1 if ($portsensisity ne "");
    }else{
      $ast_str=$ast_str."    ";
    }
    $pt="";
    for(my $j=2;$j<scalar(@{$table[$i]});$j++){
      if($port_ref_table[4][$j] eq "-2" || $table[0][$j] !~ /output|electrical_out/ || ($port_ref_table[3][$j] eq "1" and $portsensisity eq "") || $table[$i][$j] =~ /^\*$/){
        next;
      }
      if ($table[$i][$j] =~ /#.*\$/ || $table[$i][$j] =~ /^\(.*\)$/){
        my $expr = $table[$i][$j];
        if($sim ==2  && $wave ne "ams"){
          $expr =~ s/\.r/_c/g;    
        }
        $expr =~ s/#/\(/g;
        $expr =~ s/\$/\)/g;
        my $tmp_ast="";
        if ($port_ref_table[2][$j] eq 1){ # real port
          if($sim !=2){
            $tmp_ast = "(($port_ref_table[7][$j] > (($expr)-delta))&&($port_ref_table[7][$j] < (($expr)+delta))";
            if ($port_ref_table[5][$j] == 3){ # x value x
              $tmp_ast = "($tmp_ast)||($port_ref_table[7][$j] === `wrealXState)";
            }elsif($port_ref_table[5][$j] == 4){ # x value x z
              $tmp_ast = "($tmp_ast)||($port_ref_table[7][$j] === `wrealXState)||($port_ref_table[7][$j] === `wrealZState)";
            }
          }else{
            if($wave ne "ams"){
              $tmp_ast = "(($port_ref_table[0][$j]_c > (($expr)-delta))&&($port_ref_table[0][$j]_c < (($expr)+delta))";
              if ($port_ref_table[5][$j] == 3){ # x value x
                $tmp_ast = "($tmp_ast)||($port_ref_table[0][$j]_c === `wrealXState)";
              }elsif($port_ref_table[5][$j] == 4){ # x value x z
                $tmp_ast = "($tmp_ast)||($port_ref_table[0][$j]_c === `wrealXState)||($port_ref_table[0][$j]_c === `wrealZState)";
              }
            }else{
              $tmp_ast = "(($port_ref_table[0][$j] > (($expr)-delta))&&($port_ref_table[0][$j] < (($expr)+delta))";
              if ($port_ref_table[5][$j] == 3){ # x value x
                $tmp_ast = "($tmp_ast)||($port_ref_table[0][$j] === 1'bx)";
              }elsif($port_ref_table[5][$j] == 4){ # x value x z
                $tmp_ast = "($tmp_ast)||($port_ref_table[0][$j] === 1'bx)||($port_ref_table[0][$j] === 1'bz)";
              }
            }
          }
        }else{
          $tmp_ast = "(($port_ref_table[7][$j] === ($expr))";
          if ($port_ref_table[5][$j] == 3){ # x value x
             $tmp_ast = "($tmp_ast)||($port_ref_table[7][$j] === 1'bx)";
          }elsif($port_ref_table[5][$j] == 4){ # x value x z
             $tmp_ast = "($tmp_ast)||($port_ref_table[7][$j] === 1'bx)||($port_ref_table[7][$j] === 1'bz)";
          }
        }
        $pt= $pt.$tmp_ast.")&&";
      }elsif ($table[$i][$j] =~ /^HOLD$/ and $is_hold_row == 1){ 
        $pt= $pt."\$stable($table[2][$j])&&";
      }elsif ($table[$i][$j] =~ /^STRONG_HOLD$/ and $is_hold_row == 1){ 
        $pt= $pt."\$stable($table[2][$j])&&";
        $hold_port = $table[2][$j];
      }else{
        if ($port_ref_table[2][$j] eq 1){ # real port
          if($sim !=2){
            $pt= $pt.real_port_assertion($port_ref_table[7][$j],$table[$i][$j],3,1);
          }else{
            if($wave ne "ams"){
              $pt= $pt.real_port_assertion($port_ref_table[0][$j]."_c",$table[$i][$j],3,1);
            }else{
              $pt= $pt.real_port_assertion($port_ref_table[0][$j],$table[$i][$j],3,1);
            }
          }
        }else{
          $pt= $pt."($port_ref_table[7][$j] === 1'b$table[$i][$j])&&";
        }
      }
    }
    $pt=~s/\&\&$//;
    if ($pt !~ /^\s*$/){ # Care output (not all *)
      if ($portsensisity eq "") {
        $ast_str=$ast_str."($pt)";
      }else{
        if ($ast_str !~ /^\s*$/){
          if($ast_str =~ /not/){
            $ast_str =~ s/\)$//g;
          }
          $ast_str=$ast_str."&&$pt";
          if($ast_str =~ /not/){
            $ast_str = $ast_str.")";
          }
        }
        $ast_str=$ast_str."not($pt)" if ($ast_str =~ /^\s*$/);
      }
      $exist_cont = 1;
    }
#    $pt="";
#    if($ex_msg_col != -1){
#      if($table[$i][$ex_msg_col] ne "-"){
#        $ast_str=~s/\&\&$//g;
#        $pt=$pt.", \$display(\"$table[$i][$ex_msg_col]\\n\")";
#      }
#    }else{
#      $pt=$pt.")";
#    }
#    $ast_str=$ast_str.$pt;
    $pt="";
    if ($exist_cont eq "1") {
      $ast_str = $ast_str."\n  )";
      if($ex_msg_col ne -1){
        if($table[$i][$ex_msg_col] ne "-"){
            if ($ctrl_ex_message ne "" && $assert_ctrl_col != -1  && $assert_ctrl_n_col != -1){
                if ($ctrl_ex_message ne "" || $table[$i][$assert_ctrl_col] ne "-" || $table[$i][$assert_ctrl_n_col] ne "-"){
                    if($table[$i][$assert_ctrl_col] ne "-" && $ctrl_ex_message ne ""){
                        print("ERROR ::: [$table[$i][0]] Erakis does not support define the value of assert_control column while \"assert_control\" tag in \"Erakis info\" sheet is defined.\n");
                        close(AST);
                        system ("rm -f $file");
                        exit(3);
                    }
                    if($table[$i][$assert_ctrl_n_col] ne "-" && $ctrl_ex_message ne ""){
                        print("ERROR ::: [$table[$i][0]] Erakis does not support define the value of assert_control_n column while \"assert_control\" tag in \"Erakis info\" sheet is defined.\n");
                        close(AST);
                        system ("rm -f $file");
                        exit(3);
                    }
                    if($table[$i][$assert_ctrl_col] ne "-" && $table[$i][$assert_ctrl_n_col] ne "-"){
                        print("ERROR ::: [$table[$i][0]] Erakis does not support define the value in both \"assert_control\" and \"assert_control_n\" columns at line $table[$i][1].\n");
                        close(AST);
                        system ("rm -f $file");
                        exit(3);
                    }
                }
                if($table[$i][$assert_ctrl_col] ne "-"){
                    $pt=$pt." else begin `ifdef $table[$i][$assert_ctrl_col] \$display(\"$table[$i][$ex_msg_col]\\n\"); `endif end";
                }elsif($table[$i][$assert_ctrl_n_col] ne "-"){
                    $pt=$pt." else begin `ifndef $table[$i][$assert_ctrl_n_col] \$display(\"$table[$i][$ex_msg_col]\\n\"); `endif end";
                }else{
                    $pt=$pt." else begin `ifdef $ctrl_ex_message \$display(\"$table[$i][$ex_msg_col]\\n\"); `endif end";
                }
            }elsif($ctrl_ex_message ne "" && $assert_ctrl_col != -1){
                if($table[$i][$assert_ctrl_col] ne "-" && $ctrl_ex_message ne ""){
                    print("ERROR ::: [$table[$i][0]] Erakis does not support define the value of assert_control column while \"assert_control\" tag in \"Erakis info\" sheet is defined.\n");
                    close(AST);
                    system ("rm -f $file");
                    exit(3);
                }
                if($table[$i][$assert_ctrl_col] ne "-"){
                    $pt=$pt." else begin `ifdef $table[$i][$assert_ctrl_col] \$display(\"$table[$i][$ex_msg_col]\\n\"); `endif end";
                }else{
                    $pt=$pt." else begin `ifdef $ctrl_ex_message \$display(\"$table[$i][$ex_msg_col]\\n\"); `endif end";
                }
            }elsif ($ctrl_ex_message ne "" &&  $assert_ctrl_n_col != -1){
                if($table[$i][$assert_ctrl_n_col] ne "-" && $ctrl_ex_message ne ""){
                    print("ERROR ::: [$table[$i][0]] Erakis does not support define the value of assert_control_n column while \"assert_control\" tag in \"Erakis info\" sheet is defined.\n");
                    close(AST);
                    system ("rm -f $file");
                    exit(3);
                }
                if($table[$i][$assert_ctrl_n_col] ne "-"){
                    $pt=$pt." else begin `ifndef $table[$i][$assert_ctrl_n_col] \$display(\"$table[$i][$ex_msg_col]\\n\"); `endif end";
                }else{
                    $pt=$pt." else begin `ifdef $ctrl_ex_message \$display(\"$table[$i][$ex_msg_col]\\n\"); `endif end";
                }
            }elsif ($assert_ctrl_col != -1  && $assert_ctrl_n_col != -1){
                if($table[$i][$assert_ctrl_col] ne "-" && $table[$i][$assert_ctrl_n_col] ne "-"){
                    print("ERROR ::: [$table[$i][0]] Erakis does not support define the value in both \"assert_control\" and \"assert_control_n\" columns at line $table[$i][1].\n");
                    close(AST);
                    system ("rm -f $file");
                    exit(3);
                }
                if($table[$i][$assert_ctrl_n_col] ne "-"){
                    $pt=$pt." else begin `ifndef $table[$i][$assert_ctrl_n_col] \$display(\"$table[$i][$ex_msg_col]\\n\"); `endif end";
                }
                if($table[$i][$assert_ctrl_col] ne "-"){
                    $pt=$pt." else begin `ifdef $table[$i][$assert_ctrl_col]  \$display(\"$table[$i][$ex_msg_col]\\n\"); `endif end";
                }
            }elsif ($assert_ctrl_col != -1){
                if($table[$i][$assert_ctrl_col] ne "-"){
                    $pt=$pt." else begin `ifdef $table[$i][$assert_ctrl_col] \$display(\"$table[$i][$ex_msg_col]\\n\"); `endif end";
                }else{
                    $pt=$pt." else  \$display(\"$table[$i][$ex_msg_col]\\n\")";
                }
            }elsif ($assert_ctrl_n_col != -1){
                if($table[$i][$assert_ctrl_n_col] ne "-"){
                    $pt=$pt." else begin `ifndef $table[$i][$assert_ctrl_n_col] \$display(\"$table[$i][$ex_msg_col]\\n\"); `endif end";
                }else{
                    $pt=$pt." else \$display(\"$table[$i][$ex_msg_col]\\n\")";
                }
            }elsif ($ctrl_ex_message ne "" ){
                $pt=$pt." else begin `ifdef $ctrl_ex_message \$display(\"$table[$i][$ex_msg_col]\\n\"); `endif end";
            }else{
                $pt=$pt." else \$display(\"$table[$i][$ex_msg_col]\\n\")";
            }
        }
      }
      $pt=$pt.";\n";
      if($is_ctrl_ast == 1){
          $pt=$pt."  `endif\n";
      }
      $ast_str=$ast_str.$pt;
      
      $print = $print."$ast_str";
# Process for STRONG_HOLD  
      if($hold_port ne ""  and $is_hold_row == 1){
        $strong_hold_ast_str = $ast_str;
        $strong_hold_ast_str =~ s/state !== BACK_TO_HOLD/state === BACK_TO_HOLD/g;
        $strong_hold_ast_str =~ s/\$stable\($hold_port\)/$hold_port === \$past\($hold_port,2\)/g;
        $strong_hold_ast_str =~ s/$prefix/$prefix\_BACK_HOLD/g;
        $print = $print."\n"."$strong_hold_ast_str";
      }
      if ($prefix ne "check") {  
        $ast++;
      }
    }
#    if($ex_control_col != -1){
#        if($table[$i][$ex_control_col] ne "-"){
#            $print=$print."  `endif\n";
#        }
#    }
    $print=$print."\n";
  }
  print(AST "\n//------------next truth table-------//\n") if ($print ne "" && $portsensisity eq "");
  print(AST "$print") if ($print ne "");
  close(AST);
  return $ast;
}

sub split_line{#[0] line to split [1] split pattern
  my ($log_line, $ptn)=@_;
  my @array=();
  my @tmp=();
  # NOTE: lack log formats are different
  if ($ptn eq " "){# split output of haskel check lack log
    @tmp = split(/[$ptn]+/, substr($log_line, 1, length($log_line)-2));# remove first empty, remove \n
  }elsif($ptn eq"\t"){#plit lack log file
    @tmp = split(/[$ptn]+/, substr($log_line, 0, length($log_line)-2));#remove \n character
  }elsif($ptn eq ","){# state path
    @tmp = split(/[$ptn]+/, substr($log_line, 0, length($log_line)-1));
  }
  for(my $i=0;$i<scalar(@tmp);$i++){
    if ($tmp[$i] ne ""){
      $tmp[$i]=~s/ //g;
      push(@array, $tmp[$i]);
    }
  }
  return @array;
}

### Make shell script for VCS ###
sub MakeVcsScript{ #[0]testbench file name [1]wave type [2]vcs source file [3]verdi source file [4] LD_LIBRARY_PATH [5]-verilog file path
  my ($tb, $wave, $vcs, $verdi,$verilog,$split,$pat,$rnm,$rnm_lib,$timescale,$freq_check,$option,$sdf,$pat_grp,@table)=@_;
  my @sdf_info = @$sdf;
  my $path=`pwd`;
  my @pattern_group = @$pat_grp;
  $path=~s/\n//;
  my $bs="bs -os RHEL6 -M 1000";
  my $opt="-debug_all -cm assert+line+branch -timescale=$timescale "; 
  my $selectSDF = substr($sdf_info[3],0,3);
  if($sdf_info[0] == 1){
      $opt=$opt."+".$selectSDF."delays ";
  }
  if ($rnm == 1 or $freq_check == 1){
    $opt = "$opt -wreal res_def ";
    if ($rnm == 1){
      $opt = $opt." -lca -sverilog $rnm_lib ";
    }
  }
  $opt = $opt.$option;
  # file and option list
  open(IF,">infile.f");
    return(1) if(!(fileno(IF)));
    if($freq_check){
      print(IF $ENV{'ERAKIS_LIB'}."/L2F.vams\n../FreqCheckTop.vams\n");
    }
    print(IF "-sverilog $path/$tb\n$verilog");
  close(IF);

  # Dump control message check
  my $msg_col = -1;
  if (@table != 0){
    for(my $j=2;$j<scalar(@{$table[1]});$j++){
      if($table[0][$j] eq "message"){
        $msg_col=$j;
        last;
      }
    }
  }
  # shell script
  open(RUN,">run_vcs");
    return(1) if(!(fileno(RUN)));
    print(RUN "\#!/bin/csh -f\n\nmkdir exe\ncd exe\n");
    my $fsdb_opt="";
    if($wave eq "fsdb"){ # wave fsdb
      print(RUN "source $verdi\n");
      print(RUN "if(\$?VERDI_HOME) then\n");
      print(RUN "setenv LD_LIBRARY_PATH \"\$VERDI_HOME/share/PLI/VCS/LINUX64/:\$LD_LIBRARY_PATH\"\n");
      print(RUN "set fsdb_opt=\"-P \$VERDI_HOME/share/PLI/VCS/LINUX64/novas.tab \$VERDI_HOME/share/PLI/VCS/LINUX64/pli.a\"\n");
      print(RUN "else if (\$?NOVAS_HOME) then\n");
      print(RUN "setenv LD_LIBRARY_PATH \"\$NOVAS_HOME/share/PLI/VCS/LINUX64/:\$LD_LIBRARY_PATH\"\n");
      print(RUN "set fsdb_opt=\"-P \$NOVAS_HOME/share/PLI/VCS/LINUX64/novas.tab \$NOVAS_HOME/share/PLI/VCS/LINUX64/pli.a\"\n");
      print(RUN "else\n");
      print(RUN "setenv LD_LIBRARY_PATH \"\$NOVAS/share/PLI/VCS/LINUX64/:\$LD_LIBRARY_PATH\"\n");
      print(RUN "set fsdb_opt=\"-P \$NOVAS/share/PLI/VCS/LINUX64/novas.tab \$NOVAS/share/PLI/VCS/LINUX64/pli.a\"\n");
      print(RUN "endif\n");
    }
    print(RUN "set vcs = \"$vcs\"\n");
    my $num_grp = 1;
    if(scalar(@pattern_group) > 0){
       $num_grp = scalar(@pattern_group); 
    }
    my $num_dir = $num_grp*$split;
#    if($split > 1){
#      my $pat_name = $pat;
#      my $ext = $pat;
#      $pat_name =~ s/\.\w+//;
#      $ext =~ s/$pat_name//;
#      open(DEF,">definitionfile");
#      return(1) if(!(fileno(DEF)));
#      foreach my $num(0..($split-1)){
#          if(scalar(@pattern_group) > 0){
#              print(DEF "../$pat_name"."_$num$ext $num\n");
#          }else{
#              print(DEF "../$pat_name"."_$num$ext $num\n");
#          }
#      }
    if($num_dir > 1){
      open(DEF,">definitionfile");
      my $pat_name = $pat;
      my $ext = $pat;
      $pat_name =~ s/\.\w+//;
      $ext =~ s/$pat_name//;
      my $grp_name = "";
      my $split_index = "";
      my $grp_folder = "";
      my $split_folder = "";
      foreach my $num(0..($num_dir-1)){
         $grp_name = "_".$pattern_group[$num+1/$num_grp] if($num_grp > 1);  
         $split_index = "_".$num % $split if($split > 1); 
         $grp_folder = $pattern_group[$num+1/$num_grp] if($num_grp > 1);
         $split_folder = $num % $split if($split > 1);
         print(DEF "../$pat_name$grp_name$split_index$ext $grp_folder$split_folder\n");
      }
      close(DEF);
      if($wave eq "fsdb"){ # wave fsdb
          print(RUN "$bs -source \$vcs vcs $opt -file $path/infile.f \$fsdb_opt -l vcslog.erks \$*\n");
      }else{
          print(RUN "$bs -source \$vcs vcs $opt -file $path/infile.f -l vcslog.erks \$*\n");
      }
      print(RUN "set job_list = \"\"\n");
      print(RUN "set report_dir_list = \"\"\n");
      print(RUN "foreach line (\"`cat ../definitionfile`\")\n");
      print(RUN "  if (\"\$line\" =~ \"#*\") continue\n");
      print(RUN "  set file = `echo \"\$line\" | awk -F\" \" '{print \$1}' `\n");
      print(RUN "  set dir  = `echo \"\$line\" | awk -F\" \" '{print \$2}' `\n");
      print(RUN "  rm -rf \$dir\n");
      print(RUN "  mkdir \$dir\n");
      print(RUN "  cp -f \$file \$dir/$pat\n");
      print(RUN "  cd \$dir\n");
      print(RUN "  ln -fs ../simv ./\n");
      print(RUN "  ln -fs ../csrc ./\n");
      print(RUN "  ln -fs ../simv.daidir ./\n");
      print(RUN "  cp -rf ../simv.vdb ./\n");
      if($wave eq "fsdb"){ # wave fsdb
          print(RUN "  $bs -J job\$dir -B -source \$vcs simv -cm assert+line+branch \$fsdb_opt \$*\n");
      }else{
          print(RUN "  $bs -J job\$dir -B -source \$vcs simv -cm assert+line+branch \$*\n");
      }
      print(RUN "  cd -\n");
      print(RUN "  if (\"\$job_list\" == \"\") then\n");
      print(RUN "    set job_list = \"ended(job\$dir)\"\n");
      print(RUN "  else\n");
      print(RUN "    set job_list = \"\$job_list && ended(job\$dir)\"\n");
      print(RUN "  endif\n");
      print(RUN "  set report_dir_list = \"\$report_dir_list -dir \$dir/simv.vdb\"\n");
      print(RUN "  $bs -J job_report -w \"ended(job\$dir)\" -source \$vcs urg -dir \$dir/simv.vdb -format text -metric assert -report \$dir/urgReport\n");
      print(RUN "end\n");
      print(RUN "$bs -J job_report -w \"\$job_list\" -source \$vcs urg \$report_dir_list -format text -metric assert\n");
      print(RUN "cat vcslog_end.erks >> vcslog.erks; rm -rf vcslog_end.erks\n");
      print(RUN "cat ./urgReport/asserts.txt\n");
      if ($msg_col != -1) {
        print(RUN "cat msg_chk_log.erks\n");
      }
    }else{
      if($wave eq "fsdb"){ # wave fsdb
          print(RUN "$bs -source \$vcs vcs $opt -R -file $path/infile.f \$fsdb_opt -l vcslog.erks \$*\n");
      }else{
          print(RUN "$bs -source \$vcs vcs $opt -R -file $path/infile.f -l vcslog.erks \$*\n");
      }
      print(RUN "$bs -source \$vcs urg -dir ./simv.vdb -format text -metric assert\n");
      print(RUN "cat ./urgReport/asserts.txt\n");
      print(RUN "cat vcslog.erks >> test.log\n");
      print(RUN "mv test.log vcslog.erks\n");
      if ($msg_col != -1){
        print(RUN "cat msg_chk_log.erks\n");
      }
    }
    if($sdf_info[0] ==1){
        print(RUN "if( ! -e $sdf_info[1]) then\n");
        print(RUN "echo \"************** SDF Error: Can not open SDF file $sdf_info[1] for reading\"\n");
        print(RUN "endif \n");
    }
    print(RUN "cd \.\./\n");
    system ("chmod +x run_vcs\n");
  close(RUN);

  return(0);
}

### Make shell script for Incisive ###
sub MakeIusScript{ #[0]testbench file name [1]wave type [2]ius source file path [3] Verdi path [4] LD_LIBRARY_PATH [5]-verilog file path
  my ($tb,$wave,$ius,$verdi,$verilog,$split,$pat,$rnm,$rnm_lib,$timescale,$delay,$freq_check,$option,$sdf,$pat_grp,@table)=@_;
  my @sdf_info = @$sdf;
  my @pattern_group = @$pat_grp;
  my $path=`pwd`;
  $path=~s/\n//;
  my $bs="bs -os RHEL6 -M 10000";
  my $opt="-access +r -timescale $timescale ".$option;
  my $check_point = 10000; # check point for check message
  my $selectSDF = substr($sdf_info[3],0,3);
  if($sdf_info[0] == 1){
    $opt=$opt."+".$selectSDF."delays ";
  }
  if($freq_check==0){
    $opt=$opt." -sv";
  }
  my $num_grp = 1;
  if(scalar(@pattern_group) > 0){
      $num_grp = scalar(@pattern_group); 
  }
  my $num_dir = $num_grp*$split;

# input file
  open(IF,"> infile.f");
    return(1) if(!(fileno(IF)));
    if($freq_check){
      print(IF $ENV{'ERAKIS_LIB'}."/L2F.vams\n../FreqCheckTop.vams\n");
    }
    print(IF "$path/$tb\n$verilog");
  close(IF);

  # Dump control message check
  my $msg_col = -1;
  if (@table != 0){
    for(my $j=2;$j<scalar(@{$table[1]});$j++){
      if($table[0][$j] eq "message"){
        $msg_col=$j;
        last;
      }
    }
  }
  # nsim exe tcl
  open(TCL,">irun.tcl");
    return(1) if(!(fileno(TCL)));
    if($wave ne ""){
      print(TCL "database -open waves -into waves.shm -default\nprobe -create -database waves -all -depth all -waveform\n");
    }
    print(TCL "set loop 1\n");
    print(TCL "set cnt 0\n");
    print(TCL "set log_index 1\n");
    print(TCL "set check_point [expr {$check_point*$delay}]\n");
    if($msg_col != -1 and $split == 1){
      print(TCL "exec echo Summary for message | tee msg_chk_log.erks\n");
    }
    print(TCL "while {\$loop == 1} {\n");
    print(TCL "  set ctrl_time [expr {\$check_point*\$log_index}]\n");
    print(TCL "  stop -time \$ctrl_time ns -label \"Check point\"\n");
    print(TCL "  logfile -set test.log\n");
    print(TCL "  catch {run} results\n");
    print(TCL "  catch {string match {*Cannot continue simulation due to a previous*} \$results} check\n");
    print(TCL "  logfile -set -default\n");
    print(TCL "  if { \$check == 1 } {\n");
    print(TCL "    exit\n");
    print(TCL "  }\n");
    print(TCL "  incr cnt\n");
    if($split > 1){
      print(TCL "  exec grep \"\" test.log | grep -v \"INPUT :::\" | grep -v \"MSG   :::\" >> irun.log\n");
      print(TCL "  exec grep \"\" test.log | grep -v \"INPUT :::\" | grep -v \"MSG   :::\" >> ../irun.log\n");
    }else{
      print(TCL "  exec grep \"\" test.log | grep -v \"INPUT :::\" | grep -v \"MSG   :::\" >> irun.log\n");
    }
    print(TCL "  exec mv test.log \$log_index\n");
    if ($msg_col != -1){
      if($split > 1){
        print(TCL "  exec perl ../../msg_chk.pl \$log_index ../msg_chk_log.erks\n");
      } else {
        print(TCL "  exec perl ../msg_chk.pl \$log_index msg_chk_log.erks\n");
      }
    }
    print(TCL "  exec rm -rf \$log_index\n");
    print(TCL "  incr log_index\n");
    print(TCL "}\n");
    print(TCL "exec rm -rf \$log_index \$log_index\\.rsl\n");
    print(TCL "exit\n");
  close(TCL);

  # shell script
  open(RUN,"> run_irun");
    return(1) if(!(fileno(RUN)));
    print(RUN "\#!/bin/csh -f\n\nmkdir exe\ncd exe\n");
    my $fsdb_opt="";
    if($wave eq "fsdb"){ # wave fsdb
      $fsdb_opt="-loadpli1 debpli:novas_pli_boot";
      print(RUN "source $verdi\n");
      print(RUN "if (\$?VERDI_HOME) then\n");
      print(RUN "setenv LD_LIBRARY_PATH \"\$VERDI_HOME/share/PLI/IUS/LINUX64/:\$LD_LIBRARY_PATH\"\n");
      print(RUN "else if (\$?NOVAS_HOME) then\n");
      print(RUN "setenv LD_LIBRARY_PATH \"\$NOVAS_HOME/share/PLI/IUS/LINUX64/:\$LD_LIBRARY_PATH\"\n");
      print(RUN "else\n");
      print(RUN "setenv LD_LIBRARY_PATH \"\$NOVAS/share/PLI/IUS/LINUX64/:\$LD_LIBRARY_PATH\"\n");
      print(RUN "endif\n");
    
    }
    
    open(IMC,">imc.cmd");
    return(1) if(!(fileno(IMC)));
    if($num_dir > 1){
        open(DEF,">definitionfile");
        my $pat_name = $pat;
        my $ext = $pat;
        $pat_name =~ s/\.\w+//;
        $ext =~ s/$pat_name//;
        my $grp_name = "";
        my $split_index = "";
        my $grp_folder = "";
        my $split_folder = "";
        foreach my $num(0..($num_dir-1)){
           $grp_name = "_".$pattern_group[$num+1/$num_grp] if($num_grp > 1);  
           $split_index = "_".$num % $split if($split > 1); 
           $grp_folder = $pattern_group[$num+1/$num_grp] if($num_grp > 1);
           $split_folder = $num % $split if($split > 1);
           print(DEF "../$pat_name$grp_name$split_index$ext $grp_folder$split_folder\n");
           open(IMC_TMP,">imc$grp_name$split_index.cmd");
           print(IMC_TMP "load $grp_folder$split_folder/cov_work/scope/test\n");
           print(IMC_TMP "report -detail -metrics block|assertion|functional -text -all -out $grp_folder$split_folder/report_summary.txt\n");
           print(IMC_TMP "report -summary -metrics block|assertion|functional -text -all\n");
           return(1) if(!(fileno(IMC_TMP)));
           close(IMC_TMP);
        }
        close(DEF);

#    if($split > 1){
#      my $pat_name = $pat;
#      my $ext = $pat;
#      $pat_name =~ s/\.\w+//;
#      $ext =~ s/$pat_name//;
#      open(DEF,">definitionfile");
#      return(1) if(!(fileno(DEF)));
#      foreach my $num(0..($split-1)){
#        print(DEF "../$pat_name"."_$num$ext $num\n");
#      }
#      close(DEF);
      print(IMC "load all\n");
      print(IMC "report -detail -metrics block|assertion|functional -text -all -out report_summary.txt\n");
      print(IMC "report -summary -metrics block|assertion|functional -text -all\n");

      print(RUN "\nset ius = \"$ius\"\n");
      if($rnm == 1){
        print(RUN "$bs -source \$ius irun $rnm_lib -f $path/infile.f $opt $fsdb_opt -snapshot run_ius -elaborate +nccoverage+all:u:t:b:e:a \$*\n");
      }else{
        print(RUN "$bs -source \$ius irun -f $path/infile.f $opt $fsdb_opt -snapshot run_ius -elaborate +nccoverage+all:u:t:b:e:a \$*\n");
      }
      print(RUN "set job_list = \"\"\n");
      print(RUN "set report_dir_list = \"\"\n");
      print(RUN "foreach line (\"`cat ../definitionfile`\")\n");
      print(RUN "  if (\"\$line\" =~ \"#*\") continue\n");
      print(RUN "  set file = `echo \"\$line\" | awk -F\" \" '{print \$1}' `\n");
      print(RUN "  set dir  = `echo \"\$line\" | awk -F\" \" '{print \$2}' `\n");
      print(RUN "  rm -rf \$dir\n");
      print(RUN "  mkdir \$dir\n");
      print(RUN "  cp -f \$file \$dir/$pat\n");
      print(RUN "  cd \$dir\n");
      print(RUN "  ln -fs ../INCA_libs ./\n");
      print(RUN "  $bs -B -J job\$dir -source \$ius irun -R -snapshot run_ius +nccoverage+all:u:t:e:b:a -input ../../irun.tcl \$*\n");
      print(RUN "  cd -\n");
      print(RUN "  if (\"\$job_list\" == \"\") then\n");
      print(RUN "    set job_list = \"ended(job\$dir)\"\n");
      print(RUN "  else\n");
      print(RUN "    set job_list = \"\$job_list && ended(job\$dir)\"\n");
      print(RUN "  endif\n");
      print(RUN "  set report_dir_list = \"\$report_dir_list .\/\$dir\/cov_work\/scope\/test\"\n");
      print(RUN "  bs -os RHEL6 -M 10000 -w \"ended(job\$dir)\" -source \$ius imc -exec ../imc_\$dir.cmd\n");
      print(RUN "end\n");
      print(RUN "$bs -w \"\$job_list\" -source \$ius imc -execcmd \"merge -out all \$report_dir_list\"\n");
      print(RUN "$bs -w \"\$job_list\" -source \$ius imc -exec ../imc.cmd\n");
      print(RUN "cat report_summary.txt\n");
      if ($msg_col != -1){
        print(RUN "cat msg_chk_log.erks\n");
      }
    }else{
      print(IMC "load test\n");
      print(IMC "report -detail -metrics block|assertion|functional -text -all -out report_summary.txt\n");
      print(IMC "report -summary -metrics block|assertion|functional -text -all\n");

      print(RUN "\nset ius = \"$ius\"\n");
      if($rnm == 1){
        print(RUN "$bs -source \$ius irun $rnm_lib -f $path/infile.f $opt $fsdb_opt +nccoverage+all:u:t:b:e:a -input ../irun.tcl \$*\n");
      }else{
        print(RUN "$bs -source \$ius irun -f $path/infile.f $opt $fsdb_opt +nccoverage+all:u:t:b:e:a -input ../irun.tcl \$*\n");
      }
      print(RUN "$bs -source \$ius imc -exec ../imc.cmd\n");
      if ($msg_col != -1){
        print(RUN "cat msg_chk_log.erks\n");
      }
    }
    if($sdf_info[0] ==1){
        print(RUN "if( ! -e $sdf_info[1]) then\n");
        print(RUN "echo \"************** SDF Error: Can not open SDF file $sdf_info[1] for reading\"\n");
        print(RUN "endif \n");
    }
    print(RUN "cd \.\./\n");
    close(IMC);
  close(RUN);
  system ("chmod +x run_irun\n");
  return(0);
}

### make script for irun with circuit ###
sub MakeAMSScript{ #[0]:tb_file [1]:Incisive [2]:virtuoso [3]:cell [4]:cds.lib [5]:lib_name [6]:view_name [7]:fin_time [8]:timescale [9]:connectrule
  my ($testbench, $irun_env, $virtuoso_env, $cell, $lib_path, $lib, $view, $fin_time, $timescale, $rule, $option, $rnm, $rnm_lib)=@_;
  my $path=`pwd`;

  $path=~s/\n//;
  my $bs="bs -os RHEL6 -M 10000 -source";

  # probe.tcl
  open(TCL,"> probe.tcl");
    if(!fileno(TCL)){
      print("tcl?\n");
      return(1);
    }
    print(TCL "\n\# database settings\nset AMS_RESULTS_DIR \"./psf\"\ndatabase -open ams_database -into \${AMS_RESULTS_DIR} -defalt\n");
    print(TCL "\n\# probe settings\nprobe -create -emptyok -database ams_database {TestBCover.\*}\n");
    print(TCL "probe -create -emptyok -database ams_database {TestBCover.AmsTop.\*}\n");
  close(TCL);
  
  # control spectre
  open(CTL,"> amsControlSpectre.scs");
    if(!fileno(CTL)){
      print("amscontrol?\n");
      return(1);
    }
    print(CTL "\nsimulator lang=spectre\n\ntran tran stop=$fin_time\n");
  close(CTL);

  # ocean script
  open(OCN,"> $cell.ocn");
    if(!fileno(OCN)){
      print("ocn?\n");
      return(1);
    }
    print(OCN "simulator(\'ams)\nsolver(\'Spectre)\ndesign(\"$lib\" \"$cell\" \"$view\")\nocnAmsSetOSSNetlister()\ncreateNetlist()\nexit\n");
  close(OCN);
  
  # execution file
  open(EXE,"> run_irun");
    if(!fileno(EXE)){
      print("irun?\n");
      return(1);
    }
    print(EXE "\#!/bin/sh\n\nmkdir exe\ncd exe\n\n");
    print(EXE "cp $lib_path/\.cdsinit \./\ncp $lib_path/cds\.lib \./\nif [ -e $lib_path/\.simrc ]\; then\n  cp $lib_path/\.simrc \./\nfi\n\n");
    print(EXE "\# change simulation directory\necho \"\" >> .cdsinit\necho \"envSetVal( \\\"asimenv.startup\\\" \\\"projectDir\\\" \'string \\\"\${PWD}\\\" )\" >> .cdsinit\n\n");
    print(EXE "\# make circuit netlist\n$bs $virtuoso_env virtuoso -nograph -restore ../$cell.ocn\n\n");
    print(EXE "\# make infile.f\nrm -rf infile.f\ntouch infile.f\n");
    if($rnm == 1){
      print(EXE "echo \"$rnm_lib\" >> infile.f\n");
    }
    print(EXE "echo \"../$testbench\" >> infile.f\necho \"../AmsTop.vams\" >> infile.f\n");
    print(EXE "if [ -e $cell/ams/$view/netlist/userDisciplines.vams ]; then\n  cp $cell/ams/$view/netlist/userDisciplines.vams ./\nfi\n");
    print(EXE "echo \"$cell/ams/$view/netlist/netlist.vams\" >> infile.f\n\n");
    print(EXE "\# make irunArgs\nrm -rf irunArgs\ntouch irunArgs\necho \"-cdslib ./cds.lib\" >> irunArgs\n");
    print(EXE "echo \"-timescale $timescale\" >> irunArgs\n");
    print(EXE "echo \"-discipline logic\" >> irunArgs\n");
    print(EXE "echo \"-amsconnrules $rule\" >> irunArgs\n");
    print(EXE "echo \"../amsControlSpectre.scs\" >> irunArgs\n");
    print(EXE "echo \"-access r\" >> irunArgs\n");
    print(EXE "echo \"-input ../probe.tcl\" >> irunArgs\n");
    print(EXE "echo \"-run -exit\" >> irunArgs\n");
    print(EXE "echo -ncsimargs \\\"+amsrawdir ./psf\\\" >> irunArgs\n");
    print(EXE "echo \"-l ./irun.log\" >> irunArgs\n");
    print(EXE "echo \"-f ./infile.f\" >> irunArgs\n");
    print(EXE "echo \"$option\" >> irunArgs\n");
    print(EXE "if [ -e $cell/ams/$view/netlist/textInputs ]; then\n  echo \"-f $cell/ams/$view/netlist/textInputs\" >> irunArgs\nfi\n\n");
    print(EXE "\# execution irun\n$bs $irun_env irun -f irunArgs\n\n");
    print(EXE "\# clean files\nrm .cdsinit cds.lib .simrc\n\ncd ../\n");
  close(EXE);
  system ("chmod +x run_irun\n");
  
  return(0);
}

### checking table ###
sub CheckOverlap{ #[0]:max error [1]:log file [2] -rnm option [3]:table
  my ($max, $cr_str,$file, $rnm, $tbl_org,$pr,$vtl,$ptbl,$blank_error,$clock_info_)=@_;
  my @table_org=@$tbl_org;
  my @port_ref= @$pr;
  my @port = @$ptbl;
  my @merged_port=CheckCompressionPort($cr_str, @port);
  $max=$max+1;
  my $str=0;
  open(LOG,">$file");
    return(1) if(!fileno(LOG));
    print(LOG "\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\# Error Summary \#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\n");
    my($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst)=localtime(time);
    my $pt=sprintf("%02d\/%02d\/%02d %02d:%02d:%02d",$year-100,$mon+1,$mday,$hour,$min,$sec);
    print(LOG "\#  Executed $pt                                     \#\n");
#    my $user=$ENV{'USERNAME'};
    my $user=$ENV{'USER'};
    printf(LOG "\#  Executed User : %20s                           \#\n",$user);
    my $version=$ENV{'ERAKIS_VER'};
    print(LOG "\#  Checked by $version                           \#\n");
    print(LOG "\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\n");
    print(LOG "\nnumber of port name:");

    # Split table before checking
    my @TruthTableList = Ex2Tbl::SeparateTruthTable($rnm, @table_org);
    for (my $tt=0;$tt<scalar(@TruthTableList);$tt++){
      my @table = @{$TruthTableList[$tt]};
      my @split_table = @table;
      if ($rnm == 1){
        my $cont = 1;
        ($cont,@split_table)=Ex2Tbl::SplitPatTable(\@split_table,$pr);
        while ($cont == 1){
          ($cont,@split_table)=Ex2Tbl::SplitPatTable(\@split_table,$pr);
        }
      }
      @table = @split_table;
      my $header_print = "";
      $header_print = $header_print."\n========================\n";
      $header_print = $header_print."\nSheet\tline\t";
      for(my $i=0;$i<scalar(@{$table[0]});$i++){
        if($table[0][$i] =~ /power|ground|clock|input|output|electrical_in|electrical_out/){
          $header_print = $header_print."$table[0][$i]\t";
        }
      }
      $header_print = $header_print."\n-\t-\t";
      for(my $i=0;$i<scalar(@{$table[0]});$i++){
        if($table[0][$i] =~ /power|ground|clock|input|output|electrical_in|electrical_out/){
          $header_print = $header_print."$table[2][$i]\t";
        }
      }
      $header_print = $header_print."\n";
      my %dup_check;
      my @overlap_table = ();
      my $recheck_flag = -1;
      # create overlap
      open(my $TABLE,">dpltable.txt");
      return(1) if(!fileno($TABLE));
      print($TABLE "; input dpltable.txt file -> haskel -> check overlap patterns\n");
      # Step1: Put information of port table
      print($TABLE "\n; Variables or columns of a given truth table\n");
      for (my $i=2;$i<scalar(@{$table[0]}); $i++){
        if ($table[0][$i] =~ /input|power|ground|clock/){
          my $lv="";
          if ($cr_str eq "-20"){# compress all input port
            $lv="_";
          }else{
            if (grep(/^\Q$table[2][$i]\E$/, @merged_port)>0){
              $lv=$lv."_";
            }
          }
          my ($post_lv, @care_range) = Ex2Tbl::get_port_level($table[2][$i], @port);
          $lv=$lv."lv".$post_lv;
          print($TABLE "(int  $table[2][$i]  $lv)\n");
        }
      }

      # Step2: Put information of truth table
      print($TABLE "\n; Rows of a given truth table\n");
      print($TABLE "; Sheet  line");
      for (my $i=2;$i<scalar(@{$table[0]});$i++){
        if ($table[0][$i] =~ /input|power|ground|clock/){
          print($TABLE "  $table[2][$i]");
        }
      }
      print($TABLE "\n");
      for (my $i=4;$i<scalar(@table);$i++){
        $table[$i][1] =~ s/ERKS_(SUB)?HOLD_//;
        print($TABLE "(row");
        for (my $k=0;$k<scalar(@{$table[0]});$k++){
          if ($k >= 2) {
            if ($table[0][$k] =~ /input|power|ground|clock/){
              if ($table[$i][$k] =~ /^\*$/){
                print($TABLE "  _");
              }elsif ($table[$i][$k] =~ /^(-|S)$/i || $table[$i][$k] =~ /^ramp/i || $table[$i][$k] =~ /^(RISE|FALL)$/){
                print($TABLE "  _");
              }elsif($table[$i][$k] =~ /EXP_NOT_1_VAL/){
                print($TABLE "  0");
              }elsif($table[$i][$k] =~ /EXP_NOT_0_VAL/){
                print($TABLE "  1");
              }elsif($table[$i][$k] =~ /[Xx]/){
                print($TABLE "  2");
              }elsif($table[$i][$k] =~ /[Zz]/){
                print($TABLE "  3");
              }else{
                print($TABLE "  $table[$i][$k]");
              }
            }
          }elsif ($k == 0){
            print($TABLE "  $i");
          }
        }
        print($TABLE ")  ; ID = $table[$i][0]/$table[$i][1]\n");
      }
      close($TABLE);
      # Step3: Run solveBCP
      system("solveBCP findDuplicateRows dpltable.txt &> /dev/null\n");

      # Step4: Exchange output result
      open(my $OVERLAPLOG, "dpltable.dpl.log") or die "ERROR ::: Cannot open temporary table.dpl.log file.\n";
      my @log=<$OVERLAPLOG>;
      my $is_first_ov = 1;
      my %ov_dup_check;
      if (scalar(@log) - 5 > 0){
        my $ov_cont = 0;
        for (my $i=0;$i<4;$i++){
          push(@overlap_table,$table[$i]);
        }
        for (my $i=5;$i<scalar(@log);$i++){
          if ($log[$i] !~ /^\*\*\*ERROR/ and $log[$i] !~ /^ *$/){
            my $row = (split(/ /,$log[$i]))[1];
            push(@overlap_table,$table[$row]) if (!exists $ov_dup_check{"$row"});
            $ov_dup_check{"$row"} = $row;
          }
        }
      }
      close($OVERLAPLOG);
      unlink("dpltable.txt");
      unlink("dpltable.dpl.log");
      unlink("dpltable.dpl.vld0.csp");
      unlink("dpltable.dpl.vld1.csp");
     # Check again if enabled
      if (scalar(@overlap_table) > 4) {
        for(my $i=4;$i<scalar(@overlap_table);$i++){
          next if (grep(/^HOLD$|^STRONG_HOLD$/,@{$overlap_table[$i]})>0);
          for(my $j=$i+1;$j<scalar(@overlap_table);$j++){
            my ($check, $ov_pat) = OverLap(\@{$overlap_table[$i]},\@{$overlap_table[$j]},\@{$overlap_table[0]},\%dup_check,$pr,$vtl,\@port,$rnm,$blank_error,$clock_info_);
            if($check eq "1" && $str<$max){
              if (@$ov_pat != 0){
                my @overlap_pattern=@$ov_pat;
                print(LOG $header_print) if ($is_first_ov eq "1");
                $is_first_ov = -1;
                for (my $l=1;$l<scalar(@overlap_pattern);$l++){
                  print(LOG "***ERROR : Exist Data two or more\n");
                  $str++;
                  for(my $k=0;$k<scalar(@{$overlap_table[$i]});$k++){
                    if($overlap_table[0][$k] =~ /Sheet|line|power|ground|clock|input|output|electrical_in|electrical_out/){
                      if (grep (/^\Q$overlap_table[2][$k]\E/,@{$overlap_pattern[0]}) > 0){
                        my $port_col = Ex2Tbl::get_port_col($overlap_table[2][$k],0,@overlap_pattern);
                        print(LOG "$overlap_pattern[$l][$port_col]\t");
                      }else{
                        my $val = $overlap_table[$i][$k];
                        if ($val =~ /^EXP_NOT_/) {
                          $val =~ s/EXP_NOT_//;
                          $val =~ s/_.*$//;
                          print(LOG "!$val\t");
                        } else {
                          print(LOG "$overlap_table[$i][$k]\t");
                        }
                      }
                    }
                  }
                  print(LOG "\n");
                  for(my $k=0;$k<scalar(@{$overlap_table[$j]});$k++){
                    if($overlap_table[0][$k] =~ /Sheet|line|power|ground|clock|input|output|electrical_in|electrical_out/){
                      if (grep (/^\Q$overlap_table[2][$k]\E/,@{$overlap_pattern[0]}) > 0){
                        my $port_col = Ex2Tbl::get_port_col($overlap_table[2][$k],0,@overlap_pattern);
                        print(LOG "$overlap_pattern[$l][$port_col]\t");
                      }else{
                        my $val = $overlap_table[$j][$k];
                        if ($val =~ /^EXP_NOT_/) {
                          $val =~ s/EXP_NOT_//;
                          $val =~ s/_.*$//;
                          print(LOG "!$val\t");
                        } else {
                          print(LOG "$overlap_table[$j][$k]\t");
                        }
                      }
                    }
                  }
                  print(LOG "\n");
                }
              }else{
                print(LOG $header_print) if ($is_first_ov eq "1");
                $is_first_ov = -1;
                print(LOG "***ERROR : Exist Data two or more\n");
                $str++;
                for(my $k=0;$k<scalar(@{$overlap_table[$i]});$k++){
                  if($overlap_table[0][$k] =~ /Sheet|line|power|ground|clock|input|output|electrical_in|electrical_out/){
                    my $val = $overlap_table[$i][$k];
                    if ($val =~ /^EXP_NOT_/) {
                      $val =~ s/EXP_NOT_//;
                      $val =~ s/_.*$//;
                      print(LOG "!$val\t");
                    } else {
                      print(LOG "$overlap_table[$i][$k]\t");
                    }
                  }
                }
                print(LOG "\n");
                for(my $k=0;$k<scalar(@{$overlap_table[$j]});$k++){
                  if($overlap_table[0][$k] =~ /Sheet|line|power|ground|clock|input|output|electrical_in|electrical_out/){
                    my $val = $overlap_table[$j][$k];
                    if ($val =~ /^EXP_NOT_/) {
                      $val =~ s/EXP_NOT_//;
                      $val =~ s/_.*$//;
                      print(LOG "!$val\t");
                    } else {
                      print(LOG "$overlap_table[$j][$k]\t");
                    }
                  }
                }
                print(LOG "\n");
              }
            }
          }
        }
      }
    }
    print(LOG "\n ### END ###\n");
  close(LOG);
  
  if($str==0){
    unlink($file);
    return(0);
  }else{
    return(3); # exist overlap
  }
}

sub OverLap{
  my ($a, $b, $c, $d, $r, $v,$pt,$rnm,$blank_error,$clock_info_)=@_;
  my @ina=@$a;
  my @inb=@$b;
  my @io=@$c;
  my @pr=@$r;
  my @ov_pat=();
  # check overlap input ports
  return(0,\@ov_pat) if (check_input_overlap($a,$b,$c,$r) eq "0"); # return if input is not overlapped
  
  my @input_pat = Ex2Tbl::get_input_pattern($a,$b,$c,$r);
  # with overlap above, continue check difference output ports -> return 1 when difer
  for(my $i=0;$i<scalar(@io);$i++){
    if($io[$i] =~ /output|electrical_out/){
      if($ina[$i] eq "\*" || $inb[$i] eq "\*"){
        next;
      }elsif($ina[$i] =~ /\(.*\)/ || $inb[$i] =~ /\(.*\)/){ # check expression
        @ov_pat = cmp_expr($ina[$i], $inb[$i], \@input_pat, $r, $v,$pt,$rnm,$blank_error,$clock_info_) if (@input_pat != 0);
        if (scalar(@ov_pat) > 1){
          return(1,\@ov_pat);
        }
      }elsif($ina[$i] ne $inb[$i]){
        return(1,\@ov_pat);
      }
    }
  }
  if (!exists $d->{"$ina[0]/line $ina[1] and $inb[0]/line $inb[1]"}){
    print("WARNING ::: input patterns and output patterns are same in $ina[0]/line $ina[1] and $inb[0]/line $inb[1]\n");
    $d->{"$ina[0]/line $ina[1] and $inb[0]/line $inb[1]"} = "abc";
  }
  return(0,\@ov_pat);
}

sub cmp_expr{
  my ($a, $b, $pat, $pr, $vtl,$ptbl,$rnm,$blank_error,$clock_info_) = @_;
  my @input_pat = @$pat;
  my @port_ref = @$pr;
  my @ref_var = ();
  my $total_input = 0;
  my $input_cnt = 0;
  my @overlap_pattern;
  my @ret_pattern;
  if ($a =~ /^\(.*\)$/){
    $a =~ s/\.r\b//g; # remove ".r" of real port
    ($input_cnt,@ref_var)=Ex2Tbl::get_ref_list($a, \@port_ref, \@ref_var, $vtl);
    $total_input+= $input_cnt;
  }
  if ($b =~ /^\(.*\)$/){
    $b =~ s/\.r\b//g; # remove ".r" of real port
    ($input_cnt,@ref_var)=Ex2Tbl::get_ref_list($b, \@port_ref, \@ref_var, $vtl);
    $total_input+= $input_cnt;
  }
  my @loop_cnt_ctrl = ("0")x $total_input;
  my @port_loop_cnt = ("0")x $total_input;
  my @port_name     = ("") x $total_input;
  my @port_range    = ("0")x $total_input;
  my @port_value    = ("0")x $total_input;
  my @port_col      = ("") x $total_input;
  my @port_break    = ("0")x ($total_input+1);
  my $col = 0;
  $port_break[$total_input]  = "1";
  for (my $i=0;$i<scalar(@{$ref_var[0]});$i++){
    if ($ref_var[2][$i] ne "-1"){
      $port_range[$col] = scalar(@{$input_pat[$ref_var[1][$i]]});
      $port_name[$col]  = $ref_var[0][$i];
      $port_col[$col]   = $ref_var[1][$i];
      $port_value[$col] = $input_pat[$ref_var[1][$i]][0];
      $col++;
    }
  }
  push (@overlap_pattern,[@port_name]);
  my $loop_cont     = 1;
  $loop_cnt_ctrl[$total_input-1] = 1;
  while ($loop_cont == 1) {
    $loop_cont = 0;
    for (my $i1=$total_input-1;$i1>=0;$i1--){
      for(my $i2=0;$i2<$port_range[$i1];$i2++){
        if($port_loop_cnt[$i1]==$i2){
          $port_value[$i1] = $input_pat[$port_col[$i1]][$i2];
          last;
        }
      }
      if ($port_loop_cnt[$i1] >= ($port_range[$i1]-1)){
        $port_break[$i1] = 1;
      }else{
        if ($loop_cnt_ctrl[$i1] == 1) {
          $port_loop_cnt[$i1] = $port_loop_cnt[$i1] + 1;
        }
      }
    } # end for
    # calculate expression with input value
    my $vala = $a;
    my $valb = $b;
    if ($a =~ /^(.*)$/){
      $vala = Ex2Tbl::calc_expr($a,\@port_name,\@port_value,\@ref_var,$vtl,$ptbl,$rnm,$blank_error,$clock_info_);
    }
    if ($b =~ /^(.*)$/){
      $valb = Ex2Tbl::calc_expr($b,\@port_name,\@port_value,\@ref_var,$vtl,$ptbl,$rnm,$blank_error,$clock_info_);
    }
    push (@overlap_pattern,[@port_value]) if ($vala ne $valb);
    my $next_flag = 1;
    for (my $i1=$total_input-1;$i1>=0;$i1--){
      $next_flag = $next_flag & $port_break[$i1];
    }
    if ($next_flag == 1){
      $loop_cont=0;
    } else{
      $loop_cont=1;
      my $disable_cnt=0;
      for (my $i1=$total_input-1;$i1>=0;$i1--){
        $next_flag = 1;
        my $disable_process_loop_ctrl = 0;
        for (my $i2=$total_input-1;$i2>=0;$i2--){
          if ($i2 >= $i1){
            $next_flag = $next_flag & $port_break[$i2];
          }
        }
        if ($port_break[$i1] == 1){
          if($next_flag == 1){
            for (my $i2=$i1-1;$i2>=0;$i2--){
              if ($port_break[$i2] == 1){
                $disable_process_loop_ctrl = 1;
                last;
              }else{
                if ($i1 == $total_input - 1){
                  $disable_cnt = 1;
                }
                last;
              }
            }
            if($disable_process_loop_ctrl eq "0"){
              for (my $i2=$total_input-1;$i2>=$i1;$i2--){
                $port_loop_cnt[$i2] = 0;
                $port_break[$i2] = 0;
              }
              for (my $i2=$i1;$i2>=0;$i2--){
                $loop_cnt_ctrl[$i2] = 0;
              }
              $loop_cnt_ctrl[$total_input-1] = 1;
              $port_loop_cnt[$i1-1]++;
            }
          } else{
            if ($loop_cnt_ctrl[$total_input-1] == 0 && $disable_cnt == 0){
              $port_loop_cnt[$total_input-1]++;
            }
            for (my $i2=$total_input-1;$i2>=0;$i2--){
              $loop_cnt_ctrl[$i2] = 0;
            }
            $port_break[$total_input-1] = 0;
            $loop_cnt_ctrl[$total_input-1] = 1;
          }
        }
      }
    }
  }
  return (@overlap_pattern);
}

sub check_input_overlap{
  my ($a, $b, $c, $r)=@_;
  my @ina = @$a;
  my @inb = @$b;
  my @io  = @$c;
  my @port_ref=@$r;
  for (my $j=0;$j<scalar(@ina);$j++){
    my $is_ov = 0;
    if ($io[$j] =~ /power|ground|input|electrical_in/){ # next column if not input
      my %var   = Ex2Tbl::get_pattern($ina[$j],$j,1,@port_ref);
      my %check = Ex2Tbl::get_pattern($inb[$j],$j,1,@port_ref);
      foreach my $key (keys %var){
        if (exists $check{"$key"}){
          $is_ov = 1;
          last;
        }
      }
      return 0 if ($is_ov == 0);
    }
  }
  return 1;
}

sub CheckTransFromOther{ ## [0] Trans table
  my $ex=0;
  my ($t)=@_;
  my @table=@$t;
  for (my $i=1;$i<scalar(@{$table[0]});$i++){ # Checked col
    my $found=0;
    my $target=$table[0][$i];
    $target=~s/^\*//;
    for (my $k=1;$k<scalar(@{$table[0]});$k++){# compare col
      if ($k == $i){
        next;
      }else{
        for (my $cpr=1;$cpr<scalar(@table);$cpr++){ # compare row
          if ($target eq $table[$cpr][$k]){# Found
            $found=1;
            last; # Break compare row
          }
        }
      }
      if($found==1){
        last; # Break compare col -> continue checking next state
      }
    }
    if($found==0){
      print("WARNING ::: State \"$target\" is not transitted from others.\n");
    }
  }
  return $ex;
}

sub CheckTransToOther{ ## [0] Trans table
  my $ex=0;
  my ($t)=@_;
  my @table=@$t;
  for (my $i=1;$i<scalar(@{$table[0]});$i++){ # checked col
    my $found=0;
    my $target=$table[0][$i];
    $target=~s/^\*//;
    for (my $k=1;$k<scalar(@table);$k++){ # check cell in this col
      if($table[$k][$i] eq $target){
        print("WARNING ::: State \"$target\" transits to itself.\n");
      }else{
        if (!($table[$k][$i] eq "X" || $table[$k][$i] eq "x" || $table[$k][$i] eq "/")){
          $found=1;
          last; # break
        }
      }
    }
    if ($found==0){
      print("WARNING ::: State \"$target\" does NOT transit to other state.\n");
    }
  }
  return $ex;
}

sub GetColumnList {
  my @ret = ();
  my @state_table = @{$_[0]};
  my $col_id = $_[1];
  if ($#_ < 1) {
    $col_id = scalar(@{$state_table[0]})-1;
  }
  for (my $i=1;$i<scalar(@state_table);$i++){
    push(@ret, $state_table[$i][$col_id]);
  }
  return @ret;
}

sub CheckTranStateNotDefine { 
  my $ex    =0;
  my @table =@{$_[0]};
  my @state_list = &GetColumnList($_[1]);
  for (my $i=0;$i<scalar(@table);$i++){ # row
    for (my $j=1;$j<scalar(@{$table[$i]}); $j++) { #col
      my $state = $table[$i][$j];
      $state =~ s/^\*//;
      $state =~ s/^[x\/]$//i;
      if ($state ne '' && grep(/^$state$/, @state_list) < 1) {
        print("ERROR ::: State \"$state\" is NOT existed in state table.\n");
        $ex = 1;
      }
    }
  }
  return $ex;
}

sub CountInitialState {
  my ($stt, @table)=@_;
  my $count    =0;
  for (my $i=1;$i<scalar(@{$table[0]});$i++){ # col
    my $state = $table[0][$i];
    if ($state =~ /^\*/) {
      $count += 1;
    }
  }
  if ($count ==1){
    return 0;
  }elsif($count ==0){
    print("ERROR ::: [$stt] None of initial state is found.\n");
    return 1;
  }else{
    print("ERROR ::: [$stt] More than one inital states is found.\n");
    return 1;
  }
}

sub CheckDuplicatedName {
  my $ex    =0;
  my @table =@{$_[0]};
  my $category = $_[1];
  my $table_name = $_[2];
  foreach my $name (@table) {
    if (grep(/^$name$/, @table) > 1) {
      print("ERROR ::: Duplicate $category '$name' in $table_name table.\n");
      return 1;
    }
  }
  return $ex;
}

sub CheckDuplicatedEventName {
  my $ex = 0;
  my @list = &GetColumnList($_[0]);
  $ex = &CheckDuplicatedName(\@list, "event", "event definition");
  @list = &GetColumnList($_[1], 0);
  $ex += &CheckDuplicatedName(\@list, "event", "transition");
  return $ex;
}

sub CheckDuplicatedStateName {
  my $ex = 0;
  my @list = &GetColumnList($_[0]);
  $ex = &CheckDuplicatedName(\@list, "state", "state definition");
  @list = &GetColumnList($_[1], 0);
  $ex += &CheckDuplicatedName(\@list, "state", "output definition");
  return $ex;
}

sub CheckDuplicatedList {
  my $ex = 1;
  my @c1 = @{$_[0]};
  my @c2 = @{$_[1]};
  for (my $i = 0; $i < scalar(@c1); $i ++) {
    if ($c1[$i] ne $c2[$i] && $c1[$i] ne '*' && $c2[$i] ne '*') {
      $ex = 0;
      last;
    }
  }
  return $ex;
}

sub CheckDuplicatedConds {
  my $ex    =0;
  my @table =@{$_[0]};
  my $category = $_[1];
  for (my $i=2;$i<scalar(@table);$i++){ # row
    my @c1 = @{$table[$i]};
    my $name = pop(@c1);
    for (my $comp = 1; $comp < $i; $comp++) { # previous row
      my @c2 = @{$table[$comp]};
      pop(@c2);
      $ex = &CheckDuplicatedList(\@c1, \@c2);
      if ($ex == 1) {
        print("ERROR ::: Duplicate combination of signals of '$name' in $category table.\n");
        return $ex;
      }
    }
  }
  return $ex;
}

sub CheckMatchSTTAndEDT {
  my $ex = 0;
  my @stt = &GetColumnList($_[2],0);
  $ex = &CheckFullName($_[0], $_[1], $_[3], \@stt, 'event', 'event definition');
  return $ex;
}

sub CheckMatchSTTAndSDT {
  my $ex = 0;
  my @stt = @{$_[2]};
  my @check;
  for (my $i = 1; $i < scalar(@{$stt[0]}); $i++) {
    my $state = $stt[0][$i];
    $state =~ s/^\*//;
    push(@check, $state);
  }
  $ex = &CheckFullName ($_[0], $_[1], $_[3], \@check, 'state', 'state definition');
  $ex += &CheckFullName ($_[1], $_[0], \@check, $_[3], 'state', 'state transition');
  return $ex;
}

sub CheckMatchSTTAndODT {
  my $ex = 0;
  my @ott = &GetColumnList($_[3],0);
  my @stt = @{$_[2]};
  my @check;
  for (my $i = 1; $i < scalar(@{$stt[0]}); $i++) {
    my $state = $stt[0][$i];
    $state =~ s/^\*//;
    push(@check, $state);
  }
  $ex = &CheckFullName($_[1], $_[0],\@check, \@ott, 'state', 'transition');
  $ex += &CheckFullName($_[0], $_[1], \@ott, \@check, 'state', 'output definition');
  return $ex;
}

# Check if all elements in argument 2 are in argument 1
sub CheckFullName {
  my $ex = 0;
  my @c1 = @{$_[2]};
  my @c2 = @{$_[3]};
  my $category = ucfirst($_[4]);
  my $table_name = $_[5];
  for (my $i = 0; $i <= $#c2; $i++){
    if (grep(/^$c2[$i]$/, @c1) < 1) {
      print("ERROR ::: [$_[0]] $category \"$c2[$i]\" is not defined in $table_name table \"$_[1]\".\n");
      $ex = 1;
    }
  }
  return $ex;
}

sub CheckCompressionPort{# [0] compression string [1] port table
  my ($cr_str, @port)=@_;
  my @port_list=();
  my @merged_port=();
  if ($cr_str ne "-20" && $cr_str ne "-100"){
    my @cr_port = split(/,/, $cr_str);
    for (my $col=0;$col<scalar(@{$port[0]});$col++){
      push(@port_list,$port[0][$col]);
    }
    for (my $i=0;$i<scalar(@cr_port);$i++){
      my $is_found=0;
      for (my $col=0;$col<scalar(@{$port[0]});$col++){
        if (Ex2Tbl::cmp_port_name($cr_port[$i],$port[10][$col]) == 1){
          $is_found = 1;
          if ($port[9][$col] == -1){
            if ($cr_port[$i] =~ /^\w+$/){
              push(@merged_port,$cr_port[$i]);
            }else{
              $is_found = 0;
            }
          }else{
            my $msb=(split(":",$port[11][$col]))[0];
            my $lsb=(split(":",$port[11][$col]))[1];
            if ($cr_port[$i] =~ /^\w+\[\d+:\d+\]$/){
              my $tmp = "";
              # get first port name
              $tmp = (split(/\]/,$cr_port[$i]))[0];
              my @tmp_split = split(/\[/,$tmp);
              my $port_index = $tmp_split[scalar(@tmp_split)-1];
              @tmp_split = split(/\W+/,$tmp_split[scalar(@tmp_split)-2]);
              my $port_name = $tmp_split[scalar(@tmp_split)-1];
              my ($max, $min) = split(/:/,$port_index);
              if ($max > $msb || $lsb > $min){
                print("ERROR ::: [-cr|-compression] \"");print $cr_port[$i];print ("\" is not a valid port range in port table.\n");
                exit(1);
              }
              for (my $k=$min;$k<=$max;$k++){
                push(@merged_port,$port_name."[$k]");
              }
            }elsif($cr_port[$i] =~ /^\w+$/){
              for (my $k=$lsb;$k<=$msb;$k++){
                push(@merged_port,$cr_port[$i]."[$k]");
              }
            }else{
              push(@merged_port,$cr_port[$i]);
            }
          }
          last;
        }
      }
      if($is_found == 0){
        print("ERROR ::: [-cr|-compression] \"");print $cr_port[$i];print ("\" is not a port in port table.\n");
        exit(1);
      }
    }
  }
  return @merged_port;
}

sub CreateLackLogFile{ # [0] merge, [1] max error [2] compression string [3] lack log file name, [4] -rnm option [5] Port table, [6] Truth table
  my($merge, $max_error, $cr_str, $file, $rnm, $p, $t)=@_;
  my @port=@$p;
  my @table_org=Ex2Tbl::FilterTruthTable(@$t);
  my $ret=0;
  my $is_first_lack=1;
  my @merged_port=CheckCompressionPort($cr_str, @port);
  # Split table before checking
  my @TruthTableList = Ex2Tbl::SeparateTruthTable($rnm, @table_org);
  # Check lack patterns for each truth table
  for (my $tt=0;$tt<scalar(@TruthTableList);$tt++){
    open(my $TABLE,">abstable.txt");
    return(1) if(!fileno($TABLE));
    my @table = @{$TruthTableList[$tt]};
    print($TABLE "; input abstable.txt file -> haskel -> check lack patterns\n");
    # Step1: Put information of port table
    print($TABLE "\n; Variables or columns of a given truth table\n");
    for (my $i=2;$i<scalar(@{$table[0]}); $i++){
      if ($table[0][$i] =~ /input|power|ground/){
        my $lv="";
        if ($cr_str eq "-20"){# compress all input port
          $lv="_";
        }else{
          if (grep(/^\Q$table[2][$i]\E$/, @merged_port)>0){
            $lv=$lv."_";
          }
        }
        my ($post_lv, @care_range) = Ex2Tbl::get_port_level($table[2][$i], @port);
        $lv=$lv."lv".$post_lv;
        print($TABLE "(int  $table[2][$i]  $lv)\n");
      }
    }   
    # Step2: Put information of truth table
    print($TABLE "\n; Rows of a given truth table\n");
    print($TABLE ";   ");
    for (my $i=2;$i<scalar(@{$table[0]});$i++){
      if ($table[0][$i] =~ /input|power|ground/){
        print($TABLE "  $table[2][$i]");
      }
    }
    print($TABLE "\n");
    for (my $i=4;$i<scalar(@table);$i++){
      print($TABLE "(row");
      for (my $k=0;$k<scalar(@{$table[0]});$k++){
        if ($k >= 2) {
          if ($table[0][$k] =~ /input|power|ground/){
            if ($table[$i][$k] eq "*" or $table[$i][$k] =~ /^(RISE|FALL)/){
              print($TABLE "  _");
            }elsif($table[$i][$k] =~ /EXP_NOT_1_VAL/){
              print($TABLE "  0");
            }elsif($table[$i][$k] =~ /EXP_NOT_0_VAL/){
              print($TABLE "  1");
            }elsif($table[$i][$k] =~ /[Xx]/){
              print($TABLE "  2");
            }elsif($table[$i][$k] =~ /[Zz]/){
              print($TABLE "  3");
            }else{
              print($TABLE "  $table[$i][$k]");
            }
          }
        }elsif ($k == 0){
          print($TABLE "  $table[$i][$k]");
        }
      }
      print($TABLE ")\n");
    }
    close($TABLE);
    # Step3: Run solveBCP
    if ($max_error < 0){
      system("solveBCP findAbsentRows abstable.txt &> /dev/null\n");
    }else{
      system("solveBCP findAbsentRows abstable.txt -ub $max_error &> /dev/null\n");
    }

    # Step4: Exchange output result
    open(my $LACKLOG, "abstable.abs.log") or die "ERROR ::: Cannot open temporary table.abs.log file.\n";
    my @log=<$LACKLOG>;
    if (scalar(@log) - 5 > 0){
      my $num_lack=0;
      if ($max_error < 0){
        $num_lack=put_lack_ptn_to_file($merge, $max_error, $is_first_lack, $file, \@log, \@table);
      }elsif($max_error > 0){
        $num_lack=put_lack_ptn_to_file($merge, $max_error, $is_first_lack, $file, \@log, \@table);
        $max_error=$max_error-$num_lack;
      }
      $is_first_lack=0;
      $ret=2;
    }
    close($LACKLOG);
    unlink("abstable.txt");
    unlink("abstable.abs.log");
    unlink("abstable.abs.vld0.csp");
    unlink("abstable.abs.vld1.csp");
  }# end for each truth table
  return $ret;
}

sub put_lack_ptn_to_file{ #[0] merge [1] max error [2] indicate first lack table, [3] output file, [4] lack log, [5] truth table
  my ($merge, $max_error, $is_first_lack, $file, $ll, $tt)=@_;
  my @log=@$ll;
  my @table=@$tt;
  my $count=0;
  # Open file to write/append
  if ($is_first_lack==1){
    open(OUT, ">$file");
  }else{
    open(OUT, ">>$file");
  }
  # Check open successfully or not
  if(!(fileno(OUT))){
    print("ERROR ::: Cannot open file $file.\n");
    exit(1);
  }
  # Put header
  if ($is_first_lack==1){
    print(OUT "\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\# Error Summary \#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\n");
    my($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst)=localtime(time);
    my $pt=sprintf("%02d\/%02d\/%02d %02d:%02d:%02d",$year-100,$mon+1,$mday,$hour,$min,$sec);
    print(OUT "\#  Executed $pt                                     \#\n");
#    my $user=$ENV{'USERNAME'};
    my $user=$ENV{'USER'};
    printf(OUT "\#  Executed User : %20s                           \#\n",$user);
    my $version=$ENV{'ERAKIS_VER'};
    print(OUT "\#  Checked by $version                           \#\n");
    print(OUT "\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\#\n\nnumber of port name:\n");
  }
  # Put lack patterns info
  if ($merge != 1){
    print(OUT "\n//------------next truth table-------//\n");
    for (my $i=2;$i<scalar(@{$table[0]});$i++){
      print(OUT "$table[0][$i]\t");#print input/output
    }
    print(OUT "\n");
  }
  if ($merge != 1 || $is_first_lack==1){
    for (my $i=2;$i<scalar(@{$table[0]});$i++){# col
      if(($table[0][$i] eq "input") || ($table[0][$i] eq "output") || ($table[0][$i] =~ /supply|power|ground/)){
        print(OUT "$table[2][$i]\t");#print port name
      }
    }
    print(OUT "\n");
  }
  for (my $k=5;$k<scalar(@log);$k++){# 5 is begin
    if ($max_error < 0 || $count < $max_error){
      my @log_line=split_line($log[$k]," ");
      my $index=0;
      for (my $i=2;$i<scalar(@{$table[0]});$i++){
        if($table[0][$i] eq "input" || $table[0][$i] =~ /supply|power|ground/){
          if ($log_line[$index] eq 2){
            print(OUT "X\t");
          }elsif($log_line[$index] eq 3){
            print(OUT "Z\t");
          }elsif($log_line[$index] eq "_"){
            print(OUT "*\t");
          }else{
            print(OUT "$log_line[$index]\t");#print port value
          }
          $index++;
        }elsif($table[0][$i] eq "output"){
          if ($merge != 1){
            print(OUT "X\t");
          }else{
            print(OUT " \t");
          }
        }
      }
      $count++;
      print(OUT "\n");
    }
  }
  close(OUT);
  return $count;
}

sub CreateSTTInputFile{#[0] stt input file [1] STT: state transition table [2] SDT: state definition table
  my ($sttinputfile, $t, $s)=@_;
  my @transtable=@$t;
  my @statetable=@$s;
  open(my $STT, ">$sttinputfile");
  if(!(fileno($STT))){
    print("ERROR ::: Cannot open file $sttinputfile.\n");
    exit(1);
  }
  # print for initial state first
  for(my $col=1;$col<scalar(@{$transtable[0]}); $col++){
    if ($transtable[0][$col] =~ /^\*/){#initial state
      my $src_st_id=get_id($transtable[0][$col], @statetable);
      print($STT "S, $src_st_id\n");
      for(my $row=1;$row<scalar(@transtable);$row++){
        if(($transtable[$row][$col] ne "X") && ($transtable[$row][$col] ne "x") && ($transtable[$row][$col] ne "/")){
          my $dest_st_id=get_id($transtable[$row][$col], @statetable);
          print($STT "$src_st_id, $dest_st_id\n");
        }
      }
      last;
    }
  }
  # print other states
  for(my $col=1;$col<scalar(@{$transtable[0]}); $col++){
    if ($transtable[0][$col] !~ /^\*/){#NOT initial state
      for(my $row=1;$row<scalar(@transtable);$row++){
        if(($transtable[$row][$col] ne "X") && ($transtable[$row][$col] ne "x") && ($transtable[$row][$col] ne "/")){
          my $src_st_id=get_id($transtable[0][$col], @statetable);
          my $dest_st_id=get_id($transtable[$row][$col], @statetable);
          print($STT "$src_st_id, $dest_st_id\n");
        }
      }
    }
  }
  close($STT);
}

sub CreateStatePath{# [0] state output log
  my ($outlog)=@_;
  my $startpathline=0;
  my @statepaths=();
  open(my $STTOUT, "$outlog");
  if(!(fileno($STTOUT))){
    print("ERROR ::: Cannot open file $outlog.\n");
    return(1, @statepaths);
  }
  my @sttoutlog=<$STTOUT>;
  # found the line state path
  for(my $i=0;$i<scalar(@sttoutlog);$i++){
    if($sttoutlog[$i]=~/optimal combination/){
      $startpathline=$i+1;
      last;
    }
  }
  # Create list of state paths
  if ($startpathline ==scalar(@sttoutlog)){
    print "ERROR ::: [FSM] None optimal combination path of states.\n";
    print "                So, Erakis stops generating test vector and assertion file for FSM.\n";
    return (1, @statepaths);
  }
  for(my $i=$startpathline;$i<scalar(@sttoutlog);$i++){
    my @tmp=();
    @tmp=split_line($sttoutlog[$i],",");
    @{$statepaths[scalar(@statepaths)]}=@tmp;
  }
  close($STTOUT);
  return (0,@statepaths);
}

sub CreateEventPath{#[0] all state paths [1] trans table [2] state table
  my ($p, $t, $s)=@_;
  my @paths=@$p;
  my @transtable=@$t;
  my @statetable=@$s;
  my @eventpaths=();
  for(my $i=0;$i<scalar(@paths);$i++){# for each path
    my $pre=-1;
    my $next=-1;
    my @tmp=();
    for(my $j=0;$j<scalar(@{$paths[$i]});$j++){# for each state in path
      $pre=$next;
      $next=$paths[$i][$j];
      if (($pre!=-1) && ($next!=-1)){
        $tmp[scalar(@tmp)]=get_event_name_edge($pre, $next, \@transtable, \@statetable);
      }
    }
    @{$eventpaths[$i]}=@tmp;
  }
  return @eventpaths;
}

sub get_event_name_edge{#[0] pre state id [1] next state id [2] trans table [3] state table
  my ($preid, $nextid, $t, $s)=@_;
  my @transtable=@$t;
  my @statetable=@$s;
  my $prestate=get_name($preid, @statetable);
  my $nextstate=get_name($nextid, @statetable);
  for(my $col=1;$col<scalar(@{$transtable[0]});$col++){
    my $col_name=$transtable[0][$col];
    $col_name=~s/^\*//;
    if($prestate eq $col_name){
      for(my $row=1;$row<scalar(@transtable);$row++){
        if($nextstate eq $transtable[$row][$col]){
          return $transtable[$row][0];
        }
      }
    }
  }
}

sub get_id{#[0] state name [1] SDT: state definition table
  my ($name, @table)=@_;
  my $ret=0;
  my $max_col_index=scalar(@{$table[0]})-2;
  $name=~s/^\*//;
  my $lastcolid=scalar(@{$table[0]})-1;
  for(my $row=1;$row<scalar(@table);$row++){
    if($table[$row][$lastcolid] eq $name){
      for(my $col=0;$col<=$max_col_index;$col++){
        $ret=$ret+($table[$row][$col] << ($max_col_index-$col));
      }
      return $ret;
    }
  }
}

sub get_name{#[0] state id [1] SDT: state definition table
  my($id, @table)=@_;
  my $max_col_index=scalar(@{$table[0]})-2;
  for(my $row=1;$row<scalar(@table);$row++){
    my $ret=0;
    for(my $col=0;$col<=$max_col_index;$col++){
      $ret=$ret+($table[$row][$col] << ($max_col_index-$col));
    }
    if($ret == $id){
      return $table[$row][$max_col_index+1];
    }
  }
}

sub GenerateFSMPatterns{#[0] fsm id [1] clock table [2] state paths [3] event paths [4] STT [5] SDT [6] EDT [7] FSM [8] port table
  my ($fin_time, $fsmid, $clk, $sp, $ep, $stt, $sdt, $edt, $fsm, $pt, $tbl)=@_;
  my @clock=@$clk;
  my @statepaths=@$sp;
  my @eventpaths=@$ep;
  my @trans=@$stt;
  my @state=@$sdt;
  my @event=@$edt;
  my @FSMTable=@$fsm;
  my @port=@$pt;
  my @table=Ex2Tbl::FilterTruthTable(@$tbl);
  my $file=$FSMTable[1+$fsmid][0].".ptn";
  my $fsmname=uc($FSMTable[$fsmid+1][0]);
  my $delay=0;
  my $clockname="";
  my @port_list_tbl=();
  for(my $i=0;$i<scalar(@{$table[0]});$i++){
    if($table[0][$i] =~ /input|electrical_in|inout/){
      if(grep(/$table[2][$i]/,@port_list_tbl)<1){
        my $temp = $table[2][$i];
        $temp =~ s/\[\d+\]//g;
        push(@port_list_tbl, $temp);
      }
    }
  }
  for (my $i=0;$i<scalar(@clock);$i++){
    if ($clock[$i][0] eq $FSMTable[$i+1][5]){
      $delay = $clock[$i][1];
      if(grep(/$clock[$i][0]/,@port_list_tbl)<1){
        $clockname=$clock[$i][0];
      }else{
        $clockname=$clock[$i][0]."_erks";

      }
    }
  }

  open(FSMPTN, ">$file") or die "ERROR ::: Cannot open file $file.\n";
  # generate_fsmptn_header;
  my($se, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst)=localtime(time);
  my $exe_date=sprintf("%04d\/%02d\/%02d %02d:%02d:%02d",$year+1900,$mon+1,$mday,$hour,$min,$se);
  my $version=$ENV{'ERAKIS_VER'};
#  my $user=$ENV{'USERNAME'};
  my $user=$ENV{'USER'};

  print(FSMPTN "////////////////////////////////////////////////////////////////////////////\n");
  print(FSMPTN "/// DATE : $exe_date\n");
  print(FSMPTN "/// USER : $user\n");
  print(FSMPTN "/// TOOL : $version\n");
  print(FSMPTN "////////////////////////////////////////////////////////////////////////////\n");

  # generate_fsmptn_body
  print(FSMPTN "\nparameter DELAY_$fsmname=$delay;\n\n");
  print(FSMPTN "\ninitial begin\n");
  print(FSMPTN "\n  #($fin_time+$delay)\n\n");# wait the former finish
  print(FSMPTN "\n  sig_sel = 1'b0;\n\n");# wait the former finish
  print(FSMPTN "  //Correct the clock\n");
  print(FSMPTN "  $clockname=1;\n");# correct clock (maybe after ptn of Truth table, it was wrong)
  print(FSMPTN "  #1 \/\/Make signal stable at rising edge\n");

  for(my $i=0;$i<scalar(@statepaths);$i++){# for each state path
    print(FSMPTN "  //===== Create PTN check state path=====\n");
    for(my $j=0;$j<scalar(@{$statepaths[$i]});$j++){# for each state in path
      if($j==0){# initial state
        gen_ptn_reset_negate($fsmid,\@FSMTable,\@port_list_tbl);
      }
      my $statename=get_name($statepaths[$i][$j], @state);
      print(FSMPTN "  //----- Come from initial to state \"$statename\" -----\n");
      print(FSMPTN "  #DELAY_$fsmname\n");
      gen_ptn_come_state($fsmname, $i, $j, \@eventpaths, \@event, \@port, \@port_list_tbl);
      print(FSMPTN "\n");
      gen_ptn_ignored_event($fsmname, $statename, \@trans, \@event, \@port, \@port_list_tbl);
      print(FSMPTN "\n");
      gen_ptn_reset_negate($fsmid,\@FSMTable,\@port_list_tbl);
      print(FSMPTN "\n");
    }
  }
  my $rst = get_rst_name($fsmid, \@FSMTable,\@port_list_tbl);
  print(FSMPTN "  $rst = 1'b0;\n");# assert
  if ($fsmid == ($#FSMTable-1)){#last one (-1 because of title line)
    print(FSMPTN "  #DELAY_$fsmname\n  \$finish;\n\nend\n");
  }else{
    print(FSMPTN "end\n");
  }
  close(FSMPTN);

  # cal fin time
  open(TMP,"< $file") or die "ERROR ::: Cannot open file $file.\n";
  foreach my $line(<TMP>){
    if($line =~ /DELAY/){
      $fin_time+= $delay;
    }
  }
  close(TMP);
  return $fin_time;
}

sub gen_ptn_come_state{# [0] fsm name [1] cur row state path [2] cur col state path [3] event paths [4] EDT [5] port table
  my($fsmname, $cur_row_stpth, $cur_col_stpth, $ep, $et, $pt,$port_list)=@_;
  my @eventpaths=@$ep;
  my @event=@$et;
  my @port=@$pt;
  for(my $i=0;$i<$cur_col_stpth;$i++){
    gen_ptn_event($fsmname, $eventpaths[$cur_row_stpth][$i], \@event, \@port,$port_list);
  }
}

sub gen_ptn_event{# [0] fsm name [1] event name [2] EDT [3] port table
  my($fsmname, $name, $et, $pt,$port_list)=@_;
  my @event=@$et;
  my @port=@$pt;
  my @port_list_tbl=();
#  if(ref($port_list)){
    @port_list_tbl = @$port_list;
#  }
  my $event_col_id=scalar(@{$event[0]})-1;
  for(my $row=0;$row<scalar(@event);$row++){
    if($event[$row][$event_col_id] eq $name){
      for(my $col=0;$col<$event_col_id;$col++){# for each signal of event
        # use "force" value if not connect to DUV port
        my $force_phrase="";
        if (grep(/^$event[0][$col]$/, @{$port[10]})<1){# if not exist
          $force_phrase="force TopInst.";
        }
        # assign/force value
        if ($event[$row][$col] !~ /^\*$/){
          my ($max,$min)=get_bit_width($event[0][$col], \@port, \@event);
          my $bitwidth=($max-$min + 1);
          if ($event[$row][$col] =~ /(x|z)/i){
            if(grep(/$event[0][$col]/,@port_list_tbl)>0){
              print(FSMPTN "  $force_phrase$event[0][$col]_erks=${bitwidth}'b$event[$row][$col];\n");
            }else{
              print(FSMPTN "  $force_phrase$event[0][$col]=${bitwidth}'b$event[$row][$col];\n");
            }
          }else{
            if(grep(/$event[0][$col]/,@port_list_tbl)>0){
              print(FSMPTN "  $force_phrase$event[0][$col]_erks=$event[$row][$col];\n");
            }else{
              print(FSMPTN "  $force_phrase$event[0][$col]=$event[$row][$col];\n");
            }
          }
        }
      }
      print(FSMPTN "  #DELAY_$fsmname\n");
      last;
    }
  }
}

sub gen_ptn_ignored_event{# [0] fsm name [1] state name [2] STT [3] EDT [4] port table
  my($fsmname, $stname, $stt, $ev, $pt,$port_list)=@_;
  my @trans=@$stt;
  my @event=@$ev;
  my @port=@$pt;
  for(my $col=1;$col<scalar(@{$trans[0]});$col++){
    if(get_pure_state_name($trans[0][$col]) eq $stname){
      for(my $row=1;$row<scalar(@trans);$row++){
        if ($trans[$row][$col] eq "/"){
          gen_ptn_event($fsmname, $trans[$row][0], \@event, \@port,$port_list);
        }
      }
      last;
    }
  }
}

sub get_pure_state_name{
  my ($pure)=@_;
  $pure=~s/^[\*]+//;
  return $pure;
}

sub gen_ptn_reset_negate{#[0] fsm id [1] fsm table
  my($fsmid, $fsmtable_,$port_list)=@_;
  my @fsmtable = @$fsmtable_;
  my $fsmname=uc($fsmtable[$fsmid+1][0]);
  my $rst=get_rst_name($fsmid, \@fsmtable,$port_list);
  # assert reset->de-assert reset => go to initial state
  print(FSMPTN "  #(DELAY_$fsmname*2)\n");
  print(FSMPTN "  $rst = 1'b0;\n");# assert
  print(FSMPTN "  #(DELAY_$fsmname*2)\n");
  print(FSMPTN "  $rst = 1'b1;\n");# de-assert
}

sub get_clk_name{#[0] fsm id [1] FSM table
  my ($fsmid, @fsmtable) =@_;
  for(my $i=0;$i<scalar(@{$fsmtable[0]});$i++){
    if($fsmtable[0][$i] =~ /(clock|clk)/i){
      return $fsmtable[1+$fsmid][$i];
    }
  }
}

sub get_clk_period{# [0] clk name [1] port table
  my ($clkname, @port)=@_;
  for(my $i=0;$i<scalar(@{$port[0]});$i++){
    if ($port[0][$i] eq $clkname){
      return $port[6][$i];
    }
  }
}

sub get_rst_name{#[0] fsm id [1] FSM table
  my ($fsmid, $fsmtbl, $port_list) =@_;
  my @fsmtable = @$fsmtbl;
  my @port_list_tbl=();
  if(ref($port_list)){
      @port_list_tbl = @$port_list;
  }
  my $rst ="";
  my $index=0;
  for(my $i=0;$i<scalar(@{$fsmtable[0]});$i++){
    if($fsmtable[0][$i] =~ /(reset|rst)/i){
      if(grep(/$fsmtable[1+$fsmid][$i]/,@port_list_tbl)<1){
        return $fsmtable[1+$fsmid][$i];
      }else{
        return $fsmtable[1+$fsmid][$i]."_erks";    
      }
    }
  }
}
sub GenerateFSMAssertion{# [0] work dir [1] xls [2] fsm id [3] state path [4] SDT [5] EDT [6] STT [7] FSM [8] ODT [9] port table
  my($work_dir, $xls, $fsmid, $sp, $sdt, $edt, $stt, $fsm, $odt, $pt, $rnm, $clock_info_,$wave)=@_;
  my @statepaths=@$sp;
  my @state=@$sdt;
  my @event=@$edt;
  my @trans=@$stt;
  my @fsmtable=@$fsm;
  my @out=@$odt;
  my @port=@$pt;
  my $file=$fsmtable[1+$fsmid][0]."_ast.sv";
  
  open(FSMAST, "> $file") or die "ERROR ::: Cannot open file $file.\n";

  my $fsmname=$fsmtable[$fsmid+1][0];
  print(FSMAST "\n\n//=============================================//\n");
  print(FSMAST "//============Check FSM name: $fsmname\n");
  print(FSMAST "//=============================================//\n");

  my $clk=get_clk_name($fsmid, @fsmtable);
  my $rst=get_rst_name($fsmid, \@fsmtable,0);
  my $initial_state=get_name($statepaths[0][0], @state);

  # declare module of assertion FSM
  my $md="module ast_$fsmname($clk, $rst,";
  for (my $i=0;$i<scalar(@{$event[0]})-1;$i++){# not get [event]
    $md=~s/$/ $event[0][$i],/;
  }
  for (my $i=1;$i<scalar(@{$out[0]});$i++){#not get [state]
    $md=~s/$/ $out[0][$i],/;
  }
  for (my $i=0;$i<scalar(@{$state[0]})-1;$i++){# not get [state]
    $md=~s/$/ $state[0][$i],/;
  }
  $md=~s/,$/);/;
  print(FSMAST "$md\n\n");

  # declare input sig
  print(FSMAST "input $clk;\n");
  print(FSMAST "input $rst;\n");
  for (my $i=0;$i<scalar(@{$event[0]})-1;$i++){# not get [event]
    $md="input ".wireg_bit($event[0][$i], get_bit_width($event[0][$i], \@port, \@event)).";";
    print(FSMAST "$md\n");
  }
  for (my $i=1;$i<scalar(@{$out[0]});$i++){#not get [state]
    $md="input ".wireg_bit($out[0][$i], get_bit_width($out[0][$i], \@port, \@out)).";";
    print(FSMAST "$md\n");
  }
  for (my $i=0;$i<scalar(@{$state[0]})-1;$i++){# not get [state]
    $md="input ".wireg_bit($state[0][$i], get_bit_width($state[0][$i], \@port, \@state)).";";
    print(FSMAST "$md\n");
  }
  print(FSMAST "\n");

  gen_ast_ini_st($fsmname, $clk, $rst, $initial_state, \@state, \@port);
  gen_assertion_all_states($fsmname, $clk, $rst, \@state, \@event, \@trans, \@port);
  gen_assertion_output($fsmname, $work_dir, $xls, $clk, $rst, \@state, \@out, \@port, $rnm, $clock_info_);

  print(FSMAST "endmodule\n");

  close(FSMAST);
}

sub gen_ast_ini_st{# [0] fsm name [1] clk name [2] rst name [3] initial state [4] SDT
  my ($fsmname, $clk, $rst, $initial_state, $stt, $pt)=@_;
  my @state=@$stt;
  my @port=@$pt;
  print(FSMAST "check_initial_state_$fsmname: assert property (\n    \@(posedge $rst) (");

  my $last_col_id=scalar(@{$state[0]})-1;
  my $ast=get_ast_str_of_signal($initial_state, \@state, \@port);
  print(FSMAST "$ast)\n);\n");
}

sub get_ast_str_of_signal{#[0] input table [1] SDT [2] port table
  my ($input, $tbl, $pt)=@_;
  my @table=@$tbl;
  my @port=@$pt;
  my $ast="";
  my $last_col_id=scalar(@{$table[0]})-1;
  for (my $row=1; $row<scalar(@table);$row++){
    if ($table[$row][$last_col_id] eq $input){
      for (my $col=0;$col<$last_col_id;$col++){
        if ($table[$row][$col] !~ /^\*$/){
          my ($max,$min)=get_bit_width($table[0][$col], \@port, \@table);
          my $bitwidth=($max-$min + 1);
          if ($table[$row][$col] =~ /(x|z)/i){
            $ast=$ast."($table[0][$col]===${bitwidth}'b$table[$row][$col])&&";
          }else{
            $ast=$ast."($table[0][$col]===$table[$row][$col])&&";
          }
        }
      }
      last;
    }
  }
  $ast=~s/\&\&$//;
  return $ast;
}

sub gen_assertion_all_states{#[0] fsm name [1] clk name [2] rst name [3] SDT [4] EDT [5] STT [6] port table
  my ($fsmname, $clk, $rst, $sdt, $edt, $stt, $pt)=@_;
  my @state=@$sdt;
  my @event=@$edt;
  my @trans=@$stt;
  my @port=@$pt;
  my $covered_index=0;
  my $ignored_index=0;
  my $prohibited_index=0;
  for (my $col=1;$col<scalar(@{$trans[0]});$col++){# for each state
    my $source_state=get_pure_state_name($trans[0][$col]);
    my $ast_src_st=get_ast_str_of_signal($source_state, \@state, \@port);
    for (my $row=1;$row<scalar(@trans);$row++){# for each event
      my $eventname=$trans[$row][0];
      my $ast_ev=get_ast_str_of_signal($eventname, \@event, \@port);
      my $destination_state=$trans[$row][$col];
      my $cell_content=$trans[$row][$col];
      if ($cell_content =~ /(^[ ]*[Xx][ ]*$)/){# if prohibited event
        print(FSMAST "prohibited_${fsmname}_${prohibited_index}: assert property (\n    \@(posedge $clk) disable iff($rst===1'b0) (");
        print(FSMAST "$ast_src_st) |-> !($ast_ev)\n);\n");
        $prohibited_index++;
      }elsif($cell_content =~ /(^[ ]*[\/][ ]*$)/){# if ignored event
        print(FSMAST "ignored_${fsmname}_${ignored_index}: assert property (\n    \@(posedge $clk) disable iff($rst===1'b0) (");
        print(FSMAST "$ast_src_st && $ast_ev) |=> $ast_src_st\n);\n");
        $ignored_index++;
      }else{ # if destination state
        my $ast_des_st=get_ast_str_of_signal($destination_state, \@state, \@port);
        print(FSMAST "covered_${fsmname}_${covered_index}: assert property (\n    \@(posedge $clk) disable iff($rst===1'b0) (");
        print(FSMAST "$ast_src_st && $ast_ev) |=> $ast_des_st\n);\n");
        $covered_index++;
      }
    }
  }
}

sub gen_assertion_output{#[0] fsm name [1] work dir [2] xls, [3] clk name [4] rst name [5] SDT [6] ODT
  my ($fsmname, $work_dir, $xls, $clk, $rst, $sdt, $odt, $pt, $rnm, $clock_info_)=@_;
  my @state=@$sdt;
  my @out=@$odt;
  my @port=@$pt;
  my $out_ast_index=0;
  my $outast="";
  for(my $row=1;$row<scalar(@out);$row++){
    my $ast_state=get_ast_str_of_signal($out[$row][0], \@state, \@port);
    my $right_ast="";
    for (my $col=1;$col<scalar(@{$out[0]});$col++){
      if ($out[$row][$col]=~/^[ ]*<[a-zA-Z]+[\w_]*>[ ]*$/){
        my $ref_tbl_name=$out[$row][$col];
        $ref_tbl_name=~s/^[ ]*<//;
        $ref_tbl_name=~s/>[ ]*$//;

        use Cwd;
        my $curdir=getcwd();
        chdir($work_dir);
        my ($aa,@reference) = Ex2Tbl::make_truth_tbl($xls, $ref_tbl_name,0,0,\@port,0,"","off",$clock_info_);
        chdir($curdir);

        for (my $row=2;$row<scalar(@reference);$row++){
          my $fusion_left_ast=$ast_state."&&";
          my $fusion_right_ast="";
          for (my $col=2;$col<scalar(@{$reference[0]});$col++){
            my ($max,$min)=get_bit_width($reference[1][$col], \@port, \@reference);
            my $bitwidth=($max-$min + 1);
            if (($reference[0][$col] eq "input") && ($reference[$row][$col] !~ /\*/)){
              if ($reference[$row][$col] =~ /(x|z)/i){
                $fusion_left_ast=~s/$/($reference[1][$col]===${bitwidth}'b$reference[$row][$col])&&/;
              }else{
                $fusion_left_ast=~s/$/($reference[1][$col]===$reference[$row][$col])&&/;
              }
            }elsif($reference[0][$col] eq "output"){
              if ($reference[$row][$col] =~ /(x|z)/i){
                $fusion_right_ast=~s/$/($reference[1][$col]===${bitwidth}'b$reference[$row][$col])&&/;
              }else{
                $fusion_right_ast=~s/$/($reference[1][$col]===$reference[$row][$col])&&/;
              }
            }
          }
          $fusion_left_ast=~s/\&\&$//;
          $fusion_right_ast=~s/\&\&$//;
          print(FSMAST "output_of_states_${fsmname}_${out_ast_index}: assert property (\n    \@(posedge $clk) ");
          print(FSMAST "(".$fusion_left_ast.") |-> (".$fusion_right_ast.")\n);\n");
          $out_ast_index++;
        }
      }else{
        my ($max,$min)=get_bit_width($out[0][$col], \@port, \@out);
        my $bitwidth=($max-$min + 1);
        if ($out[$row][$col] =~ /(x|z)/i){
          $right_ast=$right_ast."($out[0][$col]===${bitwidth}'b$out[$row][$col])&&";
        }else{
          $right_ast=$right_ast."($out[0][$col]===$out[$row][$col])&&";
        }
      }
    }
    if($right_ast ne ""){
      $right_ast=~s/\&\&$//;
      print(FSMAST "output_of_states_${fsmname}_${out_ast_index}: assert property (\n    \@(posedge $clk) ");
      print(FSMAST "(".$ast_state.") |-> (".$right_ast.")\n);\n");
      $out_ast_index++;
    }
  }
}

sub calc_fixed_point_value{
  my ($val,$fix_num) = @_;
  my $zero_length = $fix_num - length($val);
  my $ret = $val.("0" x $zero_length);
  return $ret;
}

sub get_port_timing_info{
  my ($cond_name, $out_name, @port_ref_table) = @_;
  $cond_name =~ s/\(.*\)//g;
  $cond_name =~ s/ERKSRISE_//g;
  $cond_name =~ s/ERKSFALL_//g;
  $out_name =~ s/\(.*\)//g;
  $out_name =~ s/ERKSRISE_//g;
  $out_name =~ s/ERKSFALL_//g;
  my $port_ref_num = 0;
  my $in_port_name = "";
  my $out_port_name = "";
  my $input_found = -1;
  my $output_found = -1;
  my @input_port_ref_num = ();
  for (my $j=0;$j<scalar(@{$port_ref_table[0]});$j++){
    if (Ex2Tbl::cmp_port_name($cond_name,$port_ref_table[0][$j])){
      if ($port_ref_table[1][$j] ne "-1") {
        if ($input_found eq "-1"){
          $port_ref_num = $port_ref_table[1][$j];
          $in_port_name = $port_ref_table[7][$j];
        }
        $input_found = 1;
        push(@input_port_ref_num,$port_ref_table[1][$j]);
      } else {
        if ($input_found eq "-1"){
          $port_ref_num = $port_ref_table[1][$j];
          $in_port_name = $port_ref_table[7][$j];
        }
        $input_found = 1;
        push(@input_port_ref_num,$port_ref_table[1][$j]);
      }
    }
    if (Ex2Tbl::cmp_port_name($out_name,$port_ref_table[0][$j]) and $output_found eq "-1"){
      $out_port_name = $port_ref_table[7][$j];
      $output_found = 1;
    }
  }
  return ($cond_name,$out_name,$port_ref_num,$in_port_name,$out_port_name,@input_port_ref_num);
}
1;
