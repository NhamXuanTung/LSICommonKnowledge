#!/usr/bin/perl

### ssgen (Synthesizable SystemC code Generator)
### Created by Front-End Design Technology Development Department
### Renesas Group Confidential
### History
# - 2011/09/29 v1.0   FEDT(Y.Oshima & S.Imamura) New created
# - 2011/10/18 v1.0.1 FEDT supported reset & input are same in hierarchy mode
#                          abolished E605 because of the above support
# - 2011/10/31 v1.0.2 FEDT changed the spec of memory port
#                          supported 2port memory with 2 clocks
#                          improved the output of CtoS script
# - 2011/11/28 v1.0.3 FEDT supported hierarchical module with only one sub command
#                          prevented generating report_slack from CtoS Script
# - 2011/12/01 v1.0.4 FEDT mixed output of #define and #include in the order of a row
# - 2011/12/08 v1.0.5 FEDT fixed the error bug of tap command
# - 2011/12/09 v1.0.6 FEDT supported oversize check for word depth of memory model
# - 2012/03/26 v1.1   FEDT supported multi threads
#                          supported environment and indent setting commands
#                          supported multi instances
#                          supported port binding between different names
#                          supported pipeline synthesis description
#                          supported "-only_script" and "-notb" command line options
#                          supported header output mode for some functions (reset,etc)
#                          changed the spec of overwriting existed file
#                          enhanced memory customization (port-suffix and initialaizer)
#                          supported no reset design
#                          enhanced error check (macro name and TB's member overlap)
#                          output #include/#define also to TB
#                          fixed some bugs
# - 2012/04/23 v1.1.1 FEDT added "-include" for command line option to read common setting
#                          added "mem_suffix" command to read suffix file globally
#                          supported "`include" command for hierarchy mode
#                          modified the method of "flatten_array" of CtoS script
# - 2012/05/23 v1.1.2 FEDT surrounded constructor by "_CTOS_TOP" macro at module header
#                          added "-D_CTOS_TOP" to compile_flags of ctos script at hierarchy mode
# - 2012/05/30 v1.1.3 FEDT supported "-nowd" option for mem command
#                          fixed a bug of generating ctos script (no reset case)
# - 2012/06/11 v1.1.4 FEDT supported dynamic allocation of module instantiation
# - 2012/10/18 v1.2   FEDT & FEGr (Tuan Tu & Hiep Nguyen)
#                          supported specifying macro defined by `define command to
#                          the following parameters
#                            "N" of {u|s}inN, {u|s}outN, {u|s}regN and {u|s}varN
#                            element count of array
#                            width, size and latency of {u|s}mem
#                          updated default version of EDA tools
#                          supported -clk_edge option for cthread command
#                          abolished E604 because v1.1.2 revision enabled to avoid CtoS error
#                          supported new soft reset description style for soft_reset command
# - 2012/12/03 v1.2.1 FEDT supported generating hierarchy module for co-sim
# - 2013/01/24 v1.3   FEDT & FEGr (Truc Pham)
#                          supported new memory access types (rw1:r and rw1:w)
#                          supported range check of variable and using SSGEN_ASSERT macro
#                          supported the description for BlackBox verification of SLEC
# - 2013/02/01 v1.3.1 FEDT supported the assist code for var2reg.pl
# - 2013/02/20 v1.3.2 FEDT supported "-noad" option for mem command
#                          supported fixed port for bind command
# - 2013/03/01 v1.3.3 FEDT enhanced tap command for specifying a name of mem command
# - 2013/03/26 v1.3.4 FEDT modified the code for BlackBox verification of SLEC
#                          fixed a bug of hierarchy generation of r1w1:w memory without -cs
# - 2013/04/04 v1.3.5 FEDT added vcd_trace command for the control of generating sc_trace
# - 2013/04/11 v1.3.6 FEDT supported three dimensions array for const data type
#                          supported var2reg option to [u]int/[u]short/[u]char command
#                          changed the naming of SC_METHOD functions so as to contain "method"
# - 2013/04/17 v1.4   FEDT added debug_trace feature for var and ctype command
#                          added ev command which supports blocking register access
#                          enhanced #ifdef command (possible to use arbitrary macro names)
# - 2013/05/22 v1.4.1 FEDT supported new memory access types (rw2:a and rw2:b)
# - 2013/06/13 v1.4.2 FEDT moved the position of free-area generated onto the codes of func
#                          fixed bugs for v1.4.1
# - 2013/07/25 v1.4.3 FEDT supported -port_pfx option and #ifdef command for sub command
#                          moved the initialization of memory data from tb to memory
# - 2013/09/24 v1.5   FEDT supported SLEC scripts generation (-slec command line)
#                          supported checker scripts generation (-checker command line)
#                          enhanced the description of some scripts generated
#                          supported "-subdir" command line for generation with sub directories
#                          supported "-standard" command line for generation with general codes
# - 2014/01/22 v1.5.1 FEDT added "clk_off" option in vcd_trace command
# - 2014/04/07 v1.5.2 FEDT supported tap command and bind command in `ifdef area
#                          supported `ifdef nesting in hierarchy definition file
#                          added "-mem_pfx", "-mem_ipfx" and "-mem_opfx" options in tap command
# - 2014/04/14 v1.5.3 FEDT enhanced bind command for fixing memory ports
#                          modified memory model generation for sc2ac conversion
# - 2014/05/12 v1.5.4 FEDT supported cthread/sub/tap/bind command in `include file
# - 2014/07/09 v1.5.5 FEDT supported specifying macro defined by `define command to
#                          fixed value in "bind"
# - 2014/07/30 v1.5.6 FEDT changed FIX SC_METHOD style in hierarcy mode
# - 2014/08/08 v1.5.7 FEDT & FEGr
#                          supported "range_check" for array variable
# - 2014/09/29 v1.6   FEDT & FEGr
#                          added "sync" command for synchronzing circuit
#                          added "-sync" option for "{u|s}in" command for synchronized input read
#                          added "-sync_header" option for "cthread" command
#                          supported log2 operation in macro defined by `define command
#                          supported CtoS 13.20-s200 and SLEC 7.1c
#                          supported SC_METHOD only module
#                          supported 1 element array
#                          enhanced SC_METHOD sensitivity for array signal
#                          changed output directory of mod_xxx.in
# - 2014/12/26 v1.6.1 RSD/DA-gi & RVC/SLD
#                          supported "-sync|-sync_pulse|-sync_enable|-sync_pulse_enable" for
#                          "bind" command
#                          supported "prefix_sync" command in hierarchy mode
#                          supported "-ctos_dont_touch" for "func" command
#                          supported "-sta" command line for generation of STAcheck scripts
# - 2015/03/31 v1.7   RSD/DA-gi & RVC/SLD
#                          removed "sync" command in module generation mode
#                          removed "-sync" of "{u|s}in" command
#                          removed "-sync_header" option of "cthread" command
#                          added "toggle_coverage" command in module mode
#                          added "hdl_observer" command for generating codes for referring to
#                            SystemC signal from Verilog/SystemVerilog module in Cadence/IES
#                          added "insert_port" command in hierarchy mode
#                          supported "-dummy" for "cthread" command
#                          supported 9 more options of synchronizer for "bind" command
#                          supported CtoS 14.20-p100 and SLEC 7.1j
# - 2015/04/15 v1.7.1 RSD/DA-gi & RVC/SLD
#                          supported "toggle_coverage" command in hierarchy mode for synchronizer
#                             module
#                          enhanced synchronizer generation to output logic in cpp file
# - 2015/05/28 v1.7.2 RSD/DA-gi & RVC/SLD
#                          added "-debug_trace" option for "hdl_observer" command for referring to
#                            debug_trace signal of {u|s}var and ctype var on Verilog/SystemVerilog
#                            module in Cadence/IES
# - 2015/06/30 v1.7.3 RSD/DA-gi & RVC/SLD
#                          supported "`ifdef" nesting in module generation mode
#                          supported "-D" option in command line (similar to "`define" command)
#                          supported "-ifv" option in command line for generation of formal
#                            verification
#                          supported "-sva" option in command line for generation of sva module
#                            template and binding
#                          enhanced the generations of IES/VCS with ABVIP/AIP if aigen is used
#                          added "-wait_expand" option for "cthread" command and supported
#                            "wait_expand" command to enable generating all wait related functions
#                            in my_wait directly
#                          supported "#include" command for TESTBENCH in both hierarchy mode and
#                            module mode
# - 2015/09/30 v1.8   RSD/DA-gi & RVC/SLD
#                          fixed calulation of macro value
#                          supported "`if" and "`elif" as preprocessor similar to C/C++ compiler
#                          supported "-ins" option in command line for generation of cpp2ins
#                          supported overflow checker generation env. by "-checker" option
#                          added "-symbol", "-time_unit" and "-period" to "clock" command
#                          supported CDNS clock gating library "ctos_gating_clock" instantiation
#                          revised all EDA tools env.
#                          added "-no_trace" option for in/out/reg command to disable tracing
#                          added "-partial_rst" to "reset" command to disable reset constratints
#                            in SLEC scripts
#                          added "-ctos_noninline" to "func" and "-wait_noninline" to "cthread"
# - 2015/10/23 v1.8.1 RSD/DM-gi & RVC/SLD
#                          supported "range_check" for in command
#                          supported "range_check" for 3D array signals
# - 2015/10/23 v1.8.2 RSD/DM-gi & RVC/SLD
#                          added property check "cas" and "dbz " in slec_sc.tcl
# - 2015/12/22 v1.8.3 RSD/DM-gi & RVC/SLD
#                          added command line option "-cer" for generating Certitude pragma
#                          added "cer_off" command in hierarchy generation mode,
#                            it is valid when "-cer" specified
#                          fixed bugs of run_XXX.csh
# - 2016/06/29 v1.8.4 RSD/DM-gi & RVC/SLD
#                          fixed bug of slec_XXX_eq.tcl of hierarchy module
# - 2016/06/30 v1.9 RSD/DM-gi & RVC/SLD
#                          updated default version of EDA tools
#                          fixed compilation errors if size of specified min/max value is greater
#                            than 32bit
#                          added command line option "-stratus" for generating scripts for Stratus
#                            synthesis
#                          added command "env_stratus"
#                          added command line option "-sim_eq" for generating scripts and test
#                            bench for SC-RTL simulation based equivalence checker
#                          added commands "env_ies_eq" and "env_jg_eq"
# - 2016/07/28 v1.8.5 RSD/DM-gi & RVC/SLD
#                          supported 2port memory with write byte enable
# - 2016/07/29 v1.9.1 RSD/DM-gi & RVC/SLD
#                          updated version of Stratus-HLS
#                          added JG-SEC to sim_eq environment
# - 2017/03/31 v1.9.2 RSD/DM-gi & RVC/SLD
#                          merged with v1.8.5
#                          enhanced Makefile of OSCI for checking dependency of header files
#                          revised version of EDA tools
# - 2017/06/30 v1.9.3 RSD/DM-gi & RVC/SLD
#                          supported new command "keep_ssgen_define"
#                          enhanced "`define" command to keep hex style in SystemC
#                          supported "-min", "-max" option with array of values
#                          supported asterisk(*) for sensitive list of method (beta)
#                          supported "-slec" for Stratus flow
#                          revised version of EDA tools and utilities
# - 2017/09/29 v1.9.4 REL/DMD & RVC/SLD
#                          supported 'struct' generation
#                          added "-vcs" option for "hdl_observer" command
# - 2017/12/26 v1.9.5 REL/DMD & RVC/SLD
#                          supported 'template' command for module generation mode
#                          fixex stratus with -D_MEM_MODEL
#                          added "-slec_bbox" option for "func" command
#                          updated version of SLEC
###

#require 5.8.8;

$ssgen_ver = "v1.9.5";

### constant values
# for scope
use constant COM      => 0;
use constant SIM      => 1;
use constant TB       => 2;
use constant SLECBB   => 3;
# for general type
use constant G_COM    => 0;
use constant G_NAME   => 1;
use constant G_FLAG   => 2;
use constant G_VALUE  => 3;
use constant G_FILE   => 4;
use constant G_SUBS   => 5;
use constant G_INST   => 6;
use constant G_TYPE   => 7;
# for type
use constant T_COM    => 0;
use constant T_NAME   => 1;
use constant T_INST   => 2;
use constant T_TYPE   => 3;
use constant T_INIT   => 4;
use constant T_ARRAY  => 5;
use constant T_WID    => 6;
use constant T_ONAME  => 7;
use constant T_FLG    => 8;
use constant T_TH     => 9;
use constant T_MIN    => 10;
use constant T_MAX    => 11;
use constant T_DBG    => 12;
use constant T_ENAME  => 13;
use constant T_SYMBL  => 14;
use constant T_CTSCG  => 15;
use constant T_UNIT   => 16;
use constant T_PERIOD => 17;
use constant T_OPTOR  => 18;
# for sync
use constant S_COM    => 0;
use constant S_NAME   => 1; # EnableName
use constant S_INVAL  => 2; # InputVal string
use constant S_ONAME  => 3;
use constant S_TH     => 4;
use constant S_FLG    => 5;
use constant S_INST   => 6;
use constant S_EN     => 7;
# for memory
use constant M_COM    => 0;
use constant M_NAME   => 1;
use constant M_SIGN   => 2;
use constant M_WID    => 3;
use constant M_SIZE   => 4;
use constant M_RW     => 5;
use constant M_LAT    => 6;
use constant M_IPRE   => 7;
use constant M_OPRE   => 8;
use constant M_PONLY  => 9;
use constant M_WE     => 10; # we (0:N/A,    1:high, 2:low)
use constant M_RE     => 11; # re (0:notuse, 1:high, 2:low)
use constant M_CS     => 12; # cs (0:notuse, 1:high, 2:low)
use constant M_BE     => 13; # be (0:notuse, 1:high, 2:low)
use constant M_CLKR   => 14;
use constant M_CLKW   => 15;
use constant M_TH     => 16;
use constant M_INIT   => 17;
use constant M_SUF    => 18;
use constant M_FLG    => 19;
use constant M_INST   => 20;
use constant M_FIX    => 21;
use constant M_SHARE  => 22;
# for func
use constant F_COM    => 0;
use constant F_NAME   => 1;
use constant F_RET    => 2;
use constant F_BODY   => 3;
use constant F_FLG    => 4;
# for cthread
use constant TH_COM    => 0;
use constant TH_NAME   => 1;
use constant TH_FLG    => 2;
use constant TH_CLK    => 3;
use constant TH_EDGE   => 4;
use constant TH_LAT    => 5;
use constant TH_MACRO  => 6;
use constant TH_RST    => 7;
# for module
use constant MOD_COM   => 0;
use constant MOD_NAME  => 1;
use constant MOD_FLG   => 2;
use constant MOD_INST  => 3;
use constant MOD_PATH  => 4;
use constant MOD_MACRO => 5;
use constant MOD_DBG   => 6;
use constant MOD_TMPL  => 7;
use constant MOD_BIND  => 8;
# for tap
use constant TAP_COM  => 0;
use constant TAP_SIG  => 1;
use constant TAP_OUT  => 2;
use constant TAP_INST => 3;
use constant TAP_USED => 4;
use constant TAP_IPRE => 5;
use constant TAP_OPRE => 6;
# for bind
use constant B_COM     => 0;
use constant B_INST_S  => 1;
use constant B_PORT_S  => 2;
use constant B_INST_E  => 3;
use constant B_PORT_E  => 4;
use constant B_SIG     => 5;
use constant B_FLG_S   => 6;
use constant B_FLG_E   => 7;
use constant B_INST_EN => 8;
use constant B_PORT_EN => 9;
# for struct
use constant STR_COM        => 0;
use constant STR_NAME       => 1;
use constant STR_OPTOR      => 2;
use constant STR_VAR        => 3;
use constant STR_FREE_AREA  => 4;
use constant STR_CH_LOG     => 5;
use constant STR_MACRO      => 6;
use constant STR_MEM_ARRAY  => 7;
# for various flags
use constant FLG_CONST      => 0x00000000001;
use constant FLG_USED       => 0x00000000002;
use constant FLG_PIPE       => 0x00000000004;
use constant FLG_MULTI      => 0x00000000008;
use constant FLG_HDR        => 0x00000000010;
use constant FLG_HDR_RST    => 0x00000000010;
use constant FLG_HDR_WAIT   => 0x00000000020;
use constant FLG_NOWD       => 0x00000000040;
use constant FLG_RTL        => 0x00000000080;
use constant FLG_RNGCHK     => 0x00000000100;
use constant FLG_VAR2REG    => 0x00000000200;
use constant FLG_NOAD       => 0x00000000400;
use constant FLG_FIX        => 0x00000000800;
use constant FLG_SLECBB     => 0x00000001000;
use constant FLG_DTRACE     => 0x00000002000;
use constant FLG_EV         => 0x00000004000;
use constant FLG_IFDEF      => 0x00000008000;
use constant FLG_RNGFOR     => 0x00000010000;
use constant FLG_USED_SIG   => 0x00000020000;
use constant FLG_DONT_TOUCH => 0x00000040000;
use constant FLG_ONLY_DEF   => 0x00000080000;
use constant FLG_DUMMY      => 0x00000100000;
use constant FLG_SYNC       => 0x00000200000;
use constant FLG_SYNC_EN    => 0x00000400000;
use constant FLG_SYNC_OUT   => 0x00000800000;
use constant FLG_SYNC_LVL   => 0x00001000000;
use constant FLG_SYNC_POS   => 0x00002000000;
use constant FLG_SYNC_NEG   => 0x00004000000;
use constant FLG_SYNC_TOG   => 0x00008000000;
use constant FLG_SYNC_CHK   => 0x00010000000;
use constant FLG_ACTV_LOW   => 0x00020000000;
use constant FLG_WAIT_EXP   => 0x00040000000;
use constant FLG_NO_TRACE   => 0x00080000000;
use constant FLG_PART_RST   => 0x00100000000;
use constant FLG_N_INLINE   => 0x00200000000;
use constant FLG_CATG_EN    => 0x00400000000;
use constant FLG_CATG_DATA  => 0x00800000000;
use constant FLG_CATG_REG   => 0x01000000000;
use constant FLG_CATG_STALL => 0x02000000000;
use constant FLG_DISABLE    => 0x04000000000;
use constant FLG_RANDOM     => 0x08000000000;
use constant FLG_KEEP_STR   => 0x10000000000;
use constant FLG_STR_TYPE   => 0x20000000000;
# for memory access kind
use constant MA_R      => 0x0001;
use constant MA_W      => 0x0002;
use constant MA_A      => 0x0004;
use constant MA_B      => 0x0008;
use constant MA_1PORT  => 0x0010;
use constant MA_2PORT  => 0x0020;
use constant MA_DPORT  => 0x0040;
use constant MA_RW1    => MA_1PORT | MA_R | MA_W; # rw1 (rw)
use constant MA_RW1_R  => MA_1PORT | MA_R;        # rw1:r
use constant MA_RW1_W  => MA_1PORT | MA_W;        # rw1:w
use constant MA_R1W1_R => MA_2PORT | MA_R;        # r1w1:r (r)
use constant MA_R1W1_W => MA_2PORT | MA_W;        # r1w1:w (w)
use constant MA_RW2_A  => MA_DPORT | MA_A;        # rw2:a
use constant MA_RW2_B  => MA_DPORT | MA_B;        # rw2:b
# for type of memory port suffix set
use constant MP_FILE  => 0;
use constant MP1_AD   => 1;
use constant MP1_WD   => 2;
use constant MP1_RD   => 3;
use constant MP1_WE   => 4;
use constant MP1_CS   => 5;
use constant MP1_WA   => 6;
use constant MP1_RA   => 7;
use constant MP1_RE   => 8;
use constant MP2_WA   => 9;
use constant MP2_WD   => 10;
use constant MP2_WE   => 11;
use constant MP2_CS   => 12;
use constant MP2_BE   => 13;
use constant MP2_RA   => 14;
use constant MP2_RD   => 15;
use constant MP2_RE   => 16;
use constant MPA_AD   => 17;
use constant MPA_WD   => 18;
use constant MPA_RD   => 19;
use constant MPA_WE   => 20;
use constant MPA_CS   => 21;
use constant MPB_AD   => 22;
use constant MPB_WD   => 23;
use constant MPB_RD   => 24;
use constant MPB_WE   => 25;
use constant MPB_CS   => 26;
use constant MP_CLK   => 27;
use constant MP_CLKR  => 28;
use constant MP_CLKW  => 29;
use constant MP_CLKA  => 30;
use constant MP_CLKB  => 31;

### reserve list
@rsv_prefix = ("sc_", "SC_", "MEM_", "ssgen_");
%rsv_word = (
    "int", 0, "long", 0, "short", 0, "signed", 0, "unsigned", 0, "float", 0,
    "double", 0, "bool", 0, "true", 0, "false", 0, "char", 0, "wchar_t", 0,
    "void", 0, "class", 0, "struct", 0, "union", 0, "enum", 0, "const", 0,
    "volatile", 0, "auto", 0, "extern", 0, "register", 0, "static", 0,
    "mutable", 0, "friend", 0, "typedef", 0, "explicit", 0, "inline", 0,
    "virtual", 0, "public", 0, "protected", 0, "private", 0, "operator", 0,
    "this", 0, "if", 0, "else", 0, "for", 0, "while", 0, "do", 0, "switch", 0,
    "case", 0, "default", 0, "break", 0, "continue", 0, "goto", 0, "return", 0,
    "try", 0, "catch", 0, "new", 0, "delete", 0, "dynamic_cast", 0,
    "static_cast", 0, "const_cast", 0, "reinterpret_cast", 0, "sizeof", 0,
    "typeid", 0, "throw", 0, "template", 0, "typename", 0, "export", 0,
    "namespace", 0, "using", 0, "and", 0, "and_eq", 0, "bitand", 0, "bitor", 0,
    "compl", 0, "not", 0, "not_eq", 0, "or", 0, "or_eq", 0, "xor", 0,
    "xor_eq", 0, "asm", 0, "systemc", 0, "reset_signal_is", 0,
    "async_reset_signal_is", 0, "dont_initialize", 0, "sensitive", 0, "read", 0,
    "write", 0, "pos", 0, "neg", 0, "posedge", 0, "negedge", 0,
    "posedge_event", 0, "negedge_event", 0, "wait", 0, "next_trigger", 0,
    "halt", 0, "always", 0, "assign", 0, "buf", 0, "bufif0", 0, "bufif1", 0,
    "casex", 0, "casez", 0, "cmos", 0, "deassign", 0, "defparam", 0,
    "disable", 0, "edge", 0, "endattribute", 0, "endcase", 0, "endfunction", 0,
    "endmodule", 0, "endprimitive", 0, "endspecify", 0, "endtable", 0,
    "endtask", 0, "event", 0, "force", 0, "forever", 0, "fork", 0, "highz0", 0,
    "highz1", 0, "ifnone", 0, "initial", 0, "input", 0, "join", 0, "large", 0,
    "macromodule", 0, "medium", 0, "module", 0, "nmos", 0, "notif0", 0,
    "notif1", 0, "output", 0, "parameter", 0, "pmos", 0, "primitive", 0,
    "pull0", 0, "pull1", 0, "pulldown", 0, "pullup", 0, "rcmos", 0, "reg", 0,
    "release", 0, "repeat", 0, "rnmos", 0, "rpmos", 0, "rtran", 0,
    "rtranif0", 0, "rtranif1", 0, "scalared", 0, "small", 0, "specify", 0,
    "specparam", 0, "strength", 0, "strong0", 0, "strong1", 0, "supply0", 0,
    "supply1", 0, "table", 0, "task", 0, "time", 0, "tran", 0, "tranif0", 0,
    "tranif1", 0, "tri", 0, "tri0", 0, "tri1", 0, "triand", 0, "trior", 0,
    "trireg", 0, "vectored", 0, "wand", 0, "weak0", 0, "weak1", 0, "wire", 0,
    "wor", 0, "attribute", 0, "begin", 0, "end", 0, "function", 0, "inout", 0,
    "nand", 0, "nor", 0, "package", 0, "use", 0, "xnor", 0, "TESTBENCH", 0,
    "_OSCI", 0, "_MEM_MODEL", 0, "_MODE_RTL", 0, "__CTOS__", 0,
    "CALYPTO_SYSC", 0, "T_MAX", 0, "HIRE_MAX", 0, "tf", 0, "mem_rw1", 0,
    "mem_r1w1", 0, "mem_r1w1_2clk", 0, "CtoS_MAIN_LOOP", 0, "_CTOS_TOP", 0,
    "SSGEN_ASSERT", 0, "_COVERAGE", 0, "_SLEC_BBOX", 0
);

### options
$opt_mem      = 0;
$opt_ctos     = 0;
$opt_stratus  = 0;
$opt_slec     = 0;
$opt_osci     = 0;
$opt_vcs      = 0;
$opt_ies      = 0;
$opt_ifv      = 0;
$opt_sva      = 0;
$opt_chk      = 0;
$opt_sim_eq   = 0;
$opt_ow       = 0;
$opt_notb     = 0;
$opt_scr      = 0;
$opt_subd     = 0;
$opt_sta      = 0;
$opt_ins      = 0;
$opt_only_map = 0;
$opt_standard = 0;
$opt_cer      = 0;

### parameters
$tab = "";
$style_module = ""; # sc or c++
$style_alloc  = ""; # static or dynamic instance allcation
$mem_suffix   = "";
$vcd_trace    = "";  # 1(on), 0(off), 2(clk_off)
$mem_macro    = "_MEM_MODEL";
$tb_macro     = "TESTBENCH";
$dbg_macro    = "_DEBUG_SIM";
$rtl_macro    = "_MODE_RTL";
$osci_macro   = "_OSCI";
$assert_macro = "SSGEN_ASSERT";
$cov_macro    = "_COVERAGE";
$slecbb_macro = "_SLEC_BBOX";
$wait_name    = "my_wait";
$hier_max     = "HIER_MAX";
$module_name  = "";
$org_module_name = "";
$struct_name  = "";
$MODULE_NAME  = "";
$bs_vcs_mem   = "500";
$bs_vcs_os    = "RHEL5";
$bs_ies_mem   = "500";
$bs_ies_os    = "RHEL5";
$bs_sim_eq_mem = "16000";
$bs_sim_eq_os = "RHEL5";
$bs_ifv_mem   = "10000";
$bs_ifv_os    = "RHEL5";
$env_systemc  = "";
$env_vcs      = "";
$env_ies      = "";
$env_ies_eq   = "";
$env_jg_eq    = "";
$env_vipcat   = "";
$env_ctos     = "";
$env_stratus  = "";
$env_slec     = "";
$env_vcs_gcc  = "";
$env_ssgen    = "";
$env_1team    = "";
$env_sschk    = "";
$env_ovrflw   = "";
$env_cpp2ins  = "";

$ctos_period        = "5000";
$ctos_target_lib    = "tutorial.lbr";
$stratus_period     = "5.000";
$stratus_target_lib = "";

### default settings
$def_systemc = "/common/appl/Renesas/SystemC/SystemC-2.2";
$def_vcs     = "/common/appl/dotfiles/vcs_mx.CSHRC_2016.06-sp2";
$def_ies     = "/common/appl/dotfiles/cadence.CSHRC_ius15.20s020";
$def_ies_eq  = "/common/appl/dotfiles/cadence.CSHRC_ius15.20s020_64";
$def_jg_eq   = "/common/appl/dotfiles/cadence.CSHRC_jasper16.09.000";
$def_ctos    = "/common/appl/dotfiles/cadence.CSHRC_ctos_v14.20-s302";
$def_stratus = "/common/appl/dotfiles/cadence.CSHRC_stratus_v16.23-s100";
$def_slec    = "/common/appl/dotfiles/slec.CSHRC_10.2";
$def_vcs_gcc = "/common/appl/Synopsys/vg_gnu_package/2016.06/linux/source_me_gcc4_32.csh";
$def_ssgen   = "/common/appl/Renesas/SystemC/utility/ssgen/${ssgen_ver}";
$def_1team   = "/common/appl/dotfiles/1TeamSystem.CSHRC_1.16.7";
$def_sschk   = "/common/appl/Renesas/SystemC/utility/SSChecker/v3.2.1";
$def_opencad = "/common/appl/Renesas/OPENCAD/ENV/NetWalker.ENV";
$def_vipcat  = "/common/appl/Cadence/vipcat/11.30.031";
$def_ovrflw  = "/common/appl/Renesas/SystemC/utility/ctos/check_overflow/v1.65";
$def_rpt_ovr = "/common/appl/Renesas/SystemC/utility/ctos/report_overflow/v1.1/report_overflow.pl";
$def_cpp2ins = "/common/appl/Renesas/SystemC/utility/coverage/v1.6";
$def_gen_state_map = "/common/appl/Renesas/SystemC/utility/stratus/gen_state_map/v1.1";
$def_get_state_node = "/common/appl/Renesas/SystemC/utility/stratus/get_state_node/v1.0";
$def_gen_bbox_map = "/common/appl/Renesas/SystemC/utility/stratus/gen_bbox_map/v1.0";

@suf_def  = ("", "ad1", "wd1", "rd1", "we1", "cs1",
             "wa1", "ra1", "re1",
             "wa1", "wd1", "we1", "cs1", "be1", "ra1", "rd1", "re1",
             "ad1", "wd1", "rd1", "we1", "cs1",
             "ad2", "wd2", "rd2", "we2", "cs2",
             "clk", "rclk", "wclk", "clk1", "clk2");

$ctos_clock_gating_in = "/common/appl/Renesas/SystemC/utility/ssgen/ctos_clock_gating.in";
$ctos_noninline = 0;
$slec_bbox = 0;

### variables
# add list of struct 
@struct_list = ();
@struct_mem_list = ();
$is_struct_parsing = 0;
#
$infile  = "";
@incfile_list = ();
@def_file_list = ();
$outfile = "";
$outdir  = "./";
$now_area = COM;
$now_macro = "";
$free_area = 0;
@ifdef = ();
@ifdef_else = ();
@ifdef_ignore = ();
@ifdef_inc = ();
@top_ifdef = ();
@top_ifdef_else = ();
@top_ifdef_ignore = ();
@top_ifdef_inc = ();
$standard_ignore = 0;
$need_osci = 0;
$need_mem_rw1 = 0;
$need_mem_r1w1 = 0;
$need_mem_r1w1_2clk = 0;
$need_mem_r1w1_be = 0;
$need_mem_r1w1_2clk_be = 0;
$need_mem_rw2 = 0;
$need_moddef = 0;
$top_mode = 0;
$tb_mode = 0;
$top_dbg = "";
$parse_state = 0;
$mod_inst = "";
$use_rand = 0;
$use_pipe = 0;
$use_hdr  = 0;
$use_aigen = 0;
$use_valid_thread = 0;
$use_disable = 0;
$use_template = 0;
$mod_aigen = "";
$prefix_sync = "";
$toggle_cov_mode = "";
$wait_expand = "";
$keep_ssgen_define = "";
$top_keep_ssgen_define = "";

@define_in_list = ();
@define_in_list_struct = ();
@template_list  = ();
@clk_list       = ();
@clk_list_sync  = ();
@rst_list       = ();
@rst_list_sync  = ();
@mem_list       = ();
@thread_list    = ();
@method_list    = ();

@in_list        = ();
@in_list_slecbb = ();
@in_list_sync   = ();
@in_list_insert = ();

@out_list       = ();
@out_list_slecbb = ();
@out_list_sync   = ();
@out_list_insert = ();
@out_list_enable = ();

@reg_list = ();
@reg_list_tb = ();
@reg_list_sync = ();

@var_list = ();
@var_list_tb = ();

@ev_list = ();

@sync_list = ();

@ctype_list = ();
@ctype_list_tb = ();

@func_list = ();
@func_list_tb = ();

@free_area_list = ();
@free_area_list_tb = ();
@free_area_list_struct = ();

@data_list_m = ();
@func_list_m = ();
@free_area_list_m = ();

@changelog_list = ();
@changelog_list_struct = ();
@prepro_list = ();
@prepro_list_tb = ();
@prepro_list_struct = ();

@mod_list = ();
@mod_list_sync = ();
@tap_list = ();
@bind_list = ();
@suf_list = ();
push(@suf_list, [@suf_def]);

@tmpl_inst_list = ();

%defined_word       = ();
%defined_word_struct= ();
%defined_word_tb    = ();

## only collect `ifdef XXX from mod infile and top infile for parsing top infile
@define_in_top_list = ();

## valid only when specify -cer
@cer_off_list = ();

## HDL checker connection
$hdl_ies_on = 0;
$hdl_vcs_on = 0;
$hdl_module = "";
$hdl_sig_prefix = "";
$hdl_debug_trace = 0;

## ctos_clock_gating
$use_ctos_cg = 0;

## for ssgen development
$debug_ssgen = 0;

##
## main procedure
##
print "ssgen $ssgen_ver (Synthesizable SystemC code Generator)\n";

&read_argv(@ARGV);
&pre_parse;

if ($top_mode == 0) {
    foreach $incfile (@incfile_list) {
        $nowdir = &get_dir($incfile);
        &mod_parse($incfile, 1);
    }
    $nowdir = &get_dir($infile);
    &mod_parse($infile, 0);
}
else {
    foreach $incfile (@incfile_list) {
        $nowdir = &get_dir($incfile);
        &top_parse_1st($incfile, 1);
    }
    $nowdir = &get_dir($infile);
    &top_parse_1st($infile, 0);
    &top_parse_2nd($infile);
}

&post_check;

if ($opt_scr == 0) {
    if ($top_mode == 0) {
        &gen_mod_h;
        &gen_mod_cpp;
        &gen_struct_h;
        if ($use_template == 1) {
            &gen_template_mod;
        }
    }
    else {
        &gen_top_h;
        &gen_top_cpp;
        &gen_top_moddef;
        &gen_sync_h;
        &gen_sync_cpp;
    }
    &gen_memif_h;
    &gen_memif_cpp;
    if (@def_file_list != 0) {
        &gen_def_h;
    }

    if ($opt_notb == 0) {
        if (&get_valid_clock == 0) {
            &add_dummy_clk;
        }
        &gen_tb_h(0);
        &gen_tb_cpp(0);
        &gen_main(0);
    }

    if ($opt_mem == 1) {
        &gen_mem_rw1;
        &gen_mem_r1w1;
        &gen_mem_r1w1_2clk;
        &gen_mem_r1w1_be;
        &gen_mem_r1w1_2clk_be;
        &gen_mem_rw2;
    }

    if ($opt_sva == 1) {
        &gen_sva;
    }
}

if ($opt_ctos == 1) {
    if ($top_mode == 0 && $use_template == 1) {
        foreach $tmpl (@tmpl_inst_list) {
            $module_name = @$tmpl[MOD_NAME];
            &gen_ctos;
            $module_name = $org_module_name;
        }
    }
    else {
        &gen_ctos;
    }
    &gen_ctos_memif;
    &gen_ctos_sync;
}

if ($opt_stratus == 1) {
    if ($top_mode == 0 && $use_template == 1) {
        foreach $tmpl (@tmpl_inst_list) {
            $module_name = @$tmpl[MOD_NAME];
            &gen_stratus_scr;
            $module_name = $org_module_name;
        }
    }
    else {
        &gen_stratus_scr;
    }
}

if ($opt_slec == 1) {
    if ($top_mode == 0 && $use_template == 1) {
        foreach $tmpl (@tmpl_inst_list) {
            $module_name = @$tmpl[MOD_NAME];
            &gen_slec_scr;
            $module_name = $org_module_name;
        }
    }
    else {
        &gen_slec_scr;
    }
}

if ($opt_sta == 1) {
    if ($top_mode == 0 && $use_template == 1) {
        foreach $tmpl (@tmpl_inst_list) {
            $module_name = @$tmpl[MOD_NAME];
            &gen_sta_scr;
            $module_name = $org_module_name;
        }
    }
    else {
        &gen_sta_scr;
    }
}

if ($opt_osci == 1) {
    &gen_osci_scr;
}

if ($opt_vcs == 1) {
    if ($opt_only_map == 0) {
        &gen_vcs_scr;
    }
    &gen_map_file(0);
    if ($opt_only_map == 0) {
        &gen_vip_file(0);
    }
}

if ($opt_ies == 1) {
    if ($opt_only_map == 0) {
        &gen_ies_scr;
    }
    &gen_map_file(1);
    if ($opt_only_map == 0) {
        &gen_vip_file(1);
    }
}

if ($opt_ifv == 1) {
    &gen_ifv_scr;
}

if ($opt_sim_eq == 1) {
    &gen_main(1);
    &gen_tb_h(1);
    &gen_tb_cpp(1);
    &gen_sim_eq_random;
    &gen_sim_eq_scr;
    &gen_map_file(2);
}

if ($opt_chk == 1) {
    &gen_1team_scr;
    &gen_sschecker_scr;
    if ($top_mode == 0 && $use_template == 1) {
        foreach $tmpl (@tmpl_inst_list) {
            $module_name = @$tmpl[MOD_NAME];
            &gen_overflow;
            $module_name = $org_module_name;
        }
    }
    else {
        &gen_overflow;
    }
    &gen_overflow_memif;
    &gen_overflow_sync;
}

if ($opt_ins == 1) {
    &gen_cpp2ins_scr;
}


&last_check;

print "generation was finished successfully.\n";

##
## print message for error or warning
##   $no       : message number
##   $file     : file name
##   $line_num : line number
##   $msg      : message string
##
sub message {
    my ($no, $file, $line_num, $msg) = @_;
    print "[$no";
    print ":${file}" if ($file ne "");
    print ":$line_num" if ($line_num > 0);
    print "] $msg.\n";
    if ($no =~ /^E/) {
        die "aborted parsing here.\n";
    }
}

##
## remove return code from the end of strings
##   $string : string
##
sub remove_rtn {
    my $string = $_[0];
    chomp($$string);
    $$string =~ s/[\r\n]$//g;
}

##
## get directory name except filename
##   return : directory name
##   $path  : full path name
##
sub get_dir {
    my $path = $_[0];
    my $dir  = "";
    if ($path =~ /(.*[\/|\\]).*/) {
        $dir = $1;
    }
    return $dir;
}

##
## get string (separate comment part from string and remove redundant space)
##   $string(O)  : string
##   $comment(O) : comment
##
sub get_string {
    my ($string, $comment) = @_;
    $$comment = "";

    if ($$string =~ /^(.*?)\/\/\s*(.*)$/) {
        $$string =  $1;
        $$comment = $2;
        $$comment =~ s/\s*$//;
    }

    $$string =~ s/^\s*//;
    $$string =~ s/\s*$//;
    $$string =~ s/;*$//;
}

##
## print comment (with "\n")
##   $com : comment string
##   $sp  : inserting space flag (= 1:Y, 0:N)
##
sub comment {
    my $com = $_[0];
    my $sp  = $_[1];
    $sp = 0 unless defined($sp);

    if ($com eq "") {
        $com = "\n";
    }
    else {
        $com = ($sp == 1 ? " " : "") .  "// $com\n";
    }
    return $com;
}

##
## calculate log2
##  return : result of log2 calculate
##   $num  : target number
##
sub log2 {
    #my $num = $_[0] - 1;
    my $num = $_[0];
    if (&is_number($num) == 0) {
        $num = &get_macro_value($num, "", 0);
    }
    $num--;
    my $cnt = 0;
    while ($num != 0) {
        $num = $num >> 1;
        $cnt++;
    }
    return $cnt;
}

##
## open output file & write summary
##   OUT   : file pointer
##   $com  : comment character
##   $subd : sub directory name for -subdir command
##   $over : overwrite flag (= 1:Y, 0:N)
##   $perm : set permission (= DC or 755)
##
sub my_open {
    local(*OUT) = $_[0];
    my $com  = $_[1];
    my $subd = $_[2];
    my $over = $_[3];
    my $perm = $_[4];
    my $perl = $_[5];
    my $path;
    $perm = "" unless defined($perm);
    $perl = 0 unless defined($perl);

    if ( $outfile eq "mod_${module_name}.in") {
        $path = "./" . $outfile;
    } elsif ($opt_subd) {
        $path = $outdir . $subd;
        if  (! -d $path) {
            mkdir($path) || die "can't make directory [$path]\n";
        }
        $path = $path . "/" . $outfile;
    }
    else {
        $path = $outdir . $outfile;
    }

    my $backup;
    if ($outfile =~ /^(tb_)?${module_name}.cpp$/  ||
        (($hdl_ies_on == 1 || $hdl_vcs_on == 1) && $outfile =~ /\.sv$/) ||
        $outfile =~ /\.sgdc$/ ||
        $outfile =~ /\.cfg$/
       ) {
        if (-e "$path") {
            $backup = $path . "_tmp";
            message("I004", "", 0,
               "\"$backup\" was generated because \"$path\" has already existed");
            $path = $backup;
        }
    }
    else {
        if ($opt_ow == 0 && $over == 0) {
            my $suffix = 1;
            $backup = $path;
            while (-e "$backup") {
                $backup = $path . ".$suffix";
                $suffix++;
            }
            if ($path ne $backup) {
                rename($path, $backup);
                message("I001", "", 0,
                    "the existed file \"$path\" was renamed to \"$backup\"");
            }
        }
    }
    open (OUT, ">$path") || die "can't open output file [$path]\n";

    if ($com eq "#!") {
        if ($perl != 0) {
            print OUT "#!/usr/bin/perl\n";
        }
        else {
            print OUT "#!/bin/csh -f\n";
        }
        $com = "##";
    }
    print OUT $com, "=====================================================\n";
    print OUT $com, "  ssgen $ssgen_ver (Synthesizable SystemC code Generator)\n" if (!$opt_standard);
    print OUT $com, "  Renesas Group Confidential\n";
    print OUT $com, "=====================================================\n";

    if ($perm ne "") {
        system("chmod $perm $path");
    }
}

##
## read suffix file for mem command
##   $suf_file : suffix file name
##   $mode     : read mode (0:global, 1:each port)
##
sub read_suf_file {
    my $suf_file = $_[0];
    my $mode     = $_[1];
    foreach $mem (@mem_list) {
        if (@$mem[M_SUF] eq $suf_file) {
            return;
        }
    }

    my @elm = ("") x MP_CLK;
    $elm[MP_FILE] = $suf_file;
    my $line_num  = 0;
    my %used_rw1  = ();
    my %used_r1w1 = ();
    my %used_rw2  = ();
    open (SUF, "<$suf_file") || die "can't open input file [$suf_file]\n";

    while (<SUF>) {
        $line_num++;
        $line = $_;
        &remove_rtn(\$line);
        &get_string(\$line);

        if ($line eq "") {
            # do nothing
        }
        elsif ($line =~ /(\w+)\s*=\s*(.*)/) {
            $kind = $1;
            $suf  = $2;

            if ($suf !~ /^\w+$/ || length($suf) > 99) {
                goto ERROR_SUF;
            }

            if ($kind eq "rw1_ad") {
                if ($elm[MP1_AD] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MP1_AD] = $suf;
            }
            elsif ($kind eq "rw1_we") {
                if ($elm[MP1_WE] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MP1_WE] = $suf;
            }
            elsif ($kind eq "rw1_cs") {
                if ($elm[MP1_CS] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MP1_CS] = $suf;
            }
            elsif ($kind eq "rw1_wd") {
                if ($elm[MP1_WD] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MP1_WD] = $suf;
            }
            elsif ($kind eq "rw1_rd") {
                if ($elm[MP1_RD] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MP1_RD] = $suf;
            }
            elsif ($kind eq "rw1_wa") {
                if ($elm[MP1_WA] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MP1_WA] = $suf;
            }
            elsif ($kind eq "rw1_ra") {
                if ($elm[MP1_RA] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MP1_RA] = $suf;
            }
            elsif ($kind eq "rw1_re") {
                if ($elm[MP1_RE] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MP1_RE] = $suf;
            }
            elsif ($kind eq "r1w1_wa") {
                if ($elm[MP2_WA] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MP2_WA] = $suf;
            }
            elsif ($kind eq "r1w1_we") {
                if ($elm[MP2_WE] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MP2_WE] = $suf;
            }
            elsif ($kind eq "r1w1_cs") {
                if ($elm[MP2_CS] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MP2_CS] = $suf;
            }
            elsif ($kind eq "r1w1_be") {
                if ($elm[MP2_BE] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MP2_BE] = $suf;
            }
            elsif ($kind eq "r1w1_wd") {
                if ($elm[MP2_WD] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MP2_WD] = $suf;
            }
            elsif ($kind eq "r1w1_ra") {
                if ($elm[MP2_RA] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MP2_RA] = $suf;
            }
            elsif ($kind eq "r1w1_re") {
                if ($elm[MP2_RE] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MP2_RE] = $suf;
            }
            elsif ($kind eq "r1w1_rd") {
                if ($elm[MP2_RD] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MP2_RD] = $suf;
            }
            elsif ($kind eq "rw2a_ad") {
                if ($elm[MPA_AD] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MPA_AD] = $suf;
            }
            elsif ($kind eq "rw2a_we") {
                if ($elm[MPA_WE] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MPA_WE] = $suf;
            }
            elsif ($kind eq "rw2a_cs") {
                if ($elm[MPA_CS] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MPA_CS] = $suf;
            }
            elsif ($kind eq "rw2a_wd") {
                if ($elm[MPA_WD] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MPA_WD] = $suf;
            }
            elsif ($kind eq "rw2a_rd") {
                if ($elm[MPA_RD] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MPA_RD] = $suf;
            }
            elsif ($kind eq "rw2b_ad") {
                if ($elm[MPB_AD] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MPB_AD] = $suf;
            }
            elsif ($kind eq "rw2b_we") {
                if ($elm[MPB_WE] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MPB_WE] = $suf;
            }
            elsif ($kind eq "rw2b_cs") {
                if ($elm[MPB_CS] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MPB_CS] = $suf;
            }
            elsif ($kind eq "rw2b_wd") {
                if ($elm[MPB_WD] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MPB_WD] = $suf;
            }
            elsif ($kind eq "rw2b_rd") {
                if ($elm[MPB_RD] ne "") {
                    goto ERROR_SUF;
                }
                $elm[MPB_RD] = $suf;
            }
            else {
                goto ERROR_SUF;
            }

            if ($kind =~ /^rw1_/) {
                if (exists $used_rw1{$suf}) {
                    goto ERROR_SUF;
                }
                $used_rw1{$suf} = 0;
            }
            elsif ($kind =~ /^r1w1_/) {
                if (exists $used_r1w1{$suf}) {
                    goto ERROR_SUF;
                }
                $used_r1w1{$suf} = 0;
            }
            else {
                if (exists $used_rw2{$suf}) {
                    goto ERROR_SUF;
                }
                $used_rw2{$suf} = 0;
            }
        }
        else {
            goto ERROR_SUF;
        }
    }
    if ($mode == 0) {
        $elm[MP_FILE] = "";
        @{$suf_list[0]} = @elm;
    }
    else {
        push(@suf_list, [@elm]);
    }
    return;

    ERROR_SUF:
    {
        message("E336", $suf_file, $line_num,
                "There is an inappropriate setting in suffix setting \"$suf_file\"");
    }
}

##
## check reserved word
##   $word     : target string
##   $file     : file name
##   $line_num : line number
##
sub check_reserved {
    my ($word, $file, $line_num) = @_;

    if (exists $rsv_word{$word}) {
        message("E501", $file, $line_num,
            "\"$word\" may be identical with reserved word");
    }

    foreach $prefix (@rsv_prefix) {
        if ($word =~ /^$prefix/) {
            message("E501", $file, $line_num,
                "\"$word\" may be identical with reserved word");
        }
    }
}

##
## check namerule
##   $word        : target string
##   $file        : file name
##   $strict_mode : prohibit '_' for heading character (= 1:Y, 0:N)
##   $line_num    : line number
##
sub check_namerule {
    my ($word, $strict_mode, $file, $line_num) = @_;
    if ($word !~ /^\w+$/
        || $word =~ /_$/
        || length($word) > 511
        || ($strict_mode == 0 && $word =~ /^\d/)
        || ($strict_mode == 1 && $word =~ /^[_\d]/)) {
            message("E502", $file, $line_num,
                "\"$word\" violates the naming rule");
    }
}

##
## check format (check reserved word & namerule)
##   $word        : target string
##   $file        : file name
##   $strict_mode : prohibit '_' for heading character (= 1:Y, 0:N)
##   $line_num    : line number
##
sub check_format {
    my ($word, $strict_mode, $file, $line_num) = @_;
    &check_reserved($word, $file, $line_num);
    &check_namerule($word, $strict_mode, $file, $line_num);
}

##
## check the word has already defined
##   $word     : target string
##   $mode     : add target string to hash (= 1:Y, 0:N)
##   $file     : file name
##   $line_num : line number
##
sub check_defined {
    my ($word, $mode, $file, $line_num) = @_;

    if (exists $defined_word{lc($word)}) {
        message("E601", $file, $line_num,
            "\"$word\" has been already defined");
    }

    if ($mode == 1) {
        $defined_word{lc($word)} = 0;
    }
}

##
## check the word has already defined for TB
##   $word     : target string
##   $mode     : add target string to hash (= 1:Y, 0:N)
##   $file     : file name
##   $line_num : line number
##
sub check_defined_tb {
    my ($word, $mode, $file, $line_num) = @_;

    if (exists $defined_word_tb{lc($word)}) {
        message("E601", $file, $line_num,
            "\"$word\" has been already defined");
    }

    if ($mode == 1) {
        $defined_word_tb{lc($word)} = 0;
    }
}

##
## check the variable is number or not
##  return : flag (= 1:number, 0:string)
##   $arg  : variable
##
sub is_number {
    my $arg = $_[0];
    if ($arg =~ /^([+-]?([1-9]\d*|0x[0-9a-f]+|0[0-7]*))u?l*$/i) {
        return 1;
    }
    else {
        return 0;
    }
}

##
## check the variable is hex number or not
##  return : flag (= 1:hex number, 0: others)
##   $arg  : variable
##
sub is_hex_number {
    my $arg = $_[0];
    if ($arg =~ /^(0x[0-9a-f]+)u?l*$/i) {
        return 1;
    }
    return 0;
}

##
## check if the variable include floating point
##  return : flag (= 1:use, 0: not use)
##   $arg  : variable
##
sub use_float {
    my $arg = $_[0];
    if ($arg =~ /\b\d+\.\d+\b/){
        return 1;
    }
    else {
        return 0;
    }
}

##
## check the string is correct format for width description
##   $wid      : target string
##   $file     : file name
##   $line_num : line number
##
sub check_width {
    my ($wid, $file, $line_num) = @_;
    if (&is_template_parameter($$wid, \$tmp) == 1) {
        if (@$tmp[G_TYPE] ne "typename") {
            message("E808", $file, $line_num, "not support \"@$tmp[G_TYPE]\" template for bitwidth");
        }
    }
    elsif ($$wid ne "b" && &is_struct($$wid) == 0) {
        my $tmp = &get_macro_value($$wid, $file, $line_num);
        if ($tmp < 1) {
            message("E203", $file, $line_num,
                    "width should be more than 0 [$tmp]");
        }
        if (&is_keep_define($$wid) == 0) {
            $$wid = $tmp;
        }
    }
}

##
## check now scope is COM for COM only command or TB for TB only command
##   $command  : command string
##   $mode     : flag (= 0:COM only, 1:TB only)
##   $file     : file name
##   $line_num : line number
##
sub check_scope {
    my ($command, $mode, $file, $line_num) = @_;
    if ($mode == 0) {
        if ($now_area == TB) {
            message("E013", $file, $line_num,
                    "\"$command\" should not be set in \"$tb_macro\"");
        }
        elsif ($now_area == SIM) {
            message("E016", $file, $line_num,
                    "\"$command\" should not be set in \"#ifdef macro\"");
        }
        elsif ($now_area == SLECBB) {
            message("E023", $file, $line_num,
                    "\"$command\" should not be set in \"$slecbb_macro\"");
        }
    }
    else {
        if ($now_area != TB) {
            message("E020", $file, $line_num,
                    "\"$command\" should be set in \"$tb_macro\"");
        }
    }
}

##
## check the command is not used inside `ifdef or `else (except TESTBENCH)
##   $command  : command string
##   $file     : file name
##   $line_num : line number
##
sub check_inside_ifdef {
    my ($command, $file, $line_num) = @_;
    if ($ifdef[$level] > 0) {
        message("E021", $file, $line_num,
                "\"$command\" should not be set in \"`ifdef\" or \"`else\"");
    }
}

##
## check the order of command for module definition file
##   $command  : command string
##   $state    : command state which should be
##   $file     : file name
##   $line_num : line number
##   $level    : nest level
##
sub check_mod_order {
    my ($command, $state, $file, $line_num, $level) = @_;
    if ($top_mode == 1 || $level > 0) {
        return;
    }

    if ($state == $parse_state + 1) {
        $parse_state++;
    }

    if ($state == 0 && $parse_state > 0) {
        message("E001", $file, $line_num,
                "\"$command\" should be set before \"module\"");
    }
    elsif ($state == 2 && $parse_state == 0) {
        message("E002", $file, $line_num,
                    "\"$command\" should be set after \"module\"");
    }
    elsif ($state == 3 && $parse_state == 0) {
        if (@clk_list == 0) {
            #message("E003", $file, $line_num,
            #            "\"$command\" should be set after \"clock\"");
        }
        else {
            message("E002", $file, $line_num,
                        "\"$command\" should be set after \"module\"");
        }
    }
    elsif ($state == 3 && $parse_state == 1) {
        if (@clk_list > 0) {
            $parse_state = 3;
        }
        #else {
        #    message("E003", $file, $line_num,
        #                "\"$command\" should be set after \"clock\"");
        #}
    }
    if ($state == 0 && $use_template == 1) {
        message("E004", $file, $line_num,
                        "\"template\" must be followed by \"module\"");
    }
}

##
## check the order of command for top definition file
##   $command  : command string
##   $state    : command state which should be
##   $file     : file name
##   $line_num : line number
##   $level    : nest level
##
sub check_top_order {
    my ($command, $state, $file, $line_num, $level) = @_;
    if ($level > 0) {
        return;
    }

    if ($state == $parse_state + 1) {
        $parse_state++;
    }

    if ($state == 0 && $parse_state > 0) {
        message("E006", $file, $line_num,
                "\"$command\" should be set before \"top\"");
    }
    elsif ($state == 2 && $parse_state < 2) {
        message("E007", $file, $line_num,
                    "\"$command\" should be set after \"top\"");
    }
    elsif ($state == 2 && $parse_state == 3) {
        #message("E022", $file, $line_num,
        #            "\"sub\" should be set before \"tap/bind/`ifdef\"");
        message("E022", $file, $line_num,
                    "\"$command\" should be set before \"tap/bind/`ifdef\"");
    }
    elsif ($state == 3 && $parse_state < 3) {
        message("E008", $file, $line_num,
                    "\"$command\" should be set after \"sub\"");
    }
}

##
## check the memory type match pattern
##   $name : memory name
##   $t1   : memory type1
##   $t2   : memory type2
##
sub check_memtype_match {
    my ($name, $t1, $t2) = @_;
    my $tmp;
    if (($t1 & MA_W) || ($t1 & MA_B)) {
        $tmp = $t1;
        $t1 = $t2;
        $t2 = $tmp;
    }
    if ($top_mode == 0) {
        if (!($t1 == MA_R1W1_R && $t2 == MA_R1W1_W)) {
            if ($t1 == MA_RW1_R && $t2 == MA_RW1_W) {
                message("E414", "", 0, "not support specifying \"rw1:r\" and \"rw1:w\" to one " .
                 "memory \"$name\" in a module");
            }
            else {
                message("E401", "", 0, "not support multiple access to one " .
                 "memory \"$name\" except for R/W or DP access");
            }
        }
    }
    else {
        if (!($t1 == MA_R1W1_R && $t2 == MA_R1W1_W)
         && !($t1 == MA_RW1_R && $t2 == MA_RW1_W)
         && !($t1 == MA_RW2_A && $t2 == MA_RW2_B)) {
            message("E401", "", 0, "not support multiple access to one " .
             "memory \"$name\" except for R/W or DP access");
        }
    }
}

##
## check the name has already been included in the array
##  return   : flag (= 1:Y, 0:N)
##   $array  : target array
##   $name   : target name
##   $rtn(O) : pointer of hit element
##
sub name_exist {
    my ($array, $name, $rtn) = @_;
    foreach $elm (@$array) {
        if (@$elm[1] eq $name) {
            $$rtn = $elm;
            return 1;
        }
    }
    return 0;
}

##
## check the macro has already define by `define command
##  return   : flag (= 1:Y, 0:N)
##   $name   : target macro name
##
sub define_exist {
    my $name = $_[0];
    my $define_list = ($top_mode != 0) ? \@define_in_top_list : \@define_in_list;
    foreach my $def (@$define_list) {
        if ($name eq @$def[G_NAME]) {
            return 1;
        }
    }
    return 0;
}

##
## check the name has already been included in the array for macro list
##  return   : flag (= 1:Y, 0:N)
##   $array  : target array
##   $name   : target name
##   $rtn(O) : pointer of hit element
##
sub name_exist_m {
    my ($array, $name, $rtn) = @_;
    my ($m, $elm);
    foreach $m (@$array) {
        $macro = shift(@$m);
        foreach $elm (@$m) {
            if (@$elm[1] eq $name) {
                $$rtn = $elm;
                return 1;
            }
        }
        unshift(@$m, $macro);
    }
    return 0;
}

##
## check the thread should have merge reset for osci-sim
##  return : flag (= 1:Y, 0:N)
##   $th   : target thread
##
sub need_osci_reset {
    my $th = $_[0];
    if (@$th == TH_RST) {
        $head = $rst_list[0];
        if (@rst_list > 1 || @$head[T_TYPE] eq "areset") {
            return 1;
        }
    }
    else {
        $name = @$th[TH_RST];
        if (lc $name eq "n") {
            return 0;
        }
        &name_exist(\@rst_list, $name, \$head);
        if (@$th > TH_RST + 1 || @$head[T_TYPE] eq "areset") {
            return 1;
        }
    }
    return 0;
}

##
## check whether const member exists
##  return : result (= 1:Y, 0:N)
##   $list : pointer of list data
##
sub exist_const {
    my $list = $_[0];
    my $exist = 0;
    foreach $elm (@$list) {
        if (@$elm[T_FLG] & FLG_CONST) {
            $exist = 1;
            last;
        }
    }
    return $exist;
}

##
## get valid clock num & 1st data
##  return : number of valid clock
##   $rtn(O) : pointer of 1st valid clock data
##
sub get_valid_clock {
    my $rtn = $_[0];
    my $num = 0;
    foreach $elm (@clk_list) {
        if (@$elm[T_NAME] ne "") {
            if ($num == 0) {
                $$rtn = $elm;
            }
            $num++;
        }
    }
    return $num;
}

##
## get port data
##   $inst : instance name
##   $port : port name
##   $ptr  : port pointer
##
sub get_port_data {
    my ($inst, $port, $ptr) = @_;
    foreach $elm (@clk_list, @rst_list, @in_list, @in_list_sync, @out_list, @out_list_sync) {
        if (@$elm[T_INST] eq $inst && @$elm[T_ONAME] eq $port) {
            $$ptr = $elm;
            last;
        }
    }
}

##
## get reg data
##   $inst : instance name
##   $port : port name
##   $ptr  : port pointer
##
sub get_reg_data {
    my ($reg, $ptr) = @_;
    foreach $elm (@reg_list) {
        if (@$elm[T_NAME] eq $reg) {
            $$ptr = $elm;
            last;
        }
    }
}

##
## is FLG_FIX and FLG_IFDEF contained?
##  return : = 1:yes, 0:no
##  $elm   : data array
##
sub is_ifdeffix {
    my $elm = $_[0];
    my $flg = 0;

    if ((@$elm[T_FLG] & FLG_FIX) && (@$elm[T_FLG] & FLG_IFDEF)) {
        $flg = 1;
    }
    return $flg;
}

##
## get the memory kind string
##  return    : string
##   $memkind : memory kind
##
sub get_memkind_string {
    my $memkind = $_[0];
    my $memshare = $_[1];
    my $rtn = "";
    if ($memkind == MA_RW1) {
        $rtn = "rw1";
    }
    elsif ($memkind == MA_RW1_R) {
        if ($memshare == 0) {
            $rtn = "rw1:r";
        }
        else {
            $rtn = "rw1";
        }
    }
    elsif ($memkind == MA_RW1_W) {
        if ($memshare == 0) {
            $rtn = "rw1:w";
        }
        else {
            $rtn = "rw1";
        }
    }
    elsif ($memkind == MA_R1W1_R) {
        $rtn = "r1w1:r";
    }
    elsif ($memkind == MA_R1W1_W) {
        $rtn = "r1w1:w";
    }
    elsif ($memkind == MA_RW2_A) {
        $rtn = "rw2:a";
    }
    elsif ($memkind == MA_RW2_B) {
        $rtn = "rw2:b";
    }
    return $rtn;
}

##
## separate macro string into name and body
##   $str     : macro string
##   $name(O) : macro name
##   $body(O) : macro body
##
sub sep_macro {
    my ($str, $name, $body) = @_;
    $str =~ s/\s+$//;
    if ($str =~ /(\w+)((\s|\().*)/) {
        $$name = $1;
        $$body = $2;
    }
    else {
        $$name = $str;
        $$body = "";
    }
}

##
## get the comment for macro function
##  return : comment string
##   $elm  : pointer of memory data
##
sub get_macro_comment {
    my $elm = $_[0];
    my $rw  = @$elm[M_RW];
    my $com;

    if (($rw == MA_RW1) || (($rw & MA_1PORT) && @$elm[M_SHARE] > 0)) {
        $com = "1port";
    }
    elsif ($rw == MA_RW1_R) {
        $com = "1port-R";
    }
    elsif ($rw == MA_RW1_W) {
        $com = "1port-W";
    }
    elsif ($rw == MA_R1W1_R) {
        $com = "2port-R";
    }
    elsif ($rw == MA_R1W1_W) {
        $com = "2port-W";
    }
    elsif ($rw == MA_RW2_A) {
        $com = "dual-port-A";
    }
    elsif ($rw == MA_RW2_B) {
        $com = "dual-port-B";
    }
    if (($rw & MA_W) || ($rw & MA_DPORT) || ($rw == MA_RW1_R && @$elm[M_SHARE] > 0)) {
        $com = $com . ", WE(" . (@$elm[M_WE] == 2 ? "L" : "H") . ")";
    }
    if ((($rw & MA_W) || ($rw & MA_DPORT) || ($rw == MA_RW1_R && @$elm[M_SHARE] > 0)) && (@$elm[M_CS] > 0)) {
        $com = $com . ", CS";
        $com = $com . "(" . (@$elm[M_CS] == 2 ? "L" : "H") . ")";
    }
    if (($rw & MA_W) && (@$elm[M_BE] > 0)) {
        $com = $com . ", BE";
        $com = $com . "(" . (@$elm[M_BE] == 2 ? "L" : "H") . ")";
    }
    if (($rw & MA_R) && (@$elm[M_RE] > 0) && (@$elm[M_SHARE] == 0)) {
        $com = $com . ", RE";
        $com = $com . "(" . (@$elm[M_RE] == 2 ? "L" : "H") . ")";
    }
    if (@$elm[M_PONLY]) {
        $com = $com . ", port-only";
    }
    return $com;
}

##
## is `define macro string is kept
##  return : flag (= 1: kept, 0: not)
##   $name : macro name
##
sub is_keep_define {
    my $name = $_[0];
    my $define_list = ($top_mode != 0) ? \@define_in_top_list : \@define_in_list;
    foreach $elm (@$define_list) {
        if(@$elm[G_NAME] eq $name) {
            @$elm[G_FLAG] |= FLG_USED;
            if (@$elm[G_FLAG] & FLG_KEEP_STR) {
                return 1;
            }
            last;
        }
    }
    return 0;
}

##
## is signed type ?
##  return : = 1:signed, 0:unsigned/bool
##   $port : port array
##
sub is_signed {
    my $port = $_[0];
    my $sign = 0;

    if (@$port[T_WID] ne "b" && @$port[T_TYPE] !~ /^u/) {
        $sign = 1;
    }
    return $sign;
}

##
## get SystemC data type
##  return    : data type string
##   $sign    : sign  of data
##   $wid     : width of data
##   $no_tmpl : not generating template width (= 1:Y, 0:N)
##   $use_big : use sc_bigint/sc_biguint type forcibly  (= 1:Y, 0:N)
##
sub get_sctype {
    my ($sign, $wid, $no_tmpl, $use_big) = @_;
    my $type_name = "";
    $no_tmpl = 0 unless defined($no_tmpl);
    $use_big = 0 unless defined($use_big);

    my $tmp = &define_exist($wid) ? &get_macro_value($wid, "", 0) : $wid;

    if (&is_number($tmp)) {
        if ($tmp > 64 || $use_big == 1) {
            $type_name = $sign == 1 ? "sc_bigint" : "sc_biguint";
        }
        else {
            $type_name = $sign == 1 ? "sc_int" : "sc_uint";
        }
        if ($no_tmpl == 0) {
            $type_name = $type_name . "<" . $wid . ">";
        }
    }
    elsif ($wid =~ />>3$/) {
        $type_name = $sign == 1 ? "sc_int" : "sc_uint";
        if ($no_tmpl == 0) {
            $type_name = $type_name . "<" . $wid . ">";
        }
    }
    else {
        if ($wid eq "b") {
            $type_name = "bool";
        }
        elsif ($wid =~ /(uchar|ushort|uint)/) {
            $type_name = "unsigned " . substr($wid, 1);
        }
        else {
            $type_name = $wid;
        }
    }

    return $type_name;
}

##
## get type definition
##  return : type string
##   $type : type of data
##   $wid  : width of data
##   $rev  : flag of reversing R/W (= 1:Y, 0:N)
##
sub get_type {
    my ($type, $wid, $rev) = @_;
    my $type_name = "";
    my $sign = 0;
    $rev = 0 unless defined($rev);

    if ($type =~ /^(sin|sout|sreg|svar|sev)$/) {
        $sign = 1;
    }

    if ($type =~ /in$/) {
        if ($rev == 0) {
            $type_name = "sc_in < ";
        }
        else {
            $type_name = "sc_out < ";
        }
    }
    elsif ($type =~ /out$/) {
        if ($rev == 0) {
            $type_name = "sc_out < ";
        }
        else {
            $type_name = "sc_in < ";
        }
    }
    elsif ($type =~ /reg$/) {
        $type_name = "sc_signal < ";
    }

    if ($type =~ /(in|out|reg|var)$/) {
        $type_name = $type_name . &get_sctype($sign, $wid);
        if ($type =~ /(in|out|reg)$/) {
            $type_name = $type_name . " >";
        }
    }
    else {
        $type_name = &get_sctype($sign, $type);
    }
    return $type_name;
}

##
## get attributes (array / initialization / threadname)
##   $elm(O)   : array for attributes
##   $line     : string
##   $file     : file name
##   $line_num : line number
##   $com      : comment
##   $inst     : module instance name
##   $type     : type name
##   $wid      : width of type data
##   $flg      : flag of type data
##
sub get_attributes {
    my ($elm, $line, $file, $line_num, $com, $inst, $type, $wid, $flg) = @_;
    $name  = "";
    $array = "";
    $init  = "";
    $th    = "";
    $min   = "";
    $max   = "";
    $macro = "";
    $ename = "";

    if (&is_template_parameter($wid) && $type =~ /^[u|s]ev$/) {
        message("E809", $file, $line_num, "not support template for {u|s}ev command");
    }

    $wid_t  = ($wid eq "b") ? $wid : &get_macro_value($wid , $file, $line_num);
    $cnt_init = 0;
    $cnt_min  = 0;
    $cnt_max  = 0;
    $struct_op_str = "";

    # when both of "=" and "-init" are used mixed
    if ($line =~ /=/ && $line =~ /\s-init\s/) {
        message("E202", $file, $line_num, "\"$type\" has invalid format");
    }
    # check option
    if ($line =~ m{^(.*?)\s+(-(init|th|range_check
                        |for_style|var2reg|min|max
                        |debug_trace|debug_macro
                        |no_trace|sync|low|high
                        |en|data|reg|stall|en_sig
                        |dis_sig|dont_touch|random|op).*)$}x)
    {
        $prev = $1;
        $opt  = $2;
        if ($opt =~ /(.*?)([^><=!]=.*)/) {
            $opt = $1;
            $line = $prev . $2;
        }
        else {
            $line = $prev;
        }
        while ($opt =~ /-((op\s+\W+|[^-]|-\d)+)/g) {
            my $one = $1;
            $one =~ s/\s*$//;
            my $lhs = $one;
            my $rhs = "";
            if ($one =~ /(.*?)(\s*=\s*|\s+)(.*)/) {
                $lhs = $1;
                $rhs = $3;
            }
            if ($lhs eq "th") {
                if ($now_area == TB) {
                    message("E330", $file, $line_num,
                        "th option should not be set to \"$type\" in $tb_macro macro");
                }
                if ($type =~ /^(sin|uin)$/ || $rhs =~ /\s/) {
                    message("E202", $file, $line_num, "\"$type\" has invalid format");
                }
                if ($rhs eq "") {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                if ($th ne "") {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                $th = $rhs;
            }
            elsif ($lhs eq "init") {
                if ($type =~ /^(sin|uin)$/) {
                    message("E202", $file, $line_num, "\"$type\" has invalid format");
                }
                if ($init ne "") {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                if ($rhs eq "") {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                $init = $rhs;
                while ($rhs =~ /[^\s\{\}\,]+/g) {
                    my $tmp = $&;
                    my $val = $tmp;
                    $cnt_init++;
                    if (&is_keep_define($tmp) == 0 && &define_exist($tmp) == 1) {
                        $val = &get_macro_value($tmp, $file, $line_num);
                        $init =~ s/\b$tmp\b/$val/;
                    }
                }
            }
            elsif ($lhs eq "min") {
                if ($min ne "") {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                if ($rhs eq "" || &is_struct($wid_t)) {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                while ($rhs =~ /[^\s\{\}\,]+/g) {
                    my $tmp = $&;
                    if (&is_keep_define($tmp) == 0 && &define_exist($tmp) == 1) {
                        $tmp = &get_macro_value($tmp, $file, $line_num);
                    }
                    $min .= ($min eq "") ? $tmp : " $tmp";
                    $cnt_min++;
                }
            }
            elsif ($lhs eq "max") {
                if ($max ne "") {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                if ($rhs eq "" || &is_struct($wid_t)) {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                while ($rhs =~ /[^\s\{\}\,]+/g) {
                    my $tmp = $&;
                    if (&is_keep_define($tmp) == 0 && &define_exist($tmp) == 1) {
                        $tmp = &get_macro_value($tmp, $file, $line_num);
                    }
                    $max .= ($max eq "") ? $tmp : " $tmp";
                    $cnt_max++;
                }
            }
            elsif ($lhs eq "for_style") {
                if ($flg & FLG_RNGFOR) {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                if ($rhs ne "") {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                $flg |= FLG_RNGFOR;
            }
            elsif ($lhs eq "range_check") {
                if ($flg & FLG_RNGCHK) {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                if ($rhs ne "") {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                $flg |= FLG_RNGCHK;
            }
            elsif ($lhs eq "var2reg") {
                if (($type !~ /^([su]var|u?int|u?short|u?char)$/) || ($flg & FLG_CONST)) {
                    message("E202", $file, $line_num, "\"$type\" has invalid format");
                }
                if ($flg & FLG_VAR2REG) {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                if ($rhs ne "") {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                if ($now_area != COM) {
                    message("E339", $file, $line_num,
                       "option [-$lhs] should not be set in \"#ifdef macro\" or \"`ifdef $tb_macro\"");
                }
                $flg |= FLG_VAR2REG;
            }
            elsif ($lhs eq "debug_trace") {
                if (($type !~ /^([su]var|u?int|u?short|u?char)$/) || ($flg & FLG_CONST)) {
                    message("E202", $file, $line_num, "\"$type\" has invalid format");
                }
                if ($flg & FLG_DTRACE) {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                if ($rhs ne "") {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                if ($now_area != COM) {
                    message("E339", $file, $line_num,
                       "option [-$lhs] should not be set in \"#ifdef macro\" or \"`ifdef $tb_macro\"");
                }
                if (&is_number($wid_t) && $wid_t > 999) {
                    message("E343", $file, $line_num,
                        "option [-$lhs] should not set to variable whose width is more than 999");
                }
                $flg |= FLG_DTRACE;
            }
            elsif ($lhs eq "debug_macro") {
                if (($type !~ /^([su]var|u?int|u?short|u?char)$/) || ($flg & FLG_CONST)) {
                    message("E202", $file, $line_num, "\"$type\" has invalid format");
                }
                if ($rhs eq "") {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                if ($macro ne "") {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                if ($now_area != COM) {
                    message("E339", $file, $line_num,
                       "option [-$lhs] should not be set in \"#ifdef macro\" or \"`ifdef $tb_macro\"");
                }
                $macro = $rhs ne "" ? $rhs : $dbg_macro;
            }
            elsif ($lhs eq "no_trace") {
                if ($type !~ /^([su](in|out|ev|reg))$/) {
                    message("E202", $file, $line_num, "\"$type\" has invalid format");
                }
                if ($flg & FLG_NO_TRACE) {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                if ($rhs ne "") {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                if ($now_area != COM) {
                    message("E339", $file, $line_num,
                       "option [-$lhs] should not be set in \"#ifdef macro\" or \"`ifdef $tb_macro\"");
                }
                $flg |= FLG_NO_TRACE;
            }
            elsif ($lhs eq "en") {
                if ($type !~ /^([su](in|out))$/ || $wid ne "b") {
                    message("E202", $file, $line_num, "\"$type\" has invalid format");
                }
                if (($flg & FLG_CATG_EN)  || ($flg & FLG_CATG_DATA) ||
                    ($flg & FLG_CATG_REG) || ($flg & FLG_CATG_STALL))
                {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                if ($rhs ne "" && $rhs ne "high" && $rhs ne "low") {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                $flg |= FLG_CATG_EN;
                $flg |= FLG_ACTV_LOW if ($rhs eq "low");
            }
            elsif ($lhs eq "data") {
                if ($type !~ /^([su](in|out))$/) {
                    message("E202", $file, $line_num, "\"$type\" has invalid format");
                }
                if (($flg & FLG_CATG_EN)  || ($flg & FLG_CATG_DATA) ||
                    ($flg & FLG_CATG_REG) || ($flg & FLG_CATG_STALL))
                {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                if ($rhs ne "") {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                $flg |= FLG_CATG_DATA;
            }
            elsif ($lhs eq "reg") {
                if ($type !~ /^([su]in)$/) {
                    message("E202", $file, $line_num, "\"$type\" has invalid format");
                }
                if (($flg & FLG_CATG_EN)  || ($flg & FLG_CATG_DATA) ||
                    ($flg & FLG_CATG_REG) || ($flg & FLG_CATG_STALL))
                {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                if ($rhs ne "") {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                $flg |= FLG_CATG_REG;
            }
            elsif ($lhs eq "stall") {
                if ($type !~ /^([su](in|out))$/ || $wid ne "b") {
                    message("E202", $file, $line_num, "\"$type\" has invalid format");
                }
                if (($flg & FLG_CATG_EN)  || ($flg & FLG_CATG_DATA) ||
                    ($flg & FLG_CATG_REG) || ($flg & FLG_CATG_STALL))
                {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                if ($rhs ne "" && $rhs ne "high" && $rhs ne "low") {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                $flg |= FLG_CATG_STALL;
                $flg |= FLG_ACTV_LOW if ($rhs eq "low");
            }
            elsif ($lhs eq "en_sig" || $lhs eq "dis_sig") {
                if ($type !~ /^([su](in|out))$/ || ($type =~ /^[su]out$/ && ($flg & FLG_CATG_EN))) {
                    message("E202", $file, $line_num, "\"$type\" has invalid format");
                }
                if ($ename ne "") {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                if ($rhs eq $ename) {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                $ename = $rhs;
                if ($lhs eq "dis_sig") {
                    $flg |= FLG_DISABLE;
                    $use_disable = 1;
                }
            }
            elsif ($lhs eq "dont_touch") {
                if ($type !~ /^[su]in$/ && !($flg & FLG_CATG_EN) && !($flg & FLG_CATG_STALL)) {
                    message("E202", $file, $line_num, "\"$type\" has invalid format");
                }
                if ($flg & FLG_DONT_TOUCH) {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                if ($rhs ne "") {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                $flg |= FLG_DONT_TOUCH;
            }
            elsif ($lhs eq "random") {
                if ($type !~ /^[su]in$/ && !($flg & FLG_CATG_EN) && !($flg & FLG_CATG_STALL)) {
                    message("E202", $file, $line_num, "\"$type\" has invalid format");
                }
                if ($flg & FLG_RANDOM) {
                    message("E207", $file, $line_num, "option [-$lhs] is set again");
                }
                if ($rhs ne "") {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                $flg |= FLG_RANDOM;
            }
            elsif ($lhs eq "op" && $is_struct_parsing == 1) {
                if ($rhs eq "") {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
                &check_struct_operator($file, $line_num, $rhs);
                $struct_op_str = $rhs;
            }
            else {
                message("E202", $file, $line_num, "\"$type\" has invalid format");
            }
        }
    }

    if (!($flg & FLG_CATG_EN)  && !($flg & FLG_CATG_DATA) &&
        !($flg & FLG_CATG_REG) && !($flg & FLG_CATG_STALL))
    {
        $flg |= FLG_CATG_DATA;
    }

    # when init value is assigned by "="
    if ($line =~ /=/) {
        $line =~ /(.*?)\s*=\s*(.*)/;
        $line = $1;
        $rhs  = $2;
        $rhs =~ s/\s*$//;
        if ($rhs ne "") {
            $init = $rhs;
            $cnt_init = 0;
            while ($rhs =~ /[^\s\{\}\,]+/g) {
                my $tmp = $&;
                my $val = $tmp;
                $cnt_init++;
                if (&is_keep_define($tmp) == 0 && &define_exist($tmp) == 1) {
                    $val = &get_macro_value($tmp, $file, $line_num);
                    $init =~ s/\b$tmp\b/$val/;
                }
            }
        }
    }

    if ($init =~ /=/) { # temporary check
        message("E306", $file, $line_num, "init value has invalid format [$init]");
    }

    if (lc $init eq "n" && ($flg & FLG_CONST)) {
        message("E307", $file, $line_num,
            "no initialize (\"n\") should not be set when you set \"const\"");
    }
    if (lc $init eq "n" && $is_struct_parsing) {
        message("E307", $file, $line_num,
            "no initialize (\"n\") should not be set for struct member");
    }

    if ($type =~ /^(sin|uin)$/) {
        if ($init ne "") {
            message("E202", $file, $line_num, "\"$type\" has invalid format");
        }
        $init = "0";
    }
    else {
        if ($init eq "") {
            $init = "0";
        }
    }

    # revise init, min, max for bitwid > 32
    $wid_t  = ($wid eq "b") ? $wid : &get_macro_value($wid , $file, $line_num);
    $init_t = "";
    $min_t  = "";
    $max_t  = "";
    if ($wid_t && $wid_t ne "b" && $wid_t > 32) {
        $type_t = &get_type(($type =~ /^s/) ? "svar" : "uvar", $wid);
        while ($init =~ /[^\s\{\}\,]+/g) {
            my $tmp = $&;
            $init_t .= ($init_t ne "") ? " " : "";
            if (&is_number($tmp)) {
                if ($tmp ne "0" && &log2($tmp) > 32) {
                    $tmp =~ s/u?l*$//i;
                    $init_t .= "(" . $type_t . ")" . $tmp . (($type =~ /^s/) ? "LL" : "ULL");
                }
                else {
                    $init_t .= $tmp;
                }
            }
            else {
                $init_t .= "(" . $type_t . ")" . $tmp;
            }
        }
        $init = ($init eq "n" || ($t_flg & FLG_CONST)) ? $init : $init_t;
        while ($min =~ /[^\s]+/g) {
            my $tmp = $&;
            $min_t .= ($min_t ne "") ? " " : "";
            if (&is_number($tmp)) {
                if ($tmp ne "0" && &log2($tmp) > 32) {
                    $tmp =~ s/u?l*$//i;
                    $min_t .= "(" . $type_t . ")" . $tmp . (($type =~ /^s/) ? "LL" : "ULL");
                }
                else {
                    $min_t .= $tmp;
                }
            }
            else {
                $min_t .= "(" . $type_t . ")" . $tmp;
            }
        }
        $min = $min_t;
        while ($max =~ /[^\s]+/g) {
            my $tmp = $&;
            $max_t .= ($max_t ne "") ? " " : "";
            if (&is_number($tmp)) {
                if ($tmp ne "0" && &log2($tmp) > 32) {
                    $tmp =~ s/u?l*$//i;
                    $max_t .= "(" . $type_t . ")" . $tmp . (($type =~ /^s/) ? "LL" : "ULL");
                }
                else {
                    $max_t .= $tmp;
                }
            }
            else {
                $max_t .= "(" . $type_t . ")" . $tmp;
            }
        }
        $max = $max_t;
    }

    # pick up name & array
    $line =~ /\w+\s+(\w+)(.*)/;
    $name   = $1;
    $array  = $2;
    $array =~ s/\s//g;

    my $dim = 0;
    if ($array ne "") {
        if ($array !~ /^(\[.*?\])+$/) {
            message("E202", $file, $line_num, "\"$type\" has invalid format");
        }

        #my $dim = 0;
        my $tmpl_arr = $array;
        my $len_val;
        my $tmpl_macro;
        #my $cnt_arr = 1;
        my $temp;
        while ($tmpl_arr =~ /\w+/g) {
            $tmpl_macro = $&;
            if (&is_template_parameter($tmpl_macro, \$temp)) {
                $len_val = $$temp[G_VALUE];    
            }
            else {
                $len_val = &get_macro_value($tmpl_macro, $file, $line_num);
                if (&is_keep_define($tmpl_macro) == 0) {
                    $array =~ s/\b$tmpl_macro\b/$len_val/g;
                }
            }
            if ($len_val < 1) {
                message("E304", $file, $line_num, "array element should be more than 0");
            }
            #$cnt_arr *= $len_val;
            $dim++;
        }
        if ($is_struct_parsing) {
            $struct_array = ($dim > $struct_array) ? $dim : $struct_array;
        }
        if ($dim > 3) {
            message("E305", $file, $line_num, "not support 4D or more array");
        }
        my $struct;
        if (&name_exist(\@struct_list, $wid, \$struct)) {
            if (($dim + $$struct[STR_MEM_ARRAY]) > 3) {
                message("E305", $file, $line_num, "not support 4D or more array for struct and member");
            }
        }
        if (($flg & FLG_CATG_EN) || ($flg & FLG_CATG_STALL)) {
            message("E319", $file, $line_num, "not support array of enable/stall signal");
        }
    }

    if ($flg & FLG_RNGCHK) {
        if (&is_number($wid_t) && ($wid_t > 64)) {
            message("I007", $file, $line_num,
                "ignored \"-range_check\" option because the width > 64");
            $flg &= ~FLG_RNGCHK;
        }
        if ($flg & FLG_CONST) {
            message("I008", $file, $line_num,
                "ignored \"-range_check\" option because the variable is a constant variable");
            $flg &= ~FLG_RNGCHK;
        }
        if ($opt_standard) {
            $standard_ignore = 1;
            $flg &= ~FLG_RNGCHK;
        }
    }

    if ($flg & FLG_DTRACE) {
        $macro = $dbg_macro if ($macro eq "");
        $now_macro = $macro;
        if ($macro !~ /^_DEBUG/) {
            message("E308", $file, $line_num, "please use only _DEBUG* for -debug_macro option");
        }
    }

    if ($top_dbg ne "") {
        $flg |= FLG_IFDEF;
    }

    if (&is_struct($wid)) {
        $flg |= FLG_STR_TYPE;
    }

    @$elm = ($com, $name, $inst, $type, $init, $array, $wid, $name, $flg, $th, $min, $max, $top_dbg, $ename, "", "", "", 0, $struct_op_str);
}

##
## replace argument of function
##  return : string replaced type
##   $pre  : previous character
##   $type : data type
##   $suf  : words after data type
##
sub arg_replace {
    my ($pre, $type, $suf) = @_;
    if ($suf !~ /^\s*$|^[b\*\&]$/ && &is_keep_define($suf) == 0) {
        $suf = &get_macro_value($suf, "", 0);
    }
    $str = $pre . &get_type($type, $suf);
    if ($type =~ /(uchar|ushort|uint)/) {
        $str = $str . $suf;
    }
    return $str;
}

##
## get return part and body part from func format
##   $line     : string
##   $file     : file name
##   $line_num : line number
##   $name(O)  : pointer of name string
##   $ret(O)   : pointer of return string
##   $body(O)  : pointer of function body string
##
sub get_func_ret_body {
    my ($line, $file, $line_num, $name, $ret, $body, $flg) = @_;

    # delete "func" and separate return and body
    if ($line =~ /^func\s+(.+?)\s+(\S+?)\s*(\(.*\))\s*((-(ctos_dont_touch|only_def|ctos_noninline|slec_bbox)\s*)*)$/) {
        $$ret = $1;
        $$name = $2;
        $$body = $3;
        $$flg = 0;
        $opt = $4;
        while ($opt =~ /-(\w+)/g) {
            my $one = $1;
            if ($one eq "ctos_dont_touch") {
                if ($$flg & FLG_DONT_TOUCH) {
                    message("E207", $file, $line_num, "option [-$one] is set again");
                }
                $$flg |= FLG_DONT_TOUCH;
            }
            elsif ($one eq "only_def") {
                if ($$flg & FLG_PRT_ONLY) {
                    message("E207", $file, $line_num, "option [-$one] is set again");
                }
                $$flg |= FLG_ONLY_DEF;
            }
            elsif ($one eq "ctos_noninline") {
                if ($$flg & FLG_N_INLINE) {
                    message("E207", $file, $line_num, "option [-$one] is set again");
                }
                $$flg |= FLG_N_INLINE;
                $ctos_noninline++;
            }
            elsif ($one eq "slec_bbox") {
                if ($$flg & FLG_SLECBB) {
                    message("E207", $file, $line_num, "option [-$one] is set again");
                }
                $$flg |= FLG_SLECBB;
                $slec_bbox++;
            }
        }
        &check_format($$name, 0, $file, $line_num);
        if ($now_area != TB) {
            if (&name_exist(\@func_list, $$name) == 0
             && &name_exist_m(\@func_list_m, $$name) == 0) {
                &check_defined($$name, 1, $file, $line_num);
            }
        }
        else {
            if (&name_exist(\@func_list_tb, $$name) == 0) {
                &check_defined_tb($$name, 1, $file, $line_num);
            }
        }

        # format check for body
        if ($$body !~ /\)/) {
            message("E202", $file, $line_num, "\"func\" has invalid format");
        }

        # replace type of return
        $$ret =~ s/(^|\W)(uchar|ushort|uint)($|\W)/&arg_replace($1, $2, $3)/eg;
        $$ret =~ s/(^|\W)(var|uvar|svar)(\w+)/&arg_replace($1, $2, $3)/eg;

        # replace type of body
        $$body =~ s/(\W)(uchar|ushort|uint)(\W)/&arg_replace($1, $2, $3)/eg;
        $$body =~ s/(\W)(var|uvar|svar)(\w+)/&arg_replace($1, $2, $3)/eg;
    }
    else {
        message("E202", $file, $line_num, "\"func\" has invalid format");
    }
}

##
## get memory port suffix name
##  return : string
##   $mem  : memory array pointer
##   $type : memory port type
##
sub get_mem_suf {
    my ($mem, $type) = @_;
    my ($name, $suf);

    foreach $elm (@suf_list) {
        if (@$mem[M_SUF] eq @$elm[MP_FILE]) {
            $suf = $elm;
            last;
        }
    }

    $name = @$suf[$type];

    if ($name eq "") {
        $name = $suf_def[$type];
    }

    if ($type == MP1_WE || $type == MP2_WE || $type == MPA_WE || $type == MPB_WE) {
        $name = $name . "_n" if (@$mem[M_WE] == 2 && $tb_mode == 0);
    }

    if ($type == MP1_RE || $type == MP2_RE) {
        $name = $name . "_n" if (@$mem[M_RE] == 2);
    }

    if ($type == MP1_CS || $type == MP2_CS || $type == MPA_CS || $type == MPB_CS) {
        $name = $name . "_n" if (@$mem[M_CS] == 2 && $tb_mode == 0);
    }

    if ($type == MP2_BE) {
        $name = $name . "_n" if (@$mem[M_BE] == 2 && $tb_mode == 0);
    }
    return $name;
}

##
## get memory port name
##  return : string
##   $mem  : memory array pointer
##   $type : memory port type
##
sub get_mem_portnm {
    my ($mem, $type) = @_;
    my ($name, $suf);
    if ($type == MP1_RD || $type == MP2_RD || $type == MPA_RD || $type == MPB_RD) {
        $name = @$mem[M_IPRE];
    }
    else {
        $name = @$mem[M_OPRE];
    }
    $name = $name . @$mem[M_NAME];
    $name = $name . "_" . &get_mem_suf($mem, $type);
    return $name;
}

##
## get memory bind description for top
##  return : string
##   $mem  : memory array pointer
##   $type : memory port type
##   $bind : bind name
##
sub get_mem_topbind {
    my ($mem, $type, $name_bind, $prefix) = @_;
    $mem_nm = @$mem[M_NAME];
    $old_port = &get_mem_portnm(\@$mem, $type);
    @$mem[M_NAME] = $name_bind if ($name_bind ne "");
    if ($prefix ne "") {
        if ($type == MP1_RD || $type == MP2_RD || $type == MPA_RD || $type == MPB_RD) {
            $old_pfx = @$mem[M_IPRE];
            @$mem[M_IPRE] = $prefix;
        }
        else {
            $old_pfx = @$mem[M_OPRE];
            @$mem[M_OPRE] = $prefix;
        }
    }
    $new_port = &get_mem_portnm(\@$mem, $type);
    $bind = "$tab$tab$mod_inst.$old_port($new_port);";
    @$mem[M_NAME] = $mem_nm;
    if ($prefix ne "") {
        if ($type == MP1_RD || $type == MP2_RD || $type == MPA_RD || $type == MPB_RD) {
            @$mem[M_IPRE] = $old_pfx;
        }
        else {
            @$mem[M_OPRE] = $old_pfx;
        }
    }
    return $bind;
}

##
## get memory interface name
##  return : string
##   $mem  : memory array pointer
##
sub get_mem_ifnm {
    my ($mem) = @_;
    my $name;
    if (@$mem[M_OPRE] ne "") {
        $name = @$mem[M_OPRE];
    }
    else {
        $name = "";
    }
    $name = $name . @$mem[M_NAME] . "_if";
    return $name;
}

##
## insert macro data to the corresponding list
##   $kind  : kind string (data/func/free_area)
##   $data  : data array pointer
##
sub insert_macro_data {
    my ($kind, $data) = @_;
    my $ptr_list = 0;

    if ($kind eq "data") {
        $ptr_list = \@data_list_m;
    }
    elsif ($kind eq "func") {
        $ptr_list = \@func_list_m;
    }
    elsif ($kind eq "free_area") {
        $ptr_list = \@free_area_list_m;
    }

    $find = 0;
    foreach $elm (@$ptr_list) {
        if (@$elm[0] eq $now_macro) {
            push(@$elm, $data);
            $find = 1;
            last;
        }
    }

    if ($find == 0) {
        my @new_elm = ($now_macro, $data);
        push(@$ptr_list, \@new_elm);
    }
}

##
## read argument from command line
##   @argvs : all arguments
##
sub read_argv {
    my @argvs = @_;
    $usage = "Usage: ssgen.pl -in filename [options]\n" .
             "Options:\n" .
             "  -D<macro>[=<value>]      : Define <macro> as <value> (default is 1)\n" .
             "  -out <outdir>            : Specify the directory path where ssgen generates output files\n" .
             "                             If not specify, ssgen generates to current directory\n" .
             "  -include                 : Read optional file\n" .
             "  -subdir                  : Generate files into each sub directory according to the category\n" .
             "  -mem                     : Generate memory model\n" .
             "  -ctos                    : Generate CtoS script for synthesis\n" .
             "  -stratus                 : Generate Stratus script for synthesis\n" .
             "  -slec                    : Generate SLEC script for formal check\n" .
             "  -sta                     : Generate script for STACheck\n" .
             "  -osci                    : Generate Makefile for OSCI compile\n" .
             "  -vcs [memsize][osname]   : Generate script for VCS-MX simulation\n" .
             "                             Specify the memory size and OS name for bs command, if necessary\n" .
             "  -ies [memsize][osname]   : Generate script for IES simulation\n" .
             "                             Specify the memory size and OS name for bs command, if necessary\n" .
             "  -ifv [memsize][osname]   : Generate script for formal verification\n" .
             "                             Specify the memory size and OS name for bs command, if necessary\n" .
             "  -sim_eq [memsize][osname]: Generate script for sc-rtl simulation based equivalence checker\n" .
             "                             Specify the memory size and OS name for bs command, if necessary\n" .
             "  -sva                     : Generate sva module and binding file\n" .
             "  -checker                 : Generate script for 1Team:System and SSChecker\n" .
             "  -ins                     : Generate script for cpp2ins\n" .
             "  -only_script             : Generate only script for scripting options\n" .
             "                             Specify any one or more of them with this option\n" .
             "  -only_map                : Generate only map file for -vcs/-ies options\n" .
             "                             Specify any one or more of them with this option\n" .
             "  -notb                    : Not generate testbench file\n" .
             "  -standard                : Generate SystemC codes without ssgen extended feature\n";

    die $usage if (@argvs == 0);

    for ($i = 0; $i < @argvs; $i++) {
        $option = $argvs[$i];
        if ($option eq "-in") {
            if ($infile ne "") {
                die "\"-in\" option should be set only once\n";
            }
            if (($i+1 < @argvs) && ($argvs[$i+1] !~ /^-/)) {
                $i++;
                $infile = $argvs[$i];
            }
            else {
                die $usage;
            }
        }
        elsif ($option =~ /^-D(\w+)(=(\d+))?$/) {
            my $macro = $1;
            my $value = $3;
            $value = 1 if ($value eq "");
            @elm = ("", $macro, 0, $value);
            push(@define_in_list, [@elm]);
            push(@define_in_top_list, [@elm]);
        }
        elsif ($option eq "-out") {
            if (($i+1 < @argvs) && ($argvs[$i+1] !~ /^-/)) {
                $i++;
                $outdir = $argvs[$i];
                $outdir = $outdir . "/" if ($outdir !~ /\/$/);
                if (! -d $outdir) {
                    die "$outdir does not exist [-out]\n";
                }
            }
            else {
                die $usage;
            }
        }
        elsif ($option eq "-include") {
            if (($i+1 < @argvs) && ($argvs[$i+1] !~ /^-/)) {
                $i++;
                push(@incfile_list, $argvs[$i]);
            }
            else {
                die $usage;
            }
        }
        elsif ($option eq "-subdir") {
            $opt_subd = 1;
        }
        elsif ($option eq "-ins") {
            $opt_ins = 1;
        }
        elsif ($option eq "-mem") {
            $opt_mem = 1;
        }
        elsif ($option eq "-osci") {
            $opt_osci = 1;
        }
        elsif ($option eq "-vcs") {
            $opt_vcs = 1;
            for ($j = 0; ($i+1 < @argvs) && ($argvs[$i+1] !~ /^-/); $j++) {
                $i++;
                $bs_vcs_mem = $argvs[$i] if ($j == 0);
                $bs_vcs_os  = $argvs[$i] if ($j == 1);
            }
        }
        elsif ($option eq "-ies") {
            $opt_ies = 1;
            for ($j = 0; ($i+1 < @argvs) && ($argvs[$i+1] !~ /^-/); $j++) {
                $i++;
                $bs_ies_mem = $argvs[$i] if ($j == 0);
                $bs_ies_os  = $argvs[$i] if ($j == 1);
            }
        }
        elsif ($option eq "-ifv") {
            $opt_ifv = 1;
            for ($j = 0; ($i+1 < @argvs) && ($argvs[$i+1] !~ /^-/); $j++) {
                $i++;
                $bs_ifv_mem = $argvs[$i] if ($j == 0);
                $bs_ifv_os  = $argvs[$i] if ($j == 1);
            }
        }
        elsif ($option eq "-sva") {
            $opt_sva = 1;
        }
        elsif ($option eq "-ctos") {
            $opt_ctos = 1;
        }
        elsif ($option eq "-stratus") {
            $opt_stratus = 1;
        }
        elsif ($option eq "-slec") {
            $opt_slec = 1;
        }
        elsif ($option eq "-sta") {
            $opt_sta = 1;
        }
        elsif ($option eq "-checker") {
            $opt_chk = 1;
        }
        elsif ($option eq "-sim_eq") {
            $opt_sim_eq = 1;
            for ($j = 0; ($i+1 < @argvs) && ($argvs[$i+1] !~ /^-/); $j++) {
                $i++;
                $bs_sim_eq_mem = $argvs[$i] if ($j == 0);
                $bs_sim_eq_os  = $argvs[$i] if ($j == 1);
            }
        }
        elsif ($option eq "-only_script") {
            $opt_scr = 1;
        }
        elsif ($option eq "-only_map") {
            $opt_only_map = 1;
        }
        elsif ($option eq "-notb") {
            $opt_notb = 1;
        }
        elsif ($option eq "-standard") {
            $opt_standard = 1;
            $hier_max = "1000";
        }
        elsif ($option eq "-overwrite") {
            $opt_ow = 1;
        }
        elsif ($option eq "-cer") {
            $opt_cer = 1;
        }
        elsif ($option eq "-debug") {
            $debug_ssgen = 1;
        }
        else {
            die $usage;
        }
    }
    die $usage if ($infile eq "");
    die $usage if ($opt_scr &&
                    !($opt_osci    || $opt_vcs  || $opt_ies
                    || $opt_ifv    || $opt_ctos || $opt_stratus
                    || $opt_slec   || $opt_chk  || $opt_sta
                    || $opt_sim_eq || $opt_ins  || $opt_only_map));
    die $usage if ($opt_only_map && !($opt_vcs || $opt_ies));
}

##
## set style parameters
##   $words    : token array
##   $file     : file name
##   $line_num : line number
##   $level    : nest level
##
sub set_style_parameter {
    my ($words, $file, $line_num, $level) = @_;
    my $com = @$words[0];
    my $arg = @$words[1];
    if ($top_mode == 0) {
        &check_mod_order($com, 0, $file, $line_num, $level);
        #&check_inside_ifdef($com, $file, $line_num);
    }
    elsif ($top_mode == 1) {
        &check_top_order($com, 0, $file, $line_num, $level);
    }
    &check_scope($com, 0, $file, $line_num);

    if (@$words != 2) {
        message("E202", $file, $line_num, "\"$com\" has invalid format");
    }

    if ($com eq "style_module") {
        if ($style_module ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        if (lc $arg ne "sc" && lc $arg ne "c++") {
            message("E301", $file, $line_num,
                "set sc or c++ to style_module [$arg]");
        }
        $style_module = lc $arg;
    }
    elsif ($com eq "style_alloc") {
        if ($style_alloc ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        if (lc $arg ne "static" && lc $arg ne "dynamic") {
            message("E301", $file, $line_num,
                "set static or dynamic to $com [$arg]");
        }
        $style_alloc = lc $arg;
    }
    elsif ($com eq "space_indent") {
        if ($tab ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        if (!&is_number($arg) || $arg > 10 || $arg < 1) {
            message("E337", $file, $line_num,
                      "space of indent should be between 1 and 10");
        }
        for ($i = 0; $i < $arg; $i++) {
            $tab = $tab . " ";
        }
    }
    elsif ($com eq "mem_suffix") {
        if ($mem_suffix ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $mem_suffix = $nowdir . $arg;
        &read_suf_file($mem_suffix, 0);
    }
    elsif ($com eq "vcd_trace") {
        if ($vcd_trace ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        if (lc $arg ne "on" && lc $arg ne "off" && lc $arg ne "clk_off") {
            message("E301", $file, $line_num, "set on, off or clk_off to $com [$arg]");
        }
        $vcd_trace = lc $arg eq "on" ? 1 : ( lc $arg eq "clk_off" ? 2 : 0 );
    }
    elsif ($com eq "toggle_coverage") {
        if ($toggle_cov_mode ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        if (lc $arg ne "on" && lc $arg ne "off" && lc $arg ne "only_in" && lc $arg ne "only_out") {
            message("E301", $file, $line_num, "set on, off, only_in or only_out to $com [$arg]");
        }
        $toggle_cov_mode = lc $arg eq "off"     ? 0 :
                           lc $arg eq "on"      ? 1 :
                           lc $arg eq "only_in" ? 2 : 3;
    }
    elsif ($com eq "wait_expand") {
        if ($wait_expand ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        if (lc $arg ne "on" && lc $arg ne "off") {
            message("E301", $file, $line_num, "set on, off to $com [$arg]");
        }
        $wait_expand = lc $arg eq "off" ? 0 : 1;
    }
    elsif ($com eq "keep_ssgen_define") {
        if ($top_mode == 1) {
            if (lc $arg ne "on" && lc $arg ne "off") {
                message("E301", $file, $line_num, "set on, off to $com [$arg]");
            }
            if ($top_keep_ssgen_define ne "") {
                if (($arg eq "on" && $top_keep_ssgen_define == 0)
                    || ($arg eq "off" && $top_keep_ssgen_define == 1)) {
                    message("E101", $file, $line_num, "\"$com\" multiple settings");
                }
            }
            $top_keep_ssgen_define = lc $arg eq "off" ? 0 : 1;
        } else {
            if ($top_mode == 0) {
                if (lc $arg ne "on" && lc $arg ne "off") {
                    message("E301", $file, $line_num, "set on, off to $com [$arg]");
                }
                if ($keep_ssgen_define ne "") {
                    if (($arg eq "on" && $keep_ssgen_define == 0)
                        || ($arg eq "off" && $keep_ssgen_define == 1)) {
                        message("E101", $file, $line_num, "\"$com\" multiple settings");
                    }
                }
            }
            $keep_ssgen_define = lc $arg eq "off" ? 0 : 1;
        }
    }
}

##
## set enviroment parameters
##   $words    : token array
##   $file     : file name
##   $line_num : line number
##   $level    : nest level
##
sub set_env_parameter {
    my ($words, $file, $line_num, $level) = @_;
    my $com = @$words[0];
    my $arg = @$words[1];
    if ($com !~ /^env_(systemc|vcs|ies|ies_eq|jg_eq|vipcat|ctos|stratus|slec|vcs_gcc|ssgen|1team|sschecker|slec|overflow|cpp2ins)$/) {
        message("E201", $file, $line_num, "invalid command [$com]");
    }
    if ($top_mode == 0) {
        &check_mod_order($com, 0, $file, $line_num, $level);
        #&check_inside_ifdef($com, $file, $line_num);
    }
    else {
        &check_top_order($com, 0, $file, $line_num, $level);
    }
    &check_scope($com, 0, $file, $line_num);

    if (@$words != 2) {
        message("E202", $file, $line_num, "\"$com\" has invalid format");
    }

    if ($com eq "env_systemc") {
        if ($env_systemc ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $env_systemc = $arg;
    }
    elsif ($com eq "env_vcs") {
        if ($env_vcs ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $env_vcs = $arg;
    }
    elsif ($com eq "env_ies") {
        if ($env_ies ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $env_ies = $arg;
    }
    elsif ($com eq "env_ies_eq") {
        if ($env_ies_eq ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $env_ies_eq = $arg;
    }
    elsif ($com eq "env_jg_eq") {
        if ($env_jg_eq ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $env_jg_eq = $arg;
    }
    elsif ($com eq "env_vipcat") {
        if ($env_vipcat ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $env_vipcat = $arg;
    }
    elsif ($com eq "env_ctos") {
        if ($env_ctos ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $env_ctos = $arg;
    }
    elsif ($com eq "env_stratus") {
        if ($env_stratus ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $env_stratus = $arg;
    }
    elsif ($com eq "env_slec") {
        if ($env_slec ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $env_slec = $arg;
    }
    elsif ($com eq "env_vcs_gcc") {
        if ($env_vcs_gcc ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $env_vcs_gcc = $arg;
    }
    elsif ($com eq "env_ssgen") {
        if ($env_ssgen ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $env_ssgen = $arg;
    }
    elsif ($com eq "env_1team") {
        if ($env_1team ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $env_1team = $arg;
    }
    elsif ($com eq "env_sschecker") {
        if ($env_sschk ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $env_sschk = $arg;
    }
    elsif ($com eq "env_overflow") {
        if ($env_ovrflw ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $env_ovrflw = $arg;
    }
    elsif ($com eq "env_cpp2ins") {
        if ($env_cpp2ins ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $env_cpp2ins = $arg;
    }
    elsif ($com eq "env_slec") {
        if ($env_slec ne "") {
            message("E101", $file, $line_num, "\"$com\" multiple settings");
        }
        $env_slec = $arg;
    }
}

##
## set CtoS script parameters
##   $words    : token array
##   $file     : file name
##   $line_num : line number
##   $level    : nest level
##
sub set_ctos_parameter {
    my ($words, $file, $line_num, $level) = @_;
    my $com = @$words[0];
    my $arg = @$words[1];
    if ($com !~ /^ctos_(period|target_lib)$/) {
        message("E201", $file, $line_num, "invalid command [$com]");
    }
    if ($top_mode == 0) {
        &check_mod_order($com, 0, $file, $line_num, $level);
        #&check_inside_ifdef($com, $file, $line_num);
    }
    else {
        &check_top_order($com, 0, $file, $line_num, $level);
    }
    &check_scope($com, 0, $file, $line_num);

    if (@$words != 2) {
        message("E202", $file, $line_num, "\"$com\" has invalid format");
    }

    if ($com eq "ctos_period") {
        $ctos_period = $arg;
    }
    elsif ($com eq "ctos_target_lib") {
        $ctos_target_lib = $arg;
    }
}

##
## set Stratus script parameters
##   $words    : token array
##   $file     : file name
##   $line_num : line number
##   $level    : nest level
##
sub set_stratus_parameter {
    my ($words, $file, $line_num, $level) = @_;
    my $com = @$words[0];
    my $arg = @$words[1];
    if ($com !~ /^stratus_(period|target_lib)$/) {
        message("E201", $file, $line_num, "invalid command [$com]");
    }
    if ($top_mode == 0) {
        &check_mod_order($com, 0, $file, $line_num, $level);
        #&check_inside_ifdef($com, $file, $line_num);
    }
    else {
        &check_top_order($com, 0, $file, $line_num, $level);
    }
    &check_scope($com, 0, $file, $line_num);

    if (@$words != 2) {
        message("E202", $file, $line_num, "\"$com\" has invalid format");
    }

    if ($com eq "stratus_period") {
        $stratus_period = $arg;
    }
    elsif ($com eq "stratus_target_lib") {
        $stratus_target_lib = $arg;
    }
}

##
## set hdl_observer parameters
##   $line : command
##
sub set_hdl_observer_parameter {
    my $line     = $_[0];
    my $file     = $_[1];
    my $line_num = $_[2];

    if( $line =~ /(hdl_observer|sva_check)(\s+)(.+)/ ) {
        my $opt = $3;

        while ($opt =~ /-([^-]+)/g) {
            my $one = $1;
            $one =~ s/\s*$//;
            if($one eq "ies") {
                $hdl_ies_on = 1;
            } 
            elsif($one eq "vcs") {
                $hdl_vcs_on = 1;
            }
            elsif($one eq "debug_trace") {
                $hdl_debug_trace = 1;
            }
            elsif($one =~ /(.+)(\s+)(.+)/) {
                my $lhs = $1;
                my $rhs = $3;
                if($lhs eq "module") {
                    $hdl_module = $rhs;
                }
                elsif($lhs eq "prefix") {
                    $hdl_sig_prefix = $rhs;
                }
                else {
                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                }
            }
            else {
                message("E206", $file, $line_num, "option [-$one] is invalid");
            }
        }
    }
}

##
## previous parse (get primary settings)
##
sub pre_parse {
    my $line_num = 0;
    open (IN, "<$infile") || die "can't open input file [$infile]\n";

    while (<IN>) {
        $line_num++;
        $line = $_;
        &remove_rtn(\$line);
        &get_string(\$line);
        next if ($line eq "");
        @words = split /\s+/, $line;

        ## "top"
        if ($words[0] eq "top") {
            $top_mode = 1;
            $need_moddef = 1;
            if ($module_name ne "") {
                message("E101", $infile, $line_num, "\"$words[0]\" multiple settings");
            }
            if (@words != 2) {
                message("E202", $infile, $line_num, "\"$words[0]\" has invalid format");
            }
            &check_format($words[1], 1, $infile, $line_num);
            &check_defined($words[1], 1, $infile, $line_num);
            &check_defined_tb("tb_" . $words[1], 1, $infile, $line_num);

            $module_name = $words[1];
            $org_module_name = $module_name;
            $MODULE_NAME = uc $module_name;
        }
    }
    close(IN);

    # TB necessarily defines
    &check_defined_tb("thread_main", 1, "", 0);
}

##
## module parse (read module file)
##   $file     : file name
##   $level    : nest level
##   $line_num : line number
##
sub mod_parse {
    my $file  = $_[0];
    my $level = $_[1];
    my $line_num = 0;
    local(*IN);

    $free_area = 0;
    $ifdef[$level] = 0;
    $ifdef_ignore[$level] = 0;
    $ifdef_else[$level][$ifdef[$level]] = 0;
    $ifdef_inc[$level][$ifdef[$level]] = 0;
    $keep_ssgen_define = "" if ($level == 0 && $top_mode != 0);
    $struct_array = 0;
    @tmpl_inst_list = ();

    #my @struct =();
    open (IN, "<$file") || die "can't open input file [$file]\n";

    while (<IN>) {
        $line_num++;
        $line = $_;
        &remove_rtn(\$line);
        $line_org = $line;
        &get_string(\$line, \$comment);
        next if ($line eq "");
        @words = split /\s+/, $line;

        # get aigen signature
        if ($file =~ /^((.*\/)*)(\w+)_apb_def.in$/ && $comment eq "generated by aigen") {
            $use_aigen = 1;
            $mod_aigen = $3;
        }

        $t_flg = 0;
        # "const" check
        if ($words[0] eq "const" && ($top_mode != 2)) {
            $t_flg |= FLG_CONST;
            $line =~ s/const\s+//;
            @words = split /\s+/, $line;
            if (($words[0] !~ /^(uvar|svar)(\w+)$/)
             && ($words[0] !~ /^(char|uchar|short|ushort|int|uint)$/)) {
                message("E205", $file, $line_num, "const should not be set to \"$words[0]\"") if($free_area == 0);
            }
        }
        # "`ifdef"
        if ($words[0] eq "`ifdef") {
            if ($top_mode != 2) {
                &check_mod_order($words[0], 3, $file, $line_num, $level);
            }
            if ($now_area != COM) {
                message("E010", $file, $line_num, "not support nesting with \"#ifdef\"");
            }
            if (@words != 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            $ifdef[$level]++;
            $ifdef_inc[$level][$ifdef[$level]] = 0;
            if ($ifdef_ignore[$level] == 0) {
                if ($words[1] eq $tb_macro) {
                    $ifdef_ignore[$level] = 0;
                    $now_area = TB;
                }
                else {
                    $find = 0;
                    my $define_list = ($top_mode != 0) ? \@define_in_top_list : \@define_in_list;
                    foreach $elm (@$define_list) {
                        if($words[1] eq @$elm[G_NAME]) {
                            @$elm[G_FLAG] |= FLG_USED;
                            $ifdef_ignore[$level] = 0;
                            $ifdef_inc[$level][$ifdef[$level]] = 1;
                            $find = 1;
                        }
                    }
                    if ($find == 0) {
                        $ifdef_ignore[$level] = $ifdef[$level];
                    }
                }
            }
        }
        # "`ifndef"
        elsif ($words[0] eq "`ifndef") {
            if ($top_mode != 2) {
                &check_mod_order($words[0], 3, $file, $line_num, $level);
            }
            if ($now_area != COM) {
                message("E010", $file, $line_num, "not support nesting with \"$words[0]\" in $tb_macro macro");
            }
            if (@words != 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            $ifdef[$level]++;
            $ifdef_inc[$level][$ifdef[$level]] = 0;
            if ($ifdef_ignore[$level] == 0) {
                if ($words[1] eq $tb_macro) {
                    message("E025", $file, $line_num, "not support \"$tb_macro\" macro in \"$words[0]\" command");
                }
                else {
                    $find = 0;
                    my $define_list = ($top_mode != 0) ? \@define_in_top_list : \@define_in_list;
                    foreach $elm (@$define_list) {
                        if($words[1] eq @$elm[G_NAME]) {
                            @$elm[G_FLAG] |= FLG_USED;
                            $ifdef_ignore[$level] = $ifdef[$level];
                            $find = 1;
                        }
                    }
                    if ($find == 0) {
                        $ifdef_ignore[$level] = 0;
                        $ifdef_inc[$level][$ifdef[$level]] = 1;
                    }
                }
            }
        }
        # "`if"
        elsif ($words[0] eq "`if") {
            if ($top_mode != 2) {
                &check_mod_order($words[0], 3, $file, $line_num, $level);
            }
            if ($now_area != COM) {
                message("E010", $file, $line_num, "not support nesting with \"$words[0]\" in $tb_macro macro");
            }
            if (@words < 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            $ifdef[$level]++;
            $ifdef_inc[$level][$ifdef[$level]] = 0;
            if ($ifdef_ignore[$level] == 0) {
                my $define = $line;
                $define =~ s/^`if\s+//;
                while ($define =~ /(\bdefined((\s*\(\s*)|\s+)(\w+)(\s*\))?)/) {
                    my $tmp_define = $1;
                    my $macro      = $4;
                    if (($3 eq "" && $5 ne "") || ($3 ne "" && $5 eq "")) {
                        message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                    }
                    if ($macro eq $tb_macro) {
                        message("E025", $file, $line_num, "not support \"$tb_macro\" macro in \"$words[0]\" command");
                    }
                    $find = 0;
                    my $define_list = ($top_mode != 0) ? \@define_in_top_list : \@define_in_list;
                    foreach $elm (@$define_list) {
                        if($macro eq @$elm[G_NAME]) {
                            @$elm[G_FLAG] |= FLG_USED;
                            $find = 1;
                        }
                    }
                    if ($find == 1) {
                        $define =~ s/\Q$tmp_define\E/1/;
                    }
                    else {
                        $define =~ s/\Q$tmp_define\E/0/;
                    }
                }
                while ($define =~ /(\A|\W)([_a-zA-Z].\w*)(\W|\Z)/) {
                    my $macro = $2;
                    my $macro_value = &get_macro_value($macro, $file, $line_num, 1);
                    $define =~ s/\Q$macro\E/$macro_value/;
                }
                if (eval($define) == 0) {
                    $ifdef_ignore[$level] = $ifdef[$level];
                }
                else {
                    $ifdef_ignore[$level] = 0;
                    $ifdef_inc[$level][$ifdef[$level]] = 1;
                }
            }
        }
        # "`elif"
        elsif ($words[0] eq "`elif") {
            if ($top_mode != 2) {
                &check_mod_order($words[0], 3, $file, $line_num, $level);
            }
            if ($ifdef[$level] == 0) {
                message("E011", $file, $line_num, "\"$words[0]\" should be set after \"`ifdef/`if/`elif\"");
            }
            if ($ifdef_else[$level][$ifdef[$level]] == 1) {
                message("E011", $file, $line_num, "\"$words[0]\" should not be set after \"`else\"");
            }
            if ($now_area != COM) {
                message("E010", $file, $line_num, "not support nesting with \"$words[0]\" in $tb_macro macro");
            }
            if (@words < 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            if ($ifdef_ignore[$level] == $ifdef[$level] && $ifdef_inc[$level][$ifdef[$level]] == 0) {
                my $define = $line;
                $define =~ s/^`elif\s+//;
                while ($define =~ /(\bdefined((\s*\(\s*)|\s+)(\w+)(\s*\))?)/) {
                    my $tmp_define = $1;
                    my $macro      = $4;
                    if (($3 eq "" && $5 ne "") || ($3 ne "" && $5 eq "")) {
                        message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                    }
                    if ($macro eq $tb_macro) {
                        message("E025", $file, $line_num, "not support \"$tb_macro\" macro in \"$words[0]\" command");
                    }
                    $find = 0;
                    my $define_list = ($top_mode != 0) ? \@define_in_top_list : \@define_in_list;
                    foreach $elm (@$define_list) {
                        if($macro eq @$elm[G_NAME]) {
                            @$elm[G_FLAG] |= FLG_USED;
                            $find = 1;
                        }
                    }
                    if ($find == 1) {
                        $define =~ s/\Q$tmp_define\E/1/;
                    }
                    else {
                        $define =~ s/\Q$tmp_define\E/0/;
                    }
                }
                while ($define =~ /(\A|\W)([_a-zA-Z].\w*)(\W|\Z)/) {
                    my $macro = $2;
                    my $macro_value = &get_macro_value($macro, $file, $line_num, 1);
                    $define =~ s/\Q$macro\E/$macro_value/;
                }
                if (eval($define) == 0) {
                    $ifdef_ignore[$level] = $ifdef[$level];
                }
                else {
                    $ifdef_ignore[$level] = 0;
                    $ifdef_inc[$level][$ifdef[$level]] = 1;
                }
            }
            elsif ($ifdef_inc[$level][$ifdef[$level]] == 1) {
                $ifdef_ignore[$level] = $ifdef[$level];
            }
        }
        # "`else"
        elsif ($words[0] eq "`else") {
            if (@words != 1) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            if ($ifdef[$level] == 0) {
                message("E011", $file, $line_num, "\"$words[0]\" should be set after \"`ifdef/`if/`elif\"");
            }
            if ($ifdef_else[$level][$ifdef[$level]] == 1) {
                message("E024", $file, $line_num, "\"$words[0]\" is set multiple times");
            }
            $ifdef_else[$level][$ifdef[$level]] = 1;
            if ($ifdef_ignore[$level] == 0) {
                if ($now_area == TB) {
                    message("E112", $file, $line_num,
                        "\"$words[0]\" should not be set to \"`ifdef $tb_macro\"");
                }
                else {
                    $ifdef_ignore[$level] = $ifdef[$level];
                }
            }
            elsif($ifdef_ignore[$level] == $ifdef[$level] && $ifdef_inc[$level][$ifdef[$level]] == 0) {
                $ifdef_ignore[$level] = 0;
                $ifdef_inc[$level][$ifdef[$level]] = 1;
            }
        }
        # "`endif"
        elsif ($words[0] eq "`endif") {
            if (@words != 1) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            if ($ifdef[$level] == 0) {
                message("E011", $file, $line_num, "\"$words[0]\" should be set after \"`ifdef/`if/`elif\"");
            }
            $ifdef_ignore[$level] = 0 if ($ifdef_ignore[$level] == $ifdef[$level]);
            $ifdef_else[$level][$ifdef[$level]] = 0;
            $ifdef_inc[$level][$ifdef[$level]] = 0;
            $ifdef[$level]--;
            $now_area = COM;
        }
        # skip line
        elsif ($ifdef_ignore[$level] > 0) {
        }
        # free Area
        elsif ($words[0] eq "--!" && ($top_mode != 2)) {
            if ($free_area == 0) {
                message("E018", $file, $line_num,
                        "\"--!\" should be set after \"!--\"");
            }
            $free_area = 0;
        }
        elsif ($free_area == 1) {
            if ($is_struct_parsing == 1) {
                push(@free_area_list_struct, $line_org);
            } 
            elsif ($now_area == COM) {
                push(@free_area_list, $line_org);
            }
            elsif ($now_area == SIM) {
                &insert_macro_data("free_area", $line_org);
            }
            else {
                push(@free_area_list_tb, $line_org);
            }
        }
        elsif ($words[0] eq "!--" && $top_mode != 2) {
            &check_mod_order($words[0], 3, $file, $line_num, $level);
            if (@words > 1) {
                message("E017", $file, $line_num,
                        "\"!--\" should not be set with another word");
            }
            $free_area = 1;
        }
        # #ifdef
        elsif ($words[0] eq "#ifdef" && $top_mode != 2) {
            &check_mod_order($words[0], 3, $file, $line_num, $level);
            #if ($ifdef == 1) {
            #    message("E009", $file, $line_num, "not support nesting with \"`ifdef\"");
            #}
            if ($now_area != COM || $ifdef[$level] > 0) {
                message("E010", $file, $line_num, "not support nesting with \"#ifdef\"");
            }
            if (@words != 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            if ($words[1] eq $slecbb_macro) {
                $now_area = SLECBB;
            }
            else {
                $now_area = SIM;
                $now_macro = $words[1];
                if ($now_macro !~ /^_DEBUG/) {
                    message("E308", $file, $line_num, "please use only _DEBUG* or $slecbb_macro for #ifdef macro");
                }
                &check_format($words[1], 0, $file, $line_num);
            }
        }
        # #endif
        elsif ($words[0] eq "#endif" && $top_mode != 2) {
            if ($now_area == COM) {
                message("E014", $file, $line_num,
                        "\"#endif\" should be set after \"#ifdef\"");
            }
            if (@words != 1) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            $now_area = COM;
        }
        # "`define"
        elsif ($words[0] eq "`define") {
            if ($top_mode != 2) {
                &check_mod_order($words[0], 0, $file, $line_num, $level);
                &check_scope($words[0], 0, $file, $line_num);
                #&check_inside_ifdef($words[0], $file, $line_num);
                if (@words < 2) {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }
                &check_reserved($words[1], $file, $line_num);
            }
            my $substance = "";
            for(my $index = 2; $index < @words; $index++) {
                $substance = $substance . $words[$index];
            }

            @elm = ($comment, $words[1], 0, $substance, "", $substance);
            if ($keep_ssgen_define == 1) {
                $elm[G_FLAG] |= FLG_KEEP_STR;
                $elm[G_FILE] = $file;
            }
            my $define_list = ($top_mode != 0) ? \@define_in_top_list : \@define_in_list;
            if (&name_exist($define_list, $words[1], \$def) == 1) {
                if ($elm[G_SUBS] ne @$def[G_SUBS] && $top_mode != 1) {
                    if (@$def[G_FLAG] &  FLG_KEEP_STR) {
                        message("E302", $file, $line_num,
                            "macro \"$words[1]\" should not be redefined because is target of keep_ssgen_define");
                    }
                    elsif ($elm[G_FLAG] &  FLG_KEEP_STR) {
                        message("W006", $file, $line_num, "macro \"$words[1]\" is redefined and become target of keep_ssgen_define");
                    }
                    else {
                        message("W005", $file, $line_num, "macro \"$words[1]\" is redefined");
                    }
                }
                @$def[G_VALUE] = $substance;
                @$def[G_SUBS]  = $substance;
                if ($keep_ssgen_define == 1) {
                    @$def[G_FLAG] |= FLG_KEEP_STR;
                }
                elsif (@$def[G_FLAG] & FLG_KEEP_STR) {
                    @$def[G_FLAG] ^= FLG_KEEP_STR;
                }
                #@$def[G_VALUE] = &get_macro_value($words[1], $file, $line_num) if ($substance ne "");
            }
            else {
                #my $tmp = [@elm];
                #push(@$define_list, $tmp);
                #@$tmp[G_VALUE] = &get_macro_value($words[1], $file, $line_num) if ($substance ne "");
                push(@$define_list, [@elm]);
            }
        }
        # "`include"
        elsif ($words[0] eq "`include") {
            if ($top_mode != 2) {
                &check_mod_order($words[0], 0, $file, $line_num, $level);
                &check_scope($words[0], 0, $file, $line_num);
                #&check_inside_ifdef($words[0], $file, $line_num);
            }

            if (@words != 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            if ($level == 0) {
                my $inc_name = $words[1];
                my $orgdir  = $nowdir;
                if ($top_mode == 0) {
                    $inc_file = $nowdir . $inc_name;
                }
                else {
                    $inc_file = $nowdir . $mod_fpath . $inc_name;
                }
                $nowdir = &get_dir($inc_file);
                &mod_parse($inc_file, $level + 1); # recursive call
                $nowdir = $orgdir;

                # check scope
                if ($free_area == 1) {
                    message("E019", "$inc_name", 0, "\"--!\" should be set");
                }
                #elsif ($ifdef == 1) {
                #    message("E012", "$inc_name", 0, "\"`endif\" should be set");
                #}
                elsif ($now_area != COM) {
                    message("E015", "$inc_name", 0, "\"#endif\" should be set");
                }
            }
            else {
                message("E102", $file, $line_num,
                    "\"`include\": not support more than 1 level nesting");
            }
        }
        # #define
        elsif ($words[0] eq "#define" && ($top_mode != 2)) {
            &check_mod_order($words[0], 0, $file, $line_num, $level);
            &check_scope($words[0], 0, $file, $line_num);
            #&check_inside_ifdef($words[0], $file, $line_num);
            $words[1] =~ s/^(\w*).*$/$1/;
            if (@words == 1 || $words[1] eq "") {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            $line =~ s/#define\s+//;
            &sep_macro($line, \$name, \$body);
            &check_format($name, 1, $file, $line_num);
            my $exist = 0;
            my $ref_prepro_list = \@prepro_list;
            $ref_prepro_list = \@prepro_list_struct if ($is_struct_parsing) ;
            if ($top_mode == 1) {
                foreach $pre (@{$ref_prepro_list}) {
                    if (@$pre[G_FLAG] eq "#define") {
                        &sep_macro(@$pre[G_NAME], \$n, \$b);
                        if ($name eq $n) {
                            $exist = 1;
                            if ($body ne $b) {
                                message("E411", $file, $line_num,
                                    "macro \"$name\" defines the different contents in multiple modules");
                            }
                        }
                    }
                }
            }
            if ($exist == 0) {
                &check_defined($name, 1, $file, $line_num);
                &check_defined_tb($name, 1, $file, $line_num);
                @elm = ($comment, $line, "#define");
                push(@{$ref_prepro_list}, [@elm]);
            }
        }
        # #include
        elsif ($words[0] eq "#include" && $top_mode != 2) {
            if (@words != 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            if ($words[1] !~ /^\"/ && $words[1] !~ /^\</) {
                $words[1] = "\"" . $words[1] . "\"";
            }
            if ($now_area == TB) {
                my $exist = 0;
                foreach $pre (@prepro_list_tb) {
                    if (@$pre[G_FLAG] eq "#include" && @$pre[G_NAME] eq $words[1]) {
                        $exist = 1;
                        last;
                    }
                }
                if ($exist == 0) {
                    @elm = ($comment, $words[1], "#include");
                    push(@prepro_list_tb, [@elm]);
                }
            }
            else {
                &check_mod_order($words[0], 0, $file, $line_num, $level);
                &check_scope($words[0], 0, $file, $line_num);
                #&check_inside_ifdef($words[0], $file, $line_num);

                my $exist = 0;
                foreach $pre (@prepro_list) {
                    if (@$pre[G_FLAG] eq "#include" && @$pre[G_NAME] eq $words[1]) {
                        $exist = 1;
                        last;
                    }
                }
                if ($exist == 0) {
                    @elm = ($comment, $words[1], "#include");
                    push(@prepro_list, [@elm]);
                }
            }
        }
        # "changelog"
        elsif ($words[0] eq "changelog" && ($top_mode != 2)) {
            &check_mod_order($words[0], 0, $file, $line_num, $level);
            &check_scope($words[0], 0, $file, $line_num);
            #&check_inside_ifdef($words[0], $file, $line_num);
            if ($top_mode == 0) {
                if (@words == 1) {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }
                $line =~ s/changelog\s+//;
                if ($is_struct_parsing == 1) {
                    push(@changelog_list_struct, $line);
                } else {
                    push(@changelog_list, $line);
                }
            }
        }
        # "Ctype"
        elsif ($words[0] =~ /^(char|uchar|short|ushort|int|uint)$/ && ($top_mode != 2)) {
            if ($top_mode == 0) {
                &check_mod_order($words[0], 3, $file, $line_num, $level);
                if ($now_area == SLECBB) {
                    &check_scope($words[0], 0, $file, $line_num);
                }
                if (@words == 1) {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }
                my @elm = ();
                &get_attributes(\@elm, $line, $file, $line_num, $comment, $mod_inst, $words[0], "", $t_flg);
                $name = $elm[T_NAME];
                &check_format($name, 0, $file, $line_num);
                if ($is_struct_parsing == 1) {
                    if (&name_exist(\@struct_mem_list, $name) == 1) {
                        message("E601", $file, $line_num,
                            "\"$name\" has been already defined");
                    }
                    push(@struct_mem_list, [@elm]);
                }
                elsif ($now_area == COM) {
                    &check_defined($name, 1, $file, $line_num);
                    if ($elm[T_FLG] & FLG_VAR2REG) {
                        &check_defined("r_$name", 1, $file, $line_num);
                    }
                    push(@ctype_list, [@elm]);
                    if ($elm[T_FLG] & FLG_DTRACE) {
                        my @elm2 = @elm;
                        $elm2[T_NAME] = $elm2[T_NAME] . "_dbg";
                        $elm2[T_TYPE] = "ureg";
                        $elm2[T_WID]  = $elm[T_TYPE];
                        $elm2[T_FLG] &= ~FLG_VAR2REG;
                        &check_defined($elm2[T_NAME], 1, $file, $line_num);
                        &insert_macro_data("data", \@elm2);
                    }
                }
                elsif ($now_area == SIM) {
                    &check_defined($name, 1, $file, $line_num);
                    &insert_macro_data("data", \@elm);
                }
                else {
                    &check_defined_tb($name, 1, $file, $line_num);
                    push(@ctype_list_tb, [@elm]);
                }
            } elsif ($is_struct_parsing == 1) {
                my @elm = ();
                &get_attributes(\@elm, $line, $file, $line_num, $comment, $mod_inst, $words[0], "", $t_flg);
                push (@struct_mem_list, [@elm]);
            }
        }
        # "var"
        elsif ($words[0] =~ /^(uvar|svar)(\w+)$/ && ($top_mode != 2)) {
            if ($top_mode == 0) {
                &check_mod_order($words[0], 3, $file, $line_num, $level);
                if ($now_area == SLECBB) {
                    &check_scope($words[0], 0, $file, $line_num);
                }
                if (@words == 1) {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }
                $type = $1;
                $wid  = $2;
                &check_width(\$wid, $file, $line_num);
                my @elm = ();
                &get_attributes(\@elm, $line, $file, $line_num, $comment, $mod_inst, $type, $wid, $t_flg);
                $name = $elm[T_NAME];
                &check_format($name, 0, $file, $line_num);
                if ($is_struct_parsing == 1) {
                    if (&name_exist(\@struct_mem_list, $name) == 1) {
                        message("E601", $file, $line_num,
                            "\"$name\" has been already defined");
                    }
                    push (@struct_mem_list, [@elm]);
                }
                elsif ($now_area == COM) {
                    &check_defined($name, 1, $file, $line_num);
                    if ($elm[T_FLG] & FLG_VAR2REG) {
                        &check_defined("r_$name", 1, $file, $line_num);
                    }
                    push(@var_list, [@elm]);
                    if ($elm[T_FLG] & FLG_DTRACE) {
                        my @elm2 = @elm;
                        $elm2[T_NAME] = $elm2[T_NAME] . "_dbg";
                        $elm2[T_TYPE] =~ s/var/reg/;
                        $elm2[T_FLG] &= ~FLG_VAR2REG;
                        &check_defined($elm2[T_NAME], 1, $file, $line_num);
                        &insert_macro_data("data", \@elm2);
                    }
                }
                elsif ($now_area == SIM) {
                    &check_defined($name, 1, $file, $line_num);
                    &insert_macro_data("data", \@elm);
                }
                else {
                    &check_defined_tb($name, 1, $file, $line_num);
                    push(@var_list_tb, [@elm]);
                }
            } elsif ($is_struct_parsing == 1) {
                $type = $1;
                $wid  = $2;
                &check_width(\$wid, $file, $line_num);
                my @elm = ();
                &get_attributes(\@elm, $line, $file, $line_num, $comment, $mod_inst, $type, $wid, $t_flg);
                push (@struct_mem_list, [@elm]);
            }
        }
        # struct check
        elsif ($is_struct_parsing == 1) { #{
            if ($words[0] eq "}") {
                if ($top_mode == 0 && @struct_mem_list < 1) {
                    message("E703", $file, $line_num, "no member in \"$struct_name\" struct");
                }
                my @op_list = ();
                $line_tmp = $line;
                if ($line_tmp =~ /-op/ ) { #{
                    $line_tmp =~ s/\s*}\s*//g;
                    $line_tmp =~ s/-op\s*//g;
                    my @op = split /\s*,\s*/, $line_tmp;
                    &check_struct_operator($file, $line_num, $line_tmp);
                    for(my $idx = 0; $idx < @op; $idx++) {
                        # Check duplicate option here
                        if (&find_elm("$op[$idx]",\@op_list) == 1) {
                            message("E702", $file, $line_num, "operator [$op[$idx]] is set again");
                        }
                        $op[$idx] =~ s/\s+//g;
                        push(@op_list, $op[$idx]);
                    }
                }
                my @struct = ($comment, $struct_name, [@op_list], [@struct_mem_list],
                            [@free_area_list_struct], [@changelog_list_struct], [@prepro_list_struct], $struct_array);
                if ($top_mode == 0 || &name_exist(\@struct_list, $struct_name) == 0) {
                    push(@struct_list, [@struct]);
                }
                $is_struct_parsing = 0;
                @struct_mem_list = ();
                @free_area_list_struct = ();
                @changelog_list_struct = ();
                @prepro_list_struct = ();
                $struct_array = 0;
            }
            else {
                message("E204", $file, $line_num, "not support \"$words[0]\" in struct");
            }
        }
        # "struct"
        elsif ($words[0] eq "struct") {
            if (@words < 2 || @words > 3 || $line !~ /{$/) { #}
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            $words[1] =~ s/{$//; #}
            &check_format($words[1], 1, $file, $line_num);
            if ($top_mode == 0) {
                &check_defined($words[1], $file, $line_num);
            }
            $is_struct_parsing = 1;
            $struct_name  = $words[1];
        }
        # "func"
        elsif ($words[0] eq "func" && $top_mode != 2) {
            if ($top_mode == 0) {
                &check_mod_order($words[0], 3, $file, $line_num, $level);
                if ($now_area == SLECBB) {
                    &check_scope($words[0], 0, $file, $line_num);
                }
                &get_func_ret_body($line, $file, $line_num, \$name, \$ret, \$body, \$flg);

                my @elm = ($comment, $name, $ret, $body, $flg);
                if ($now_area == COM) {
                    push(@func_list, [@elm]);
                }
                elsif ($now_area == SIM) {
                    &insert_macro_data("func", \@elm);
                }
                else {
                    push(@func_list_tb, [@elm]);
                }
            }
        }
        # "in"
        elsif ($words[0] =~ /^(uin|sin)(\w+)$/ && $top_mode != 2) {
            &check_mod_order($words[0], 3, $file, $line_num, $level);
            if ($now_area != SLECBB) {
                &check_scope($words[0], 0, $file, $line_num);
            }
            if (@words == 1) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            $type = $1;
            $wid  = $2;
            &check_width(\$wid, $file, $line_num);

            my @elm;
            &get_attributes(\@elm, $line, $file, $line_num, $comment, $mod_inst, $type, $wid, $t_flg);
            $name = $elm[T_NAME];
            &check_format($name, 1, $file, $line_num);
            &check_defined($name, !$top_mode, $file, $line_num);
            &check_defined_tb($name, !$top_mode, $file, $line_num);
            my @dim = ();
            if ($elm[T_ARRAY] ne "") {
                my @id = ();
                while ($elm[T_ARRAY] =~ /\w+/g) {
                    push(@dim, $&);
                    push(@id, 0);
                }
                for ($i = 0; $i < @dim; $i++) {
                    $name_chk = $name_chk."_$id[$i]";
                    for ($id[$i] = 0; $id[$i] < $dim[$i]; $id[$i]++) {
                        if ($i == $#dim) {
                            my $name_chk = $name;
                            for ($j = 0; $j < $i ; $j++) {
                                $name_chk = $name_chk."_$id[$j]";
                            }
                            $name_chk = $name_chk."_$id[$i]";
                            &check_defined($name_chk, !$top_mode, $file, $line_num);
                            &check_defined_tb($name_chk, !$top_mode, $file, $line_num);
                        }
                    }
                }
            }
            if ($now_area == SLECBB) {
                push(@in_list_slecbb, [@elm]);
            }
            else {
                push(@in_list, [@elm]);
            }
        }
        # "out"
        elsif ($words[0] =~ /^(uout|sout)(\w+)$/ && $top_mode != 2) {
            &check_mod_order($words[0], 3, $file, $line_num, $level);
            if ($now_area != SLECBB) {
                &check_scope($words[0], 0, $file, $line_num);
            }
            if (@words == 1) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            if ($top_dbg ne "") {
                message("E114", $file, $line_num, "sub \"$sub_name\" in #ifdef must not have output port");
            }
            $type = $1;
            $wid  = $2;
            &check_width(\$wid, $file, $line_num);
            my @elm;
            &get_attributes(\@elm, $line, $file, $line_num, $comment, $mod_inst, $type, $wid, $t_flg);
            $name = $elm[T_NAME];
            &check_format($name, 1, $file, $line_num);
            &check_defined($name, !$top_mode, $file, $line_num);
            &check_defined_tb($name, !$top_mode, $file, $line_num);
            my @dim = ();
            if ($elm[T_ARRAY] ne "") {
                my @id = ();
                while ($elm[T_ARRAY] =~ /\w+/g) {
                    push(@dim, $&);
                    push(@id, 0);
                }
                for ($i = 0; $i < @dim; $i++) {
                    $name_chk = $name_chk."_$id[$i]";
                    for ($id[$i] = 0; $id[$i] < $dim[$i]; $id[$i]++) {
                        if ($i == $#dim) {
                            my $name_chk = $name;
                            for ($j = 0; $j < $i ; $j++) {
                                $name_chk = $name_chk."_$id[$j]";
                            }
                            $name_chk = $name_chk."_$id[$i]";
                            &check_defined($name_chk, !$top_mode, $file, $line_num);
                            &check_defined_tb($name_chk, !$top_mode, $file, $line_num);
                        }
                    }
                }
            }
            if ($now_area == SLECBB) {
                $elm[T_FLG] |= FLG_SLECBB;
                push(@out_list_slecbb, [@elm]);
            }
            else {
                if($top_mode == 1 && $sub_name eq "ctos_clock_gating") {
                    $elm[T_CTSCG] = 1;
                }
                push(@out_list, [@elm]);
                if (&is_struct($wid)) {
                    push(@out_list_struct, [@elm]);
                    &get_rtl_port(\@out_list_tb_rtl, \@elm);
                }
            }
        }
        # "reg"
        elsif ($words[0] =~ /^(ureg|sreg)(\w+)$/ && $top_mode != 2) {
            if ($top_mode == 0) {
                &check_mod_order($words[0], 3, $file, $line_num, $level);
                if ($now_area == SLECBB) {
                    &check_scope($words[0], 0, $file, $line_num);
                }
                if (@words == 1) {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }
                $type = $1;
                $wid  = $2;
                &check_width(\$wid, $file, $line_num);
                my @elm = ();
                &get_attributes(\@elm, $line, $file, $line_num, $comment, $mod_inst, $type, $wid, $t_flg);
                $name = $elm[T_NAME];
                &check_format($name, 0, $file, $line_num);
                if ($now_area == COM) {
                    &check_defined($name, 1, $file, $line_num);
                    push(@reg_list, [@elm]);
                    if (&is_struct($wid)) {
                        push(@reg_list_struct, [@elm]);
                        &get_rtl_port(\@reg_list_tb_rtl, \@elm);
                    }
                }
                elsif ($now_area == SIM) {
                    &check_defined($name, 1, $file, $line_num);
                    &insert_macro_data("data", \@elm);
                }
                else {
                    &check_defined_tb($name, 1, $file, $line_num);
                    push(@reg_list_tb, [@elm]);
                }
            }
        }
        # "ev"
        elsif ($words[0] =~ /^(uev|sev)(\w+)$/ && $top_mode != 2) {
            if ($top_mode == 0) {
                if ($opt_standard) {
                    $standard_ignore = 1;
                    next;
                }
                &check_mod_order($words[0], 3, $file, $line_num, $level);
                &check_scope($words[0], 0, $file, $line_num);
                if (@words == 1) {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }
                $type = $1;
                $wid  = $2;
                &check_width(\$wid, $file, $line_num);
                my @elm = ();
                &get_attributes(\@elm, $line, $file, $line_num, $comment, $mod_inst, $type, $wid, $t_flg);
                $name = $elm[T_NAME];
                &check_format($name, 0, $file, $line_num);
                &check_defined($name, 1, $file, $line_num);
                &check_defined("r_" . $name, 1, $file, $line_num);
                push(@ev_list, [@elm]);
            }
        }
        # "mem"
        elsif ($words[0] =~ /^(umem|smem)$/ && $top_mode != 2) {
            if ($opt_standard) {
                $standard_ignore = 1;
                next;
            }
            &check_mod_order($words[0], 3, $file, $line_num, $level);
            &check_scope($words[0], 0, $file, $line_num);
            if ($top_dbg ne "") {
                message("E114", $file, $line_num, "sub \"$sub_name\" in #ifdef must not have memory ports");
            }

            $sign = $words[0] eq "smem" ? 1 : 0;

            if ($line =~ /^\w+\s+(\w+)\s+(\w+)\s+(\S+)\s+(\S+)\s+(\w+)(.*)$/) {
                $wid      = $1;
                $size     = $2;
                $name     = $3;
                $rw       = $4;
                $lat      = $5;
                $opt      = $6;
                $prefix   = "";
                $iprefix  = "";
                $oprefix  = "";
                $ponly    = 0;
                $we       = 0;
                $re       = 0;
                $cs       = 0;
                $be       = 0;
                $th       = "";
                $init     = "";
                $suf_file = "";

                my $wid_t = $wid eq "b" ? 1 : &get_macro_value($wid, $file, $line_num);
                if ($wid_t < 2) {
                    message("E309", $file, $line_num,
                        "memory width should be more than 1");
                }
                $wid = $wid_t if (&is_keep_define($wid) == 0);

                my $size_t = &get_macro_value($size, $file, $line_num);
                if ($size_t < 2) {
                    message("E310", $file, $line_num,
                        "memory size should be more than 1");
                }
                $size = $size_t if (&is_keep_define($size) == 0);

                if ($rw =~ /^(rw|r|w|rw1|r1w1:r|r1w1:w|rw1:r|rw1:w|rw2:a|rw2:b)$/) {
                    if ($rw eq "rw1" || $rw eq "rw") {
                        $rw = MA_RW1;
                    }
                    elsif ($rw eq "r1w1:r" || $rw eq "r") {
                        $rw = MA_R1W1_R;
                    }
                    elsif ($rw eq "r1w1:w" || $rw eq "w") {
                        $rw = MA_R1W1_W;
                    }
                    elsif ($rw eq "rw1:r") {
                        $rw = MA_RW1_R;
                    }
                    elsif ($rw eq "rw1:w") {
                        $rw = MA_RW1_W;
                    }
                    elsif ($rw eq "rw2:a") {
                        $rw = MA_RW2_A;
                    }
                    elsif ($rw eq "rw2:b") {
                        $rw = MA_RW2_B;
                    }
                }
                else {
                    message("E311", $file, $line_num,
                        "memory type should be rw1|r1w1:r|r1w1:w|rw1:r|rw1:w|rw2:a|rw2:b");
                }

                my $lat_t = &get_macro_value($lat, $file, $line_num);
                if ($lat_t < 1 || $lat_t > 4) {
                    message("E313", $file, $line_num,
                        "memory latency should be between 1 and 4");
                }
                $lat = $lat_t if (&is_keep_define($lat) == 0);

                $opt =~ s/^\s*//;
                if ($opt ne "" && $opt !~ /^-/) {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }

                while ($opt =~ /-([^-]+)/g) {
                    my $elm = $1;
                    $elm =~ s/\s*$//;
                    my $lhs = $elm;
                    my $rhs = "";
                    if ($elm =~ /(.*?)(\s*=\s*|\s+)(.*)/) {
                        $lhs = $1;
                        $rhs = $3;
                    }

                    if ($lhs eq "prefix") {
                        if ($prefix ne "") {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($iprefix ne "" || $oprefix ne "") {
                            message("E208", $file, $line_num,
                                    "should not set prefix option and iprefix/oprefix at the same time");
                        }
                        if ($rhs eq "" || $rhs =~ /^(_|sc_|SC_|ssgen_|MEM_)/) {
                            message("E314", $file, $line_num, "memory prefix is invalid [$rhs]");
                        }
                        $prefix = $rhs;
                    }
                    elsif ($lhs eq "iprefix") {
                        if ($iprefix ne "") {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($prefix ne "") {
                            message("E208", $file, $line_num,
                                    "should not set prefix option and iprefix/oprefix at the same time");
                        }
                        if ($rhs eq "" || $rhs =~ /^(_|sc_|SC_|ssgen_|MEM_)/) {
                            message("E314", $file, $line_num, "memory prefix is invalid [$rhs]");
                        }
                        $iprefix = $rhs;
                    }
                    elsif ($lhs eq "oprefix") {
                        if ($oprefix ne "") {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($prefix ne "") {
                            message("E208", $file, $line_num,
                                    "should not set prefix option and iprefix/oprefix at the same time");
                        }
                        if ($rhs eq "" || $rhs =~ /^(_|sc_|SC_|ssgen_|MEM_)/) {
                            message("E314", $file, $line_num, "memory prefix is invalid [$rhs]");
                        }
                        $oprefix = $rhs;
                    }
                    elsif ($lhs eq "ponly") {
                        if ($rhs ne "") {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if ($ponly == 1) {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        $ponly = 1;
                    }
                    elsif ($lhs eq "we") {
                        if ($we != 0) {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($rw == MA_R1W1_R || $rw == MA_RW1_R) {
                            message("E312", $file, $line_num,
                                "\"-we\" should be set to memory type \"rw1|rw1:w|r1w1:w|rw2:a|rw2:b\"");
                        }
                        if ($rhs eq "high") {
                            $we = 1;
                        }
                        elsif ($rhs eq "low") {
                            $we = 2;
                        }
                        else {
                            message("E315", $file, $line_num,
                                "set high or low to active of memory enable");
                        }
                    }
                    elsif ($lhs eq "re") {
                        if ($rw != MA_R1W1_R && $rw != MA_RW1_R) {
                            message("E312", $file, $line_num,
                                "\"-re\" should be set to memory type \"rw1:r|r1w1:r\"");
                        }
                        if ($re != 0) {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($rhs eq "" || $rhs eq "high") {
                            $re = 1;
                        }
                        elsif ($rhs eq "low") {
                            $re = 2;
                        }
                        else {
                            message("E315", $file, $line_num,
                                "set high or low to active of memory enable");
                        }
                    }
                    elsif ($lhs eq "cs") {
                        if ($rw == MA_R1W1_R || $rw == MA_RW1_R || $rw == MA_RW1_W) {
                            message("E312", $file, $line_num,
                                "\"-cs\" should be set to memory type \"rw1|r1w1:w|rw2:a|rw2:b\"");
                        }
                        if ($cs != 0) {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($rhs eq "" || $rhs eq "high") {
                            $cs = 1;
                        }
                        elsif ($rhs eq "low") {
                            $cs = 2;
                        }
                        else {
                            message("E315", $file, $line_num,
                                "set high or low to active of memory enable");
                        }
                    }
                    elsif ($lhs eq "be") {
                        if ($rw != MA_R1W1_W || $cs == 0) {
                            message("E312", $file, $line_num,
                                "\"-be\" should be set to memory type \"r1w1:w\" along with \"-cs\"");
                        }
                        if ($be != 0) {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($rhs eq "" || $rhs eq "high") {
                            $be = 1;
                        }
                        elsif ($rhs eq "low") {
                            $be = 2;
                        }
                        else {
                            message("E315", $file, $line_num,
                                "set high or low to active of memory enable");
                        }
                    }
                    elsif ($lhs eq "clk") {
                        $mod_clknm = $rhs;
                    }
                    elsif ($lhs eq "th") {
                        if ($th ne "") {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($rhs eq "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $th = $rhs;
                    }
                    elsif ($lhs eq "init") {
                        if ($init ne "") {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($rhs eq "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $init = $rhs;
                    }
                    elsif ($lhs eq "suffix") {
                        if ($suf_file ne "") {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        $suf_file = $rhs;

                        if ($top_mode == 0) {
                            $suf_file = $nowdir . $suf_file;
                        }
                        else {
                            $suf_file = $nowdir . $mod_fpath . $suf_file;
                        }
                        &read_suf_file($suf_file, 1);
                    }
                    elsif ($lhs eq "header") {
                        if ($t_flg & FLG_HDR) {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($rhs ne "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $t_flg |= FLG_HDR;
                        $use_hdr = 1;
                    }
                    elsif ($lhs eq "nowd") {
                        if ($rw == MA_R1W1_R || $rw == MA_RW1_R || $rw == MA_RW1_W) {
                            message("E312", $file, $line_num,
                                "\"-nowd\" should be set to memory type \"rw1|r1w1:w|rw2:a|rw2:b\"");
                        }
                        if ($t_flg & FLG_NOWD) {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($rhs ne "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $t_flg |= FLG_NOWD;
                    }
                    elsif ($lhs eq "noad") {
                        if ($rw == MA_RW1_R || $rw == MA_RW1_W) {
                            message("E312", $file, $line_num,
                                "\"-noad\" should be set to memory type \"rw1|r1w1:r|r1w1:w|rw2:a|rw2:b\"");
                        }
                        if ($t_flg & FLG_NOAD) {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($rhs ne "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $t_flg |= FLG_NOAD;
                    }
                    else {
                        message("E206", $file, $line_num, "option [-$lhs] is invalid");
                    }
                }
                if ($prefix ne "") {
                    $iprefix = $prefix;
                    $oprefix = $prefix;
                }

                &check_format($iprefix . $name, 1, $file, $line_num);
                &check_format($oprefix . $name, 1, $file, $line_num);
                if ($top_mode == 0 && &name_exist(\@mem_list, $name) == 0) {
                    &check_defined($name, 1, $file, $line_num);
                    &check_defined_tb($name, 1, $file, $line_num);
                }
                @elm = ($comment, $name, $sign, $wid, $size, $rw, $lat,$iprefix, $oprefix,
                        $ponly, $we, $re, $cs, $be, $mod_clknm, $mod_clknm, $th, $init, $suf_file, $t_flg, $mod_inst, 0);
                push(@mem_list, [@elm]);
            }
            else {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
        }
        # style parameters
        elsif ($words[0] eq "keep_ssgen_define") {
            if ($top_mode == 0 || $top_keep_ssgen_define == 1) {
                $pre_top_mode = $top_mode;
                $top_mode = 2 if ($top_mode == 1);
                &set_style_parameter(\@words, $file, $line_num, $level);
                $top_mode = 1 if ($pre_top_mode == 1);
            }
        }
        elsif ( ($words[0] eq "style_module"
          || $words[0] eq "style_alloc"
          || $words[0] eq "space_indent"
          || $words[0] eq "mem_suffix"
          || $words[0] eq "toggle_coverage"
          #|| $words[0] eq "keep_ssgen_define"
          || $words[0] eq "wait_expand"
          || $words[0] eq "vcd_trace" ) && $top_mode != 2 ) {
            if ($top_mode == 0) {
                &set_style_parameter(\@words, $file, $line_num, $level);
            }
        }
        # "hdl_observer"
        elsif ( $words[0] eq "hdl_observer" || $words[0] eq "sva_check" ) {
            if ($top_mode == 0) {
                &set_hdl_observer_parameter($line, $file, $line_num);
            }
        }
        # "env_xxx"
        elsif ($words[0] =~ /^env_/ && $top_mode != 2) {
            if ($top_mode == 0) {
                &set_env_parameter(\@words, $file, $line_num, $level);
            }
        }
        # "ctos_xxx"
        elsif ($words[0] =~ /^ctos_/ && $top_mode != 2) {
            if ($top_mode == 0) {
                &set_ctos_parameter(\@words, $file, $line_num, $level);
            }
        }
        # "stratus_xxx"
        elsif ($words[0] =~ /^stratus_/ && $top_mode != 2) {
            if ($top_mode == 0) {
                &set_stratus_parameter(\@words, $file, $line_num, $level);
            }
        }
        # "clock"
        elsif ($words[0] eq "clock") {
            if ($top_mode != 2) {
                &check_mod_order($words[0], 2, $file, $line_num, $level);
                &check_scope($words[0], 0, $file, $line_num);
                #&check_inside_ifdef($words[0], $file, $line_num);
            }
            if (@words > 8) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            my $symbol = "";
            my $unit   = "SC_NS";
            my $period = "10";
            if ($line =~ /^(?:\w+\s+){2}(.*)$/) {
                $opt = $1;
                $opt =~ s/\s*$//;
                if ($opt ne "" && $opt !~ /^-/) {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }
                while ($opt =~ /-([^-]+)/g) {
                    my $one = $1;
                    $one =~ s/\s*$//;
                    if ($one =~ /^(symbol)(\s+)(.+)/) {
                        $symbol = $3;
                    }
                    elsif ($one =~ /^(time_unit)(\s+)(.+)/) {
                        $unit = "SC_". uc $3;
                    }
                    elsif ($one =~ /^(period)(\s+)(.+)/) {
                        $period = $3;
                    }
                    else {
                        message("E206", $file, $line_num, "option [-$one] is invalid");
                    }
                }
            }

            if ( $unit ne "SC_NS" && $unit ne "SC_PS" ) {
                message("E348", $file, $line_num, "specify \"ns\" or \"ps\" to -time_unit option");
            }

            &check_format($words[1], 1, $file, $line_num);
            @elm = ($comment, $words[1], $mod_inst, $words[0], "", "", "b", $words[1], $t_flg, "", "", "", $top_dbg, "", $symbol, "", $unit, $period);
            $mod_clknm = $words[1];
            &check_defined($words[1], !$top_mode, $file, $line_num);
            &check_defined_tb($words[1], !$top_mode, $file, $line_num);
            push(@clk_list, [@elm]);
        }
        # "areset" / "sreset"
        elsif ($words[0] =~ /^(areset|sreset)$/) {
            if ($top_mode != 2) {
                &check_mod_order($words[0], 3, $file, $line_num, $level);
                &check_scope($words[0], 0, $file, $line_num);
            }
            if ( !(@words == 3 || @words == 4) ) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            if ($words[2] ne "pos" && $words[2] ne "neg") {
                message("E303", $file, $line_num, "edge type should be \"pos\" or \"neg\"");
            }
            if ($words[3]) {
                if ($words[3] eq "-partial_rst") {
                    $t_flg = $t_flg | FLG_PART_RST;
                } else {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }
            }
            &check_format($words[1], 1, $file, $line_num);
            @elm = ($comment, $words[1], $mod_inst, $words[0], $words[2], "", "b", $words[1], $t_flg, "", "", "", $top_dbg);
            &check_defined($words[1], !$top_mode, $file, $line_num);
            &check_defined_tb($words[1], !$top_mode, $file, $line_num);
            push(@rst_list, [@elm]);
        }
        # "soft_reset"
        elsif ($words[0] eq "soft_reset" && $top_mode != 2) {
            if ($top_mode == 0) {
                &check_mod_order($words[0], 3, $file, $line_num, $level);
                &check_scope($words[0], 0, $file, $line_num);
                if (@words < 3) {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }
                if ($words[2] ne "pos" && $words[2] ne "neg") {
                    message("E303", $file, $line_num, "edge type should be \"pos\" or \"neg\"");
                }
                if ($line =~ /^(?:\w+\s+){3}(.*)$/) {
                    $opt = $1;
                    $opt =~ s/\s*$//;

                    if ($opt ne "" && $opt !~ /^-/) {
                        message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                    }

                    while ($opt =~ /-([^-]+)/g) {
                        my $one = $1;
                        $one =~ s/\s*$//;
                        my $lhs = $one;
                        my $rhs = "";
                        if ($one =~ /(.*?)(\s*=\s*|\s+)(.*)/) {
                            $lhs = $1;
                            $rhs = $3;
                        }

                        if ($lhs eq "header") {
                            if ($t_flg & FLG_HDR) {
                                message("E207", $file, $line_num, "option [-$lhs] is set again");
                            }
                            if ($rhs ne "") {
                                message("E206", $file, $line_num, "option [-$lhs] is invalid");
                            }
                            $t_flg |= FLG_HDR;
                            $use_hdr = 1;
                        }
                        else {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                    }
                }
                &check_format($words[1], 0, $file, $line_num);
                @elm = ($comment, $words[1], $mod_inst, $words[0], $words[2], "", "b", $words[1], $t_flg, "", "", "", $top_dbg);
                &check_defined($words[1], 1, $file, $line_num);
                push(@rst_list, [@elm]);
            }
        }
        # "cthread"
        elsif ($words[0] eq "cthread" && $top_mode != 2) {
            &check_mod_order($words[0], 3, $file, $line_num, $level);
            &check_scope($words[0], 0, $file, $line_num);
            #&check_inside_ifdef($words[0], $file, $line_num);

            if ($top_mode == 0) {
                if (@words == 1) {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }
                #if ($level != 0) {
                #    message("E103", $file, $line_num, "\"$words[0]\" should not be set in include file");
                #}

                $clk  = "";
                $edge = "";
                $lat  = 3;
                $macro = "CtoS_MAIN_LOOP";
                @th_rst = ();
                if ($line =~ /^\w+\s+\w+\s+(.*)$/) {
                    $opt = $1;
                    $opt =~ s/\s*$//;

                    if ($opt ne "" && $opt !~ /^-/) {
                        message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                    }

                    while ($opt =~ /-([^-]+)/g) {
                        my $one = $1;
                        $one =~ s/\s*$//;
                        my $lhs = $one;
                        my $rhs = "";
                        if ($one =~ /(.*?)(\s*=\s*|\s+)(.*)/) {
                            $lhs = $1;
                            $rhs = $3;
                        }

                        if ($lhs eq "clk") {
                            if ($clk ne "") {
                                message("E207", $file, $line_num, "option [-$lhs] is set again");
                            }
                            if ($rhs eq "") {
                                message("E206", $file, $line_num, "option [-$lhs] is invalid");
                            }
                            $clk = $rhs;
                            if (&name_exist(\@clk_list, $clk) == 0) {
                                message("E326", $file, $line_num, "clock \"$clk\" does not exist");
                            }

                        }
                        elsif ($lhs eq "clk_edge") {
                            if ($edge ne "") {
                                message("E207", $file, $line_num, "option [-$lhs] is set again");
                            }
                            if ($rhs ne "pos" && $rhs ne "neg") {
                                message("E206", $file, $line_num, "option [-$lhs] is invalid");
                            }
                            $edge = $rhs;
                        }
                        elsif ($lhs eq "rst") {
                            if (@th_rst != 0) {
                                message("E207", $file, $line_num, "option [-$lhs] is set again");
                            }
                            if ($rhs eq "") {
                                message("E206", $file, $line_num, "option [-$lhs] is invalid");
                            }
                            @th_rst = split /\s+/, $rhs;
                        }
                        elsif ($lhs eq "pipe") {
                            if ($t_flg & FLG_PIPE) {
                                message("E207", $file, $line_num, "option [-$lhs] is set again");
                            }
                            if ($rhs ne "") {
                                message("E206", $file, $line_num, "option [-$lhs] is invalid");
                            }
                            $t_flg |= FLG_PIPE;
                            $use_pipe = 1;
                        }
                        elsif ($lhs eq "pipe_macro") {
                            if ($rhs eq "") {
                                message("E206", $file, $line_num, "option [-$lhs] is invalid");
                            }
                            $macro = $rhs;
                        }
                        elsif ($lhs eq "pipe_max") {
                            if ($rhs ne "") {
                                if (&is_number($rhs) && $rhs > 1) {
                                    $lat = $rhs;
                                }
                                else{
                                    message("E206", $file, $line_num, "option [-$lhs] is invalid");
                                }
                            }
                            else{
                                message("E206", $file, $line_num, "option [-$lhs] is invalid");
                            }
                        }
                        elsif ($lhs eq "reset_header") {
                            if ($t_flg & FLG_HDR_RST) {
                                message("E207", $file, $line_num, "option [-$lhs] is set again");
                            }
                            if ($rhs ne "") {
                                message("E206", $file, $line_num, "option [-$lhs] is invalid");
                            }
                            $t_flg |= FLG_HDR_RST;
                            $use_hdr = 1;
                        }
                        elsif ($lhs eq "wait_header") {
                            if ($t_flg & FLG_HDR_WAIT) {
                                message("E207", $file, $line_num, "option [-$lhs] is set again");
                            }
                            if ($rhs ne "") {
                                message("E206", $file, $line_num, "option [-$lhs] is invalid");
                            }
                            $t_flg |= FLG_HDR_WAIT;
                            $use_hdr = 1;
                        }
                        elsif ($lhs eq "dummy") {
                            if ($t_flg & FLG_DUMMY) {
                                message("E207", $file, $line_num, "option [-$lhs] is set again");
                            }
                            if ($rhs ne "") {
                                message("E206", $file, $line_num, "option [-$lhs] is invalid");
                            }
                            $t_flg |= FLG_DUMMY;
                        }
                        elsif ($lhs eq "wait_expand") {
                            if ($t_flg & FLG_WAIT_EXP) {
                                message("E207", $file, $line_num, "option [-$lhs] is set again");
                            }
                            if ($rhs ne "") {
                                message("E206", $file, $line_num, "option [-$lhs] is invalid");
                            }
                            $t_flg |= FLG_WAIT_EXP;
                        }
                        elsif ($lhs eq "wait_noninline") {
                            if ($t_flg & FLG_N_INLINE) {
                                message("E207", $file, $line_num, "option [-$lhs] is set again");
                            }
                            if ($rhs ne "") {
                                message("E206", $file, $line_num, "option [-$lhs] is invalid");
                            }
                            $t_flg |= FLG_N_INLINE;
                            $ctos_noninline++;
                        }
                        else {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                    }
                }

                &check_format($words[1], 0, $file, $line_num);
                &check_defined($words[1], 1, $file, $line_num);
                @elm = ($comment, $words[1], $t_flg, $clk, $edge, $lat, $macro);

                if (!($t_flg & FLG_DUMMY)) {
                    $use_valid_thread = 1;
                }

                $no_rst_flg = 0;
                my %used_map = ();
                foreach $name (@th_rst) {
                    if (exists $used_map{$name}) {
                        message("E328", $file, $line_num,
                            "\"$name\" is set to reset list again");
                    }
                    if (lc $name eq "n") {
                        $no_rst_flg = 1;
                    }
                    push(@elm, $name);
                    $used_map{$name} = 0;
                }
                if ($no_rst_flg == 1 && @th_rst > 1) {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }
                push(@thread_list, [@elm]);
            }
        }
        # "method"
        elsif ($words[0] eq "method" && $top_mode != 2) {
            if ($top_mode == 0) {
                &check_mod_order($words[0], 3, $file, $line_num, $level);
                &check_scope($words[0], 0, $file, $line_num);
                if (@words < 3) {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }
                &check_format($words[1], 0, $file, $line_num);
                &check_defined($words[1], 1, $file, $line_num);

                @elm = ($comment, $words[1], 0);
                shift(@words);
                shift(@words);
                my %used_map = ();
                foreach $item (@words) {
                    if ($item =~ /^([\w\*]+)(.*)/) {
                        $pattern = $1;
                        $orgin = $1;
                        $suffix = $2;
                        $pattern =~ s/\*/(\\w)\*/g;
                        $find = 0;
                        foreach $elm (@clk_list, @rst_list, @in_list, @out_list, @ev_list, @reg_list) {
                            if (@$elm[T_NAME] =~ /\b$pattern\b/) {
                                if (($suffix =~ /^(\[.*\])+/) && (@$elm[T_ARRAY] eq "")) {
                                    next;
                                }
                                $name = @$elm[T_NAME];
                                if (exists $used_map{$name}) {
                                    message("E317", $file, $line_num,
                                        "\"$name\" is set to sensitivity list again");
                                }
                                if ($suffix eq "") {
                                    $used_map{$name} = 0;
                                }
                                if (@$elm[T_TYPE] =~ /ev$/) {
                                    $name = "r_" . $name;
                                }
                                if ((@$elm[T_ARRAY] ne "") && ($suffix !~ /^(\[.*\])+/)) {
                                    my @dim = ();
                                    my $a_item = "";

                                    while (@$elm[T_ARRAY] =~ /\w+/g) {
                                        &get_array_info(\@dim, $&);
                                    }

                                    for ($i = 0; $i < $dim[0]; $i++) {
                                        if (@dim == 1) {
                                            $a_item = $name . "[$i]";
                                            push(@elm, $a_item);
                                        }
                                        else {
                                            for ($j = 0; $j < $dim[1]; $j++) {
                                                if (@dim == 2) {
                                                    $a_item = $name . "[$i][$j]";
                                                    push(@elm, $a_item);
                                                }
                                                else {
                                                    for ($k = 0; $k < $dim[2]; $k++) {
                                                        $a_item = $name . "[$i][$j][$k]";
                                                        push(@elm, $a_item);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else {
                                    push(@elm, "$name$suffix");
                                }
                                $find = 1;
                            }
                        }
                        if ($find == 0) {
                            message("E316", $file, $line_num,
                                "\"$orgin\" should be defined as port/signal above this line");
                        }
                        if ($suffix eq ".pos()" || $suffix eq ".neg()") {
                            message("E318", $file, $line_num,
                                    "not support edge trigger SC_METHOD [\"$item\"]");
                        }
                        #if ($suffix !~ /^(\[.*\])+/) {
                        #    message("E206", $file, $line_num, "option [$item] is invalid");
                        #}
                    }
                    elsif ($item =~ /^(\w+)(.*)/) {
                        $name = $1;
                        $suffix = $2;
                        $hit = [];
                        if (&name_exist(\@clk_list, $name, \$hit) == 0
                                && &name_exist(\@rst_list, $name, \$hit) == 0
                                && &name_exist(\@in_list,  $name, \$hit) == 0
                                && &name_exist(\@out_list, $name, \$hit) == 0
                                && &name_exist(\@ev_list,  $name, \$hit) == 0
                                && &name_exist(\@reg_list, $name, \$hit) == 0 ) {
                            message("E316", $file, $line_num,
                                    "\"$name\" should be defined as port/signal above this line");
                        }
                        if (exists $used_map{$name}) {
                            message("E317", $file, $line_num,
                                    "\"$name\" is set to sensitivity list again");
                        }
                        if ($suffix eq ".pos()" || $suffix eq ".neg()") {
                            message("E318", $file, $line_num,
                                    "not support edge trigger SC_METHOD [\"$item\"]");
                        }
                        #if ($suffix !~ /^(\[.*\])+/) {
                        #    message("E206", $file, $line_num, "option [$item] is invalid");
                        #}
                        if ($item eq $name) {
                            $used_map{$name} = 0;
                        }

                        if (@$hit[T_TYPE] =~ /ev$/) {
                            $item = "r_" . $item;
                        }

                        if ((@$hit[T_ARRAY] ne "") && ($suffix !~ /^(\[.*\])+/)) {
                            my @dim = ();
                            my $a_item = "";

                            while (@$hit[T_ARRAY] =~ /\w+/g) {
                                &get_array_info(\@dim, $&);
                            }

                            for ($i = 0; $i < $dim[0]; $i++) {
                                if (@dim == 1) {
                                    $a_item = $item . "[$i]";
                                    push(@elm, $a_item);
                                }
                                else {
                                    for ($j = 0; $j < $dim[1]; $j++) {
                                        if (@dim == 2) {
                                            $a_item = $item . "[$i][$j]";
                                            push(@elm, $a_item);
                                        }
                                        else {
                                            for ($k = 0; $k < $dim[2]; $k++) {
                                                $a_item = $item . "[$i][$j][$k]";
                                                push(@elm, $a_item);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else {
                            push(@elm, $item);
                        }
                    }
                    elsif ($item =~ /^-only_def$/) {
                        if ($elm[TH_FLG] & FLG_ONLY_DEF) {
                            message("E207", $file, $line_num, "option [$item] is set again");
                        }
                        $elm[TH_FLG] |= FLG_ONLY_DEF;
                    }
                    else {
                        message("E206", $file, $line_num, "option [$item] is invalid");
                    }
                }
                push(@method_list, [@elm]);
            }
        }
        # "template"
        elsif ($words[0] eq "template") {
            &check_mod_order($words[0], 0, $file, $line_num, $level) if ($top_mode != 2);
            &check_scope($words[0], 0, $file, $line_num);
            if ($line =~ /^template\s+\<([^<>]*)\>$/) {
                my @tmpl_list = split(/,/, $1);
                foreach my $arg (@tmpl_list) {
                    $arg =~ s/(^\s+|\s+$)//g;
                    if ($arg =~ /^(\w+)\s+(\w+)\s*=\s*(\w+)$/) {
                        my $t_type = $1;
                        my $t_name = $2;
                        my $t_subs = $3;
                        if (&name_exist(\@define_in_list, $t_name)) {
                            message("E108", $file, $line_num, "\"$t_name\" is already defined by \"`define\" command");
                        }
                        foreach $pre (@prepro_list) {
                            if (@$pre[G_FLAG] eq "#define") {
                                &sep_macro(@$pre[G_NAME], \$n, \$b);
                                if ($t_name eq $n) {
                                    message("E108", $file, $line_num, "\"$t_name\" is already defined by \"#define\" command");
                                }
                            }
                        }
                        if ($top_mode == 0 && &name_exist(\@template_list, $t_name)) {
                            message("E207", $file, $line_num, "\"$t_name\" is set again");
                        }
                        if ($t_type ne "typename" && $t_type ne "int") {
                            message("E801", $file, $line_num, "only support \"typename|int\" in template");
                        }
                        if ($t_type eq "typename" && $t_subs !~ /^(u|s)var(b|\d+)$/) {
                            message("E802", $file, $line_num, "only support \"{u|s}varN\" for \"typename\" in template");
                        }
                        my $t_wid = $2;
                        if ($t_type eq "int" && &is_number($t_subs) == 0) {
                            message("E803", $file, $line_num, "only support constant number for \"int\" in template");
                        }
                        my $t_val = ($t_type eq "int") ? $t_subs : 0;
                        if ($t_type eq "typename") {
                            $t_subs = ($t_wid eq "b") ? "bool" : &get_sctype(($t_subs =~ /^u/) ? 0 : 1, $t_wid);
                        }
                        my @tmpl = ($com, $t_name, 0, $t_val, $file, $t_subs, "", $t_type);
                        push(@template_list, [@tmpl]);
                    }
                    else {
                        message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                    }
                }
            }
            else {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            $use_template = 1;
        }
        # "module"
        elsif ($words[0] eq "module") {
            if ($top_mode != 2) {
                &check_mod_order($words[0], 1, $file, $line_num, $level);
                &check_scope($words[0], 0, $file, $line_num);
                #&check_inside_ifdef($words[0], $file, $line_num);
            }
            if (@words < 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }

            &check_format($words[1], 1, $file, $line_num);
            if ($top_mode == 0) {
                if ($level != 0) {
                    message("E103", $file, $line_num, "\"$words[0]\" should not be set in include file");
                }
                if ($module_name ne "") {
                    message("E101", $file, $line_num, "\"$words[0]\" multiple settings");
                }
                $module_name = $words[1];
                $org_module_name = $module_name;
                $MODULE_NAME = uc $module_name;
                &check_defined($words[1], 1, $file, $line_num);
                &check_defined_tb("tb_" . $words[1], 1, $file, $line_num);
            }
            else {
                if ($top_mode == 1 && $sub_name ne "") {
                    message("E101", $file, $line_num, "\"$words[0]\" multiple settings");
                }
                &check_format($words[1], 1, $file, $line_num);
                $sub_name = $words[1];
            }
            @mod_tmpl_list = ();
            foreach my $tmpl (@template_list) {
                if (@$tmpl[G_INST] eq "") {
                    @$tmpl[G_INST] = ($top_mode == 0) ? $module_name : $sub_name;
                    push(@mod_tmpl_list, $tmpl);
                }
            }

            if ($line =~ /^\w+\s+\w+\s+(.*)$/) {
                $opt = $1;
                $opt =~ s/\s*$//;

                if ($opt ne "" && $opt !~ /^-/) {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }

                while ($opt =~ /-([^-]+)/g) {
                    my $one = $1;
                    $one =~ s/\s*$//;
                    my $lhs = $one;
                    my $rhs = "";
                    if ($one =~ /(\w+)(\s+)(.*)/) {
                        $lhs = $1;
                        $rhs = $3;
                    }

                    if ($lhs eq "template_inst") {
                        if ($use_template == 0) {
                            message("E805", $file, $line_num, "\"" . 
                                (($top_mode == 0) ? $module_name : $sub_name) . "\" is not a template");
                        }
                        if ($rhs =~ /^(\w+)\<([^<>]*)\>$/) {
                            my @tmpl_list = ();
                            my $tmpl_inst = $1;
                            my @arg_list = split(/\s*,\s*/, $2); 
                            if (&name_exist(\@tmpl_inst_list, $tmpl_inst)) {
                                message("E601", $file, $line_num,
                                    "\"$tmpl_inst\" has been already defined");
                            }
                            if (@arg_list > @mod_tmpl_list) {
                                message("E804", $file, $line_num, "wrong number of template arguments");
                            }
                            for (my $i=0; $i<@arg_list; $i++) {
                                my $t_type = ${$mod_tmpl_list[$i]}[G_TYPE];
                                my $t_name = ${$mod_tmpl_list[$i]}[G_NAME];
                                my $t_subs = $arg_list[$i];
                                if ($t_subs ne "") {
                                    if ($t_type eq "typename" && $t_subs !~ /^(u|s)var(b|\d+)$/) {
                                        message("E802", $file, $line_num, "only support \"{u|s}varN\" for \"typename\" in template");
                                    }
                                    my $t_wid = $2;
                                    if ($t_type eq "int" && &is_number($t_subs) == 0) {
                                        message("E803", $file, $line_num, "only support constant number for \"int\" in template");
                                    }
                                    if ($t_type eq "typename") {
                                        $t_subs = ($t_wid eq "b") ? "bool" : &get_sctype(($t_subs =~ /^u/) ? 0 : 1, $t_wid);
                                    }
                                }
                                else {
                                    $t_subs = ${$mod_tmpl_list[$i]}[G_SUBS];
                                }
                                my @tmpl = ($t_name, $t_subs);
                                push(@tmpl_list, [@tmpl]);
                            }
                            if (@tmpl_list < @mod_tmpl_list) {
                                for (my $i=@tmpl_list; $i<@mod_tmpl_list; $i++) {
                                    my $t_name = ${$mod_tmpl_list[$i]}[G_NAME];
                                    my $t_subs = ${$mod_tmpl_list[$i]}[G_SUBS];
                                    my @tmpl = ($t_name, $t_subs);
                                    push(@tmpl_list, [@tmpl]);
                                }
                            }
                            my @tmpl_data = ("", $tmpl_inst, 0, $module_name, "", "", $top_dbg, \@tmpl_list, "");
                            push(@tmpl_inst_list, [@tmpl_data]);
                        }
                        else {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                    }
                    else {
                        message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                    }
                }
            }
            if ($use_template == 1) {
                if (@tmpl_inst_list == 0) {
                    my @tmpl_list = ();
                    foreach my $tmpl (@mod_tmpl_list) {
                        my $t_name = @$tmpl[G_NAME];
                        my $t_subs = @$tmpl[G_SUBS];
                        push(@tmpl_list, [$t_name, $t_subs]);
                    }
                    my @tmpl_data = ("", "${module_name}0", 0, $module_name, "", "", $top_dbg, \@tmpl_list, "");
                    push(@tmpl_inst_list, [@tmpl_data]);
                }
            }
        }
        elsif (@words > 0 && $top_mode != 2) {
            if ($level == 0) {
                message("E201", $file, $line_num, "invalid command [$words[0]]");
            }
            else {
                message("I005", $file, $line_num, "skip invalid command [$words[0]]");
            }
        }
    }
    close(IN);

    if ($free_area == 1) {
        message("E019", $file, 0, "\"--!\" should be set");
    }
    elsif ($ifdef[$level] > 0) {
        message("E012", $file, 0, "\"`endif\" should be set");
    }
    if ($level != 0 && $keep_ssgen_define == 1) {
        $find = 0;
        my $define_list = ($top_mode != 0) ? \@define_in_top_list : \@define_in_list;
        foreach $def (@$define_list) {
            if ((@$def[G_FLAG] & FLG_KEEP_STR) && @$def[G_FILE] eq $file) {
                $find = 1;
            }
        }
        if ($find == 1 && grep(/^\Q$file\Q$/, @def_file_list) == 0) {
            push(@def_file_list, $file);
        }
    }
}

##
## top parse 1st (read top file)
##
sub top_parse_1st {
    my $file  = $_[0];
    my $level = $_[1];
    my $line_num = 0;
    local(*IN);

    open (IN, "<$file") || die "can't open input file [$file]\n";

    $top_ifdef[$level] = 0;
    $top_ifdef_else[$level][$top_ifdef[$level]] = 0;
    $top_ifdef_ignore[$level][$top_ifdef[$level]] = 0;
    $top_ifdef_inc[$level][$top_ifdef[$level]] = 0;

    while (<IN>) {
        $line_num++;
        $line = $_;
        &remove_rtn(\$line);
        $line_org = $line;
        &get_string(\$line, \$comment);
        next if ($line eq "");
        @words = split /\s+/, $line;

        print "$top_ifdef_ignore[$level][$top_ifdef[$level]] $line\n" if($debug_ssgen == 1);

        $t_flg = 0;
        # "const" check
        if ($words[0] eq "const") {
            $t_flg |= FLG_CONST;
            $line =~ s/const\s+//;
            @words = split /\s+/, $line;
            if (($words[0] !~ /^(uvar|svar)(\w+)$/)
             && ($words[0] !~ /^(char|uchar|short|ushort|int|uint)$/)) {
                message("E205", $file, $line_num, "const should not be set to \"$words[0]\"") if($free_area == 0);
            }
        }
        # "`ifdef"
        if ($words[0] eq "`ifdef") {
            #if ($top_ifdef == 1) {
            #    message("E009", $file, $line_num, "not support nesting with \"`ifdef\"");
            #}
            if (@words != 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            if ($now_area != COM) {
                message("E010", $file, $line_num, "not support nesting with \"#ifdef\"");
            }

            if ($words[1] eq "$tb_macro") {
                $now_area = TB;
            }
            else {
                #message("E324", $file, $line_num,
                #    "please use only \"$tb_macro\" for macro [$words[1]]");
            }
            #&check_top_order($words[0], 3, $file, $line_num, $level);

            $top_ifdef[$level]++;
            $top_ifdef_ignore[$level][$top_ifdef[$level]] = 1;
            if ($words[1] eq $tb_macro) {
                if($top_ifdef_ignore[$level][($top_ifdef[$level]-1)] == 0) {
                    $top_ifdef_ignore[$level][$top_ifdef[$level]] = 0;
                    $now_area = TB;
                }
            }
            else {
                foreach $elm (@define_in_top_list) {
                    if($words[1] eq @$elm[G_NAME]) {
                        if($top_ifdef_ignore[$level][($top_ifdef[$level]-1)] == 0) {
                            @$elm[G_FLAG] |= FLG_USED;
                            $top_ifdef_ignore[$level][$top_ifdef[$level]] = 0;
                        }
                    }
                }
            }
            if ($top_ifdef_ignore[$level][$top_ifdef[$level]] == 0) {
                $top_ifdef_inc[$level][$top_ifdef[$level]] = 1;
            }
        }
        # "`ifndef"
        elsif ($words[0] eq "`ifndef") {
            if (@words != 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            if ($words[1] eq "$tb_macro") {
                message("E025", $file, $line_num, "not support \"$tb_macro\" macro in \"$words[0]\" command");
            }
            $top_ifdef[$level]++;
            $top_ifdef_ignore[$level][$top_ifdef[$level]] = 0;
            if($top_ifdef_ignore[$level][($top_ifdef[$level]-1)] == 0) {
                foreach $elm (@define_in_top_list) {
                    if($words[1] eq @$elm[G_NAME]) {
                        @$elm[G_FLAG] |= FLG_USED;
                        $top_ifdef_ignore[$level][$top_ifdef[$level]] = 1;
                    }
                }
            }
            else {
                $top_ifdef_ignore[$level][$top_ifdef[$level]] = 1;
            }
            if ($top_ifdef_ignore[$level][$top_ifdef[$level]] == 0) {
                $top_ifdef_inc[$level][$top_ifdef[$level]] = 1;
            }
        }
        # "`if"
        elsif ($words[0] eq "`if") {
            if ($now_area != COM) {
                message("E010", $file, $line_num, "not support nesting with \"$words[0]\" in $tb_macro macro");
            }
            if (@words < 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            $top_ifdef[$level]++;
            $top_ifdef_ignore[$level][$top_ifdef[$level]] = 1;
            if($top_ifdef_ignore[$level][($top_ifdef[$level]-1)] == 0) {
                my $define = $line;
                $define =~ s/^`if\s+//;
                while ($define =~ /(\bdefined((\s*\(\s*)|\s+)(\w+)(\s*\))?)/) {
                    my $tmp_define = $1;
                    my $macro      = $4;
                    if (($3 eq "" && $5 ne "") || ($3 ne "" && $5 eq "")) {
                        message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                    }
                    if ($macro eq $tb_macro) {
                        message("E025", $file, $line_num, "not support \"$tb_macro\" macro in \"$words[0]\" command");
                    }
                    $find = 0;
                    foreach $elm (@define_in_top_list) {
                        if($macro eq @$elm[G_NAME]) {
                            @$elm[G_FLAG] |= FLG_USED;
                            $find = 1;
                        }
                    }
                    if ($find == 1) {
                        $define =~ s/\Q$tmp_define\E/1/;
                    }
                    else {
                        $define =~ s/\Q$tmp_define\E/0/;
                    }
                }
                while ($define =~ /(\A|\W)([_a-zA-Z].\w*)(\W|\Z)/) {
                    my $macro = $2;
                    my $macro_value = &get_macro_value($macro, $file, $line_num, 1);
                    $define =~ s/\Q$macro\E/$macro_value/;
                }
                if (eval($define) == 1) {
                    $top_ifdef_ignore[$level][$top_ifdef[$level]] = 0;
                }
            }
            if ($top_ifdef_ignore[$level][$top_ifdef[$level]] == 0) {
                $top_ifdef_inc[$level][$top_ifdef[$level]] = 1;
            }
        }
        # "`elif"
        elsif ($words[0] eq "`elif") {
            if ($top_ifdef[$level] == 0) {
                message("E011", $file, $line_num, "\"$words[0]\" should be set after \"`ifdef/`if/`elif\"");
            }
            if ($top_ifdef_else[$level][$top_ifdef[$level]] == 1) {
                message("E011", $file, $line_num, "\"$words[0]\" should not be set after \"`else\"");
            }
            if ($now_area != COM) {
                message("E010", $file, $line_num, "not support nesting with \"$words[0]\" in $tb_macro macro");
            }
            if (@words < 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            if ($top_ifdef_ignore[$level][($top_ifdef[$level]-1)] == 0) {
                if ($top_ifdef_ignore[$level][$top_ifdef[$level]] == 1 && $top_ifdef_inc[$level][$top_ifdef[$level]] == 0) {
                    my $define = $line;
                    $define =~ s/^`elif\s+//;
                    while ($define =~ /(\bdefined((\s*\(\s*)|\s+)(\w+)(\s*\))?)/) {
                        my $tmp_define = $1;
                        my $macro      = $4;
                        if (($3 eq "" && $5 ne "") || ($3 ne "" && $5 eq "")) {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if ($macro eq $tb_macro) {
                            message("E025", $file, $line_num, "not support \"$tb_macro\" macro in \"$words[0]\" command");
                        }
                        $find = 0;
                        foreach $elm (@define_in_top_list) {
                            if($macro eq @$elm[G_NAME]) {
                                @$elm[G_FLAG] |= FLG_USED;
                                $find = 1;
                            }
                        }
                        if ($find == 1) {
                            $define =~ s/\Q$tmp_define\E/1/;
                        }
                        else {
                            $define =~ s/\Q$tmp_define\E/0/;
                        }
                    }
                    while ($define =~ /(\A|\W)([_a-zA-Z].\w*)(\W|\Z)/) {
                        my $macro = $2;
                        my $macro_value = &get_macro_value($macro, $file, $line_num, 1);
                        $define =~ s/\Q$macro\E/$macro_value/;
                    }
                    if (eval($define) == 1) {
                        $top_ifdef_ignore[$level][$top_ifdef[$level]] = 0;
                    }
                }
                elsif ($top_ifdef_inc[$level][$top_ifdef[$level]] == 1) {
                    $top_ifdef_ignore[$level][$top_ifdef[$level]] = 1;
                }
            }
            if ($top_ifdef_ignore[$level][$top_ifdef[$level]] == 0) {
                $top_ifdef_inc[$level][$top_ifdef[$level]] = 1;
            }
        }
        # "`else"
        elsif ($words[0] eq "`else") {
            if (@words != 1) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            if ($top_ifdef[$level] == 0) {
                message("E011", $file, $line_num, "\"$words[0]\" should be set after \"`ifdef/`if/`elif\"");
            }
            if ($top_ifdef_else[$level][$top_ifdef[$level]] == $top_ifdef[$level]) {
                message("E024", $file, $line_num, "\"$words[0]\" is set multiple times");
            }
            $top_ifdef_else[$level][$top_ifdef[$level]] = 1;
            if($top_ifdef_ignore[$level][$top_ifdef[$level]] == 1 && $top_ifdef_inc[$level][$top_ifdef[$level]] == 0) {
                if($top_ifdef_ignore[$level][($top_ifdef[$level]-1)] == 0) {
                    $top_ifdef_ignore[$level][$top_ifdef[$level]] = 0;
                }
            }
            else {
                if ($now_area == TB) {
                    message("E112", $file, $line_num,
                        "\"$words[0]\" should not be set to \"`ifdef $tb_macro\"");
                }
                else {
                    $top_ifdef_ignore[$level][$top_ifdef[$level]] = 1;
                }
            }
            if ($top_ifdef_ignore[$level][$top_ifdef[$level]] == 0) {
                $top_ifdef_inc[$level][$top_ifdef[$level]] = 1;
            }
        }
        # "`endif"
        elsif ($words[0] eq "`endif") {
            if (@words != 1) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            if ($top_ifdef[$level] == 0) {
                message("E011", $file, $line_num, "\"$words[0]\" should be set after \"`ifdef/`if/`elif\"");
            }
            $top_ifdef_ignore[$level][$top_ifdef[$level]] = 0;
            $top_ifdef_else[$level][$top_ifdef[$level]] = 0;
            $top_ifdef_inc[$level][$top_ifdef[$level]] = 0;
            $top_ifdef[$level]--;
            $now_area = COM;
        }
        # skip line
        elsif ($top_ifdef_ignore[$level][$top_ifdef[$level]] == 1) {
        }
        # "top"
        elsif ($words[0] eq "top") {
            if ($level != 0) {
                message("E103", $file, $line_num, "\"$words[0]\" should not be set in include file");
            }
            &check_scope($words[0], 0, $file, $line_num);
            &check_top_order($words[0], 1, $file, $line_num, $level);
        }
        # "`define"
        elsif ($words[0] eq "`define") {
            &check_top_order($words[0], 0, $file, $line_num, $level);
            &check_scope($words[0], 0, $file, $line_num);
            if (@words < 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            &check_reserved($words[1], $file, $line_num);
            my $substance = "";
            for(my $index = 2; $index < @words; $index++) {
                $substance = $substance . $words[$index];
            }
            @elm = ($comment, $words[1], 0, $substance, "", $substance);
            if ($top_keep_ssgen_define == 1) {
                $elm[G_FLAG] |= FLG_KEEP_STR;
                $elm[G_FILE] = $file;
            }
            if (&name_exist(\@define_in_top_list, $words[1], \$def) == 1) {
                #message("W005", $file, $line_num,
                #    "macro \"$words[1]\" is redefined");
                if ($elm[G_SUBS] ne @$def[G_SUBS]) {
                    if (@$def[G_FLAG] &  FLG_KEEP_STR) {
                        message("E302", $file, $line_num,
                            "macro \"$words[1]\" should not be redefined because is target of keep_ssgen_define");
                    }
                    elsif ($elm[G_FLAG] &  FLG_KEEP_STR) {
                        message("W006", $file, $line_num, "macro \"$words[1]\" is redefined and become target of keep_ssgen_define");
                    }
                    else {
                        message("W005", $file, $line_num, "macro \"$words[1]\" is redefined");
                    }
                }
                @$def[G_VALUE] = $substance;
                @$def[G_SUBS] = $substance;
                @$def[G_FLAG] |= FLG_KEEP_STR if ($top_keep_ssgen_define == 1);
                #@$def[G_VALUE] = &get_macro_value($words[1], $file, $line_num) if ($substance ne "");
            }
            else {
                #my $tmp = [@elm];
                #push(@define_in_top_list, $tmp);
                #@$tmp[G_VALUE] = &get_macro_value($words[1], $file, $line_num) if ($substance ne "");
                push(@define_in_top_list, [@elm]);
            }
        }
        # "`include"
        elsif ($words[0] eq "`include") {
            &check_top_order($words[0], 0, $file, $line_num, $level);
            &check_scope($words[0], 0, $file, $line_num);

            if (@words != 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            if ($level == 0) {
                my $inc_name = $words[1];
                my $orgdir  = $nowdir;
                $inc_file = $nowdir . $inc_name;
                $nowdir = &get_dir($inc_file);
                &top_parse_1st($inc_file, $level + 1); # recursive call
                $nowdir = $orgdir;

                # check scope
                if ($top_free_area == 1) {
                    message("E019", "$inc_name", 0, "\"--!\" should be set");
                }
                #elsif ($top_ifdef > 0) {
                #    message("E012", "$inc_name", 0, "\"`endif\" should be set");
                #}
                elsif ($now_area != COM) {
                    message("E015", "$inc_name", 0, "\"#endif\" should be set");
                }
            }
            else {
                message("E102", $file, $line_num,
                    "\"`include\": not support more than 1 level nesting");
            }
        }
        # #include
        elsif ($words[0] eq "#include") {
            &check_scope($words[0], 1, $file, $line_num);
            if (@words != 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            if ($words[1] !~ /^\"/ && $words[1] !~ /^\</) {
                $words[1] = "\"" . $words[1] . "\"";
            }
            my $exist = 0;
            foreach $pre (@prepro_list_tb) {
                if (@$pre[G_FLAG] eq "#include" && @$pre[G_NAME] eq $words[1]) {
                    $exist = 1;
                    last;
                }
            }
            if ($exist == 0) {
                @elm = ($comment, $words[1], "#include");
                push(@prepro_list_tb, [@elm]);
            }
        }
        # free Area
        elsif ($words[0] eq "!--") {
            &check_scope($words[0], 1, $file, $line_num);
            if ($top_free_area == 1) {
                message("E020", $file, $line_num,
                        "\"!--\" should not be set in Free Area");
            }
            if (@words > 1) {
                message("E017", $file, $line_num,
                        "\"!--\" should not be set with another word");
            }
            $top_free_area = 1;
        }
        elsif ($words[0] eq "--!") {
            &check_scope($words[0], 1, $file, $line_num);
            if ($top_free_area == 0) {
                message("E018", $file, $line_num,
                        "\"--!\" should be set after \"!--\"");
            }
            $top_free_area = 0;
        }
        elsif ($top_free_area == 1) {
            foreach my $s (@struct_list) {
                my $st_name = @$s[$STR_NAME];
                if ($line_org =~ /\bstruct\s+$st_name\b/) {
                    message("E017", $file, $line_num, "struct \"$st_name\" is redefined in free area");
                }
            }
            if ($is_struct_parsing)  {
                push(@free_area_list_struct, $line_org);
            }
            elsif ($now_area == TB) {
                push(@free_area_list_tb, $line_org);
            }
        }
        # #ifdef
        elsif ($words[0] eq "#ifdef") {
            #if ($top_ifdef > 0) {
            #    message("E009", $file, $line_num, "not support nesting with \"`ifdef\"");
            #}
            if ($now_area != COM || $top_ifdef[$level] > 0) {
                message("E010", $file, $line_num, "not support nesting with \"#ifdef\"");
            }
            if (@words != 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            else {
                $now_area = SIM;
                $now_macro = $words[1];
                if ($now_macro !~ /^_DEBUG/) {
                    message("E308", $file, $line_num, "please use only _DEBUG* for #ifdef macro");
                }
                &check_format($words[1], 0, $file, $line_num);
            }
        }
        # #endif
        elsif ($words[0] eq "#endif") {
            if ($now_area == COM) {
                message("E014", $file, $line_num,
                        "\"#endif\" should be set after \"#ifdef\"");
            }
            if (@words != 1) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            $now_area = COM;
        }
        # "changelog"
        elsif ($words[0] eq "changelog") {
            &check_scope($words[0], 0, $file, $line_num);
            if (@words == 1) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            &check_top_order($words[0], 0, $file, $line_num, $level);

            $line =~ s/changelog\s+//;
            if ($is_struct_parsing == 1) {
                push(@changelog_list_struct, $line);
            } else {
                push(@changelog_list, $line);
            }
        }
        # "Ctype"
        elsif ($words[0] =~ /^(char|uchar|short|ushort|int|uint)$/) {
            &check_scope($words[0], 1, $file, $line_num);
            if ($now_area == TB || $is_struct_parsing) {
                if (@words == 1) {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }
                &get_attributes(\@elm, $line, $file, $line_num, $comment, "", $words[0], "", $t_flg);
                $name = $elm[T_NAME];
                &check_format($name, 0, $file, $line_num);
                if ($is_struct_parsing) {
                    &check_defined_struct($name, $struct_name, $file, $line_num);  
                    push(@struct_mem_list, [@elm]);
                } else {
                    &check_defined_tb($name, 1, $file, $line_num);
                    push(@ctype_list_tb, [@elm]);
                }
            }
        }
        # "var"
        elsif ($words[0] =~ /^(uvar|svar)(\w+)$/) {
            &check_scope($words[0], 1, $file, $line_num);
            if ($now_area == TB || $is_struct_parsing) {
                if (@words == 1) {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }
                $type = $1;
                $wid  = $2;
                &check_width(\$wid, $file, $line_num);
                &get_attributes(\@elm, $line, $file, $line_num, $comment, "", $type, $wid, $t_flg);
                $name = $elm[T_NAME];
                &check_format($name, 0, $file, $line_num);
                if ($is_struct_parsing) {
                    &check_defined_struct($name, $struct_name, $file, $line_num);
                    push(@struct_mem_list, [@elm]);
                } else {
                    &check_defined_tb($name, 1, $file, $line_num);
                    push(@var_list_tb, [@elm]);
                }
            }
        }
        # "reg"
        elsif ($words[0] =~ /^(ureg|sreg)(\w+)$/) {
            &check_scope($words[0], 1, $file, $line_num);
            if ($now_area == TB) {
                if (@words == 1) {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }
                $type = $1;
                $wid  = $2;
                &check_width(\$wid, $file, $line_num);
                &get_attributes(\@elm, $line, $file, $line_num, $comment, "", $type, $wid, $t_flg);
                $name = $elm[T_NAME];
                &check_format($name, 0, $file, $line_num);
                &check_defined_tb($name, 1, $file, $line_num);
                push(@reg_list_tb, [@elm]);
            }
        }
        # style parameters
        elsif ($words[0] eq "style_module"
          || $words[0] eq "style_alloc"
          || $words[0] eq "space_indent"
          || $words[0] eq "mem_suffix"
          || $words[0] eq "toggle_coverage"
          || $words[0] eq "keep_ssgen_define"
          #|| $words[0] eq "wait_expand"
          || $words[0] eq "vcd_trace") {
            &set_style_parameter(\@words, $file, $line_num, 0);
        }
        # "hdl_observer"
        elsif ( $words[0] eq "hdl_observer" || $words[0] eq "sva_check" ) {
            &set_hdl_observer_parameter($line, $file, $line_num);
        }
        # "env_xxx"
        elsif ($words[0] =~ /^env_/) {
            &set_env_parameter(\@words, $file, $line_num, 0);
        }
        # "ctos_xxx"
        elsif ($words[0] =~ /^ctos_/) {
            &set_ctos_parameter(\@words, $file, $line_num, 0);
        }
        # "stratus_xxx"
        elsif ($words[0] =~ /^stratus_/) {
            &set_stratus_parameter(\@words, $file, $line_num, 0);
        }
        # "func"
        elsif ($words[0] eq "func") {
            &check_scope($words[0], 1, $file, $line_num);
            if ($now_area == TB) {
                &get_func_ret_body($line, $file, $line_num, \$name, \$ret, \$body, \$flg);
                @elm = ($comment, $name, $ret, $body, $flg);
                push(@func_list_tb, [@elm]);
            }
        }
        # "sub"
        elsif ($words[0] eq "sub") {
            #if ($level != 0) {
            #    message("E103", $file, $line_num, "\"$words[0]\" should not be set in include file");
            #}
            if ($now_area != COM && $now_area != SIM) {
                &check_scope($words[0], 0, $file, $line_num);
            }
            &check_top_order($words[0], 2, $file, $line_num, $level);
            if (@words < 3) {
                message("E202", $file, $line_num, "\"sub\" has invalid format");
            }
            &check_format($words[2], 1, $file, $line_num);
            &check_defined($words[2], 1, $file, $line_num);

            $line =~ /^sub\s+(\S+)\s+(\S+)(.*)$/;
            $mod_file  = $1;
            $mod_inst  = $2;
            $mod_opt   = $3;
            $mod_fpath = &get_dir($mod_file);
            $mod_flg   = 0;
            $top_mode = 2; ## get only `define command from sub module file
            $sub_name = "";
            $sub_tmpl_name = "";

            $mod_opt =~ s/^\s*//;
            if ($mod_opt ne "") {
                if ($mod_opt =~ /^([^-]\S*)(.*)/) {
                    $mod_path = $1;
                    $mod_opt = $2;
                }

                while ($mod_opt =~ /-([^-]+)/g) {
                    my $elm = $1;
                    $elm =~ s/\s*$//;
                    my $lhs = $elm;
                    my $rhs = "";
                    if ($elm =~ /(.*?)\s+(.*)/) {
                        $lhs = $1;
                        $rhs = $2;
                    }

                    if ($lhs eq "template_inst") {
                        if ($rhs eq "") {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if ($sub_tmpl_name ne "") {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        $sub_tmpl_name = $rhs;
                    }
                }
            }

            if( $mod_file ne "ctos_clock_gating.in" ) {
                $use_template = 0;
                &mod_parse($nowdir . $mod_file, 0);
            }
            else {
                &mod_parse($ctos_clock_gating_in, 0);
                $use_ctos_cg = 1;
            }
            $top_mode = 1;
            if ($sub_tmpl_name ne "") {
                if ($use_template == 0) {
                    message("E805", $file, $line_num, "\"$sub_name\" is not a template");
                }
                if (&name_exist(\@tmpl_inst_list, $sub_tmpl_name) == 0) {
                    message("E806", $file, $line_num, "module \"$sub_tmpl_name\" is not defined in \"$mod_file\"");
                }
            }
            $sub_name = $sub_tmpl_name if ($sub_tmpl_name ne "");
            &check_defined($sub_name, 0, $file, $line_num);
            if (&name_exist(\@mod_list, $sub_name, \$tmp)) {
                $mod_flg |= FLG_MULTI;
                @$tmp[MOD_FLG] |= FLG_MULTI;
            }
            my @mod_data = ($comment, $sub_name, $mod_flg, $mod_inst, "", $mod_macro, $top_dbg, [], "");
            push(@mod_list, [@mod_data]);
        }
        # "prefix_sync"
        elsif ($words[0] eq "prefix_sync") {
            if ($now_area != COM && $now_area != SIM) {
                &check_scope($words[0], 0, $file, $line_num);
            }
            &check_top_order($words[0], 0, $file, $line_num, $level);
            if (@words != 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            &check_reserved($words[1], $file, $line_num);
            &check_defined($words[1], 1, $infile, $line_num);
            $prefix_sync = $words[1];
        }
        # "tap"
        elsif ($words[0] eq "tap") {
            #if ($level != 0) {
            #    message("E103", $file, $line_num, "\"$words[0]\" should not be set in include file");
            #}
            &check_scope($words[0], 0, $file, $line_num);
            &check_top_order($words[0], 3, $file, $line_num, $level);

            if (@words < 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }
            if ($words[1] =~ /\[/ || $words[2] =~ /\[/) {
                message("E325", $file, $line_num,
                        "set signal/output name without array element description");
            }
            if ($words[2] =~ /^-/) {
                message("E345", $file, $line_num,
                        "set output memory name when specifying memory in \"tap\"");
            }

            my $tap_mod = "";
            my $tap_sig = "";
            if ($words[1] =~ /(.*)\.(.*)/) {
                $tap_mod = $1;
                $tap_sig = $2;
            }
            else {
                $tap_sig = $words[1];
            }

            if ($words[2] eq "") {
                $words[2] = $tap_sig;
            }
            else {
                &check_format($words[2], 1, $file, $line_num);
            }

            foreach $tmp (@tap_list) {
                if (@$tmp[TAP_SIG] eq $tap_sig
                    && @$tmp[TAP_INST] eq $tap_mod) {
                    message("E323", $file, $line_num, "\"$words[1]\" is set to tap again");
                }
            }

            my $iprefix  = "";
            my $oprefix  = "";
            my @opt = split(/-/,$line);
            shift @opt;
            foreach $tmp (@opt) {
                $tmp =~ s/\s*$//g;
                if ($tmp =~ /(.*?)(\s*=\s*|\s+)(.*)/) {
                    $lhs = $1;
                    $rhs = $3;
                }
                if ($lhs eq "mem_pfx" || $lhs eq "prefix") {
                    $iprefix = $rhs;
                    $oprefix = $rhs;
                }
                elsif ($lhs eq "mem_ipfx" || $lhs eq "iprefix") {
                    $iprefix = $rhs;
                }
                elsif ($lhs eq "mem_opfx" || $lhs eq "oprefix") {
                    $oprefix = $rhs;
                }
            }
            &check_format($iprefix . $words[2], 1, $file, $line_num);
            &check_format($oprefix . $words[2], 1, $file, $line_num);

            @elm = ($comment, $tap_sig, $words[2], $tap_mod, 0, $iprefix, $oprefix);
            push(@tap_list, [@elm]);
        }
        # "bind"
        elsif ($words[0] eq "bind") {
            #if ($level != 0) {
            #    message("E103", $file, $line_num, "\"$words[0]\" should not be set in include file");
            #}
            if ($now_area != COM && $now_area != SIM) {
                &check_scope($words[0], 0, $file, $line_num);
            }
            &check_top_order($words[0], 3, $file, $line_num, $level);

            #if (@words < 3 || @words > 6) {
            #    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            #}
            for ($i=1;$i<7;$i++) {
                if ($words[$i] =~ /\[/) {
                    message("E325", $file, $line_num,
                            "set signal/output name without array element description");
                }
            }

            my $bind_sig = "";
            my $bind_opt = "";
            my $bind_flg = 0;
            my $sync_en  = "";
            my $b_inst_en = "";
            my $b_port_en = "";
            # bind ins0.port0 ins1.port1 [signal] [options]
            if ($line =~ /^bind\s+([\w\.]+)\s+([\w\.]+)(\s+([^- ]\S*))?(\s+((-\w+).*))?$/) {
                $bind_sig = $4;
                $bind_opt = $6;
                if ($bind_sig ne "") {
                    &check_format($bind_sig, 1, $file, $line_num);
                    $bind_flg |= FLG_USED_SIG;
                }
                my $set_en_level = 0;
                while ($bind_opt =~ /-(([^-]|-\d)+)/g) {
                    my $one = $1;
                    $one =~ s/\s*$//;
                    my $lhs = $one;
                    my $rhs = "";
                    if ($one =~ /(.*?)(\s*=\s*|\s+)(.*)/) {
                        $lhs = $1;
                        $rhs = $3;
                    }
                    if ($lhs eq "sync" || $lhs eq "sync_level") {
                        if ($bind_flg & FLG_SYNC) {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if ($rhs ne "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $bind_flg |= (FLG_SYNC | FLG_SYNC_OUT | FLG_SYNC_LVL);
                    }
                    elsif ($lhs eq "sync_pulse" || $lhs eq "sync_posedge") {
                        if ($bind_flg & FLG_SYNC) {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if ($rhs ne "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $bind_flg |= (FLG_SYNC | FLG_SYNC_OUT | FLG_SYNC_POS);
                    }
                    elsif ($lhs eq "sync_negedge") {
                        if ($bind_flg & FLG_SYNC) {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if ($rhs ne "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $bind_flg |= (FLG_SYNC | FLG_SYNC_OUT | FLG_SYNC_NEG);
                    }
                    elsif ($lhs eq "sync_toggle") {
                        if ($bind_flg & FLG_SYNC) {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if ($rhs ne "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $bind_flg |= (FLG_SYNC | FLG_SYNC_OUT | FLG_SYNC_TOG);
                    }
                    elsif ($lhs eq "sync_enable") {
                        if ($bind_flg & FLG_SYNC) {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if ($rhs eq "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $bind_flg |= (FLG_SYNC | FLG_SYNC_EN | FLG_SYNC_LVL);
                        $sync_en = $rhs;
                    }
                    elsif ($lhs eq "sync_pulse_enable") {
                        if ($bind_flg & FLG_SYNC) {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if ($rhs eq "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $bind_flg |= (FLG_SYNC | FLG_SYNC_EN | FLG_SYNC_POS);
                        $sync_en = $rhs;
                    }
                    elsif ($lhs eq "sync_bus") {
                        if ($bind_flg & FLG_SYNC) {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if ($rhs ne "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $bind_flg |= (FLG_SYNC | FLG_SYNC_EN);
                    }
                    elsif ($lhs eq "enable_level") {
                        if (!($bind_flg & FLG_SYNC) || !($bind_flg & FLG_SYNC_EN)) {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if (($bind_flg & FLG_SYNC_LVL) || ($bind_flg & FLG_SYNC_POS)
                         || ($bind_flg & FLG_SYNC_NEG) || ($bind_flg & FLG_SYNC_TOG)) {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($rhs eq "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $bind_flg |= FLG_SYNC_LVL;
                        $sync_en = $rhs;
                    }
                    elsif ($lhs eq "enable_posedge") {
                        if (!($bind_flg & FLG_SYNC) || !($bind_flg & FLG_SYNC_EN)) {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if (($bind_flg & FLG_SYNC_LVL) || ($bind_flg & FLG_SYNC_POS)
                         || ($bind_flg & FLG_SYNC_NEG) || ($bind_flg & FLG_SYNC_TOG)) {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($rhs eq "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $bind_flg |= FLG_SYNC_POS;
                        $sync_en = $rhs;
                    }
                    elsif ($lhs eq "enable_negedge") {
                        if (!($bind_flg & FLG_SYNC) || !($bind_flg & FLG_SYNC_EN)) {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if (($bind_flg & FLG_SYNC_LVL) || ($bind_flg & FLG_SYNC_POS)
                         || ($bind_flg & FLG_SYNC_NEG) || ($bind_flg & FLG_SYNC_TOG)) {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($rhs eq "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $bind_flg |= FLG_SYNC_NEG;
                        $sync_en = $rhs;
                    }
                    elsif ($lhs eq "enable_toggle") {
                        if (!($bind_flg & FLG_SYNC) || !($bind_flg & FLG_SYNC_EN)) {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if (($bind_flg & FLG_SYNC_LVL) || ($bind_flg & FLG_SYNC_POS)
                         || ($bind_flg & FLG_SYNC_NEG) || ($bind_flg & FLG_SYNC_TOG)) {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($rhs eq "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $bind_flg |= FLG_SYNC_TOG;
                        $sync_en = $rhs;
                    }
                    elsif ($lhs eq "high") {
                        if (!($bind_flg & FLG_SYNC_EN) || !($bind_flg & FLG_SYNC_LVL)) {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if ($rhs ne "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        if ($set_en_level == 1) {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        $set_en_level = 1;
                    }
                    elsif ($lhs eq "low") {
                        if (!($bind_flg & FLG_SYNC_EN) || !($bind_flg & FLG_SYNC_LVL)) {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if ($rhs ne "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        if ($set_en_level == 1) {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        $bind_flg |= FLG_ACTV_LOW;
                        $set_en_level = 1;
                    }
                    else {
                        message("E206", $file, $line_num, "option [-$lhs] is invalid");
                    }
                }
                if (($bind_flg & FLG_SYNC_EN) && $sync_en eq "") {
                    message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                }
                if ($sync_en =~ /(.*)\.(.*)/) {
                    $b_inst_en = $1;
                    $b_port_en = $2;
                }
                else {
                    $b_port_en = $sync_en;
                }
            }
            else {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }


            my @inst = ();
            my @port = ();
            my @flg  = (0, 0);
            for ($i = 0; $i < 2; $i++) {
                if ($words[$i+1] =~ /(.*)\.(.*)/) {
                    $inst[$i] = $1;
                    $port[$i] = $2;
                }
                else {
                    $inst[$i] = "";
                    $port[$i] = $words[$i+1];
                    if (is_number(substr($port[$i], 0, 1))) {
                        $flg[$i] |= (FLG_USED|FLG_FIX);
                    }
                    else {
                        my $macro_value = &get_macro_value($port[$i], $file, $line_num);
                        $flg[$i] |= (FLG_USED|FLG_FIX);
                        $port[$i] = $macro_value if (&is_keep_define($port[$i]) == 0);
                     }
                    #else {
                    #    message("E340", $file, $line_num,
                    #        "bind command should be specified with \"instance.port\" form");
                    #}
                }
                if ($bind_sig eq "" && !($flg[$i] & FLG_FIX) && !($bind_flg & FLG_SYNC)) {
                    $bind_sig = $port[$i];
                }
            }

            if (($flg[0] & FLG_FIX) && ($flg[1] & FLG_FIX)) {
                message("E331", $file, $line_num,
                    "bind target \"$words[1]\" does not exist in any instances");
            }

            foreach $tmp (@bind_list) {
                if (!($flg[0] & FLG_FIX)
                    && !($bind_flg & FLG_SYNC)
                    && @$tmp[B_INST_S] eq $inst[0]
                    && @$tmp[B_PORT_S] eq $port[0]
                    && @$tmp[B_SIG] ne $bind_sig) {
                    message("E407", $file, $line_num,
                                "bind target \"$words[1]\" is connected to multiple signals");
                }

                if (!($flg[1] & FLG_FIX)
                    && @$tmp[B_INST_E] eq $inst[1]
                    && @$tmp[B_PORT_E] eq $port[1]) {
                    message("E406", $file, $line_num,
                                "signal \"$words[2]\" is driven from multiple modules");
                }

                if (@$tmp[B_SIG] eq $bind_sig
                    && (($flg[0] & FLG_FIX) || ($flg[1] & FLG_FIX))) {
                    message("E408", $file, $line_num,
                                "signal of fixed port \"$bind_sig\" should not be same as the other signal");
                }
            }

            if ($bind_flg & FLG_SYNC) {
                if (($flg[0] & FLG_FIX) || ($flg[1] & FLG_FIX)) {
                    message("E409", $file, $line_num,
                            "fixed port should not be used in asynchronous binding");
                }
                my $sync_mod  = "";
                my $sync_inst = "";
                my $sync_in   = "";
                my $sync_out  = "";
                my @s_clk     = ();
                my @e_clk     = ();
                my @s_rst     = ();
                my @e_rst     = ();
                my $s_multi   = 0;
                my $e_multi   = 0;
                foreach $elm (@clk_list) {
                    if (@$elm[T_INST] eq $inst[0]) {
                        $s_clk = $elm;
                    }
                    elsif (@$elm[T_INST] eq $inst[1]) {
                        $e_clk = $elm;
                    }
                }
                #if (@$s_clk[T_NAME] eq "" || @$e_clk[T_NAME] eq "") {
                #    message("E410", $file, $line_num,
                #            "SC_METHOD only module should not be used in asynchronous binding");
                #}
                if (@$s_clk[T_NAME] eq "") {
                    message("E418", $file, $line_num,
                            "Clock is not found in instance \"$inst[0]\"");
                }
                if (@$e_clk[T_NAME] eq "") {
                    message("E418", $file, $line_num,
                            "Clock is not found in instance \"$inst[1]\"");
                }
                if (@$s_clk[T_NAME] eq @$e_clk[T_NAME]) {
                    message("E419", $file, $line_num,
                            "Asynchronous binding should not be used for same clock domain");
                }
                foreach $elm (@rst_list) {
                    if (@$elm[T_INST] eq $inst[0] && @$elm[T_TYPE] ne "soft_reset") {
                        $s_rst = $elm;
                    }
                    if (@$elm[T_INST] eq $inst[1] && @$elm[T_TYPE] ne "soft_reset") {
                        $e_rst = $elm;
                    }
                }
                $sync_mod  = $prefix_sync . lc ("sync_" . @$s_clk[T_NAME] . "2" . @$e_clk[T_NAME]);
                $sync_inst = ($prefix_sync eq "") ? lc ("sync_" . @$s_clk[T_NAME] . "2" . @$e_clk[T_NAME] . "_i")
                                                  : lc ("sync_" . @$s_clk[T_NAME] . "2" . @$e_clk[T_NAME]);
                foreach $mod (@mod_list) {
                    if ((@$mod[MOD_INST] eq $inst[0]) && (@$mod[MOD_FLG] & FLG_MULTI)) {
                        $s_multi = 1;
                        $bind_flg |= FLG_MULTI;
                    }
                    if ((@$mod[MOD_INST] eq $inst[1]) && (@$mod[MOD_FLG] & FLG_MULTI)) {
                        $e_multi = 1;
                    }
                }

                $sync_in = ($s_multi == 1) ? $inst[0] . "_" . $port[0] : $port[0];
                if ($bind_flg & FLG_USED_SIG) {
                    if ($sync_in eq $bind_sig) {
                        message("E406", $infile, 0, "signal \"$bind_sig\"" .
                                " is driven from multiple modules");
                    }
                    $sync_out = $bind_sig;
                }
                else {
                    if ($bind_flg & FLG_SYNC_EN) {
                        $sync_out = ($e_multi == 1) ? "sync_" . $inst[1] . "_" . $port[1] : "sync_" . $port[1];
                    }
                    else {
                        $sync_out = ($s_multi == 1) ? "sync_" . $inst[0] . "_" . $port[0] : "sync_" . $port[0];
                        if ($bind_flg & FLG_SYNC_POS) {
                            $sync_out = $sync_out . "_posedge";
                        }
                        elsif ($bind_flg & FLG_SYNC_NEG) {
                            $sync_out = $sync_out . "_negedge";
                        }
                        elsif ($bind_flg & FLG_SYNC_TOG) {
                            $sync_out = $sync_out . "_toggle";
                        }
                    }
                    $bind_sig = $sync_out;
                }

                $find = 0;
                foreach $elm (@bind_list) {
                    if (@$elm[B_INST_S] eq $inst[0]   && @$elm[B_PORT_S] eq $port[0] &&
                        @$elm[B_INST_E] eq $sync_inst && @$elm[B_PORT_E] eq $sync_in) {
                        $find = 1;
                    }
                }
                if ($find == 0) {
                    @elm = ($comment, $inst[0], $port[0], $sync_inst, $sync_in,
                            $sync_in, $flg[0], $bind_flg | FLG_USED, $b_inst_en, $b_port_en);
                    push(@bind_list, [@elm]);
                }
                @elm = ($comment, $sync_inst, $sync_out, $inst[1], $port[1],
                        $bind_sig, $bind_flg | FLG_USED, $flg[1], $b_inst_en, $b_port_en);
                push(@bind_list, [@elm]);

                if (!(&name_exist(\@mod_list_sync, $sync_mod))) {
                    my $mod_flg  = ($s_multi == 1) ? $bind_flg ^ FLG_MULTI : $bind_flg;
                    my @mod_data = ("", $sync_mod, $mod_flg, $sync_inst, "", "", $top_dbg, [], "");
                    push(@mod_list_sync, [@mod_data]);
                    @s_elm = ("", @$e_clk[T_NAME], $sync_inst, @$e_clk[T_TYPE], "",
                            "", "", @$e_clk[T_NAME], $bind_flg, "", "", "", "", "");
                    push(@clk_list_sync, [@s_elm]);
                    @s_elm = ("", @$e_rst[T_NAME], $sync_inst, @$e_rst[T_TYPE], @$e_rst[T_INIT],
                            "", "", @$e_rst[T_NAME], $bind_flg, "", "", "", "", "");
                    push(@rst_list_sync, [@s_elm]);
                }

                &name_exist(\@sync_list, $bind_sig, \$tmp);
                if (@$tmp[S_NAME] ne $bind_sig || @$tmp[S_INST] ne $sync_inst) {
                    my @sync_data = ($comment, $bind_sig, $sync_in, $sync_out, "", $bind_flg, $sync_inst, "");
                    push (@sync_list, [@sync_data]);
                }

                # for checker module
                my $chk_mod  = $prefix_sync . "chk_" . lc(@$s_clk[T_NAME]) . "2" . lc(@$e_clk[T_NAME]);
                my $chk_inst = ($prefix_sync eq "") ? $chk_mod . "_i"
                                                    : "chk_" . lc(@$s_clk[T_NAME]) . "2" . lc(@$e_clk[T_NAME]);
                #my $chk_inst = $chk_mod . "_i";
                my $chk_flg  = ($bind_flg | FLG_SYNC_CHK) ^ FLG_SYNC;
                if ($find == 0) {
                    @elm = ("" , $inst[0], $port[0], $chk_inst, $sync_in,
                            $sync_in, $flg[0], $chk_flg | FLG_USED, $b_inst_en, $b_port_en);
                    push(@bind_list, [@elm]);
                }
                if (!(&name_exist(\@mod_list_sync, $chk_mod))) {
                    my $mod_flg  = ($s_multi == 1) ? $bind_flg ^ FLG_MULTI : $bind_flg;
                    my @mod_data = ("", $chk_mod, $mod_flg, $chk_inst, "", "", $dbg_macro, [], "");
                    push(@mod_list_sync, [@mod_data]);
                    @s_elm = ("", @$s_clk[T_NAME], $chk_inst, @$s_clk[T_TYPE], "",
                            "", "", @$s_clk[T_NAME], $bind_flg, @$s_clk[T_NAME] . "_thread", "", "", "", "");
                    push(@clk_list_sync, [@s_elm]);
                    @s_elm = ("", @$e_clk[T_NAME], $chk_inst, @$e_clk[T_TYPE], "",
                            "", "", @$e_clk[T_NAME], $bind_flg, @$e_clk[T_NAME] . "_thread", "", "", "", "");
                    push(@clk_list_sync, [@s_elm]);
                    @s_elm = ("", @$s_rst[T_NAME], $chk_inst, @$s_rst[T_TYPE], @$s_rst[T_INIT],
                            "", "", @$s_rst[T_NAME], $bind_flg, @$s_clk[T_NAME] . "_thread", "", "", "", "");
                    push(@rst_list_sync, [@s_elm]);
                    @s_elm = ("", @$e_rst[T_NAME], $chk_inst, @$e_rst[T_TYPE], @$e_rst[T_INIT],
                            "", "", @$e_rst[T_NAME], $bind_flg, @$e_clk[T_NAME] . "_thread", "", "", "", "");
                    push(@rst_list_sync, [@s_elm]);
                    @s_elm = ("", @$s_clk[T_NAME] . "_thread", 0, @$s_clk[T_NAME], "pos", "", $dbg_macro);
                    push(@thread_list, [@s_elm]);
                    @s_elm = ("", @$e_clk[T_NAME] . "_thread", 0, @$e_clk[T_NAME], "pos", "", $dbg_macro);
                    push(@thread_list, [@s_elm]);
                }
            }
            else {
                @elm = ($comment, $inst[0], $port[0], $inst[1], $port[1], $bind_sig, $flg[0], $flg[1], "", "");
                push(@bind_list, [@elm]);
            }
        }
        # "insert_port"
        elsif ($words[0] eq "insert_port") {
            if ($now_area != COM && $now_area != SIM) {
                &check_scope($words[0], 0, $file, $line_num);
            }
            &check_top_order($words[0], 3, $file, $line_num, $level);

            if (@words != 3) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }

            if ($words[1] =~ /^(uin|sin|uout|sout)(\w+)$/) {
                $type = $1;
                $wid  = $2;
                &check_width(\$wid, $file, $line_num);
            }
            else {
                message("E347", $file, $line_num, "\"$words[1]\" should not be specified to \"insert_port\"");
            }

            my $argument = $words[1]." ".$words[2];
            &get_attributes(\@elm, $argument, $file, $line_num, $comment, "", $type, $wid, 0);
            $name = $elm[T_NAME];

            &check_format($name, 1, $file, $line_num);
            &check_defined($name, 1, $file, $line_num);
            &check_defined_tb($name, 1, $file, $line_num);

            if ($words[1] =~ /^(uin|sin)(\w+)$/) {
                push(@in_list_insert, [@elm]);
            }
            else {
                push(@out_list_insert, [@elm]);
            }
        }
        # "cer_off"
        elsif ($words[0] eq "cer_off") {
            if ($now_area != COM && $now_area != SIM) {
                &check_scope($words[0], 0, $file, $line_num);
            }
            &check_top_order($words[0], 3, $file, $line_num, $level);

            if (@words != 2) {
                message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
            }

            #if ($opt_cer) {
            @elm = ($comment, $words[1]);
            push(@cer_off_list, [@elm]);
            #}
        }
        elsif (@words > 0) {
            if ($level == 0) {
                message("E201", $file, $line_num, "invalid command [$words[0]]");
            }
            else {
                message("I005", $file, $line_num, "skip invalid command [$words[0]]");
            }
        }
    }
    close(IN);

    if ($level == 0) {
        @mod_list = ();
        @clk_list = ();
        @rst_list = ();
    }

    # check scope
    if ($top_free_area == 1) {
        message("E019", "", 0, "\"--!\" should be set");
    }
    elsif ($top_ifdef[$level] > 0) {
        message("E012", "", 0, "\"`endif\" should be set");
    }
}

##
## top parse 2nd (read top file)
##
sub top_parse_2nd {
    my $file  = $_[0];
    my $line_num = 0;
    $top_dbg = "";
    local(*IN);

    open (IN, "<$file") || die "can't open input file [$file]\n";

    if ($tab eq "") {
        $tab = "    "; # top_parse_2nd needs tab data
    }

    $top_ifdef[$level] = 0;
    $top_ifdef_ignore[$level][$top_ifdef[$level]] = 0;
    $top_ifdef_inc[$level][$top_ifdef[$level]] = 0;

    while (<IN>) {
        $line_num++;
        $line = $_;
        &remove_rtn(\$line);
        $line_org = $line;
        &get_string(\$line, \$comment);
        next if ($line eq "");
        @words = split /\s+/, $line;

        print "$top_ifdef_ignore[$level][$top_ifdef[$level]] $line\n" if($debug_ssgen == 1);

        # "`ifdef"
        if ($words[0] eq "`ifdef") {
            $top_ifdef[$level]++;
            $top_ifdef_ignore[$level][$top_ifdef[$level]] = 1;
            if ($words[1] eq $tb_macro) {
                if($top_ifdef_ignore[$level][($top_ifdef[$level]-1)] == 0) {
                    $top_ifdef_ignore[$level][$top_ifdef[$level]] = 0;
                    $now_area = TB;
                }
            }
            else {
                foreach $elm (@define_in_top_list) {
                    if($words[1] eq @$elm[G_NAME]) {
                        if($top_ifdef_ignore[$level][($top_ifdef[$level]-1)] == 0) {
                            @$elm[G_FLAG] |= FLG_USED;
                            $top_ifdef_ignore[$level][$top_ifdef[$level]] = 0;
                        }
                    }
                }
            }
            if ($top_ifdef_ignore[$level][$top_ifdef[$level]] == 0) {
                $top_ifdef_inc[$level][$top_ifdef[$level]] = 1;
            }
        }
        # "`ifndef"
        elsif ($words[0] eq "`ifndef") {
            $top_ifdef[$level]++;
            $top_ifdef_ignore[$level][$top_ifdef[$level]] = 0;
            if($top_ifdef_ignore[$level][($top_ifdef[$level]-1)] == 0) {
                if ($words[1] ne $tb_macro) {
                    foreach $elm (@define_in_top_list) {
                        if($words[1] eq @$elm[G_NAME]) {
                            @$elm[G_FLAG] |= FLG_USED;
                            $top_ifdef_ignore[$level][$top_ifdef[$level]] = 1;
                        }
                    }
                }
            }
            else {
                $top_ifdef_ignore[$level][$top_ifdef[$level]] = 1;
            }
            if ($top_ifdef_ignore[$level][$top_ifdef[$level]] == 0) {
                $top_ifdef_inc[$level][$top_ifdef[$level]] = 1;
            }
        }
        # "`if"
        elsif ($words[0] eq "`if") {
            $top_ifdef[$level]++;
            $top_ifdef_ignore[$level][$top_ifdef[$level]] = 1;
            if($top_ifdef_ignore[$level][($top_ifdef[$level]-1)] == 0) {
                my $define = $line;
                $define =~ s/^`if\s+//;
                while ($define =~ /(\bdefined((\s*\(\s*)|\s+)(\w+)(\s*\))?)/) {
                    my $tmp_define = $1;
                    my $macro      = $4;
                    $find = 0;
                    foreach $elm (@define_in_top_list) {
                        if($macro eq @$elm[G_NAME]) {
                            @$elm[G_FLAG] |= FLG_USED;
                            $find = 1;
                        }
                    }
                    if ($find == 1) {
                        $define =~ s/\Q$tmp_define\E/1/;
                    }
                    else {
                        $define =~ s/\Q$tmp_define\E/0/;
                    }
                }
                while ($define =~ /(\A|\W)([_a-zA-Z].\w*)(\W|\Z)/) {
                    my $macro = $2;
                    my $macro_value = &get_macro_value($macro, $file, $line_num, 1);
                    $define =~ s/\Q$macro\E/$macro_value/;
                }
                if (eval($define) == 1) {
                    $top_ifdef_ignore[$level][$top_ifdef[$level]] = 0;
                }
            }
            if ($top_ifdef_ignore[$level][$top_ifdef[$level]] == 0) {
                $top_ifdef_inc[$level][$top_ifdef[$level]] = 1;
            }
        }
        # "`elif"
        elsif ($words[0] eq "`elif") {
            if ($top_ifdef_ignore[$level][($top_ifdef[$level]-1)] == 0) {
                if ($top_ifdef_ignore[$level][$top_ifdef[$level]] == 1 && $top_ifdef_inc[$level][$top_ifdef[$level]] == 0) {
                    my $define = $line;
                    $define =~ s/^`elif\s+//;
                    while ($define =~ /(\bdefined((\s*\(\s*)|\s+)(\w+)(\s*\))?)/) {
                        my $tmp_define = $1;
                        my $macro      = $4;
                        if (($3 eq "" && $5 ne "") || ($3 ne "" && $5 eq "")) {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if ($macro eq $tb_macro) {
                            message("E025", $file, $line_num, "not support \"$tb_macro\" macro in \"$words[0]\" command");
                        }
                        $find = 0;
                        foreach $elm (@define_in_top_list) {
                            if($macro eq @$elm[G_NAME]) {
                                @$elm[G_FLAG] |= FLG_USED;
                                $find = 1;
                            }
                        }
                        if ($find == 1) {
                            $define =~ s/\Q$tmp_define\E/1/;
                        }
                        else {
                            $define =~ s/\Q$tmp_define\E/0/;
                        }
                    }
                    while ($define =~ /(\A|\W)([_a-zA-Z].\w*)(\W|\Z)/) {
                        my $macro = $2;
                        my $macro_value = &get_macro_value($macro, $file, $line_num, 1);
                        $define =~ s/\Q$macro\E/$macro_value/;
                    }
                    if (eval($define) == 1) {
                        $top_ifdef_ignore[$level][$top_ifdef[$level]] = 0;
                    }
                }
                else {
                    $top_ifdef_ignore[$level][$top_ifdef[$level]] = 1;
                }
            }
            if ($top_ifdef_ignore[$level][$top_ifdef[$level]] == 0) {
                $top_ifdef_inc[$level][$top_ifdef[$level]] = 1;
            }
        }

        # "`else"
        elsif ($words[0] eq "`else") {
            $top_ifdef_ignore[$level][$top_ifdef[$level]] = 1;
            if($top_ifdef[$level] > 0) {
                if($top_ifdef_ignore[$level][$top_ifdef[$level]] == 1 && $top_ifdef_inc[$level][$top_ifdef[$level]] == 0) {
                    if($top_ifdef_ignore[$level][($top_ifdef[$level]-1)] == 0) {
                        $top_ifdef_ignore[$level][$top_ifdef[$level]] = 0 ;
                    }
                }
                else {
                    $top_ifdef_ignore[$level][$top_ifdef[$level]] = 1;
                }
            }
            if ($top_ifdef_ignore[$level][$top_ifdef[$level]] == 0) {
                $top_ifdef_inc[$level][$top_ifdef[$level]] = 1;
            }
        }
        # "`endif"
        elsif ($words[0] eq "`endif") {
            $top_ifdef_ignore[$level][$top_ifdef[$level]] = 0;
            $top_ifdef_inc[$level][$top_ifdef[$level]] = 0;
            $top_ifdef[$level]--;
            $now_area = COM;
        }
        # skip line
        elsif ($top_ifdef_ignore[$level][$top_ifdef[$level]] == 1) {
        }
        # "`include"
        elsif ($words[0] eq "`include") {
            my $inc_name = $words[1];
            my $orgdir  = $nowdir;
            $inc_file = $nowdir . $inc_name;
            $nowdir = &get_dir($inc_file);
            &top_parse_2nd($inc_file, $level + 1); # recursive call
            $nowdir = $orgdir;
        }
        # "sub"
        elsif ($words[0] eq "sub") {

            $line =~ /^sub\s+(\S+)\s+(\S+)(.*)$/;
            $mod_file  = $1;
            $mod_inst  = $2;
            $mod_opt   = $3;
            $mod_fpath = &get_dir($mod_file);
            $mod_path  = "";
            $mod_rtl   = 0;
            $mod_macro = "";
            $mod_pfx   = "";
            $mod_flg   = 0;
            $sub_name  = "";
            $sub_tmpl_name = "";
            @mod_bind  = ();

            $mod_opt =~ s/^\s*//;
            if ($mod_opt ne "") {
                if ($mod_opt =~ /^([^-]\S*)(.*)/) {
                    $mod_path = $1;
                    $mod_opt = $2;
                }

                while ($mod_opt =~ /-([^-]+)/g) {
                    my $elm = $1;
                    $elm =~ s/\s*$//;
                    my $lhs = $elm;
                    my $rhs = "";
                    if ($elm =~ /(.*?)\s+(.*)/) {
                        $lhs = $1;
                        $rhs = $2;
                    }

                    if ($lhs eq "rtl") {
                        if ($rhs ne "") {
                            message("E202", $file, $line_num, "\"$words[0]\" has invalid format");
                        }
                        if ($mod_rtl == 1) {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        $mod_rtl = 1;
                        $mod_flg |= FLG_RTL;
                    }
                    elsif ($lhs eq "macro") {
                        if ($mod_macro ne "") {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($rhs eq "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        &check_format($rhs, 0, $file, $line_num);
                        $mod_macro = $rhs;
                    }
                    elsif ($lhs eq "port_pfx") {
                        if ($mod_pfx ne "") {
                            message("E207", $file, $line_num, "option [-$lhs] is set again");
                        }
                        if ($rhs eq "") {
                            message("E206", $file, $line_num, "option [-$lhs] is invalid");
                        }
                        $mod_pfx = $rhs;
                        $rhs =~ s/_$//g;
                        &check_namerule($rhs, 0, $file, $line_num);
                    }
                    elsif ($lhs eq "template_inst") {
                        $sub_tmpl_name = $rhs;
                    }
                    else {
                        message("E206", $file, $line_num, "option [-$lhs] is invalid");
                    }
                }

                if ($mod_rtl == 1) {
                    if (($mod_flg & FLG_RTL) && $sub_tmpl_name ne "") {
                        message("E807", $file, $line_num, "not support template for rtl module");
                    }
                    if ($mod_macro eq "") {
                        $mod_macro = "_MODE_RTL_" . uc $mod_inst;
                    }
                }
            }

            if( $mod_file ne "ctos_clock_gating.in" ) {
                $use_template = 0;
                &mod_parse($nowdir . $mod_file, 0);
            }
            else {
                &mod_parse($ctos_clock_gating_in, 0);
            }

            if ($sub_name eq "") {
                message("E113", $mod_file, 0, "no module is defined");
            }
            if ($use_template == 1) {
                $sub_name = $sub_tmpl_name;
                # change width and array according to template inst
                foreach $elm (@clk_list, @rst_list, @in_list, @out_list) {
                    if (@$elm[T_INST] eq $mod_inst) {
                        my $tmp1 = "";
                        my $tmp2 = "";
                        if (&is_template_parameter(@$elm[T_WID], \$tmp1)) {
                            my $new_tmpl = uc $sub_tmpl_name . "_@$elm[T_WID]";
                            #@$elm[T_WID] = $new_tmpl;
                            my $sc_type = "";
                            if (&is_template_parameter($new_tmpl, \$tmp2)) {
                                $sc_type = @$tmp2[G_SUBS];
                            }
                            else {
                                my @tmpl = @$tmp1;
                                foreach $elm1 (@tmpl_inst_list) {
                                    if (@$elm1[MOD_NAME] eq $sub_name) {
                                        foreach $elm2 (@{@$elm1[MOD_TMPL]}) {
                                            if (@$elm2[0] eq $tmpl[G_NAME]) {
                                                $tmpl[G_SUBS] = @$elm2[1];
                                                $tmpl[G_VALUE] = 0;
                                                last;
                                            }
                                        }
                                    }
                                }
                                $tmpl[G_NAME] = $new_tmpl; 
                                push(@template_list, [@tmpl]);
                                $sc_type = $tmpl[G_SUBS];
                            }
                            @$elm[T_TYPE] =~ s/^u//; 
                            $sc_type =~ /sc_(big)?(u)?int<\s*(\d+)\s*>/;
                            @$elm[T_WID] = $3;
                            @$elm[T_TYPE] = $2.@$elm[T_TYPE];
                            #print "XXX $$elm[T_NAME] $sc_type @$elm[T_TYPE] @$elm[T_WID]\n";
                        }
                        if (@$elm[T_ARRAY] ne "") {
                            my @dim = ();
                            while (@$elm[T_ARRAY] =~ /\w+/g) {
                                $num = $&;
                                if (&is_template_parameter($num, \$tmp1)) {
                                    my $new_tmpl = uc $sub_tmpl_name . "_$num";
                                    #$num = $new_tmpl;
                                    if (&is_template_parameter($new_tmpl, \$tmp2)) {
                                        $num = @$tmp2[G_VALUE];
                                    }
                                    else {
                                        my @tmpl = @$tmp1;
                                        foreach $elm1 (@tmpl_inst_list) {
                                            if (@$elm1[MOD_NAME] eq $sub_name) {
                                                foreach $elm2 (@{@$elm1[MOD_TMPL]}) {
                                                    if (@$elm2[0] eq $tmpl[G_NAME]) {
                                                        $tmpl[G_SUBS] = @$elm2[1];
                                                        $tmpl[G_VALUE] = @$elm2[1];
                                                        last;
                                                    }
                                                }
                                            }
                                        }
                                        $tmpl[G_NAME] = $new_tmpl; 
                                        push(@template_list, [@tmpl]);
                                        $num = $tmpl[G_VALUE];
                                    }
                                }
                                push(@dim, $num);
                            }
                            @$elm[T_ARRAY] = "";
                            foreach $i (@dim) {
                                @$elm[T_ARRAY] .= "[$i]";
                            }
                            #print "XXX $$elm[T_NAME] $sc_type @$elm[T_TYPE] @$elm[T_WID] @$elm[T_ARRAY]\n";
                        }
                    }
                }
            }
            &check_defined($sub_name, 0, $file, $line_num);
            if (&name_exist(\@mod_list, $sub_name)) {
                $mod_flg |= FLG_MULTI;
            }

            foreach $elm (@clk_list, @rst_list, @in_list, @out_list) {
                if (@$elm[T_INST] eq $mod_inst) {
                    $name_bind = @$elm[T_NAME];
                    $flg_bind      = 0;
                    $flg_bind_sync = 0;
                    $flg_tap       = 0;
                    $flg_fix       = 0;

                    # 1st priority: match signal & instance from bind list
                    foreach $tmp (@bind_list) {
                        if (@$tmp[B_PORT_S] eq @$elm[T_NAME]) {
                            if (@$tmp[B_INST_S] eq $mod_inst) {
                                @$tmp[B_FLG_S] |= FLG_USED;
                                if (@$elm[T_TYPE] =~ /out/) {
                                    $name_bind = @$tmp[B_SIG];
                                    $flg_bind = 1;
                                    if (@$tmp[B_FLG_E] & FLG_SYNC) {
                                        $flg_bind_sync = 1;
                                    }
                                    if (@$tmp[B_FLG_E] & FLG_FIX) {
                                        $flg_fix = 1;
                                    }
                                }
                            }
                        }

                        if (@$tmp[B_PORT_E] eq @$elm[T_NAME]) {
                            if (@$tmp[B_INST_E] eq $mod_inst) {
                                @$tmp[B_FLG_E] |= FLG_USED;
                                if (@$elm[T_TYPE] !~ /out/) {
                                    $name_bind = @$tmp[B_SIG];
                                    $flg_bind = 1;
                                    if (@$tmp[B_FLG_S] & FLG_SYNC) {
                                        $flg_bind_sync = 1;
                                    }
                                    if (@$tmp[B_FLG_S] & FLG_FIX) {
                                        $flg_fix = 1;
                                    }
                                }
                            }
                        }
                    }

                    # 2nd priority: match signal & instance from tap list
                    foreach $tmp (@tap_list) {
                        if (@$tmp[TAP_SIG] eq $name_bind && @$tmp[TAP_INST] eq $mod_inst) {
                            $name_bind = @$tmp[TAP_OUT];
                            @$tmp[TAP_USED] = 1;
                            $flg_tap = 1;
                            last;
                        }
                    }

                    # 3rd priority: match signal only from tap list
                    if ($flg_tap == 0) {
                        foreach $tmp (@tap_list) {
                            if (@$tmp[TAP_SIG] eq $name_bind && @$tmp[TAP_INST] eq "") {
                                $name_bind = @$tmp[TAP_OUT];
                                @$tmp[TAP_USED] = 1;
                                $flg_tap = 1;
                                last;
                            }
                        }
                    }

                    if ($mod_pfx ne "" && $flg_bind == 0 && $flg_tap == 0) {
                        $name_bind = $mod_pfx . $name_bind;
                    }

                    if (@$elm[T_ARRAY] eq "") {
                        $bind = "$tab$tab$mod_inst.@$elm[T_NAME]($name_bind);";
                        push(@mod_bind, $bind);
                    }
                    else {
                        my @dim = ();
                        while (@$elm[T_ARRAY] =~ /\w+/g) {
                            push(@dim, $&);
                        }
                        if ($mod_rtl == 1) {
                            $bind = "#ifndef $mod_macro";
                            push(@mod_bind, $bind);
                        }
                        for ($i = 0; $i < @dim; $i++) {
                            $bind = $tab x2 . $tab x$i . "for (int i$i = 0; i$i < $dim[$i]; i$i++) {";
                            push(@mod_bind, $bind);
                        }
                        $bind = $tab x2 . $tab x $i . "$mod_inst.@$elm[T_NAME]";
                        for ($i = 0; $i < @dim; $i++) {
                            $bind = $bind . "[i$i]";
                        }
                        $bind = $bind . "($name_bind";
                        for ($i = 0; $i < @dim; $i++) {
                            $bind = $bind . "[i$i]";
                        }
                        $bind = $bind . ");";
                        push(@mod_bind, $bind);

                        for ($i = @dim - 1; $i >= 0; $i--) {
                            $bind = $tab x2 . $tab x$i . "}";
                            push(@mod_bind, $bind);
                        }

                        if ($mod_rtl == 1) {
                            @dim = ();
                            while (@$elm[T_ARRAY] =~ /\w+/g) {
                                &get_array_info(\@dim, $&);
                            }
                            my $max = 1;
                            foreach $i (@dim) {
                                $max *= $i;
                            }
                            @mod = ();
                            $val = $max;
                            foreach $i (@dim) {
                                $val /= $i;
                                push(@mod, $val);
                            }
                            $bind = "#else";
                            push(@mod_bind, $bind);
                            for ($i = 0; $i < $max; $i++) {
                                $bind = $tab x2 . "$mod_inst.@$elm[T_NAME]";
                                for ($j = 0; $j < @mod; $j++) {
                                    $bind = $bind . "_" . int($i / $mod[$j]) % $dim[$j];
                                }
                                $bind = $bind . "($name_bind";
                                for ($j = 0; $j < @mod; $j++) {
                                    $bind = $bind . "[" . int($i / $mod[$j]) % $dim[$j] . "]";
                                }
                                $bind = $bind . ");";
                                push(@mod_bind, $bind);
                            }
                            $bind = "#endif";
                            push(@mod_bind, $bind);
                        }
                    }

                    if ($flg_bind && $flg_tap && @$elm[T_TYPE] !~ /out/) {
                        @$elm[T_NAME] = "";
                    }
                    elsif ($flg_bind_sync == 0) {
                        @$elm[T_NAME] = $name_bind;
                    }

                    if ($flg_fix) {
                        @$elm[T_NAME] = "";
                        $type = @$elm[T_TYPE];
                        if ($type =~ /(clock|reset)/) {
                            $type = "ureg";
                        }
                        else {
                            $type =~ s/(in|out)/reg/;
                        }
                        @reg = ("", $name_bind, "", $type, "", @$elm[T_ARRAY], @$elm[T_WID],
                                $name_bind, @$elm[T_FLG] | FLG_FIX, "", "", "", @$elm[T_DBG]);
                        push(@reg_list, [@reg]);
                    }
                }
            }

            for ($i = 0; $i < @mem_list; $i++) {
                $elm = $mem_list[$i];

                next if (@$elm[M_INST] ne $mod_inst);
                if (@$elm[M_PONLY] == 0) {
                    $bind = "#ifdef $mem_macro";
                    push(@mod_bind, $bind);
                }

                # find fix/float memory
                foreach $tmp (@bind_list) {
                    if (@$tmp[B_PORT_S] eq @$elm[M_NAME]) {
                        if (@$tmp[B_INST_S] eq $mod_inst) {
                            $name_bind = @$tmp[B_SIG];
                            @$elm[M_FIX] = 1;
                            $pair_exist = 0;
                            for ($j = $i + 1; $j < @mem_list; $j++) {
                                $pair = $mem_list[$j];
                                if (@$pair[M_NAME] eq @$elm[M_NAME] &&
                                    @$pair[M_INST] eq $mod_inst) {
                                    $pair_exist = 1;
                                }
                            }
                            if ($pair_exist == 0) {
                                @$tmp[B_FLG_S] |= FLG_USED;
                                @$tmp[B_PORT_S] = @$tmp[B_SIG];
                            }
                        }
                    }
                    elsif(@$tmp[B_PORT_E] eq @$elm[M_NAME]) {
                        if (@$tmp[B_INST_E] eq $mod_inst) {
                            message("E346", $file, 0, "not specify memory in end point of \"bind\"");
                        }
                    }
                }

                if (@$elm[M_FIX] == 0) {
                    $name_bind = "";
                    $name_bind = $mod_pfx . @$elm[M_NAME] if ($mod_pfx ne "");
                }
                $iprefix = "";
                $oprefix = "";

                # 1st priority: match name & instance from tap list
                foreach $tmp (@tap_list) {
                    if (@$tmp[TAP_SIG] eq @$elm[M_NAME] && @$tmp[TAP_INST] eq $mod_inst) {
                        $name_bind = @$tmp[TAP_OUT];
                        @$tmp[TAP_USED] = 1;
                        $iprefix = @$tmp[TAP_IPRE];
                        $oprefix = @$tmp[TAP_OPRE];
                        last;
                    }
                }

                # 2nd priority: match name only from tap list
                if ($name_bind eq "") {
                    foreach $tmp (@tap_list) {
                        if (@$tmp[TAP_SIG] eq @$elm[M_NAME] && @$tmp[TAP_INST] eq "") {
                            $name_bind = @$tmp[TAP_OUT];
                            @$tmp[TAP_USED] = 1;
                            $iprefix = @$tmp[TAP_IPRE];
                            $oprefix = @$tmp[TAP_OPRE];
                            last;
                        }
                    }
                }

                if ($name_bind ne "" && (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W)) {
                    message("E342", $file, $line_num,
                            "not support specifying tap for memory type of rw1:r|rw1:w");
                }

                if (@$elm[M_RW] == MA_RW1) {
                    $bind = &get_mem_topbind(\@$elm, MP1_AD, $name_bind, $oprefix);
                    push(@mod_bind, $bind);
                    $bind = &get_mem_topbind(\@$elm, MP1_WD, $name_bind, $oprefix);
                    push(@mod_bind, $bind);
                    $bind = &get_mem_topbind(\@$elm, MP1_RD, $name_bind, $iprefix);
                    push(@mod_bind, $bind);
                    $bind = &get_mem_topbind(\@$elm, MP1_WE, $name_bind, $oprefix);
                    push(@mod_bind, $bind);
                    if (@$elm[M_CS] > 0) {
                        $bind = &get_mem_topbind(\@$elm, MP1_CS, $name_bind, $oprefix);
                        push(@mod_bind, $bind);
                    }
                }
                elsif (@$elm[M_RW] == MA_RW1_W) {
                    $bind = &get_mem_topbind(\@$elm, MP1_WA, $name_bind, "");
                    push(@mod_bind, $bind);
                    $bind = &get_mem_topbind(\@$elm, MP1_WD, $name_bind, "");
                    push(@mod_bind, $bind);
                    $bind = &get_mem_topbind(\@$elm, MP1_WE, $name_bind, "");
                    push(@mod_bind, $bind);
                }
                elsif (@$elm[M_RW] == MA_RW1_R) {
                    $bind = &get_mem_topbind(\@$elm, MP1_RA, $name_bind, "");
                    push(@mod_bind, $bind);
                    $bind = &get_mem_topbind(\@$elm, MP1_RD, $name_bind, "");
                    push(@mod_bind, $bind);
                    if (@$elm[M_RE] > 0) {
                        $bind = &get_mem_topbind(\@$elm, MP1_RE, $name_bind, "");
                        push(@mod_bind, $bind);
                    }
                }
                elsif (@$elm[M_RW] == MA_R1W1_W) {
                    $bind = &get_mem_topbind(\@$elm, MP2_WA, $name_bind, $oprefix);
                    push(@mod_bind, $bind);
                    $bind = &get_mem_topbind(\@$elm, MP2_WD, $name_bind, $oprefix);
                    push(@mod_bind, $bind);
                    $bind = &get_mem_topbind(\@$elm, MP2_WE, $name_bind, $oprefix);
                    push(@mod_bind, $bind);
                    if (@$elm[M_CS] > 0) {
                        $bind = &get_mem_topbind(\@$elm, MP2_CS, $name_bind, $oprefix);
                        push(@mod_bind, $bind);
                    }
                    if (@$elm[M_BE] > 0) {
                        $bind = &get_mem_topbind(\@$elm, MP2_BE, $name_bind, $oprefix);
                        push(@mod_bind, $bind);
                    }
                }
                elsif (@$elm[M_RW] == MA_R1W1_R) {
                    $bind = &get_mem_topbind(\@$elm, MP2_RA, $name_bind, $oprefix);
                    push(@mod_bind, $bind);
                    $bind = &get_mem_topbind(\@$elm, MP2_RD, $name_bind, $iprefix);
                    push(@mod_bind, $bind);
                    if (@$elm[M_RE] > 0) {
                        $bind = &get_mem_topbind(\@$elm, MP2_RE, $name_bind, $oprefix);
                        push(@mod_bind, $bind);
                    }
                }
                elsif (@$elm[M_RW] == MA_RW2_A) {
                    $bind = &get_mem_topbind(\@$elm, MPA_AD, $name_bind, $oprefix);
                    push(@mod_bind, $bind);
                    $bind = &get_mem_topbind(\@$elm, MPA_WD, $name_bind, $oprefix);
                    push(@mod_bind, $bind);
                    $bind = &get_mem_topbind(\@$elm, MPA_RD, $name_bind, $iprefix);
                    push(@mod_bind, $bind);
                    $bind = &get_mem_topbind(\@$elm, MPA_WE, $name_bind, $oprefix);
                    push(@mod_bind, $bind);
                    if (@$elm[M_CS] > 0) {
                        $bind = &get_mem_topbind(\@$elm, MPA_CS, $name_bind, $oprefix);
                        push(@mod_bind, $bind);
                    }
                }
                elsif (@$elm[M_RW] == MA_RW2_B) {
                    $bind = &get_mem_topbind(\@$elm, MPB_AD, $name_bind, $oprefix);
                    push(@mod_bind, $bind);
                    $bind = &get_mem_topbind(\@$elm, MPB_WD, $name_bind, $oprefix);
                    push(@mod_bind, $bind);
                    $bind = &get_mem_topbind(\@$elm, MPB_RD, $name_bind, $iprefix);
                    push(@mod_bind, $bind);
                    $bind = &get_mem_topbind(\@$elm, MPB_WE, $name_bind, $oprefix);
                    push(@mod_bind, $bind);
                    if (@$elm[M_CS] > 0) {
                        $bind = &get_mem_topbind(\@$elm, MPB_CS, $name_bind, $oprefix);
                        push(@mod_bind, $bind);
                    }
                }

                @$elm[M_NAME] = $name_bind if ($name_bind ne "");
                &check_defined(@$elm[M_NAME], 0, $file, $line_num);
                &check_defined_tb(@$elm[M_NAME], 0, $file, $line_num);

                if (@$elm[M_PONLY] == 0) {
                    $bind = "#endif";
                    push(@mod_bind, $bind);
                }

                if ($iprefix ne "") {
                    if (@$elm[M_RW] == MA_RW1   || @$elm[M_RW] == MA_R1W1_R ||
                        @$elm[M_RW] == MA_RW2_A || @$elm[M_RW] == MA_RW2_B) {
                        @$elm[M_IPRE] = $iprefix;
                    }
                    elsif (@$elm[M_RW] == MA_R1W1_W && @$elm[M_IPRE] ne "") {
                        @$elm[M_IPRE] = $iprefix;
                    }
                }
                if ($oprefix ne "") {
                    if (@$elm[M_RW] == MA_RW1    || @$elm[M_RW] == MA_R1W1_W ||
                        @$elm[M_RW] == MA_R1W1_R || @$elm[M_RW] == MA_RW2_A  ||
                        @$elm[M_RW] == MA_RW2_B) {
                        @$elm[M_OPRE] = $oprefix;
                    }
                }
            }

            my @mod_data = ($comment, $sub_name, $mod_flg, $mod_inst, $mod_path, $mod_macro, $top_dbg, [@mod_tmpl_list], @mod_bind);
            push(@mod_list, [@mod_data]);
        }
        elsif ($words[0] eq "#ifdef") {
            $top_dbg = $words[1];
        }
        elsif ($words[0] eq "#endif") {
            $top_dbg = "";
        }
    }
    close(IN);
}

##
## post check
##
sub post_check {
    # check scope
    #if ($free_area == 1 || $top_free_are == 1) {
    #    message("E019", "", 0, "\"--!\" should be set");
    #}
    #elsif ($ifdef > 1 || $top_ifdef > 0) {
    #    message("E012", "", 0, "\"`endif\" should be set");
    #}
    #elsif ($now_area != COM) {
    #    message("E015", "", 0, "\"#endif\" should be set");
    #}
    if ($now_area != COM) {
        message("E015", "", 0, "\"#endif\" should be set");
    }

    # check `define macro
    #my $define_list = ($top_mode != 0) ? \@define_in_top_list : \@define_in_list;
    #foreach $elm (@$define_list) {
    #    next if (@$elm[G_NAME] eq "SIM_EQ_MAX_CNT" && $opt_sim_eq);
    #    if ((@$elm[G_FLAG] & FLG_USED) == 0) {
    #        message("W001", $infile, 0,
    #            "`define macro name \"@$elm[G_NAME]\" is not used");
    #    }
    #}

    # check -pipe option & -header option
    if ($use_pipe && $use_hdr) {
        message("W003", $infile, 0,
                "not recommend to specify \"-header/-reset_header/-wait_header/-sync_header\"".
                " with specifying -pipe option to cthread");
    }

    # check style parameters
    if ($style_module eq "") {
         $style_module = "sc";
    }
    if ($style_alloc eq "") {
         $style_alloc = "static";
    }
    if ($tab eq "") {
        $tab = "    ";
    }
    if ($vcd_trace eq "") {
         $vcd_trace = 1;
    }
    if ($toggle_cov_mode eq "") {
        $toggle_cov_mode = 0;
    }
    if ($wait_expand eq "") {
        $wait_expand = 0;
    }

    # check environment parameters
    if ($env_systemc eq "") {
        $env_systemc = $def_systemc;
    }
    if ($env_vcs eq "") {
        $env_vcs = $def_vcs;
    }
    if ($env_ies eq "") {
        $env_ies = $def_ies;
    }
    if ($env_vipcat eq "") {
        $env_vipcat = $def_vipcat;
    }
    if ($env_ctos eq "") {
        $env_ctos = $def_ctos;
    }
    if ($env_stratus eq "") {
        $env_stratus = $def_stratus;
    }
    if ($env_ies_eq eq "") {
        $env_ies_eq = $def_ies_eq;
    }
    if ($env_jg_eq eq "") {
        $env_jg_eq = $def_jg_eq;
    }
    if ($env_slec eq "") {
        $env_slec = $def_slec;
    }
    if ($env_vcs_gcc eq "") {
        $env_vcs_gcc = $def_vcs_gcc;
    }
    if ($env_ssgen eq "") {
        $env_ssgen = $def_ssgen;
    }
    if ($env_1team eq "") {
        $env_1team = $def_1team;
    }
    if ($env_sschk eq "") {
        $env_sschk = $def_sschk;
    }
    if ($env_ovrflw eq "") {
        $env_ovrflw = $def_ovrflw;
    }
    if ($env_cpp2ins eq "") {
        $env_cpp2ins = $def_cpp2ins;
    }

    # check module list of top_mode
    if ($top_mode == 1 && @mod_list < 1) {
        message("E111", $infile, 0, "define 1 \"sub\" commands or more");
    }

    # check module name
    if ($module_name eq "") {
        message("E113", $infile, 0, "no module is defined");
    }

    # check cthread/method
    my $head_thnm;
    if ($top_mode == 0) {
        if (@thread_list == 0) {
            #message("E110", $infile, 0, "no SC_CTHREAD is defined");
            if (@method_list == 0) {
                message("E110", $infile, 0, "no valid SC_CTHREAD/SC_METHOD is defined");
            }
            if (@clk_list != 0 || @rst_list != 0 || @ev_list != 0 || @mem_list != 0) {
                message("E115", $infile, 0, "clock/reset/ev/mem should not be set to module with only SC_METHOD");
            }
            if ($toggle_cov_mode != 0) {
                message("W004", $infile, 0, "toggle coverage is not supported in module with only SC_METHOD");
            }
        }
        else {
            if ($use_valid_thread == 0 && @method_list == 0) {
                message("E110", $infile, 0, "no valid SC_CTHREAD/SC_METHOD is defined");
            }
            if ($use_valid_thread == 1 && (@{$thread_list[0]}[TH_FLG] & FLG_DUMMY)) {
                message("E116", $infile, 0, "valid SC_CTHREAD must be defined first");
            }
            $head_thnm = @{$thread_list[0]}[TH_NAME];
            foreach $elm (@thread_list) {
                my $arst_cnt = 0;
                if (@$elm == TH_RST) {
                    foreach $rst (@rst_list) {
                        if (@$rst[T_TYPE] eq "soft_reset") {
                            if (@$rst[T_FLG] & FLG_USED) {
                                message("E412", $infile, 0,
                                        "soft reset \"@$rst[T_NAME]\" should not be set to multiple thread");
                            }
                            @$rst[T_TH] = @$elm[TH_NAME];
                        }
                        elsif(@$rst[T_TYPE] eq "areset") {
                            $arst_cnt++;
                            if($arst_cnt > 1) {
                                message("E106", $infile, 0, "areset should be defined in \"@$elm[TH_NAME]\" only once");
                            }
                        }
                        @$rst[T_FLG] |= FLG_USED;
                    }
                }
                elsif (lc @$elm[TH_RST] ne "n") {
                    $extrst_flg = 0;
                    $arst_pos = TH_RST;
                    for ($i = TH_RST; $i < @$elm; $i++) {
                        $name = @$elm[$i];
                        if (&name_exist(\@rst_list, $name, \$rst)) {
                            if (@$rst[T_TYPE] eq "soft_reset") {
                                if (@$rst[T_FLG] & FLG_USED) {
                                    message("E412", $infile, 0,
                                            "soft reset \"$name\" should not be set to multiple thread");
                                }
                                @$rst[T_TH] = @$elm[TH_NAME];
                            }
                            else {
                                $extrst_flg = 1;
                                if (@$rst[T_TYPE] eq "areset") {
                                    $arst_pos = $i;
                                    $arst_cnt++;
                                    if($arst_cnt > 1) {
                                        message("E106", $infile, 0, "areset should be defined in \"@$elm[TH_NAME]\" only once");
                                    }
                                }
                            }
                            @$rst[T_FLG] |= FLG_USED;
                        }
                        else {
                            message("E327", $infile, 0, "reset \"$name\" does not exist");
                        }
                    }
                    if ($extrst_flg == 0) {
                        message("E338", $infile, 0,
                                "\"@$elm[TH_NAME]\" has only soft reset as reset");
                    }
                    if ($arst_pos != TH_RST) {
                        @tmp = splice(@$elm, $arst_pos, 1);
                        splice(@$elm, TH_RST, 0, @tmp);
                    }
                }

                if (lc @$elm[TH_RST] eq "n" || @rst_list == 0) {
                    message("W002", $infile, 0, "thread \"@$elm[TH_NAME]\": no reset is defined");
                }

                if (&need_osci_reset($elm) == 1) {
                    $need_osci = 1;
                }
            }

            #toggle coverage
            if ($toggle_cov_mode != 0) {
                foreach $elm (@in_list, @out_list) {
                    next if (@$elm[T_TYPE] =~ /out/ && $toggle_cov_mode == 2);
                    next if (@$elm[T_TYPE] =~ /in/  && $toggle_cov_mode == 3);
                    my @t_var_elm = ();
                    $now_macro = $cov_macro;
                    my $t_var_name = "mCov_" . @$elm[T_NAME];
                    my $t_var_type = (@$elm[T_TYPE] =~ /^u(in|out)$/) ? "uvar" : "svar";
                    &check_format($t_var_name, 0, $file, 0);
                    &check_defined($t_var_name, 0, $file, 0);
                    @t_var_elm = ("", $t_var_name, "", $t_var_type, "0", @$elm[T_ARRAY], @$elm[T_WID],
                            "", @$elm[T_FLG], $head_thnm, "", "", $cov_macro, "");
                    &insert_macro_data("data", \@t_var_elm);
                }
            }

            foreach $elm (@rst_list, @in_list, @out_list, @out_list_slecbb,
                    @reg_list, @var_list, @ctype_list, @ev_list) {
                next if (@$elm[T_TYPE] =~ /^(areset|sreset)$/);
                $find = 0;
                @$elm[T_TH] = $head_thnm if (@$elm[T_TH] eq "");
                next if (@$elm[T_TYPE] =~ /^(uin|sin)$/);
                foreach $th (@thread_list) {
                    if (@$elm[T_TH] eq @$th[TH_NAME]) {
                        $find = 1;
                        if (@$elm[T_FLG] & FLG_VAR2REG) {
                            @$th[TH_FLG] |= FLG_VAR2REG;
                        }
                        if (@$elm[T_FLG] & FLG_SLECBB) {
                            @$th[TH_FLG] |= FLG_SLECBB;
                        }
                        if (@$elm[T_TYPE] =~ /ev$/) {
                            @$th[TH_FLG] |= FLG_EV;
                        }
                        last;
                    }
                }
                if ($find == 0) {
                    message("E329", $infile, 0, "\"@$elm[T_TH]\" does not exist in module");
                }
            }

            foreach $m (@data_list_m) {
                $macro = shift(@$m);
                foreach $elm (@$m) {
                    $find = 0;
                    @$elm[T_TH] = $head_thnm if (@$elm[T_TH] eq "");
                    foreach $th (@thread_list) {
                        if (@$elm[T_TH] eq @$th[TH_NAME]) {
                            $find = 1;
                            if (@$elm[T_FLG] & FLG_DTRACE) {
                                @$th[TH_FLG] |= FLG_DTRACE;
                            }
                            last;
                        }
                    }
                    if ($find == 0) {
                        message("E329", $infile, 0, "\"@$elm[T_TH]\" does not exist in module");
                    }
                }
                unshift(@$m, $macro);
            }
        }
    }

    # check memory model
    $need_mem_rw1 = 0;
    $need_mem_r1w1 = 0;
    $need_mem_r1w1_2clk = 0;
    $need_mem_r1w1_be = 0;
    $need_mem_r1w1_2clk_be = 0;
    $need_mem_rw2 = 0;
    my $suf_path_elm  = "";
    my $suf_path_pair = "";
    for ($i = 0; $i < @mem_list; $i++) {
        $elm = $mem_list[$i];
        next if(@$elm[M_FIX] == 1);
        if ($top_mode == 0) {
            $find = 0;
            @$elm[M_TH] = $head_thnm if (@$elm[M_TH] eq "");
            foreach $th (@thread_list) {
                if (@$elm[M_TH] eq @$th[TH_NAME]) {
                    $find = 1;
                    last;
                }
            }
            if ($find == 0) {
                message("E329", $infile, 0, "\"@$elm[M_TH]\" does not exist in module");
            }
        }
        if (@$elm[M_SHARE] == 0) {
            if (@$elm[M_SUF] =~ /.*\/(.*)/) {
                $suf_path_elm = $1;
            }
            else {
                $suf_path_elm = @$elm[M_SUF];
            }
            for ($j = $i + 1; $j < @mem_list; $j++) {
                $pair = $mem_list[$j];
                next if(@$pair[M_FIX] == 1);
                if (@$elm[M_NAME] eq @$pair[M_NAME]) {
                    @$elm[M_SHARE]++;
                    @$pair[M_SHARE]++;
                    if (@$elm[M_SHARE] > 1) {
                        message("E401", "", 0, "not support multiple access to one " .
                         "memory \"@$elm[M_NAME]\" except for R/W or DP access");
                    }
                    else {
                        &check_memtype_match(@$elm[M_NAME], @$elm[M_RW], @$pair[M_RW]);
                    }

                    if (@$pair[M_SUF] =~ /.*\/(.*)/) {
                        $suf_path_pair = $1;
                    }
                    else {
                        $suf_path_pair = @$pair[M_SUF];
                    }

                    if (@$elm[M_RW] & MA_1PORT) {
                        $memtype = "single port";
                    }
                    elsif (@$elm[M_RW] & MA_2PORT) {
                        $memtype = "2port";
                    }
                    else {
                        $memtype = "dual port";
                    }

                    if ((@$elm[M_SIGN] != @$pair[M_SIGN])
                     || (@$elm[M_WID]  ne @$pair[M_WID])
                     || (@$elm[M_SIZE] ne @$pair[M_SIZE])
                     || (@$elm[M_LAT]  ne @$pair[M_LAT])
                     || (@$elm[M_OPRE] ne @$pair[M_OPRE])
                     || (@$elm[M_PONLY] != @$pair[M_PONLY])
                     || (@$elm[M_INIT] ne @$pair[M_INIT])
                     || ($suf_path_elm ne $suf_path_pair))
                    {
                        message("E402", "", 0,
                         "$memtype memory \"@$elm[M_NAME]\" has incompatible setting between R/W or DP");
                    }
                    if (@$elm[M_RW] & MA_1PORT) {
                        if (@$elm[M_CLKR] ne @$pair[M_CLKW] || @$elm[M_CLKW] ne @$pair[M_CLKR]) {
                            message("E402", "", 0,
                             "$memtype memory \"@$elm[M_NAME]\" has incompatible setting between R/W");
                        }
                    }
                    elsif (@$elm[M_RW] & MA_DPORT) {
                        if (@$elm[M_IPRE] ne @$pair[M_IPRE]) {
                            message("E402", "", 0,
                             "$memtype memory \"@$elm[M_NAME]\" has incompatible setting between R/W or DP");
                        }
                    }
                    if (@$elm[M_RW] == MA_R1W1_R || @$elm[M_RW] == MA_RW1_R) {
                        @$elm[M_WE] = @$pair[M_WE];
                        if (@$elm[M_RW] == MA_R1W1_R) {
                            @$elm[M_CS] = @$pair[M_CS];
                        }
                        else {
                            @$elm[M_CS] = @$elm[M_RE];
                        }
                        @$pair[M_RE] = @$elm[M_RE];

                        @$elm[M_CLKW] = @$pair[M_CLKW];
                        @$pair[M_CLKR] = @$elm[M_CLKR];
                    }
                    elsif (@$elm[M_RW] == MA_R1W1_W || @$elm[M_RW] == MA_RW1_W) {
                        @$elm[M_RE] = @$pair[M_RE];
                        @$pair[M_WE] = @$elm[M_WE];
                        if (@$elm[M_RW] == MA_R1W1_W) {
                            @$pair[M_CS] = @$elm[M_CS];
                            @$pair[M_BE] = @$elm[M_BE];
                        }
                        else {
                            @$elm[M_CS] = @$pair[M_RE];
                        }

                        @$elm[M_CLKR] = @$pair[M_CLKR];
                        @$pair[M_CLKW] = @$elm[M_CLKW];
                    }
                }
            }
        }
        if (@$elm[M_INIT] eq "rand") {
            $use_rand = 1;
        }
    }

    if ($top_mode == 1) {
        # sub check
        foreach $elm (@mod_list) {
            if (@$elm[MOD_DBG] ne "") {
                foreach $elm2 (@mod_list) {
                    if (@$elm2[MOD_DBG] eq "" && @$elm[MOD_NAME] eq @$elm2[MOD_NAME]) {
                        message("E415", $infile, 0,
                            "don't specify sub \"@$elm[MOD_NAME]\" inside #ifdef that is specifed" .
                            " also outside");
                    }
                }
            }
        }

        # sub inside #ifdef check
        foreach $elm (@clk_list, @rst_list, @in_list) {
            if (@$elm[T_NAME] ne "" && (@$elm[T_FLG] & FLG_IFDEF)) {
                my $hit = 0;
                foreach $elm2 (@clk_list, @rst_list, @in_list, @out_list) {
                    if (!(@$elm2[T_FLG] & FLG_IFDEF) && @$elm[T_NAME] eq @$elm2[T_NAME]) {
                        $hit = 1;
                        last;
                    }
                }
                if ($hit == 0) {
                    message("E416", $infile, 0,
                        "port \"@$elm[T_ONAME]\" of \"@$elm[T_INST]\" in #ifdef should be bound to the other port");
                }
            }
        }

        # bind sync 1st check
        foreach $elm (@bind_list) {
            if (@$elm[B_FLG_S] & FLG_SYNC) {
                foreach $in (@in_list) {
                    next if (@$in[T_NAME] ne @$elm[B_PORT_E]);
                    next if (@$in[T_INST] ne @$elm[B_INST_E]);
                    if (@$in[T_WID] ne "b" && @$elm[B_PORT_EN] eq "") {
                        message("E417", $infile, 0,
                            "2-FF asychronous binding should not be bus signal \"@$elm[B_SIG]\"");
                    }
                    @$in[T_NAME] = @$elm[B_PORT_S];
                }
            }

            next if (!(@$elm[B_FLG_S] & FLG_SYNC_EN));
            $find = 0;
            if (@$elm[B_INST_EN] eq "") {
                $en_cnt = 0;
                foreach $tmp (@out_list) {
                    if (@$tmp[T_NAME] eq @$elm[B_PORT_EN]) {
                        @$elm[B_INST_EN] = @$tmp[T_INST];
                        $en_cnt++;
                        $find = 1;
                    }
                }
                if ($find == 0) {
                    message("E331", $infile, 0,
                            "bind target \"@$elm[B_PORT_EN]\" does not exist in any instances");
                }
                if ($en_cnt > 1) {
                    message("E406", $infile, 0, "signal \"@$elm[B_PORT_EN]\"" .
                            " is driven from multiple modules");
                }
            }
            else {
                &get_port_data(@$elm[B_INST_EN], @$elm[B_PORT_EN], \$port_en);
                if (@$port_en[T_NAME] eq "") {
                    message("E331", $infile, 0,
                            "bind target \"@$elm[B_PORT_EN]\" does not exist in instance \"@$elm[B_INST_EN]\"");
                }
                if (@$port_en[T_TYPE] !~ /out/) {
                    message("E332", $infile, 0,
                            "start point \"@$elm[B_PORT_EN]\" is not output port of instance \"@$elm[B_INST_EN]\"");
                }
                if (@$port_en[T_ARRAY] ne "") {
                    message("E334", $infile, 0,
                            "enable signal \"@$elm[B_PORT_EN]\" for multi-bit asynchronous binding should not be array");
                }
            }
            $find = 0;
            foreach $elm2 (@sync_list) {
                next if (@$elm2[S_INST] ne @$elm[B_INST_S]);
                if (@$elm2[S_FLG] & FLG_MULTI) {
                    next if (@$elm2[S_INVAL] ne (@$elm[B_INST_EN] . "_" . @$elm[B_PORT_EN]));
                }
                else {
                    next if (@$elm2[S_INVAL] ne @$elm[B_PORT_EN]);
                }
                if (((@$elm[B_FLG_S] & FLG_SYNC_LVL) && (@$elm2[S_FLG] & FLG_SYNC_LVL)) ||
                    ((@$elm[B_FLG_S] & FLG_SYNC_POS) && (@$elm2[S_FLG] & FLG_SYNC_POS)) ||
                    ((@$elm[B_FLG_S] & FLG_SYNC_NEG) && (@$elm2[S_FLG] & FLG_SYNC_NEG)) ||
                    ((@$elm[B_FLG_S] & FLG_SYNC_TOG) && (@$elm2[S_FLG] & FLG_SYNC_TOG)) )

                {
                    if (@$elm2[S_FLG] & FLG_SYNC_OUT) {
                        $en_name = @$elm2[S_ONAME];
                    }
                    else {
                        $en_name = (@$elm2[S_FLG] & FLG_SYNC_LVL) ? @$elm2[S_NAME] . "_ff1" : @$elm2[S_NAME];
                    }
                    $find = 1;
                    last;
                }
            }
            if ($find == 0) {
                my $s_flg   = @$elm[B_FLG_S] ^ FLG_SYNC_EN;
                my $s_inval = ($s_flg & FLG_MULTI) ? @$elm[B_INST_EN] . "_" . @$elm[B_PORT_EN]
                                                   : @$elm[B_PORT_EN];
                my $s_name  = "";
                if ($s_flg & FLG_SYNC_POS) {
                    $s_name = "sync_" . $s_inval . "_posedge";
                }
                elsif ($s_flg & FLG_SYNC_NEG) {
                    $s_name = "sync_" . $s_inval . "_negedge";
                }
                elsif ($s_flg & FLG_SYNC_TOG) {
                    $s_name = "sync_" . $s_inval . "_toggle";
                }
                else {
                    $s_name = "sync_" . $s_inval;
                }
                my @sync_new = ("", $s_name, $s_inval, "", "", $s_flg, @$elm[B_INST_S], "");
                push(@sync_list, [@sync_new]);
                $en_name = ($s_flg & FLG_SYNC_LVL) ? $s_name . "_ff1" : $s_name;

                my $b_inst_s = @$elm[B_INST_EN];
                my $b_port_s = @$elm[B_PORT_EN];
                my $b_inst_e = @$elm[B_INST_S];
                my $b_port_e = $s_inval;
                my $b_sig    = $s_inval;
                my $b_flg_s  = @$elm[B_FLG_S] ^ (FLG_SYNC | FLG_SYNC_EN);
                my $b_flg_e  = @$elm[B_FLG_S] ^ FLG_SYNC_EN;
                if ($b_flg_e & FLG_USED_SIG) {
                    $b_flg_e ^= FLG_USED_SIG;
                }
                my @bind_data = ("", $b_inst_s, $b_port_s, $b_inst_e, $b_port_e,
                        $b_sig, $b_flg_s, $b_flg_e, "", "");
                push(@bind_list, [@bind_data]);
                foreach $mod (@mod_list) {
                    next if (@$mod[MOD_INST] ne @$elm[B_INST_EN]);
                    for ($i=MOD_BIND; $i<@$mod; $i++) {
                        @$mod[$i] =~ s/\($b_port_s\)/\($b_sig\)/;
                    }
                }

                # for checker module
                $b_flg_e  = ($b_flg_e | FLG_SYNC_CHK) ^ FLG_SYNC;
                $b_inst_e =~ s/sync_/chk_/;
                @bind_data = ("", $b_inst_s, $b_port_s, $b_inst_e, $b_port_e,
                             $b_sig, $b_flg_s, $b_flg_e, "", "");
                push(@bind_list, [@bind_data]);
            }
            foreach $elm2 (@sync_list) {
                next if (@$elm2[S_INST] ne @$elm[B_INST_S]);
                next if (@$elm2[S_ONAME] ne @$elm[B_SIG]);
                @$elm2[S_EN] = $en_name;
                #last;
            }
        }

        # bind sync 2nd check
        my @s_elm = ();
        foreach $elm (@sync_list) {
            foreach $out (@out_list) {
                next if ((@$elm[S_INVAL] ne (@$out[T_INST] . "_" . @$out[T_NAME]))
                        && (@$elm[S_INVAL] ne @$out[T_NAME]));
                @$out[T_NAME] = @$elm[S_INVAL];
                $type   = @$out[T_TYPE];
                $enable = (@$elm[S_FLG] & FLG_SYNC_EN) ? @$elm[S_EN] : "";
                $init   = (@$elm[S_FLG] & FLG_SYNC_EN) ? @$out[T_INIT] : "n";
                my $port_t = "";
                if ((@$elm[S_FLG] & FLG_SYNC_OUT) || (@$elm[S_FLG] & FLG_SYNC_EN)) {
                    &get_port_data(@$elm[S_INST], @$elm[S_ONAME], \$port_t);
                    if (@$port_t[T_NAME] eq "") {
                        @s_elm = ("", @$elm[S_ONAME], @$elm[S_INST], $type, $init, @$out[T_ARRAY],
                                @$out[T_WID], @$elm[S_ONAME], @$elm[S_FLG], "", "", "", "", $enable);
                        push(@out_list_sync, [@s_elm]);
                        # toggle coverage
                        if ($toggle_cov_mode == 1 || $toggle_cov_mode == 3) {
                            my @t_var_elm = ();
                            $now_macro = $cov_macro;
                            $t_var_name = "mCov_" .  @$elm[S_ONAME];
                            $t_var_type = ($type =~ /^uout$/) ? "uvar" : "svar";
                            @t_var_elm = ("", $t_var_name, @$elm[S_INST], $t_var_type, ($init eq "n" ? 0 : $init),
                                        @$out[T_ARRAY], @$out[T_WID], "", @$elm[S_FLG], "", "", "", $cov_macro, "");
                            &insert_macro_data("data", \@t_var_elm);
                        }
                    }
                }
                $type =~ s/out/in/;
                $port_t = "";
                &get_port_data(@$elm[S_INST], @$elm[S_INVAL], \$port_t);
                if (@$port_t[T_NAME] eq "") {
                    $init = @$out[T_INIT];
                    $flg  = (@$elm[S_FLG] & FLG_USED) ? @$elm[S_FLG] ^ FLG_USED : @$elm[S_FLG];
                    @s_elm = ("", @$elm[S_INVAL], @$elm[S_INST], $type, $init, @$out[T_ARRAY],
                            @$out[T_WID], @$elm[S_INVAL], $flg, "", "", "", "", $enable);
                    push(@in_list_sync, [@s_elm]);
                    # toggle coverage
                    if ($toggle_cov_mode == 1 || $toggle_cov_mode == 2) {
                        my @t_var_elm = ();
                        $now_macro = $cov_macro;
                        $t_var_name = "mCov_" .  @$elm[S_INVAL];
                        $t_var_type = ($type =~ /^uin$/) ? "uvar" : "svar";
                        @t_var_elm = ("", $t_var_name, @$elm[S_INST], $t_var_type, $init, @$out[T_ARRAY],
                                @$out[T_WID], "", $flg, "", "", "", $cov_macro, "");
                        &insert_macro_data("data", \@t_var_elm);
                    }
                }

                $type =~ s/in/reg/;
                if (!(@$elm[S_FLG] & FLG_SYNC_EN)) {
                    @s_elm = ("", "sync_" . @$elm[S_INVAL] . "_ff0", @$elm[S_INST], $type,
                            $init, @$out[T_ARRAY], @$out[T_WID], "", @$elm[S_FLG], "", "", "", "", "");
                    push(@reg_list_sync, [@s_elm]);
                    @s_elm = ("", "sync_" . @$elm[S_INVAL] . "_ff1", @$elm[S_INST], $type,
                            $init, @$out[T_ARRAY], @$out[T_WID], "", @$elm[S_FLG], "", "", "", "", "");
                    push(@reg_list_sync, [@s_elm]);
                    if (!(@$elm[S_FLG] & FLG_SYNC_LVL)) {
                        @s_elm = ("", "sync_" . @$elm[S_INVAL] . "_ff2", @$elm[S_INST], $type,
                                $init, @$out[T_ARRAY], @$out[T_WID], "", @$elm[S_FLG], "", "", "", "", "");
                        push(@reg_list_sync, [@s_elm]);
                        if (!(@$elm[S_FLG] & FLG_SYNC_OUT)) {
                            my $s_name = "";
                            if (@$elm[S_FLG] & FLG_SYNC_POS) {
                                $s_name = "sync_" . @$elm[S_INVAL] . "_posedge";
                            }
                            elsif (@$elm[S_FLG] & FLG_SYNC_NEG) {
                                $s_name = "sync_" . @$elm[S_INVAL] . "_negedge";
                            }
                            else {
                                $s_name = "sync_" . @$elm[S_INVAL] . "_toggle";
                            }
                            @s_elm = ("", $s_name, @$elm[S_INST], $type, "n", @$out[T_ARRAY],
                                        @$out[T_WID], "", @$elm[S_FLG], "", "", "", "", "");
                            push(@reg_list_sync, [@s_elm]);
                        }
                    }
                }
            }
        }

        # bind sync 3rd check - for checker module
        foreach $mod (@mod_list_sync) {
            next if (@$mod[MOD_DBG] eq "");
            my $tx_clk = "";
            my $rx_clk = "";
            my $tx_rst = "";
            my $rx_rst = "";
            $inst = @$mod[MOD_INST];
            $use_rx_thread = 0;
            foreach $clk (@clk_list_sync) {
                next if (@$clk[T_INST] ne $inst);
                if ($tx_clk eq "") {
                    $tx_clk = @$clk[T_NAME];
                }
                elsif ($rx_clk eq "") {
                    $rx_clk = @$clk[T_NAME];
                }
            }
            foreach $rst (@rst_list_sync) {
                next if (@$rst[T_INST] ne $inst);
                if ($tx_rst eq "") {
                    $tx_rst = @$rst[T_NAME];
                }
                elsif ($rx_rst eq "") {
                    $rx_rst = @$rst[T_NAME];
                }
            }
            foreach $bind (@bind_list) {
                next if (@$bind[B_INST_E] ne $inst);
                foreach $out (@out_list) {
                    next if (@$out[T_INST] ne @$bind[B_INST_S]);
                    next if ((@$out[T_NAME] ne @$bind[B_PORT_S]) &&
                             (@$out[T_NAME] ne (@$bind[B_INST_S] . "_" . @$bind[B_PORT_S])));
                    $type  = @$out[T_TYPE];
                    $init  = @$out[T_INIT];
                    $name  = @$out[T_NAME];
                    $array = @$out[T_ARRAY];
                    $wid   = @$out[T_WID];
                    #$flg   = @$out[T_FLG] | FLG_SYNC_CHK;
                    $flg   = @$bind[B_FLG_E] | FLG_SYNC_CHK;
                    $en    = (@$bind[B_FLG_E] & FLG_MULTI) ? @$bind[B_INST_EN] . "_" . @$bind[B_PORT_EN]
                                                           : @$bind[B_PORT_EN];
                    $type =~ s/out/in/;
                    $flg  |= FLG_SYNC_EN if (@$bind[B_PORT_EN] ne "");
                    @s_elm = ("", $name, $inst, $type, $init, $array,
                            $wid, $name, $flg, "", "", "", "", $en);
                    push(@in_list_sync, [@s_elm]);

                    $type =~ s/in/reg/;
                    if (!($flg & FLG_SYNC_EN)) {
                        @s_elm = ("", $name . "_" . $tx_clk . "_ff0", $inst, $type, $init, $array,
                                $wid, $name, $flg, $tx_clk . "_thread", "", "", "", "");
                        push(@reg_list_sync, [@s_elm]);
                        @s_elm = ("", $name . "_" . $tx_clk . "_ff1", $inst, $type, $init, $array,
                                $wid, $name, $flg, $tx_clk . "_thread", "", "", "", "");
                        push(@reg_list_sync, [@s_elm]);
                        @s_elm = ("", $name . "_" . $tx_clk . "_ff2", $inst, $type, $init, $array,
                                $wid, $name, $flg, $tx_clk . "_thread", "", "", "", "");
                        push(@reg_list_sync, [@s_elm]);
                    }
                    else {
                        @s_elm = ("", $en . "_" . $rx_clk . "_ff0", $inst, $type, $init, "",
                                "b", $en, $flg, $rx_clk . "_thread", "", "", "", "");
                        push(@reg_list_sync, [@s_elm]);
                        @s_elm = ("", $en . "_" . $rx_clk . "_ff1", $inst, $type, $init, "",
                                "b", $en, $flg, $rx_clk . "_thread", "", "", "", "");
                        push(@reg_list_sync, [@s_elm]);
                        @s_elm = ("", $name . "_ff", $inst, $type, $init, $array,
                                $wid, $name, $flg, $rx_clk . "_thread", "", "", "", "");
                        push(@reg_list_sync, [@s_elm]);
                        $use_rx_thread = 1;
                    }
                }
            }
            if ($use_rx_thread == 0) {
                foreach $clk (@clk_list_sync) {
                    next if (@$clk[T_INST] ne $inst || @$clk[T_NAME] ne $rx_clk);
                    @$clk[T_NAME] = "";
                }
                if ($tx_rst ne $rx_rst) {
                    foreach $rst (@rst_list_sync) {
                        next if (@$rst[T_INST] ne $inst || @$rst[T_NAME] ne $rx_rst);
                        @$rst[T_NAME] = "";
                    }
                }
            }
        }

        # bind check
        foreach $elm (@bind_list) {
            if (!(@$elm[B_FLG_S] & FLG_USED)) {
                message("E331", $infile, 0,
                    "bind target \"@$elm[B_PORT_S]\" does not exist in instance \"@$elm[B_INST_S]\"");
            }
            if (!(@$elm[B_FLG_E] & FLG_USED)) {
                message("E331", $infile, 0,
                    "bind target \"@$elm[B_PORT_E]\" does not exist in instance \"@$elm[B_INST_E]\"");
            }
            &check_defined(@$elm[B_SIG], 0, $infile, 0);

            if (!(@$elm[B_FLG_S] & FLG_FIX)) {
                &get_port_data(@$elm[B_INST_S], @$elm[B_PORT_S], \$port_s);
                $fix_mem_flg = 0;
                foreach $tmp (@mem_list) {
                    next if(@$tmp[M_FIX] == 0);
                    if ((@$tmp[M_NAME] eq @$elm[B_PORT_S]) && (@$tmp[M_INST] eq @$elm[B_INST_S])) {
                        $fix_mem_flg = 1;
                    }
                }
                if (@$port_s[T_TYPE] !~ /out/ && $fix_mem_flg == 0) {
                    message("E332", $infile, 0,
                      "start point \"@$elm[B_PORT_S]\" is not output port of instance \"@$elm[B_INST_S]\"");
                }
            }

            if (!(@$elm[B_FLG_E] & FLG_FIX)) {
                &get_port_data(@$elm[B_INST_E], @$elm[B_PORT_E], \$port_e);
                if (@$port_e[T_TYPE] =~ /out/) {
                    message("E333", $infile, 0,
                      "end point \"@$elm[B_PORT_E]\" is not input port of instance \"@$elm[B_INST_E]\"");
                }
                if (!(@$elm[B_FLG_S] & FLG_FIX)
                 && (@$port_e[T_FLG] & FLG_IFDEF)
                 && (@$elm[B_PORT_S] ne @$elm[B_SIG]) ) {
                    message("E344", $infile, 0,
                      "don't specify 3rd argument of bind command for debug module \"@$elm[B_INST_E]\" without port fixed");
                }
            }

            if (!(@$elm[B_FLG_S] & FLG_FIX) && !(@$elm[B_FLG_E] & FLG_FIX)) {
                if (&is_signed($port_s) != &is_signed($port_e)
                 || @$port_s[T_ARRAY] ne @$port_e[T_ARRAY]
                 || @$port_s[T_WID] ne @$port_e[T_WID]) {
                    message("E405", $infile, 0, "signal \"@$elm[B_SIG]\"" .
                            " has incompatible setting between output and" .
                            " input in multiple modules");
                }
            }

            if ((@$elm[B_FLG_S] & FLG_FIX) || (@$elm[B_FLG_E] & FLG_FIX)) {
                foreach $tmp (@clk_list, @rst_list, @in_list, @out_list) {
                    if (@$tmp[T_NAME] eq @$elm[B_SIG]) {
                        message("E408", $infile, 0,
                          "signal of fixed port \"@$elm[B_SIG]\" should not be same as the other signal");
                    }
                }
                foreach $tmp (@tap_list) {
                    if (@$tmp[TAP_SIG] eq @$elm[B_SIG]) {
                        message("E341", $infile, 0,
                          "signal of fixed port \"@$elm[B_SIG]\" should not be set to tap command");
                    }
                }
            }
        }

        # tap check
        foreach $elm (@tap_list) {
            &check_defined(@$elm[TAP_OUT], 0, $infile, 0);
            &check_defined_tb(@$elm[TAP_OUT], 0, $infile, 0);
            if (@$elm[TAP_USED] == 0) {
                $msg = "tap target \"@$elm[TAP_SIG]\" does not exist";
                $msg = $msg . " in instance \"@$elm[TAP_INST]\"" if (@$elm[TAP_INST] ne "");
                message("E322", $infile, 0, $msg);
            }
        }

        # clock overlapping check
        for ($i = 0; $i < @clk_list; $i++) {
            $elm = $clk_list[$i];
            next if (@$elm[T_NAME] eq "");
            for ($j = $i + 1; $j < @clk_list; $j++) {
                $pair = $clk_list[$j];
                if (@$elm[T_NAME] eq @$pair[T_NAME]) {
                    @$pair[T_NAME] = "";
                    @$elm[T_SYMBL] = @$pair[T_SYMBL] if(@$elm[T_SYMBL] eq "");
                    if(@$elm[T_PERIOD] == 10 && @$elm[T_UNIT] eq "SC_NS") {
                        @$elm[T_PERIOD] = @$pair[T_PERIOD];
                        @$elm[T_UNIT]   = @$pair[T_UNIT];
                    }
                }
            }

            foreach $pair (@rst_list, @in_list) {
                next if (@$pair[T_NAME] eq "");
                if (@$elm[T_NAME] eq @$pair[T_NAME]) {
                    if (@$pair[T_TYPE] =~ /reset/) {
                        message("E603", $infile, 0, "clock and reset have" .
                                " same name \"@$elm[T_NAME]\" in multiple modules");
                    }
                    @$pair[T_NAME] = "";
                }
            }
        }

        # reset overlapping check
        for ($i = 0; $i < @rst_list; $i++) {
            $elm = $rst_list[$i];
            next if (@$elm[T_NAME] eq "");
            for ($j = $i + 1; $j < @rst_list; $j++) {
                $pair = $rst_list[$j];
                if (@$elm[T_NAME] eq @$pair[T_NAME]) {
                    if (&name_exist(\@out_list, @$elm[T_NAME]) == 0) {
                        if (@$elm[T_TYPE] ne @$pair[T_TYPE]
                         || @$elm[T_INIT] ne @$pair[T_INIT]) {
                            message("E403", $infile, 0,
                                "reset signal \"@$elm[T_NAME]\"" .
                                " has incompatible setting in multiple modules");
                        }
                        @$pair[T_NAME] = "";
                    }
                }
            }

            foreach $pair (@in_list) {
                if (@$elm[T_NAME] eq @$pair[T_NAME]) {
                    if (&name_exist(\@out_list, @$elm[T_NAME]) == 0) {
                        if (@$elm[T_ARRAY] ne @$pair[T_ARRAY]
                         || @$elm[T_WID] ne @$pair[T_WID]) {
                            message("E404", $infile, 0, "input port \"@$elm[T_NAME]\"" .
                                    " has incompatible setting in multiple modules");
                        }
                        @$pair[T_NAME] = "";
                    }
                }
            }
        }

        # input port overlapping check
        for ($i = 0; $i < @in_list; $i++) {
            $elm = $in_list[$i];
            next if (@$elm[T_NAME] eq "");
            for ($j = $i + 1; $j < @in_list; $j++) {
                $pair = $in_list[$j];
                if (@$elm[T_NAME] eq @$pair[T_NAME]) {
                    if (&name_exist(\@out_list, @$elm[T_NAME]) == 0) {
                        if (@$elm[T_ARRAY] ne @$pair[T_ARRAY]
                         || @$elm[T_TYPE] ne @$pair[T_TYPE]
                         || @$elm[T_WID] ne @$pair[T_WID]) {
                            message("E404", $infile, 0, "input port \"@$elm[T_NAME]\"" .
                                " has incompatible setting in multiple modules");
                        }
                        @$pair[T_NAME] = "";
                    }
                }
            }
        }

        # output port overlapping check
        for ($i = 0; $i < @out_list; $i++) {
            $elm = $out_list[$i];
            next if (@$elm[T_NAME] eq "");
            for ($j = $i + 1; $j < @out_list; $j++) {
                $pair = $out_list[$j];
                if (@$elm[T_NAME] eq @$pair[T_NAME]) {
                    message("E406", $infile, 0, "signal \"@$elm[T_NAME]\"" .
                            " is driven from multiple modules");
                }
            }
        }

        # check top port
        foreach $out (@out_list, @out_list_sync) {
            my $tap_exist   = 0;
            my $in_cnt      = 0;
            next if (@$out[T_NAME] eq "");

            foreach $tap (@tap_list) {
                if (@$out[T_NAME] eq @$tap[TAP_OUT]
                 && (@$out[T_INST] eq @$tap[TAP_INST] || @$tap[TAP_INST] eq "")) {
                    $tap_exist = 1;
                    last;
                }
            }

            foreach $in (@in_list, @in_list_sync, @clk_list, @rst_list) {
                if (@$out[T_NAME] eq @$in[T_NAME]) {
                    if (@$out[T_ARRAY] ne @$in[T_ARRAY]
                     || @$out[T_WID] ne @$in[T_WID]
                     || &is_signed($out) != &is_signed($in)) {
                        message("E405", $infile, 0, "signal \"@$out[T_NAME]\"" .
                                " has incompatible setting between output and" .
                                " input in multiple modules");
                    }
                    $in_cnt++ if (!(@$in[T_FLG] & FLG_IFDEF));
                    @$in[T_NAME] = "" if (!((@$in[T_FLG] & FLG_SYNC) || (@$in[T_FLG] & FLG_SYNC_CHK)));
                }
            }

            if ($in_cnt > 0 && $tap_exist == 0
              && &name_exist(\@reg_list, @$out[T_NAME]) == 0) {
                $type = @$out[T_TYPE];
                $type =~ s/out/reg/;
                @elm = ("", @$out[T_NAME], "", $type, "", @$out[T_ARRAY], @$out[T_WID],
                        @$out[T_NAME], 0, "", "", "", "", "", "", @$out[T_CTSCG]);
                push(@reg_list, [@elm]);
                @$out[T_NAME] = "" if (!(@$out[T_FLG] & FLG_SYNC));
            }
        }

        # check synchronizer module clock/reset/port/signal overlapping
        for ($i = 0; $i < @clk_list_sync; $i++) {
            $elm = $clk_list_sync[$i];
            next if (@$elm[T_NAME] eq "");
            for ($j = $i + 1; $j < @clk_list_sync; $j++) {
                $pair = $clk_list_sync[$j];
                if (@$elm[T_NAME] eq @$pair[T_NAME] && @$elm[T_INST] eq @$pair[T_INST]) {
                    @$pair[T_NAME] = "";
                }
            }
        }
        for ($i = 0; $i < @rst_list_sync; $i++) {
            $elm = $rst_list_sync[$i];
            next if (@$elm[T_NAME] eq "");
            for ($j = $i + 1; $j < @rst_list_sync; $j++) {
                $pair = $rst_list_sync[$j];
                if (@$elm[T_NAME] eq @$pair[T_NAME] && @$elm[T_INST] eq @$pair[T_INST]) {
                    @$pair[T_NAME] = "";
                }
            }
        }
        for ($i = 0; $i < @out_list_sync; $i++) {
            $elm = $out_list_sync[$i];
            next if (@$elm[T_NAME] eq "");
            for ($j = $i + 1; $j < @out_list_sync; $j++) {
                $pair = $out_list_sync[$j];
                if (@$elm[T_NAME] eq @$pair[T_NAME] && @$elm[T_INST] eq @$pair[T_INST]) {
                    @$pair[T_NAME] = "";
                }
            }
        }
        for ($i = 0; $i < @in_list_sync; $i++) {
            $elm = $in_list_sync[$i];
            next if (@$elm[T_NAME] eq "");
            for ($j = $i + 1; $j < @in_list_sync; $j++) {
                $pair = $in_list_sync[$j];
                if (@$elm[T_NAME] eq @$pair[T_NAME] && @$elm[T_INST] eq @$pair[T_INST]) {
                    @$pair[T_NAME] = "";
                }
            }
        }
        for ($i = 0; $i < @reg_list_sync; $i++) {
            $elm = $reg_list_sync[$i];
            next if (@$elm[T_NAME] eq "");
            for ($j = $i + 1; $j < @reg_list_sync; $j++) {
                $pair = $reg_list_sync[$j];
                if (@$elm[T_NAME] eq @$pair[T_NAME] && @$elm[T_INST] eq @$pair[T_INST]) {
                    @$pair[T_NAME] = "";
                }
            }
        }

        # bind sync 4th check
        foreach $elm (@mod_list_sync) {
            @mod_bind = ();
            $mod_inst = @$elm[MOD_INST];
            foreach $tmp (@clk_list_sync, @rst_list_sync, @in_list_sync, @out_list_sync) {
                next if (@$tmp[T_NAME] eq "");
                next if (@$tmp[T_INST] ne $mod_inst);
                $name_bind = @$tmp[T_NAME];
                # match signal from tap list
                foreach $tap (@tap_list) {
                    if (@$tap[TAP_SIG] eq $name_bind) {
                        $name_bind = @$tap[TAP_OUT];
                        last;
                    }
                }
                if (@$tmp[T_ARRAY] eq "") {
                    $bind = "$tab$tab$mod_inst.@$tmp[T_NAME]($name_bind);";
                    push(@mod_bind, $bind);
                }
                else {
                    my @dim = ();
                    while (@$tmp[T_ARRAY] =~ /\w+/g) {
                        push(@dim, $&);
                    }
                    if ($mod_rtl == 1) {
                        $bind = "#ifndef $mod_macro";
                        push(@mod_bind, $bind);
                    }
                    for ($i = 0; $i < @dim; $i++) {
                        $bind = $tab x2 . $tab x$i . "for (int i$i = 0; i$i < $dim[$i]; i$i++) {";
                        push(@mod_bind, $bind);
                    }
                    $bind = $tab x2 . $tab x $i . "$mod_inst.@$tmp[T_NAME]";
                    for ($i = 0; $i < @dim; $i++) {
                        $bind = $bind . "[i$i]";
                    }
                    $bind = $bind . "($name_bind";
                    for ($i = 0; $i < @dim; $i++) {
                        $bind = $bind . "[i$i]";
                    }
                    $bind = $bind . ");";
                    push(@mod_bind, $bind);

                    for ($i = @dim - 1; $i >= 0; $i--) {
                        $bind = $tab x2 . $tab x$i . "}";
                        push(@mod_bind, $bind);
                    }
                }
            }
            for ($i=0;$i<@mod_bind;$i++) {
                @$elm[$i+MOD_BIND] = $mod_bind[$i];
            }
            push(@mod_list, [@$elm]);
        }
    }

    # check enable ports for sim_eq
    if ($opt_sim_eq == 1) {
        foreach $port (@in_list, @in_list_insert) {
            next if ((@$port[T_NAME] eq "") || (@$port[T_ENAME] eq ""));
            $find = 0;
            foreach $pair (@in_list, @in_list_insert) {
                if (@$pair[T_NAME] eq @$port[T_ENAME]) {
                    $find = 1;
                    last;
                }
            }
            if ($find == 0) {
                message("E329", $infile, 0, "\"@$port[T_ENAME]\" does not exist in module");
            }
        }
        foreach $port (@out_list, @out_list_insert) {
            next if ((@$port[T_NAME] eq "") || (@$port[T_ENAME] eq ""));
            $find = 0;
            foreach $pair (@out_list, @out_list_insert) {
                if (@$pair[T_NAME] eq @$port[T_ENAME]) {
                    $find = 1;
                    last;
                }
            }
            if ($find == 0) {
                message("E329", $infile, 0, "\"@$port[T_ENAME]\" does not exist in module");
            }
        }
        $find = 0;
        foreach $port1 (@out_list, @out_list_insert) {
            next if (@$port1[T_NAME] eq "");
            if (@$port1[T_FLG] & FLG_CATG_EN) {
                foreach $port2 (@out_list, @out_list_insert) {
                    next if (@$port2[T_NAME] eq "" || @$port2[T_NAME] eq @$port1[T_NAME]);
                    if (@$port2[T_ENAME] eq @$port1[T_NAME]) {
                        push(@out_list_enable, $port1);
                        last;
                    }
                }
            }
            if ((@$port1[T_FLG] & FLG_CATG_DATA) && @$port1[T_ENAME] eq "") {
                $find = 1;
            }
        }
        if ($find == 1) {
            push(@out_list_enable, ["", "", "", "", "", "", "", "", "", "", "", "", "", ""]);
        }
    }

    # check clock
    $clk_num = &get_valid_clock(\$clk_data); #need to exec here

    # check memory generation
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        @$elm[M_CLKR] = @$clk_data[T_NAME] if (@$elm[M_CLKR] eq "");
        @$elm[M_CLKW] = @$clk_data[T_NAME] if (@$elm[M_CLKW] eq "");

        if (@$elm[M_RW] & MA_1PORT) {
            $need_mem_rw1 = 1;
        }
        elsif (@$elm[M_RW] & MA_2PORT) {
            if (@$elm[M_CLKR] eq @$elm[M_CLKW]) {
                if(@$elm[M_BE] > 0) {
                    $need_mem_r1w1_be = 1;
                }
                else {
                    $need_mem_r1w1 = 1;
                }
            }
            else {
                if(@$elm[M_BE] > 0) {
                    $need_mem_r1w1_2clk_be = 1;
                }
                else {
                    $need_mem_r1w1_2clk = 1;
                }
            }
        }
        else {
            $need_mem_rw2 = 1;
        }
    }

    # check clock list
    if ($top_mode == 0 && $clk_num == 0 && @thread_list != 0) {
        message("E104", $infile, 0, "no clock is defined");
    }
    if ($top_mode == 0) {
        if ($clk_num > 1) {
            message("E105", $infile, 0, "not support multiple clock");
        }
    }
    else {
        if ($clk_num > 1) {
            message("I003", $infile, 0, "because ssgen generates only one SC_CTHREAD" .
                    " in testbench, please make SC_CTHREADs for every clocks, if necessary");
        }
    }

    # check reset list
    $rst_cnt     = 0;
    $arst_cnt    = 0;
    $softrst_cnt = 0;
    $arst_pos    = -1;

    for ($i = 0; $i < @rst_list; $i++) {
        @elm = @{$rst_list[$i]};
        if ($elm[T_NAME] ne "") {
            $rst_cnt++;
            if ($elm[T_TYPE] eq "areset") {
                $arst_cnt++;
                $arst_pos = $i;
            }
            elsif ($elm[T_TYPE] eq "soft_reset") {
                $softrst_cnt++;
            }
            if ($top_mode == 0 && !($elm[T_FLG] & FLG_USED)) {
                message("E413", $infile, 0,
                                "\"$elm[T_NAME]\" is not set to any threads as reset signal");
            }
        }
    }

    if ($rst_cnt > 0 && $rst_cnt == $softrst_cnt) {
        message("E107", $infile, 0, "only soft_reset is defined as reset");
    }

    if ($arst_cnt == 1) {
        if ($arst_pos > 0) {
            @tmp = splice(@rst_list, $arst_pos, 1);
            unshift(@rst_list, @tmp);
        }
    }
    #elsif ($arst_cnt > 1 && $top_mode == 0) {
    #    message("E106", $infile, 0, "areset should be defined only once");
    #}

    if ($standard_ignore) {
        message("I999", $infile, 0, "some commands and options were ignored by specifing -standard");
    }

    if ($opt_subd) {
        if ($opt_ctos || $opt_stratus) {
            my $rtldir = $outdir . "rtl";
            if  (! -d $rtldir) {
                mkdir($rtldir) || die "can't make directory [$rtldir]\n";
            }
        }
        if ($opt_sim_eq) {
            my $simdir = $outdir . "sim_eq";
            if  (! -d $simdir) {
                mkdir($simdir) || die "can't make directory [$simdir]\n";
            }
        }
    }
}

##
## last check
##
sub last_check {
    # check `define macro
    my $define_list = ($top_mode != 0) ? \@define_in_top_list : \@define_in_list;
    foreach $elm (@$define_list) {
        next if (@$elm[G_NAME] eq "SIM_EQ_MAX_CNT" && $opt_sim_eq);
        if (((@$elm[G_FLAG] & FLG_USED) | (@$elm[G_FLAG] & FLG_KEEP_STR)) == 0) {
            message("W001", $infile, 0,
                "`define macro name \"@$elm[G_NAME]\" is not used");
        }
    }
}

##
## generate template module
##
sub gen_template_mod {
    foreach $elm (@tmpl_inst_list) {
        my $new_name = @$elm[MOD_NAME];
        my $org_name = @$elm[MOD_INST];
        my $NEW_NAME = uc $new_name;
        my @tmpl_list= @{@$elm[MOD_TMPL]};

        $outfile = $new_name . ".h";
        &my_open(*OUT_H, "//", "src", 0);

        print OUT_H "#ifndef ${NEW_NAME}_H\n";
        print OUT_H "#define ${NEW_NAME}_H\n";

        # #include
        print OUT_H "\n";
        print OUT_H "#include \"${org_name}.h\"\n\n";

        # #define
        foreach $tmpl (@tmpl_list) {
            print OUT_H "#define ${NEW_NAME}_@$tmpl[0] @$tmpl[1]\n";
        }

        # module inheritance
        print OUT_H "\n";
        print OUT_H "class $new_name: public $org_name<";
        $init = 0;
        foreach $tmpl (@tmpl_list) {
            print OUT_H "," if ($init != 0);
            print OUT_H " ${NEW_NAME}_@$tmpl[0]";
            $init = 1;
        }
        print OUT_H " > {\n";
        print OUT_H "public:\n";
        print OUT_H $tab, "$new_name(sc_module_name name)\n";
        print OUT_H $tab x2, ": $org_name<";
        $init = 0;
        foreach $tmpl (@tmpl_list) {
            print OUT_H "," if ($init != 0);
            print OUT_H " ${NEW_NAME}_@$tmpl[0]";
            $init = 1;
        }
        print OUT_H " > (name)\n";
        print OUT_H $tab, "{}\n";
        print OUT_H "};\n";
        print OUT_H "\n";
        print OUT_H "#ifdef __CTOS__\n";
        print OUT_H "SC_MODULE_EXPORT($new_name);\n";
        print OUT_H "#endif\n";
        print OUT_H "\n";
        print OUT_H "#endif // ${NEW_NAME}_H\n";
        close(OUT_H);

        $outfile = $new_name . ".cpp";
        &my_open(*OUT_CPP, "//", "src", 0);
        print OUT_CPP "// ${new_name}.cpp\n";
        print OUT_CPP "#include \"${new_name}.h\"\n";
        close(OUT_CPP);
    }
}

##
## generate model header
##
sub gen_mod_h {
    $outfile = $module_name . ".h";
    &my_open(*OUT_H, "//", "src", 0);

    print OUT_H "#ifndef ${MODULE_NAME}_H\n";
    print OUT_H "#define ${MODULE_NAME}_H\n";

    # change log
    print OUT_H "\n" if (@changelog_list > 0);
    foreach $elm (@changelog_list) {
        print OUT_H "// $elm\n";
    }

    # #include & #define
    print OUT_H "\n";
    print OUT_H "#include <systemc.h>\n";
    if ($hdl_vcs_on == 1) {
        print OUT_H "#ifdef VCS_SYSTEMC\n";
        print OUT_H "#include \"cosim/bf/hdl_connect_v.h\"\n";
        print OUT_H "#endif\n";
    }
    if ($opt_stratus) {
        print OUT_H "#ifndef __CTOS__\n";
        print OUT_H "#include <stratus_hls.h>\n";
        print OUT_H "#endif\n";
    }
    print OUT_H "#include \"ssgenlib.h\"\n" if (!$opt_standard);
    print OUT_H "\n" if (@prepro_list > 0);
    &print_preprocessor(*OUT_H);
    &print_kept_ssgen_define(*OUT_H, $infile, 0);
    if (@def_file_list != 0) {
        foreach $def_file (@def_file_list) {
            my $def_h = $def_file;
            $def_h =~ s/\.in/.h/;
            $def_h =~ s/^.*\///;
            print OUT_H "#include \"$def_h\"\n";
        }
    }
    # include struct header file
    if (@struct_list != 0) {
        my $incl_list = "";
        foreach my $str(@struct_list) {
            $file_name = @$str[STR_NAME];
            $file_name = $file_name.".h";
            if ($incl_list !~ /\b$file_name\b/) {
                print OUT_H "#include \"$file_name\"\n";
                $incl_list = "$incl_list  $file_name ";
            }
        }
    }

    # memory pointer
    &print_memory_ptr;

    # template
    &print_module_tempalte;

    # module declaration
    &print_module_def(*OUT_H, $module_name);

    # port and reset
    &print_port;

    # memory
    &print_memory_def;

    # ev
    &print_ev_def;

    # reg, var, ctype
    &print_decl_data;

    # reset for osci simlation
    &print_osci_reset;

    # free area
    &print_free_area(*OUT_H, 0);

    # constructor
    &print_constructor;

    # ssgen reset function
    &print_ssgen_reset_func;

    # reset function
    #&print_reset_func(*OUT_H, 1);
    &print_reset_func(*OUT_H, $use_template == 0);

    # soft reset function
    #&print_soft_reset_func(*OUT_H, 1);
    &print_soft_reset_func(*OUT_H, $use_template == 0);

    # wait function
    #&print_wait_func(*OUT_H, 1);
    &print_wait_func(*OUT_H, $use_template == 0);

    # prev wait function
    &print_prev_wait_func;

    # post wait function
    &print_post_wait_func;

    # ev function
    &print_ev_func(*OUT_H, 0);

    # var2reg function
    &print_var2reg_func(*OUT_H, 0);

    # toggle functions
    &print_toggle_prepare_func(*OUT_H);
    &print_toggle_check_func(*OUT_H);

    # slecbb function
    &print_slecbb_func(*OUT_H, 0);

    # debug_trace function
    &print_debug_trace_func(*OUT_H, 0);

    # memory function
    #&print_memory_func(*OUT_H, 1);
    &print_memory_func(*OUT_H, $use_template == 0);

    # thread
    #&print_thread(*OUT_H, 1);
    &print_thread(*OUT_H, $use_template == 0);

    # method
    #&print_method(*OUT_H, 1);
    &print_method(*OUT_H, $use_template == 0);

    # function
    #&print_func(*OUT_H, 1);
    &print_func(*OUT_H, $use_template == 0);

    # VCD trace
    &print_vcd_trace_func;

    print OUT_H "};\n";
    print OUT_H "\n";
    if ($use_template == 0) {
        print OUT_H "#ifdef __CTOS__\n";
        print OUT_H "SC_MODULE_EXPORT($module_name);\n";
        print OUT_H "#endif\n";
    }
    print OUT_H "\n";
    print OUT_H "#endif // ${MODULE_NAME}_H\n";
    close(OUT_H);
}

##
## generate model source
##
sub gen_mod_cpp {
    $outfile = $module_name . ".cpp";
    &my_open(*OUT_CPP, "//", "src", 0);

    print OUT_CPP "// ${module_name}.cpp\n";
    print OUT_CPP "#include \"${module_name}.h\"\n";

    if ($use_template == 0) {
    # const
    &print_const(*OUT_CPP, 1);

    # thread
    &print_thread(*OUT_CPP, 2);

    # method
    &print_method(*OUT_CPP, 2);

    # function
    &print_func(*OUT_CPP, 2);

    # reset function
    &print_reset_func(*OUT_CPP, 2);

    # soft reset function
    &print_soft_reset_func(*OUT_CPP, 2);

    # wait function
    &print_wait_func(*OUT_CPP, 2);

    # memory function
    &print_memory_func(*OUT_CPP, 2);
    }
    close(OUT_CPP);
}

##
## generate top header
##
sub gen_top_h {
    $outfile = $module_name . ".h";
    &my_open(*OUT_H, "//", "src", 0);

    local $print_fix_method = 0; ## 1: only port, 2: only mem, 3: port & mem

    print OUT_H "#ifndef ${MODULE_NAME}_H\n";
    print OUT_H "#define ${MODULE_NAME}_H\n";

    # change log
    print OUT_H "\n" if (@changelog_list > 0);
    foreach $elm (@changelog_list) {
        print OUT_H "// $elm\n";
    }

    # module include
    print OUT_H "\n";
    print OUT_H "#include <systemc.h>\n";
    if ($hdl_vcs_on == 1) {
        print OUT_H "#ifdef VCS_SYSTEMC\n";
        print OUT_H "#include \"cosim/bf/hdl_connect_v.h\"\n";
        print OUT_H "#endif\n";
    }
    if ($opt_stratus) {
        print OUT_H "#ifndef __CTOS__\n";
        print OUT_H "#include <stratus_hls.h>\n";
        print OUT_H "#endif\n";
    }
    print OUT_H "#include \"ssgenlib.h\"\n" if (!$opt_standard);
    foreach $mod (@mod_list) {
        next if (@$mod[MOD_FLG] & FLG_MULTI);
        $header = @$mod[MOD_NAME];
        if (@$mod[MOD_PATH] ne "") {
            $header = @$mod[MOD_PATH] . "/" . $header;
        }
        print OUT_H "#ifdef @$mod[MOD_DBG]\n" if (@$mod[MOD_DBG] ne "");
        print OUT_H "#include \"$header.h\"\n";
        print OUT_H "#endif\n" if (@$mod[MOD_DBG] ne "");
    }
    &print_kept_ssgen_define(*OUT_H, $infile, 0);
    @mem_used = ();
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        my $skip = 0;
        if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
            foreach $used (@mem_used) {
                if ($used eq @$elm[M_NAME]) {
                    $skip = 1;
                    last;
                }
            }
            push(@mem_used, @$elm[M_NAME]);
        }
        if ($skip == 0 && @$elm[M_SHARE] > 0) {
            if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                $ifnm = &get_mem_ifnm(\@$elm);
                print OUT_H "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);
                print OUT_H "#include \"${ifnm}.h\"\n";
                print OUT_H "#endif\n" if (@$elm[M_PONLY] == 0);
            }
        }
    }

    # module declaration
    &print_module_def(*OUT_H, $module_name);

    # port and reset
    &print_port;

    # memory
    &print_memory_def;

    # reg
    &print_decl_data;

    # fix memory signal
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 0);
        print OUT_H "\n";
        print OUT_H "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);
        my $atype = "sc_uint<".&log2(&get_macro_value(@$elm[M_SIZE], "", 0)).">";
        my $big   = (&get_macro_value(@$elm[M_WID], "", 0) > 64)? "big": "";
        my $sign  = (@$elm[M_SIGN] == 1)? "sc_".$big."int": "sc_".$big."uint";
        my $dtype = $sign."<@$elm[M_WID]>";
        my $btype = "sc_uint<".(&get_macro_value(@$elm[M_WID], "", 0)>>3).">";
        if (@$elm[M_RW] == MA_RW1) {
            print OUT_H $tab, "sc_signal < ", $atype, " > ", &get_mem_portnm(\@$elm, MP1_AD), ";\n";
            print OUT_H $tab, "sc_signal < ", $dtype, " > ", &get_mem_portnm(\@$elm, MP1_WD), ";\n";
            print OUT_H $tab, "sc_signal < bool > ", &get_mem_portnm(\@$elm, MP1_WE), ";\n";
            print OUT_H $tab, "sc_signal < ", $dtype, " > ", &get_mem_portnm(\@$elm, MP1_RD), ";\n";
            if (@$elm[M_CS] > 0) {
                print OUT_H $tab, "sc_signal < bool > ", &get_mem_portnm(\@$elm, MP1_CS), ";\n";
            }
        }
        elsif (@$elm[M_RW] == MA_RW1_W) {
            print OUT_H $tab, "sc_signal < ", $atype, " > ", &get_mem_portnm(\@$elm, MP1_WA), ";\n";
            print OUT_H $tab, "sc_signal < ", $dtype, " > ", &get_mem_portnm(\@$elm, MP1_WD), ";\n";
            print OUT_H $tab, "sc_signal < bool > ", &get_mem_portnm(\@$elm, MP1_WE), ";\n";
        }
        elsif (@$elm[M_RW] == MA_RW1_R) {
            print OUT_H $tab, "sc_signal < ", $atype, " > ", &get_mem_portnm(\@$elm, MP1_RA), ";\n";
            print OUT_H $tab, "sc_signal < ", $dtype, " > ", &get_mem_portnm(\@$elm, MP1_RD), ";\n";
            if (@$elm[M_RE] > 0) {
                print OUT_H $tab, "sc_signal < bool > ", &get_mem_portnm(\@$elm, MP1_RE), ";\n";
            }
        }
        elsif (@$elm[M_RW] == MA_R1W1_W) {
            print OUT_H $tab, "sc_signal < ", $atype, " > ", &get_mem_portnm(\@$elm, MP2_WA), ";\n";
            print OUT_H $tab, "sc_signal < ", $dtype, " > ", &get_mem_portnm(\@$elm, MP2_WD), ";\n";
            print OUT_H $tab, "sc_signal < bool > ", &get_mem_portnm(\@$elm, MP2_WE), ";\n";
            if (@$elm[M_CS] > 0) {
                print OUT_H $tab, "sc_signal < bool > ", &get_mem_portnm(\@$elm, MP2_CS), ";\n";
            }
            if (@$elm[M_BE] > 0) {
                print OUT_H $tab, "sc_signal < ", $btype, " > ", &get_mem_portnm(\@$elm, MP2_BE), ";\n";
            }
        }
        elsif (@$elm[M_RW] == MA_R1W1_R) {
            print OUT_H $tab, "sc_signal < ", $atype, " > ", &get_mem_portnm(\@$elm, MP2_RA), ";\n";
            print OUT_H $tab, "sc_signal < ", $dtype, " > ", &get_mem_portnm(\@$elm, MP2_RD), ";\n";
            if (@$elm[M_RE] > 0) {
                print OUT_H $tab, "sc_signal < bool > ", &get_mem_portnm(\@$elm, MP2_RE), ";\n";
            }
        }
        elsif (@$elm[M_RW] == MA_RW2_A) {
            print OUT_H $tab, "sc_signal < ", $atype, " > ", &get_mem_portnm(\@$elm, MPA_AD), ";\n";
            print OUT_H $tab, "sc_signal < ", $dtype, " > ", &get_mem_portnm(\@$elm, MPA_WD), ";\n";
            print OUT_H $tab, "sc_signal < bool > ", &get_mem_portnm(\@$elm, MPA_WE), ";\n";
            print OUT_H $tab, "sc_signal < ", $dtype, " > ", &get_mem_portnm(\@$elm, MPA_RD), ";\n";
            if (@$elm[M_CS] > 0) {
                print OUT_H $tab, "sc_signal < bool > ", &get_mem_portnm(\@$elm, MPA_CS), ";\n";
            }
        }
        elsif (@$elm[M_RW] == MA_RW2_B) {
            print OUT_H $tab, "sc_signal < ", $atype, " > ", &get_mem_portnm(\@$elm, MPB_AD), ";\n";
            print OUT_H $tab, "sc_signal < ", $dtype, " > ", &get_mem_portnm(\@$elm, MPB_WD), ";\n";
            print OUT_H $tab, "sc_signal < bool > ", &get_mem_portnm(\@$elm, MPB_WE), ";\n";
            print OUT_H $tab, "sc_signal < ", $dtype, " > ", &get_mem_portnm(\@$elm, MPB_RD), ";\n";
            if (@$elm[M_CS] > 0) {
                print OUT_H $tab, "sc_signal < bool > ", &get_mem_portnm(\@$elm, MPB_CS), ";\n";
            }
        }
        print OUT_H "#endif\n" if (@$elm[M_PONLY] == 0);
    }

    #signals for memory
    @mem_used = ();
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        my $skip = 0;
        foreach $used (@mem_used) {
            if ($used eq @$elm[M_NAME]) {
                $skip = 1;
                last;
            }
        }
        push(@mem_used, @$elm[M_NAME]);
        if ($skip == 0 && @$elm[M_SHARE] > 0) {
            if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                #$size = &log2(@$elm[M_SIZE]);
                $size = &log2(&get_macro_value(@$elm[M_SIZE], "", 0));
                print OUT_H "\n";
                print OUT_H "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);
                print OUT_H $tab, &get_type("ureg", $size);
                print OUT_H " ", &get_mem_portnm(\@$elm, MP1_WA), ";\n";
                print OUT_H $tab, &get_type("ureg", $size);
                print OUT_H " ", &get_mem_portnm(\@$elm, MP1_RA), ";\n";
                if (@$elm[M_RE] > 0) {
                    print OUT_H $tab, &get_type("ureg", "b");
                    print OUT_H " ", &get_mem_portnm(\@$elm, MP1_RE), ";\n";
                }
                print OUT_H "#endif\n" if (@$elm[M_PONLY] == 0);
            }
        }
    }

    # instance
    print OUT_H "\n";
    foreach $mod (@mod_list) {
        print OUT_H "#ifdef @$mod[MOD_DBG]\n" if (@$mod[MOD_DBG] ne "");
        if(@$mod[MOD_NAME] ne "ctos_clock_gating") {
            print OUT_H $tab, "@$mod[MOD_NAME] @$mod[MOD_INST];\n";
        }
        else {
            print OUT_H $tab, "ctos_clock_gate_module @$mod[MOD_INST];\n";
        }
        print OUT_H "#endif\n" if (@$mod[MOD_DBG] ne "");
    }
    @mem_used = ();
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        my $skip = 0;
        if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
            foreach $used (@mem_used) {
                if ($used eq @$elm[M_NAME]) {
                    $skip = 1;
                    last;
                }
            }
            push(@mem_used, @$elm[M_NAME]);
        }
        if ($skip == 0 && @$elm[M_SHARE] > 0) {
            if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                print OUT_H "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);
                $ifnm = &get_mem_ifnm(\@$elm);
                print OUT_H $tab, "${ifnm} ";
                print OUT_H "${ifnm}_ins;\n";
                print OUT_H "#endif\n" if (@$elm[M_PONLY] == 0);
            }
        }
    }

    # constructor
    &print_constructor;

    # method for fix port/mem
    &print_method_fixed;

    # methods for fix port
    #&print_method_fixed_port;

    # methods for fix mem
    #&print_method_fixed_mem;

    # VCD trace
    &print_vcd_trace_func;

    print OUT_H "};\n";
    print OUT_H "\n";
    print OUT_H "#ifdef __CTOS__\n";
    print OUT_H "SC_MODULE_EXPORT($module_name);\n";
    print OUT_H "#endif\n";
    print OUT_H "\n";
    print OUT_H "#endif // ${MODULE_NAME}_H\n";
    close(OUT_H);
}

##
## generate top source
##
sub gen_top_cpp {
    $outfile = $module_name . ".cpp";
    &my_open(*OUT_CPP, "//", "src", 0);

    print OUT_CPP "// ${module_name}.cpp\n";
    print OUT_CPP "#include \"${module_name}.h\"\n";
    close(OUT_CPP);
}

##
## generate define header
##
sub gen_def_h {
    #my $define_list = ($top_mode != 0) ? \@define_in_top_list : \@define_in_list;
    foreach $def_file (@def_file_list) {
        my $def = $def_file;
        $def =~ s/.in$//;
        $def =~ s/^.*\///;
        $outfile = $def. ".h";
        &my_open(*OUT_H, "//", "src", 1);
        print OUT_H "#ifndef " . uc $def . "_H\n";
        print OUT_H "#define " . uc $def . "_H\n";
        print OUT_H "\n";
        &print_kept_ssgen_define(*OUT_H, $def_file, 0);
        print OUT_H "\n";
        print OUT_H "#endif\n";
        close(OUT_H);
    }
}

##
## generate main file of testbench
##   $out_mode : print mode (= 0: ocsi/vcs/ies, 1: sim_eq)
##
sub gen_main {
    $out_mode = $_[0];
    $postfix = ($out_mode == 0) ? "" : "_eq";
    if ($top_mode == 0 && $use_template == 1) {
        $module_name = @{$tmpl_inst_list[0]}[MOD_NAME];
    }
    $subdir  = ($out_mode == 0) ? "tb" : "sim_eq/$module_name";
    $outfile = "main_" . $module_name . $postfix . ".cpp";
    &my_open(*OUT_MAIN, "//", $subdir, 0);

    # include
    print OUT_MAIN "// main_$module_name.cpp\n";
    print OUT_MAIN "#include \"$module_name.h\"\n";
    if ($out_mode == 1) {
        print OUT_MAIN "#include \"$module_name$postfix.h\"\n";
    }
    print OUT_MAIN "#include \"tb_$module_name$postfix.h\"\n";
    if ($out_mode == 0) {
        if ($hdl_vcs_on == 1) {
            print OUT_MAIN "#ifdef VCS_SYSTEMC\n";
            print OUT_MAIN $tab, "#include \"cosim/bf/hdl_connect_v.h\"\n";
            print OUT_MAIN $tab, "#include \"$hdl_module.h\"\n";
            print OUT_MAIN "#endif\n";
        }
        if ($use_aigen == 1) {
            print OUT_MAIN "#if defined(_VCS_AIP) && !defined(_IES_ABVIP)\n";
            print OUT_MAIN $tab, "#include \"${module_name}_vcs_apb_monitor.h\"\n";
            print OUT_MAIN "#endif\n";
            print OUT_MAIN "#if !defined(_VCS_AIP) && defined(_IES_ABVIP)\n";
            print OUT_MAIN $tab, "#include \"${module_name}_ies_apb_monitor.h\"\n";
            print OUT_MAIN "#endif\n";
        }
        if ($opt_sva == 1) {
            print OUT_MAIN "#ifdef _USE_SVA\n";
            print OUT_MAIN $tab, "#include \"${module_name}_sva.h\"\n";
            print OUT_MAIN "#endif\n";
        }

        if ($need_mem_rw1 == 1) {
            print OUT_MAIN "#include \"mem_rw1.h\"\n";
        }
        if ($need_mem_r1w1 == 1) {
            print OUT_MAIN "#include \"mem_r1w1.h\"\n";
        }
        if ($need_mem_r1w1_2clk == 1) {
            print OUT_MAIN "#include \"mem_r1w1_2clk.h\"\n";
        }
        if ($need_mem_r1w1_be == 1) {
            print OUT_MAIN "#include \"mem_r1w1_be.h\"\n";
        }
        if ($need_mem_r1w1_2clk_be == 1) {
            print OUT_MAIN "#include \"mem_r1w1_2clk_be.h\"\n";
        }
        if ($need_mem_rw2 == 1) {
            print OUT_MAIN "#include \"mem_rw2.h\"\n";
        }
        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 1);
            if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                if ($top_mode == 0 || ($top_mode == 1 && @$elm[M_SHARE] == 0)) {
                    $ifnm = &get_mem_ifnm(\@$elm);
                    print OUT_MAIN "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);
                    print OUT_MAIN "#include \"${ifnm}.h\"\n";
                    print OUT_MAIN "#endif\n" if (@$elm[M_PONLY] == 0);
                }
            }
        }

        # memory pointer
        $start = 1;
        @mem_used = ();
        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 1);
            my $skip = 0;
            foreach $used (@mem_used) {
                if ($used eq @$elm[M_NAME]) {
                    $skip = 1;
                    last;
                }
            }
            push(@mem_used, @$elm[M_NAME]);
            if ($skip == 0) {
                if ($start == 1) {
                    print OUT_MAIN "\n";
                    $start = 0;
                }
                $type = &get_type(@$elm[M_SIGN] == 1 ? "svar" : "var", @$elm[M_WID]);
                print OUT_MAIN $type, " *ptr_", @$elm[M_NAME], ";\n";
            }
        }
    }

    # file pointers
    if ($out_mode == 1) {
        print OUT_MAIN "\n";
        for (my $i=0; $i<@out_list_enable; $i++) {
            print OUT_MAIN "FILE *scout$i;\n";
            print OUT_MAIN "FILE *rtlout$i;\n";
        }
    }

    print OUT_MAIN "\n";
    # primary declaration
    print OUT_MAIN "int sc_main(int argc, char *argv[]) {\n";
    if ($out_mode == 0) {
        print OUT_MAIN $tab, "srand(0);\n" if ($use_rand == 1);
        print OUT_MAIN $tab, "bool vcd_dump  = 0;\n";
        print OUT_MAIN $tab, "int  vcd_depth = $hier_max;\n";
    }

    my @clk_symbol_list = (); # [0]: Name, [1]: Symbol, [2]: Unit
    my $clk_num = 1;
    foreach $elm (@clk_list) {
        if (@$elm[T_NAME] ne "") {
            my $clk_symbol = @$elm[T_SYMBL];
            if($clk_symbol eq "") {
                $clk_symbol = "clk".$clk_num;
            }
            print OUT_MAIN $tab, "int  ${clk_symbol}_period = @$elm[T_PERIOD];\n";
            my @elm_clk = (@$elm[T_NAME], $clk_symbol, @$elm[T_UNIT]);
            push(@clk_symbol_list, [@elm_clk]);
            $clk_num++;
        }
    }

    print OUT_MAIN $tab, "for (int i = 1; i < argc; i++) {\n";
    $init = 0;
    if ($out_mode == 0) {
        print OUT_MAIN $tab x2, "// vcd dump control\n";
        print OUT_MAIN $tab x2, "if (strcmp(argv[i], \"-vcd\") == 0) {\n";
        print OUT_MAIN $tab x3, "vcd_dump = 1;\n";
        print OUT_MAIN $tab x3, "if (i < argc - 1 && *argv[i+1] != '-') {\n";
        print OUT_MAIN $tab x4, "vcd_depth = atoi(argv[i+1]);\n";
        print OUT_MAIN $tab x4, "i++;\n";
        print OUT_MAIN $tab x3, "}\n";
        print OUT_MAIN $tab x2, "}\n";
        $init = 1;
    }

    foreach $elm (@clk_symbol_list) {
        if (@$elm[0] ne "") {
            if ($init == 0) {
                print OUT_MAIN $tab x2, "if (strcmp(argv[i], \"-@$elm[1]\") == 0)";
                $init = 1;
            }
            else {
                print OUT_MAIN $tab x2, "else if (strcmp(argv[i], \"-@$elm[1]\") == 0)";
            }
            print OUT_MAIN " {\n";
            print OUT_MAIN $tab x3, "if (i < argc - 1 && *argv[i+1] != '-') {\n";
            print OUT_MAIN $tab x4, "@$elm[1]_period = atoi(argv[i+1]);\n";
            print OUT_MAIN $tab x4, "i++;\n";
            print OUT_MAIN $tab x3, "}\n";
            print OUT_MAIN $tab x2, "}\n";
        }
    }

    if ($out_mode == 0) {
        print OUT_MAIN $tab x2, "// command line sample (you can customize)\n";
        print OUT_MAIN $tab x2, "else if (strcmp(argv[i], \"-mode\") == 0) {\n";
        print OUT_MAIN $tab x3, "i++;\n";
        print OUT_MAIN $tab x3, "if (i < argc) {\n";
        print OUT_MAIN $tab x4, "if (strcmp(argv[i], \"0\") == 0) {\n";
        print OUT_MAIN $tab x4, "}\n";
        print OUT_MAIN $tab x4, "else {\n";
        print OUT_MAIN $tab x4, "}\n";
        print OUT_MAIN $tab x3, "}\n";
        print OUT_MAIN $tab x2, "}\n";
    }
    print OUT_MAIN $tab x1, "}\n";
    print OUT_MAIN "\n";

    print OUT_MAIN $tab, "sc_set_time_resolution(1, SC_PS);\n";
    #foreach $elm (@clk_list)
    foreach $elm (@clk_symbol_list) {
        if (@$elm[0] ne "") {
            print OUT_MAIN $tab, "sc_clock @$elm[0](\"@$elm[0]\", @$elm[1]_period, @$elm[2]);\n";
        }
    }
    print OUT_MAIN "\n";

    foreach $elm (@clk_symbol_list) {
        if (@$elm[0] ne "") {
            my $unit = "ns";
            $unit = "ps" if(@$elm[2] eq "SC_PS");
            print OUT_MAIN $tab, "printf(\"@$elm[0]: \%d $unit (you can change this clock period by \\\"-@$elm[1] PERIOD\\\")\\n\", @$elm[1]_period);\n";
        }
    }

    # memory allocation
    if ($out_mode == 0) {
        $start = 1;
        @mem_used = ();
        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 1);
            my $skip = 0;
            foreach $used (@mem_used) {
                if ($used eq @$elm[M_NAME]) {
                    $skip = 1;
                    last;
                }
            }
            push(@mem_used, @$elm[M_NAME]);
            if ($skip == 0) {
                if ($start == 1) {
                    print OUT_MAIN "\n";
                    $start = 0;
                }
                $type = &get_type(@$elm[M_SIGN] == 1 ? "svar" : "var", @$elm[M_WID]);
                print OUT_MAIN $tab, "ptr_", @$elm[M_NAME], " = new ",
                      $type, " [@${elm[M_SIZE]}];\n";
            }
        }
    }

    # module instances
    print OUT_MAIN "\n";

    print OUT_MAIN $tab, "$module_name ";
    if ($style_alloc eq "static") {
        print OUT_MAIN "${module_name}0(\"${module_name}0\");\n";
    }
    else {
        print OUT_MAIN "*${module_name}0 = new $module_name(\"${module_name}0\");\n";
    }
    if ($out_mode == 1) {
        print OUT_MAIN $tab, "$module_name$postfix ";
        if ($style_alloc eq "static") {
            print OUT_MAIN "${module_name}${postfix}0(\"${module_name}${postfix}0\");\n";
        }
        else {
            print OUT_MAIN "*${module_name}${postfix}0 = new ${module_name}${postfix}(\"${module_name}${postfix}0\");\n";
        }
    }

    print OUT_MAIN $tab, "tb_$module_name$postfix ";
    if ($style_alloc eq "static") {
        print OUT_MAIN "tb_${module_name}${postfix}0(\"tb_${module_name}${postfix}0\");\n";
    }
    else {
        print OUT_MAIN "*tb_${module_name}${postfix}0 = new tb_${module_name}${postfix}(\"tb_${module_name}${postfix}0\");\n";
    }
    if ( $out_mode == 0 && $hdl_vcs_on == 1) {
        print OUT_MAIN "#ifdef VCS_SYSTEMC\n";
        print OUT_MAIN $tab, "$hdl_module ${hdl_module}0(\"${hdl_module}0\");\n";
        print OUT_MAIN "#endif\n";
    }

    if ($out_mode == 0) {
        if ($use_aigen == 1) {
            print OUT_MAIN "\n";
            print OUT_MAIN "#if defined(_VCS_AIP) && !defined(_IES_ABVIP)\n";
            print OUT_MAIN $tab, "${module_name}_vcs_apb_monitor ";
            if ($style_alloc eq "static") {
                print OUT_MAIN "${module_name}_vcs_apb_monitor0(\"${module_name}_vcs_apb_monitor0\");\n";
            }
            else {
                print OUT_MAIN "*${module_name}_vcs_apb_monitor0 = new ${module_name}_vcs_apb_monitor(\"${module_name}_vcs_apb_monitor0\");\n";
            }
            print OUT_MAIN "#endif\n";

            print OUT_MAIN "\n";
            print OUT_MAIN "#if !defined(_VCS_AIP) && defined(_IES_ABVIP)\n";
            print OUT_MAIN $tab, "${module_name}_ies_apb_monitor ";
            if ($style_alloc eq "static") {
                print OUT_MAIN "${module_name}_ies_apb_monitor0(\"${module_name}_ies_apb_monitor0\");\n";
            }
            else {
                print OUT_MAIN "*${module_name}_ies_apb_monitor0 = new ${module_name}_ies_apb_monitor(\"${module_name}_ies_apb_monitor0\");\n";
            }
            print OUT_MAIN "#endif\n";
        }

        if ($opt_sva == 1) {
            print OUT_MAIN "\n";
            print OUT_MAIN "#ifdef _USE_SVA\n";
            print OUT_MAIN $tab, "${module_name}_sva ";
            if ($style_alloc eq "static") {
                print OUT_MAIN "${module_name}_sva0(\"${module_name}_sva0\");\n";
            }
            else {
                print OUT_MAIN "*${module_name}_sva0 = new ${module_name}_sva(\"${module_name}_sva0\");\n";
            }
            print OUT_MAIN "#endif\n";
        }

        # instance of memory and mem_interface
        &print_main_memins();
    }

    # signals for reset
    print OUT_MAIN "\n";
    foreach $elm (@rst_list) {
        if (@$elm[T_TYPE] ne "soft_reset" && @$elm[T_NAME] ne "") {
            print OUT_MAIN $tab, "sc_signal < bool > @$elm[T_NAME];\n";
        }
    }

    # signals for port
    foreach $elm (@in_list) {
        next if (@$elm[T_NAME] eq "");
        my $name = @$elm[T_NAME];
        if (@$elm[T_FLG] & FLG_STR_TYPE) {
            print OUT_MAIN "#ifndef _MODE_RTL\n" if ($out_mode == 0);
            print OUT_MAIN $tab, &get_type(@$elm[T_TYPE] =~ /^s/ ? "sreg" : "ureg", @$elm[T_WID]);
            print OUT_MAIN " $name@$elm[T_ARRAY];\n";
            print OUT_MAIN "#else\n" if ($out_mode == 0);
            my @rtl_port;
            &get_rtl_port(\@rtl_port, $elm);
            foreach my $e (@rtl_port) {
                $name = @$e[T_NAME];
                $name =~ s/://g;
                print OUT_MAIN $tab, &get_type(@$e[T_TYPE] =~ /^s/ ? "sreg" : "ureg", @$e[T_WID]);
                print OUT_MAIN " $name@$e[T_ARRAY];\n";
            }
            print OUT_MAIN "#endif\n" if ($out_mode == 0);
        } else {
            print OUT_MAIN $tab, &get_type(@$elm[T_TYPE] =~ /^s/ ? "sreg" : "ureg", @$elm[T_WID]);
            print OUT_MAIN " $name@$elm[T_ARRAY];\n";
        }
    }
    foreach $elm (@out_list) {
        next if (@$elm[T_NAME] eq "");
        my $name = @$elm[T_NAME];
        my $type = &get_type(@$elm[T_TYPE] =~ /^s/ ? "sreg" : "ureg", @$elm[T_WID]);
        if (@$elm[T_FLG] & FLG_STR_TYPE) {
            if ($out_mode == 0) {
                print OUT_MAIN "#ifndef _MODE_RTL\n";
                print OUT_MAIN $tab, "$type ${name}@$elm[T_ARRAY];\n";
                print OUT_MAIN "#else\n";
            }
            else {
                print OUT_MAIN $tab, "$type ${name}_s@$elm[T_ARRAY];\n";
            }
            my @rtl_port;
            &get_rtl_port(\@rtl_port, $elm);
            foreach my $e (@rtl_port) {
                $name = @$e[T_NAME];
                $name =~ s/://g;
                $type = &get_type(@$e[T_TYPE] =~ /^s/ ? "sreg" : "ureg", @$e[T_WID]);
                if ($out_mode == 0) {
                    print OUT_MAIN $tab, "$type ${name}@$e[T_ARRAY];\n";
                }
                else {
                    print OUT_MAIN $tab, "$type ${name}_s@$e[T_ARRAY];\n";
                    print OUT_MAIN $tab, "$type ${name}_r@$e[T_ARRAY];\n";
                }
            }
            print OUT_MAIN "#endif\n" if ($out_mode == 0);
        } else {
            if ($out_mode == 0) {
                print OUT_MAIN $tab, "$type ${name}@$elm[T_ARRAY];\n";
            }
            else {
                print OUT_MAIN $tab, "$type ${name}_s@$elm[T_ARRAY];\n";
                print OUT_MAIN $tab, "$type ${name}_r@$elm[T_ARRAY];\n";
            }
        }
    }

    if ($top_mode == 1) {
        foreach $elm (@in_list_insert) {
            if (@$elm[T_NAME] ne "") {
                print OUT_MAIN $tab, &get_type(@$elm[T_TYPE] =~ /^s/ ? "sreg" : "ureg", @$elm[T_WID]);
                print OUT_MAIN " @$elm[T_NAME]@$elm[T_ARRAY];\n";
            }
        }
        foreach $elm (@out_list_insert) {
            if (@$elm[T_NAME] ne "") {
                $type = &get_type(@$elm[T_TYPE] =~ /^s/ ? "sreg" : "ureg", @$elm[T_WID]);
                if ($out_mode == 0) {
                    print OUT_MAIN $tab, "$type @$elm[T_NAME]@$elm[T_ARRAY];\n";
                }
                else {
                    print OUT_MAIN $tab, "$type @$elm[T_NAME]_s@$elm[T_ARRAY];\n";
                    print OUT_MAIN $tab, "$type @$elm[T_NAME]_r@$elm[T_ARRAY];\n";
                }
            }
        }
    }

    if ($out_mode == 0) {
        #signals for memory
        &print_main_memsig;

        if ($hdl_ies_on == 1 || $hdl_vcs_on == 1) {
            $outfile = $hdl_module . "_" . $module_name . "_sc_main" . ".svh";
            &my_open(*OUT_SVH, "//", "sva", 0);

            print OUT_MAIN "\n";
            if ($hdl_ies_on == 1) {
                print OUT_MAIN "#ifdef NC_SYSTEMC\n";
                foreach $elm (@clk_list,@rst_list,@in_list,@out_list) {
                    if (@$elm[T_NAME] ne "") {
                        my $name = @$elm[T_NAME];
                        my $array = @$elm[T_ARRAY];
                        my $width = @$elm[T_WID];
                        my $type  = @$elm[T_TYPE];
                        if (@$elm[T_FLG] & FLG_STR_TYPE) {
                            #my @rtl_port;
                            #&get_rtl_port(\@rtl_port, $elm);
                            #foreach my $e (@rtl_port) {
                            #    $name = @$e[T_NAME];
                            #    $name =~ s/://g;
                            #    $array = @$e[T_ARRAY];
                            #    $width = @$e[T_WID];
                            #    $type  = @$e[T_TYPE];
                            #    &print_hdl_connection($name, $array, $width, $type, *OUT_MAIN, *OUT_SVH, 1, "ies");
                            #}
                        } else {
                            &print_hdl_connection($name, $array, $width, $type, *OUT_MAIN, *OUT_SVH, 1, "ies");
                        }
                    }
                }
                print OUT_MAIN "#endif\n"
            }
            if ($hdl_vcs_on == 1) {
                print OUT_MAIN "#ifdef VCS_SYSTEMC\n";
                foreach $elm (@clk_list,@rst_list,@in_list,@out_list) {
                    if (@$elm[T_NAME] ne "") {
                        my $name = @$elm[T_NAME];
                        my $array = @$elm[T_ARRAY];
                        my $width = @$elm[T_WID];
                        my $type  = @$elm[T_TYPE];
                        if (@$elm[T_FLG] & FLG_STR_TYPE) {
                            #my @rtl_port;
                            #&get_rtl_port(\@rtl_port, $elm);
                            #foreach my $e (@rtl_port) {
                            #    $name = @$e[T_NAME];
                            #    $name =~ s/://g;
                            #    $array = @$e[T_ARRAY];
                            #    $width = @$e[T_WID];
                            #    $type  = @$e[T_TYPE];
                            #    &print_hdl_connection($name, $array, $width, $type, *OUT_MAIN, *OUT_SVH, 1, "vcs");
                            #}
                        } else {
                            &print_hdl_connection($name, $array, $width, $type, *OUT_MAIN, *OUT_SVH, 1, "vcs");
                        }
                    }
                }
                print OUT_MAIN "#endif\n"
            }
        }
    }

    if ($out_mode == 0) {
        # binding model
        print OUT_MAIN "\n";
        &print_main_bind(0);

        # binding testbench
        print OUT_MAIN "\n";
        &print_main_bind(1);

        # binding VIP
        if ($use_aigen == 1) {
            print OUT_MAIN "\n";
            print OUT_MAIN "#if defined(_VCS_AIP) && !defined(_IES_ABVIP)\n";
            &print_main_bind_vip(0);
            print OUT_MAIN "#endif\n";

            print OUT_MAIN "\n";
            print OUT_MAIN "#if !defined(_VCS_AIP) && defined(_IES_ABVIP)\n";
            &print_main_bind_vip(1);
            print OUT_MAIN "#endif\n";
        }

        # binding SVA
        if ($opt_sva == 1) {
            print OUT_MAIN "\n";
            print OUT_MAIN "#ifdef _USE_SVA\n";
            &print_main_bind(2);
            print OUT_MAIN "#endif\n";
        }

        # binding interface
        @mem_used = ();
        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 1);
            my $skip = 0;
            if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                foreach $used (@mem_used) {
                    if ($used eq @$elm[M_NAME]) {
                        $skip = 1;
                        last;
                    }
                }
                push(@mem_used, @$elm[M_NAME]);
            }
            if ($skip == 0) {
                if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                    if ($top_mode == 0 || ($top_mode == 1 && @$elm[M_SHARE] == 0)) {
                        $ifnm = &get_mem_ifnm(\@$elm);
                        &print_main_memif_bind($ifnm);
                    }
                }
            }
        }

        # binding memory
        &print_main_membind;

        # vcd trace
        my $a = $style_alloc eq "static" ? "." : "->";
        print OUT_MAIN "\n";
        if ($opt_standard) {
            print OUT_MAIN $tab, " sc_trace_file *tf = NULL;\n";
            print OUT_MAIN $tab, "if (vcd_dump == 1) tf = sc_create_vcd_trace_file(\"$module_name\");\n";
        }
        else {
            print OUT_MAIN $tab, "ssgen_trace_file *tf = NULL;\n";
            print OUT_MAIN $tab, "if (vcd_dump == 1) tf = create_ssgen_trace_file(\"$module_name\");\n";
        }
        print OUT_MAIN "#ifndef $rtl_macro\n";
        print OUT_MAIN $tab, "${module_name}0${a}vcd_trace(tf, vcd_depth);\n";
        print OUT_MAIN "#endif\n";
        print OUT_MAIN $tab, "tb_${module_name}0${a}vcd_trace(tf);\n";

        @mem_used = ();
        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 1);
            my $skip = 0;
            foreach $used (@mem_used) {
                if ($used eq @$elm[M_NAME]) {
                    $skip = 1;
                    last;
                }
            }
            push(@mem_used, @$elm[M_NAME]);
            if ($skip == 0) {
                print OUT_MAIN "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);
                if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                    if ($top_mode == 0 || ($top_mode == 1 && @$elm[M_SHARE] == 0)) {
                        $ifnm = &get_mem_ifnm(\@$elm);
                        print OUT_MAIN $tab, "${ifnm}0${a}vcd_trace(tf);\n";
                    }
                }
                print OUT_MAIN $tab, "@$elm[M_NAME].vcd_trace(tf);\n";
                print OUT_MAIN "#endif\n" if (@$elm[M_PONLY] == 0);
            }
        }
    }
    else {
        # print binding model
        print OUT_MAIN "\n";
        &print_main_bind_sim_eq(0);

        # print binding clone
        print OUT_MAIN "\n";
        &print_main_bind_sim_eq(1);

        # print binding tb
        print OUT_MAIN "\n";
        &print_main_bind_sim_eq(2);

        # print file access
        for ($i=0; $i<@out_list_enable; $i++) {
            print OUT_MAIN $tab, "scout$i = fopen(\"sc$i.log\", \"w\");\n";
            print OUT_MAIN $tab, "rtlout$i = fopen(\"rtl$i.log\", \"w\");\n";
        }
    }

    print OUT_MAIN "\n";
    print OUT_MAIN $tab, "sc_start();\n";
    print OUT_MAIN "\n";
    if ($out_mode == 0) {
        print OUT_MAIN $tab, "if (vcd_dump == 1) {\n";
        print OUT_MAIN $tab x2, "sc_close_vcd_trace_file(tf);\n";
        print OUT_MAIN $tab x2, "ssgen_trace_post(\"$module_name.vcd\");\n" if (!$opt_standard);
        print OUT_MAIN $tab, "}\n";
        print OUT_MAIN "\n";
    }

    if ($out_mode == 1) {
        for ($i=0; $i<@out_list_enable; $i++) {
            print OUT_MAIN $tab, "fclose(scout$i);\n";
            print OUT_MAIN $tab, "fclose(rtlout$i);\n";
        }
        print OUT_MAIN "\n";
    }

    print OUT_MAIN $tab, "return 0;\n";
    print OUT_MAIN "}\n";
    close(OUT_MAIN);
    if ($top_mode == 0 && $use_template == 1) {
        $module_name = $org_module_name;
    }
}

##
## print port declaration in test bench
##  $elm        : target port
##  $out_mode   : testbench output mode (0: normal, 1: sim_eq)
##  $dir        : direction (0: input, 1: output)
##
sub print_tb_port_decl {
    my $elm = $_[0];
    my $out_mode = $_[1];
    my $dir = $_[2];

    my $name = @$elm[T_NAME];
    my $type = "";
    my $array = @$elm[T_ARRAY];
    my $tmpl_list = @{$tmpl_inst_list[0]}[MOD_TMPL];
    if ($top_mode == 0 && &is_template_parameter(@$elm[T_WID]) == 1) {
        $type = ($dir == 0) ? "sc_out < " : "sc_in < ";
        foreach $tmp (@$tmpl_list) {
            if (@$elm[T_WID] eq @$tmp[0]) {
                $type = $type . @$tmp[1];
                last;
            }
        }
        $type = $type . " >";
        # modify for sim related generation
        @$elm[T_TYPE] = ($type =~ /uint/) ? "u" : "";
        @$elm[T_TYPE] .= ($dir == 0) ? "in" : "out";
        $type =~ /\<\s*(\d+)\s*\>/;
        @$elm[T_WID] = $1;
    }
    else {
        $type = &get_type(@$elm[T_TYPE], @$elm[T_WID], 1);
    }
    if ($top_mode == 0 && @$elm[T_ARRAY] ne "") {
        $array = "";
        while (@$elm[T_ARRAY] =~ /\w+/g) {
            my $i = $&;
            if (&is_template_parameter($i) == 1) {
                foreach $tmp (@$tmpl_list) {
                    if ($i eq @$tmp[0]) {
                        $i = @$tmp[1];
                        last;
                    }
                }
            }
            $array.= "[$i]";
        }
        # modify for sim related generation
        @$elm[T_ARRAY] = $array;
    }
    if (@$elm[T_FLG] & FLG_STR_TYPE) {
        if ($out_mode == 0) {
            print OUT_TB_H "#ifndef _MODE_RTL\n";
            print OUT_TB_H $tab, "$type $name@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
            print OUT_TB_H "#else\n";
        }
        else {
            if ($dir == 0) {
                print OUT_TB_H $tab, "$type ${name}@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
            }
            else {
                print OUT_TB_H $tab, "$type ${name}_s@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
            }
        }
        my @rtl_port;
        &get_rtl_port(\@rtl_port, $elm);
        foreach my $e (@rtl_port) {
            $type = &get_type(@$e[T_TYPE], @$e[T_WID], 1);
            $name = @$e[T_NAME];
            $name =~ s/://g;
            if ($out_mode == 0) {
                print OUT_TB_H $tab, "$type $name;", &comment(@$em[T_COM], 1);
                print OUT_TB_H "#endif\n";
            }
            else {
                if ($dir == 0) {
                    print OUT_TB_H $tab, "$type ${name};", &comment(@$elm[T_COM], 1);
                }
                else {
                    print OUT_TB_H $tab, "$type ${name}_r;", &comment(@$elm[T_COM], 1);
                }
            }
        }
    } else {
        if ($out_mode == 0) {
            print OUT_TB_H $tab, "$type $name$array;", &comment(@$elm[T_COM], 1);
        }
        else {
            if ($dir == 0) {
                print OUT_TB_H $tab, "$type ${name}$array;", &comment(@$elm[T_COM], 1);
            }
            else {
                print OUT_TB_H $tab, "$type ${name}_s$array;", &comment(@$elm[T_COM], 1);
                print OUT_TB_H $tab, "$type ${name}_r$array;", &comment(@$elm[T_COM], 1);
            }
        }
    }
}

##
## generate testbench header
##   $out_mode : print mode (= 0: ocsi/vcs/ies, 1: sim_eq)
##
sub gen_tb_h {
    $out_mode = $_[0];
    $postfix = ($out_mode == 0) ? "" : "_eq";
    if ($top_mode == 0 && $use_template == 1) {
        $module_name = @{$tmpl_inst_list[0]}[MOD_NAME];
    }
    $subdir  = ($out_mode == 0) ? "tb" : "sim_eq/$module_name";
    $tb_mode = ($out_mode == 0) ? 1 : 0;
    $outfile = "tb_" . $module_name . $postfix . ".h";
    &my_open(*OUT_TB_H, "//", $subdir, 0);

    # global
    print OUT_TB_H "#ifndef " . uc "tb_${module_name}${postfix}_h" . "\n";
    print OUT_TB_H "#define " . uc "tb_${module_name}${postfix}_h" . "\n";

    # #include & #define
    print OUT_TB_H "\n";
    print OUT_TB_H "#include <systemc.h>\n";
    print OUT_TB_H "#include \"ssgenlib.h\"\n" if (!$opt_standard);
    print OUT_TB_H "\n" if (@prepro_list > 0 || @prepro_list_tb > 0);
    &print_kept_ssgen_define(*OUT_TB_H, $infile, 2);
    &print_preprocessor(*OUT_TB_H);
    my $incl_list = "";
    foreach my $s (@struct_list) {
        my $struct_header = @$s[STR_NAME];
        if ($incl_list !~ /\b$struct_header\b/) {
            print OUT_TB_H "#include \"$struct_header.h\"\n";
            $incl_list = "$incl_list  $struct_header ";
        }
    }

    # memory pointer
    if ($out_mode == 0) {
        &print_tb_memory_ptr;
    }

    # module
    &print_module_def(*OUT_TB_H, "tb_".$module_name . $postfix);

    # clock
    foreach $elm (@clk_list) {
        if (@$elm[T_NAME] ne "") {
            print OUT_TB_H $tab, "sc_in < bool > @$elm[T_NAME];", &comment(@$elm[T_COM], 1);
        }
    }

    # reset
    foreach $elm (@rst_list) {
        if (@$elm[T_TYPE] ne "soft_reset" && @$elm[T_NAME] ne "") {
            print OUT_TB_H $tab, "sc_out < bool > @$elm[T_NAME];", &comment(@$elm[T_COM], 1);
        }
    }

    # port
    foreach $elm (@in_list) {
        if (@$elm[T_NAME] ne "") {
            &print_tb_port_decl($elm, $out_mode, 0);
        }
    }
    foreach $elm (@out_list) {
        if (@$elm[T_NAME] ne "") {
            &print_tb_port_decl($elm, $out_mode, 1);
        }
    }

    # data member for struct
    foreach $elm (@in_list, @out_list) {
        if (@$elm[T_NAME] ne "" && (@$elm[T_FLG] & FLG_STR_TYPE) ) {
            if (@$elm[T_TYPE] =~ /^[us]in$/ || $out_mode == 0) {
                print OUT_TB_H $tab, "@$elm[T_WID] m_@$elm[T_NAME]@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
            }
            else {
                print OUT_TB_H $tab, "@$elm[T_WID] m_@$elm[T_NAME]_s@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
                print OUT_TB_H $tab, "@$elm[T_WID] m_@$elm[T_NAME]_r@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
            }
        }
    }

    # insert_port
    if ($top_mode == 1) {
        foreach $elm (@in_list_insert) {
            if (@$elm[T_NAME] ne "") {
                print OUT_TB_H $tab, &get_type(@$elm[T_TYPE], @$elm[T_WID], 1);
                print OUT_TB_H " @$elm[T_NAME]@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
            }
        }
        foreach $elm (@out_list_insert) {
            if (@$elm[T_NAME] ne "") {
                $type = &get_type(@$elm[T_TYPE], @$elm[T_WID], 1);
                if ($out_mode == 0) {
                    print OUT_TB_H $tab, "$type @$elm[T_NAME]@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
                }
                else {
                    print OUT_TB_H $tab, "$type @$elm[T_NAME]_s@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
                    print OUT_TB_H $tab, "$type @$elm[T_NAME]_r@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
                }
            }
        }
    }

    if ($out_mode == 0) {
        # memory
        &print_tb_memory_def;

        # reg, var, ctype
        &print_tb_decl_data;

        # free area
        &print_free_area(*OUT_TB_H, 1);
    }

    # constructor
    &print_tb_constructor($out_mode);

    # reset_function
    &print_tb_reset_func($out_mode);

    # wait function
    &print_tb_wait_func($out_mode);

    if ($out_mode == 0) {
        # memory function
        &print_tb_memory_func;

        # function
        &print_func_one(*OUT_TB_H, 1, \@func_list_tb);

        # VCD trace
        &print_tb_vcd_trace_func;
    }

    print OUT_TB_H "\n";
    print OUT_TB_H $tab, "void thread_main();\n";
    print OUT_TB_H $tab, "void thread_monitor();\n" if ($out_mode == 1);
    print OUT_TB_H "};\n\n";
    print OUT_TB_H "#endif // " . uc "tb_${module_name}${postfix}_h" . "\n";
    close(OUT_TB_H);
    $tb_mode = 0;
    if ($top_mode == 0 && $use_template == 1) {
        $module_name = $org_module_name;
    }
}

##
## generate testbench source
##   $out_mode : print mode (= 0: ocsi/vcs/ies, 1: sim_eq)
##
sub gen_tb_cpp {
    $out_mode = $_[0];
    $postfix = ($out_mode == 0) ? "" : "_eq";
    if ($top_mode == 0 && $use_template == 1) {
        $module_name = @{$tmpl_inst_list[0]}[MOD_NAME];
    }
    $subdir  = ($out_mode == 0) ? "tb" : "sim_eq/$module_name";
    $tb_mode = ($out_mode == 0) ? 1 : 0;
    $outfile = "tb_" . $module_name . $postfix . ".cpp";
    &my_open(*OUT_TB_CPP, "//", $subdir, 0);

    # calculate max_cnt pipeline latency
    $max_lat = 3;
    foreach my $elm (@thread_list) {
        next if (@$elm[TH_NAME] eq "");
        if (@$elm[TH_LAT] > $max_lat) {
            $max_lat = @$elm[TH_LAT];
        }
    }

    # global
    print OUT_TB_CPP "// tb_$module_name$postfix.cpp\n";
    print OUT_TB_CPP "#include \"tb_$module_name$postfix.h\"\n";

    # file pointers
    if ($out_mode == 1) {
        print OUT_TB_CPP "\n";
        for ($i=0; $i<@out_list_enable; $i++) {
            print OUT_TB_CPP "extern FILE *scout$i;\n";
            print OUT_TB_CPP "extern FILE *rtlout$i;\n";
        }
    }


    if ($out_mode == 0) {
        # const
        @list = (@var_list_tb, @ctype_list_tb);
        if (&exist_const(\@list) == 1) {
            print OUT_TB_CPP "\n";
            &print_const_init_data(*OUT_TB_CPP, \@list, 1);
        }
    }

    # main thread
    print OUT_TB_CPP "\n";
    print OUT_TB_CPP "void tb_${module_name}${postfix}::thread_main() {\n";
    print OUT_TB_CPP $tab, "reset_function();\n";
    if ($out_mode == 0) {
        print OUT_TB_CPP $tab, "wait();\n";
        print OUT_TB_CPP $tab, "// please write here!\n";
    }
    else {
        print OUT_TB_CPP $tab, "wait(10);\n";
        # reset
        foreach $elm (@rst_list) {
            if (@$elm[T_TYPE] ne "soft_reset" && @$elm[T_NAME] ne "") {
                print OUT_TB_CPP $tab, "@$elm[T_NAME].write(";
                print OUT_TB_CPP @$elm[T_INIT] eq "pos" ? "0" : "1", ");\n";
            }
        }
        print OUT_TB_CPP "\n";
        print OUT_TB_CPP $tab, "srand(0);\n";
        print OUT_TB_CPP "\n";
        # enable - 1st
        foreach $elm (@in_list, @in_list_insert) {
            next if (@$elm[T_NAME] eq "");
            if (@$elm[T_FLG] & FLG_CATG_EN) {
                print OUT_TB_CPP $tab, "@$elm[T_NAME].write(";
                print OUT_TB_CPP ((@$elm[T_FLG] & FLG_ACTV_LOW) ? "1" : "0") . ");\n";
            }
        }

        # stall - 1st
        foreach $elm (@in_list, @in_list_insert) {
            next if (@$elm[T_NAME] eq "");
            if (@$elm[T_FLG] & FLG_CATG_STALL) {
                print OUT_TB_CPP $tab, "@$elm[T_NAME].write(";
                print OUT_TB_CPP ((@$elm[T_FLG] & FLG_ACTV_LOW) ? "1" : "0") . ");\n";
            }
        }
        print OUT_TB_CPP $tab, "wait();\n";
        print OUT_TB_CPP "\n";
        print OUT_TB_CPP $tab, "#include \"${module_name}_stimulus.h\"\n";
        print OUT_TB_CPP "\n";
        foreach $elm (@in_list, @in_list_insert) {
            next if (@$elm[T_NAME] eq "");
            if ((@$elm[T_FLG] & FLG_CATG_EN) || (@$elm[T_FLG] & FLG_CATG_STALL)) {
                print OUT_TB_CPP $tab, "@$elm[T_NAME].write(";
                print OUT_TB_CPP (@$elm[T_FLG] & FLG_ACTV_LOW) ? "1" : "0", ");\n";
            }
        }
        print OUT_TB_CPP $tab, "wait($max_lat);\n";
        print OUT_TB_CPP "\n";
        for (my $i=0; $i<10; $i++) {
            print OUT_TB_CPP $tab, "$wait_name();\n";
        }
    }
    print OUT_TB_CPP "\n";
    print OUT_TB_CPP $tab, "$wait_name();\n";
    print OUT_TB_CPP $tab, "sc_stop();\n";
    print OUT_TB_CPP $tab, "$wait_name();\n";
    print OUT_TB_CPP "}\n";

    if ($out_mode == 0) {
        # function
        if (@func_list_tb > 0) {
            print OUT_TB_CPP "\n";
            print_func_one(*OUT_TB_CPP, 2, \@func_list_tb, "tb_");
        }
    }
    else {
        # monitor thread
        print OUT_TB_CPP "\n";
        print OUT_TB_CPP "void tb_${module_name}${postfix}::thread_monitor() {\n";
        print OUT_TB_CPP $tab, "while (1) {\n";
        $init = 0;
        foreach $elm (@in_list, @in_list_insert) {
            next if (@$elm[T_NAME] eq "" || !(@$elm[T_FLG] & FLG_CATG_STALL));
            if ($init == 0) {
                print OUT_TB_CPP $tab x2, "while (";
                $init = 1;
            }
            else {
                print OUT_TB_CPP " && ";
            }
            print OUT_TB_CPP (@$elm[T_FLG] & FLG_ACTV_LOW) ? "!" : "";
            print OUT_TB_CPP "@$elm[T_NAME].read()";
        }
        if ($init == 1) {
            print OUT_TB_CPP ") {\n";
            print OUT_TB_CPP $tab x3, "wait();\n";
            print OUT_TB_CPP $tab x2, "}\n";
        }
        for (my $i=0; $i<@out_list_enable; $i++) {
            $en = $out_list_enable[$i];
            $indent = (@$en[T_NAME] eq "") ? $tab x2 : $tab x3;

            # monitor for SystemC
            print OUT_TB_CPP $tab x2, "// scout$i\n";
            if (@$en[T_NAME] ne "") {
                print OUT_TB_CPP $tab x2, "if (";
                print OUT_TB_CPP "!" if (@$en[T_FLG] & FLG_ACTV_LOW);
                print OUT_TB_CPP "@$en[T_NAME]_s.read()) {\n";
            }
            foreach $port (@out_list, @out_list_insert) {
                next if (@$port[T_NAME] eq "" || @$port[T_ENAME] ne @$en[T_NAME]);
                if (@$port[T_FLG] & FLG_CATG_DATA) {
                    &print_port_monitor("scout$i", @$port[T_NAME] . "_s",
                        @$port[T_TYPE], @$port[T_ARRAY], @$port[T_WID], $indent);
                }
            }
            print OUT_TB_CPP $indent, "fprintf(scout$i, \"\\n\");\n";
            print OUT_TB_CPP $tab x2, "}\n" if (@$en[T_NAME] ne "");
            print OUT_TB_CPP "\n";

            # monitor for HLS-RTL
            print OUT_TB_CPP $tab x2, "// rtlout$i\n";
            if (@$en[T_NAME] ne "") {
                print OUT_TB_CPP $tab x2, "if (";
                print OUT_TB_CPP "!" if (@$en[T_FLG] & FLG_ACTV_LOW);
                print OUT_TB_CPP "@$en[T_NAME]_r.read()) {\n";
            }
            foreach $port (@out_list, @out_list_insert) {
                next if (@$port[T_NAME] eq "" || @$port[T_ENAME] ne @$en[T_NAME]);
                if (@$port[T_FLG] & FLG_CATG_DATA) {
                    &print_port_monitor("rtlout$i", @$port[T_NAME] . "_r",
                        @$port[T_TYPE], @$port[T_ARRAY], @$port[T_WID], $indent);
                }
            }
            print OUT_TB_CPP $indent, "fprintf(rtlout$i, \"\\n\");\n";
            print OUT_TB_CPP $tab x2, "}\n" if (@$en[T_NAME] ne "");
            print OUT_TB_CPP "\n";
        }
        print OUT_TB_CPP $tab x2, "wait();\n";
        print OUT_TB_CPP $tab, "}\n";
        print OUT_TB_CPP "}\n";

    }
    close(OUT_TB_CPP);
    $tb_mode = 0;
    if ($top_mode == 0 && $use_template == 1) {
        $module_name = $org_module_name;
    }
}

##
## generate synchronizer header
##
sub gen_sync_h {
    foreach $mod (@mod_list_sync) {
        $mod_name = @$mod[MOD_NAME];
        $mod_inst = @$mod[MOD_INST];
        $mod_dbg  = @$mod[MOD_DBG];
        @clk_name = ();
        @rst_name = ();
        @rst_type = ();
        @rst_init = ();

        $use_rx_thread = 0;
        if ($mod_dbg ne "") {
            foreach $elm (@bind_list) {
                if ((@$elm[B_FLG_E] & FLG_SYNC_EN) && (@$elm[B_INST_E] eq $mod_inst)) {
                    $use_rx_thread = 1;
                    last;
                }
            }
        }

        $outfile = $mod_name . ".h";
        &my_open(*OUT_SYNC_H, "//", "src", 0);

        # global
        $MOD_NAME = uc $mod_name;
        print OUT_SYNC_H "#ifndef ${MOD_NAME}_H\n";
        print OUT_SYNC_H "#define ${MOD_NAME}_H\n";

        # #include & #define
        print OUT_SYNC_H "\n";
        print OUT_SYNC_H "#include <systemc.h>\n";
        if ($opt_stratus) {
            print OUT_SYNC_H "#include <stratus_hls.h>\n";
        }
        print OUT_SYNC_H "#include \"ssgenlib.h\"\n" if (!$opt_standard);

        # module
        &print_module_def(*OUT_SYNC_H, $mod_name);

        # clock
        $i = 0;
        foreach $elm (@clk_list_sync) {
            if ((@$elm[T_NAME] ne "") && (@$elm[T_INST] eq $mod_inst)) {
                if ($i == 0 || $use_rx_thread) {
                    print OUT_SYNC_H $tab, "sc_in < bool > @$elm[T_NAME];", &comment(@$elm[T_COM], 1);
                }
                $clk_name[$i] = @$elm[T_NAME];
                $i++;
            }
        }

        # reset
        $i = 0;
        foreach $elm (@rst_list_sync) {
            if ((@$elm[T_NAME] ne "") && (@$elm[T_TYPE] ne "soft_reset") && (@$elm[T_INST] eq $mod_inst)) {
                if ($i == 0 || $use_rx_thread) {
                    print OUT_SYNC_H $tab, "sc_in < bool > @$elm[T_NAME];", &comment(@$elm[T_COM], 1);
                }
                $rst_name[$i] = @$elm[T_NAME];
                $rst_type[$i] = @$elm[T_TYPE];
                $rst_init[$i] = @$elm[T_INIT];
                $i++;
            }
        }

        # port
        foreach $elm (@in_list_sync) {
            if (@$elm[T_NAME] ne "" && @$elm[T_INST] eq $mod_inst) {
                print OUT_SYNC_H $tab, &get_type(@$elm[T_TYPE], @$elm[T_WID]);
                print OUT_SYNC_H " @$elm[T_NAME]@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
            }
        }
        foreach $elm (@out_list_sync) {
            if (@$elm[T_NAME] ne "" && @$elm[T_INST] eq $mod_inst) {
                print OUT_SYNC_H $tab, &get_type(@$elm[T_TYPE], @$elm[T_WID]);
                print OUT_SYNC_H " @$elm[T_NAME]@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
            }
        }

        # reg
        print OUT_SYNC_H "\n";
        &print_decl_data_one(*OUT_SYNC_H, \@reg_list_sync);

        # toggle coverage
        if ($mod_dbg eq "" && $toggle_cov_mode != 0) {
            foreach $m (@data_list_m) {
                $macro = shift(@$m);
                if ($macro eq $cov_macro) {
                    print OUT_SYNC_H "\n#ifdef $macro\n";
                    &print_decl_data_one(*OUT_SYNC_H, \@$m);
                    print OUT_SYNC_H "#endif\n";
                }
                unshift(@$m, $macro);
            }
        }

        if ($rst_type[0] eq "areset" || ($rst_type[1] eq "areset" && $use_rx_thread)) {
            print OUT_SYNC_H "\n#ifdef $osci_macro\n";
            if ($mod_dbg eq "") {
                print OUT_SYNC_H $tab, "sc_signal < bool > ssgen_merge_rst_main_thread;\n";
            }
            else {
                for (my $i=0; $i<2; $i++) {
                    if ($i == 0 || $use_rx_thread) {
                        my $j = (@rst_type == 1) ? 0 : $i;
                        if ($rst_type[$j] eq "areset") {
                            print OUT_SYNC_H $tab, "sc_signal < bool > ssgen_merge_rst_";
                            print OUT_SYNC_H $clk_name[$i] . "_thread;\n";
                        }
                    }
                }
            }
            print OUT_SYNC_H "#endif\n";
        }

        # constructor
        &print_sync_constructor;

        # cthread function
        if ($mod_dbg eq "") {
            &print_toggle_prepare_func(*OUT_SYNC_H);
            &print_toggle_check_func(*OUT_SYNC_H);
            &print_sync_thread(*OUT_SYNC_H, 1);
        }
        else {
            &print_chk_thread;
        }

        # method functions
        &print_sync_method(*OUT_SYNC_H, 1);

        # vcd trace func
        &print_sync_vcd_trace_func;

        print OUT_SYNC_H "};\n";
        print OUT_SYNC_H "\n";
        if ($mod_dbg eq "") {
            print OUT_SYNC_H "#ifdef __CTOS__\n";
            print OUT_SYNC_H "SC_MODULE_EXPORT($mod_name);\n";
            print OUT_SYNC_H "#endif\n";
            print OUT_SYNC_H "\n";
        }
        print OUT_SYNC_H "#endif // ${MOD_NAME}_H\n";

        close(OUT_SYNC_H);
    }
}

##
## generate synchronizer source
##
sub gen_sync_cpp {
    foreach $mod (@mod_list_sync) {
        $mod_name = @$mod[MOD_NAME];
        $mod_inst = @$mod[MOD_INST];
        $mod_dbg  = @$mod[MOD_DBG];
        $outfile = $mod_name . ".cpp";
        &my_open(*OUT_SYNC_CPP, "//", "src", 0);

        print OUT_SYNC_CPP "// ${mod_name}.cpp\n";
        print OUT_SYNC_CPP "#include \"${mod_name}.h\"\n";
        if ($mod_dbg eq "") {
            &print_sync_thread(*OUT_SYNC_CPP, 2);
        }

        &print_sync_method(*OUT_SYNC_CPP, 2);
        close(OUT_SYNC_CPP);
    }
}

##
## generate memory interface header
##
sub gen_memif_h {
    @mem_used = ();
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        my $skip = 0;
        foreach $used (@mem_used) {
            if ($used eq @$elm[M_NAME]) {
                $skip = 1;
                last;
            }
        }
        push(@mem_used, @$elm[M_NAME]);
        if ($skip == 0) {
            if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                return if ($opt_notb && @$elm[M_SHARE] == 0);
                $ifnm = &get_mem_ifnm(\@$elm);
                $IFNM = uc $ifnm;
                $outfile = "$ifnm" . ".h";
                &my_open(*OUT_H, "//", @$elm[M_SHARE] > 0 ? "src" : "tb", 0);

                # global
                print OUT_H "#ifndef ${IFNM}_H\n";
                print OUT_H "#define ${IFNM}_H\n";

                # #include & #define
                print OUT_H "\n";
                print OUT_H "#include <systemc.h>\n";
                print OUT_H "#include \"ssgenlib.h\"\n";
                print OUT_H "\n" if (@prepro_list > 0);
                &print_preprocessor(*OUT_H);

                # module
                &print_module_def(*OUT_H, "$ifnm");

                # port
                if (@$elm[M_SHARE] == 0) {
                    if (@$elm[M_RW] == MA_RW1_W) {
                        @$elm[M_RE] = 1;
                        @$elm[M_CS] = 1;
                    }
                    else {
                        if (@$elm[M_RE] > 0) {
                            @$elm[M_CS] = @$elm[M_RE];
                        }
                    }
                }
                else {
                    if (@$elm[M_RE] == 2) {
                        @$elm[M_CS] = 2;
                    }
                }
                print OUT_H $tab, &get_type("in", $size);
                print OUT_H " ", &get_mem_portnm(\@$elm, MP1_WA), ";\n";
                print OUT_H $tab, &get_type("in", "b");
                print OUT_H " ", &get_mem_portnm(\@$elm, MP1_WE), ";\n";
                print OUT_H $tab, &get_type("in", $size);
                print OUT_H " ", &get_mem_portnm(\@$elm, MP1_RA), ";\n";
                if (@$elm[M_RE] > 0) {
                    print OUT_H $tab, &get_type("in", "b");
                    print OUT_H " ", &get_mem_portnm(\@$elm, MP1_RE), ";\n";
                }
                print OUT_H $tab, &get_type("out", $size);
                print OUT_H " ", &get_mem_portnm(\@$elm, MP1_AD), ";\n";
                if (@$elm[M_RE] > 0) {
                    print OUT_H $tab, &get_type("out", "b");
                    print OUT_H " ", &get_mem_portnm(\@$elm, MP1_CS), ";\n";
                }

                # constructor
                &print_if_constructor;

                # VCD trace
                &print_if_vcd_trace_func;

                print OUT_H "\n";
                print OUT_H $tab, "void method_select_addr();\n";
                if (@$elm[M_RE] > 0) {
                    print OUT_H $tab, "void method_generate_cs();\n";
                }
                print OUT_H "};\n\n";
                print OUT_H "#ifdef __CTOS__\n";
                print OUT_H "SC_MODULE_EXPORT($ifnm);\n";
                print OUT_H "#endif\n";
                print OUT_H "\n";
                print OUT_H "#endif // ${IFNM}_H\n";
                close(OUT_H);
            }
        }
    }
}

##
## generate memory interface source
##
sub gen_memif_cpp {
    @mem_used = ();
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        my $skip = 0;
        foreach $used (@mem_used) {
            if ($used eq @$elm[M_NAME]) {
                $skip = 1;
                last;
            }
        }
        push(@mem_used, @$elm[M_NAME]);
        if ($skip == 0) {
            if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                return if ($opt_notb && @$elm[M_SHARE] == 0);
                $ifnm = &get_mem_ifnm(\@$elm);
                $IFNM = uc $ifnm;
                $outfile = "$ifnm" . ".cpp";
                &my_open(*OUT_CPP, "//", @$elm[M_SHARE] > 0 ? "src" : "tb", 0);
                print OUT_CPP "// ${ifnm}.cpp\n";
                print OUT_CPP "#include \"${ifnm}.h\"\n";

                $port_nm_we = &get_mem_portnm(\@$elm, MP1_WE);
                $port_nm_wa = &get_mem_portnm(\@$elm, MP1_WA);
                $port_nm_re = &get_mem_portnm(\@$elm, MP1_RE);
                $port_nm_ra = &get_mem_portnm(\@$elm, MP1_RA);
                $port_nm_cs = &get_mem_portnm(\@$elm, MP1_CS);
                $port_nm_ad = &get_mem_portnm(\@$elm, MP1_AD);

                # method for address selection
                print OUT_CPP "\n";
                print OUT_CPP "void ${ifnm}::method_select_addr() {\n";
                if (@$elm[M_RE] > 0) {
                    if (@$elm[M_WE] != 2) {
                        print OUT_CPP $tab, "if ($port_nm_we.read() == 1)\n";
                    }
                    else {
                        print OUT_CPP $tab, "if ($port_nm_we.read() == 0)\n";
                    }
                    print OUT_CPP $tab x2, "$port_nm_ad.write($port_nm_wa.read());\n";
                    if (@$elm[M_RE] == 1) {
                        print OUT_CPP $tab, "else if ($port_nm_re.read() == 1)\n";
                    }
                    else {
                        print OUT_CPP $tab, "else if ($port_nm_re.read() == 0)\n";
                    }
                    print OUT_CPP $tab x2, "$port_nm_ad.write($port_nm_ra.read());\n";
                    print OUT_CPP $tab, "else $port_nm_ad.write(0);\n";
                }
                else {
                    if (@$elm[M_WE] != 2) {
                        print OUT_CPP $tab, "if ($port_nm_we.read() == 1)\n";
                    }
                    else {
                        print OUT_CPP $tab, "if ($port_nm_we.read() == 0)\n";
                    }
                    print OUT_CPP $tab x2, "$port_nm_ad.write($port_nm_wa.read());\n";
                    print OUT_CPP $tab, "else $port_nm_ad.write($port_nm_ra.read());\n";
                }
                print OUT_CPP "}\n";

                # method for chip select generation
                if (@$elm[M_RE] > 0) {
                    print OUT_CPP "\n";
                    print OUT_CPP "void ${ifnm}::method_generate_cs() {\n";
                    if (@$elm[M_WE] != 2 && @$elm[M_RE] == 1) {
                        print OUT_CPP $tab, "if ($port_nm_we.read() == 1 && $port_nm_re.read() == 1) {\n";
                        print OUT_CPP $tab x2, "cout << \"[Warning @\" << sc_time_stamp()\n";
                        print OUT_CPP $tab x2, " << \"] Read/Write access conflict: \"\n";
                        print OUT_CPP $tab x2, " << name() << \"'s address = \" << $port_nm_wa.read() << endl;\n";
                        print OUT_CPP $tab, "}\n";
                        print OUT_CPP $tab, "$port_nm_cs.write($port_nm_we.read() | $port_nm_re.read());\n";
                    }
                    elsif (@$elm[M_WE] != 2 && @$elm[M_RE] == 2) {
                        print OUT_CPP $tab, "if ($port_nm_we.read() == 1 && $port_nm_re.read() == 0) {\n";
                        print OUT_CPP $tab x2, "cout << \"[Warning @\" << sc_time_stamp()\n";
                        print OUT_CPP $tab x2, " << \"] Read/Write access conflict: \"\n";
                        print OUT_CPP $tab x2, " << name() << \"'s address = \" << $port_nm_wa.read() << endl;\n";
                        print OUT_CPP $tab, "}\n";
                        print OUT_CPP $tab, "$port_nm_cs.write(!($port_nm_we.read() | !$port_nm_re.read()));\n";
                    }
                    elsif (@$elm[M_WE] == 2 && @$elm[M_RE] == 1) {
                        print OUT_CPP $tab, "if ($port_nm_we.read() == 0 && $port_nm_re.read() == 1) {\n";
                        print OUT_CPP $tab x2, "cout << \"[Warning @\" << sc_time_stamp()\n";
                        print OUT_CPP $tab x2, " << \"] Read/Write access conflict: \"\n";
                        print OUT_CPP $tab x2, " << name() << \"'s address = \" << $port_nm_wa.read() << endl;\n";
                        print OUT_CPP $tab, "}\n";
                        print OUT_CPP $tab, "$port_nm_cs.write(!$port_nm_we.read() | $port_nm_re.read());\n";
                    }
                    elsif (@$elm[M_WE] == 2 && @$elm[M_RE] == 2) {
                        print OUT_CPP $tab, "if ($port_nm_we.read() == 0 && $port_nm_re.read() == 0) {\n";
                        print OUT_CPP $tab x2, "cout << \"[Warning @\" << sc_time_stamp()\n";
                        print OUT_CPP $tab x2, " << \"] Read/Write access conflict: \"\n";
                        print OUT_CPP $tab x2, " << name() << \"'s address = \" << $port_nm_wa.read() << endl;\n";
                        print OUT_CPP $tab, "}\n";
                        print OUT_CPP $tab, "$port_nm_cs.write(!(!$port_nm_we.read() | !$port_nm_re.read()));\n";
                    }
                    print OUT_CPP "}\n\n";
                }
                close(OUT_CPP);
            }
        }
    }
}

##
## print port monitor logic
##   $ptn   : file pointer
##   $name  : signal name
##
sub print_port_monitor {
    my ($ptn, $name, $type, $array, $wid, $indent) = @_;
    my @dim = ();

    $wid = ($wid eq "b") ? $wid : &get_macro_value($wid, "", 0) ;
    $type = ($wid eq "b") ? "bool" : &get_sctype(($type =~ /^u/) ? 0 : 1, $wid);

    if ($array eq "") {
        print OUT_TB_CPP $indent, $type . " v_${name} = ${name}.read();\n";
        print OUT_TB_CPP $indent, "fprintf($ptn, \"";
        if ($wid eq "b" || $wid <= 32) {
            print OUT_TB_CPP " %08x\" , v_${name}";
            print OUT_TB_CPP ".to_uint()" if ($wid ne "b");
            print OUT_TB_CPP ");\n";
        }
        else {
            for (my $i=0; $i<int($wid/32 + 0.5); $i++) {
                print OUT_TB_CPP " %08x";
            }
            print OUT_TB_CPP "\",\n";
            if ($wid%32 != 0) {
                print OUT_TB_CPP $indent, $tab, "v_${name}.range(" . ($wid - 1) . "," . 32*int($wid/32) . ").to_uint(),\n";
            }
            for (my $i=int($wid/32); $i>0 ; $i--) {
                print OUT_TB_CPP $indent, $tab, "v_${name}.range(" . (32*$i -1) . "," . (32*($i-1)) . ").to_uint()";
                print OUT_TB_CPP ($i==1) ? "\n" : ",\n";
            }
            print OUT_TB_CPP $indent, ");\n";
        }
    }
    else {
        while ($array =~ /\w+/g) {
            &get_array_info(\@dim, $&);
        }

        print OUT_TB_CPP $indent, $type . " v_" . $name . $array . ";\n";

        for (my $i = 0; $i < @dim; $i++) {
            print OUT_TB_CPP $indent, $tab x$i, "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
            $name = $name . "[i$i]";
        }
        print OUT_TB_CPP $indent, $tab x@dim, "v_" . $name . " = " . $name . ".read();\n";
        print OUT_TB_CPP $indent, $tab x@dim, "fprintf($ptn, \"";
        if ($wid eq "b" || $wid <= 32) {
            print OUT_TB_CPP " %08x\" , v_${name}";
            print OUT_TB_CPP ".to_uint()" if ($wid ne "b");
            print OUT_TB_CPP ");\n";
        }
        else {
            for (my $i=0; $i<int($wid/32 + 0.5); $i++) {
                print OUT_TB_CPP " %08x";
            }
            print OUT_TB_CPP "\",\n";
            if ($wid%32 != 0) {
                print OUT_TB_CPP $indent, $tab x(@dim+1), "v_${name}.range(" . ($wid - 1) . "," . 32*int($wid/32) . ").to_uint(),\n";
            }
            for (my $i=int($wid/32); $i>0 ; $i--) {
                print OUT_TB_CPP $indent, $tab x(@dim+1), "v_${name}.range(" . (32*$i -1) . "," . (32*($i-1)) . ").to_uint()";
                print OUT_TB_CPP ($i==1) ? "\n" : ",\n";
            }
            print OUT_TB_CPP $indent, $tab x@dim, ");\n";
        }
        for (my $i = @dim - 1; $i >= 0; $i--) {
            print OUT_TB_CPP $indent, $tab x$i, "}\n";
        }
    }
}

##
## print random input data
##
sub print_data_random {
    my ($name, $type, $array, $wid, $indent) = @_;
    my @dim = ();

    #$wid = &get_macro_value($wid, "", 0);
    $wid = ($wid eq "b") ? $wid : &get_macro_value($wid, "", 0) ;
    $type = ($wid eq "b") ? "bool" : &get_sctype(($type =~ /^u/) ? 0 : 1, $wid);

    if ($array eq "") {
        print OUT_RAND $indent, $type . " v_${name};\n";
        if ($wid eq "b") {
            print OUT_RAND $indent, "v_${name} = rand()%2;\n";
        }
        elsif ($wid < 16) {
            print OUT_RAND $indent, "v_${name} = rand()%" . (1<<$wid) . ";\n";
        }
        else {
            if ($wid%16 != 0) {
                print OUT_RAND $indent, "v_${name}.range("  . ($wid-1) . "," . (16*int($wid/16)) . ") = rand()%" . (1<<($wid%16)) . ";\n";
            }
            for (my $i=int($wid/16); $i>0 ; $i--) {
                print OUT_RAND $indent, "v_${name}.range(" . (16*$i-1) . "," . (16*($i-1)) . ") = rand()%65536;\n";
            }
        }
        print OUT_RAND $indent, "${name}.write(v_${name});\n";
    }
    else {
        while ($array =~ /\w+/g) {
            &get_array_info(\@dim, $&);
        }

        print OUT_RAND $indent, $type . " v_" . $name . $array . ";\n";

        for (my $i = 0; $i < @dim; $i++) {
            print OUT_RAND $indent, $tab x$i, "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
            $name = $name . "[i$i]";
        }

        if ($wid eq "b") {
            print OUT_RAND $indent, $tab x@dim, "v_${name} = rand()%2;\n";
        }
        elsif ($wid < 16) {
            print OUT_RAND $indent, $tab x@dim, "v_${name} = rand()%" . (1<<$wid) . ";\n";
        }
        else {
            if ($wid%16 != 0) {
                print OUT_RAND $indent, $tab x@dim, "v_${name}.range("  . ($wid-1) . "," . (16*int($wid/16)) . ") = rand()%" . (1<<($wid%16)) . ";\n";
            }
            for (my $i=int($wid/16); $i>0 ; $i--) {
                print OUT_RAND $indent, $tab x@dim, "v_${name}.range(" . (16*$i-1) . "," . (16*($i-1)) . ") = rand()%65536;\n";
            }
        }

        print OUT_RAND $indent, $tab x@dim, "${name}.write(v_${name});\n";
        for (my $i = @dim - 1; $i >= 0; $i--) {
            print OUT_RAND $indent, $tab x$i, "}\n";
        }

    }
}

##
## print preprocessor
##   OUT  : file pointer
##
sub print_preprocessor {
    local(*OUT) = $_[0];
    if ($tb_mode == 1 && @prepro_list_tb > 0) {
        foreach $elm (@prepro_list_tb) {
            print OUT "#include @$elm[G_NAME]";
            print OUT " // @$elm[G_COM]" if (@$elm[G_COM] ne "");
            print OUT "\n";
        }
        print OUT "\n";
    }

    foreach $elm (@prepro_list) {
        if (@$elm[G_FLAG] eq "#include") {
            print OUT "#include @$elm[G_NAME]";
        }
        else {
            print OUT "#define @$elm[G_NAME]";
        }
        print OUT " // @$elm[G_COM]" if (@$elm[G_COM] ne "");
        print OUT "\n";
    }
}

##
## print kept ssgen define
##   $out_mode : print mode (= 0:module header, 1:moddef, 2: testbench header)
##
sub print_kept_ssgen_define {
    local(*OUT) = $_[0];
    my $in_file = $_[1];
    my $out_mod = $_[2];
    my $define_list = ($top_mode != 0) ? \@define_in_top_list : \@define_in_list;
    foreach $def (@$define_list) {
        next if ((@$def[G_FLAG] & FLG_KEEP_STR) == 0);
        next if (@$def[G_FILE] ne $in_file && $out_mod == 0);
        my $val = ($out_mod != 1 && @$def[G_VALUE] ne "") ? &get_macro_value(@$def[G_NAME], "", 0) : @$def[G_VALUE];
        print OUT (($out_mod != 1) ? "#define" : "`define") . " @$def[G_NAME] $val\n";
    }
}

##
## print array binding
##   $inst    : instance name
##   $name    : signal name
##   $array   : array part
##   $mode_rtl: generate binding for Co-Sim (=2:only RTL, 1:N, 0:Y)
##
sub print_bind_array {
    my ($inst, $name, $array, $mode_rtl) = @_;
    my @dim = ();
    my $indent = $tab;
    my $a = $style_alloc eq "static" ? "." : "->";

    print OUT_MAIN "#ifndef $rtl_macro\n" if ($mode_rtl == 0);
    if ($mode_rtl != 2) {
        while ($array =~ /\w+/g) {
            push(@dim, $&);
        }
        for ($i = 0; $i < @dim; $i++) {
            print OUT_MAIN $indent, $tab x$i, "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
        }
        print OUT_MAIN $indent, $tab x $i, "$inst$a$name";
        for ($i = 0; $i < @dim; $i++) {
            print OUT_MAIN "[i$i]";
        }
        print OUT_MAIN "($name";
        for ($i = 0; $i < @dim; $i++) {
            print OUT_MAIN "[i$i]";
        }
        print OUT_MAIN ");\n";

        for ($i = @dim - 1; $i >= 0; $i--) {
            print OUT_MAIN $indent, $tab x$i, "}\n";
        }
    }
    if ($mode_rtl != 1) {
        @dim = ();
        while ($array =~ /\w+/g) {
            &get_array_info(\@dim, $&);
        }
        my $max = 1;
        foreach $i (@dim) {
            $max *= $i;
        }
        @mod = ();
        $val = $max;
        foreach $i (@dim) {
            $val /= $i;
            push(@mod, $val);
        }
        print OUT_MAIN "#else\n" if ($mode_rtl == 0);
        for ($i = 0; $i < $max; $i++) {
            print OUT_MAIN $indent, "$inst$a$name";
            for ($j = 0; $j < @mod; $j++) {
                print OUT_MAIN "_", int($i / $mod[$j]) % $dim[$j];
            }
            print OUT_MAIN "($name";
            for ($j = 0; $j < @mod; $j++) {
                print OUT_MAIN "[", int($i / $mod[$j]) % $dim[$j], "]";
            }
            print OUT_MAIN ");\n";
        }
        print OUT_MAIN "#endif\n" if ($mode_rtl == 0);
    }
}

##
## print array binding for sim_eq
##   $inst      : instance name
##   $port      : port name
##   $signal    : signal name
##   $array     : array part
##   $mode_rtl  : generate binding for rtl (0: N, 1: Y)
##
sub print_bind_array_sim_eq {
    my ($inst, $port, $signal, $array, $mode_rtl) = @_;
    my @dim = ();
    my $indent = $tab;
    my $a = $style_alloc eq "static" ? "." : "->";
    if ($mode_rtl == 0) {
        while ($array =~ /\w+/g) {
            push(@dim, $&);
        }
        for ($i = 0; $i < @dim; $i++) {
            print OUT_MAIN $indent, $tab x$i, "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
        }
        print OUT_MAIN $indent, $tab x $i, "$inst$a$port";
        for ($i = 0; $i < @dim; $i++) {
            print OUT_MAIN "[i$i]";
        }
        print OUT_MAIN "($signal";
        for ($i = 0; $i < @dim; $i++) {
            print OUT_MAIN "[i$i]";
        }
        print OUT_MAIN ");\n";

        for ($i = @dim - 1; $i >= 0; $i--) {
            print OUT_MAIN $indent, $tab x$i, "}\n";
        }
    }
    else {
        while ($array =~ /\w+/g) {
            &get_array_info(\@dim, $&);
        }
        my $max = 1;
        foreach $i (@dim) {
            $max *= $i;
        }
        @mod = ();
        $val = $max;
        foreach $i (@dim) {
            $val /= $i;
            push(@mod, $val);
        }
        for ($i = 0; $i < $max; $i++) {
            print OUT_MAIN $indent, "$inst$a$port";
            for ($j = 0; $j < @mod; $j++) {
                print OUT_MAIN "_", int($i / $mod[$j]) % $dim[$j];
            }
            print OUT_MAIN "($signal";
            for ($j = 0; $j < @mod; $j++) {
                print OUT_MAIN "[", int($i / $mod[$j]) % $dim[$j], "]";
            }
            print OUT_MAIN ");\n";
        }
    }
}

##
## print module template
##
sub print_module_tempalte {
    if ($use_template == 1) {
        $init = 0;
        print OUT_H "\ntemplate < ";
        foreach $temp (@template_list) {
            print OUT_H ", " if ($init == 1);
            print OUT_H "@$temp[G_TYPE] @$temp[G_NAME]=@$temp[G_SUBS]";
            $init = 1 if ($init == 0);
        }
        print OUT_H " >";
    }
}

##
## print module defintion
##   OUT  : file pointer
##   name : module name
##
sub print_module_def {
    local(*OUT) = $_[0];
    my $name = $_[1];
    if ($style_module eq "sc") {
        print OUT "\nSC_MODULE($name) {\n";
    }
    else {
        print OUT "\nclass $name : public sc_module {\n";
        print OUT "public:\n";
    }
}

##
## print port
##
sub print_port {
    foreach $elm (@clk_list) {
        if (@$elm[T_NAME] ne "") {
            print OUT_H $tab, "sc_in < bool > @$elm[T_NAME];", &comment(@$elm[T_COM], 1);
        }
    }

    # reset
    foreach $elm (@rst_list) {
        if (@$elm[T_TYPE] eq "soft_reset") {
            print OUT_H $tab, "sc_signal < bool > @$elm[T_NAME];", &comment(@$elm[T_COM], 1);
        }
        else {
            if (@$elm[T_NAME] ne "") {
                print OUT_H $tab, "sc_in < bool > @$elm[T_NAME];", &comment(@$elm[T_COM], 1);
            }
        }
    }

    # in
    foreach $elm (@in_list) {
        if (@$elm[T_NAME] ne "") {
            print OUT_H $tab, &get_type(@$elm[T_TYPE], @$elm[T_WID]);
            print OUT_H " @$elm[T_NAME]@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
        }
    }

    # out
    if ( 0 ) { ## Certitude K-2015.09-SP1 issue
        foreach $elm (@out_list) {
            if (@$elm[T_NAME] ne "") {
                my $cer_off = &name_exist(\@cer_off_list, @$elm[T_NAME]);
                print OUT_H "#pragma certitude_off\n" if ($cer_off);
                print OUT_H $tab, &get_type(@$elm[T_TYPE], @$elm[T_WID]);
                print OUT_H " @$elm[T_NAME]@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
                print OUT_H "#pragma certitude_on\n" if ($cer_off);
            }
        }
    }
    my $cer_area = 0;
    foreach $elm (@out_list) {
        if (@$elm[T_NAME] ne "") {
            my $cer_off = &name_exist(\@cer_off_list, @$elm[T_NAME]);
            print OUT_H "#pragma certitude_on\n"  if (!$cer_off &  $cer_area);
            print OUT_H "#pragma certitude_off\n" if ( $cer_off & !$cer_area);
            print OUT_H $tab, &get_type(@$elm[T_TYPE], @$elm[T_WID]);
            print OUT_H " @$elm[T_NAME]@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
            $cer_area = $cer_off;
        }
    }
    print OUT_H "#pragma certitude_on\n" if ($cer_area);

    if ($top_mode == 0) {
        if (@in_list_slecbb > 0 || @out_list_slecbb > 0) {
            print OUT_H "\n#ifdef $slecbb_macro\n";

            # in for SLECBB
            foreach $elm (@in_list_slecbb) {
                print OUT_H $tab, &get_type(@$elm[T_TYPE], @$elm[T_WID]);
                print OUT_H " @$elm[T_NAME]@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
            }

            # out for SLECBB
            foreach $elm (@out_list_slecbb) {
                print OUT_H $tab, &get_type(@$elm[T_TYPE], @$elm[T_WID]);
                print OUT_H " @$elm[T_NAME]@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
            }

            print OUT_H "#endif\n";
        }
    }
    else {
        # insert_port
        foreach $elm (@in_list_insert) {
            if (@$elm[T_NAME] ne "") {
                print OUT_H $tab, &get_type(@$elm[T_TYPE], @$elm[T_WID]);
                print OUT_H " @$elm[T_NAME]@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
            }
        }
        foreach $elm (@out_list_insert) {
            if (@$elm[T_NAME] ne "") {
                print OUT_H $tab, &get_type(@$elm[T_TYPE], @$elm[T_WID]);
                print OUT_H " @$elm[T_NAME]@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
            }
        }
    }
}

##
## print declaration data of one list
##   OUT       : file pointer
##   $ptr_list : pointer of list
##
sub print_decl_data_one {
    local(*OUT) = $_[0];
    my $ptr_list = $_[1];

    foreach $elm (@$ptr_list) {
        next if (@$elm[T_NAME] eq "");
        next if (@$elm[T_INST] ne $mod_inst &&
                ((@$elm[T_FLG] & FLG_SYNC) || (@$elm[T_FLG] & FLG_SYNC_CHK)));
        print OUT "#ifdef @$elm[T_DBG]\n" if (&is_ifdeffix($elm));
        print OUT $tab;
        if (@$elm[T_FLG] & FLG_CONST) {
            print OUT "static const ";
        }
        if(@$elm[T_CTSCG] == 1) {
            print OUT "ctos_clock_gate_signal";
        }
        else {
            print OUT &get_type(@$elm[T_TYPE], @$elm[T_WID]);
        }
        print OUT " @$elm[T_NAME]@$elm[T_ARRAY];", &comment(@$elm[T_COM], 1);
        if (@$elm[T_FLG] & FLG_VAR2REG) {
            my $type = @$elm[T_TYPE];
            print OUT $tab;
            if ($type =~ /var$/) {
                $type =~ s/var/reg/g;
                print OUT &get_type($type, @$elm[T_WID]);
            }
            else {
                print OUT "sc_signal < ", &get_type($type, @$elm[T_WID]), " >" ;
            }
            print OUT " r_@$elm[T_NAME]@$elm[T_ARRAY];\n";
        }
        print OUT "#endif\n" if (&is_ifdeffix($elm));
    }
}

##
## print declaration data
##
sub print_decl_data {
    # common
    if (@reg_list > 0 || @var_list > 0 || @ctype_list > 0) {
        print OUT_H "\n";
        print_decl_data_one(*OUT_H, \@reg_list);
        print_decl_data_one(*OUT_H, \@var_list);
        print_decl_data_one(*OUT_H, \@ctype_list);
    }
    # sim
    foreach $m (@data_list_m) {
        $macro = shift(@$m);
        if ($macro ne $cov_macro || (@thread_list != 0 && $top_mode == 0)) {
            print OUT_H "\n#ifdef $macro\n";
            print_decl_data_one(*OUT_H, \@$m);
            print OUT_H "#endif\n";
        }
        unshift(@$m, $macro);
    }
}

##
## print ev type definition
##
sub print_ev_def {
    if (@ev_list > 0) {
        print OUT_H "\n";
        foreach $elm (@ev_list) {
            print OUT_H $tab, "EV_DEF(@$elm[T_NAME]@$elm[T_ARRAY], ";
            print OUT_H &get_sctype(@$elm[T_TYPE] eq "sev" ? 1 : 0, @$elm[T_WID]);
            print OUT_H ");", &comment(@$elm[T_COM], 1);
        }
    }
}

##
## print init data
##   OUT       : file pointer
##   $indent   : indent string
##   $thnm     : belonged thread name
##   $ptr_list : pointer of list
##
sub print_init_data {
    local(*OUT)  = $_[0];
    my $indent   = $_[1];
    my $thnm     = $_[2];
    my $ptr_list = $_[3];
    my $arg_num  = 0;
    my $tb_mode  = 0;
    my $arg_id   = 0;
    if (@_ > 4) {
        $arg_num = $_[4];
    }
    if (@_ > 5) {
        $tb_mode = $_[5];
    }

    $org_indent = $indent;
    $indent = $indent . $tab;

    foreach $elm (@$ptr_list) {
        next if ($thnm ne "" && $thnm ne @$elm[T_TH] && @_ < 5);
        next if (@$elm[T_INST] ne $mod_inst &&
                ((@$elm[T_FLG] & FLG_SYNC) || (@$elm[T_FLG] & FLG_SYNC_CHK)));
        if (@$elm[T_NAME] eq "" || (@$elm[T_FLG] & FLG_CONST) || lc @$elm[T_INIT] eq "n") {
            next;
        }
        my $sig   = @$elm[T_TYPE] =~ /(in|out|reg)$/ ? 1 : 0;
        my $ev    = @$elm[T_TYPE] =~ /ev$/ ? 1 : 0;
        my $name  = @$elm[T_NAME];
        my $array = @$elm[T_ARRAY];
        my $init  = @$elm[T_INIT];
        my $dt    = @$elm[T_FLG] & FLG_STR_TYPE;
        $name     =~ s/://g;
        if ($dt != 0) { # for struct
            $init = @$elm[T_WID]."()";
        } elsif ($arg_num == 1) {   # one init value for all struct members
            $init = "v";
        } elsif ($arg_num > 1) {    # init values corresponding to struct members
            $init = "arg$arg_id";
            $arg_id = $arg_id + 1;
        } elsif ($arg_num == -1) {  # init value get from existed struct data
            $init = "v.$name";
        }
        my @dim = ();
        my @num = ();

        if ($tb_mode == 1 && $dt != 0 ) {
            print OUT "#ifndef _MODE_RTL\n";
        } 
        if ($array eq "") {
            if ($sig == 1) {
                print OUT $indent, "$name.write($init);\n";
            }
            elsif ($ev == 1) {
                print OUT $indent, "EV_INIT($name, $init);\n";
            }
            else {
                if ($dt == 0) { # for struct
                    print OUT $indent, "$name = $init;\n";
                } else {
                    print OUT $indent, "$name.reset();\n";
                }
                if (@$elm[T_FLG] & FLG_VAR2REG) {
                    print OUT $indent, "r_$name.write($init);\n";
                }
            }
        }
        else {
            my $str_tmp = "";   # array index to init value get from existed struct data
            while ($init =~ /[^\s\{\}\,]+/g) {
                push(@num, $&);
            }

            if (@num == 1) {
                while ($array =~ /\w+/g) {
                    push(@dim, $&);
                }
                for ($i = 0; $i < @dim; $i++) {
                    print OUT $indent, $tab x$i, "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
                }
                print OUT $indent, $tab x $i;
                print OUT "EV_INIT(" if ($ev == 1);
                print OUT "$name";
                for ($i = 0; $i < @dim; $i++) {
                    $str_tmp = "$str_tmp\[i$i\]";
                    print OUT "[i$i]";
                }
                my $init_val_elm = "$num[0]";
                if ($arg_num == -1 || $arg_num > 1 ) {
                    $init_val_elm = "$init$str_tmp";
                }
                if ($sig == 1) {
                    print OUT ".write($num[0]);\n";
                }
                elsif ($ev == 1) {
                    print OUT ", $num[0]);\n";
                }
                else {
                    print OUT " = $init_val_elm;\n";
                }
                if (@$elm[T_FLG] & FLG_VAR2REG) {
                    print OUT $indent, $tab x $i, "r_$name";
                    for ($i = 0; $i < @dim; $i++) {
                        print OUT "[i$i]";
                    }
                    print OUT ".write($num[0]);\n";
                }
                for ($i = @dim - 1; $i >= 0; $i--) {
                    print OUT $indent, $tab x$i, "}\n";
                }
            }
            elsif (@num > 1) {
                while ($array =~ /\w+/g) {
                    &get_array_info(\@dim, $&);
                }
                $max = 1;
                foreach $i (@dim) {
                    $max *= $i;
                }
                @mod = ();
                $val = $max;
                foreach $i (@dim) {
                    $val /= $i;
                    push(@mod, $val);
                }
                for ($i = 0; $i < $max; $i++) {
                    print OUT $indent;
                    print OUT "EV_INIT(" if ($ev == 1);
                    print OUT "$name";
                    for ($j = 0; $j < @mod; $j++) {
                        $str_tmp = "$str_tmp\[", int($i / $mod[$j]) % $dim[$j], "\]";
                        print OUT "[", int($i / $mod[$j]) % $dim[$j], "]";
                    }
                    $pos = ($i < @num) ? $i : $#num;
                    my $init_val_elm = "$num[$pos]";
                    if ($arg_num == -1 || $arg_num > 1 ) {
                        $init_val_elm = "$init$str_tmp";
                    }
                    if ($sig == 1) {
                        print OUT ".write($num[$pos]);\n";
                    }
                    elsif ($ev == 1) {
                        print OUT ", $num[$pos]);\n";
                    }
                    else {
                        print OUT " = $init_val_elm;\n";
                    }
                    if (@$elm[T_FLG] & FLG_VAR2REG) {
                        print OUT $indent, "r_$name";
                        for ($j = 0; $j < @mod; $j++) {
                            print OUT "[", int($i / $mod[$j]) % $dim[$j], "]";
                        }
                        $pos = ($i < @num) ? $i : $#num;
                        print OUT ".write($num[$pos]);\n";
                    }
                }
            }
        }
        if ($tb_mode == 1 && $dt != 0 ) {
            print OUT "#else\n";
            my @rtl_port;
            &get_rtl_port(\@rtl_port, $elm);
            &print_init_data(*OUT, $org_indent, "", \@rtl_port);
            print OUT "#endif\n";
        }
    }
}

##
## print const init data
##   OUT       : file pointer
##   $ptr_list : pointer of list
##   $tb_data  : testbench data flag (= 1:Y, 0:N)
##
sub print_const_init_data {
    local(*OUT) = $_[0];
    my $ptr_list = $_[1];
    my $tb_data  = $_[2];
    $tb_data = 0 unless defined($tb_data);

    foreach $elm (@$ptr_list) {
        if ((@$elm[T_FLG] & FLG_CONST) && lc @$elm[T_INIT] ne "n") {
            next if (&is_struct(@$elm[T_WID]) && $elm[T_INIT] eq "0"); 
            my $str = "const ";
            $str    = $str . &get_type(@$elm[T_TYPE], @$elm[T_WID]);
            $str    = $str . (($tb_data) ? " tb_" : " ");
            $str    = $str . $module_name . "::@$elm[T_NAME]@$elm[T_ARRAY] = ";
            if (@$elm[T_ARRAY] ne "" && @$elm[T_INIT] !~ /^{.*}$/) {
                my @dim = ();
                my @num = ();
                my $exp = "";
                my $max = 1;
                while (@$elm[T_INIT] =~ /[^\s\{\}\,]+/g) {
                    push(@num, $&);
                }
                while (@$elm[T_ARRAY] =~ /\w+/g) {
                    &get_array_info(\@dim, $&);
                }
                foreach $i (@dim) {
                    $max *= $i;
                }
                for ($i = 0; $i < $max; $i++) {
                    $mod = 1;
                    for ($j = $#dim; $j >= 0; $j--) {
                        $mod *= $dim[$j];
                        $exp .= "{" if (($i % $mod) == 0);
                    }
                    $pos = ($i < @num) ? $i : $#num;
                    $exp .= $num[$pos]; 
                    $mod = 1;
                    for ($j = $#dim; $j >= 0; $j--) {
                        $mod *= $dim[$j];
                        $exp .= "}" if (($i % $mod) == ($mod - 1));
                    }
                    $exp .= ", " if ($i != $max-1);
                }
                print OUT "$str$exp;\n";
            }
            elsif (@$elm[T_ARRAY] ne "" || &is_struct(@$elm[T_WID]) == 0 || @$elm[T_INIT] !~ /\{/) {
                print OUT "$str";
                print OUT "@$elm[T_INIT];\n";
            }
        }
    }
}

##
## print const assignment
##   OUT : file pointer
##
sub print_const {
    local(*OUT) = $_[0];

    # common
    @list = (@var_list, @ctype_list);
    if (&exist_const(\@list) == 1) {
        print OUT "\n";
        &print_const_init_data(*OUT, \@list);
    }

    # sim
    foreach $m (@data_list_m) {
        $macro = shift(@$m);
        if (&exist_const(\@$m) == 1) {
            print OUT "\n";
            print OUT "#ifdef $macro\n";
            &print_const_init_data(*OUT, \@$m);
            print OUT "#endif\n";
        }
        unshift(@$m, $macro);
    }
}

##
## print code for connection with signal of SVA checker
##
sub print_hdl_connection {
    my $name     = $_[0];
    my $array    = $_[1];
    my $width    = $_[2];
    my $type     = $_[3];

    return if (&is_struct($width));
    $width = ($width eq "b") ? $width : &get_macro_value($width, "", 0) ;
    #$width = &get_macro_value($width, "", 0);
    local(*OUT)     = $_[4];
    local(*OUT_SVH) = $_[5];
    my $out_mode    = $_[6];
    my $hdl_eda  = "";
    if (@_ > 6) {
        $hdl_eda = $_[7];
    }
    my $indent = $out_mode == 2 ? $tab : "";

    if ($width eq "b" || $width == 1) {
        $width = "";
    }
    elsif ($type eq "uchar" || $type eq "char") {
        $width = "[7:0]";
    }
    elsif ($type eq "ushort" || $type eq "short") {
        $width = "[15:0]";
    }
    elsif ($type eq "uint" || $type eq "int") {
        $width = "[31:0]";
    }
    elsif (&is_struct($width) == 1) {
        return;
    }
    else {
        $width = "[".($width-1).":0]";
    }
    $name = "r_".$name if($type eq "uev" || $type eq "sev");
    $name = $name."_dbg" if ($type eq "uvar"   || $type eq "svar"  || $type eq "uchar" || $type eq "char" ||
                             $type eq "ushort" || $type eq "short" || $type eq "uint"  || $type eq "int" );

    if ($array ne "") {
        my @dim = ();
        while ($array =~ /\w+/g) {
            &get_array_info(\@dim, $&);
        }
        my $tmp_name = "";
        for ($i = 0; $i < $dim[0]; $i++) {
            if (@dim == 1) {
                if ($hdl_eda eq "vcs") {
                    print OUT $indent, $tab, "hdl_connect_v(${name}\[$i], \"${hdl_module}0.$hdl_sig_prefix${name}_${i}\", HDL_OUTPUT, HDL_vcs);\n";
                    print OUT_SVH $tab, "reg $width ${name}_${i};\n" if ($hdl_ies_on == 0);
                }
                else {
                    print OUT $indent, $tab, "${name}\[$i].control_foreign_signal(\"$hdl_module.$hdl_sig_prefix${name}_${i}\");\n";
                    print OUT_SVH $tab, "reg $width ${name}_${i};\n";
                }
            }
            else {
                for ($j = 0; $j < $dim[1]; $j++) {
                    if ($hdl_eda eq "vcs") {
                        print OUT $indent, $tab, "hdl_connect_v(${name}\[$i][$j], \"${hdl_module}0.$hdl_sig_prefix${name}_${i}_${j}\", HDL_OUTPUT, HDL_vcs);\n";
                        print OUT_SVH $tab, "reg $width ${name}_${i}_${j};\n" if ($hdl_ies_on == 0);
                    }
                    else {
                        print OUT $indent, $tab, "${name}\[$i][$j].control_foreign_signal(\"$hdl_module.$hdl_sig_prefix${name}_${i}_${j}\");\n";
                        print OUT_SVH $tab, "reg $width ${name}_${i}_${j};\n";
                    }
                }
            }
        }
    }
    else {
        if ($hdl_eda eq "vcs") {
            print OUT $indent, $tab, "hdl_connect_v($name, \"${hdl_module}0.$hdl_sig_prefix$name\", HDL_OUTPUT, HDL_vcs);\n";
            print OUT_SVH $tab, "reg $width ${name};\n" if ($hdl_ies_on == 0);
        }
        else {
            print OUT $indent, $tab, "$name.control_foreign_signal(\"$hdl_module.$hdl_sig_prefix$name\");\n";
            print OUT_SVH $tab, "reg $width ${name};\n";
        }
    }
}

##
## print range data
##   OUT       : file pointer
##   $indent   : indent string
##   $thnm     : belonged thread name
##   $ptr_list : pointer of list
##
sub print_range_data {
    local(*OUT)  = $_[0];
    my $indent_org= $_[1];
    my $thnm     = $_[2];
    my $ptr_list = $_[3];
    my $prefix_n = "";
    $prefix_n = $_[4] if (@_ > 4);

    my $indent = $indent_org . $tab;

    foreach $elm (@$ptr_list) {
        my $array = @$elm[T_ARRAY];
        my $post = "";
        if (@$elm[T_TYPE] =~/(in|out|reg)$/) {
            $post = ".read()";
        }
        elsif (@$elm[T_TYPE] =~/ev$/) {
            $post = ".get()";
        }

        #find struct
        my $range_check_struct = 0;
        if (@$elm[T_WID] =~/^[a-zA-Z_]/) {
            my $str = &get_struct(@$elm[T_WID]);
            if ($str != 0) {
                my $str_mem_list = @$str[STR_VAR];
                my $name = "@$elm[T_NAME]";
                $name = "$prefix_n.$name" if ($prefix_n ne "");
                $range_check_struct = 1;
                if ($array ne "") {
                    my @dim = ();
            
                    while ($array =~ /\w+/g) {
                        push(@dim, $&);
                    }
                    for (my $i = 0; $i < @dim; $i++) {
                        print OUT $indent, $tab x$i, "for (int j$i = 0; j$i < $dim[$i]; j$i++) {\n";
                        $name = $name . "[j$i]";
                    }
                    &print_range_data (*OUT, $indent_org.$tab x@dim, "", $str_mem_list, "$name$post."); 
                    for ($i = @dim - 1; $i >= 0; $i--) {
                        print OUT $indent, $tab x$i, "}\n";
                    }
                } else {
                    &print_range_data (*OUT, $indent_org, "", $str_mem_list, "$name$post."); 
                }
            }
        }
        next if ($range_check_struct || ($thnm ne "" && $thnm ne @$elm[T_TH])
              || !(@$elm[T_FLG] & FLG_RNGCHK)
              || (@$elm[T_MIN] eq "" && @$elm[T_MAX] eq ""));

        $name = $prefix_n.@$elm[T_NAME];
        if ($array ne "") {
            my @dim = ();
            my @min = ();
            my @max = ();
            while (@$elm[T_MIN] =~ /[^\s]+/g) {
                push(@min, $&);
            }
            while (@$elm[T_MAX] =~ /[^\s]+/g) {
                push(@max, $&);
            }

            if (@min == 1 || @max == 1) {
                while ($array =~ /\w+/g) {
                    push(@dim, $&);
                }
                for ($i = 0; $i < @dim; $i++) {
                    print OUT $indent, $tab x$i, "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
                    $name = $name . "[i$i]";
                }
                if (@max == 1) {
                    print OUT $indent, $tab x @dim, "$assert_macro($name$post <= $max[0]);\n";
                }
                if (@min == 1) {
                    print OUT $indent, $tab x @dim, "$assert_macro($name$post >= $min[0]);\n";
                }
                for ($i = @dim - 1; $i >= 0; $i--) {
                    print OUT $indent, $tab x$i, "}\n";
                }
            }
            if (@min > 1 || @max > 1) {
                while ($array =~ /\w+/g) {
                    &get_array_info(\@dim, $&);
                }
                $cnt = 1;
                foreach $i (@dim) {
                    $cnt *= $i;
                }
                @mod = ();
                $val = $cnt;
                foreach $i (@dim) {
                    $val /= $i;
                    push(@mod, $val);
                }
                for ($i = 0; $i < $cnt; $i++) {
                    if (@max > 1) {
                       $pos = ($i < @max) ? $i : $#max;
                       print OUT $indent, "$assert_macro($name";
                       for ($j = 0; $j < @dim; $j++) {
                           print OUT "[", int($i / $mod[$j]) % $dim[$j], "]";
                       }
                       print OUT "$post <= $max[$pos]);\n";
                    }
                    if (@min > 1) {
                       $pos = ($i < @min) ? $i : $#min;
                       print OUT $indent, "$assert_macro($name";
                       for ($j = 0; $j < @dim; $j++) {
                           print OUT "[", int($i / $mod[$j]) % $dim[$j], "]";
                       }
                       print OUT "$post >= $min[$pos]);\n";
                    }
                }
            }
        }
        else {
            if (@$elm[T_MAX] ne "") {
                print OUT $indent, "$assert_macro($name$post <= @$elm[T_MAX]);\n";
            }
            if (@$elm[T_MIN] ne "") {
                print OUT $indent, "$assert_macro($name$post >= @$elm[T_MIN]);\n";
            }
        }
    }
}

##
## print coverage data
##   OUT       : file pointer
##   $indent   : indent string
##   $thnm     : belonged thread name
##   $ptr_list : pointer of list
##
sub print_cov_data {
    local(*OUT)  = $_[0];
    my $indent_org = $_[1];
    my $thnm     = $_[2];
    my $ptr_list = $_[3];
    my $prefix_n = "";
    $prefix_n = $_[4] if (@_ > 4);

    my $indent = $indent_org . $tab;

    foreach $elm (@$ptr_list) {
        my $array = @$elm[T_ARRAY];
        my $post = "";
        if (@$elm[T_TYPE] =~/(in|out|reg)$/) {
            $post = ".read()";
        }
        elsif (@$elm[T_TYPE] =~/ev$/) {
            $post = ".get()";
        }

        #find struct
        my $range_check_struct = 0;
        if (@$elm[T_WID] =~/^[a-zA-Z_]/) {
            my $str = &get_struct(@$elm[T_WID]);
            if ($str != 0) {
                my $str_mem_list = @$str[STR_VAR];
                my $name = "@$elm[T_NAME]";
                $name = "$prefix_n.$name" if ($prefix_n ne "");
                $range_check_struct = 1;
                if ($array ne "") {
                    my @dim = ();
            
                    while ($array =~ /\w+/g) {
                        &get_array_info(\@dim, $&);
                    }
                    my $cnt = 1;
                    foreach $i (@dim) {
                        $cnt *= $i;
                    }
                    my @mod = ();
                    my $val = $cnt;
                    foreach $i (@dim) {
                        $val /= $i;
                        push(@mod, $val);
                    }
                    for (my $i = 0; $i < $cnt; $i++) {
                        my $name_tmp = $name;
                        for (my $j = 0; $j < @mod; $j++) {
                            my $v = int($i / $mod[$j]) % $dim[$j];
                            $name_tmp =  $name_tmp."[$v]";
                        }
                        &print_cov_data (*OUT, $indent_org, "", $str_mem_list, "$name_tmp$post."); 
                    }
                } else {
                    &print_cov_data (*OUT, $indent_org, "", $str_mem_list, "$name$post."); 
                }
            }
        }
        next if ($range_check_struct || ($thnm ne "" && $thnm ne @$elm[T_TH]) || !(@$elm[T_FLG] & FLG_RNGCHK));

        $name = $prefix_n.@$elm[T_NAME];
        $array = @$elm[T_ARRAY];
        &get_minmax_value($elm, \$min_t, \$max_t);
        $min_t = @$elm[T_MIN] if (@$elm[T_MIN] ne "");
        $max_t = @$elm[T_MAX] if (@$elm[T_MAX] ne "");
        $wid_t = (@$elm[T_WID] eq "b") ? @$elm[T_WID] : &get_macro_value(@$elm[T_WID], "", 0);

        if ($array ne "") {
            my @dim = ();
            my @min = ();
            my @max = ();
            while ($min_t =~ /[^\s]+/g) {
                push(@min, $&);
            }
            while ($max_t =~ /[^\s]+/g) {
                push(@max, $&);
            }

            if ((@$elm[T_FLG] & FLG_RNGFOR) && (@min == 1) && (@max == 1)) {
                while ($array =~ /\w+/g) {
                    push(@dim, $&);
                }
                print OUT "\n";
                for ($i = 0; $i < @dim; $i++) {
                    print OUT $indent, $tab x$i, "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
                    $name = $name . "[i$i]";
                }
                print OUT $indent, $tab x @dim, "if ($name$post == $max_t)\n";
                print OUT $indent, $tab x (@dim + 1), "int dummy_range_max = 0;\n";
                if ($wid_t eq "b" || $wid_t == 1) {
                    print OUT $indent, $tab x @dim, "else int dummy_range_min = 0;\n";
                }
                else {
                    print OUT $indent, $tab x @dim, "else if ($name$post == $min_t)\n";
                    print OUT $indent, $tab x (@dim + 1), "int dummy_range_min = 0;\n";
                    print OUT $indent, $tab x @dim, "else int dummy_range_mid = 0;\n";
                }
                for ($i = @dim - 1; $i >= 0; $i--) {
                    print OUT $indent, $tab x$i, "}\n";
                }
            }
            else {
                while ($array =~ /\w+/g) {
                    &get_array_info(\@dim, $&);
                }
                $cnt = 1;
                foreach $i (@dim) {
                    $cnt *= $i;
                }
                @mod = ();
                $val = $cnt;
                foreach $i (@dim) {
                    $val /= $i;
                    push(@mod, $val);
                }
                for ($i = 0; $i < $cnt; $i++) {
                    print OUT "\n";
                    print OUT $indent, "if ($name";
                    for ($j = 0; $j < @mod; $j++) {
                        print OUT "[", int($i / $mod[$j]) % $dim[$j], "]";
                    }
                    print OUT "$post == ";
                    $pos = ($i < @max) ? $i : $#max;
                    print OUT "$max[$pos])\n";
                    print OUT $indent, $tab, "int dummy_range_max = 0;\n";
                    if ($wid_t eq "b" || $wid_t == 1) {
                        print OUT $indent, "else int dummy_range_min = 0;\n";
                    }
                    else {
                        print OUT $indent, "else if ($name";
                        for ($j = 0; $j < @mod; $j++) {
                            print OUT "[", int($i / $mod[$j]) % $dim[$j], "]";
                        }
                        print OUT "$post == ";
                        $pos = ($i < @min) ? $i : $#min;
                        print OUT "$min[$pos])\n";
                        print OUT $indent, $tab, "int dummy_range_min = 0;\n";
                        print OUT $indent, "else int dummy_range_mid = 0;\n";
                    }
                }
            }
        }
        else {
            print OUT "\n";
            print OUT $indent, "if ($name$post == $max_t)\n";
            print OUT $indent, $tab, "int dummy_range_max = 0;\n";
            if ($wid_t eq "b" || $wid_t == 1) {
                print OUT $indent, "else int dummy_range_min = 0;\n";
            }
            else {
                print OUT $indent, "else if ($name$post == $min_t)\n";
                print OUT $indent, $tab, "int dummy_range_min = 0;\n";
                print OUT $indent, "else int dummy_range_mid = 0;\n";
            }
        }
    }
}

##
## print sc_trace
##   OUT       : file pointer
##   $ptr_list : pointer of list
##
sub print_sc_trace {
    local(*OUT) = $_[0];
    my $ptr_list = $_[1];
    my $tb_mode = 0;
    $tb_mode = $_[2] if (@_ > 2);
    my $indent = $tab x3;

    foreach $elm (@$ptr_list) {
        next if (@$elm[T_NAME] eq "");
        next if (@$elm[T_FLG] & FLG_FIX);
        next if (@$elm[T_INST] ne $mod_inst &&
                ((@$elm[T_FLG] & FLG_SYNC) || (@$elm[T_FLG] & FLG_SYNC_CHK)));
        next if (@$elm[T_TYPE] =~ /^([su]var|u?int|u?short|u?char)$/ && !(@$elm[T_FLG] & FLG_VAR2REG));
        next if (@$elm[T_FLG] & FLG_NO_TRACE);
        if (&is_number(@$elm[T_WID]) && @$elm[T_WID] > 999) {
            message("I002", $outfile, 0,
                "@$elm[T_NAME] can not be registered for VCD dump because the width is more than 999");
            next;
        }
        $pre = "";
        if (@$elm[T_FLG] & FLG_VAR2REG || @$elm[T_TYPE] =~ /ev$/) {
            $pre  =  "r_";
        }
        $name = @$elm[T_NAME];
        my @dim = ();
        if ((@$elm[T_FLG] & FLG_STR_TYPE) && $tb_mode == 1) {
            print OUT "#ifndef _MODE_RTL\n";
        }
        if (@$elm[T_ARRAY] eq "") {
            print OUT $indent, "sc_trace(tf, $pre$name, nm + \".$pre$name\");\n";
        }
        else {
            while (@$elm[T_ARRAY] =~ /\w+/g) {
                push(@dim, $&);
            }

            for ($i = 0; $i < @dim; $i++) {
                print OUT $indent, $tab x$i, "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
            }
            print OUT $indent, $tab x @dim, "std::ostringstream indx;\n";
            $indx = "";
            for ($i = 0; $i < @dim; $i++) {
                $indx = $indx . "[i$i]";
                print OUT $indent, $tab x @dim, "indx << \"(\" << i$i << \")\";\n";
            }
            print OUT $indent, $tab x @dim, "sc_trace(tf, $pre$name$indx, nm + \".$pre$name\" + indx.str());\n";
            for ($i = @dim - 1; $i >= 0; $i--) {
                print OUT $indent, $tab x$i, "}\n";
            }
        }
        if ((@$elm[T_FLG] & FLG_STR_TYPE) && $tb_mode == 1) {
            print OUT "#else\n";
            my @rtl_port;
            &get_rtl_port(\@rtl_port, $elm);
            foreach my $e (@rtl_port) {
                $name = @$e[T_NAME];
                $name =~ s/://g;
                print OUT $indent, "sc_trace(tf, $pre$name, nm + \".$pre$name\");\n";
            }
            print OUT "#endif\n";
        }

    }
}

##
## print osci reset
##
sub print_osci_reset {
    if ($need_osci == 1) {
        print OUT_H "\n";
        print OUT_H "#ifdef $osci_macro\n";
        foreach $elm (@thread_list) {
            if (&need_osci_reset($elm)) {
                print OUT_H $tab, "sc_signal < bool > ssgen_merge_rst_@$elm[TH_NAME];\n";
            }
        }
        print OUT_H "#endif\n";
    }
}

##
## print constructor
##
sub print_constructor {
    $init = 0;
    print OUT_H "\n";
    if ($style_module eq "sc") {
        if ($template_wrapper) {
            print OUT_H $tab, "SC_CTOR(wrapper_$module_name)\n";
        }
        else {
            print OUT_H $tab, "SC_CTOR($module_name)\n";
        }
    }
    else {
        if ($template_wrapper) {
            print OUT_H $tab, "SC_HAS_PROCESS(wrapper_$module_name);\n";
            print OUT_H $tab, "wrapper_$module_name(sc_module_name nm)\n";
        }
        else {
            print OUT_H $tab, "SC_HAS_PROCESS($module_name);\n";
            print OUT_H $tab, "$module_name(sc_module_name nm)\n";
        }
        print OUT_H $tab x2, ": sc_module(nm)\n";
        $init = 1;
    }

    &print_constructor_initializer;

    print OUT_H $tab, "{";
    if ($top_mode == 1 || $template_wrapper == 1) {
        # sub module binding
        print OUT_H "\n";
        if ( 0 ) { ## Certitude K-2015.09-SP1 issue
        foreach $elm (@mod_list) {
            @mod = @$elm;
            print OUT_H "#ifdef $mod[MOD_DBG]\n" if ($mod[MOD_DBG] ne "");
            for ($cnt = MOD_BIND; $cnt < @mod; $cnt++) {
                my $sig_name = $mod[$cnt];
                $sig_name =~ s/(.+)(\.)(.+)(\()(.+)(\);)/$5/;
                my $cer_off = &name_exist(\@cer_off_list, $sig_name);
                print OUT_H "#pragma certitude_off\n" if ($cer_off);
                print OUT_H "$mod[$cnt]\n";
                print OUT_H "#pragma certitude_on\n" if ($cer_off);
            }
            print OUT_H "#endif\n" if ($mod[MOD_DBG] ne "");
        }
        }
        my $cer_area = 0;
        foreach $elm (@mod_list) {
            @mod = @$elm;
            print OUT_H "#ifdef $mod[MOD_DBG]\n" if ($mod[MOD_DBG] ne "");
            for ($cnt = MOD_BIND; $cnt < @mod; $cnt++) {
                my $sig_name = $mod[$cnt];
                $sig_name =~ s/(.+)(\.)(.+)(\()(.+)(\);)/$5/;
                my $cer_off = &name_exist(\@cer_off_list, $sig_name);
                print OUT_H "#pragma certitude_on\n"  if (!$cer_off &  $cer_area);
                print OUT_H "#pragma certitude_off\n" if ( $cer_off & !$cer_area);
                print OUT_H "$mod[$cnt]\n";
                $cer_area = $cer_off;
            }
            print OUT_H "#endif\n" if ($mod[MOD_DBG] ne "");
        }
        print OUT_H "#pragma certitude_on\n"  if ($cer_area);

        @mem_used = ();
        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 1);
            my $skip = 0;
            foreach $used (@mem_used) {
                if ($used eq @$elm[M_NAME]) {
                    $skip = 1;
                    last;
                }
            }
            push(@mem_used, @$elm[M_NAME]);
            if ($skip == 0 && @$elm[M_SHARE] > 0) {
                if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                    $ifnm = &get_mem_ifnm(\@$elm);
                    my $inst = $ifnm . "_ins.";
                    print OUT_H "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);
                    $port_nm = &get_mem_portnm(\@$elm, MP1_WA);
                    print OUT_H $tab x2, $inst, "$port_nm($port_nm);\n";
                    $port_nm = &get_mem_portnm(\@$elm, MP1_WE);
                    print OUT_H $tab x2, $inst, "$port_nm($port_nm);\n";
                    $port_nm = &get_mem_portnm(\@$elm, MP1_RA);
                    print OUT_H $tab x2, $inst, "$port_nm($port_nm);\n";
                    if (@$elm[M_RE] > 0) {
                        $port_nm = &get_mem_portnm(\@$elm, MP1_RE);
                        print OUT_H $tab x2, $inst, "$port_nm($port_nm);\n";
                    }
                    $port_nm = &get_mem_portnm(\@$elm, MP1_AD);
                    print OUT_H $tab x2, $inst, "$port_nm($port_nm);\n";
                    if (@$elm[M_RE] > 0) {
                        @$elm[M_CS] = @$elm[M_RE];
                        $port_nm = &get_mem_portnm(\@$elm, MP1_CS);
                        print OUT_H $tab x2, $inst, "$port_nm($port_nm);\n";
                    }
                    print OUT_H "#endif\n" if (@$elm[M_PONLY] == 0);
                }
            }
        }

        foreach $elm (@bind_list) {
            if (@$elm[B_FLG_S] & FLG_FIX) {
                $print_fix_method = 1;
                print OUT_H "\n";
                print OUT_H $tab x2, "SC_METHOD(method_fixed);\n";
                last;
            }
        }

        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 0);
            if (@$elm[M_RW] == MA_RW1 || @$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_R1W1_R ||
                @$elm[M_RW] == MA_RW2_A || @$elm[M_RW] == MA_RW2_B) {
                $print_fix_method = ($print_fix_method==1 || $print_fix_method==3)? 3 : 2;
                if( $print_fix_method==2 ) {
                    print OUT_H $tab x2, "\n";
                    print OUT_H "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);
                    print OUT_H $tab x2, "SC_METHOD(method_fixed);\n";
                    print OUT_H "#endif\n" if (@$elm[M_PONLY] == 0);
                }
                last;
            }
        }
    }
    else {
        print OUT_H "\n#ifndef _CTOS_TOP";
        &print_constructor_cthread_reg;
        &print_constructor_method_osci_reset;

        # SC_METHOD
        foreach $elm (@method_list) {
            print OUT_H "\n";
            print OUT_H $tab x2, "SC_METHOD(@$elm[TH_NAME]);\n";
            print OUT_H $tab x2, "sensitive\n";
            @data = @$elm;
            shift(@data);
            shift(@data);
            shift(@data);
            foreach $in (@data) {
                print OUT_H $tab x2, " << $in\n";
            }
            print OUT_H $tab x2, ";\n";
        }

        # SC_METHOD for memory data shift for sim
        my $start = 1;
        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 1);
            if (@$elm[M_PONLY] == 0) {
                print OUT_H "\n" if ($start == 1);
                print OUT_H $tab x2, "MEM_PIPE";
                print OUT_H "_2R" if (@$elm[M_RW] == MA_R1W1_R || @$elm[M_RW] == MA_RW1_R);
                print OUT_H "_CTOR(@$elm[M_NAME], ";
                print OUT_H (@$elm[M_RW] == MA_R1W1_R || @$elm[M_RW] == MA_RW1_R) ? @$elm[M_CLKR] : @$elm[M_CLKW];
                print OUT_H ")";
                print OUT_H " // SC_METHOD for pipeline function for array access\n";
                $start = 0;
            }
        }
        print OUT_H "#endif\n";
    }

    my @var_dbg_list = ();
    if (($hdl_ies_on || $hdl_vcs_on) && $hdl_debug_trace) {
        foreach my $elm (@var_list,@ctype_list) {
            my $flg = @$elm[T_FLG];
            if ($flg&FLG_DTRACE) {
                push(@var_dbg_list,[@$elm]);
            }
        }
    }

    if ($hdl_ies_on || $hdl_vcs_on) {

        $outfile = $hdl_module . ".sv";
        &my_open(*OUT_SV, "//", "sva", 0);
        print OUT_SV "module ${hdl_module}();\n\n";
        print OUT_SV $tab, "// please write `include \"${hdl_module}_*.svh\"\n\n";
        print OUT_SV "endmodule\n";
        close(OUT_SV);

        if (@reg_list>0 || @ev_list>0 || @var_dbg_list>0) {
            $outfile = $hdl_module . "_" . $module_name . ".svh";
            &my_open(*OUT_SVH, "//", "sva", 0);

            print OUT_H "\n";
            if ($hdl_ies_on == 1) {
                print OUT_H "#ifdef NC_SYSTEMC\n";
                #print OUT_H "#pragma certitude_off\n" if ($opt_cer == 1);
                foreach my $elm (@reg_list,@ev_list,@var_dbg_list) {
                    my $name  = @$elm[T_NAME];
                    my $array = @$elm[T_ARRAY];
                    my $width = @$elm[T_WID];
                    my $type  = @$elm[T_TYPE];

                    if (@$elm[T_FLG] & FLG_STR_TYPE) {
                        #my @rtl_port;
                        #&get_rtl_port(\@rtl_port, $elm);
                        #foreach my $e (@rtl_port) {
                        #    $name = @$e[T_NAME];
                        #    $name =~ s/://g;
                        #    $array = @$e[T_ARRAY];
                        #    $width = @$e[T_WID];
                        #    $type  = @$e[T_TYPE];
                        #    &print_hdl_connection($name, $array, $width, $type, *OUT_H, *OUT_SVH, 2, "ies");
                        #}
                    } else {
                        &print_hdl_connection($name, $array, $width, $type, *OUT_H, *OUT_SVH, 2, "ies");
                    }
                }
                #print OUT_H "#pragma certitude_on\n" if ($opt_cer == 1);
                print OUT_H "#endif\n";
            }
            if ($hdl_vcs_on == 1) {
                print OUT_H "#ifdef VCS_SYSTEMC\n";
                #print OUT_H "#pragma certitude_off\n" if ($opt_cer == 1);
                foreach my $elm (@reg_list,@ev_list,@var_dbg_list) {
                    my $name  = @$elm[T_NAME];
                    my $array = @$elm[T_ARRAY];
                    my $width = @$elm[T_WID];
                    my $type  = @$elm[T_TYPE];

                    if (@$elm[T_FLG] & FLG_STR_TYPE) {
                        #my @rtl_port;
                        #&get_rtl_port(\@rtl_port, $elm);
                        #foreach my $e (@rtl_port) {
                        #    $name = @$e[T_NAME];
                        #    $name =~ s/://g;
                        #    $array = @$e[T_ARRAY];
                        #    $width = @$e[T_WID];
                        #    $type  = @$e[T_TYPE];
                        #    &print_hdl_connection($name, $array, $width, $type, *OUT_H, *OUT_SVH, 2, "vcs");
                        #}
                    } else {
                        &print_hdl_connection($name, $array, $width, $type, *OUT_H, *OUT_SVH, 2, "vcs");
                    }
                }
                #print OUT_H "#pragma certitude_on\n" if ($opt_cer == 1);
                print OUT_H "#endif\n";
            }

            close(OUT_SVH);
        }
    }

    print OUT_H $tab, "}\n";
}

##
## print constructor for interface
##
sub print_if_constructor {
    print OUT_H "\n";
    if ($style_module eq "sc") {
        print OUT_H $tab, "SC_CTOR($ifnm)\n";
    }
    else {
        print OUT_H $tab, "SC_HAS_PROCESS($ifnm);\n";
        print OUT_H $tab, "$ifnm(sc_module_name nm)\n";
        print OUT_H $tab x2, ": sc_module(nm)\n";
    }

    $port_nm_wa = &get_mem_portnm(\@$elm, MP1_WA);
    $port_nm_we = &get_mem_portnm(\@$elm, MP1_WE);
    $port_nm_ra = &get_mem_portnm(\@$elm, MP1_RA);
    $port_nm_re = &get_mem_portnm(\@$elm, MP1_RE);
    $port_nm_ad = &get_mem_portnm(\@$elm, MP1_AD);
    $port_nm_cs = &get_mem_portnm(\@$elm, MP1_CS);
    print OUT_H $tab x2, ": $port_nm_wa(\"$port_nm_wa\")\n";
    print OUT_H $tab x2, ", $port_nm_we(\"$port_nm_we\")\n";
    print OUT_H $tab x2, ", $port_nm_ra(\"$port_nm_ra\")\n";
    if (@$elm[M_RE] > 0) {
        print OUT_H $tab x2, ", $port_nm_re(\"$port_nm_re\")\n";
    }
    print OUT_H $tab x2, ", $port_nm_ad(\"$port_nm_ad\")\n";
    if (@$elm[M_RE] > 0) {
        print OUT_H $tab x2, ", $port_nm_cs(\"$port_nm_cs\")\n";
    }

    print OUT_H $tab, "{";
    print OUT_H "\n#ifndef _CTOS_TOP";

    # SC_METHOD for address selection
    print OUT_H "\n";
    print OUT_H $tab x2, "SC_METHOD(method_select_addr);\n";
    print OUT_H $tab x2, "sensitive\n";
    print OUT_H $tab x2, " << $port_nm_wa\n";
    print OUT_H $tab x2, " << $port_nm_we\n";
    print OUT_H $tab x2, " << $port_nm_ra\n";
    if (@$elm[M_RE] > 0) {
        print OUT_H $tab x2, " << $port_nm_re\n";
    }
    print OUT_H $tab x2, ";\n";

    # SC_METHOD for chip select generation
    if (@$elm[M_RE] > 0) {
        print OUT_H "\n";
        print OUT_H $tab x2, "SC_METHOD(method_generate_cs);\n";
        print OUT_H $tab x2, "sensitive\n";
        print OUT_H $tab x2, " << $port_nm_we\n";
        print OUT_H $tab x2, " << $port_nm_re\n";
        print OUT_H $tab x2, ";\n";
    }

    print OUT_H "#endif\n";
    print OUT_H $tab, "}\n";
}

##
## print constructor initializer
##
sub print_constructor_initializer {
    # initialization list
    foreach $elm (@clk_list) {
        if (@$elm[T_NAME] ne "") {
            print OUT_H $tab x2, ($init == 0) ? ":" : ",";
            $init = 1;
            print OUT_H " @$elm[T_NAME](\"@$elm[T_NAME]\")\n";
        }
    }
    foreach $elm (@rst_list) {
        if (@$elm[T_NAME] ne "") {
            print OUT_H $tab x2, ($init == 0) ? ":" : ",";
            $init = 1;
            print OUT_H " @$elm[T_NAME](\"@$elm[T_NAME]\")\n";
        }
    }
    foreach $elm (@in_list) {
        if ((@$elm[T_NAME] ne "") && (@$elm[T_ARRAY] eq "")) {
            print OUT_H $tab x2, ($init == 0) ? ":" : ",";
            $init = 1;
            print OUT_H " @$elm[T_NAME](\"@$elm[T_NAME]\")\n";
        }
    }
    foreach $elm (@out_list) {
        if ((@$elm[T_NAME] ne "") && (@$elm[T_ARRAY] eq "")) {
            print OUT_H $tab x2, ($init == 0) ? ":" : ",";
            $init = 1;
            print OUT_H " @$elm[T_NAME](\"@$elm[T_NAME]\")\n";
        }
    }

    # insert_port
    if ($top_mode == 1) {
        foreach $elm (@in_list_insert) {
            if ((@$elm[T_NAME] ne "") && (@$elm[T_ARRAY] eq "")) {
                print OUT_H $tab x2, ($init == 0) ? ":" : ",";
                $init = 1;
                print OUT_H " @$elm[T_NAME](\"@$elm[T_NAME]\")\n";
            }
        }
        foreach $elm (@out_list_insert) {
            if ((@$elm[T_NAME] ne "") && (@$elm[T_ARRAY] eq "")) {
                print OUT_H $tab x2, ($init == 0) ? ":" : ",";
                $init = 1;
                print OUT_H " @$elm[T_NAME](\"@$elm[T_NAME]\")\n";
            }
        }
    }

    # not fixed memory
    &print_memory_init_name(1);

    foreach $elm (@ev_list) {
        if (@$elm[T_ARRAY] eq "") {
            print OUT_H $tab x2, ",";
            print OUT_H " EV_ININM(@$elm[T_NAME])\n";
        }
    }
    foreach $elm (@reg_list) {
        if (@$elm[T_ARRAY] eq "") {
            print OUT_H "#ifdef @$elm[T_DBG]\n" if (&is_ifdeffix($elm));
            print OUT_H $tab x2, ($init == 0) ? ":" : ",";
            $init = 1;
            print OUT_H " @$elm[T_NAME](\"@$elm[T_NAME]\")\n";
            print OUT_H "#endif\n" if (&is_ifdeffix($elm));
        }
    }
    foreach $elm (@var_list, @ctype_list) {
        if (@$elm[T_ARRAY] eq "" && @$elm[T_FLG] & FLG_VAR2REG) {
            print OUT_H $tab x2, ($init == 0) ? ":" : ",";
            $init = 1;
            print OUT_H " r_@$elm[T_NAME](\"r_@$elm[T_NAME]\")\n";
        }
    }
    foreach $m (@data_list_m) {
        $macro = shift(@$m);
        $find = 0;
        foreach $elm (@$m) {
            if (@$elm[T_TYPE] =~ /reg$/) {
                $find = 1;
                last;
            }
        }
        if ($find == 1) {
            print OUT_H "#ifdef $macro\n";
            foreach $elm (@$m) {
                if (@$elm[T_TYPE] =~ /reg$/ && @$elm[T_ARRAY] eq "") {
                    print OUT_H $tab x2, ($init == 0) ? ":" : ",";
                    $init = 1;
                    print OUT_H " @$elm[T_NAME](\"@$elm[T_NAME]\")\n";
                }
            }
            print OUT_H "#endif\n";
        }
        unshift(@$m, $macro);
    }
    if ($need_osci == 1 && $top_mode == 0) {
        print OUT_H "#ifdef $osci_macro\n";
        foreach $elm (@thread_list) {
            if (&need_osci_reset($elm)) {
                print OUT_H $tab x2, ",";
                print OUT_H " ssgen_merge_rst_@$elm[TH_NAME](\"ssgen_merge_rst_@$elm[TH_NAME]\")\n";
            }
        }
        print OUT_H "#endif\n";
    }
    @mem_used = ();
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        my $skip = 0;
        foreach $used (@mem_used) {
            if ($used eq @$elm[M_NAME]) {
                $skip = 1;
                last;
            }
        }
        push(@mem_used, @$elm[M_NAME]);
        if ($skip == 0 && @$elm[M_SHARE] > 0) {
            if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                print OUT_H "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);
                $port_nm = &get_mem_portnm(\@$elm, MP1_WA);
                print OUT_H $tab x2, ", $port_nm(\"$port_nm\")\n";
                $port_nm = &get_mem_portnm(\@$elm, MP1_RA);
                print OUT_H $tab x2, ", $port_nm(\"$port_nm\")\n";
                if (@$elm[M_RE] > 0) {
                    $port_nm = &get_mem_portnm(\@$elm, MP1_RE);
                    print OUT_H $tab x2, ", $port_nm(\"$port_nm\")\n";
                }
                print OUT_H "#endif\n" if (@$elm[M_PONLY] == 0);
            }
        }
    }

    # fixed memory
    &print_memory_init_name(0);

    if ($top_mode == 1 || $template_wrapper) {
        foreach $mod (@mod_list) {
            print OUT_H "#ifdef @$mod[MOD_DBG]\n" if (@$mod[MOD_DBG] ne "");
            print OUT_H $tab x2, ($init == 0) ? ":" : ",";
            $init = 1;
            print OUT_H " @$mod[MOD_INST](\"@$mod[MOD_INST]\")\n";
            print OUT_H "#endif\n" if (@$mod[MOD_DBG] ne "");
        }
    }
    @mem_used = ();
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        my $skip = 0;
        if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
            foreach $used (@mem_used) {
                if ($used eq @$elm[M_NAME]) {
                    $skip = 1;
                    last;
                }
            }
            push(@mem_used, @$elm[M_NAME]);
        }
        if ($skip == 0 && @$elm[M_SHARE] > 0) {
            if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                print OUT_H "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);
                $ifnm = &get_mem_ifnm(\@$elm);
                print OUT_H $tab x2, ", ${ifnm}_ins(\"${ifnm}_ins\")\n";
                print OUT_H "#endif\n" if (@$elm[M_PONLY] == 0);
            }
        }
    }
}

##
## print constructor cthread regist
##
sub print_constructor_cthread_reg {
    &get_valid_clock(\$clk_data);
    foreach $elm (@thread_list) {
        $clknm = @$elm[TH_CLK] ne "" ? @$elm[TH_CLK] : @$clk_data[T_NAME];
        $edge  = @$elm[TH_EDGE] ne "" ? @$elm[TH_EDGE] : "pos";
        print OUT_H "\n";
        print OUT_H "#if !defined(__CTOS__) && !defined(CALYPTO_SYSC) && !defined(STRATUS)\n" if (@$elm[TH_FLG] & FLG_DUMMY);
        print OUT_H $tab x2;
        print OUT_H "SC_CTHREAD(@$elm[TH_NAME], $clknm.$edge());\n";
        print OUT_H "#ifndef $osci_macro\n" if (&need_osci_reset($elm));
        if (@$elm == TH_RST) {
            foreach $rst (@rst_list) {
                print OUT_H $tab x2;
                if (@$rst[T_TYPE] eq "areset") {
                    print OUT_H "async_reset_signal_is(";
                }
                else {
                    print OUT_H "reset_signal_is(";
                }
                print OUT_H @$rst[T_NAME], ", ",
                            @$rst[T_INIT] eq "pos" ? "true" : "false", ");\n";
            }
        }
        elsif (lc @$elm[TH_RST] ne "n") {
            for ($i = TH_RST; $i < @$elm; $i++) {
                $name = @$elm[$i];
                &name_exist(\@rst_list, $name, \$rst);
                print OUT_H $tab x2;
                if (@$rst[T_TYPE] eq "areset") {
                    print OUT_H "async_reset_signal_is(";
                }
                else {
                    print OUT_H "reset_signal_is(";
                }
                print OUT_H @$rst[T_NAME], ", ",
                            @$rst[T_INIT] eq "pos" ? "true" : "false", ");\n";
            }
        }

        if (&need_osci_reset($elm)) {
            print OUT_H "#else\n";
            print OUT_H $tab x2;
            print OUT_H "reset_signal_is(ssgen_merge_rst_@$elm[TH_NAME], true);\n";
            print OUT_H "#endif\n";
        }
        print OUT_H "#endif\n" if (@$elm[TH_FLG] & FLG_DUMMY);
    }
}

sub print_constructor_method_osci_reset {
    # SC_METHOD for osci reset
    if ($need_osci == 1) {
        print OUT_H "\n";
        print OUT_H "#ifdef $osci_macro\n";
        foreach $elm (@thread_list) {
            if (&need_osci_reset($elm)) {
                print OUT_H $tab x2, "SC_METHOD(method_ssgen_merge_rst_@$elm[TH_NAME]);\n";
                print OUT_H $tab x2, "sensitive\n";
                if (@$elm == TH_RST) {
                    foreach $rst (@rst_list) {
                        print OUT_H $tab x2, " << @$rst[T_NAME]\n";
                    }
                }
                else {
                    for ($i = TH_RST; $i < @$elm; $i++) {
                        $name = @$elm[$i];
                        print OUT_H $tab x2, " << $name\n";
                    }
                }
                print OUT_H $tab x2, ";\n\n";
            }
        }
        print OUT_H "#endif\n";
    }
}

##
## print soft reset function
##   OUT       : file pointer
##   $out_mode : print mode (= 0:header, 1:header-proto, 2:source)
##
sub print_soft_reset_func {
    local(*OUT) = $_[0];
    my $out_mode = $_[1];
    my $indent = $out_mode == 2 ? "" : $tab;

    foreach $elm (@rst_list) {
        next if (@$elm[T_TYPE] ne "soft_reset");

        $mode = $out_mode;
        if ($out_mode == 1) {
            if (@$elm[T_FLG] & FLG_HDR) {
                $mode = 0;
            }
        }
        elsif ($out_mode == 2) {
            if (@$elm[T_FLG] & FLG_HDR) {
                next;
            }
        }

        print OUT "\n";
        print OUT $indent, "void ";
        if ($mode  == 2) {
            print OUT $module_name, "::";
        }
        print OUT "set_@$elm[T_NAME]()";
        print OUT ($mode == 1 ? ";" : " {"), "\n";
        if ($mode != 1) {
            print OUT $indent, $tab, "@$elm[T_NAME].write(";
            print OUT @$elm[T_INIT] eq "pos" ? 1 : 0, ");\n";
            print OUT $indent, $tab, "$wait_name";
            print OUT "_@$elm[T_TH]" if (@thread_list > 1);
            print OUT "();\n";
            print OUT $indent, "}\n";
        }
    }
}

##
## print ssgen reset function for OSCI-Sim (not always)
##
sub print_ssgen_reset_func {
    # function for OSCI sim
    if ($need_osci == 1) {
        print OUT_H "\n";
        print OUT_H "#ifdef $osci_macro\n";
        foreach $elm (@thread_list) {
            if (&need_osci_reset($elm)) {
                print OUT_H $tab, "void method_ssgen_merge_rst_@$elm[TH_NAME]() {\n";
                print OUT_H $tab x2, "ssgen_merge_rst_@$elm[TH_NAME].write(\n";
                if (@$elm == TH_RST) {
                    for ($i = 0; $i < @rst_list; $i++) {
                        $rst = $rst_list[$i];
                        print OUT_H $tab x3, ($i == 0) ? "    " : " || ";
                        print OUT_H "@$rst[T_NAME].read() == ";
                        print OUT_H @$rst[T_INIT] eq "pos" ? "1" : "0", "\n";
                    }
                }
                else {
                    for ($i = TH_RST; $i < @$elm; $i++) {
                        $name = @$elm[$i];
                        &name_exist(\@rst_list, $name, \$rst);
                        print OUT_H $tab x3, ($i == TH_RST) ? "    " : " || ";
                        print OUT_H "@$rst[T_NAME].read() == ";
                        print OUT_H @$rst[T_INIT] eq "pos" ? "1" : "0", "\n";
                    }
                }
                print OUT_H $tab x2, ");\n";
                print OUT_H $tab, "}\n\n";
            }
        }
        print OUT_H "#endif\n";
    }
}

##
## print reset function
##   OUT       : file pointer
##   $out_mode : print mode (= 0:header, 1:header-proto, 2:source)
##
sub print_reset_func {
    local(*OUT) = $_[0];
    my $out_mode = $_[1];
    my $indent = $out_mode == 2 ? "" : $tab;

    foreach $th (@thread_list) {
        $mode = $out_mode;
        if ($out_mode == 1) {
            if (@$th[TH_FLG] & FLG_HDR_RST) {
                $mode = 0;
            }
        }
        elsif ($out_mode == 2) {
            if (@$th[TH_FLG] & FLG_HDR_RST) {
                next;
            }
        }
        if (@$th == TH_RST) {
            $rst_num = @rst_list;
        }
        else {
            $rst_num = lc @$th[TH_RST] eq "n" ? 0 : @$th - TH_RST;
        }
        next if ($rst_num == 0);

        print OUT "\n";
        print OUT $indent, "void ";
        if ($mode  == 2) {
            print OUT $module_name, "::";
        }
        print OUT "reset_@$th[TH_NAME]()";
        print OUT ($mode == 1 ? ";" : " {"), "\n";
        if ($mode != 1) {
            # soft_reset
            foreach $rst (@rst_list) {
                if (@$rst[T_TYPE] eq "soft_reset") {
                    if (@$th[TH_NAME] eq @$rst[T_TH]) {
                        print OUT $indent, $tab, "@$rst[T_NAME].write(";
                        print OUT @$rst[T_INIT] eq "pos" ? 0 : 1, ");\n";
                    }
                }
            }

            # common
            &print_init_data(*OUT, $indent, @$th[TH_NAME], \@out_list);
            &print_init_data(*OUT, $indent, @$th[TH_NAME], \@ev_list);
            &print_init_data(*OUT, $indent, @$th[TH_NAME], \@reg_list);
            &print_init_data(*OUT, $indent, @$th[TH_NAME], \@var_list);
            &print_init_data(*OUT, $indent, @$th[TH_NAME], \@ctype_list);

            # mem
            &print_memory_init(*OUT, $indent, @$th[TH_NAME]);

            # slecbb
            $slecbb_exist = 0;
            foreach $slecbb (@out_list_slecbb) {
                if (@$slecbb[T_TH] eq @$th[TH_NAME]) {
                    $slecbb_exist = 1;
                    last;
                }
            }
            if ($slecbb_exist) {
                print OUT "#ifdef $slecbb_macro\n";
                &print_init_data(*OUT, $indent, @$th[TH_NAME], \@out_list_slecbb);
                print OUT "#endif\n";
            }

            # sim
            foreach $m (@data_list_m) {
                $macro = shift(@$m);
                $find = 0;
                foreach $elm (@$m) {
                    if (@$elm[T_TH] eq @$th[TH_NAME]) {
                        $find = 1;
                        last;
                    }
                }
                if ($find) {
                    print OUT "#ifdef $macro\n";
                    #print OUT "#pragma certitude_off\n" if($opt_cer == 1);
                    &print_init_data(*OUT, $indent, @$th[TH_NAME], \@$m);
                    #print OUT "#pragma certitude_on\n" if($opt_cer == 1);
                    print OUT "#endif\n";
                }
                unshift(@$m, $macro);
            }

            print OUT $indent, "}\n";
        }
    }
}

##
## print wait function
##   OUT       : file pointer
##   $out_mode : print mode (= 0:header, 1:header-proto, 2:source)
##
sub print_wait_func {
   local(*OUT) = $_[0];
    my $out_mode = $_[1];
    my $indent = $out_mode == 2 ? "" : $tab;

    foreach $th (@thread_list) {
        $mode = $out_mode;
        if ($out_mode == 1) {
            if (@$th[TH_FLG] & FLG_HDR_WAIT) {
                $mode = 0;
            }
        }
        elsif ($out_mode == 2) {
            if (@$th[TH_FLG] & FLG_HDR_WAIT) {
                next;
            }
        }
        print OUT "\n";
        print OUT $indent, "void ";
        if ($mode == 2) {
            print OUT $module_name, "::";
        }
        print OUT "$wait_name";
        print OUT "_@$th[TH_NAME]" if (@thread_list > 1);
        print OUT "()";
        print OUT ($mode == 1 ? ";" : " {"), "\n";
        if ($mode != 1) {
            if ($wait_expand == 1 || (@$th[TH_FLG] & FLG_WAIT_EXP)) {
                # pre_ev function call
                if ((@$th[TH_FLG] & FLG_EV)) {
                    print OUT $indent, $tab, "ev_prev_write";
                    print OUT "_@$th[TH_NAME]" if (@thread_list > 1);
                    print OUT "();\n";
                }

                # prepare toggle function call
                if ($toggle_cov_mode != 0 && (@$th[TH_NAME] eq @{$thread_list[0]}[TH_NAME])) {
                    print OUT $indent, $tab, "prepare_toggle();\n";
                }

                # debug_trace function call
                if ((@$th[TH_FLG] & FLG_DTRACE)) {
                    print OUT $indent, $tab, "debug_trace";
                    print OUT "_@$th[TH_NAME]" if (@thread_list > 1);
                    print OUT "();\n";
                }
            }
            else {
                print OUT $indent, $tab, "prev_wait";
                print OUT "_@$th[TH_NAME]" if (@thread_list > 1);
                print OUT "();\n";
            }

            print OUT $indent, $tab, "wait();\n";

            if ($wait_expand == 1 || (@$th[TH_FLG] & FLG_WAIT_EXP)) {
                # post_ev function call
                if ((@$th[TH_FLG] & FLG_EV)) {
                    print OUT $indent, $tab, "ev_post_read";
                    print OUT "_@$th[TH_NAME]" if (@thread_list > 1);
                    print OUT "();\n";
                }

                # var2reg function call
                if ((@$th[TH_FLG] & FLG_VAR2REG)) {
                    print OUT $indent, $tab, "read_var2reg";
                    print OUT "_@$th[TH_NAME]" if (@thread_list > 1);
                    print OUT "();\n";
                }

                # nagate memory port description
                if (!(@$th[TH_FLG] & FLG_PIPE)) {
                    &print_memory_neg(*OUT, $indent. $tab, @$th[TH_NAME]);
                }

                # toggle check function call
                if ($toggle_cov_mode != 0 && (@$th[TH_NAME] eq @{$thread_list[0]}[TH_NAME])) {
                    print OUT $indent, $tab, "check_toggle();\n";
                }

                $range_exist = 0;
                foreach $elm (@in_list, @out_list, @reg_list, @var_list, @ctype_list, @ev_list) {
                    if (@$elm[T_TH] eq @$th[TH_NAME]
                            && (@$elm[T_FLG] & FLG_RNGCHK)
                            && (@$elm[T_MIN] ne "" || @$elm[T_MAX] ne "" || &is_struct(@$elm[T_WID]) )) {
                        $range_exist = 1;
                        last;
                    }
                }
                # range check description
                if ($range_exist) {
                    print OUT "\n";
                    &print_range_data(*OUT, $indent, @$th[TH_NAME], \@in_list);
                    &print_range_data(*OUT, $indent, @$th[TH_NAME], \@out_list);
                    &print_range_data(*OUT, $indent, @$th[TH_NAME], \@ev_list);
                    &print_range_data(*OUT, $indent, @$th[TH_NAME], \@reg_list);
                    &print_range_data(*OUT, $indent, @$th[TH_NAME], \@var_list);
                    &print_range_data(*OUT, $indent, @$th[TH_NAME], \@ctype_list);
                }

                $cov_exist = 0;
                foreach $elm (@in_list, @out_list, @reg_list, @var_list, @ctype_list, @ev_list) {
                    if (@$elm[T_TH] eq @$th[TH_NAME] && (@$elm[T_FLG] & FLG_RNGCHK)) {
                        $cov_exist = 1;
                        last;
                    }
                }
                # coverage description
                if ($cov_exist) {
                    print OUT "\n#ifdef $cov_macro";
                    &print_cov_data(*OUT, $indent, @$th[TH_NAME], \@in_list);
                    &print_cov_data(*OUT, $indent, @$th[TH_NAME], \@out_list);
                    &print_cov_data(*OUT, $indent, @$th[TH_NAME], \@ev_list);
                    &print_cov_data(*OUT, $indent, @$th[TH_NAME], \@reg_list);
                    &print_cov_data(*OUT, $indent, @$th[TH_NAME], \@var_list);
                    &print_cov_data(*OUT, $indent, @$th[TH_NAME], \@ctype_list);
                    print OUT "#endif\n";
                }

                # slecbb function call
                if ((@$th[TH_FLG] & FLG_SLECBB)) {
                    print OUT $indent, $tab, "clear_bbox_out";
                    print OUT "_@$th[TH_NAME]" if (@thread_list > 1);
                    print OUT "();\n";
                }
            }
            else {
                print OUT $indent, $tab, "post_wait";
                print OUT "_@$th[TH_NAME]" if (@thread_list > 1);
                print OUT "();\n";
            }

            print OUT $indent, "}\n";
        }
    }
}

##
## print prev_wait function
##
sub print_prev_wait_func {
    if ($wait_expand == 0) {
        foreach $th (@thread_list) {
            next if (@$th[TH_FLG] & FLG_WAIT_EXP);

            print OUT_H "\n";
            print OUT_H $tab, "void prev_wait";
            print OUT_H "_@$th[TH_NAME]" if (@thread_list > 1);
            print OUT_H "() {\n";

            # pre_ev function call
            if ((@$th[TH_FLG] & FLG_EV)) {
                print OUT_H $tab x2, "ev_prev_write";
                print OUT_H "_@$th[TH_NAME]" if (@thread_list > 1);
                print OUT_H "();\n";
            }

            # prepare toggle function call
            if ($toggle_cov_mode != 0 && (@$th[TH_NAME] eq @{$thread_list[0]}[TH_NAME])) {
                print OUT_H $tab x2, "prepare_toggle();\n";
            }

            # debug_trace function call
            if ((@$th[TH_FLG] & FLG_DTRACE)) {
                print OUT_H $tab x2, "debug_trace";
                print OUT_H "_@$th[TH_NAME]" if (@thread_list > 1);
                print OUT_H "();\n";
            }

            print OUT_H $tab, "}\n";
        }
    }
}

##
## print post_wait function
##
sub print_post_wait_func {
    if ($wait_expand == 0) {
        foreach $th (@thread_list) {
            next if (@$th[TH_FLG] & FLG_WAIT_EXP);

            print OUT_H "\n";
            print OUT_H $tab, "void post_wait";
            print OUT_H "_@$th[TH_NAME]" if (@thread_list > 1);
            print OUT_H "() {\n";

            # post_ev function call
            if ((@$th[TH_FLG] & FLG_EV)) {
                print OUT_H $tab x2, "ev_post_read";
                print OUT_H "_@$th[TH_NAME]" if (@thread_list > 1);
                print OUT_H "();\n";
            }

            # var2reg function call
            if ((@$th[TH_FLG] & FLG_VAR2REG)) {
                print OUT_H $tab x2, "read_var2reg";
                print OUT_H "_@$th[TH_NAME]" if (@thread_list > 1);
                print OUT_H "();\n";
            }

            # nagate memory port description
            if (!(@$th[TH_FLG] & FLG_PIPE)) {
                &print_memory_neg(*OUT_H, $tab x2, @$th[TH_NAME]);
            }

            # toggle check function call
            if ($toggle_cov_mode != 0 && (@$th[TH_NAME] eq @{$thread_list[0]}[TH_NAME])) {
                print OUT_H $tab x2, "check_toggle();\n";
            }

            $range_exist = 0;
            foreach $elm (@in_list, @out_list, @reg_list, @var_list, @ctype_list, @ev_list) {
                if (@$elm[T_TH] eq @$th[TH_NAME]
                        && (@$elm[T_FLG] & FLG_RNGCHK)
                        && (@$elm[T_MIN] ne "" || @$elm[T_MAX] ne "" || is_struct(@$elm[T_WID])) ) {
                    $range_exist = 1;
                    last;
                }
            }
            # range check description
            if ($range_exist) {
                print OUT_H "\n";
                &print_range_data(*OUT_H, $tab, @$th[TH_NAME], \@in_list);
                &print_range_data(*OUT_H, $tab, @$th[TH_NAME], \@out_list);
                &print_range_data(*OUT_H, $tab, @$th[TH_NAME], \@ev_list);
                &print_range_data(*OUT_H, $tab, @$th[TH_NAME], \@reg_list);
                &print_range_data(*OUT_H, $tab, @$th[TH_NAME], \@var_list);
                &print_range_data(*OUT_H, $tab, @$th[TH_NAME], \@ctype_list);
            }

            $cov_exist = 0;
            foreach $elm (@in_list, @out_list, @reg_list, @var_list, @ctype_list, @ev_list) {
                if (@$elm[T_TH] eq @$th[TH_NAME] && (@$elm[T_FLG] & FLG_RNGCHK)) {
                    $cov_exist = 1;
                    last;
                }
            }
            # coverage description
            if ($cov_exist) {
                print OUT_H "\n#ifdef $cov_macro";
                &print_cov_data(*OUT_H, $tab, @$th[TH_NAME], \@in_list);
                &print_cov_data(*OUT_H, $tab, @$th[TH_NAME], \@out_list);
                &print_cov_data(*OUT_H, $tab, @$th[TH_NAME], \@ev_list);
                &print_cov_data(*OUT_H, $tab, @$th[TH_NAME], \@reg_list);
                &print_cov_data(*OUT_H, $tab, @$th[TH_NAME], \@var_list);
                &print_cov_data(*OUT_H, $tab, @$th[TH_NAME], \@ctype_list);
                print OUT_H "#endif\n";
            }

            # slecbb function call
            if ((@$th[TH_FLG] & FLG_SLECBB)) {
                print OUT_H $tab x2, "clear_bbox_out";
                print OUT_H "_@$th[TH_NAME]" if (@thread_list > 1);
                print OUT_H "();\n";
            }

            print OUT_H $tab, "}\n";
        }
    }
}

## print thread
##   OUT       : file pointer
##   $out_mode : print mode (= 0:header, 1:header-proto, 2:source)
##
sub print_thread {
    local(*OUT) = $_[0];
    my $out_mode = $_[1];
    my $indent = $out_mode == 2 ? "" : $tab;

    foreach $elm (@thread_list) {
        print OUT "\n";
        if (@$elm[TH_COM] ne "") {
            print OUT $indent, &comment(@$elm[TH_COM]);
        }
        if ($out_mode == 1) {
            print OUT $indent, "void ", @$elm[TH_NAME], "();\n"
        }
        else {
            print OUT $indent, "void ";
            if ($out_mode  == 2) {
                print OUT $module_name, "::";
            }
            print OUT @$elm[TH_NAME], "() {\n";
            if (@$elm == TH_RST) {
                $rst_num = @rst_list;
            }
            else {
                $rst_num = lc @$elm[TH_RST] eq "n" ? 0 : @$elm - TH_RST;
            }
            if ($rst_num > 0) {
                if ($opt_stratus && (@$elm[TH_FLG] & FLG_PIPE)) {
                    print OUT $indent, $tab, "{ HLS_DEFINE_PROTOCOL(\"RESET\");\n";
                }
                if ($rst_num < 2) {
                    print OUT $indent, $tab, "reset_@$elm[TH_NAME]();\n";
                }
                else {
                    print OUT "#ifndef $osci_macro\n" if (&need_osci_reset($elm));
                    for ($j = 0; $j < $rst_num; $j++) {
                        if (@$elm == TH_RST) {
                            $rst = $rst_list[$j];
                        }
                        else {
                            $name = @$elm[$j + TH_RST];
                            &name_exist(\@rst_list, $name, \$rst);
                        }
                        if ($j == $rst_num - 1) {
                            print OUT $indent, $tab, "else {\n";
                        }
                        else {
                            print OUT $indent, $tab;
                            if ($j == 0) {
                                print OUT "if (";
                            }
                            else {
                                print OUT "else if (";
                            }
                            print OUT @$rst[T_NAME], ".read() == ";
                            print OUT @$rst[T_INIT] eq "pos" ? "1" : "0", ") {\n";
                        }
                        print OUT $indent, $tab x2, "reset_@$elm[TH_NAME]();\n";
                        print OUT $indent, $tab, "}\n";
                    }
                    if (&need_osci_reset($elm)) {
                        print OUT "#else\n";
                        print OUT $indent, $tab, "reset_@$elm[TH_NAME]();\n";
                        print OUT "#endif\n";
                    }
                }
                print OUT $indent, $tab, "wait();\n";
                if ($opt_stratus && (@$elm[TH_FLG] & FLG_PIPE)) {
                    print OUT $indent, $tab, "}\n";
                }
            }

            print OUT $indent, $tab, "@$elm[TH_MACRO]:\n" if ($opt_stratus == 0 && (@$elm[TH_FLG] & FLG_PIPE));
            print OUT $indent, $tab, "while (1) {\n";
            if ($opt_stratus && (@$elm[TH_FLG] & FLG_PIPE)) {
                print OUT $indent, $tab x2, "HLS_PIPELINE_LOOP(HARD_STALL, 1, \"STRATUS_MAIN_LOOP\");\n\n";
                print OUT $indent, $tab x2, "{ HLS_DEFINE_PROTOCOL(\"INPUT\");\n";
                print OUT $indent, $tab x2, "// please write here for input accesses!\n";
                print OUT $indent, $tab x2, "}\n\n";
                print OUT $indent, $tab x2, "{ HLS_CONSTRAIN_LATENCY(0, @$elm[TH_LAT], \"PL_MAIN_CONST\");\n";
                print OUT $indent, $tab x2, "// please write here for main pipeline process!\n";
                print OUT $indent, $tab x2, "}\n\n";
                print OUT $indent, $tab x2, "{ HLS_DEFINE_PROTOCOL(\"OUTPUT\");\n";
                print OUT $indent, $tab x2, "// please write here for output accesses!\n";
            }
            else {
                print OUT $indent, $tab x2, "// please write here!\n";
                if (@thread_list == 1 && $use_aigen == 1) {
                    print OUT $indent, $tab x2, "apb_access();\n";
                }
                if (@$elm[TH_FLG] & FLG_PIPE) {
                    &print_memory_neg(*OUT, $indent . $tab x2, @$elm[TH_NAME]);
                }
            }
            print OUT $indent, $tab x2, "$wait_name";
            print OUT "_@$elm[TH_NAME]" if (@thread_list > 1);
            print OUT "();\n";
            if ($opt_stratus && (@$elm[TH_FLG] & FLG_PIPE)) {
                print OUT $indent, $tab x2, "}\n";
            }
            print OUT $indent, $tab, "}\n";
            print OUT $indent, "}\n";
        }
    }
}

##
## print method
##   OUT       : file pointer
##   $out_mode : print mode (= 0:header, 1:header-proto, 2:source)
##
sub print_method {
    local(*OUT) = $_[0];
    my $out_mode = $_[1];
    my $indent = $out_mode == 2 ? "" : $tab;

    foreach $elm (@method_list) {
        next if ($out_mode == 2 && (@$elm[TH_FLG] & FLG_ONLY_DEF));
        $name = @$elm[TH_NAME];

        print OUT "\n";
        if (@$elm[F_COM] ne "") {
            print OUT $indent, &comment(@$elm[F_COM]);
        }
        if ($out_mode == 1) {
            print OUT $indent, "void ", $name, "();\n"
        }
        else {
            print OUT $indent, "void ";
            if ($out_mode  == 2) {
                print OUT $module_name, "::";
            }
            print OUT $name, "() {\n";
            print OUT $indent, $tab, "// please write here!\n";
            print OUT $indent, "}\n";
        }
    }
}

##
## print method for fixed port/mem (top mode only)
##
sub print_method_fixed {

    if($print_fix_method != 0) {
        print OUT_H "\n";
        print OUT_H "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0 && $print_fix_method == 2);
        print OUT_H $tab, "void method_fixed() {\n";

        # methods for fix port
        &print_method_fixed_port;

        # methods for fix mem
        &print_method_fixed_mem;

        print OUT_H $tab, "}\n";
        print OUT_H "#endif\n" if (@$elm[M_PONLY] == 0 && $print_fix_method == 2);
    }
}

##
## print method for fixed port (top mode only)
##
sub print_method_fixed_port {
    foreach $elm (@bind_list) {
        if (@$elm[B_FLG_S] & FLG_FIX) {
            &get_reg_data(@$elm[B_SIG], \$reg);
            print OUT_H "\n";
            print OUT_H "#ifdef @$reg[T_DBG]\n" if (&is_ifdeffix($reg));
            #print OUT_H $tab, "void method_write_@$elm[B_SIG]() {\n";
            if (@$reg[T_ARRAY] eq "") {
                print OUT_H $tab x2, "@$elm[B_SIG].write(@$elm[B_PORT_S]);\n";
            }
            else {
                my @dim = ();
                my @num = ();
                while (@$reg[T_ARRAY] =~ /\w+/g) {
                    push(@dim, $&);
                }
                for ($i = 0; $i < @dim; $i++) {
                    print OUT_H $tab x2, $tab x$i, "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
                }
                print OUT_H $tab x2, $tab x$i, "@$elm[B_SIG]";
                for ($i = 0; $i < @dim; $i++) {
                    print OUT_H "[i$i]";
                }
                print OUT_H ".write(@$elm[B_PORT_S]);\n";
                for ($i = @dim - 1; $i >= 0; $i--) {
                    print OUT_H $tab x2, $tab x$i, "}\n";
                }
            }
            #print OUT_H $tab, "}\n";
            print OUT_H "#endif\n" if (&is_ifdeffix($reg));
        }
    }
}

##
## print method for fixed mem (top mode only)
##
sub print_method_fixed_mem {
    foreach $elm (@mem_list) {
        next if (@$elm[M_FIX] == 0);
        if (@$elm[M_RW] == MA_RW1 || @$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_R1W1_R ||
            @$elm[M_RW] == MA_RW2_A || @$elm[M_RW] == MA_RW2_B) {
            print OUT_H $tab, "\n";
            print OUT_H "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0 && $print_fix_method == 3);
            #print OUT_H $tab, "void method_write_@$elm[M_NAME]() {\n";
            if (@$elm[M_RW] == MA_RW1) {
                $port_nm = &get_mem_portnm(\@$elm, MP1_RD);
            }
            elsif(@$elm[M_RW] == MA_RW1_R) {
                $port_nm = &get_mem_portnm(\@$elm, MP1_RD);
            }
            elsif(@$elm[M_RW] == MA_R1W1_R) {
                $port_nm = &get_mem_portnm(\@$elm, MP2_RD);
            }
            elsif(@$elm[M_RW] == MA_RW2_A) {
                $port_nm = &get_mem_portnm(\@$elm, MPA_RD);
            }
            elsif(@$elm[M_RW] == MA_RW2_B) {
                $port_nm = &get_mem_portnm(\@$elm, MPB_RD);
            }
            print OUT_H $tab x2, "$port_nm.write(0);\n";
            print OUT_H "#endif\n" if (@$elm[M_PONLY] == 0 && $print_fix_method == 3);
        }
    }
}

##
## print ev data
##   OUT       : file pointer
##   $indent   : indent string
##   $thnm     : belonged thread name
##   $macro    : macro name
##   $ptr_list : pointer of list
##
sub print_ev_data {
    local(*OUT)  = $_[0];
    my $indent   = $_[1];
    my $thnm     = $_[2];
    my $macro    = $_[3];
    my $ptr_list = $_[4];

    $indent = $indent . $tab;

    foreach $elm (@$ptr_list) {
        next if ($thnm ne "" && $thnm ne @$elm[T_TH]);
        $name = @$elm[T_NAME];
        $array = @$elm[T_ARRAY];
        my @dim = ();
        my @num = ();

        if ($array eq "") {
            print OUT $indent, "$macro($name);\n";
        }
        else {
            while ($array =~ /\w+/g) {
                push(@dim, $&);
            }
            while ($init =~ /[^\s\{\}\,]+/g) {
                push(@num, $&);
            }
            for ($i = 0; $i < @dim; $i++) {
                print OUT $indent, $tab x$i, "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
            }
            print OUT $indent, $tab x $i, "$macro($name";
            for ($i = 0; $i < @dim; $i++) {
                print OUT "[i$i]";
            }
            print OUT ");\n";
            for ($i = @dim - 1; $i >= 0; $i--) {
                print OUT $indent, $tab x$i, "}\n";
            }
        }
    }
}

##
## print ev function
##   OUT       : file pointer
##   $out_mode : print mode (= 0:header, 1:header-proto, 2:source)
##
sub print_ev_func {
    local(*OUT) = $_[0];
    my $out_mode = $_[1];
    my $indent = $out_mode == 2 ? "" : $tab;

    foreach $elm (@thread_list) {
        if (@$elm[TH_FLG] & FLG_EV) {
            print OUT "\n";
            print OUT $indent, "void ";
            if ($out_mode == 2) {
                print OUT $module_name, "::";
            }
            print OUT "ev_prev_write";
            print OUT "_@$elm[TH_NAME]" if (@thread_list > 1);
            print OUT "()";
            print OUT ($out_mode == 1 ? ";" : " {"), "\n";
            if ($out_mode != 1) {
                &print_ev_data(*OUT, $indent, @$elm[TH_NAME], "EV_WR", \@ev_list);
                print OUT $indent, "}\n";
            }

            print OUT "\n";
            print OUT $indent, "void ";
            if ($out_mode == 2) {
                print OUT $module_name, "::";
            }
            print OUT "ev_post_read";
            print OUT "_@$elm[TH_NAME]" if (@thread_list > 1);
            print OUT "()";
            print OUT ($out_mode == 1 ? ";" : " {"), "\n";
            if ($out_mode != 1) {
                &print_ev_data(*OUT, $indent, @$elm[TH_NAME], "EV_RD", \@ev_list);
                print OUT $indent, "}\n";
            }
        }
    }
}

##
## print var2reg data
##   OUT       : file pointer
##   $indent   : indent string
##   $thnm     : belonged thread name
##   $ptr_list : pointer of list
##
sub print_var2reg_data {
    local(*OUT)  = $_[0];
    my $indent   = $_[1];
    my $thnm     = $_[2];
    my $ptr_list = $_[3];

    $indent = $indent . $tab;

    foreach $elm (@$ptr_list) {
        next if ($thnm ne "" && $thnm ne @$elm[T_TH]);
        next if (!(@$elm[T_FLG] & FLG_VAR2REG));

        $name = @$elm[T_NAME];
        $array = @$elm[T_ARRAY];
        my @dim = ();
        my @num = ();

        if ($array eq "") {
            print OUT $indent, "$name = r_$name.read();\n";
        }
        else {
            while ($array =~ /\w+/g) {
                push(@dim, $&);
            }
            while ($init =~ /[^\s\{\}\,]+/g) {
                push(@num, $&);
            }
            for ($i = 0; $i < @dim; $i++) {
                print OUT $indent, $tab x$i, "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
            }
            print OUT $indent, $tab x $i, "$name";
            for ($i = 0; $i < @dim; $i++) {
                print OUT "[i$i]";
            }
            print OUT " = r_$name";
            for ($i = 0; $i < @dim; $i++) {
                print OUT "[i$i]";
            }
            print OUT ".read();\n";
            for ($i = @dim - 1; $i >= 0; $i--) {
                print OUT $indent, $tab x$i, "}\n";
            }
        }
    }
}

##
## print var2reg function
##   OUT       : file pointer
##   $out_mode : print mode (= 0:header, 1:header-proto, 2:source)
##
sub print_var2reg_func {
    local(*OUT) = $_[0];
    my $out_mode = $_[1];
    my $indent = $out_mode == 2 ? "" : $tab;

    foreach $elm (@thread_list) {
        if (@$elm[TH_FLG] & FLG_VAR2REG) {
            print OUT "\n";
            print OUT $indent, "void ";
            if ($out_mode == 2) {
                print OUT $module_name, "::";
            }
            print OUT "read_var2reg";
            print OUT "_@$elm[TH_NAME]" if (@thread_list > 1);
            print OUT "()";
            print OUT ($out_mode == 1 ? ";" : " {"), "\n";
            if ($out_mode != 1) {
                &print_var2reg_data(*OUT, $indent, @$elm[TH_NAME], \@var_list);
                &print_var2reg_data(*OUT, $indent, @$elm[TH_NAME], \@ctype_list);
                print OUT $indent, "}\n";
            }
        }
    }
}

##
## print toggle prepare function
##   OUT       : file pointer
##
sub print_toggle_prepare_func {
    local(*OUT) = $_[0];

    if (($top_mode == 1 || @thread_list != 0) && $toggle_cov_mode != 0) {
        print OUT "\n";
        print OUT $tab, "void prepare_toggle() {\n";
        print OUT "#ifdef $cov_macro\n";
        foreach $elm (@in_list, @out_list, @in_list_sync, @out_list_sync) {
            next if ($top_mode == 1 && @$elm[T_INST] ne $mod_inst);
            next if (@$elm[T_TYPE] =~ /in/ && $toggle_cov_mode != 1 && $toggle_cov_mode != 2);
            next if (@$elm[T_TYPE] =~ /out/ && $toggle_cov_mode != 1 && $toggle_cov_mode != 3);
            if (@$elm[T_ARRAY] eq "") {
                print OUT $tab x2, "mCov_" . @$elm[T_NAME] . " = ";
                print OUT @$elm[T_NAME] . ".read();\n";
            }
            else {
                my $name = @$elm[T_NAME];
                my @dim = ();
                while (@$elm[T_ARRAY] =~ /\w+/g) {
                    push(@dim, $&);
                }
                for (my $i = 0; $i < @dim; $i++) {
                    print OUT $tab x($i+2), "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
                    $name = $name . "[i$i]";
                }
                print OUT $tab x(@dim + 2), "mCov_" . $name . " = " . $name . ".read();\n";
                for (my $i = @dim - 1; $i >= 0; $i--) {
                    print OUT $tab x($i+2), "}\n";
                }
            }
        }
        print OUT "#endif\n";
        print OUT $tab, "}\n";
    }
}

##
## print toggle check function for each element
##   OUT       : file pointer
##   $array    : array info
##   name      : variable name
##   wid       : data width
##
sub print_toggle_check_func_elm {
    local(*OUT) = $_[0];
    my $elm     = $_[1];
    my $toggle_name = $_[2];
    my $var_name = @$elm[T_NAME];
    $var_name = "$toggle_name.$var_name" if ($toggle_name ne "");

    my $wid  = (@$elm[T_WID] eq "b") ? @$elm[T_WID] : &get_macro_value(@$elm[T_WID], "", 0);
    my $type = @$elm[T_TYPE];

    if (@$elm[T_WID] eq "b") {
        $type = "bool";
    }
    else {
        $type = &get_sctype(($type =~ /^u/) ? 0 : 1, @$elm[T_WID]);
    }
    if ($wid !~ /^\d/ && $type eq "") {
        if (@$elm[T_TYPE] =~ /char/) {
            $wid = 8;
        } elsif (@$elm[T_TYPE] =~ /short/) {
            $wid = 16;
        } elsif (@$elm[T_TYPE] =~ /int/) {
            $wid = 32;
        }
    }
    if (@$elm[T_ARRAY] eq "") {
        if (@$elm[T_WID] eq "b") {
            print OUT $tab x2, "if (mCov_" . $var_name . " == 1 && vCov_" . $var_name . " == 0)\n";
            print OUT $tab x3, "int dummy_for_gcov_toggle = 1; // 1->0\n";
            print OUT $tab x2, "if (mCov_" . $var_name . " == 0 && vCov_" . $var_name . " == 1)\n";
            print OUT $tab x3, "int dummy_for_gcov_toggle = 1; // 0->1\n";
        }
        else {
            for (my $i=0; $i<$wid; $i++) {
                my $mname = "mCov_$var_name.range($i,$i)";
                my $vname = "vCov_$var_name.range($i,$i)";
                if ($type eq "" ) {
                    $mname = " ((mCov_$var_name >> $i) & 0x1)";
                    $vname = " ((vCov_$var_name >> $i) & 0x1)";
                }
                print OUT $tab x2, "if ($mname == 1 && $vname == 0)\n";
                print OUT $tab x3, "int dummy_for_gcov_toggle = 1; // 1->0\n";
                print OUT $tab x2, "if ($mname == 0 && $vname == 1)\n";
                print OUT $tab x3, "int dummy_for_gcov_toggle = 1; // 0->1\n";
            }
        }
    } else {
        my $name = @$elm[T_NAME];
        my @dim = ();
        my $max = 1;
        while (@$elm[T_ARRAY] =~ /\w+/g) {
            &get_array_info(\@dim, $&);
        }
        foreach my $i (@dim) {
            $max *= $i;
        }
        my @mod = ();
        my $val = $max;
        foreach my $i (@dim) {
            $val /= $i;
            push(@mod, $val);
        }
        for (my $i = 0; $i < @dim; $i++) {
            $name = $name . "[i$i]";
        }
        for (my $i = 0; $i < $max; $i++) {
            my $iname = $var_name;
            for (my $j = 0; $j < @mod; $j++) {
                $iname .= "[" . int($i / $mod[$j]) % $dim[$j] . "]";
            }
            #print OUT "\n";
            #print OUT $tab x2, "vCov_${iname} = ${iname}.read();\n";
            if (@$elm[T_WID] eq "b") {
                print OUT $tab x2, "if (mCov_" . $iname . " == 1 && vCov_" . $iname . " == 0)\n"; 
                print OUT $tab x3, "int dummy_for_gcov_toggle = 1; // 1->0\n";
                print OUT $tab x2, "if (mCov_" . $iname . " == 0 && vCov_" . $iname . " == 1)\n";
                print OUT $tab x3, "int dummy_for_gcov_toggle = 1; // 0->1\n";
            }
            else {
                for (my $w=0; $w<$wid; $w++) {
                    my $mname = "mCov_$iname.range($w,$w)";
                    my $vname = "vCov_$iname.range($w,$w)";
                    if ($type eq "" ) {
                        $mname = " ((mCov_$iname >> $w) & 0x1)";
                        $vname = " ((vCov_$iname >> $w) & 0x1)";
                    }
                    print OUT $tab x2, "if ($mname == 1 && $vname == 0)\n";
                    print OUT $tab x3, "int dummy_for_gcov_toggle = 1; // 1->0\n";
                    print OUT $tab x2, "if ($mname == 0 && $vname == 1)\n";
                    print OUT $tab x3, "int dummy_for_gcov_toggle = 1; // 0->1\n";
                }
            }
        }
    }
}

##
## print toggle check function
##   OUT       : file pointer
##
sub print_toggle_check_func {
    local(*OUT) = $_[0];

    if (($top_mode == 1 || @thread_list != 0) && $toggle_cov_mode != 0) {
        print OUT "\n";
        print OUT $tab, "void check_toggle() {\n";
        print OUT "#ifdef $cov_macro\n";
        my $init = 1;
        foreach $elm (@in_list, @out_list, @in_list_sync, @out_list_sync) {
            my $wid  = (@$elm[T_WID] eq "b") ? @$elm[T_WID] : &get_macro_value(@$elm[T_WID], "", 0);
            my $type = @$elm[T_TYPE];
            next if ($top_mode == 1 && @$elm[T_INST] ne $mod_inst);
            next if ($type =~ /in/ && $toggle_cov_mode != 1 && $toggle_cov_mode != 2);
            next if ($type =~ /out/ && $toggle_cov_mode != 1 && $toggle_cov_mode != 3);
            if (@$elm[T_WID] eq "b") {
                $type = "bool";
            }
            else {
                $type = &get_sctype(($type =~ /^u/) ? 0 : 1, @$elm[T_WID]);
            }
            print OUT "\n" if ($init == 0);
            $init = 0;
            if (@$elm[T_ARRAY] eq "") {
                print OUT $tab x2, $type . " vCov_" . @$elm[T_NAME] . " = ";
                print OUT @$elm[T_NAME] . ".read();\n";
                if (&is_struct(@$elm[T_WID])) {
                    foreach my $st (@struct_list) {
                        my $struct_name = @$st[STR_NAME];
                        if (@$elm[T_WID] eq $struct_name) {
                            my $struct_mem = @$st[STR_VAR];
                            foreach $var (@$struct_mem) {
                                my $mem_name = @$var[T_NAME];
                                &print_toggle_check_func_elm(*OUT, $var, @$elm[T_NAME]);
                            }
                            last;
                        }
                    }
                } else {
                    &print_toggle_check_func_elm(*OUT, $elm, "");
                }
            }
            else {
                my $name = @$elm[T_NAME];
                my @dim = ();
                my $max = 1;
                while (@$elm[T_ARRAY] =~ /\w+/g) {
                    &get_array_info(\@dim, $&);
                }
                foreach $i (@dim) {
                    $max *= $i;
                }
                my @mod = ();
                my $val = $max;
                foreach $i (@dim) {
                    $val /= $i;
                    push(@mod, $val);
                }
                print OUT $tab x2, $type . " vCov_" . @$elm[T_NAME] . @$elm[T_ARRAY] . ";\n";
                for (my $i = 0; $i < @dim; $i++) {
                    print OUT $tab x($i+2), "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
                    $name = $name . "[i$i]";
                }
                print OUT $tab x(@dim + 2), "vCov_" . $name . " = " . $name . ".read();\n";
                for (my $i = @dim - 1; $i >= 0; $i--) {
                    print OUT $tab x($i+2), "}\n";
                }
                if (&is_struct(@$elm[T_WID])) {
                    my $struct_name = @$str[STR_NAME];
                    foreach my $st (@struct_list) {
                        my $struct_name = @$st[STR_NAME];
                        if (@$elm[T_WID] eq $struct_name) {
                            my $struct_mem = @$st[STR_VAR];
                            for (my $i = 0; $i < $max; $i++) {
                                my $iname = @$elm[T_NAME];
                                for (my $j = 0; $j < @mod; $j++) {
                                    $iname .= "[" . int($i / $mod[$j]) % $dim[$j] . "]";
                                }
                                foreach $var (@$struct_mem) {
                                    my $mem_name = @$var[T_NAME];
                                    &print_toggle_check_func_elm(*OUT, $var, $iname);
                                }
                            }
                            last;
                        }
                    }
                } else {
                    &print_toggle_check_func_elm(*OUT, $elm, "");
                }
            }
        }
        print OUT "#endif\n";
        print OUT $tab, "}\n";
    }
}

##
## print debug_trace data
##   OUT       : file pointer
##   $indent   : indent string
##   $thnm     : belonged thread name
##   $ptr_list : pointer of list
##
sub print_debug_trace_data {
    local(*OUT)  = $_[0];
    my $indent   = $_[1];
    my $thnm     = $_[2];
    my $ptr_list = $_[3];

    $indent = $indent . $tab;

    foreach $elm (@$ptr_list) {
        next if ($thnm ne "" && $thnm ne @$elm[T_TH]);
        next if (!(@$elm[T_FLG] & FLG_DTRACE));

        $name_dbg = @$elm[T_NAME];
        $name = $name_dbg;
        $name =~ s/_dbg$//;
        $array = @$elm[T_ARRAY];
        my @dim = ();
        my @num = ();

        if ($array eq "") {
            print OUT $indent, "$name_dbg.write($name);\n";
        }
        else {
            while ($array =~ /\w+/g) {
                push(@dim, $&);
            }
            while ($init =~ /[^\s\{\}\,]+/g) {
                push(@num, $&);
            }
            for ($i = 0; $i < @dim; $i++) {
                print OUT $indent, $tab x$i, "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
            }
            print OUT $indent, $tab x $i, "$name_dbg";
            for ($i = 0; $i < @dim; $i++) {
                print OUT "[i$i]";
            }
            print OUT ".write($name";
            for ($i = 0; $i < @dim; $i++) {
                print OUT "[i$i]";
            }
            print OUT ");\n";
            for ($i = @dim - 1; $i >= 0; $i--) {
                print OUT $indent, $tab x$i, "}\n";
            }
        }
    }
}

##
## print debug_trace function
##   OUT       : file pointer
##   $out_mode : print mode (= 0:header, 1:header-proto, 2:source)
##
sub print_debug_trace_func {
    local(*OUT) = $_[0];
    my $out_mode = $_[1];
    my $indent = $out_mode == 2 ? "" : $tab;

    foreach $th (@thread_list) {
        if (@$th[TH_FLG] & FLG_DTRACE) {
            print OUT "\n";
            print OUT $indent, "void ";
            if ($out_mode == 2) {
                print OUT $module_name, "::";
            }
            print OUT "debug_trace";
            print OUT "_@$th[TH_NAME]" if (@thread_list > 1);
            print OUT "()";
            print OUT ($out_mode == 1 ? ";" : " {"), "\n";
            if ($out_mode != 1) {
                foreach $m (@data_list_m) {
                    $macro = shift(@$m);
                    $find = 0;
                    foreach $elm (@$m) {
                        if (@$elm[T_FLG] & FLG_DTRACE) {
                            $find = 1;
                            last;
                        }
                    }
                    if ($find) {
                        print OUT "#ifdef $macro\n";
                        &print_debug_trace_data(*OUT, $indent, @$th[TH_NAME], \@$m);
                        print OUT "#endif\n";
                    }
                    unshift(@$m, $macro);
                }
                print OUT $indent, "}\n";
            }
        }
    }
}

##
## print slecbb function
##   OUT       : file pointer
##   $out_mode : print mode (= 0:header, 1:header-proto, 2:source)
##
sub print_slecbb_func {
    local(*OUT) = $_[0];
    my $out_mode = $_[1];
    my $indent = $out_mode == 2 ? "" : $tab;

    foreach $elm (@thread_list) {
        if (@$elm[TH_FLG] & FLG_SLECBB) {
            print OUT "\n";
            print OUT $indent, "void ";
            if ($out_mode == 2) {
                print OUT $module_name, "::";
            }
            print OUT "clear_bbox_out";
            print OUT "_@$elm[TH_NAME]" if (@thread_list > 1);
            print OUT "()";
            print OUT ($out_mode == 1 ? ";" : " {"), "\n";
            if ($out_mode != 1) {
                print OUT "#ifdef $slecbb_macro\n";
                &print_init_data(*OUT, $indent, @$elm[TH_NAME], \@out_list_slecbb);
                print OUT "#endif\n";
                print OUT $indent, "}\n";
            }
        }
    }
}

##
## print function for one list
##   OUT       : file pointer
##   $out_mode : print mode (= 0:header, 1:header-proto, 2:source)
##   $ptr_list : pointer of list
##   $prefix   : prefix string
##
##
sub print_func_one {
    local(*OUT) = $_[0];
    my $out_mode = $_[1];
    my $ptr_list = $_[2];
    my $prefix   = $_[3];
    my $indent = $out_mode == 2 ? "" : $tab;
    $prefix = "" unless defined($prefix);

    foreach $elm (@$ptr_list) {
        next if ($out_mode == 2 && (@$elm[F_FLG] & FLG_ONLY_DEF));
        $ret  = @$elm[F_RET];
        $body = @$elm[F_NAME] . @$elm[F_BODY];

        print OUT "\n";
        if (@$elm[F_COM] ne "") {
            print OUT $indent, &comment(@$elm[F_COM]);
        }
        if ($out_mode == 1) {
            print OUT $indent, "#pragma ctos dont_touch\n" if (@$elm[F_FLG] & FLG_DONT_TOUCH);
            print OUT $indent, $ret, " ", $body, ";\n"
        }
        else {
            print OUT $indent, $ret, " ";
            if ($out_mode  == 2) {
                print OUT $prefix, $module_name, "::";
            }
            print OUT $body, " {\n";
            if (@$elm[F_FLG] & (FLG_SLECBB | FLG_N_INLINE)) {
                print OUT $indent, $tab, "HLS_DPOPT_REGION(\"@$elm[F_NAME]\");"
            }
            print OUT $indent, $tab, "// please write here!\n";
            if ($ret ne "void") {
                if (&is_struct($ret) == 1) {
                    print OUT $indent, $tab, $ret, " rtn;\n";
                } else {
                    print OUT $indent, $tab, $ret, " rtn = 0;\n";
                }
                print OUT $indent, $tab, "return rtn;\n";
            }
            print OUT $indent, "}\n";
        }
    }
}

##
## print function
##   OUT : file pointer
##
sub print_func {
    local(*OUT) = $_[0];

    # common
    if (@func_list > 0) {
        &print_func_one($_[0], $_[1], \@func_list);
    }

    # sim
    foreach $m (@func_list_m) {
        $macro = shift(@$m);
        print OUT "\n#ifdef $macro";
        &print_func_one($_[0], $_[1], \@$m);
        print OUT "#endif\n";
        unshift(@$m, $macro);
    }
}

##
## print free area
##   OUT   : file pointer
##   $part : part flag (0:DUT, 1:TB)
##
sub print_free_area {
    local(*OUT) = $_[0];
    my $part = $_[1];

    if ($part == 0) {
        if (@free_area_list > 0) {
            print OUT "\n";
            foreach $elm (@free_area_list) {
                print OUT $tab, "$elm\n";
            }
        }
        foreach $m (@free_area_list_m) {
            $macro = shift(@$m);
            print OUT "\n#ifdef $macro\n";
            foreach $elm (@$m) {
                print OUT $tab, "$elm\n";
            }
            print OUT "#endif\n";
            unshift(@$m, $macro);
        }
    }
    else {
        if (@free_area_list_tb > 0) {
            print OUT "\n";
            foreach $elm (@free_area_list_tb) {
                print OUT $tab, "$elm\n";
            }
        }
    }
}

##
## print declaration data for testbench
##
sub print_tb_decl_data {
    if (@reg_list_tb > 0 || @var_list_tb > 0 || @ctype_list_tb > 0) {
        print OUT_TB_H "\n";
        print_decl_data_one(*OUT_TB_H, \@reg_list_tb);
        print_decl_data_one(*OUT_TB_H, \@var_list_tb);
        print_decl_data_one(*OUT_TB_H, \@ctype_list_tb);
    }
}

##
## print constructor of in/out port of testbench
##  $mode: 0: normal in/out, 1: struct in/out  2: rtl in/out
##
sub print_tb_constructor_in_port {
    my $elm = $_[0];
    my $out_mode = $_[1];

    my $name = @$elm[T_NAME];
    if (($name ne "") && (@$elm[T_ARRAY] eq "")) {
        if (@$elm[T_FLG] & FLG_STR_TYPE) {
            print OUT_TB_H "#ifndef _MODE_RTL\n" if ($out_mode == 0);
            print OUT_TB_H $tab x2, ",";
            print OUT_TB_H " $name(\"$name\")\n";
            print OUT_TB_H "#else\n" if ($out_mode == 0);
            my @rtl_port;
            &get_rtl_port(\@rtl_port, $elm);
            foreach my $e (@rtl_port) {
                $name = @$e[T_NAME];
                $name =~ s/://g;
                print OUT_TB_H $tab x2, ",";
                print OUT_TB_H " $name(\"$name\")\n";
            }
            print OUT_TB_H "#endif\n" if ($out_mode == 0);
        } else {
            print OUT_TB_H $tab x2, ",";
            print OUT_TB_H " $name(\"$name\")\n";
        }
    }
}

##
## print constructor of out port of testbench
##  $elm: port
##
sub print_tb_constructor_out_port {
    my $elm = $_[0];
    my $out_mode = $_[1];

    my $name = @$elm[T_NAME];
    if (($name ne "") && (@$elm[T_ARRAY] eq "")) {
        if (@$elm[T_FLG] & FLG_STR_TYPE) {
            if ($out_mode == 0) {
                print OUT_TB_H "#ifndef _MODE_RTL\n";
                print OUT_TB_H $tab x2, ",";
                print OUT_TB_H " $name(\"$name\")\n";
                print OUT_TB_H "#else\n";
            }
            else {
                print OUT_TB_H $tab x2, ",";
                print OUT_TB_H " ${name}_s(\"${name}_s\")\n";
            }
            my @rtl_port;
            &get_rtl_port(\@rtl_port, $elm);
            foreach my $e (@rtl_port) {
                $name = @$e[T_NAME];
                $name =~ s/://g;
                if ($out_mode == 0) {
                    print OUT_TB_H $tab x2, ",";
                    print OUT_TB_H " $name(\"$name\")\n";
                }
                else {
                    print OUT_TB_H $tab x2, ",";
                    print OUT_TB_H " ${name}_r(\"${name}_r\")\n";
                }
            }
            print OUT_TB_H "#endif\n" if ($out_mode == 0);
        } else {
            if ($out_mode == 0) {
                print OUT_TB_H $tab x2, ",";
                print OUT_TB_H " $name(\"$name\")\n";
            }
            else {
                print OUT_TB_H $tab x2, ",";
                print OUT_TB_H " ${name}_s(\"${name}_s\")\n";
                print OUT_TB_H $tab x2, ",";
                print OUT_TB_H " ${name}_r(\"${name}_r\")\n";
            }
        }
    }
}

##
## print constructor for testbench
##   $out_mode : print mode (= 0: ocsi/vcs/ies, 1: sim_eq)
##
sub print_tb_constructor {
    $out_mode = $_[0];
    $postfix = ($out_mode == 0) ? "" : "_eq";
    $init = 0;
    print OUT_TB_H "\n";
    if ($style_module eq "sc") {
        print OUT_TB_H $tab, "SC_CTOR(tb_$module_name$postfix)\n";
    }
    else {
        print OUT_TB_H $tab, "SC_HAS_PROCESS(tb_$module_name$postfix);\n";
        print OUT_TB_H $tab, "tb_$module_name(sc_module_name nm)\n";
        print OUT_TB_H $tab x2, ": sc_module(nm)\n";
        $init = 1;
    }

    # initialization list
    foreach $elm (@clk_list) {
        if (@$elm[T_NAME] ne "") {
            print OUT_TB_H $tab x2, ($init == 0) ? ":" : ",";
            $init = 1;
            print OUT_TB_H " @$elm[T_NAME](\"@$elm[T_NAME]\")\n";
        }
    }
    foreach $elm (@rst_list) {
        if ((@$elm[T_TYPE] ne "soft_reset") && (@$elm[T_NAME] ne "")) {
            print OUT_TB_H $tab x2, ",";
            print OUT_TB_H " @$elm[T_NAME](\"@$elm[T_NAME]\")\n";
        }
    }
    foreach $elm (@in_list) {
        &print_tb_constructor_in_port($elm, $out_mode);
    }
    foreach $elm (@out_list) {
        &print_tb_constructor_out_port($elm, $out_mode);
    }
    if ($top_mode == 1) {
        # insert_port
        foreach $elm (@in_list_insert) {
            if ((@$elm[T_NAME] ne "") && (@$elm[T_ARRAY] eq "")) {
                print OUT_TB_H $tab x2, ",";
                print OUT_TB_H " @$elm[T_NAME](\"@$elm[T_NAME]\")\n";
            }
        }
        foreach $elm (@out_list_insert) {
            if (@$elm[T_NAME] ne "" && @$elm[T_ARRAY] eq "") {
                if ($out_mode == 0) {
                    print OUT_TB_H $tab x2, ",";
                    print OUT_TB_H " @$elm[T_NAME](\"@$elm[T_NAME]\")\n";
                }
                else {
                    print OUT_TB_H $tab x2, ",";
                    print OUT_TB_H " @$elm[T_NAME]_s(\"@$elm[T_NAME]_s\")\n";
                    print OUT_TB_H $tab x2, ",";
                    print OUT_TB_H " @$elm[T_NAME]_r(\"@$elm[T_NAME]_r\")\n";
                }
            }
        }
    }
    if ($out_mode == 0) {
        foreach $elm (@reg_list_tb) {
            if (@$elm[T_ARRAY] eq "") {
                print OUT_TB_H $tab x2, ",";
                print OUT_TB_H " @$elm[T_NAME](\"@$elm[T_NAME]\")\n";
            }
        }

        &print_tb_memory_init_name;

        print OUT_TB_H $tab x2, ", m_tf(NULL)\n";
    }
    print OUT_TB_H $tab, "{\n";

    # SC_CTHREAD
    &get_valid_clock(\$clk_data);
    print OUT_TB_H $tab x2;
    print OUT_TB_H "SC_CTHREAD(thread_main, @$clk_data[T_NAME].pos());\n";
    if ($out_mode == 1) {
        print OUT_TB_H $tab x2;
        print OUT_TB_H "SC_CTHREAD(thread_monitor, @$clk_data[T_NAME].pos());\n";
    }

    if ($out_mode == 0) {
        # SC_METHOD for memory addr shift for sim
        my $start = 1;
        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 1);
            if (@$elm[M_SHARE] == 0) {
                if (@$elm[M_PONLY] == 0 && @$elm[M_RW] != MA_RW1) {
                    print OUT_TB_H "\n" if ($start == 1);
                    print OUT_TB_H $tab x2, "MEM_PIPE";
                    print OUT_TB_H "_2R" if (@$elm[M_RW] == MA_R1W1_W || @$elm[M_RW] == MA_RW1_W);
                    print OUT_TB_H "_CTOR(@$elm[M_NAME], ";
                    print OUT_TB_H (@$elm[M_RW] == MA_R1W1_W || @$elm[M_RW] == MA_RW1_W) ? @$elm[M_CLKR] : @$elm[M_CLKW];
                    print OUT_TB_H ")";
                    print OUT_TB_H " // SC_METHOD for pipeline function for array access\n";
                    $start = 0;
                }
            }
        }
    }
    print OUT_TB_H $tab, "}\n";
}

##
## print reset function for testbench
##   $out_mode : print mode (= 0: ocsi/vcs/ies, 1: sim_eq)
##
sub print_tb_reset_func {
    $out_mode = $_[0];
    print OUT_TB_H "\n";
    print OUT_TB_H $tab, "void reset_function() {\n";

    # reset
    foreach $elm (@rst_list) {
        if (@$elm[T_TYPE] ne "soft_reset" && @$elm[T_NAME] ne "") {
            print OUT_TB_H $tab x2, "@$elm[T_NAME].write(";
            print OUT_TB_H @$elm[T_INIT] eq "pos" ? "1" : "0", ");\n";
        }
    }

    # port and data
    &print_init_data(*OUT_TB_H, $tab, "", \@in_list, 0, 1);
    if ($top_mode == 1) {
        # insert_port
        &print_init_data(*OUT_TB_H, $tab, "", \@in_list_insert);
    }
    if ($out_mode == 0) {
        &print_init_data(*OUT_TB_H, $tab, "", \@reg_list_tb);
        &print_init_data(*OUT_TB_H, $tab, "", \@var_list_tb);
        &print_init_data(*OUT_TB_H, $tab, "", \@ctype_list_tb);

        # mem
        &print_tb_memory_init;
    }

    print OUT_TB_H $tab, "}\n"
}

##
## print constructor for synchronizer module
##
sub print_sync_constructor {
    $init = 0;
    print OUT_SYNC_H "\n";
    if ($style_module eq "sc") {
        print OUT_SYNC_H $tab, "SC_CTOR($mod_name)\n";
    }
    else {
        print OUT_SYNC_H $tab, "SC_HAS_PROCESS($mod_name);\n";
        print OUT_SYNC_H $tab, "$mod(sc_mod nm)\n";
        print OUT_SYNC_H $tab x2, ": sc_module(nm)\n";
        $init = 1;
    }

    # initialization list
    for ($i = 0; $i < 2; $i++) {
        if ($i == 0 || $use_rx_thread) {
            print OUT_SYNC_H $tab x2, ($i == 0 && $init == 0) ? ":" : ",";
            print OUT_SYNC_H " $clk_name[$i](\"$clk_name[$i]\")\n";
            $init = 1;
        }
    }
    for ($i = 0; $i < 2; $i++) {
        if ($rst_name[$i] ne "" && ($i == 0 || $use_rx_thread)) {
            print OUT_SYNC_H $tab x2, ",";
            print OUT_SYNC_H " $rst_name[$i](\"$rst_name[$i]\")\n";
        }
    }
    foreach $elm (@in_list_sync) {
        if ((@$elm[T_NAME] ne "") && @$elm[T_ARRAY] eq "" && @$elm[T_INST] eq $mod_inst) {
            print OUT_SYNC_H $tab x2, ",";
            print OUT_SYNC_H " @$elm[T_NAME](\"@$elm[T_NAME]\")\n";
        }
    }
    foreach $elm (@out_list_sync) {
        if (@$elm[T_NAME] ne "" && @$elm[T_ARRAY] eq "" && @$elm[T_INST] eq $mod_inst) {
            print OUT_SYNC_H $tab x2, ",";
            print OUT_SYNC_H " @$elm[T_NAME](\"@$elm[T_NAME]\")\n";
        }
    }
    foreach $elm (@reg_list_sync) {
        if (@$elm[T_NAME] ne "" && @$elm[T_ARRAY] eq "" && @$elm[T_INST] eq $mod_inst) {
            print OUT_SYNC_H $tab x2, ",";
            print OUT_SYNC_H " @$elm[T_NAME](\"@$elm[T_NAME]\")\n";
        }
    }
    if ($rst_type[0] eq "areset" || ($rst_type[1] eq "areset" && $use_rx_thread)) {
        print OUT_SYNC_H "#ifdef $osci_macro\n";
        if ($mod_dbg eq "") {
            print OUT_SYNC_H $tab x2, ",";
            print OUT_SYNC_H " ssgen_merge_rst_main_thread(\"ssgen_merge_rst_main_thread\")\n";
        }
        else {
            for (my $i=0; $i<2; $i++) {
                if ($i == 0 || $use_rx_thread) {
                    my $j = (@rst_type == 1) ? 0 : $i;
                    if ($rst_type[$j] eq "areset") {
                        print OUT_SYNC_H $tab x2, ",";
                        print OUT_SYNC_H " ssgen_merge_rst_" . $clk_name[$i] . "_thread";
                        print OUT_SYNC_H "(\"ssgen_merge_rst_" . $clk_name[$i] . "_thread\")\n";
                    }
                }
            }
        }
        print OUT_SYNC_H "#endif\n";
    }

    print OUT_SYNC_H $tab, "{\n";
    print OUT_SYNC_H "#ifndef _CTOS_TOP\n" if ($mod_dbg eq "");

    # SC_CTHREAD & SC_METHOD for ssgen merge rst
    for (my $i=0; $i<2; $i++) {
        if ($i == 0 || $use_rx_thread) {
            my $j = (@rst_name == 1) ? 0 : $i;
            print OUT_SYNC_H "\n" if ($i == 1);
            print OUT_SYNC_H $tab x2;
            print OUT_SYNC_H "SC_CTHREAD(", ($mod_dbg eq "") ? "main" : $clk_name[$i];
            print OUT_SYNC_H "_thread, $clk_name[$i].pos());\n";
            if ($rst_type[$j] eq "areset") {
                print OUT_SYNC_H "#ifndef $osci_macro\n";
                print OUT_SYNC_H $tab x2;
                print OUT_SYNC_H "async_reset_signal_is(";
                print OUT_SYNC_H $rst_name[$j], ", ",
                      ($rst_init[$j] eq "pos") ? "true" : "false", ");\n";
                print OUT_SYNC_H "#else\n";
                print OUT_SYNC_H $tab x2;
                print OUT_SYNC_H "reset_signal_is(ssgen_merge_rst_";
                print OUT_SYNC_H ($mod_dbg eq "") ? "main" : $clk_name[$i];
                print OUT_SYNC_H "_thread, true);\n";
                print OUT_SYNC_H "#endif\n";
                print OUT_SYNC_H "\n#ifdef $osci_macro\n";
                print OUT_SYNC_H $tab x2, "SC_METHOD(method_ssgen_merge_rst_";
                print OUT_SYNC_H ($mod_dbg eq "") ? "main" : $clk_name[$i];
                print OUT_SYNC_H "_thread);\n";
                print OUT_SYNC_H $tab x2, "sensitive\n";
                print OUT_SYNC_H $tab x2, " << $rst_name[$j]\n";
                print OUT_SYNC_H $tab x2, ";\n";
                print OUT_SYNC_H "#endif\n";
            }
            else {
                print OUT_SYNC_H $tab x2;
                print OUT_SYNC_H "reset_signal_is(";
                print OUT_SYNC_H $rst_name[$j], ", ",
                      ($rst_init[$j] eq "pos") ? "true" : "false", ");\n";
            }
        }
    }

    foreach $elm (@sync_list) {
        next if (@$elm[S_INST] ne $mod_inst);
        next if (!(@$elm[S_FLG] & FLG_SYNC_OUT) && !(@$elm[S_FLG] & FLG_SYNC_POS) &&
                 !(@$elm[S_FLG] & FLG_SYNC_NEG) && !(@$elm[S_FLG] & FLG_SYNC_TOG));
        next if (@$elm[S_FLG] & FLG_SYNC_EN);
        $name  = (@$elm[S_ONAME] eq "") ? @$elm[S_NAME] : @$elm[S_ONAME];
        $array = "";
        $sens  = "";
        foreach $in (@in_list_sync) {
            if (@$in[T_NAME] eq @$elm[S_INVAL] && @$in[T_INST] eq $mod_inst) {
                $array = @$in[T_ARRAY];
                $sens  = "sync_" . @$in[T_NAME];
                last;
            }
        }
        print OUT_SYNC_H "\n";
        print OUT_SYNC_H $tab x2, "SC_METHOD(" . $name . "_method);\n";
        print OUT_SYNC_H $tab x2, "sensitive\n";
        if ($array eq "") {
            print OUT_SYNC_H $tab x2, " << " . $sens . "_ff1\n";
            if ((@$elm[S_FLG] & FLG_SYNC_POS) || (@$elm[S_FLG] & FLG_SYNC_NEG) || (@$elm[S_FLG] & FLG_SYNC_TOG)) {
                print OUT_SYNC_H $tab x2, " << " . $sens . "_ff2\n";
            }
        }
        else {
            my @dim = ();
            while ($array =~ /\w+/g) {
                &get_array_info(\@dim, $&);
            }
            for ($i = 1; $i < 3; $i++) {
                if (($i == 1) || (@$elm[S_FLG] & FLG_SYNC_POS) || (@$elm[S_FLG] & FLG_SYNC_NEG) || (@$elm[S_FLG] & FLG_SYNC_TOG)) {
                    for ($j=0; $j<$dim[0]; $j++) {
                        if (@dim == 1) {
                            print OUT_SYNC_H $tab x2, " << " . $sens . "_ff" . $i . "[$j]\n";
                        }
                        else {
                            for ($k = 0; $k < $dim[1]; $k++) {
                                if (@dim == 2) {
                                    print OUT_SYNC_H $tab x2, " << " . $sens . "_ff" . $i . "[$j][$k]\n";
                                }
                                else {
                                    for ($l = 0; $l<$dim[2]; $l++) {
                                        print OUT_SYNC_H $tab x2, " << " . $sens . "_ff" . $i . "[$j][$k][$l]\n";
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        print OUT_SYNC_H $tab x2, ";\n";
    }

    print OUT_SYNC_H "#endif\n" if ($mod_dbg eq "");
    print OUT_SYNC_H $tab, "}\n";
}

##
## print cthread function for synchronizer module
##   OUT       : file pointer
##   $out_mode : print mode (= 0:header, 1:header-proto, 2:source)
##
sub print_sync_thread {
    local(*OUT) = $_[0];
    my $out_mode = $_[1];
    my $indent = $out_mode == 2 ? "" : $tab;
    #my $indent = $tab;

    print OUT "\n";
    print OUT $indent, "void ";
    if ($out_mode == 2) {
        print OUT $mod_name, "::";
    }
    print OUT "main_thread()";
    print OUT ($out_mode == 1 ? ";" : " {"), "\n";

    if ($out_mode != 1) {
        # reset
        print OUT $indent, $tab, "reset_main_thread();\n";

        print OUT $indent, $tab, "wait();\n";
        print OUT $indent, $tab, "while (1) {\n";

        # Toggle coverage
        if ($toggle_cov_mode != 0) {
            print OUT $indent, $tab x2, "check_toggle();\n";
            print OUT $indent, $tab x2, "prepare_toggle();\n";
        }

        # Bus transfer
        &print_sync_data(*OUT, 0);
        # 3-stage transfer
        &print_sync_data(*OUT, 1);
        # 2-stage transfer
        &print_sync_data(*OUT, 2);

        print OUT $indent, $tab x2, "wait();\n";
        print OUT $indent, $tab x1, "}\n";
        print OUT $indent,          "}\n";
    }
    else {
        print OUT "\n";
        print OUT $indent, "void reset_main_thread() {\n";
        &print_init_data(*OUT, $indent, "", \@out_list_sync);
        &print_init_data(*OUT, $indent, "", \@reg_list_sync);
        if ($mod_dbg eq "" && $toggle_cov_mode != 0) {
            foreach $m (@data_list_m) {
                $macro = shift(@$m);
                if ($macro eq $cov_macro) {
                    print OUT "#ifdef $macro\n";
                    &print_init_data(*OUT, $indent, "", \@$m);
                    print OUT "#endif\n";
                }
                unshift(@$m, $macro);
            }
        }
        print OUT $indent, "}\n";
    }
}

##
## print cthread functions for checker module
##
sub print_chk_thread {
    my $indent = $tab;

    # transmitter thread
    print OUT_SYNC_H "\n";
    print OUT_SYNC_H $tab, "void " . $clk_name[0] . "_thread() {\n";

    &print_init_data(*OUT_SYNC_H, $indent, $clk_name[0] . "_thread", \@reg_list_sync);

    print OUT_SYNC_H $indent, $tab, "wait();\n";
    print OUT_SYNC_H $indent, $tab, "while (1) {\n";

    print OUT_SYNC_H "#ifdef _CHK_SYNC\n";
    &print_chk_data(0);
    &print_chk_data(1);
    print OUT_SYNC_H "#endif // _CHK_SYNC\n";

    print OUT_SYNC_H $indent, $tab x2, "wait();\n";
    print OUT_SYNC_H $indent, $tab x1, "}\n";
    print OUT_SYNC_H $indent,          "}\n";

    # receiver thread
    if ($use_rx_thread) {
        print OUT_SYNC_H "\n";
        print OUT_SYNC_H $tab, "void " . $clk_name[1] . "_thread() {\n";

        &print_init_data(*OUT_SYNC_H, $indent, $clk_name[1] . "_thread", \@reg_list_sync);

        print OUT_SYNC_H $indent, $tab, "wait();\n";
        print OUT_SYNC_H $indent, $tab, "while (1) {\n";

        print OUT_SYNC_H "#ifdef _CHK_SYNC\n";
        &print_chk_data(2);
        &print_chk_data(3);
        print OUT_SYNC_H "#endif // _CHK_SYNC\n";

        print OUT_SYNC_H $indent, $tab x2, "wait();\n";
        print OUT_SYNC_H $indent, $tab x1, "}\n";
        print OUT_SYNC_H $indent, $tab x0, "}\n";
    }
}

#
# print method function for synchronizer module
##   OUT       : file pointer
##   $out_mode : print mode (= 0:header, 1:header-proto, 2:source)
#
sub print_sync_method {
    local(*OUT) = $_[0];
    my $out_mode = $_[1];
    my $indent = $out_mode == 2 ? "" : $tab;

    foreach $elm (@sync_list) {
        next if (@$elm[S_INST] ne $mod_inst);
        next if (!(@$elm[S_FLG] & FLG_SYNC_OUT) && !(@$elm[S_FLG] & FLG_SYNC_POS) &&
                 !(@$elm[S_FLG] & FLG_SYNC_NEG) && !(@$elm[S_FLG] & FLG_SYNC_TOG));
        next if (@$elm[S_FLG] & FLG_SYNC_EN);
        $name  = (@$elm[S_ONAME] eq "") ? @$elm[S_NAME] : @$elm[S_ONAME];
        $array = "";
        $sens  = "";
        foreach $in (@in_list_sync) {
            if (@$in[T_NAME] eq @$elm[S_INVAL] && @$in[T_INST] eq $mod_inst) {
                $array = @$in[T_ARRAY];
                $sens  = "sync_" . @$in[T_NAME];
                last;
            }
        }
        print OUT "\n";
        print OUT $indent, "void ";
        if ($out_mode == 2) {
            print OUT $mod_name, "::";
        }
        print OUT $name, "_method()";
        print OUT ($out_mode == 1 ? ";" : " {"), "\n";
        if ($out_mode != 1) {
            if ($array eq "") {
                print OUT $indent, $tab, $name;
                if (@$elm[S_FLG] & FLG_SYNC_POS) {
                    print OUT ".write( " . $sens . "_ff1.read()";
                    print OUT " && !"    . $sens . "_ff2.read()";
                    print OUT " );\n";
                }
                elsif (@$elm[S_FLG] & FLG_SYNC_NEG) {
                    print OUT ".write( !" . $sens . "_ff1.read()";
                    print OUT " && "      . $sens . "_ff2.read()";
                    print OUT " );\n";
                }
                elsif (@$elm[S_FLG] & FLG_SYNC_TOG) {
                    print OUT ".write( " . $sens . "_ff1.read()";
                    print OUT " ^ "      . $sens . "_ff2.read()";
                    print OUT " );\n";
                }
                else {
                    print OUT ".write( " . $sens . "_ff1.read() );\n";
                }
            }
            else {
                my @dim = ();
                while ($array =~ /\w+/g) {
                    push(@dim, $&);
                }
                for ($i = 0; $i < @dim; $i++) {
                    print OUT $indent, $tab x($i+1), "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
                }
                print OUT $indent, $tab x(@dim+1), $name;
                for ($i = 0; $i < @dim; $i++) {
                    print OUT "[i$i]";
                }
                if (@$elm[S_FLG] & FLG_SYNC_NEG) {
                    print OUT ".write( !" . $sens . "_ff1";
                }
                else {
                    print OUT ".write( " . $sens . "_ff1";
                }
                for ($i = 0; $i < @dim; $i++) {
                    print OUT "[i$i]";
                }
                print OUT ".read()";
                if ((@$elm[S_FLG] & FLG_SYNC_POS) || (@$elm[S_FLG] & FLG_SYNC_NEG) || (@$elm[S_FLG] & FLG_SYNC_TOG)) {
                    if (@$elm[S_FLG] & FLG_SYNC_POS) {
                        print OUT " && !" . $sens . "_ff2";
                    }
                    elsif (@$elm[S_FLG] & FLG_SYNC_NEG) {
                        print OUT " && " . $sens . "_ff2";
                    }
                    else {
                        print OUT " ^ " . $sens . "_ff2";
                    }
                    for ($i = 0; $i < @dim; $i++) {
                        print OUT "[i$i]";
                    }
                    print OUT ".read()";
                }
                print OUT " );\n";
                for ($i = @dim - 1; $i >= 0; $i--) {
                    print OUT $indent, $tab x($i+1), "}\n";
                }
            }
            print OUT $indent, "}\n";
        }
    }

    if ($out_mode != 2) {
        if ($rst_type[0] eq "areset" || ($rst_type[1] eq "areset" && $use_rx_thread)) {
            print OUT "\n#ifdef $osci_macro\n";
            for ($i=0; $i<2; $i++) {
                if ($i == 0 || $use_rx_thread) {
                    my $j = (@rst_type == 1) ? 0 : $i;
                    if ($rst_type[$j] eq "areset") {
                        print OUT "\n" if ($i == 1 && ($rst_type[0] eq $rst_type[1]));
                        print OUT $tab, "void method_ssgen_merge_rst_";
                        print OUT ($mod_dbg eq "") ? "main" : $clk_name[$i];
                        print OUT "_thread() {\n";
                        print OUT $tab x2, "ssgen_merge_rst_";
                        print OUT ($mod_dbg eq "") ? "main" : $clk_name[$i];
                        print OUT "_thread.write(";
                        print OUT "$rst_name[$j].read() == ";
                        print OUT ($rst_init[$j] eq "pos") ? "1" : "0", ");\n";
                        print OUT $tab, "}\n";
                    }
                }
            }
            print OUT "#endif\n";
        }
    }
}

##
## print VCD trace function for synchronizer module
##
sub print_sync_vcd_trace_func {
    print OUT_SYNC_H "\n";
    print OUT_SYNC_H "#if !defined(__CTOS__) && !defined(CALYPTO_SYSC) && !defined(STRATUS)\n"; #if ($mod_dbg eq "");
    print OUT_SYNC_H $tab, "void vcd_trace(";
    print OUT_SYNC_H $opt_standard ? "sc_trace_file" : "ssgen_trace_file";
    print OUT_SYNC_H "* tf, int depth = $hier_max) {\n";
    if ($vcd_trace == 1 || $vcd_trace == 2) {
        print OUT_SYNC_H $tab x2, "if (tf != 0 && depth > 0) {\n";
        print OUT_SYNC_H $tab x3, "std::string nm = std::string(name());\n";
        for ($i = 0; $i < 2; $i++) {
            if (($i == 0 || $use_rx_thread) && $vcd_trace == 1) {
                print OUT_SYNC_H $tab x3, "sc_trace(tf, $clk_name[$i], nm + \".$clk_name[$i]\");\n";
            }
        }
        for ($i = 0; $i < 2; $i++) {
            if ($rst_name[$i] ne "" && ($i == 0 || $use_rx_thread)) {
                print OUT_SYNC_H $tab x3, "sc_trace(tf, $rst_name[$i], nm + \".$rst_name[$i]\");\n";
            }
        }
        &print_sc_trace(*OUT_SYNC_H, \@in_list_sync);
        &print_sc_trace(*OUT_SYNC_H, \@out_list_sync);
        &print_sc_trace(*OUT_SYNC_H, \@reg_list_sync);
        print OUT_SYNC_H $tab x2, "}\n";
    }
    print OUT_SYNC_H $tab, "}\n";
    print OUT_SYNC_H "#endif // !defined(__CTOS__) && !defined(CALYPTO_SYSC) && !defined(STRATUS)\n"; #if ($mod_dbg eq "");
}

##
## print out/reg write for synchronizer module
##   OUT        : file pointer
##   $sync_type : synchronizer type (= 0:bus, 1:3-stage(posedge, negedge, toggle), 2:2-stage(level))
##
sub print_sync_data {
    local(*OUT) = $_[0];
    my $sync_type = $_[1];
    my $indent = $tab;

    foreach $elm (@sync_list) {
        next if (@$elm[S_INST] ne $mod_inst);
        if ($sync_type == 0) {
            next if (!(@$elm[S_FLG] & FLG_SYNC_EN));
        }
        elsif ($sync_type == 1) {
            next if ((@$elm[S_FLG] & FLG_SYNC_EN) || (@$elm[S_FLG] & FLG_SYNC_LVL));
        }
        else {
            next if ((@$elm[S_FLG] & FLG_SYNC_EN) || !(@$elm[S_FLG] & FLG_SYNC_LVL));
        }
        my $en_name  = "";
        my $reg_name = "";
        my $in_name  = "";
        my $array    = "";
        my $used_flg = 0;
        my @dim      = ();
        if ($sync_type == 0) {
            foreach $out (@out_list_sync) {
                next if (@$out[T_INST] ne $mod_inst || @$out[T_NAME] ne @$elm[S_NAME]);
                $en_name  = @$out[T_ENAME];
                $reg_name = @$out[T_NAME];
                $in_name  = @$elm[S_INVAL];
                $array    = @$out[T_ARRAY];
                last;
            }
        }
        else {
            foreach $in (@in_list_sync) {
                next if (@$in[T_NAME] eq "");
                if (@$in[T_NAME] eq @$elm[S_INVAL] && @$in[T_INST] eq @$elm[S_INST]) {
                    if (@$in[T_FLG] & FLG_USED) {
                        $used_flg = 1;
                    }
                    else {
                        @$in[T_FLG] |= FLG_USED;
                        $reg_name = "sync_" . @$elm[S_INVAL];
                        $in_name  = @$elm[S_INVAL];
                        $array    = @$in[T_ARRAY];
                    }
                    last;
                }
            }
        }
        if ($sync_type == 0 || $used_flg == 0) {
            #print OUT $tab x3, "if ( " . $en_name . ".read() )" if ($sync_type == 0);
            if ($sync_type == 0) {
                print OUT $indent, $tab, "if ( ";
                print OUT "!" if (@$elm[S_FLG] & FLG_ACTV_LOW);
                print OUT $en_name . ".read() )";
            }
            if ($array ne "") {
                while ($array =~ /\w+/g) {
                    push(@dim, $&);
                }
                print OUT " {\n" if ($sync_type == 0);
                for ($i = 0; $i < @dim; $i++) {
                    print OUT $indent, ($sync_type == 0) ? $tab x($i+2) : $tab x($i+1);
                    print OUT "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
                }
            }
            for ($cnt = 0; $cnt < 3; $cnt++) {
                my $reg = "";
                my $val = "";
                if ($cnt == 2) {
                    $reg = ($sync_type != 0) ? $reg_name . "_ff0" : $reg_name;
                    $val = $in_name;
                }
                elsif ($cnt == 1) {
                    $reg = ($sync_type != 0) ? $reg_name . "_ff1" : "";
                    $val = ($sync_type != 0) ? $reg_name . "_ff0" : "";
                }
                else {
                    $reg = ($sync_type == 1) ? $reg_name . "_ff2" : "";
                    $val = ($sync_type == 1) ? $reg_name . "_ff1" : "";
                }
                if ($reg ne "") {
                    if ($array eq "") {
                        print OUT "\n" if ($sync_type == 0);
                        print OUT $indent, ($sync_type == 0) ? $tab x2 : $tab x1;
                        print OUT $reg . ".write( " . $val . ".read() );\n";
                    }
                    else {
                        print OUT $indent, ($sync_type == 0) ? $tab x(@dim+2) : $tab x(@dim+1);
                        print OUT $reg;
                        for ($i = 0; $i < @dim; $i++) {
                            print OUT "[i$i]";
                        }
                        print OUT ".write( " . $val;
                        for ($i = 0; $i < @dim; $i++) {
                            print OUT "[i$i]";
                        }
                        print OUT ".read() );\n";
                    }
                }
            }
            if ($array ne "") {
                for ($i = @dim - 1; $i >= 0; $i--) {
                    print OUT $indent, ($sync_type == 0) ? $tab x($i+2) : $tab x($i+1);
                    print OUT "}\n";
                }
                print OUT $indent, $tab, "}\n" if ($sync_type == 0);
            }
        }
    }
}

##
## print assertion for checker module
##   $trans_type : transfer type (= 0:multi-bit tx, 1:single-bit tx, 2:multi-bit rx, 3:single-bit rx)
##
sub print_chk_data {
    my $trans_type = $_[0];

    foreach $elm (@in_list_sync) {
        next if (@$elm[T_NAME] eq "" || @$elm[T_INST] ne $mod_inst);
        next if (!(@$elm[T_FLG] & FLG_SYNC_EN) && ($trans_type == 0 || $trans_type == 2));
        next if ((@$elm[T_FLG] & FLG_SYNC_EN) && ($trans_type == 1 || $trans_type == 3));
        my $en_name  = @$elm[T_ENAME];
        my $in_name  = @$elm[T_NAME];
        my $array    = @$elm[T_ARRAY];
        my $idx      = "";
        my @dim      = ();
        my $indent   = $tab x3;

        if ($trans_type == 2) {
            if (@$elm[T_FLG] & FLG_SYNC_LVL) {
                print OUT_SYNC_H $indent, "if (";
                print OUT_SYNC_H "!" if (@$elm[T_FLG] & FLG_ACTV_LOW);
                print OUT_SYNC_H $en_name . ".read())";
            }
            elsif (@$elm[T_FLG] & FLG_SYNC_POS) {
                print OUT_SYNC_H $indent, "if ($en_name.read() && !$en_name\_$clk_name[1]\_ff0.read())";
            }
            elsif (@$elm[T_FLG] & FLG_SYNC_NEG) {
                print OUT_SYNC_H $indent, "if (!$en_name.read() && $en_name\_$clk_name[1]\_ff0.read())";
            }
            else {
                print OUT_SYNC_H $indent, "if (($en_name.read() ^ $en_name\_$clk_name[1]\_ff0.read()) == 1)";
            }
        }
        $find = 0;
        if ($trans_type == 3) {
            foreach $reg (@reg_list_sync) {
                next if (@$reg[T_INST] ne $mod_inst);
                next if (@$reg[T_TH] ne "$clk_name[1]_thread");
                if (@$reg[T_NAME] =~ /$in_name/) {
                    $find = 1;
                    last;
                }
            }
        }
        if ($array ne "" && ($trans_type != 3 || $find == 1)) {
            print OUT_SYNC_H " {\n" if ($trans_type == 2);
            while ($array =~ /\w+/g) {
                push(@dim, $&);
            }
            for ($i = 0; $i < @dim; $i++) {
                print OUT_SYNC_H $tab if ($trans_type == 2);
                print OUT_SYNC_H $tab x($i+3), "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
            }
            for ($i = 0; $i < @dim; $i++) {
                $idx .= "[i$i]";
            }
            $indent = $tab x (@dim + 3);
        }
        if ($trans_type == 0) {
            $en_name .= "_$clk_name[1]";
            print OUT_SYNC_H $indent, "$assert_macro(!(";
            print OUT_SYNC_H "($in_name$idx.read() != $in_name\_ff$idx.read()) &&\n";
            print OUT_SYNC_H $indent, "             ";
            if (@$elm[T_FLG] & FLG_SYNC_LVL) {
                if (@$elm[T_FLG] & FLG_ACTV_LOW) {
                    print OUT_SYNC_H "(!$en_name\_ff0.read() || !$en_name\_ff1.read())";
                }
                else {
                    print OUT_SYNC_H "($en_name\_ff0.read() || $en_name\_ff1.read())";
                }
            }
            elsif (@$elm[T_FLG] & FLG_SYNC_POS) {
                print OUT_SYNC_H "($en_name\_ff0.read() || $en_name\_ff1.read())";
            }
            elsif (@$elm[T_FLG] & FLG_SYNC_NEG) {
                print OUT_SYNC_H "(!$en_name\_ff0.read() || !$en_name\_ff1.read())";
            }
            else {
                print OUT_SYNC_H "(($en_name\_ff0.read() ^ $en_name\_ff1.read()) == 0)";
            }
            print OUT_SYNC_H "));\n";
        }
        elsif ($trans_type == 1) {
            print OUT_SYNC_H $indent, "$assert_macro(!(";
            print OUT_SYNC_H "($in_name$idx.read() == $in_name\_$clk_name[0]\_ff2$idx.read()) &&\n";
            print OUT_SYNC_H $indent, "               ";
            print OUT_SYNC_H "($in_name$idx.read() != $in_name\_$clk_name[0]\_ff0$idx.read()) &&\n";
            print OUT_SYNC_H $indent, "               ";
            print OUT_SYNC_H "($in_name\_$clk_name[0]\_ff0$idx.read() == $in_name\_$clk_name[0]\_ff1$idx.read())";
            print OUT_SYNC_H "));\n";
            print OUT_SYNC_H $indent, "$in_name\_$clk_name[0]\_ff2$idx.write($in_name\_$clk_name[0]\_ff1$idx.read());\n";
            print OUT_SYNC_H $indent, "$in_name\_$clk_name[0]\_ff1$idx.write($in_name\_$clk_name[0]\_ff0$idx.read());\n";
            print OUT_SYNC_H $indent, "$in_name\_$clk_name[0]\_ff0$idx.write($in_name$idx.read());\n";
        }
        elsif ($trans_type == 2) {
            print OUT_SYNC_H "\n" if ($array eq "");
            print OUT_SYNC_H $indent, $tab, "$in_name\_ff$idx.write($in_name$idx.read());\n";
        }
        else {
            if ($find == 1) {
                print OUT_SYNC_H $indent, "$in_name\_$clk_name[1]\_ff1$idx.write($in_name\_$clk_name[1]\_ff0$idx.read());\n";
                print OUT_SYNC_H $indent, "$in_name\_$clk_name[1]\_ff0$idx.write($in_name$idx.read());\n";
            }
        }
        if ($array ne "" && ($trans_type != 3 || $find == 1)) {
            for ($i = @dim - 1; $i >= 0; $i--) {
                print OUT_SYNC_H $tab if ($trans_type == 2);
                print OUT_SYNC_H $tab x($i+3), "}\n";
            }
            print OUT_SYNC_H $tab x3, "}\n" if ($trans_type == 2);
        }
    }
}

##
## print memeory negate macro for my_wait and cthread
##   OUT     : file pointer
##   $indent : indent string
##   $thnm   : belonged thread name
##
sub print_memory_neg {
    local(*OUT) = $_[0];
    my $indent = $_[1];
    my $thnm   = $_[2];

    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        if (@$elm[M_TH] eq $thnm) {
            if (@$elm[M_RW] == MA_RW1 || (@$elm[M_RW] & MA_DPORT)) {
                $type = "1";
            }
            elsif (@$elm[M_RW] == MA_R1W1_R || @$elm[M_RW] == MA_RW1_R) {
                if (@$elm[M_RW] == MA_R1W1_R) {
                    $type = "2R";
                }
                else {
                    $type = "1R";
                }
                if (@$elm[M_RE] == 0) {
                    next;
                }
            }
            elsif (@$elm[M_RW] == MA_R1W1_W || @$elm[M_RW] == MA_RW1_W) {
                if (@$elm[M_RW] == MA_R1W1_W) {
                    $type = "2W";
                }
                else {
                    $type = "1W";
                }
            }
            print OUT $indent, "MEM_NEG_$type";
            if (($type eq "2R" || $type eq "1R") || (($type eq "2W" || $type eq "1") && @$elm[M_CS] > 0)) {
                print OUT "_E";
            }
            print OUT "_P" if (@$elm[M_PONLY] == 1);
            print OUT "(@$elm[M_NAME], @$elm[M_OPRE], ";
            if ($type eq "2R" || $type eq "1R") {
                print OUT (@$elm[M_RE] == 2 ? "1" : "0");
            }
            else {
                print OUT (@$elm[M_WE] == 2 ? "1" : "0");
            }
            if (($type eq "2W" || $type eq "1") && @$elm[M_CS] > 0) {
                print OUT ", ", (@$elm[M_CS] == 2 ? "1" : "0");
            }
            if ($type eq "1") {
                if (@$elm[M_RW] & MA_DPORT) {
                    print OUT ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_WE : MPB_WE);
                    if (@$elm[M_CS] > 0) {
                        print OUT ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_CS : MPB_CS);
                    }
                }
                else {
                    print OUT ", ", &get_mem_suf(\@$elm, MP1_WE);
                    if (@$elm[M_CS] > 0) {
                        print OUT ", ", &get_mem_suf(\@$elm, MP1_CS);
                    }
                }
            }
            elsif ($type eq "1R") {
                print OUT ", ", &get_mem_suf(\@$elm, MP1_RE);
            }
            elsif ($type eq "1W") {
                print OUT ", ", &get_mem_suf(\@$elm, MP1_WE);
            }
            elsif ($type eq "2R") {
                print OUT ", ", &get_mem_suf(\@$elm, MP2_RE);
            }
            elsif ($type eq "2W") {
                print OUT ", ", &get_mem_suf(\@$elm, MP2_WE);
                if (@$elm[M_CS] > 0) {
                    print OUT ", ", &get_mem_suf(\@$elm, MP2_CS);
                }
            }
            print OUT ");";
            print OUT " // negate port: ";
            print OUT &get_macro_comment(\@$elm), "\n";
        }
    }
}

##
## print wait function for testbench
##   $out_mode : print mode (= 0: ocsi/vcs/ies, 1: sim_eq)
##
sub print_tb_wait_func {
    $out_mode = $_[0];
    print OUT_TB_H "\n";
    print OUT_TB_H $tab, "void $wait_name() {\n";
    foreach my $elm (@in_list) {
        next if (!(@$elm[T_FLG] & FLG_STR_TYPE) || @$elm[T_NAME] eq "");
        print OUT_TB_H "#ifndef _MODE_RTL\n";
        if (@$elm[T_ARRAY] ne "") {
            my @dim = ();
            my @num = ();
            my $str_tmp = "";   # array index to init value get from existed struct data
            my $array = @$elm[T_ARRAY];
            while ($array =~ /\w+/g) {
                push(@dim, $&);
            }
            for ($i = 0; $i < @dim; $i++) {
                print OUT_TB_H $tab, $tab x$i, $tab, "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
            }
            for ($i = 0; $i < @dim; $i++) {
                $str_tmp = "$str_tmp\[i$i\]";
            }
            print OUT_TB_H $tab, $tab x$i, $tab, "@$elm[T_NAME]$str_tmp.write(m_@$elm[T_NAME]$str_tmp);\n";
            for ($i = @dim - 1; $i >= 0; $i--) {
                print OUT_TB_H $tab, $tab x$i, $tab, "}\n";
            }
        } else {
            print OUT_TB_H $tab x2, "@$elm[T_NAME].write(m_@$elm[T_NAME]);\n";
        }
        print OUT_TB_H "#else\n";
        my @rtl_port;
        &get_rtl_port(\@rtl_port, $elm);
        foreach my $e (@rtl_port) {
            my @tmp = split (/:/, @$e[T_NAME]);
            my $s_inst_name = $tmp[0];
            my $s_mem_name  = $tmp[1];
            my $s_inst_array= $tmp[2];
            my $s_mem_array = $tmp[3];
            my $name = @$e[T_NAME];
            $name =~ s/://g;
            $s_mem_name =~ s/^_//;
            $s_inst_array   =~ s/(\A|_)(\d+)/[$2]/g; 
            $s_mem_array    =~ s/(\A|_)(\d+)/[$2]/g; 
            print OUT_TB_H $tab x2, "$name.write(m_$s_inst_name$s_inst_array.$s_mem_name$s_mem_array);\n";
        }
        print OUT_TB_H "#endif\n";
    }
    print OUT_TB_H $tab x2, "wait();\n";
    foreach my $elm (@out_list) {
        my $name = @$elm[T_NAME];
        next if (!(@$elm[T_FLG] & FLG_STR_TYPE) || @$elm[T_NAME] eq "");
        print OUT_TB_H "#ifndef _MODE_RTL\n";
        if (@$elm[T_ARRAY] ne "") {
            my @dim = ();
            my @num = ();
            my $str_tmp = "";   # array index to init value get from existed struct data
            my $array = @$elm[T_ARRAY];
            while ($array =~ /\w+/g) {
                push(@dim, $&);
            }
            for ($i = 0; $i < @dim; $i++) {
                print OUT_TB_H $tab, $tab x$i, $tab, "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
            }
            for ($i = 0; $i < @dim; $i++) {
                $str_tmp = "$str_tmp\[i$i\]";
            }
            print OUT_TB_H $tab, $tab x$i, $tab, "m_$name$str_tmp = $name$str_tmp.read();\n";
            for ($i = @dim - 1; $i >= 0; $i--) {
                print OUT_TB_H $tab, $tab x$i, $tab, "}\n";
            }
        } else {
            print OUT_TB_H $tab x2, "m_$name = $name.read();\n";
        }
        print OUT_TB_H "#else\n";
        my @rtl_port;
        &get_rtl_port(\@rtl_port, $elm);
        foreach my $e (@rtl_port) {
            my @tmp = split (/:/, @$e[T_NAME]);
            my $s_inst_name = $tmp[0];
            my $s_mem_name  = $tmp[1];
            my $s_inst_array= $tmp[2];
            my $s_mem_array = $tmp[3];
            my $name = @$e[T_NAME];
            $name =~ s/://g;
            $s_mem_name =~ s/^_//;
            $s_inst_array   =~ s/(\A|_)(\d+)/[$2]/g; 
            $s_mem_array    =~ s/(\A|_)(\d+)/[$2]/g; 
            print OUT_TB_H $tab x2, "m_$s_inst_name$s_inst_array.$s_mem_name$s_mem_array = $name.read();\n";
        }
        print OUT_TB_H "#endif\n";
    }

    if ($out_mode == 0) {
        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 1);
            if (@$elm[M_SHARE] == 0 && @$elm[M_RW] != MA_RW1) {
                # enable port
                if (@$elm[M_RW] == MA_R1W1_W || @$elm[M_RW] == MA_RW1_W) {
                    if (@$elm[M_RW] == MA_R1W1_W) {
                        print OUT_TB_H $tab x2, "MEM_NEG_2R_E";
                        print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                        print OUT_TB_H "(@$elm[M_NAME], @$elm[M_OPRE], 0";
                        print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_RE);
                    }
                    else {
                        print OUT_TB_H $tab x2, "MEM_NEG_1R_E";
                        print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                        print OUT_TB_H "(@$elm[M_NAME], @$elm[M_OPRE], 0";
                        print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_RE);
                    }
                }
                elsif (@$elm[M_RW] == MA_R1W1_R || @$elm[M_RW] == MA_RW1_R) {
                    if (@$elm[M_RW] == MA_R1W1_R) {
                        print OUT_TB_H $tab x2, "MEM_NEG_2W_E";
                        print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                        print OUT_TB_H "(@$elm[M_NAME], @$elm[M_OPRE], 0, 0";
                        print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_WE);
                        print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_CS);
                    }
                    else {
                        print OUT_TB_H $tab x2, "MEM_NEG_1W";
                        print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                        print OUT_TB_H "(@$elm[M_NAME], @$elm[M_OPRE], 0";
                        print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_WE);
                    }
                }
                elsif (@$elm[M_RW] & MA_DPORT) {
                    print OUT_TB_H $tab x2, "MEM_NEG_1_E";
                    print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                    print OUT_TB_H "(@$elm[M_NAME], @$elm[M_OPRE], 0, 0";
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_WE : MPA_WE);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_CS : MPA_CS);
                }
                print OUT_TB_H ");";
                print OUT_TB_H " // negate port\n";
            }
        }
    }
    print OUT_TB_H $tab, "}\n";
}

##
## print instances of memory and mem_interface in sc_main
##
sub print_main_memins {
    @mem_used = ();
    for ($i = 0; $i < @mem_list; $i++) {
        $elm = $mem_list[$i];
        next if(@$elm[M_FIX] == 1);
        my $skip = 0;
        foreach $used (@mem_used) {
            if ($used eq @$elm[M_NAME]) {
                $skip = 1;
                last;
            }
        }
        push(@mem_used, @$elm[M_NAME]);

        $elm2 = 0;
        if ((@$elm[M_RW] & MA_DPORT) && @$elm[M_SHARE] > 0) {
            for ($j = $i + 1; $j < @mem_list; $j++) {
                $pair = $mem_list[$j];
                next if(@$pair[M_FIX] == 1);
                if (@$elm[M_NAME] eq @$pair[M_NAME]) {
                    if (@$elm[M_RW] == MA_RW2_A) {
                        $elm2 = $pair;
                    }
                    else {
                        $elm2 = $elm;
                        $elm  = $pair;
                    }
                    last;
                }
            }
        }

        if ($skip == 0) {
            $init = @$elm[M_INIT];
            if ($init eq "") {
                $init = 0;
            }
            elsif ($init eq "rand") {
                $init = -1;
            }
            print OUT_MAIN "\n";
            print OUT_MAIN "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);
            if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                if ($top_mode == 0 || ($top_mode == 1 && @$elm[M_SHARE] == 0)) {
                    $ifnm = &get_mem_ifnm(\@$elm);
                    print OUT_MAIN $tab, "${ifnm} ";
                    if ($style_alloc eq "static") {
                        print OUT_MAIN "${ifnm}0(\"${ifnm}0\");\n";
                    }
                    else {
                        print OUT_MAIN "*${ifnm}0 = new $ifnm(\"${ifnm}0\");\n";
                    }
                }
            }
            #$size = &log2(@$elm[M_SIZE]);
            $size = &log2(&get_macro_value(@$elm[M_SIZE], "", 0));
            if (@$elm[M_RW] & MA_1PORT) {
                $memmod = "mem_rw1";
            }
            elsif (@$elm[M_RW] & MA_2PORT) {
                if (@$elm[M_CLKR] eq @$elm[M_CLKW]) {
                    if (@$elm[M_BE] > 0) {
                        $memmod = "mem_r1w1_be";
                    } else {
                        $memmod = "mem_r1w1";
                    }
                }
                else {
                    if (@$elm[M_BE] > 0) {
                        $memmod = "mem_r1w1_2clk_be";
                    } else {
                        $memmod = "mem_r1w1_2clk";
                    }
                }
            }
            else {
                $memmod = "mem_rw2";
            }

            print OUT_MAIN $tab, $memmod;
            print OUT_MAIN "<", &get_type("var", $size);
            print OUT_MAIN ", ";
            print OUT_MAIN &get_type(@$elm[M_SIGN] == 1 ? "svar" : "var", @$elm[M_WID]);
            if (@$elm[M_RW] & MA_R1W1_W) {
                if (@$elm[M_BE] > 0) {
                    print OUT_MAIN ", sc_uint<".(&get_macro_value(@$elm[M_WID], "", 0)>>3).">";
                }
            }
            print OUT_MAIN ", @$elm[M_LAT], ";
            if (@$elm[M_RW] == MA_RW2_B) {
                print OUT_MAIN "1, 1";
            }
            else {
                print OUT_MAIN (@$elm[M_WE] == 2 ? "0" : "1");
                print OUT_MAIN ", ", (@$elm[M_CS] == 2 ? "0" : "1");
                print OUT_MAIN ", ", (@$elm[M_RE] == 2 ? "0" : "1") if (@$elm[M_RW] & MA_2PORT);
            }
            if (@$elm[M_RW] & MA_DPORT) {
                if (@$elm[M_RW] == MA_RW2_B) {
                    print OUT_MAIN ", ", (@$elm[M_WE] == 2 ? "0" : "1");
                    print OUT_MAIN ", ", (@$elm[M_CS] == 2 ? "0" : "1");
                }
                elsif ($elm2) {
                    print OUT_MAIN ", ", (@$elm2[M_WE] == 2 ? "0" : "1");
                    print OUT_MAIN ", ", (@$elm2[M_CS] == 2 ? "0" : "1");
                }
                else {
                    print OUT_MAIN ", 1, 1";
                }
            }
            print OUT_MAIN ", ", @$elm[M_SIZE];
            if (@$elm[M_RW] & MA_R1W1_W) {
                if (@$elm[M_BE] > 0) {
                    print OUT_MAIN ", ", (@$elm[M_BE] == 2 ? "0" : "1");
                }
            }
            print OUT_MAIN "> @$elm[M_NAME](\"@$elm[M_NAME]\", ptr_@$elm[M_NAME], $init);\n";
            print OUT_MAIN "#endif\n" if (@$elm[M_PONLY] == 0);
        }
    }
}

##
## print signals of memory in sc_main
##
sub print_main_memsig {
    @mem_used = ();
    for ($i = 0; $i < @mem_list; $i++) {
        $elm = $mem_list[$i];
        next if(@$elm[M_FIX] == 1);
        my $skip = 0;
        foreach $used (@mem_used) {
            if ($used eq @$elm[M_NAME]) {
                $skip = 1;
                last;
            }
        }
        push(@mem_used, @$elm[M_NAME]);

        $elm2 = 0;
        if ((@$elm[M_RW] & MA_DPORT) && @$elm[M_SHARE] > 0) {
            for ($j = $i + 1; $j < @mem_list; $j++) {
                $pair = $mem_list[$j];
                next if(@$pair[M_FIX] == 1);
                if (@$elm[M_NAME] eq @$pair[M_NAME]) {
                    if (@$elm[M_RW] == MA_RW2_A) {
                        $elm2 = $pair;
                    }
                    else {
                        $elm2 = $elm;
                        $elm  = $pair;
                    }
                    last;
                }
            }
        }

        if ($skip == 0) {
            #$size = &log2(@$elm[M_SIZE]);
            $size = &log2(&get_macro_value(@$elm[M_SIZE], "", 0));
            print OUT_MAIN "\n";
            print OUT_MAIN "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);
            if (@$elm[M_RW] == MA_RW1) {
                print OUT_MAIN $tab, &get_type("ureg", $size);
                print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP1_AD), ";\n";
                print OUT_MAIN $tab, &get_type(@$elm[M_SIGN] == 1 ? "sreg" : "ureg", @$elm[M_WID]);
                print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP1_WD), ";\n";
                print OUT_MAIN $tab, &get_type(@$elm[M_SIGN] == 1 ? "sreg" : "ureg", @$elm[M_WID]);
                print OUT_MAIN  " ", &get_mem_portnm(\@$elm, MP1_RD), ";\n";
                print OUT_MAIN $tab, &get_type("ureg", "b");
                print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP1_WE), ";\n";
                print OUT_MAIN $tab, &get_type("ureg", "b");
                print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP1_CS), ";\n";
            }
            elsif (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                if (@$elm[M_SHARE] == 0) {
                    if (@$elm[M_RW] == MA_RW1_W) {
                        @$elm[M_RE] = 1;
                        @$elm[M_CS] = @$elm[M_RE];
                    }
                    else {
                        if (@$elm[M_RE] > 0) {
                            @$elm[M_CS] = @$elm[M_RE];
                        }
                    }
                }
                else {
                    if (@$elm[M_RE] == 2) {
                        @$elm[M_CS] = 2;
                    }
                }
                print OUT_MAIN $tab, &get_type("ureg", $size);
                print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP1_WA), ";\n";
                print OUT_MAIN $tab, &get_type(@$elm[M_SIGN] == 1 ? "sreg" : "ureg", @$elm[M_WID]);
                print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP1_WD), ";\n";
                print OUT_MAIN $tab, &get_type("ureg", "b");
                print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP1_WE), ";\n";
                print OUT_MAIN $tab, &get_type("ureg", $size);
                print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP1_RA), ";\n";
                print OUT_MAIN $tab, &get_type(@$elm[M_SIGN] == 1 ? "sreg" : "ureg", @$elm[M_WID]);
                print OUT_MAIN  " ", &get_mem_portnm(\@$elm, MP1_RD), ";\n";
                if (@$elm[M_RW] == MA_RW1_W || @$elm[M_RE] != 0) {
                    print OUT_MAIN $tab, &get_type("ureg", "b");
                    print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP1_RE), ";\n";
                }
                print OUT_MAIN $tab, &get_type("ureg", $size);
                print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP1_AD), ";\n";
                print OUT_MAIN $tab, &get_type("ureg", "b");
                print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP1_CS), ";\n";
            }
            elsif (@$elm[M_RW] & MA_2PORT) {
                print OUT_MAIN $tab, &get_type("ureg", $size);
                print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP2_WA), ";\n";
                print OUT_MAIN $tab, &get_type(@$elm[M_SIGN] == 1 ? "sreg" : "ureg", @$elm[M_WID]);
                print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP2_WD), ";\n";
                print OUT_MAIN $tab, &get_type("ureg", "b");
                print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP2_WE), ";\n";
                print OUT_MAIN $tab, &get_type("ureg", "b");
                print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP2_CS), ";\n";
                if (@$elm[M_RW] == MA_R1W1_W && @$elm[M_BE] != 0) {
                    print OUT_MAIN $tab, &get_type("ureg", (&get_macro_value(@$elm[M_WID], "", 0)>>3));
                                                          
                    print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP2_BE), ";\n";
                }
                print OUT_MAIN $tab, &get_type("ureg", $size);
                print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP2_RA), ";\n";
                print OUT_MAIN $tab, &get_type(@$elm[M_SIGN] == 1 ? "sreg" : "ureg", @$elm[M_WID]);
                print OUT_MAIN  " ", &get_mem_portnm(\@$elm, MP2_RD), ";\n";
                print OUT_MAIN $tab, &get_type("ureg", "b");
                print OUT_MAIN " ", &get_mem_portnm(\@$elm, MP2_RE), ";\n";
            }
            elsif (@$elm[M_RW] & MA_DPORT) {
                # A port
                $ptr = \@$elm;
                if (@$elm[M_RW] == MA_RW2_B) {
                    my @tmp = @$elm;
                    $tmp[M_WE] = $tmp[M_CS] = 0;
                    $ptr = \@tmp;
                }
                print OUT_MAIN $tab, &get_type("ureg", $size);
                print OUT_MAIN " ", &get_mem_portnm($ptr, MPA_AD), ";\n";
                print OUT_MAIN $tab, &get_type(@$ptr[M_SIGN] == 1 ? "sreg" : "ureg", @$ptr[M_WID]);
                print OUT_MAIN " ", &get_mem_portnm($ptr, MPA_WD), ";\n";
                print OUT_MAIN $tab, &get_type(@$ptr[M_SIGN] == 1 ? "sreg" : "ureg", @$ptr[M_WID]);
                print OUT_MAIN  " ", &get_mem_portnm($ptr, MPA_RD), ";\n";
                print OUT_MAIN $tab, &get_type("ureg", "b");
                print OUT_MAIN " ", &get_mem_portnm($ptr, MPA_WE), ";\n";
                print OUT_MAIN $tab, &get_type("ureg", "b");
                print OUT_MAIN " ", &get_mem_portnm($ptr, MPA_CS), ";\n";

                # B port
                if (@$elm[M_RW] == MA_RW2_B) {
                    $ptr = \@$elm;
                }
                elsif ($elm2) {
                    $ptr = \@$elm2;
                }
                else {
                    my @tmp = @$elm;
                    $tmp[M_WE] = $tmp[M_CS] = 0;
                    $ptr = \@tmp;
                }
                print OUT_MAIN $tab, &get_type("ureg", $size);
                print OUT_MAIN " ", &get_mem_portnm($ptr, MPB_AD), ";\n";
                print OUT_MAIN $tab, &get_type(@$ptr[M_SIGN] == 1 ? "sreg" : "ureg", @$ptr[M_WID]);
                print OUT_MAIN " ", &get_mem_portnm($ptr, MPB_WD), ";\n";
                print OUT_MAIN $tab, &get_type(@$ptr[M_SIGN] == 1 ? "sreg" : "ureg", @$ptr[M_WID]);
                print OUT_MAIN  " ", &get_mem_portnm($ptr, MPB_RD), ";\n";
                print OUT_MAIN $tab, &get_type("ureg", "b");
                print OUT_MAIN " ", &get_mem_portnm($ptr, MPB_WE), ";\n";
                print OUT_MAIN $tab, &get_type("ureg", "b");
                print OUT_MAIN " ", &get_mem_portnm($ptr, MPB_CS), ";\n";
            }

            print OUT_MAIN "#endif\n" if (@$elm[M_PONLY] == 0);
        }
    }
}

##
## print main binding port
##   $kind : kind flag (0:DUT, 1:TB, 2: SVA)
## 
sub print_main_bind_port {
    my $elm  = $_[0];
    my $kind = $_[1];
    my $inst = $_[2];
    my $a    = $_[3];

    my $name = @$elm[T_NAME];
    if (@$elm[T_FLG] & FLG_STR_TYPE) {
        return if ($kind == 2);
        print OUT_MAIN "#ifndef _MODE_RTL\n";
        if (@$elm[T_ARRAY] eq "") {
            print OUT_MAIN $tab, $inst, "$a$name($name);\n";
        }
        else {
            &print_bind_array($inst, $name, @$elm[T_ARRAY], 2);
        }
        print OUT_MAIN "#else\n";
        my @rtl_port;
        &get_rtl_port(\@rtl_port, $elm);
        foreach my $e (@rtl_port) {
            $name = @$e[T_NAME];
            $name =~ s/://g;
            print OUT_MAIN $tab, $inst, "$a$name($name);\n";
        }
        print OUT_MAIN "#endif\n";
    } else {
        if (@$elm[T_ARRAY] eq "") {
            print OUT_MAIN $tab, $inst, "$a$name($name);\n";
        }
        else {
            &print_bind_array($inst, $name, @$elm[T_ARRAY], $kind);
        }
    }
}

##
## print binding for dut/testbench/sva in sc_main
##   $kind : kind flag (0:DUT, 1:TB, 2: SVA)
##
sub print_main_bind {
    my $kind = $_[0]; # 0:dut, 1:tb, 2:sva
    $tb_mode = ($kind == 1) ? 1 : 0;
    my $inst = ($kind == 0) ? "${module_name}0" :
               ($kind == 1) ? "tb_${module_name}0" : "${module_name}_sva0";
    my $a = $style_alloc eq "static" ? "." : "->";

    # bind for clock
    foreach $elm (@clk_list) {
        if (@$elm[T_NAME] eq "ssgen_clk") {
            print OUT_MAIN $tab, $inst, "$a@$elm[T_NAME](@$elm[T_NAME]);\n" if ($kind == 1);
        }
        elsif (@$elm[T_NAME] ne "") {
            print OUT_MAIN $tab, $inst, "$a@$elm[T_NAME](@$elm[T_NAME]);\n";
        }
    }

    # bind for reset
    foreach $elm (@rst_list) {
        if (@$elm[T_TYPE] ne "soft_reset" && @$elm[T_NAME] ne "") {
            print OUT_MAIN $tab, $inst, "$a@$elm[T_NAME](@$elm[T_NAME]);\n";
        }
    }
    # bind for port
    foreach $elm (@in_list, @out_list) {
        if (@$elm[T_NAME] ne "") {
            &print_main_bind_port($elm, $kind, $inst, $a);
        }
    }

    # bind for insert_port
    if ($top_mode == 1) {
        foreach $elm (@in_list_insert, @out_list_insert) {
            if (@$elm[T_NAME] ne "") {
                if (@$elm[T_ARRAY] eq "") {
                    print OUT_MAIN $tab, $inst, "$a@$elm[T_NAME](@$elm[T_NAME]);\n";
                }
                else {
                    &print_bind_array($inst, @$elm[T_NAME], @$elm[T_ARRAY], $kind);
                }
            }
        }
    }

    # bind for memory
    if ($kind != 2) {
        @mem_used = ();
        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 1);
            my $skip = 0;
            foreach $used (@mem_used) {
                if ($used eq @$elm[M_NAME]) {
                    $skip = 1;
                    last;
                }
            }
            if ((@$elm[M_RW] == MA_RW1_W || @$elm[M_RW] == MA_RW1_R) && @$elm[M_SHARE] > 0) {
                push(@mem_used, @$elm[M_NAME]);
            }
            if ($skip == 0) {
                my $need_port = 0;
                if ($kind == 0) {
                    $need_port = 1;
                }
                elsif (@$elm[M_RW] != MA_RW1 && @$elm[M_SHARE] == 0) {
                    $need_port = 1;
                }
                if ($need_port) {
                    print OUT_MAIN "\n";
                    if (@$elm[M_PONLY] == 0) {
                        print OUT_MAIN "#ifdef $mem_macro\n";
                    }
                    if ((@$elm[M_RW] == MA_RW1)
                            || ((@$elm[M_RW] == MA_RW1_W || @$elm[M_RW] == MA_RW1_R) && @$elm[M_SHARE] > 0)) {
                        $port_nm = &get_mem_portnm(\@$elm, MP1_AD);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        $port_nm = &get_mem_portnm(\@$elm, MP1_WD);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        $port_nm = &get_mem_portnm(\@$elm, MP1_RD);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        $port_nm = &get_mem_portnm(\@$elm, MP1_WE);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        if ($kind == 1 || @$elm[M_CS] > 0) {
                            $port_nm = &get_mem_portnm(\@$elm, MP1_CS);
                            print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        }
                        if ($kind == 0 && @$elm[M_BE] > 0) {
                            $port_nm = &get_mem_portnm(\@$elm, MP2_BE);
                            print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        }
                    }
                    elsif (($kind == 0 && @$elm[M_RW] == MA_RW1_W && @$elm[M_SHARE] == 0)
                            || ($kind == 1 && @$elm[M_RW] == MA_RW1_R && @$elm[M_SHARE] == 0)) {
                        $port_nm = &get_mem_portnm(\@$elm, MP1_WA);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        $port_nm = &get_mem_portnm(\@$elm, MP1_WD);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        $port_nm = &get_mem_portnm(\@$elm, MP1_WE);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                    }
                    elsif (($kind == 0 && @$elm[M_RW] == MA_RW1_R && @$elm[M_SHARE] == 0)
                            || ($kind == 1 && @$elm[M_RW] == MA_RW1_W && @$elm[M_SHARE] == 0)) {
                        $port_nm = &get_mem_portnm(\@$elm, MP1_RA);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        $port_nm = &get_mem_portnm(\@$elm, MP1_RD);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        if ($kind == 1 || @$elm[M_RE] > 0) {
                            $port_nm = &get_mem_portnm(\@$elm, MP1_RE);
                            print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        }
                    }
                    elsif (($kind == 0 && @$elm[M_RW] == MA_R1W1_W)
                            || ($kind == 1 && @$elm[M_RW] == MA_R1W1_R)) {
                        $port_nm = &get_mem_portnm(\@$elm, MP2_WA);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        $port_nm = &get_mem_portnm(\@$elm, MP2_WD);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        $port_nm = &get_mem_portnm(\@$elm, MP2_WE);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        if ($kind == 1 || @$elm[M_CS] > 0) {
                            $port_nm = &get_mem_portnm(\@$elm, MP2_CS);
                            print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        }
                    }
                    elsif (($kind == 0 && @$elm[M_RW] == MA_R1W1_R)
                            || ($kind == 1 && @$elm[M_RW] == MA_R1W1_W)) {
                        $port_nm = &get_mem_portnm(\@$elm, MP2_RA);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        $port_nm = &get_mem_portnm(\@$elm, MP2_RD);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        if ($kind == 1 || @$elm[M_RE] > 0) {
                            $port_nm = &get_mem_portnm(\@$elm, MP2_RE);
                            print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        }
                    }
                    elsif (($kind == 0 && @$elm[M_RW] == MA_RW2_A)
                            || ($kind == 1 && @$elm[M_RW] == MA_RW2_B)) {
                        $port_nm = &get_mem_portnm(\@$elm, MPA_AD);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        $port_nm = &get_mem_portnm(\@$elm, MPA_WD);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        $port_nm = &get_mem_portnm(\@$elm, MPA_RD);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        $port_nm = &get_mem_portnm(\@$elm, MPA_WE);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        if ($kind == 1 || @$elm[M_CS] > 0) {
                            $port_nm = &get_mem_portnm(\@$elm, MPA_CS);
                            print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        }
                    }
                    elsif (($kind == 0 && @$elm[M_RW] == MA_RW2_B)
                            || ($kind == 1 && @$elm[M_RW] == MA_RW2_A)) {
                        $port_nm = &get_mem_portnm(\@$elm, MPB_AD);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        $port_nm = &get_mem_portnm(\@$elm, MPB_WD);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        $port_nm = &get_mem_portnm(\@$elm, MPB_RD);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        $port_nm = &get_mem_portnm(\@$elm, MPB_WE);
                        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        if ($kind == 1 || @$elm[M_CS] > 0) {
                            $port_nm = &get_mem_portnm(\@$elm, MPB_CS);
                            print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
                        }
                    }

                    if (@$elm[M_PONLY] == 0 && $need_port) {
                        print OUT_MAIN "#endif\n";
                    }
                }
            }
        }
    }
    $tb_mode = 0;
}

##
## print binding for aip/abvip in sc_main
##   $kind : kind flag (0:vcs/aip, 1:ies/abvip)
##
sub print_main_bind_vip {
    my $kind = $_[0];
    my $inst = $module_name . (($kind == 0) ? "_vcs" : "_ies") . "_apb_monitor0";
    my $a = $style_alloc eq "static" ? "." : "->";

    print OUT_MAIN $tab, $inst, $a, "PCLK(PCLK);\n";
    print OUT_MAIN $tab, $inst, $a, "PRESETn(PRESETn);\n";
    print OUT_MAIN $tab, $inst, $a, "PADDR(PADDR);\n";
    print OUT_MAIN $tab, $inst, $a, "PSEL(PSEL);\n";
    print OUT_MAIN $tab, $inst, $a, "PENABLE(PENABLE);\n";
    print OUT_MAIN $tab, $inst, $a, "PWRITE(PWRITE);\n";
    print OUT_MAIN $tab, $inst, $a, "PSTRB(PSTRB);\n" if ($kind == 1);
    print OUT_MAIN $tab, $inst, $a, "PWDATA(PWDATA);\n" if ($kind == 1);
    print OUT_MAIN $tab, $inst, $a, "PREADY(PREADY);\n";
    print OUT_MAIN $tab, $inst, $a, "PRDATA(PRDATA);\n";
}

##
## print binding for dut/clone/testbench in sc_main for sim_eq
##   $kind : 0: dut, 1: clone, 2: tb
##
sub print_main_bind_sim_eq {
    my $kind = $_[0];
    my $inst = ($kind == 0) ? "${module_name}0" :
               ($kind == 1) ? "${module_name}_eq0" : "tb_${module_name}_eq0";
    my $a = $style_alloc eq "static" ? "." : "->";

    # bind for clock
    foreach $elm (@clk_list) {
        if (@$elm[T_NAME] eq "ssgen_clk") {
            print OUT_MAIN $tab, $inst, "$a@$elm[T_NAME](@$elm[T_NAME]);\n" if ($kind == 1);
        }
        elsif (@$elm[T_NAME] ne "") {
            print OUT_MAIN $tab, $inst, "$a@$elm[T_NAME](@$elm[T_NAME]);\n";
        }
    }

    # bind for reset
    foreach $elm (@rst_list) {
        if (@$elm[T_TYPE] ne "soft_reset" && @$elm[T_NAME] ne "") {
            print OUT_MAIN $tab, $inst, "$a@$elm[T_NAME](@$elm[T_NAME]);\n";
        }
    }

    # bind for input ports
    @tmp_in_list = ($top_mode == 1) ? (@in_list, @in_list_insert) : @in_list;
    foreach $elm (@tmp_in_list) {
        if (@$elm[T_NAME] ne "") {
            if ((@$elm[T_FLG] & FLG_STR_TYPE) && $kind == 0) {
                my @rtl_port;
                &get_rtl_port(\@rtl_port, $elm);
                foreach my $e (@rtl_port) {
                    $name = @$e[T_NAME];
                    $name =~ s/://g;
                    print OUT_MAIN $tab, $inst, "$a$name($name);\n";
                }
            }
            elsif (@$elm[T_ARRAY] eq "") {
                print OUT_MAIN $tab, $inst, "$a@$elm[T_NAME](@$elm[T_NAME]);\n";
            }
            else {
                &print_bind_array_sim_eq($inst, @$elm[T_NAME], @$elm[T_NAME], @$elm[T_ARRAY], $kind == 0);
            }
        }
    }

    # bind for output ports
    @tmp_out_list = ($top_mode == 1) ? (@out_list, @out_list_insert) : @out_list;
    foreach $elm (@tmp_out_list) {
        if (@$elm[T_NAME] ne "") {
            if ((@$elm[T_FLG] & FLG_STR_TYPE) && $kind == 0) {
                my @rtl_port;
                &get_rtl_port(\@rtl_port, $elm);
                foreach my $e (@rtl_port) {
                    $name = @$e[T_NAME];
                    $name =~ s/://g;
                    print OUT_MAIN $tab, $inst, "$a$name(${name}_r);\n";
                }
            }
            elsif (@$elm[T_ARRAY] eq "") {
                if ($kind == 0) {
                    print OUT_MAIN $tab, $inst, "$a@$elm[T_NAME](@$elm[T_NAME]_r);\n";
                }
                elsif ($kind == 1) {
                    print OUT_MAIN $tab, $inst, "$a@$elm[T_NAME](@$elm[T_NAME]_s);\n";
                }
                else {
                    print OUT_MAIN $tab, $inst, "$a@$elm[T_NAME]_r(@$elm[T_NAME]_r);\n";
                    print OUT_MAIN $tab, $inst, "$a@$elm[T_NAME]_s(@$elm[T_NAME]_s);\n";
                }
            }
            else {
                if ($kind == 0) {
                    &print_bind_array_sim_eq($inst, @$elm[T_NAME], "@$elm[T_NAME]_r", @$elm[T_ARRAY], 1);
                }
                elsif ($kind == 1) {
                    &print_bind_array_sim_eq($inst, @$elm[T_NAME], "@$elm[T_NAME]_s", @$elm[T_ARRAY], 0);
                }
                else {
                    &print_bind_array_sim_eq($inst, "@$elm[T_NAME]_r", "@$elm[T_NAME]_r", @$elm[T_ARRAY], 0);
                    &print_bind_array_sim_eq($inst, "@$elm[T_NAME]_s", "@$elm[T_NAME]_s", @$elm[T_ARRAY], 0);
                }
            }
        }
    }

}

##
## print binding for mem interface in sc_main
##   $ifnm : interface name
##
sub print_main_memif_bind {
    my $ifnm = $_[0];
    my $inst = $ifnm . "0";
    my $a = $style_alloc eq "static" ? "." : "->";

    # bind for memory
    print OUT_MAIN "\n";
    if (@$elm[M_PONLY] == 0) {
        print OUT_MAIN "#ifdef $mem_macro\n";
    }
    $port_nm = &get_mem_portnm(\@$elm, MP1_WA);
    print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
    $port_nm = &get_mem_portnm(\@$elm, MP1_WE);
    print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
    $port_nm = &get_mem_portnm(\@$elm, MP1_RA);
    print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
    if (@$elm[M_RE] > 0) {
        $port_nm = &get_mem_portnm(\@$elm, MP1_RE);
        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
    }
    $port_nm = &get_mem_portnm(\@$elm, MP1_AD);
    print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
    if (@$elm[M_RE] > 0) {
        @$elm[M_CS] = @$elm[M_RE];
        $port_nm = &get_mem_portnm(\@$elm, MP1_CS);
        print OUT_MAIN $tab, $inst, "$a$port_nm($port_nm);\n";
    }
    if (@$elm[M_PONLY] == 0) {
        print OUT_MAIN "#endif\n";
    }
}

##
## print binding for memory in sc_main
##
sub print_main_membind {
    @mem_used = ();
    for ($i = 0; $i < @mem_list; $i++) {
        $elm = $mem_list[$i];
        next if(@$elm[M_FIX] == 1);
        my $skip = 0;
        foreach $used (@mem_used) {
            if ($used eq @$elm[M_NAME]) {
                $skip = 1;
                last;
            }
        }
        push(@mem_used, @$elm[M_NAME]);

        $elm2 = 0;
        if ((@$elm[M_RW] & MA_DPORT) && @$elm[M_SHARE] > 0) {
            for ($j = $i + 1; $j < @mem_list; $j++) {
                $pair = $mem_list[$j];
                next if(@$pair[M_FIX] == 1);
                if (@$elm[M_NAME] eq @$pair[M_NAME]) {
                    if (@$elm[M_RW] == MA_RW2_A) {
                        $elm2 = $pair;
                    }
                    else {
                        $elm2 = $elm;
                        $elm  = $pair;
                    }
                    last;
                }
            }
        }

        if ($skip == 0) {
            print OUT_MAIN "\n";
            print OUT_MAIN "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);
            # clock
            if (@$elm[M_RW] & MA_DPORT) {
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP_CLKA](@$elm[M_CLKR]);\n";
            }
            elsif (@$elm[M_CLKR] eq @$elm[M_CLKW]) {
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP_CLK](@$elm[M_CLKR]);\n";
            }
            else {
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP_CLKR](@$elm[M_CLKR]);\n";
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP_CLKW](@$elm[M_CLKW]);\n";
            }

            if (@$elm[M_RW] == MA_RW1) {
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP1_AD](",
                                    &get_mem_portnm(\@$elm, MP1_AD), ");\n";
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP1_WD](",
                                        &get_mem_portnm(\@$elm, MP1_WD), ");\n";
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP1_RD](",
                                        &get_mem_portnm(\@$elm, MP1_RD), ");\n";
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP1_WE](",
                                        &get_mem_portnm(\@$elm, MP1_WE), ");\n";
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP1_CS](",
                                        &get_mem_portnm(\@$elm, MP1_CS), ");\n";
                if (@$elm[M_CS] == 0) {
                    print OUT_MAIN $tab, &get_mem_portnm(\@$elm, MP1_CS), ".write(1);\n";
                }
            }
            elsif (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP1_AD](",
                                    &get_mem_portnm(\@$elm, MP1_AD), ");\n";
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP1_WD](",
                                        &get_mem_portnm(\@$elm, MP1_WD), ");\n";
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP1_RD](",
                                        &get_mem_portnm(\@$elm, MP1_RD), ");\n";
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP1_WE](",
                                        &get_mem_portnm(\@$elm, MP1_WE), ");\n";
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP1_CS](",
                                        &get_mem_portnm(\@$elm, MP1_CS), ");\n";
                if (@$elm[M_RW] & MA_R) {
                    if (@$elm[M_RE] == 0) {
                        print OUT_MAIN $tab, &get_mem_portnm(\@$elm, MP1_CS), ".write(1);\n";
                    }
                }
                else {
                    if (@$elm[M_SHARE] != 0 && @$elm[M_RE] == 0) {
                        print OUT_MAIN $tab, &get_mem_portnm(\@$elm, MP1_CS), ".write(1);\n";
                    }
                }
            }
            elsif (@$elm[M_RW] & MA_2PORT) {
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP2_WA](",
                                    &get_mem_portnm(\@$elm, MP2_WA), ");\n";
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP2_WD](",
                                        &get_mem_portnm(\@$elm, MP2_WD), ");\n";
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP2_WE](",
                                        &get_mem_portnm(\@$elm, MP2_WE), ");\n";
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP2_CS](",
                                        &get_mem_portnm(\@$elm, MP2_CS), ");\n";
                if (@$elm[M_RW] & MA_R1W1_W && @$elm[M_BE] > 0) {
                    print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP2_BE](",
                                            &get_mem_portnm(\@$elm, MP2_BE), ");\n";
                }

                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP2_RA](",
                                        &get_mem_portnm(\@$elm, MP2_RA), ");\n";
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP2_RD](",
                                        &get_mem_portnm(\@$elm, MP2_RD), ");\n";
                print OUT_MAIN $tab, @$elm[M_NAME], ".$suf_def[MP2_RE](",
                                        &get_mem_portnm(\@$elm, MP2_RE), ");\n";
                if (@$elm[M_RW] & MA_W) {
                    if (@$elm[M_CS] == 0) {
                        print OUT_MAIN $tab, &get_mem_portnm(\@$elm, MP2_CS), ".write(1);\n";
                    }
                    if (@$elm[M_SHARE] != 0 && @$elm[M_RE] == 0) {
                        print OUT_MAIN $tab, &get_mem_portnm(\@$elm, MP2_RE), ".write(1);\n";
                    }
                }
                else {
                    if (@$elm[M_RE] == 0) {
                        print OUT_MAIN $tab, &get_mem_portnm(\@$elm, MP2_RE), ".write(1);\n";
                    }
                    if (@$elm[M_SHARE] != 0 && @$elm[M_CS] == 0) {
                        print OUT_MAIN $tab, &get_mem_portnm(\@$elm, MP2_CS), ".write(1);\n";
                    }
                }
            }
            elsif (@$elm[M_RW] & MA_DPORT) {
                # A port
                $ptr = \@$elm;
                if (@$elm[M_RW] == MA_RW2_B) {
                    my @tmp = @$elm;
                    $tmp[M_WE] = $tmp[M_CS] = 0;
                    $ptr = \@tmp;
                }
                print OUT_MAIN $tab, @$ptr[M_NAME], ".$suf_def[MPA_AD](",
                                    &get_mem_portnm($ptr, MPA_AD), ");\n";
                print OUT_MAIN $tab, @$ptr[M_NAME], ".$suf_def[MPA_WD](",
                                        &get_mem_portnm($ptr, MPA_WD), ");\n";
                print OUT_MAIN $tab, @$ptr[M_NAME], ".$suf_def[MPA_RD](",
                                        &get_mem_portnm($ptr, MPA_RD), ");\n";
                print OUT_MAIN $tab, @$ptr[M_NAME], ".$suf_def[MPA_WE](",
                                        &get_mem_portnm($ptr, MPA_WE), ");\n";
                print OUT_MAIN $tab, @$ptr[M_NAME], ".$suf_def[MPA_CS](",
                                        &get_mem_portnm($ptr, MPA_CS), ");\n";

                # B port
                if (@$elm[M_RW] == MA_RW2_B) {
                    $ptr = \@$elm;
                }
                elsif ($elm2) {
                    $ptr = \@$elm2;
                }
                else {
                    my @tmp = @$elm;
                    $tmp[M_WE] = $tmp[M_CS] = 0;
                    $ptr = \@tmp;
                }
                print OUT_MAIN $tab, @$ptr[M_NAME], ".$suf_def[MP_CLKB](@$ptr[M_CLKR]);\n";
                print OUT_MAIN $tab, @$ptr[M_NAME], ".$suf_def[MPB_AD](",
                                    &get_mem_portnm($ptr, MPB_AD), ");\n";
                print OUT_MAIN $tab, @$ptr[M_NAME], ".$suf_def[MPB_WD](",
                                        &get_mem_portnm($ptr, MPB_WD), ");\n";
                print OUT_MAIN $tab, @$ptr[M_NAME], ".$suf_def[MPB_RD](",
                                        &get_mem_portnm($ptr, MPB_RD), ");\n";
                print OUT_MAIN $tab, @$ptr[M_NAME], ".$suf_def[MPB_WE](",
                                        &get_mem_portnm($ptr, MPB_WE), ");\n";
                print OUT_MAIN $tab, @$ptr[M_NAME], ".$suf_def[MPB_CS](",
                                        &get_mem_portnm($ptr, MPB_CS), ");\n";

                if (@$elm[M_CS] == 0) {
                    if (@$elm[M_RW] == MA_RW2_A) {
                        print OUT_MAIN $tab, &get_mem_portnm(\@$elm, MPA_CS), ".write(1);\n";
                    }
                    else {
                        print OUT_MAIN $tab, &get_mem_portnm(\@$elm, MPB_CS), ".write(1);\n";
                    }
                }
                if ($elm2 != 0 && @$elm2[M_CS] == 0) {
                    print OUT_MAIN $tab, &get_mem_portnm(\@$elm2, MPB_CS), ".write(1);\n";
                }
            }
            print OUT_MAIN "#endif\n" if (@$elm[M_PONLY] == 0);
        }
    }
}

##
## print memory pointer (extern declaration)
##
sub print_memory_ptr {
    if ($top_mode == 0) {
        my $exist = 0;
        @mem_used = ();
        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 1);
            my $skip = 0;
            foreach $used (@mem_used) {
                if ($used eq @$elm[M_NAME]) {
                    $skip = 1;
                    last;
                }
            }
            push(@mem_used, @$elm[M_NAME]);
            if ($skip == 0 && @$elm[M_PONLY] == 0) {
                $exist = 1;
                print OUT_H "\nMEM_PTR(@$elm[M_NAME], ";
                print OUT_H &get_type(@$elm[M_SIGN] == 1 ? "svar" : "var", @$elm[M_WID]);
                print OUT_H ");";
                print OUT_H " // global memory pointer for array access";
            }
        }
        print OUT_H "\n" if ($exist == 1);
    }
}

##
## print memory port and array
##
sub print_memory_def {
    print OUT_H "\n" if (@mem_list > 0);
    @mem_used = ();
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        my $skip = 0;
        if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
            foreach $used (@mem_used) {
                if ($used eq @$elm[M_NAME]) {
                    $skip = 1;
                    last;
                }
            }
            push(@mem_used, @$elm[M_NAME]);
        }
        if ($skip == 0) {
            #$size = &log2(@$elm[M_SIZE]);
            $size = &log2(&get_macro_value(@$elm[M_SIZE], "", 0));
            if (@$elm[M_RW] == MA_RW1 || (@$elm[M_RW] & MA_DPORT)) {
                $type = "1";
            }
            elsif (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                if ($top_mode == 0) {
                    if (@$elm[M_RW] == MA_RW1_R) {
                        $type = "1R";
                    }
                    else {
                        $type = "1W";
                    }
                }
                else {
                    if (@$elm[M_SHARE] != 0) {
                        $type = "1";
                    }
                    else {
                        if (@$elm[M_RW] == MA_RW1_R) {
                            $type = "1R";
                        }
                        else {
                            $type = "1W";
                        }
                    }
                }
            }
            elsif (@$elm[M_RW] == MA_R1W1_R) {
                $type = "2R";
            }
            elsif (@$elm[M_RW] == MA_R1W1_W) {
                $type = "2W";
            }

            if (@$elm[M_COM] ne "") {
                print OUT_H $tab, &comment(@$elm[M_COM]);
            }
            print OUT_H $tab, "MEM_DEF_$type";
            if ((($type eq "2R" || $type eq "1R") && @$elm[M_RE] > 0)
             || (($type eq "2W" || $type eq "1") && @$elm[M_CS] > 0)) {
                print OUT_H "_E";
                if ($type eq "2W" && @$elm[M_BE] > 0) {
                    print OUT_H "_B";
                }
            }
            print OUT_H "_P" if (@$elm[M_PONLY] == 1);
            print OUT_H "(@$elm[M_NAME], ";
            print OUT_H &get_type(@$elm[M_SIGN] == 1 ? "svar" : "var", @$elm[M_WID]);
            print OUT_H ", $size";
            if ($type eq "2W" && @$elm[M_BE] > 0) {
                print OUT_H ", ", (&get_macro_value(@$elm[M_WID], "", 0)>>3);
            }
            print OUT_H ", @$elm[M_LAT]";
            if ($type ne "2W" && $type ne "1W") {
                print OUT_H ", @$elm[M_IPRE]";
            }
            print OUT_H ", @$elm[M_OPRE]";
            if ($type eq "1") {
                if (@$elm[M_RW] & MA_DPORT) {
                    print OUT_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_AD : MPB_AD);
                    print OUT_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_WD : MPB_WD);
                    print OUT_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_WE : MPB_WE);
                    print OUT_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_RD : MPB_RD);
                    if (@$elm[M_CS] > 0) {
                        print OUT_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_CS : MPB_CS);
                    }
                }
                else {
                    print OUT_H ", ", &get_mem_suf(\@$elm, MP1_AD);
                    print OUT_H ", ", &get_mem_suf(\@$elm, MP1_WD);
                    print OUT_H ", ", &get_mem_suf(\@$elm, MP1_WE);
                    print OUT_H ", ", &get_mem_suf(\@$elm, MP1_RD);
                    if (@$elm[M_CS] > 0) {
                        print OUT_H ", ", &get_mem_suf(\@$elm, MP1_CS);
                    }
                }
            }
            elsif ($type eq "1R") {
                print OUT_H ", ", &get_mem_suf(\@$elm, MP1_RA);
                print OUT_H ", ", &get_mem_suf(\@$elm, MP1_RD);
                if (@$elm[M_RE] > 0) {
                    print OUT_H ", ", &get_mem_suf(\@$elm, MP1_RE);
                }
            }
            elsif ($type eq "1W") {
                print OUT_H ", ", &get_mem_suf(\@$elm, MP1_WA);
                print OUT_H ", ", &get_mem_suf(\@$elm, MP1_WD);
                print OUT_H ", ", &get_mem_suf(\@$elm, MP1_WE);
            }
            elsif ($type eq "2R") {
                print OUT_H ", ", &get_mem_suf(\@$elm, MP2_RA);
                print OUT_H ", ", &get_mem_suf(\@$elm, MP2_RD);
                if (@$elm[M_RE] > 0) {
                    print OUT_H ", ", &get_mem_suf(\@$elm, MP2_RE);
                }
            }
            elsif ($type eq "2W") {
                print OUT_H ", ", &get_mem_suf(\@$elm, MP2_WA);
                print OUT_H ", ", &get_mem_suf(\@$elm, MP2_WD);
                print OUT_H ", ", &get_mem_suf(\@$elm, MP2_WE);
                if (@$elm[M_CS] > 0) {
                    print OUT_H ", ", &get_mem_suf(\@$elm, MP2_CS);
                }
                if (@$elm[M_BE] > 0) {
                    print OUT_H ", ", &get_mem_suf(\@$elm, MP2_BE);
                }
            }
            print OUT_H ") // memory def: ";
            print OUT_H &get_macro_comment(\@$elm);
            print OUT_H ", addr:${size}bit, latency:@$elm[M_LAT]\n";
        }
    }
}


##
## print memory pointer for testbench
##
sub print_tb_memory_ptr {
    @mem_used = ();
    print OUT_TB_H "\n" if (@mem_list > 0);
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        my $skip = 0;
        foreach $used (@mem_used) {
            if ($used eq @$elm[M_NAME]) {
                $skip = 1;
                last;
            }
        }
        push(@mem_used, @$elm[M_NAME]);
        if ($skip == 0) {
            print OUT_TB_H "MEM_PTR_A(@$elm[M_NAME], ";
            print OUT_TB_H &get_type(@$elm[M_SIGN] == 1 ? "svar" : "var", @$elm[M_WID]);
            print OUT_TB_H ");";
            print OUT_TB_H " // global memory pointer\n";
        }
    }
}

##
## print memory port and array for testbench
##
sub print_tb_memory_def {
    my $start = 1;
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        if (@$elm[M_RW] != MA_RW1 && @$elm[M_SHARE] == 0) {
            #$size = &log2(@$elm[M_SIZE]);
            $size = &log2(&get_macro_value(@$elm[M_SIZE], "", 0));
            $dtype = &get_type(@$elm[M_SIGN] == 1 ? "svar" : "var", @$elm[M_WID]);

            if ($start == 1) {
                print OUT_TB_H "\n";
                $start = 0;
            }
            if (@$elm[M_COM] ne "") {
                print OUT_TB_H $tab, &comment(@$elm[M_COM]);
            }
            # read port
            if (@$elm[M_RW] == MA_R1W1_W || @$elm[M_RW] == MA_RW1_W) {
                if (@$elm[M_RW] == MA_R1W1_W) {
                    print OUT_TB_H $tab, "MEM_DEF_2R_E";
                    print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                    print OUT_TB_H "(@$elm[M_NAME], $dtype, $size, @$elm[M_LAT], @$elm[M_IPRE], @$elm[M_OPRE]";
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_RA);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_RD);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_RE);
                }
                else {
                    print OUT_TB_H $tab, "MEM_DEF_1R_E";
                    print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                    print OUT_TB_H "(@$elm[M_NAME], $dtype, $size, @$elm[M_LAT], @$elm[M_IPRE], @$elm[M_OPRE]";
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_RA);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_RD);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_RE);
                }
            }
            # write port
            elsif (@$elm[M_RW] == MA_R1W1_R || @$elm[M_RW] == MA_RW1_R) {
                if (@$elm[M_RW] == MA_R1W1_R) {
                    print OUT_TB_H $tab, "MEM_DEF_2W_E";
                    print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                    print OUT_TB_H "(@$elm[M_NAME], $dtype, $size, @$elm[M_LAT], @$elm[M_OPRE]";
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_WA);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_WD);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_WE);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_CS);
                }
                else {
                    print OUT_TB_H $tab, "MEM_DEF_1W";
                    print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                    print OUT_TB_H "(@$elm[M_NAME], $dtype, $size, @$elm[M_LAT], @$elm[M_OPRE]";
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_WA);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_WD);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_WE);
                }
            }
            #dual port
            elsif (@$elm[M_RW] & MA_DPORT) {
                print OUT_TB_H $tab, "MEM_DEF_1_E";
                print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                print OUT_TB_H "(@$elm[M_NAME], $dtype, $size, @$elm[M_LAT], @$elm[M_IPRE], @$elm[M_OPRE]";
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_AD : MPA_AD);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_WD : MPA_WD);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_WE : MPA_WE);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_RD : MPA_RD);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_CS : MPA_CS);
            }
            print OUT_TB_H ")";
            print OUT_TB_H " // memory definition\n";
        }
    }
}

##
## print memory init name
##
sub print_memory_init_name {
    my $fix_flg = $_[0];
    @mem_used = ();
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == $fix_flg);
        my $skip = 0;
        if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
            foreach $used (@mem_used) {
                if ($used eq @$elm[M_NAME]) {
                    $skip = 1;
                    last;
                }
            }
            push(@mem_used, @$elm[M_NAME]);
        }
        if ($skip == 0) {
            #$size = &log2(@$elm[M_SIZE]);
            $size = &log2(&get_macro_value(@$elm[M_SIZE], "", 0));
            if (@$elm[M_RW] == MA_RW1 || (@$elm[M_RW] & MA_DPORT)) {
                $type = "1";
            }
            elsif (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                if ($top_mode == 0) {
                    if (@$elm[M_RW] == MA_RW1_R) {
                        $type = "1R";
                    }
                    else {
                        $type = "1W";
                    }
                }
                else {
                    if (@$elm[M_SHARE] != 0) {
                        $type = "1";
                    }
                    else {
                        if (@$elm[M_RW] == MA_RW1_R) {
                            $type = "1R";
                        }
                        else {
                            $type = "1W";
                        }
                    }
                }
            }
            elsif (@$elm[M_RW] == MA_R1W1_R) {
                $type = "2R";
            }
            elsif (@$elm[M_RW] == MA_R1W1_W) {
                $type = "2W";
            }
            print OUT_H $tab x2, "MEM_ININM_$type";
            if ((($type eq "2R" || $type eq "1R") && @$elm[M_RE] > 0)
             || (($type eq "2W" || $type eq "1") && @$elm[M_CS] > 0)) {
                print OUT_H "_E";
                if ($type eq "2W" && @$elm[M_BE] > 0) {
                    print OUT_H "_B";
                }
            }
            print OUT_H "_P" if (@$elm[M_PONLY] == 1);
            print OUT_H "(@$elm[M_NAME]";
            if ($type ne "2W" && $type ne "1W") {
                print OUT_H ", @$elm[M_IPRE]";
            }
            print OUT_H ", @$elm[M_OPRE]";
            if ($type eq "1") {
                if (@$elm[M_RW] & MA_DPORT) {
                    print OUT_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_AD : MPB_AD);
                    print OUT_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_WD : MPB_WD);
                    print OUT_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_WE : MPB_WE);
                    print OUT_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_RD : MPB_RD);
                    if (@$elm[M_CS] > 0) {
                        print OUT_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_CS : MPB_CS);
                    }
                }
                else {
                    print OUT_H ", ", &get_mem_suf(\@$elm, MP1_AD);
                    print OUT_H ", ", &get_mem_suf(\@$elm, MP1_WD);
                    print OUT_H ", ", &get_mem_suf(\@$elm, MP1_WE);
                    print OUT_H ", ", &get_mem_suf(\@$elm, MP1_RD);
                    if (@$elm[M_CS] > 0) {
                        print OUT_H ", ", &get_mem_suf(\@$elm, MP1_CS);
                    }
                }
            }
            elsif ($type eq "1R") {
                print OUT_H ", ", &get_mem_suf(\@$elm, MP1_RA);
                print OUT_H ", ", &get_mem_suf(\@$elm, MP1_RD);
                if (@$elm[M_RE] > 0) {
                    print OUT_H ", ", &get_mem_suf(\@$elm, MP1_RE);
                }
            }
            elsif ($type eq "1W") {
                print OUT_H ", ", &get_mem_suf(\@$elm, MP1_WA);
                print OUT_H ", ", &get_mem_suf(\@$elm, MP1_WD);
                print OUT_H ", ", &get_mem_suf(\@$elm, MP1_WE);
            }
            elsif ($type eq "2R") {
                print OUT_H ", ", &get_mem_suf(\@$elm, MP2_RA);
                print OUT_H ", ", &get_mem_suf(\@$elm, MP2_RD);
                if (@$elm[M_RE] > 0) {
                    print OUT_H ", ", &get_mem_suf(\@$elm, MP2_RE);
                }
            }
            elsif ($type eq "2W") {
                print OUT_H ", ", &get_mem_suf(\@$elm, MP2_WA);
                print OUT_H ", ", &get_mem_suf(\@$elm, MP2_WD);
                print OUT_H ", ", &get_mem_suf(\@$elm, MP2_WE);
                if (@$elm[M_CS] > 0) {
                    print OUT_H ", ", &get_mem_suf(\@$elm, MP2_CS);
                }
                if (@$elm[M_BE] > 0) {
                    print OUT_H ", ", &get_mem_suf(\@$elm, MP2_BE);
                }
            }
            print OUT_H ") // set port name: ";
            print OUT_H &get_macro_comment(\@$elm);
            print OUT_H "\n";
        }
    }
}

##
## print memeory init name for testbench
##
sub print_tb_memory_init_name {
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        if (@$elm[M_RW] != MA_RW1 && @$elm[M_SHARE] == 0) {
            if (@$elm[M_RW] == MA_R1W1_W || @$elm[M_RW] == MA_RW1_W) {
                if (@$elm[M_RW] == MA_R1W1_W) {
                    print OUT_TB_H $tab x2, "MEM_ININM_2R_E";
                    print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                    print OUT_TB_H "(@$elm[M_NAME], @$elm[M_IPRE], @$elm[M_OPRE]";
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_RA);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_RD);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_RE);
                }
                else {
                    print OUT_TB_H $tab x2, "MEM_ININM_1R_E";
                    print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                    print OUT_TB_H "(@$elm[M_NAME], @$elm[M_IPRE], @$elm[M_OPRE]";
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_RA);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_RD);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_RE);
                }
                print OUT_TB_H ")";
                print OUT_TB_H " // set port name\n";
            }
            elsif (@$elm[M_RW] == MA_R1W1_R || @$elm[M_RW] == MA_RW1_R) {
                if (@$elm[M_RW] == MA_R1W1_R) {
                    print OUT_TB_H $tab x2, "MEM_ININM_2W_E";
                    print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                    print OUT_TB_H "(@$elm[M_NAME], @$elm[M_OPRE]";
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_WA);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_WD);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_WE);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_CS);
                }
                else {
                    print OUT_TB_H $tab x2, "MEM_ININM_1W";
                    print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                    print OUT_TB_H "(@$elm[M_NAME], @$elm[M_OPRE]";
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_WA);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_WD);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_WE);
                }
                print OUT_TB_H ")";
                print OUT_TB_H " // set port name\n";
            }
            elsif (@$elm[M_RW] & MA_DPORT) {
                print OUT_TB_H $tab x2, "MEM_ININM_1_E";
                print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                print OUT_TB_H "(@$elm[M_NAME], @$elm[M_IPRE], @$elm[M_OPRE]";
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_AD : MPA_AD);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_WD : MPA_WD);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_WE : MPA_WE);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_RD : MPA_RD);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_CS : MPA_CS);
                print OUT_TB_H ")";
                print OUT_TB_H " // set port name\n";
            }
        }
    }
}

##
## print memeory init
##   OUT     : file pointer
##   $indent : indent string
##   $thnm   : belonged thread name
##
sub print_memory_init {
    local(*OUT) = $_[0];
    my $indent = $_[1];
    my $thnm   = $_[2];
    $indent = $indent . $tab;

    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        next if ($thnm ne "" && $thnm ne @$elm[M_TH]);
        if (@$elm[M_RW] == MA_RW1 || (@$elm[M_RW] & MA_DPORT)) {
            $type = "1";
        }
        elsif (@$elm[M_RW] == MA_RW1_R) {
            $type = "1R";
        }
        elsif (@$elm[M_RW] == MA_RW1_W) {
            $type = "1W";
        }
        elsif (@$elm[M_RW] == MA_R1W1_R) {
            $type = "2R";
        }
        elsif (@$elm[M_RW] == MA_R1W1_W) {
            $type = "2W";
        }
        if ((@$elm[M_FLG] & FLG_NOAD)
          && (($type eq "2R" || $type eq "1R") && @$elm[M_RE] == 0)) {
            # do not generate macro call
        }
        else {
            print OUT $indent, "MEM_INIVAL_$type";
            if ((($type eq "2R" || $type eq "1R") && @$elm[M_RE] > 0)
             || (($type eq "2W" || $type eq "1") && @$elm[M_CS] > 0)) {
                print OUT "_E";
                if ($type eq "2W" && @$elm[M_BE] > 0) {
                    print OUT "_B";
                }
            }
            if ((@$elm[M_FLG] & FLG_NOAD) && (@$elm[M_FLG] & FLG_NOWD)) {
                print OUT "_NOAW";
            }
            elsif (@$elm[M_FLG] & FLG_NOAD) {
                print OUT "_NOAD";
            }
            elsif (@$elm[M_FLG] & FLG_NOWD) {
                print OUT "_NOWD";
            }
            print OUT "_P" if (@$elm[M_PONLY] == 1);
            print OUT "(@$elm[M_NAME]";
            print OUT ", @$elm[M_OPRE]";
            if ($type eq "2R" || $type eq "1R") {
                if (@$elm[M_RE] > 0) {
                    print OUT ", ";
                    print OUT (@$elm[M_RE] == 2 ? "1" : "0");
                }
            }
            else {
                print OUT ", ";
                print OUT (@$elm[M_WE] == 2 ? "1" : "0");
            }
            if (($type eq "2W" || $type eq "1") && @$elm[M_CS] > 0) {
                print OUT ", ", (@$elm[M_CS] == 2 ? "1" : "0");
            }
            if ($type eq "2W" && @$elm[M_BE] > 0) {
                print OUT ", ", (@$elm[M_BE] == 2 ? "~0" : "0");
            }

            if ($type eq "1") {
                if (@$elm[M_RW] & MA_DPORT) {
                    print OUT ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_AD : MPB_AD);
                    print OUT ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_WD : MPB_WD);
                    print OUT ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_WE : MPB_WE);
                    if (@$elm[M_CS] > 0) {
                        print OUT ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_CS : MPB_CS);
                    }
                }
                else {
                    print OUT ", ", &get_mem_suf(\@$elm, MP1_AD);
                    print OUT ", ", &get_mem_suf(\@$elm, MP1_WD);
                    print OUT ", ", &get_mem_suf(\@$elm, MP1_WE);
                    if (@$elm[M_CS] > 0) {
                        print OUT ", ", &get_mem_suf(\@$elm, MP1_CS);
                    }
                }
            }
            elsif ($type eq "1R") {
                print OUT ", ", &get_mem_suf(\@$elm, MP1_RA);
                if (@$elm[M_RE] > 0) {
                    print OUT ", ", &get_mem_suf(\@$elm, MP1_RE);
                }
            }
            elsif ($type eq "1W") {
                print OUT ", ", &get_mem_suf(\@$elm, MP1_WA);
                print OUT ", ", &get_mem_suf(\@$elm, MP1_WD);
                print OUT ", ", &get_mem_suf(\@$elm, MP1_WE);
            }
            elsif ($type eq "2R") {
                print OUT ", ", &get_mem_suf(\@$elm, MP2_RA);
                if (@$elm[M_RE] > 0) {
                    print OUT ", ", &get_mem_suf(\@$elm, MP2_RE);
                }
            }
            elsif ($type eq "2W") {
                print OUT ", ", &get_mem_suf(\@$elm, MP2_WA);
                print OUT ", ", &get_mem_suf(\@$elm, MP2_WD);
                print OUT ", ", &get_mem_suf(\@$elm, MP2_WE);
                if (@$elm[M_CS] > 0) {
                    print OUT ", ", &get_mem_suf(\@$elm, MP2_CS);
                }
                if (@$elm[M_BE] > 0) {
                    print OUT ", ", &get_mem_suf(\@$elm, MP2_BE);
                }
            }
            print OUT ");";
            print OUT " // initialize port: ";
            print OUT &get_macro_comment(\@$elm), "\n";
        }
    }
}

##
## print memeory init for testbench
##
sub print_tb_memory_init {
    @mem_used = ();
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        if (@$elm[M_RW] != MA_RW1 && @$elm[M_SHARE] == 0) {
            # read port
            if (@$elm[M_RW] == MA_R1W1_W || @$elm[M_RW] == MA_RW1_W) {
                if (@$elm[M_RW] == MA_R1W1_W) {
                    print OUT_TB_H $tab x2, "MEM_INIVAL_2R_E";
                    print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                    print OUT_TB_H "(@$elm[M_NAME], @$elm[M_OPRE], 0";
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_RA);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_RE);
                }
                else {
                    print OUT_TB_H $tab x2, "MEM_INIVAL_1R_E";
                    print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                    print OUT_TB_H "(@$elm[M_NAME], @$elm[M_OPRE], 0";
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_RA);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_RE);
                }
                print OUT_TB_H ");";
                print OUT_TB_H " // initialize port\n";
            }
            # write port
            elsif (@$elm[M_RW] == MA_R1W1_R || @$elm[M_RW] == MA_RW1_R) {
                if (@$elm[M_RW] == MA_R1W1_R) {
                    print OUT_TB_H $tab x2, "MEM_INIVAL_2W_E";
                    print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                    print OUT_TB_H "(@$elm[M_NAME], @$elm[M_OPRE], 0, 0";
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_WA);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_WD);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_WE);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_CS);
                }
                else {
                    print OUT_TB_H $tab x2, "MEM_INIVAL_1W";
                    print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                    print OUT_TB_H "(@$elm[M_NAME], @$elm[M_OPRE], 0";
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_WA);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_WD);
                    print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_WE);
                }
                print OUT_TB_H ");";
                print OUT_TB_H " // initialize port\n";
            }
            #dual port
            elsif (@$elm[M_RW] & MA_DPORT) {
                print OUT_TB_H $tab x2, "MEM_INIVAL_1_E";
                print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
                print OUT_TB_H "(@$elm[M_NAME], @$elm[M_OPRE], 0, 0";
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_AD : MPA_AD);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_WD : MPA_WD);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_WE : MPA_WE);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_CS : MPA_CS);
                print OUT_TB_H ");";
                print OUT_TB_H " // initialize port\n";
            }
        }
    }
}

##
## print memory function
##   OUT       : file pointer
##   $out_mode : print mode (= 0:header, 1:header-proto, 2:source)
##
sub print_memory_func {
    local(*OUT) = $_[0];
    my $out_mode = $_[1];
    my $indent = $out_mode == 2 ? "" : $tab;

    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        $mode = $out_mode;
        if ($mode == 1) {
            if (@$elm[M_FLG] & FLG_HDR) {
                $mode = 0;
            }
        }
        elsif ($out_mode == 2) {
            if (@$elm[M_FLG] & FLG_HDR) {
                next;
            }
        }
        #$size = &log2(@$elm[M_SIZE]);
        $size = &log2(&get_macro_value(@$elm[M_SIZE], "", 0));
        $dtype = &get_type(@$elm[M_SIGN] == 1 ? "svar" : "var", @$elm[M_WID]);
        $btype = "sc_uint<".(&get_macro_value(@$elm[M_WID], "", 0)>>3).">";
        if (@$elm[M_RW] == MA_RW1 || (@$elm[M_RW] & MA_DPORT)) {
            $type = "1";
            $tname = "1";
        }
        elsif (@$elm[M_RW] == MA_RW1_R) {
            $type = "1R";
            $tname = "1R";
        }
        elsif (@$elm[M_RW] == MA_RW1_W) {
            $type = "1W";
            $tname = "1";
        }
        elsif (@$elm[M_RW] == MA_R1W1_R) {
            $type = "2R";
            $tname = "2";
        }
        elsif (@$elm[M_RW] == MA_R1W1_W) {
            $type = "2W";
            $tname = "2";
        }

        # mem_read
        if ((@$elm[M_RW] & MA_R) || (@$elm[M_RW] & MA_DPORT)) {
            print OUT "\n";
            print OUT $indent, "void ";
            if ($mode == 2) {
                print OUT $module_name, "::";
            }
            print OUT "req_@$elm[M_NAME](";
            print OUT &get_type("var", $size);
            print OUT " addr)";
            print OUT ($mode == 1 ? ";" : " {"), "\n";

            if ($mode != 1) {
                $en = 0;
                if (($type eq "1" && @$elm[M_CS] > 0)
                 || (($type eq "2R" || $type eq "1R") && @$elm[M_RE] > 0)) {
                    $en = 1;
                }

                if ((@$elm[M_FLG] & FLG_NOAD) && $en == 0) {
                    # do not generate macro call
                }
                else {
                    print OUT $indent, $tab, "MEM_REQ_", $tname;
                    print OUT "_E" if ($en);
                    print OUT "_NOAD" if (@$elm[M_FLG] & FLG_NOAD);
                    print OUT "_P" if (@$elm[M_PONLY] == 1);
                    print OUT "(@$elm[M_NAME], @$elm[M_OPRE]";
                    if ($type eq "1") {
                        if (@$elm[M_CS] > 0) {
                            print OUT ", ", (@$elm[M_CS] == 2 ? "0" : "1");
                        }
                        if (@$elm[M_RW] & MA_DPORT) {
                            print OUT ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_AD : MPB_AD);
                            if (@$elm[M_CS] > 0) {
                                print OUT ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_CS : MPB_CS);
                            }
                        }
                        else {
                            print OUT ", ", &get_mem_suf(\@$elm, MP1_AD);
                            if (@$elm[M_CS] > 0) {
                                print OUT ", ", &get_mem_suf(\@$elm, MP1_CS);
                            }
                        }
                    }
                    elsif ($type eq "1R") {
                        if (@$elm[M_RE] > 0) {
                            print OUT ", ", (@$elm[M_RE] == 2 ? "0" : "1");
                        }
                        print OUT ", ", &get_mem_suf(\@$elm, MP1_RA);
                        if (@$elm[M_RE] > 0) {
                            print OUT ", ", &get_mem_suf(\@$elm, MP1_RE);
                        }
                    }
                    elsif ($type eq "2R") {
                        if (@$elm[M_RE] > 0) {
                            print OUT ", ", (@$elm[M_RE] == 2 ? "0" : "1");
                        }
                        print OUT ", ", &get_mem_suf(\@$elm, MP2_RA);
                        if (@$elm[M_RE] > 0) {
                            print OUT ", ", &get_mem_suf(\@$elm, MP2_RE);
                        }
                    }
                    print OUT "); // read request: ";
                    print OUT &get_macro_comment(\@$elm), "\n";
                }
                print OUT $indent, "}\n";
            }

            print OUT "\n";
            print OUT $indent, "void ";
            if ($mode == 2) {
                print OUT $module_name, "::";
            }
            print OUT "rd_@$elm[M_NAME]($dtype& data)";
            print OUT ($mode == 1 ? ";" : " {"), "\n";
            if ($mode != 1) {
                print OUT $indent, $tab, "MEM_RD_", $tname;
                if (@$elm[M_PONLY] == 1) {
                    print OUT "_P";
                }
                print OUT "(@$elm[M_NAME], @$elm[M_LAT], @$elm[M_IPRE], ";
                if ($type eq "1" || $type eq "1R") {
                    if (@$elm[M_RW] & MA_DPORT) {
                        print OUT &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_RD : MPB_RD);
                    }
                    else {
                        print OUT &get_mem_suf(\@$elm, MP1_RD);
                    }
                }
                else {
                    print OUT &get_mem_suf(\@$elm, MP2_RD);
                }
                print OUT ");";
                print OUT " // read: ";
                print OUT &get_macro_comment(\@$elm);
                print OUT ", latency:@$elm[M_LAT]\n";
                print OUT $indent, "}\n";
            }

            print OUT "\n";
            print OUT $indent, "$dtype ";
            if ($mode == 2) {
                print OUT $module_name, "::";
            }
            print OUT "rd_@$elm[M_NAME]()";
            print OUT ($mode == 1 ? ";" : " {"), "\n";
            if ($mode != 1) {
                print OUT $indent, $tab, $dtype, " data;\n";
                print OUT $indent, $tab, "MEM_RD_", $tname;
                if (@$elm[M_PONLY] == 1) {
                    print OUT "_P";
                }
                print OUT "(@$elm[M_NAME], @$elm[M_LAT], @$elm[M_IPRE], ";
                if ($type eq "1" || $type eq "1R") {
                    if (@$elm[M_RW] & MA_DPORT) {
                        print OUT &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_RD : MPB_RD);
                    }
                    else {
                        print OUT &get_mem_suf(\@$elm, MP1_RD);
                    }
                }
                else {
                    print OUT &get_mem_suf(\@$elm, MP2_RD);
                }
                print OUT ");";
                print OUT " // read: ";
                print OUT &get_macro_comment(\@$elm);
                print OUT ", latency:@$elm[M_LAT]\n";
                print OUT $indent, $tab, "return data;\n";
                print OUT $indent, "}\n";
            }
        }

        # mem_write
        if ((@$elm[M_RW] & MA_W) || (@$elm[M_RW] & MA_DPORT)) {
            print OUT "\n";
            print OUT $indent, "void ";
            if ($mode == 2) {
                print OUT $module_name, "::";
            }
            print OUT "wr_@$elm[M_NAME](";
            print OUT &get_type("var", $size);
            print OUT " addr, $dtype data";
            if (@$elm[M_BE] > 0) {
                print OUT ", $btype be";
            }
            print OUT ")";
            print OUT ($mode == 1 ? ";" : " {"), "\n";
            if ($mode != 1) {
                print OUT $indent, $tab, "MEM_WR_", $tname;
                print OUT "_E" if (@$elm[M_CS] > 0);
                print OUT "_B" if (@$elm[M_BE] > 0);
                if ((@$elm[M_FLG] & FLG_NOAD) && (@$elm[M_FLG] & FLG_NOWD)) {
                    print OUT "_NOAW";
                }
                elsif (@$elm[M_FLG] & FLG_NOAD) {
                    print OUT "_NOAD";
                }
                elsif (@$elm[M_FLG] & FLG_NOWD) {
                    print OUT "_NOWD";
                }
                print OUT "_P" if (@$elm[M_PONLY] == 1);
                print OUT "(@$elm[M_NAME], @$elm[M_OPRE], ";
                print OUT (@$elm[M_WE] == 2 ? "0" : "1");
                print OUT ", ", (@$elm[M_CS] == 2 ? "0" : "1") if (@$elm[M_CS] > 0);
                if ($type eq "1") {
                    if (@$elm[M_RW] & MA_DPORT) {
                        print OUT ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_AD : MPB_AD);
                        print OUT ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_WD : MPB_WD);
                        print OUT ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_WE : MPB_WE);
                        if (@$elm[M_CS] > 0) {
                            print OUT ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_CS : MPB_CS);
                        }
                    }
                    else {
                        print OUT ", ", &get_mem_suf(\@$elm, MP1_AD);
                        print OUT ", ", &get_mem_suf(\@$elm, MP1_WD);
                        print OUT ", ", &get_mem_suf(\@$elm, MP1_WE);
                        if (@$elm[M_CS] > 0) {
                            print OUT ", ", &get_mem_suf(\@$elm, MP1_CS);
                        }
                    }
                }
                elsif ($type eq "1W") {
                    print OUT ", ", &get_mem_suf(\@$elm, MP1_WA);
                    print OUT ", ", &get_mem_suf(\@$elm, MP1_WD);
                    print OUT ", ", &get_mem_suf(\@$elm, MP1_WE);
                }
                elsif ($type eq "2W") {
                    print OUT ", ", &get_mem_suf(\@$elm, MP2_WA);
                    print OUT ", ", &get_mem_suf(\@$elm, MP2_WD);
                    print OUT ", ", &get_mem_suf(\@$elm, MP2_WE);
                    if (@$elm[M_CS] > 0) {
                        print OUT ", ", &get_mem_suf(\@$elm, MP2_CS);
                    }
                    if (@$elm[M_BE] > 0) {
                        print OUT ", ", &get_mem_suf(\@$elm, MP2_BE);
                    }
                }
                print OUT  ");";
                print OUT " // write: ";
                print OUT &get_macro_comment(\@$elm), "\n";
                print OUT $indent, "}\n";
            }
        }

        # mem_addr shift
        if (@$elm[M_PONLY] == 0 && $mode != 2) {
            print OUT "\n";
            print OUT $tab, "MEM_PIPE";
            print OUT "_2R" if (@$elm[M_RW] == MA_R1W1_R || @$elm[M_RW] == MA_RW1_R);
            print OUT "(@$elm[M_NAME], @$elm[M_LAT])";
            print OUT " // pipeline function for array access\n";
        }
    }
}

##
## print memory function for testbench
##
sub print_tb_memory_func {
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        next if (@$elm[M_RW] == MA_RW1 || @$elm[M_SHARE] != 0);

        #$size = &log2(@$elm[M_SIZE]);
        $size = &log2(&get_macro_value(@$elm[M_SIZE], "", 0));
        $dtype = &get_type(@$elm[M_SIGN] == 1 ? "svar" : "var", @$elm[M_WID]);

        # mem_read
        if (@$elm[M_RW] == MA_R1W1_W || @$elm[M_RW] == MA_RW1_W || (@$elm[M_RW] & MA_DPORT)) {
            print OUT_TB_H "\n";
            print OUT_TB_H $tab, "void req_@$elm[M_NAME](";
            print OUT_TB_H &get_type("var", $size);
            print OUT_TB_H " addr) {\n";
            if (@$elm[M_RW] == MA_R1W1_W) {
                print OUT_TB_H $tab x2, "MEM_REQ_2_E";
            }
            elsif (@$elm[M_RW] == MA_RW1_W) {
                print OUT_TB_H $tab x2, "MEM_REQ_1R_E";
            }
            else {
                print OUT_TB_H $tab x2, "MEM_REQ_1_E";
            }
            print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
            print OUT_TB_H "(@$elm[M_NAME], @$elm[M_OPRE], 1";
            if (@$elm[M_RW] == MA_R1W1_W) {
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_RA);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_RE);
            }
            elsif (@$elm[M_RW] == MA_RW1_W) {
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_RA);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_RE);
            }
            else {
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_AD : MPA_AD);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_CS : MPA_CS);
            }
            print OUT_TB_H ");";
            print OUT_TB_H " // read request\n";
            print OUT_TB_H $tab, "}\n";

            print OUT_TB_H "\n";
            print OUT_TB_H $tab, "void rd_@$elm[M_NAME]($dtype& data) {\n";
            print OUT_TB_H $tab x2, "MEM_RD_";
            if (@$elm[M_RW] == MA_R1W1_W) {
                print OUT_TB_H "2";
            }
            elsif (@$elm[M_RW] == MA_RW1_W) {
                print OUT_TB_H "1R";
            }
            else {
                print OUT_TB_H "1";
            }
            if (@$elm[M_PONLY] == 1) {
                print OUT_TB_H "_P";
            }
            print OUT_TB_H "(@$elm[M_NAME], @$elm[M_LAT], @$elm[M_IPRE], ";
            if (@$elm[M_RW] == MA_R1W1_W) {
                print OUT_TB_H &get_mem_suf(\@$elm, MP2_RD);
            }
            elsif (@$elm[M_RW] == MA_RW1_W) {
                print OUT_TB_H &get_mem_suf(\@$elm, MP1_RD);
            }
            else {
                print OUT_TB_H &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_RD : MPA_RD);
            }
            print OUT_TB_H ");";
            print OUT_TB_H " // read\n";
            print OUT_TB_H $tab, "}\n";

            print OUT_TB_H "\n";
            print OUT_TB_H $tab, $dtype, " rd_@$elm[M_NAME]() {\n";
            print OUT_TB_H $tab x2, $dtype, " data;\n";
            print OUT_TB_H $tab x2, "MEM_RD_";
            if (@$elm[M_RW] == MA_R1W1_W) {
                print OUT_TB_H "2";
            }
            elsif (@$elm[M_RW] == MA_RW1_W) {
                print OUT_TB_H "1R";
            }
            else {
                print OUT_TB_H "1";
            }
            if (@$elm[M_PONLY] == 1) {
                print OUT_TB_H "_P";
            }
            print OUT_TB_H "(@$elm[M_NAME], @$elm[M_LAT], @$elm[M_IPRE], ";
            if (@$elm[M_RW] == MA_R1W1_W) {
                print OUT_TB_H &get_mem_suf(\@$elm, MP2_RD);
            }
            elsif (@$elm[M_RW] == MA_RW1_W) {
                print OUT_TB_H &get_mem_suf(\@$elm, MP1_RD);
            }
            else {
                print OUT_TB_H &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_RD : MPA_RD);
            }
            print OUT_TB_H ");";
            print OUT_TB_H " // read\n";
            print OUT_TB_H $tab x2, "return data;\n";
            print OUT_TB_H $tab, "}\n";
        }

        # mem_write
        if (@$elm[M_RW] == MA_R1W1_R || @$elm[M_RW] == MA_RW1_R || (@$elm[M_RW] & MA_DPORT)) {
            print OUT_TB_H "\n";
            print OUT_TB_H $tab, "void wr_@$elm[M_NAME](";
            print OUT_TB_H &get_type("var", $size);
            print OUT_TB_H " addr, $dtype data) {\n";
            if (@$elm[M_RW] == MA_R1W1_R) {
                print OUT_TB_H $tab x2, "MEM_WR_2_E";
            }
            elsif (@$elm[M_RW] == MA_RW1_R) {
                print OUT_TB_H $tab x2, "MEM_WR_1";
            }
            else {
                print OUT_TB_H $tab x2, "MEM_WR_1_E";
            }
            print OUT_TB_H "_P" if (@$elm[M_PONLY] == 1);
            if (@$elm[M_RW] == MA_R1W1_R) {
                print OUT_TB_H "(@$elm[M_NAME], @$elm[M_OPRE], 1, 1";
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_WA);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_WD);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_WE);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP2_CS);
            }
            elsif (@$elm[M_RW] == MA_RW1_R) {
                print OUT_TB_H "(@$elm[M_NAME], @$elm[M_OPRE], 1";
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_WA);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_WD);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, MP1_WE);
            }
            else {
                print OUT_TB_H "(@$elm[M_NAME], @$elm[M_OPRE], 1, 1";
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_AD : MPA_AD);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_WD : MPA_WD);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_WE : MPA_WE);
                print OUT_TB_H ", ", &get_mem_suf(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_CS : MPA_CS);
            }
            print OUT_TB_H ");";
            print OUT_TB_H " // write\n";
            print OUT_TB_H $tab, "}\n";
        }

        # mem_addr shift
        if (@$elm[M_PONLY] == 0) {
            print OUT_TB_H "\n";
            print OUT_TB_H $tab, "MEM_PIPE";
            print OUT_TB_H "_2R" if (@$elm[M_RW] == MA_R1W1_W || @$elm[M_RW] == MA_RW1_W);
            print OUT_TB_H "(@$elm[M_NAME], @$elm[M_LAT])";
            print OUT_TB_H " // pipeline function for array access\n";
        }
    }
}

##
## print VCD trace function
##
sub print_vcd_trace_func {
    print OUT_H "\n";
    print OUT_H "#if !defined(__CTOS__) && !defined(CALYPTO_SYSC) && !defined(STRATUS)\n";
    #print OUT_H "#pragma certitude_off\n" if($opt_cer == 1);
    print OUT_H $tab, "void vcd_trace(";
    print OUT_H $opt_standard ? "sc_trace_file" : "ssgen_trace_file";
    print OUT_H "* tf, int depth = $hier_max) {\n";
    if ($vcd_trace == 1 || $vcd_trace == 2 || $top_mode == 1) {
        print OUT_H $tab x2, "if (tf != 0 && depth > 0) {\n";
    }
    if ($vcd_trace == 1 || $vcd_trace == 2) {
        print OUT_H $tab x3, "std::string nm = std::string(name());\n";
        foreach $elm (@clk_list) {
            if (@$elm[T_NAME] ne "" && $vcd_trace == 1) {
                print OUT_H $tab x3, "sc_trace(tf, @$elm[T_NAME], nm + \".@$elm[T_NAME]\");\n";
            }
        }
        foreach $elm (@rst_list) {
            if (@$elm[T_NAME] ne "") {
                print OUT_H $tab x3, "sc_trace(tf, @$elm[T_NAME], nm + \".@$elm[T_NAME]\");\n";
            }
        }
        &print_sc_trace(*OUT_H, \@in_list);
        &print_sc_trace(*OUT_H, \@out_list);
        if ($top_mode == 1) {
            # insert_port
            &print_sc_trace(*OUT_H, \@in_list_insert);
            &print_sc_trace(*OUT_H, \@out_list_insert);
        }
        &print_sc_trace(*OUT_H, \@ev_list);
        &print_sc_trace(*OUT_H, \@reg_list);
        &print_sc_trace(*OUT_H, \@var_list);
        &print_sc_trace(*OUT_H, \@ctype_list);
        foreach $m (@data_list_m) {
            $macro = shift(@$m);
            $find = 0;
            foreach $elm (@$m) {
                if (@$elm[T_TYPE] =~ /reg$/) {
                    $find = 1;
                    last;
                }
            }
            if ($find == 1) {
                print OUT_H "#ifdef $macro\n";
                &print_sc_trace(*OUT_H, \@$m);
                print OUT_H "#endif\n";
            }
            unshift(@$m, $macro);
        }

        @mem_used = ();
        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 1);
            my $skip = 0;
            if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                foreach $used (@mem_used) {
                    if ($used eq @$elm[M_NAME]) {
                        $skip = 1;
                        last;
                    }
                }
                push(@mem_used, @$elm[M_NAME]);
            }
            if ($skip == 0) {
                print OUT_H "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);
                if ((@$elm[M_RW] == MA_RW1) || ((@$elm[M_RW] & MA_1PORT) && @$elm[M_SHARE] > 0)) {
                    $port_nm = &get_mem_portnm(\@$elm, MP1_AD);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    $port_nm = &get_mem_portnm(\@$elm, MP1_WD);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    $port_nm = &get_mem_portnm(\@$elm, MP1_RD);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    $port_nm = &get_mem_portnm(\@$elm, MP1_WE);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    if (@$elm[M_CS] > 0) {
                        $port_nm = &get_mem_portnm(\@$elm, MP1_CS);
                        print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    }
                    if (@$elm[M_RW] != MA_RW1) {
                        $port_nm = &get_mem_portnm(\@$elm, MP1_WA);
                        print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                        $port_nm = &get_mem_portnm(\@$elm, MP1_RA);
                        print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                        if (@$elm[M_RE] > 0) {
                            $port_nm = &get_mem_portnm(\@$elm, MP1_RE);
                            print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                        }
                    }
                }
                elsif (@$elm[M_RW] == MA_RW1_W) {
                    $port_nm = &get_mem_portnm(\@$elm, MP1_WA);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    $port_nm = &get_mem_portnm(\@$elm, MP1_WD);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    $port_nm = &get_mem_portnm(\@$elm, MP1_WE);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                }
                elsif (@$elm[M_RW] == MA_RW1_R) {
                    $port_nm = &get_mem_portnm(\@$elm, MP1_RA);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    $port_nm = &get_mem_portnm(\@$elm, MP1_RD);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    if (@$elm[M_RE] > 0) {
                        $port_nm = &get_mem_portnm(\@$elm, MP1_RE);
                        print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    }
                }
                elsif (@$elm[M_RW] == MA_R1W1_W) {
                    $port_nm = &get_mem_portnm(\@$elm, MP2_WA);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    $port_nm = &get_mem_portnm(\@$elm, MP2_WD);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    $port_nm = &get_mem_portnm(\@$elm, MP2_WE);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    if (@$elm[M_CS] > 0) {
                        $port_nm = &get_mem_portnm(\@$elm, MP2_CS);
                        print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    }
                    if (@$elm[M_BE] > 0) {
                        $port_nm = &get_mem_portnm(\@$elm, MP2_BE);
                        print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    }
                }
                elsif (@$elm[M_RW] == MA_R1W1_R) {
                    $port_nm = &get_mem_portnm(\@$elm, MP2_RA);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    $port_nm = &get_mem_portnm(\@$elm, MP2_RD);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    if (@$elm[M_RE] > 0) {
                        $port_nm = &get_mem_portnm(\@$elm, MP2_RE);
                        print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    }
                }
                elsif (@$elm[M_RW] & MA_DPORT) {
                    $port_nm = &get_mem_portnm(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_AD : MPB_AD);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    $port_nm = &get_mem_portnm(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_WD : MPB_WD);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    $port_nm = &get_mem_portnm(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_RD : MPB_RD);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    $port_nm = &get_mem_portnm(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_WE : MPB_WE);
                    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    if (@$elm[M_CS] > 0) {
                        $port_nm = &get_mem_portnm(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_CS : MPB_CS);
                        print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                    }
                }
                print OUT_H "#endif\n" if (@$elm[M_PONLY] == 0);
            }
        }
    }

    if ($top_mode == 1) {
        foreach $elm (@mod_list) {
            next if(@$elm[MOD_NAME] eq "ctos_clock_gating");
            print OUT_H "#ifdef @$elm[MOD_DBG]\n" if (@$elm[MOD_DBG] ne "");
            print OUT_H "#ifndef @$elm[MOD_MACRO]\n" if (@$elm[MOD_FLG] & FLG_RTL);
            print OUT_H $tab x3, "@$elm[MOD_INST].vcd_trace(tf, depth-1);\n";
            print OUT_H "#endif\n" if (@$elm[MOD_FLG] & FLG_RTL);
            print OUT_H "#endif\n" if (@$elm[MOD_DBG] ne "");
        }
        @mem_used = ();
        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 1);
            my $skip = 0;
            if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                foreach $used (@mem_used) {
                    if ($used eq @$elm[M_NAME]) {
                        $skip = 1;
                        last;
                    }
                }
                push(@mem_used, @$elm[M_NAME]);
            }
            if ($skip == 0 && @$elm[M_SHARE] > 0) {
                if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                    $ifnm = &get_mem_ifnm(\@$elm);
                    print OUT_H "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);
                    print OUT_H $tab x3, "${ifnm}_ins.vcd_trace(tf, depth-1);\n";
                    print OUT_H "#endif\n" if (@$elm[M_PONLY] == 0);
                }
            }
        }
    }
    if ($vcd_trace == 1 || $vcd_trace == 2 || $top_mode == 1) {
        print OUT_H $tab x2, "}\n";
    }
    print OUT_H $tab, "}\n";
    #print OUT_H "#pragma certitude_on\n" if($opt_cer == 1);
    print OUT_H "#endif // !defined(__CTOS__) && !defined(CALYPTO_SYSC) && !defined(STRATUS)\n";
}

##
## print VCD trace function for testbench
##
sub print_tb_vcd_trace_func {
    my $trace_class = $opt_standard ? "sc_trace_file" : "ssgen_trace_file";
    print OUT_TB_H "\n";
    print OUT_TB_H $tab, "$trace_class* m_tf;\n";
    print OUT_TB_H $tab, "void vcd_trace($trace_class* tf) {\n";
    print OUT_TB_H $tab x2, "m_tf = tf;\n";
    print OUT_TB_H $tab x2, "if (tf != 0) {\n";
    print OUT_TB_H $tab x3, "std::string nm = std::string(name());\n";
    foreach $elm (@clk_list) {
        if (@$elm[T_NAME] ne "") {
            print OUT_TB_H $tab x3, "sc_trace(tf, @$elm[T_NAME], nm + \".@$elm[T_NAME]\");\n";
        }
    }
    foreach $elm (@rst_list) {
        if (@$elm[T_TYPE] ne "soft_reset" && @$elm[T_NAME] ne "") {
            print OUT_TB_H $tab x3, "sc_trace(tf, @$elm[T_NAME], nm + \".@$elm[T_NAME]\");\n";
        }
    }
    &print_sc_trace(*OUT_TB_H, \@in_list, 1);
    &print_sc_trace(*OUT_TB_H, \@out_list, 1);
    if ($top_mode == 1) {
        # insert_port
        &print_sc_trace(*OUT_TB_H, \@in_list_insert);
        &print_sc_trace(*OUT_TB_H, \@out_list_insert);
    }
    &print_sc_trace(*OUT_TB_H, \@reg_list_tb);

    my $need = 0;
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        if (@$elm[M_RW] != MA_RW1 && @$elm[M_SHARE] == 0) {
            $need = 1;
            last;
        }
    }
    if ($need == 1) {
        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 1);
            if (@$elm[M_RW] == MA_RW1 || @$elm[M_SHARE] != 0) {
                next;
            }
            print OUT_TB_H "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);

            # write port
            if (@$elm[M_RW] == MA_RW1_R) {
                $port_nm = &get_mem_portnm(\@$elm, MP1_WA);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                $port_nm = &get_mem_portnm(\@$elm, MP1_WD);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                $port_nm = &get_mem_portnm(\@$elm, MP1_WE);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
            }
            elsif (@$elm[M_RW] == MA_R1W1_R) {
                $port_nm = &get_mem_portnm(\@$elm, MP2_WA);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                $port_nm = &get_mem_portnm(\@$elm, MP2_WD);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                $port_nm = &get_mem_portnm(\@$elm, MP2_WE);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                $port_nm = &get_mem_portnm(\@$elm, MP2_CS);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
            }
            # read port
            elsif (@$elm[M_RW] == MA_RW1_W) {
                $port_nm = &get_mem_portnm(\@$elm, MP1_RA);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                $port_nm = &get_mem_portnm(\@$elm, MP1_RD);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                $port_nm = &get_mem_portnm(\@$elm, MP1_RE);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
            }
            elsif (@$elm[M_RW] == MA_R1W1_W) {
                $port_nm = &get_mem_portnm(\@$elm, MP2_RA);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                $port_nm = &get_mem_portnm(\@$elm, MP2_RD);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                $port_nm = &get_mem_portnm(\@$elm, MP2_RE);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
            }
            # dual port
            else {
                $port_nm = &get_mem_portnm(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_AD : MPA_AD);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                $port_nm = &get_mem_portnm(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_WD : MPA_WD);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                $port_nm = &get_mem_portnm(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_RD : MPA_RD);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                $port_nm = &get_mem_portnm(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_WE : MPA_WE);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
                $port_nm = &get_mem_portnm(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPB_CS : MPA_CS);
                print OUT_TB_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
            }
            print OUT_TB_H "#endif\n" if (@$elm[M_PONLY] == 0);
        }
    }
    print OUT_TB_H $tab x2, "}\n";
    print OUT_TB_H $tab, "}\n";
}

##
## print VCD trace function for interface
##
sub print_if_vcd_trace_func {
    print OUT_H "\n";
    print OUT_H "#if !defined(__CTOS__) && !defined(CALYPTO_SYSC) && !defined(STRATUS)\n";
    print OUT_H $tab, "void vcd_trace(ssgen_trace_file* tf, int depth = $hier_max) {\n";
    print OUT_H $tab x2, "if (tf != 0 && depth > 0) {\n";
    print OUT_H $tab x3, "std::string nm = std::string(name());\n";
    print OUT_H "#ifdef $mem_macro\n" if (@$elm[M_PONLY] == 0);
    $port_nm = &get_mem_portnm(\@$elm, MP1_WA);
    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
    $port_nm = &get_mem_portnm(\@$elm, MP1_WE);
    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
    $port_nm = &get_mem_portnm(\@$elm, MP1_RA);
    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
    if (@$elm[M_RE] > 0) {
        $port_nm = &get_mem_portnm(\@$elm, MP1_RE);
        print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
    }
    $port_nm = &get_mem_portnm(\@$elm, MP1_AD);
    print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
    if (@$elm[M_RE] > 0) {
        $port_nm = &get_mem_portnm(\@$elm, MP1_CS);
        print OUT_H $tab x3, "sc_trace(tf, $port_nm, nm + \".$port_nm\");\n";
    }
    print OUT_H "#endif\n" if (@$elm[M_PONLY] == 0);
    print OUT_H $tab x2, "}\n";
    print OUT_H $tab, "}\n";
    print OUT_H "#endif // !defined(__CTOS__) && !defined(CALYPTO_SYSC) && !defined(STRATUS)\n";
}

##
## generate constructor's common part of memory model
##   OUT  : file pointer
##
sub gen_mem_constructor_common {
    local(*OUT) = $_[0];
    print OUT $tab x2, "if (T_LAT < 1 || T_LAT > 4) {\n";
    print OUT $tab x3, "cout << \"memory latency must be from 1 to 4.\" << endl;\n";
    print OUT $tab x3, "sc_assert(1);\n";
    print OUT $tab x3, "exit(0);\n";
    print OUT $tab x2, "}\n";
    print OUT "\n";
    print OUT $tab x2, "T_DATA val = 0;\n";
    print OUT $tab x2, "int wid = val.length();\n";
    print OUT $tab x2, "int num = (wid + 15) >> 4;\n";
    print OUT $tab x2, "if (init > 0) {\n";
    print OUT $tab x3, "val = get_init(num, init);\n";
    print OUT $tab x2, "}\n";
    print OUT $tab x2, "for (int i = 0; i < T_WORD; i++) {\n";
    print OUT $tab x3, "if (init == -1) {\n";
    print OUT $tab x4, "val = get_init(num, init);\n";
    print OUT $tab x3, "}\n";
    print OUT $tab x3, "ptr_mem[i] = val;\n";
    print OUT $tab x2, "}\n";
}

##
## generate initial data function of memory model
##   OUT  : file pointer
##   $sig : signal name
##
sub gen_mem_init_data_func {
    local(*OUT) = $_[0];
    print OUT $tab, "T_DATA get_init(int num, int init) {\n";
    print OUT "#ifndef _USE_AC\n";
    print OUT "#define DATA16 sc_biguint<16>\n";
    print OUT "#else\n";
    print OUT "#define DATA16 ac_int<16,false>\n";
    print OUT "#endif\n";
    print OUT $tab x2, "T_DATA result = 0;\n";
    print OUT $tab x2, "DATA16 part;\n";
    print OUT $tab x2, "for (int i = 0; i < num; i++) {\n";
    print OUT $tab x3, "if (init == -1) {\n";
    print OUT $tab x4, "part = (DATA16)rand();\n";
    print OUT $tab x3, "}\n";
    print OUT $tab x3, "else {\n";
    print OUT $tab x4, "part = (DATA16)init;\n";
    print OUT $tab x3, "}\n";
    print OUT "\n";
    print OUT $tab x3, "if (i == 0) {\n";
    print OUT $tab x4, "result = part;\n";
    print OUT $tab x3, "}\n";
    print OUT $tab x3, "else {\n";
    print OUT $tab x4, "result = result | ((T_DATA)part << (16*i));\n";
    print OUT $tab x3, "}\n";
    print OUT $tab x2, "}\n";
    print OUT $tab x2, "return result;\n";
    print OUT $tab, "}\n";
}

##
## generate oversize check for word depth of memory model
##   OUT  : file pointer
##   $sig : signal name
##   $acc : access type
##
sub gen_mem_sizecheck {
    local(*OUT) = $_[0];
    my $sig = $_[1];
    my $acc = $_[2];
    print OUT $tab x5, "if ($sig.read() >= T_WORD) {\n";
    print OUT $tab x6, "cout << \"[Error @\" << sc_time_stamp()\n";
    print OUT $tab x6, "     << \"] $acc access over size: \"\n";
    print OUT $tab x6, "     << name() << \"'s address = \" << $sig.read() << endl;\n";
    print OUT $tab x6, "sc_stop();\n";
    print OUT $tab x6, "wait();\n";
    print OUT $tab x5, "}\n";
}

##
## generate thread description for 1port of memory model
##   OUT   : file pointer
##   $type : type
##
sub gen_1port_thread {
    local(*OUT) = $_[0];
    my $type = $_[1];

    if ($type == 0) {
        $indx  = "";
        $t_we  = "T_ACTW";
        $t_cs  = "T_ACTC";
        $mp_ad = MP1_AD;
        $mp_wd = MP1_WD;
        $mp_rd = MP1_RD;
        $mp_we = MP1_WE;
        $mp_cs = MP1_CS;
        $schk  = "Read/Write";
    }
    elsif ($type == 1) {
        $indx  = "[0]";
        $t_we  = "T_WEA";
        $t_cs  = "T_CSA";
        $mp_ad = MPA_AD;
        $mp_wd = MPA_WD;
        $mp_rd = MPA_RD;
        $mp_we = MPA_WE;
        $mp_cs = MPA_CS;
        $schk  = "PortA Read/Write";
    }
    elsif ($type == 2) {
        $indx  = "[1]";
        $t_we  = "T_WEB";
        $t_cs  = "T_CSB";
        $mp_ad = MPB_AD;
        $mp_wd = MPB_WD;
        $mp_rd = MPB_RD;
        $mp_we = MPB_WE;
        $mp_cs = MPB_CS;
        $schk  = "PortB Read/Write";
    }

    print OUT $tab, "void thread_main";
    if ($type == 1) {
        print OUT "1";
    }
    elsif ($type == 2) {
        print OUT "2";
    }
    print OUT "() {\n";
    print OUT $tab x2, "$suf_def[$mp_rd].write(0);\n";
    print OUT $tab x2, "for (int i = 0; i < T_LAT; i++) {\n";
    print OUT $tab x3, "reg_ad${indx}\[i].write(0);\n";
    print OUT $tab x3, "reg_wd${indx}\[i].write(0);\n";
    print OUT $tab x3, "reg_we${indx}\[i].write(!$t_we);\n";
    print OUT $tab x3, "reg_cs${indx}\[i].write(!$t_cs);\n";
    print OUT $tab x2, "}\n";
    print OUT $tab x2, "wait();\n";
    print OUT $tab x2, "while (1) {\n";
    print OUT $tab x3, "if (T_LAT == 1) {\n";
    print OUT $tab x4, "if (T_WORD != 0) {\n";
    &gen_mem_sizecheck(*OUT, $suf_def[$mp_ad], $schk);
    print OUT $tab x4, "}\n";
    print OUT "\n";
    print OUT $tab x4, "if ($suf_def[$mp_cs].read() == $t_cs) {\n";
    print OUT $tab x5, "if ($suf_def[$mp_we].read() == $t_we) {\n";
    print OUT $tab x6, "ptr_mem[(int)$suf_def[$mp_ad].read()] = $suf_def[$mp_wd].read();\n";
    print OUT $tab x5, "}\n";
    print OUT $tab x5, "else {\n";
    print OUT $tab x6, "$suf_def[$mp_rd].write(ptr_mem[(int)$suf_def[$mp_ad].read()]);\n";
    print OUT $tab x5, "}\n";
    print OUT $tab x4, "}\n";
    print OUT $tab x3, "}\n";
    print OUT $tab x3, "else {\n";
    print OUT $tab x4, "reg_ad${indx}\[T_LAT-2].write($suf_def[$mp_ad].read());\n";
    print OUT $tab x4, "reg_wd${indx}\[T_LAT-2].write($suf_def[$mp_wd].read());\n";
    print OUT $tab x4, "reg_we${indx}\[T_LAT-2].write($suf_def[$mp_we].read());\n";
    print OUT $tab x4, "reg_cs${indx}\[T_LAT-2].write($suf_def[$mp_cs].read());\n";
    print OUT "\n";
    print OUT $tab x4, "for (int i = 0; i < T_LAT-2; i++) {\n";
    print OUT $tab x5, "reg_ad${indx}\[i].write(reg_ad${indx}\[i+1].read());\n";
    print OUT $tab x5, "reg_wd${indx}\[i].write(reg_wd${indx}\[i+1].read());\n";
    print OUT $tab x5, "reg_we${indx}\[i].write(reg_we${indx}\[i+1].read());\n";
    print OUT $tab x5, "reg_cs${indx}\[i].write(reg_cs${indx}\[i+1].read());\n";
    print OUT $tab x4, "}\n";
    print OUT "\n";
    print OUT $tab x4, "if (T_WORD != 0) {\n";
    &gen_mem_sizecheck(*OUT, "reg_ad${indx}\[0]", $schk);
    print OUT $tab x4, "}\n";
    print OUT "\n";
    print OUT $tab x4, "if (reg_cs${indx}\[0].read() == $t_cs) {\n";
    print OUT $tab x5, "if (reg_we${indx}\[0].read() == $t_we) {\n";
    print OUT $tab x6, "ptr_mem[(int)reg_ad${indx}\[0].read()] = reg_wd${indx}\[0].read();\n";
    print OUT $tab x5, "}\n";
    print OUT $tab x5, "else {\n";
    print OUT $tab x6, "$suf_def[$mp_rd].write(ptr_mem[(int)reg_ad${indx}\[0].read()]);\n";
    print OUT $tab x5, "}\n";
    print OUT $tab x4, "}\n";
    print OUT $tab x3, "}\n";
    print OUT $tab x3, "wait();\n";
    print OUT $tab x2, "}\n";
    print OUT $tab, "}\n";
}

##
## generate single port memory model
##
sub gen_mem_rw1 {
    if ($need_mem_rw1 == 0) {
        return;
    }

    $outfile = "mem_rw1.h";
    &my_open(*OUT_MEM, "//", "tb", 1);

    print OUT_MEM "#ifndef MEM_RW1_H\n";
    print OUT_MEM "#define MEM_RW1_H\n";
    print OUT_MEM "\n";
    print OUT_MEM "template <typename T_ADDR, typename T_DATA, int T_LAT=1, int T_ACTW=1, int T_ACTC=T_ACTW, int T_WORD=0>\n";
    print OUT_MEM "class mem_rw1 : public sc_module {\n";
    print OUT_MEM "public:\n";
    print OUT_MEM $tab, "sc_in <bool> $suf_def[MP_CLK];\n";
    print OUT_MEM $tab, "sc_in < T_ADDR > $suf_def[MP1_AD];\n";
    print OUT_MEM $tab, "sc_in < T_DATA > $suf_def[MP1_WD];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MP1_WE];\n";
    print OUT_MEM $tab, "sc_out < T_DATA > $suf_def[MP1_RD];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MP1_CS];\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "sc_signal < T_ADDR > reg_ad[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < T_DATA > reg_wd[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < bool > reg_we[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < bool > reg_cs[T_LAT];\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "T_DATA* ptr_mem;\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "SC_HAS_PROCESS(mem_rw1);\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "mem_rw1(sc_module_name nm, T_DATA* ptr, int init = 0)\n";
    print OUT_MEM $tab x2, ": sc_module(nm)\n";
    print OUT_MEM $tab x2, ", $suf_def[MP_CLK](\"$suf_def[MP_CLK]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP1_AD](\"$suf_def[MP1_AD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP1_WD](\"$suf_def[MP1_WD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP1_WE](\"$suf_def[MP1_WE]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP1_RD](\"$suf_def[MP1_RD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP1_CS](\"$suf_def[MP1_CS]\")\n";
    print OUT_MEM $tab x2, ", ptr_mem(ptr)\n";
    print OUT_MEM $tab, "{\n";
    &gen_mem_constructor_common(*OUT_MEM);
    print OUT_MEM "\n";
    print OUT_MEM $tab x2, "SC_CTHREAD(thread_main, $suf_def[MP_CLK].pos());\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "\n";
    &gen_mem_init_data_func(*OUT_MEM);
    print OUT_MEM "\n";
    &gen_1port_thread(*OUT_MEM, 0);
    print OUT_MEM "\n";
    print OUT_MEM $tab, "void vcd_trace(ssgen_trace_file* tf, int depth = $hier_max) {\n";
    print OUT_MEM $tab x2, "if (tf != 0 && depth > 0) {\n";
    print OUT_MEM $tab x3, "std::string nm = std::string(name());\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP_CLK], nm + \".$suf_def[MP_CLK]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP1_AD], nm + \".$suf_def[MP1_AD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP1_WD], nm + \".$suf_def[MP1_WD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP1_WE], nm + \".$suf_def[MP1_WE]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP1_RD], nm + \".$suf_def[MP1_RD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP1_CS], nm + \".$suf_def[MP1_CS]\");\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "};\n";
    print OUT_MEM "\n";
    print OUT_MEM "#endif // MEM_RW1_H\n";
    close(OUT_MEM);
}

##
## generate 2port memory model
##
sub gen_mem_r1w1 {
    if ($need_mem_r1w1 == 0) {
        return;
    }

    $outfile = "mem_r1w1.h";
    &my_open(*OUT_MEM, "//", "tb", 1);

    print OUT_MEM "#ifndef MEM_R1W1_H\n";
    print OUT_MEM "#define MEM_R1W1_H\n";
    print OUT_MEM "\n";
    print OUT_MEM "template <typename T_ADDR, typename T_DATA, int T_LAT=1, int T_ACTW=1, int T_ACTC=T_ACTW, int T_ACTR=T_ACTW, int T_WORD=0>\n";
    print OUT_MEM "class mem_r1w1 : public sc_module {\n";
    print OUT_MEM "public:\n";
    print OUT_MEM $tab, "sc_in <bool> $suf_def[MP_CLK];\n";
    print OUT_MEM $tab, "sc_in < T_ADDR > $suf_def[MP2_WA];\n";
    print OUT_MEM $tab, "sc_in < T_DATA > $suf_def[MP2_WD];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MP2_WE];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MP2_CS];\n";
    print OUT_MEM $tab, "sc_in < T_ADDR > $suf_def[MP2_RA];\n";
    print OUT_MEM $tab, "sc_out < T_DATA > $suf_def[MP2_RD];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MP2_RE];\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "sc_signal < T_ADDR > reg_wa[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < T_DATA > reg_wd[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < bool > reg_we[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < bool > reg_cs[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < T_ADDR > reg_ra[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < bool > reg_re[T_LAT];\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "T_DATA* ptr_mem;\n";
    print OUT_MEM $tab, "T_ADDR  pre_addr;\n";
    print OUT_MEM $tab, "bool    pre_match;\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "SC_HAS_PROCESS(mem_r1w1);\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "mem_r1w1(sc_module_name nm, T_DATA* ptr, int init = 0)\n";
    print OUT_MEM $tab x2, ": sc_module(nm)\n";
    print OUT_MEM $tab x2, ", $suf_def[MP_CLK](\"$suf_def[MP_CLK]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_WA](\"$suf_def[MP2_WA]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_WD](\"$suf_def[MP2_WD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_WE](\"$suf_def[MP2_WE]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_CS](\"$suf_def[MP2_CS]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_RA](\"$suf_def[MP2_RA]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_RD](\"$suf_def[MP2_RD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_RE](\"$suf_def[MP2_RE]\")\n";
    print OUT_MEM $tab x2, ", ptr_mem(ptr)\n";
    print OUT_MEM $tab x2, ", pre_addr(0)\n";
    print OUT_MEM $tab x2, ", pre_match(false)\n";
    print OUT_MEM $tab, "{\n";
    &gen_mem_constructor_common(*OUT_MEM);
    print OUT_MEM "\n";
    print OUT_MEM $tab x2, "SC_CTHREAD(thread_main, $suf_def[MP_CLK].pos());\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "\n";
    &gen_mem_init_data_func(*OUT_MEM);
    print OUT_MEM "\n";
    print OUT_MEM $tab, "void thread_main() {\n";
    print OUT_MEM $tab x2, "$suf_def[MP2_RD].write(0);\n";
    print OUT_MEM $tab x2, "for (int i = 0; i < T_LAT; i++) {\n";
    print OUT_MEM $tab x3, "reg_wa[i].write(0);\n";
    print OUT_MEM $tab x3, "reg_wd[i].write(0);\n";
    print OUT_MEM $tab x3, "reg_we[i].write(!T_ACTW);\n";
    print OUT_MEM $tab x3, "reg_cs[i].write(!T_ACTC);\n";
    print OUT_MEM $tab x3, "reg_ra[i].write(0);\n";
    print OUT_MEM $tab x3, "reg_re[i].write(!T_ACTR);\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab x2, "wait();\n";
    print OUT_MEM $tab x2, "while (1) {\n";
    print OUT_MEM $tab x3, "if (T_LAT == 1) {\n";
    print OUT_MEM $tab x4, "if (T_WORD != 0) {\n";
    &gen_mem_sizecheck(*OUT_MEM, $suf_def[MP2_WA], "Write");
    &gen_mem_sizecheck(*OUT_MEM, $suf_def[MP2_RA], "Read");
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "if ($suf_def[MP2_WE].read() == T_ACTW && $suf_def[MP2_CS].read() == T_ACTC) {\n";
    print OUT_MEM $tab x5, "ptr_mem[(int)$suf_def[MP2_WA].read()] = $suf_def[MP2_WD].read();\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x4, "if ($suf_def[MP2_RE].read() == T_ACTR) {\n";
    print OUT_MEM $tab x5, "$suf_def[MP2_RD].write(ptr_mem[(int)$suf_def[MP2_RA].read()]);\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "// conflict check\n";
    print OUT_MEM $tab x4, "if ($suf_def[MP2_WE].read() == T_ACTW\n";
    print OUT_MEM $tab x4, " && $suf_def[MP2_CS].read() == T_ACTC\n";
    print OUT_MEM $tab x4, " && $suf_def[MP2_RE].read() == T_ACTR\n";
    print OUT_MEM $tab x4, " && $suf_def[MP2_WA].read() == $suf_def[MP2_RA].read()\n";
    print OUT_MEM $tab x4, " && (pre_match == false || pre_addr != $suf_def[MP2_WA].read())) {\n";
    print OUT_MEM $tab x5, "pre_addr = $suf_def[MP2_WA].read();\n";
    print OUT_MEM $tab x5, "pre_match = true;\n";
    print OUT_MEM $tab x5, "cout << \"[Warning @\" << sc_time_stamp()\n";
    print OUT_MEM $tab x5, "     << \"] Read/Write access conflict: \"\n";
    print OUT_MEM $tab x5, "     << name() << \"'s address = \" << $suf_def[MP2_WA].read() << endl;\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x4, "else {\n";
    print OUT_MEM $tab x5, "pre_match =false;\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x3, "}\n";
    print OUT_MEM $tab x3, "else {\n";
    print OUT_MEM $tab x4, "reg_wa[T_LAT-2].write($suf_def[MP2_WA].read());\n";
    print OUT_MEM $tab x4, "reg_wd[T_LAT-2].write($suf_def[MP2_WD].read());\n";
    print OUT_MEM $tab x4, "reg_we[T_LAT-2].write($suf_def[MP2_WE].read());\n";
    print OUT_MEM $tab x4, "reg_cs[T_LAT-2].write($suf_def[MP2_CS].read());\n";
    print OUT_MEM $tab x4, "reg_ra[T_LAT-2].write($suf_def[MP2_RA].read());\n";
    print OUT_MEM $tab x4, "reg_re[T_LAT-2].write($suf_def[MP2_RE].read());\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "for (int i = 0; i < T_LAT-2; i++) {\n";
    print OUT_MEM $tab x5, "reg_wa[i].write(reg_wa[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_wd[i].write(reg_wd[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_we[i].write(reg_we[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_cs[i].write(reg_cs[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_ra[i].write(reg_ra[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_re[i].write(reg_re[i+1].read());\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "if (T_WORD != 0) {\n";
    &gen_mem_sizecheck(*OUT_MEM, "reg_wa[0]", "Write");
    &gen_mem_sizecheck(*OUT_MEM, "reg_ra[0]", "Read");
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "if (reg_we[0].read() == T_ACTW && reg_cs[0].read() == T_ACTC) {\n";
    print OUT_MEM $tab x5, "ptr_mem[(int)reg_wa[0].read()] = reg_wd[0].read();\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x4, "if (reg_re[0].read() == T_ACTR) {\n";
    print OUT_MEM $tab x5, "$suf_def[MP2_RD].write(ptr_mem[(int)reg_ra[0].read()]);\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "// conflict check\n";
    print OUT_MEM $tab x4, "if (reg_we[0].read() == T_ACTW\n";
    print OUT_MEM $tab x4, " && reg_cs[0].read() == T_ACTC\n";
    print OUT_MEM $tab x4, " && reg_re[0].read() == T_ACTR\n";
    print OUT_MEM $tab x4, " && reg_wa[0].read() == reg_ra[0].read()\n";
    print OUT_MEM $tab x4, " && (pre_match == false || pre_addr != reg_wa[0].read())) {\n";
    print OUT_MEM $tab x5, "pre_addr = reg_wa[0].read();\n";
    print OUT_MEM $tab x5, "pre_match = true;\n";
    print OUT_MEM $tab x5, "cout << \"[Warning @\" << sc_time_stamp()\n";
    print OUT_MEM $tab x5, "     << \"] Read/Write access conflict: \"\n";
    print OUT_MEM $tab x5, "     << name() << \"'s address = \" << reg_wa[0].read() << endl;\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x4, "else {\n";
    print OUT_MEM $tab x5, "pre_match =false;\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x3, "}\n";
    print OUT_MEM $tab x3, "wait();\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "void vcd_trace(ssgen_trace_file* tf, int depth = $hier_max) {\n";
    print OUT_MEM $tab x2, "if (tf != 0 && depth > 0) {\n";
    print OUT_MEM $tab x3, "std::string nm = std::string(name());\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP_CLK], nm + \".$suf_def[MP_CLK]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_WA], nm + \".$suf_def[MP2_WA]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_WD], nm + \".$suf_def[MP2_WD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_WE], nm + \".$suf_def[MP2_WE]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_CS], nm + \".$suf_def[MP2_CS]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_RA], nm + \".$suf_def[MP2_RA]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_RD], nm + \".$suf_def[MP2_RD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_RE], nm + \".$suf_def[MP2_RE]\");\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "};\n";
    print OUT_MEM "\n";
    print OUT_MEM "#endif // MEM_R1W1_H\n";
    close(OUT_MEM);
}

##
## generate 2port memory model with 2clock
##
sub gen_mem_r1w1_2clk {
    if ($need_mem_r1w1_2clk == 0) {
        return;
    }

    $outfile = "mem_r1w1_2clk.h";
    &my_open(*OUT_MEM, "//", "tb", 1);

    print OUT_MEM "#ifndef MEM_R1W1_2CLK_H\n";
    print OUT_MEM "#define MEM_R1W1_2CLK_H\n";
    print OUT_MEM "\n";
    print OUT_MEM "template <typename T_ADDR, typename T_DATA, int T_LAT=1, int T_ACTW=1, int T_ACTC=T_ACTW, int T_ACTR=T_ACTW, int T_WORD=0>\n";
    print OUT_MEM "class mem_r1w1_2clk : public sc_module {\n";
    print OUT_MEM "public:\n";
    print OUT_MEM $tab, "sc_in <bool> $suf_def[MP_CLKR];\n";
    print OUT_MEM $tab, "sc_in <bool> $suf_def[MP_CLKW];\n";
    print OUT_MEM $tab, "sc_in < T_ADDR > $suf_def[MP2_WA];\n";
    print OUT_MEM $tab, "sc_in < T_DATA > $suf_def[MP2_WD];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MP2_WE];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MP2_CS];\n";
    print OUT_MEM $tab, "sc_in < T_ADDR > $suf_def[MP2_RA];\n";
    print OUT_MEM $tab, "sc_out < T_DATA > $suf_def[MP2_RD];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MP2_RE];\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "sc_signal < T_ADDR > reg_wa[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < T_DATA > reg_wd[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < bool > reg_we[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < bool > reg_cs[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < T_ADDR > reg_ra[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < bool > reg_re[T_LAT];\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "T_DATA* ptr_mem;\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "SC_HAS_PROCESS(mem_r1w1_2clk);\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "mem_r1w1_2clk(sc_module_name nm, T_DATA* ptr, int init = 0)\n";
    print OUT_MEM $tab x2, ": sc_module(nm)\n";
    print OUT_MEM $tab x2, ", $suf_def[MP_CLKR](\"$suf_def[MP_CLKR]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP_CLKW](\"$suf_def[MP_CLKW]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_WA](\"$suf_def[MP2_WA]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_WD](\"$suf_def[MP2_WD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_WE](\"$suf_def[MP2_WE]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_CS](\"$suf_def[MP2_CS]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_RA](\"$suf_def[MP2_RA]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_RD](\"$suf_def[MP2_RD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_RE](\"$suf_def[MP2_RE]\")\n";
    print OUT_MEM $tab x2, ", ptr_mem(ptr)\n";
    print OUT_MEM $tab, "{\n";
    &gen_mem_constructor_common(*OUT_MEM);
    print OUT_MEM "\n";
    print OUT_MEM $tab x2, "SC_CTHREAD(thread_read, $suf_def[MP_CLKR].pos());\n";
    print OUT_MEM $tab x2, "SC_CTHREAD(thread_write, $suf_def[MP_CLKW].pos());\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "\n";
    &gen_mem_init_data_func(*OUT_MEM);
    print OUT_MEM "\n";
    print OUT_MEM $tab, "void thread_read() {\n";
    print OUT_MEM $tab x2, "$suf_def[MP2_RD].write(0);\n";
    print OUT_MEM $tab x2, "for (int i = 0; i < T_LAT; i++) {\n";
    print OUT_MEM $tab x3, "reg_ra[i].write(0);\n";
    print OUT_MEM $tab x3, "reg_re[i].write(!T_ACTR);\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab x2, "wait();\n";
    print OUT_MEM $tab x2, "while (1) {\n";
    print OUT_MEM $tab x3, "if (T_LAT == 1) {\n";
    print OUT_MEM $tab x4, "if (T_WORD != 0) {\n";
    &gen_mem_sizecheck(*OUT_MEM, $suf_def[MP2_RA], "Read");
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x4, "if ($suf_def[MP2_RE].read() == T_ACTR) {\n";
    print OUT_MEM $tab x5, "$suf_def[MP2_RD].write(ptr_mem[(int)$suf_def[MP2_RA].read()]);\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x3, "}\n";
    print OUT_MEM $tab x3, "else {\n";
    print OUT_MEM $tab x4, "reg_ra[T_LAT-2].write($suf_def[MP2_RA].read());\n";
    print OUT_MEM $tab x4, "reg_re[T_LAT-2].write($suf_def[MP2_RE].read());\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "for (int i = 0; i < T_LAT-2; i++) {\n";
    print OUT_MEM $tab x5, "reg_ra[i].write(reg_ra[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_re[i].write(reg_re[i+1].read());\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "if (T_WORD != 0) {\n";
    &gen_mem_sizecheck(*OUT_MEM, "reg_ra[0]", "Read");
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "if (reg_re[0].read() == T_ACTR) {\n";
    print OUT_MEM $tab x5, "$suf_def[MP2_RD].write(ptr_mem[(int)reg_ra[0].read()]);\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x3, "}\n";
    print OUT_MEM $tab x3, "wait();\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "void thread_write() {\n";
    print OUT_MEM $tab x2, "for (int i = 0; i < T_LAT; i++) {\n";
    print OUT_MEM $tab x3, "reg_wa[i].write(0);\n";
    print OUT_MEM $tab x3, "reg_wd[i].write(0);\n";
    print OUT_MEM $tab x3, "reg_we[i].write(!T_ACTW);\n";
    print OUT_MEM $tab x3, "reg_cs[i].write(!T_ACTC);\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab x2, "wait();\n";
    print OUT_MEM $tab x2, "while (1) {\n";
    print OUT_MEM $tab x3, "if (T_LAT == 1) {\n";
    print OUT_MEM $tab x4, "if (T_WORD != 0) {\n";
    &gen_mem_sizecheck(*OUT_MEM, $suf_def[MP2_WA], "Write");
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "if ($suf_def[MP2_WE].read() == T_ACTW && $suf_def[MP2_CS].read() == T_ACTC) {\n";
    print OUT_MEM $tab x5, "ptr_mem[(int)$suf_def[MP2_WA].read()] = $suf_def[MP2_WD].read();\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x3, "}\n";
    print OUT_MEM $tab x3, "else {\n";
    print OUT_MEM $tab x4, "reg_wa[T_LAT-2].write($suf_def[MP2_WA].read());\n";
    print OUT_MEM $tab x4, "reg_wd[T_LAT-2].write($suf_def[MP2_WD].read());\n";
    print OUT_MEM $tab x4, "reg_we[T_LAT-2].write($suf_def[MP2_WE].read());\n";
    print OUT_MEM $tab x4, "reg_cs[T_LAT-2].write($suf_def[MP2_CS].read());\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "for (int i = 0; i < T_LAT-2; i++) {\n";
    print OUT_MEM $tab x5, "reg_wa[i].write(reg_wa[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_wd[i].write(reg_wd[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_we[i].write(reg_we[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_cs[i].write(reg_cs[i+1].read());\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "if (T_WORD != 0) {\n";
    &gen_mem_sizecheck(*OUT_MEM, "reg_wa[0]", "Write");
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "if (reg_we[0].read() == T_ACTW && reg_cs[0].read() == T_ACTC) {\n";
    print OUT_MEM $tab x5, "ptr_mem[(int)reg_wa[0].read()] = reg_wd[0].read();\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x3, "}\n";
    print OUT_MEM $tab x3, "wait();\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "void vcd_trace(ssgen_trace_file* tf, int depth = $hier_max) {\n";
    print OUT_MEM $tab x2, "if (tf != 0 && depth > 0) {\n";
    print OUT_MEM $tab x3, "std::string nm = std::string(name());\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP_CLKR], nm + \".$suf_def[MP_CLKR]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP_CLKW], nm + \".$suf_def[MP_CLKW]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_WA], nm + \".$suf_def[MP2_WA]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_WD], nm + \".$suf_def[MP2_WD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_WE], nm + \".$suf_def[MP2_WE]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_CS], nm + \".$suf_def[MP2_CS]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_RA], nm + \".$suf_def[MP2_RA]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_RD], nm + \".$suf_def[MP2_RD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_RE], nm + \".$suf_def[MP2_RE]\");\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "};\n";
    print OUT_MEM "\n";
    print OUT_MEM "#endif // MEM_R1W1_2CLK_H\n";
    close(OUT_MEM);
}

##
## generate 2port memory model with write byte enable
##
sub gen_mem_r1w1_be {
    if ($need_mem_r1w1_be == 0) {
        return;
    }

    $outfile = "mem_r1w1_be.h";
    &my_open(*OUT_MEM, "//", "tb", 1);

    print OUT_MEM "#ifndef MEM_R1W1_BE_H\n";
    print OUT_MEM "#define MEM_R1W1_BE_H\n";
    print OUT_MEM "\n";
    print OUT_MEM "template <typename T_ADDR, typename T_DATA, typename T_BYEN, int T_LAT=1, int T_ACTW=1, int T_ACTC=T_ACTW, int T_ACTR=T_ACTW, int T_WORD=0, int T_ACTB=T_ACTW>\n";
    print OUT_MEM "class mem_r1w1_be : public sc_module {\n";
    print OUT_MEM "public:\n";
    print OUT_MEM $tab, "sc_in <bool> $suf_def[MP_CLK];\n";
    print OUT_MEM $tab, "sc_in < T_ADDR > $suf_def[MP2_WA];\n";
    print OUT_MEM $tab, "sc_in < T_DATA > $suf_def[MP2_WD];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MP2_WE];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MP2_CS];\n";
    print OUT_MEM $tab, "sc_in < T_BYEN > $suf_def[MP2_BE];\n";
    print OUT_MEM $tab, "sc_in < T_ADDR > $suf_def[MP2_RA];\n";
    print OUT_MEM $tab, "sc_out < T_DATA > $suf_def[MP2_RD];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MP2_RE];\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "sc_signal < T_ADDR > reg_wa[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < T_DATA > reg_wd[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < bool > reg_we[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < bool > reg_cs[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < T_BYEN > reg_be[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < T_ADDR > reg_ra[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < bool > reg_re[T_LAT];\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "T_DATA* ptr_mem;\n";
    print OUT_MEM $tab, "T_ADDR  pre_addr;\n";
    print OUT_MEM $tab, "bool    pre_match;\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "SC_HAS_PROCESS(mem_r1w1_be);\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "mem_r1w1_be(sc_module_name nm, T_DATA* ptr, int init = 0)\n";
    print OUT_MEM $tab x2, ": sc_module(nm)\n";
    print OUT_MEM $tab x2, ", $suf_def[MP_CLK](\"$suf_def[MP_CLK]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_WA](\"$suf_def[MP2_WA]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_WD](\"$suf_def[MP2_WD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_WE](\"$suf_def[MP2_WE]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_CS](\"$suf_def[MP2_CS]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_BE](\"$suf_def[MP2_BE]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_RA](\"$suf_def[MP2_RA]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_RD](\"$suf_def[MP2_RD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_RE](\"$suf_def[MP2_RE]\")\n";
    print OUT_MEM $tab x2, ", ptr_mem(ptr)\n";
    print OUT_MEM $tab x2, ", pre_addr(0)\n";
    print OUT_MEM $tab x2, ", pre_match(false)\n";
    print OUT_MEM $tab, "{\n";
    &gen_mem_constructor_common(*OUT_MEM);
    print OUT_MEM "\n";
    print OUT_MEM $tab x2, "SC_CTHREAD(thread_main, $suf_def[MP_CLK].pos());\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "\n";
    &gen_mem_init_data_func(*OUT_MEM);
    print OUT_MEM "\n";
    print OUT_MEM $tab, "void thread_main() {\n";
    print OUT_MEM $tab x2, "$suf_def[MP2_RD].write(0);\n";
    print OUT_MEM $tab x2, "for (int i = 0; i < T_LAT; i++) {\n";
    print OUT_MEM $tab x3, "reg_wa[i].write(0);\n";
    print OUT_MEM $tab x3, "reg_wd[i].write(0);\n";
    print OUT_MEM $tab x3, "reg_we[i].write(!T_ACTW);\n";
    print OUT_MEM $tab x3, "reg_cs[i].write(!T_ACTC);\n";
    print OUT_MEM $tab x3, "if (T_ACTB == 1)\n";
    print OUT_MEM $tab x4, "reg_be[i].write(0);\n";
    print OUT_MEM $tab x3, "else\n";
    print OUT_MEM $tab x4, "reg_be[i].write(~0);\n";
    print OUT_MEM $tab x3, "reg_ra[i].write(0);\n";
    print OUT_MEM $tab x3, "reg_re[i].write(!T_ACTR);\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab x2, "wait();\n";
    print OUT_MEM $tab x2, "while (1) {\n";
    print OUT_MEM $tab x3, "if (T_LAT == 1) {\n";
    print OUT_MEM $tab x4, "if (T_WORD != 0) {\n";
    &gen_mem_sizecheck(*OUT_MEM, $suf_def[MP2_WA], "Write");
    &gen_mem_sizecheck(*OUT_MEM, $suf_def[MP2_RA], "Read");
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "if ($suf_def[MP2_WE].read() == T_ACTW && $suf_def[MP2_CS].read() == T_ACTC) {\n";
    print OUT_MEM $tab x5, "T_DATA bit_en = 0;\n";
    print OUT_MEM $tab x5, "for (int i = ($suf_def[MP2_BE].read().length()-1); i >= 0; i--) {\n";
    print OUT_MEM $tab x6, "if ( (($suf_def[MP2_BE].read()>>i)&0x1) == T_ACTB ) {\n";
    print OUT_MEM $tab x7, "bit_en = bit_en | ((T_DATA)0xff<<(i*8));\n";
    print OUT_MEM $tab x6, "}\n";
    print OUT_MEM $tab x5, "}\n";
    print OUT_MEM $tab x5, "ptr_mem[(int)$suf_def[MP2_WA].read()] = (ptr_mem[(int)$suf_def[MP2_WA].read()] & ~bit_en) | ($suf_def[MP2_WD].read() & bit_en);\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x4, "if ($suf_def[MP2_RE].read() == T_ACTR) {\n";
    print OUT_MEM $tab x5, "$suf_def[MP2_RD].write(ptr_mem[(int)$suf_def[MP2_RA].read()]);\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "// conflict check\n";
    print OUT_MEM $tab x4, "if ($suf_def[MP2_WE].read() == T_ACTW\n";
    print OUT_MEM $tab x4, " && $suf_def[MP2_CS].read() == T_ACTC\n";
    print OUT_MEM $tab x4, " && $suf_def[MP2_RE].read() == T_ACTR\n";
    print OUT_MEM $tab x4, " && $suf_def[MP2_WA].read() == $suf_def[MP2_RA].read()\n";
    print OUT_MEM $tab x4, " && (pre_match == false || pre_addr != $suf_def[MP2_WA].read())) {\n";
    print OUT_MEM $tab x5, "pre_addr = $suf_def[MP2_WA].read();\n";
    print OUT_MEM $tab x5, "pre_match = true;\n";
    print OUT_MEM $tab x5, "cout << \"[Warning @\" << sc_time_stamp()\n";
    print OUT_MEM $tab x5, "     << \"] Read/Write access conflict: \"\n";
    print OUT_MEM $tab x5, "     << name() << \"'s address = \" << $suf_def[MP2_WA].read() << endl;\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x4, "else {\n";
    print OUT_MEM $tab x5, "pre_match =false;\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x3, "}\n";
    print OUT_MEM $tab x3, "else {\n";
    print OUT_MEM $tab x4, "reg_wa[T_LAT-2].write($suf_def[MP2_WA].read());\n";
    print OUT_MEM $tab x4, "reg_wd[T_LAT-2].write($suf_def[MP2_WD].read());\n";
    print OUT_MEM $tab x4, "reg_we[T_LAT-2].write($suf_def[MP2_WE].read());\n";
    print OUT_MEM $tab x4, "reg_cs[T_LAT-2].write($suf_def[MP2_CS].read());\n";
    print OUT_MEM $tab x4, "reg_be[T_LAT-2].write($suf_def[MP2_BE].read());\n";
    print OUT_MEM $tab x4, "reg_ra[T_LAT-2].write($suf_def[MP2_RA].read());\n";
    print OUT_MEM $tab x4, "reg_re[T_LAT-2].write($suf_def[MP2_RE].read());\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "for (int i = 0; i < T_LAT-2; i++) {\n";
    print OUT_MEM $tab x5, "reg_wa[i].write(reg_wa[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_wd[i].write(reg_wd[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_we[i].write(reg_we[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_cs[i].write(reg_cs[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_be[i].write(reg_be[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_ra[i].write(reg_ra[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_re[i].write(reg_re[i+1].read());\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "if (T_WORD != 0) {\n";
    &gen_mem_sizecheck(*OUT_MEM, "reg_wa[0]", "Write");
    &gen_mem_sizecheck(*OUT_MEM, "reg_ra[0]", "Read");
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "if (reg_we[0].read() == T_ACTW && reg_cs[0].read() == T_ACTC) {\n";
    print OUT_MEM $tab x5, "T_DATA bit_en = 0;\n";
    print OUT_MEM $tab x5, "for (int i = (reg_be[0].read().length()-1); i >= 0; i--) {\n";
    print OUT_MEM $tab x6, "if ( ((reg_be[0].read()>>i)&0x1) == T_ACTB ) {\n";
    print OUT_MEM $tab x7, "bit_en = bit_en | ((T_DATA)0xff<<(i*8));\n";
    print OUT_MEM $tab x6, "}\n";
    print OUT_MEM $tab x5, "}\n";
    print OUT_MEM $tab x5, "ptr_mem[(int)reg_wa[0].read()] = (ptr_mem[(int)reg_wa[0].read()] & ~bit_en) | (reg_wd[0].read() & bit_en);\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x4, "if (reg_re[0].read() == T_ACTR) {\n";
    print OUT_MEM $tab x5, "$suf_def[MP2_RD].write(ptr_mem[(int)reg_ra[0].read()]);\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "// conflict check\n";
    print OUT_MEM $tab x4, "if (reg_we[0].read() == T_ACTW\n";
    print OUT_MEM $tab x4, " && reg_cs[0].read() == T_ACTC\n";
    print OUT_MEM $tab x4, " && reg_re[0].read() == T_ACTR\n";
    print OUT_MEM $tab x4, " && reg_wa[0].read() == reg_ra[0].read()\n";
    print OUT_MEM $tab x4, " && (pre_match == false || pre_addr != reg_wa[0].read())) {\n";
    print OUT_MEM $tab x5, "pre_addr = reg_wa[0].read();\n";
    print OUT_MEM $tab x5, "pre_match = true;\n";
    print OUT_MEM $tab x5, "cout << \"[Warning @\" << sc_time_stamp()\n";
    print OUT_MEM $tab x5, "     << \"] Read/Write access conflict: \"\n";
    print OUT_MEM $tab x5, "     << name() << \"'s address = \" << reg_wa[0].read() << endl;\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x4, "else {\n";
    print OUT_MEM $tab x5, "pre_match =false;\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x3, "}\n";
    print OUT_MEM $tab x3, "wait();\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "void vcd_trace(ssgen_trace_file* tf, int depth = $hier_max) {\n";
    print OUT_MEM $tab x2, "if (tf != 0 && depth > 0) {\n";
    print OUT_MEM $tab x3, "std::string nm = std::string(name());\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP_CLK], nm + \".$suf_def[MP_CLK]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_WA], nm + \".$suf_def[MP2_WA]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_WD], nm + \".$suf_def[MP2_WD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_WE], nm + \".$suf_def[MP2_WE]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_CS], nm + \".$suf_def[MP2_CS]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_BE], nm + \".$suf_def[MP2_BE]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_RA], nm + \".$suf_def[MP2_RA]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_RD], nm + \".$suf_def[MP2_RD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_RE], nm + \".$suf_def[MP2_RE]\");\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "};\n";
    print OUT_MEM "\n";
    print OUT_MEM "#endif // MEM_R1W1_BE_H\n";
    close(OUT_MEM);
}

##
## generate 2port memory model with 2clock and write byte enable
##
sub gen_mem_r1w1_2clk_be {
    if ($need_mem_r1w1_2clk_be == 0) {
        return;
    }

    $outfile = "mem_r1w1_2clk_be.h";
    &my_open(*OUT_MEM, "//", "tb", 1);

    print OUT_MEM "#ifndef MEM_R1W1_2CLK_BE_H\n";
    print OUT_MEM "#define MEM_R1W1_2CLK_BE_H\n";
    print OUT_MEM "\n";
    print OUT_MEM "template <typename T_ADDR, typename T_DATA, typename T_BYEN, int T_LAT=1, int T_ACTW=1, int T_ACTC=T_ACTW, int T_ACTR=T_ACTW, int T_WORD=0, int T_ACTB=T_ACTW>\n";
    print OUT_MEM "class mem_r1w1_2clk_be : public sc_module {\n";
    print OUT_MEM "public:\n";
    print OUT_MEM $tab, "sc_in <bool> $suf_def[MP_CLKR];\n";
    print OUT_MEM $tab, "sc_in <bool> $suf_def[MP_CLKW];\n";
    print OUT_MEM $tab, "sc_in < T_ADDR > $suf_def[MP2_WA];\n";
    print OUT_MEM $tab, "sc_in < T_DATA > $suf_def[MP2_WD];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MP2_WE];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MP2_CS];\n";
    print OUT_MEM $tab, "sc_in < T_BYEN > $suf_def[MP2_BE];\n";
    print OUT_MEM $tab, "sc_in < T_ADDR > $suf_def[MP2_RA];\n";
    print OUT_MEM $tab, "sc_out < T_DATA > $suf_def[MP2_RD];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MP2_RE];\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "sc_signal < T_ADDR > reg_wa[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < T_DATA > reg_wd[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < bool > reg_we[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < bool > reg_cs[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < T_BYEN > reg_be[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < T_ADDR > reg_ra[T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < bool > reg_re[T_LAT];\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "T_DATA* ptr_mem;\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "SC_HAS_PROCESS(mem_r1w1_2clk_be);\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "mem_r1w1_2clk_be(sc_module_name nm, T_DATA* ptr, int init = 0)\n";
    print OUT_MEM $tab x2, ": sc_module(nm)\n";
    print OUT_MEM $tab x2, ", $suf_def[MP_CLKR](\"$suf_def[MP_CLKR]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP_CLKW](\"$suf_def[MP_CLKW]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_WA](\"$suf_def[MP2_WA]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_WD](\"$suf_def[MP2_WD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_WE](\"$suf_def[MP2_WE]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_CS](\"$suf_def[MP2_CS]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_BE](\"$suf_def[MP2_BE]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_RA](\"$suf_def[MP2_RA]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_RD](\"$suf_def[MP2_RD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP2_RE](\"$suf_def[MP2_RE]\")\n";
    print OUT_MEM $tab x2, ", ptr_mem(ptr)\n";
    print OUT_MEM $tab, "{\n";
    &gen_mem_constructor_common(*OUT_MEM);
    print OUT_MEM "\n";
    print OUT_MEM $tab x2, "SC_CTHREAD(thread_read, $suf_def[MP_CLKR].pos());\n";
    print OUT_MEM $tab x2, "SC_CTHREAD(thread_write, $suf_def[MP_CLKW].pos());\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "\n";
    &gen_mem_init_data_func(*OUT_MEM);
    print OUT_MEM "\n";
    print OUT_MEM $tab, "void thread_read() {\n";
    print OUT_MEM $tab x2, "$suf_def[MP2_RD].write(0);\n";
    print OUT_MEM $tab x2, "for (int i = 0; i < T_LAT; i++) {\n";
    print OUT_MEM $tab x3, "reg_ra[i].write(0);\n";
    print OUT_MEM $tab x3, "reg_re[i].write(!T_ACTR);\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab x2, "wait();\n";
    print OUT_MEM $tab x2, "while (1) {\n";
    print OUT_MEM $tab x3, "if (T_LAT == 1) {\n";
    print OUT_MEM $tab x4, "if (T_WORD != 0) {\n";
    &gen_mem_sizecheck(*OUT_MEM, $suf_def[MP2_RA], "Read");
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x4, "if ($suf_def[MP2_RE].read() == T_ACTR) {\n";
    print OUT_MEM $tab x5, "$suf_def[MP2_RD].write(ptr_mem[(int)$suf_def[MP2_RA].read()]);\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x3, "}\n";
    print OUT_MEM $tab x3, "else {\n";
    print OUT_MEM $tab x4, "reg_ra[T_LAT-2].write($suf_def[MP2_RA].read());\n";
    print OUT_MEM $tab x4, "reg_re[T_LAT-2].write($suf_def[MP2_RE].read());\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "for (int i = 0; i < T_LAT-2; i++) {\n";
    print OUT_MEM $tab x5, "reg_ra[i].write(reg_ra[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_re[i].write(reg_re[i+1].read());\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "if (T_WORD != 0) {\n";
    &gen_mem_sizecheck(*OUT_MEM, "reg_ra[0]", "Read");
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "if (reg_re[0].read() == T_ACTR) {\n";
    print OUT_MEM $tab x5, "$suf_def[MP2_RD].write(ptr_mem[(int)reg_ra[0].read()]);\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x3, "}\n";
    print OUT_MEM $tab x3, "wait();\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "void thread_write() {\n";
    print OUT_MEM $tab x2, "for (int i = 0; i < T_LAT; i++) {\n";
    print OUT_MEM $tab x3, "reg_wa[i].write(0);\n";
    print OUT_MEM $tab x3, "reg_wd[i].write(0);\n";
    print OUT_MEM $tab x3, "reg_we[i].write(!T_ACTW);\n";
    print OUT_MEM $tab x3, "reg_cs[i].write(!T_ACTC);\n";
    print OUT_MEM $tab x3, "if (T_ACTB == 1)\n";
    print OUT_MEM $tab x4, "reg_be[i].write(0);\n";
    print OUT_MEM $tab x3, "else\n";
    print OUT_MEM $tab x4, "reg_be[i].write(~0);\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab x2, "wait();\n";
    print OUT_MEM $tab x2, "while (1) {\n";
    print OUT_MEM $tab x3, "if (T_LAT == 1) {\n";
    print OUT_MEM $tab x4, "if (T_WORD != 0) {\n";
    &gen_mem_sizecheck(*OUT_MEM, $suf_def[MP2_WA], "Write");
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "if ($suf_def[MP2_WE].read() == T_ACTW && $suf_def[MP2_CS].read() == T_ACTC) {\n";
    print OUT_MEM $tab x5, "T_DATA bit_en = 0;\n";
    print OUT_MEM $tab x5, "for (int i = ($suf_def[MP2_BE].read().length()-1); i >= 0; i--) {\n";
    print OUT_MEM $tab x6, "if ( (($suf_def[MP2_BE].read()>>i)&0x1) == T_ACTB ) {\n";
    print OUT_MEM $tab x7, "bit_en = bit_en | ((T_DATA)0xff<<(i*8));\n";
    print OUT_MEM $tab x6, "}\n";
    print OUT_MEM $tab x5, "}\n";
    print OUT_MEM $tab x5, "ptr_mem[(int)$suf_def[MP2_WA].read()] = (ptr_mem[(int)$suf_def[MP2_WA].read()] & ~bit_en) | ($suf_def[MP2_WD].read() & bit_en);\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x3, "}\n";
    print OUT_MEM $tab x3, "else {\n";
    print OUT_MEM $tab x4, "reg_wa[T_LAT-2].write($suf_def[MP2_WA].read());\n";
    print OUT_MEM $tab x4, "reg_wd[T_LAT-2].write($suf_def[MP2_WD].read());\n";
    print OUT_MEM $tab x4, "reg_we[T_LAT-2].write($suf_def[MP2_WE].read());\n";
    print OUT_MEM $tab x4, "reg_cs[T_LAT-2].write($suf_def[MP2_CS].read());\n";
    print OUT_MEM $tab x4, "reg_be[T_LAT-2].write($suf_def[MP2_BE].read());\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "for (int i = 0; i < T_LAT-2; i++) {\n";
    print OUT_MEM $tab x5, "reg_wa[i].write(reg_wa[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_wd[i].write(reg_wd[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_we[i].write(reg_we[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_cs[i].write(reg_cs[i+1].read());\n";
    print OUT_MEM $tab x5, "reg_be[i].write(reg_be[i+1].read());\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "if (T_WORD != 0) {\n";
    &gen_mem_sizecheck(*OUT_MEM, "reg_wa[0]", "Write");
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab x4, "if (reg_we[0].read() == T_ACTW && reg_cs[0].read() == T_ACTC) {\n";
    print OUT_MEM $tab x5, "T_DATA bit_en = 0;\n";
    print OUT_MEM $tab x5, "for (int i = (reg_be[0].read().length()-1); i >= 0; i--) {\n";
    print OUT_MEM $tab x6, "if ( ((reg_be[0].read()>>i)&0x1) == T_ACTB ) {\n";
    print OUT_MEM $tab x7, "bit_en = bit_en | ((T_DATA)0xff<<(i*8));\n";
    print OUT_MEM $tab x6, "}\n";
    print OUT_MEM $tab x5, "}\n";
    print OUT_MEM $tab x5, "ptr_mem[(int)reg_wa[0].read()] = (ptr_mem[(int)reg_wa[0].read()] & ~bit_en) | (reg_wd[0].read() & bit_en);\n";
    print OUT_MEM $tab x4, "}\n";
    print OUT_MEM $tab x3, "}\n";
    print OUT_MEM $tab x3, "wait();\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "void vcd_trace(ssgen_trace_file* tf, int depth = $hier_max) {\n";
    print OUT_MEM $tab x2, "if (tf != 0 && depth > 0) {\n";
    print OUT_MEM $tab x3, "std::string nm = std::string(name());\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP_CLKR], nm + \".$suf_def[MP_CLKR]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP_CLKW], nm + \".$suf_def[MP_CLKW]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_WA], nm + \".$suf_def[MP2_WA]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_WD], nm + \".$suf_def[MP2_WD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_WE], nm + \".$suf_def[MP2_WE]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_CS], nm + \".$suf_def[MP2_CS]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_BE], nm + \".$suf_def[MP2_BE]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_RA], nm + \".$suf_def[MP2_RA]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_RD], nm + \".$suf_def[MP2_RD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP2_RE], nm + \".$suf_def[MP2_RE]\");\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "};\n";
    print OUT_MEM "\n";
    print OUT_MEM "#endif // MEM_R1W1_2CLK_BE_H\n";
    close(OUT_MEM);
}

##
## generate dual port memory model
##
sub gen_mem_rw2 {
    if ($need_mem_rw2 == 0) {
        return;
    }

    $outfile = "mem_rw2.h";
    &my_open(*OUT_MEM, "//", "tb", 1);

    print OUT_MEM "#ifndef MEM_RW2_H\n";
    print OUT_MEM "#define MEM_RW2_H\n";
    print OUT_MEM "\n";
    print OUT_MEM "template <typename T_ADDR, typename T_DATA, int T_LAT=1, int T_WEA=1, int T_CSA=1, int T_WEB=1, int T_CSB=1, int T_WORD=0>\n";
    print OUT_MEM "class mem_rw2 : public sc_module {\n";
    print OUT_MEM "public:\n";
    print OUT_MEM $tab, "sc_in <bool> $suf_def[MP_CLKA];\n";
    print OUT_MEM $tab, "sc_in < T_ADDR > $suf_def[MPA_AD];\n";
    print OUT_MEM $tab, "sc_in < T_DATA > $suf_def[MPA_WD];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MPA_WE];\n";
    print OUT_MEM $tab, "sc_out < T_DATA > $suf_def[MPA_RD];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MPA_CS];\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "sc_in <bool> $suf_def[MP_CLKB];\n";
    print OUT_MEM $tab, "sc_in < T_ADDR > $suf_def[MPB_AD];\n";
    print OUT_MEM $tab, "sc_in < T_DATA > $suf_def[MPB_WD];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MPB_WE];\n";
    print OUT_MEM $tab, "sc_out < T_DATA > $suf_def[MPB_RD];\n";
    print OUT_MEM $tab, "sc_in < bool > $suf_def[MPB_CS];\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "sc_signal < T_ADDR > reg_ad[2][T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < T_DATA > reg_wd[2][T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < bool > reg_we[2][T_LAT];\n";
    print OUT_MEM $tab, "sc_signal < bool > reg_cs[2][T_LAT];\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "T_DATA* ptr_mem;\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "SC_HAS_PROCESS(mem_rw2);\n";
    print OUT_MEM "\n";
    print OUT_MEM $tab, "mem_rw2(sc_module_name nm, T_DATA* ptr, int init = 0)\n";
    print OUT_MEM $tab x2, ": sc_module(nm)\n";
    print OUT_MEM $tab x2, ", $suf_def[MP_CLKA](\"$suf_def[MP_CLKA]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MPA_AD](\"$suf_def[MPA_AD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MPA_WD](\"$suf_def[MPA_WD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MPA_WE](\"$suf_def[MPA_WE]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MPA_RD](\"$suf_def[MPA_RD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MPA_CS](\"$suf_def[MPA_CS]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MP_CLKB](\"$suf_def[MP_CLKB]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MPB_AD](\"$suf_def[MPB_AD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MPB_WD](\"$suf_def[MPB_WD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MPB_WE](\"$suf_def[MPB_WE]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MPB_RD](\"$suf_def[MPB_RD]\")\n";
    print OUT_MEM $tab x2, ", $suf_def[MPB_CS](\"$suf_def[MPB_CS]\")\n";
    print OUT_MEM $tab x2, ", ptr_mem(ptr)\n";
    print OUT_MEM $tab, "{\n";
    &gen_mem_constructor_common(*OUT_MEM);
    print OUT_MEM "\n";
    print OUT_MEM $tab x2, "SC_CTHREAD(thread_main1, $suf_def[MP_CLKA].pos());\n";
    print OUT_MEM $tab x2, "SC_CTHREAD(thread_main2, $suf_def[MP_CLKB].pos());\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "\n";
    &gen_mem_init_data_func(*OUT_MEM);
    print OUT_MEM "\n";
    &gen_1port_thread(*OUT_MEM, 1);
    print OUT_MEM "\n";
    &gen_1port_thread(*OUT_MEM, 2);
    print OUT_MEM "\n";
    print OUT_MEM $tab, "void vcd_trace(ssgen_trace_file* tf, int depth = $hier_max) {\n";
    print OUT_MEM $tab x2, "if (tf != 0 && depth > 0) {\n";
    print OUT_MEM $tab x3, "std::string nm = std::string(name());\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP_CLKA], nm + \".$suf_def[MP_CLKA]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MPA_AD], nm + \".$suf_def[MPA_AD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MPA_WD], nm + \".$suf_def[MPA_WD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MPA_WE], nm + \".$suf_def[MPA_WE]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MPA_RD], nm + \".$suf_def[MPA_RD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MPA_CS], nm + \".$suf_def[MPA_CS]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MP_CLKB], nm + \".$suf_def[MP_CLKB]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MPB_AD], nm + \".$suf_def[MPB_AD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MPB_WD], nm + \".$suf_def[MPB_WD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MPB_WE], nm + \".$suf_def[MPB_WE]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MPB_RD], nm + \".$suf_def[MPB_RD]\");\n";
    print OUT_MEM $tab x3, "sc_trace(tf, $suf_def[MPB_CS], nm + \".$suf_def[MPB_CS]\");\n";
    print OUT_MEM $tab x2, "}\n";
    print OUT_MEM $tab, "}\n";
    print OUT_MEM "};\n";
    print OUT_MEM "\n";
    print OUT_MEM "#endif // MEM_RW2_H\n";
    close(OUT_MEM);
}

##
## generate tcl file for ctos
##
sub gen_ctos {
    $outfile = "ctos_" . $module_name . ".tcl";
    my $subdir = $opt_subd ? $opt_ins ? "../src_ins/" : "../src/" : "";
    my $srcfile = $opt_ins ? "_ins.cpp" : ".cpp";
    my $rtldir = $opt_subd ? "../rtl/" : "";
    &my_open(*OUT, "##", "ctos", 0);

    print OUT "# parameters\n";
    print OUT "set PERIOD $ctos_period\n";

    if ($top_mode == 0) {
        print OUT "set INPUT_DELAY 0\n";
        print OUT "set TARGET_LIB $ctos_target_lib\n";
    }
    print OUT "\n";

    print OUT "# set variables\n";
    print OUT "set NAME $module_name\n";
    print OUT "set MODULE /designs/\$NAME/modules/\$NAME\n";
    print OUT "set ARRAY \$MODULE/arrays\n";

    if ($top_mode == 0) {
        print OUT "set BEHAVIOR \$MODULE/behaviors\n";
        print OUT "set PORT \$MODULE/terms\n";
    }

    print OUT "set UTIL /common/appl/Renesas/SystemC/utility/ctos\n";

    print OUT "\n";
    print OUT "# preparation\n";
    print OUT "new_design \$NAME\n";
    if ($top_mode == 0 && $use_aigen == 1) {
        print OUT "set_attr source_files ";
        print OUT "\"$subdir$module_name.cpp $subdir$mod_aigen\_apb_func$srcfile\"";
        print OUT " [get_design]\n";
    }
    else {
        print OUT "set_attr source_files \"$subdir$module_name$srcfile\" [get_design]\n";
    }
    print OUT "set_attr compile_flags \" -w";
    print OUT " -D$mem_macro -I$env_ssgen" if (!$opt_standard);
    print OUT " -D_CTOS_TOP" if ($top_mode == 1);
    print OUT " -I../src/" if($opt_subd && $opt_ins);
    print OUT "\" [get_design]\n";
    print OUT "set_attr top_module_path \$NAME [get_design]\n";
    print OUT "set_attr verilog_rtl_model_suffix \"\" [get_design]\n";
    print OUT "set_attr auto_write_models false [get_design]\n";
    if ($top_mode == 0) {
        if (@thread_list != 0 && $use_valid_thread == 1) {
            print OUT "set_attr low_power_clock_gating true [get_design]\n";
            print OUT "set_attr reset_registers internal [get_design]\n";
        }
        print OUT "set_attr tech_lib_names \$TARGET_LIB [get_design]\n";
        print OUT "set_attr verilog_pragma_keyword \"synopsys\" [get_design]\n";
        if (@thread_list != 0 && $use_valid_thread == 1) {
            print OUT "#set_attr default_scheduling_effort low [get_design]\n";
            print OUT "#set_attr default_speed_grade 90 [get_design]\n";
        }
        print OUT "\n";
        print OUT "# slec attribute\n";
        print OUT "set_attr enable_var_correspondences true [get_design]\n";
        print OUT "#set_attr enable_slec_verification true [get_design]\n";
        print OUT "#set_attr optimize_enable_propagate_function_args false [get_design]\n";
        print OUT "\n";
    }

    if (@thread_list != 0 && $top_mode == 0 && $use_valid_thread == 1) {
        foreach $elm (@clk_list) {
            if (@$elm[T_NAME] ne "") {
                print OUT "define_clock -name @$elm[T_NAME] -period \$PERIOD\n";
            }
        }
    }

    print OUT "build\n";
    print OUT "\n";

    print OUT "# flatten_array\n";
    print OUT "set a_list [ls \$ARRAY]\n";
    print OUT "set b_list {}\n";
    print OUT "foreach a \$a_list {\n";
    print OUT $tab, "set readOnly [get_attr read_only \$ARRAY/\$a]\n";
    print OUT $tab, "if {\$readOnly==0} {\n";
    print OUT $tab x2, "lappend b_list \$ARRAY/\$a\n";
    print OUT $tab, "}\n";
    print OUT "}\n";
    print OUT "\n";
    print OUT "if {\$b_list != \"\"} {\n";
    print OUT $tab, "flatten_array \$b_list\n";
    print OUT "}\n";
    print OUT "\n";
    print OUT "# inline_function\n";
    if ($top_mode == 0 && $ctos_noninline != 0) {
        my $n = 0;
        print OUT "set func_list [ls \$BEHAVIOR]\n";
        print OUT "foreach a \$func_list {\n";
        print OUT $tab, "if {";
        foreach $elm (@func_list) {
            my $name = @$elm[F_NAME];
            if(@$elm[F_FLG] & FLG_N_INLINE) {
                print OUT " \$a != \"$name\" ";
                $n++;
                print OUT "&&" if($n < $ctos_noninline);
            }
        }
        foreach $elm (@thread_list) {
            my $name = @$elm[TH_NAME];
            if(@$elm[TH_FLG] & FLG_N_INLINE) {
                print OUT " \$a != \"$wait_name";
                print OUT "_$name" if (@thread_list > 1);
                print OUT "\" ";
                $n++;
                print OUT "&&" if($n < $ctos_noninline);
            }
        }
        print OUT "} {\n";
        print OUT $tab x2, "inline \${BEHAVIOR}/\$a\n";
        print OUT $tab, "} else {\n";
        print OUT $tab x2, "puts \"Non-inlining function '\$a'\"\n";
        print OUT $tab, "}\n";
        print OUT "}\n";
    } else {
        print OUT "inline_calls -all\n";
    }
    print OUT "\n";
    print OUT "# loop_unroll\n";
    print OUT "if {[find_combinational_loops]!=\"\"} {\n";
    print OUT $tab, "unroll_loop [find_combinational_loops]\n";
    print OUT "}\n";
    print OUT "\n";

    if ($top_mode == 0 && @thread_list != 0 && $use_valid_thread == 1) {
        print OUT "# input_delay\n";
        print OUT "if { \$INPUT_DELAY > 0 } {\n";
        print OUT "set port_list  [ls \$PORT]\n";
        print OUT "foreach i_port \$port_list {\n";
        print OUT $tab, "if { [get_attr is_clock \$PORT/\$i_port]==0\n";
        print OUT $tab x2, "&& [regexp [get_attr direction \$PORT/\$i_port] \"in\"]==1 } {\n";
        @ex_rst = ();
        foreach $elm (@rst_list) {
            if (@$elm[T_TYPE] ne "soft_reset") {
                push(@ex_rst, @$elm[T_NAME]);
            }
        }
        for ($i = 0; $i < @ex_rst; $i++) {
            if ($i == 0) {
                print OUT $tab x2, "if {";
            }
            else {
                print OUT $tab x3, "&& ";
            }
            print OUT "[regexp \"$ex_rst[$i]\" \$i_port] == 0";
            if ($i == $#ex_rst) {
                print OUT "} {";
            }
            print OUT "\n";
        }
        &get_valid_clock(\$clk_data);
        print OUT $tab x3, "puts \"set_input_delay \$i_port \$INPUT_DELAY\\ps\"\n";
        print OUT $tab x3, "external_delay -input \$INPUT_DELAY -clock @$clk_data[T_NAME]";
        print OUT " -edge rise \$PORT/\$i_port\n";
        print OUT $tab x2, "}\n" if (@ex_rst > 0);
        print OUT $tab, "}\n";
        print OUT "}\n";
        print OUT "}\n";
        print OUT "\n";

        foreach $elm(@thread_list) {
            next if (@$elm[TH_FLG] & FLG_DUMMY);
            if (@$elm[TH_FLG] & FLG_PIPE) {
                print OUT "# pipeline @$elm[TH_NAME]\n";
                print OUT "set LATENCY_", uc @$elm[TH_NAME], " @$elm[TH_LAT]\n";
                print OUT "set EXPAND_BEFORE_NET # specify net name here\n";
                print OUT "pipeline_loop -init_interval 1 \\\n";
                print OUT "  -min_lat_interval 2 \\\n";
                print OUT "  -max_lat_interval \${LATENCY_", uc @$elm[TH_NAME], "} \\\n";
                print OUT "  -expand_before [find -net \$EXPAND_BEFORE_NET] \\\n";
                print OUT "  \${BEHAVIOR}/\${NAME}_@$elm[TH_NAME]/nodes/@$elm[TH_MACRO]_while_begin\n";
                print OUT "\n";
            }
        }

        print OUT "# scheduling effort\n";
        foreach $elm(@thread_list) {
            print OUT "#set_attr scheduling_effort low \${BEHAVIOR}/\${NAME}_@$elm[TH_NAME]\n";
        }
        print OUT "\n";

        print OUT "# synthesis\n";
        print OUT "schedule\n";
        print OUT "allocate_registers\n";
        print OUT "\n";
    }

    print OUT "# write files\n";
    if ($top_mode == 0) {
        print OUT "write_rtl -non_recursive -slec slec_\${NAME}.tcl -file $rtldir\${NAME}.v \$MODULE \n";
    }
    else {
        print OUT "write_rtl -non_recursive -file $rtldir\${NAME}.v \$MODULE \n";
    }

    if ($top_mode == 0) {
        print OUT "\n";
        print OUT "# make reports\n";
        print OUT "file mkdir ./reports_\${NAME}\n";
        print OUT "report_resources -detail > reports_\${NAME}/report_resources.log\n";
        if (@thread_list != 0 && $use_valid_thread == 1) {
            print OUT "report_schedule > reports_\${NAME}/report_schedule.log\n";
            print OUT "report_timing > reports_\${NAME}/report_timing.log\n";
        }
        print OUT "report_area -detail > reports_\${NAME}/report_area.log\n";
        if (@thread_list != 0 && $use_valid_thread == 1) {
            print OUT "report_registers -detail > reports_\${NAME}/report_registers.log\n";
        }
        print OUT "report_summary > reports_\${NAME}/report_summary.log\n";
        #print OUT "exec \${UTIL}/report_share.pl reports_\${NAME}/report_schedule.log > reports_\${NAME}/report_share.log\n";
        print OUT "source \${UTIL}/report_resource_sharing.tcl\n";
        print OUT "report_resource_sharing reports_\${NAME}/report_share.log\n";
        print OUT "\n";
        print OUT "#save_design -dir SAVE_DESIGN\n";
    }
    print OUT "exit\n";
    close(OUT);

    #$outfile = "run_ctos_$module_name.sh";
    #&my_open(*OUT, "#!", "ctos", 0, "755");
    #print OUT "source $env_ctos\n";
    #print OUT "bs -M 500 -os RHEL5 ctos ctos_$module_name.tcl -log ctos_$module_name.log\n";
    #close(OUT);

    $outfile = "run_ctos.csh";
    &my_open(*OUT, "#!", "ctos", 1, "755");
    #print OUT "${subdir}run_cpp2ins.csh\n\n" if($opt_ins);
    print OUT "source $env_ctos\n";
    print OUT "bs -M 500 -os RHEL5 -tool ctos ctos_lsfsh \${*}\n";
    close(OUT);

    $outfile = "ctos_lsfsh";
    &my_open(*OUT, "#!", "ctos", 1, "755");
    print OUT "set CTS_TCL = ()\n";
    print OUT "set DEL_PRAGMA = 0\n";
    print OUT "set DEL_DATE   = 0\n";
    print OUT "set SKIP_INS = 0\n";
    print OUT "set TCF = 0\n";
    print OUT "while (\$#argv > 0)\n";
    print OUT $tab, "switch (\$1)\n";
    print OUT $tab, "case -del_pragma:\n";
    print OUT $tab x2, "set DEL_PRAGMA = 1\n";
    print OUT $tab x2, "shift\n";
    print OUT $tab x2, "breaksw\n";
    print OUT $tab, "case -del_date:\n";
    print OUT $tab x2, "set DEL_DATE = 1\n";
    print OUT $tab x2, "shift\n";
    print OUT $tab x2, "breaksw\n";
    print OUT $tab, "case -skip_ins:\n";
    print OUT $tab x2, "set SKIP_INS = 1\n";
    print OUT $tab x2, "shift\n";
    print OUT $tab x2, "breaksw\n";
    print OUT $tab, "case -tcf:\n";
    print OUT $tab x2, "set TCF = 1\n";
    print OUT $tab x2, "shift\n";
    print OUT $tab x2, "breaksw\n";
    print OUT $tab, "default:\n";
    print OUT $tab x2, "set CTS_TCL = (\$CTS_TCL \$1)\n";
    print OUT $tab x2, "shift\n";
    print OUT $tab x2, "breaksw\n";
    print OUT $tab, "endsw\n";
    print OUT "end\n";
    if($opt_ins) {
        print OUT "if ( \$SKIP_INS == 0 ) then\n";
        print OUT $tab, "${subdir}run_cpp2ins.csh\n";
        print OUT $tab, "if ( \$? == 1 ) then\n";
        print OUT $tab x2, "echo \"FAIL ${subdir}run_cpp2ins.csh\"\n";
        print OUT $tab x2, "echo \"Please execute CtoS with -skip_ins first\"\n";
        print OUT $tab x2, "exit 1\n";
        print OUT $tab, "endif\n";
        print OUT "endif\n\n";
    }
    print OUT "if(\$#CTS_TCL == 0) then\n";
    print OUT $tab, "set CTS_TCL = `find . -name \"ctos_*.tcl\"`\n";
    print OUT "endif\n";
    print OUT "\n";
    print OUT "foreach a (\$CTS_TCL)\n";
    print OUT $tab, "if( ! -e \$a ) then\n";
    print OUT $tab x2, "echo \"ERROR: Cannot find \$a !\"\n";
    print OUT $tab x2, "continue\n";
    print OUT $tab, "endif\n\n";
    print OUT $tab, "cp \$a \${a}.bk\n";
    if($opt_ins) {
        print OUT $tab, "if ( \$SKIP_INS == 1 ) then\n";
        print OUT $tab x2, "perl -i -pe 's/_ins\>//g' \$a\n";
        print OUT $tab, "endif\n\n";
    }
    print OUT $tab, "if ( \$TCF == 1 ) then\n";
    print OUT $tab x2, "perl -i -pe 's/-non_recursive/-non_recursive -tcf/g' \$a\n";
    print OUT $tab, "endif\n\n";
    print OUT $tab, "set module = `echo \$a | sed -e \"s/.*\\(ctos_\\)//\" -e \"s/\\.tcl//\"`\n";
    print OUT $tab, "ctos \$a -log ctos_\${module}.log\n";
    print OUT $tab, "if(\$DEL_PRAGMA == 1) then\n";
    print OUT $tab x2, "sed -i -e \"s/\\/\\/\\ pragma\\ .*//g\" -e \"s/\\/\\/\\ synopsys\\ .*//g\" ../rtl/\${module}.v\n";
    print OUT $tab, "endif\n";
    print OUT $tab, "if(\$DEL_DATE == 1) then\n";
    print OUT $tab x2, "sed -i -e \"/^\\/\\/\\ File\\ created\\ on\\ /d\" ../rtl/\${module}.v\n";
    print OUT $tab, "endif\n";
    print OUT $tab, "mv -f \${a}.bk \$a\n";
    print OUT "end\n";
    close(OUT);
}

##
## generate tcl file for ctos of memory interface module
##
sub gen_ctos_memif {
    return if ($top_mode == 0);
    @mem_used = ();
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        my $skip = 0;
        foreach $used (@mem_used) {
            if ($used eq @$elm[M_NAME]) {
                $skip = 1;
                last;
            }
        }
        push(@mem_used, @$elm[M_NAME]);
        if ($skip == 0 && @$elm[M_SHARE] > 0
          && (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W)) {
            $ifnm = &get_mem_ifnm(\@$elm);
            $outfile = "ctos_" . $ifnm . ".tcl";
            my $subdir = $opt_subd ? $opt_ins ? "../src_ins/" : "../src/" : "";
            my $srcfile = $opt_ins ? "_ins.cpp" : ".cpp";
            my $rtldir = $opt_subd ? "../rtl/" : "";
            &my_open(*OUT, "##", "ctos", 0);

            print OUT "# parameters\n";
            print OUT "set PERIOD $ctos_period\n";
            print OUT "set TARGET_LIB $ctos_target_lib\n";
            print OUT "\n";

            print OUT "# set variables\n";
            print OUT "set NAME $ifnm\n";
            print OUT "set MODULE /designs/\$NAME/modules/\$NAME\n";
            print OUT "set ARRAY \$MODULE/arrays\n";
            print OUT "\n";

            print OUT "# preparation\n";
            print OUT "new_design \$NAME\n";
            print OUT "set_attr source_files \"$subdir$ifnm$srcfile\" [get_design]\n";
            print OUT "set_attr compile_flags \" -w -I$env_ssgen";
            print OUT " -I../src/" if($opt_subd && $opt_ins);
            print OUT "\" [get_design]\n";
            print OUT "set_attr top_module_path \$NAME [get_design]\n";
            print OUT "set_attr verilog_rtl_model_suffix \"\" [get_design]\n";
            print OUT "set_attr auto_write_models false [get_design]\n";
            print OUT "set_attr low_power_clock_gating true [get_design]\n";
            print OUT "set_attr tech_lib_names \$TARGET_LIB [get_design]\n";
            print OUT "set_attr reset_registers internal [get_design]\n";
            print OUT "set_attr verilog_pragma_keyword \"synopsys\" [get_design]\n";
            print OUT "build\n";
            print OUT "\n";

            print OUT "# flatten_array\n";
            print OUT "set a_list [ls \$ARRAY]\n";
            print OUT "set b_list {}\n";
            print OUT "foreach a \$a_list {\n";
            print OUT $tab, "set readOnly [get_attr read_only \$ARRAY/\$a]\n";
            print OUT $tab, "if {\$readOnly==0} {\n";
            print OUT $tab x2, "lappend b_list \$ARRAY/\$a\n";
            print OUT $tab, "}\n";
            print OUT "}\n";
            print OUT "\n";
            print OUT "if {\$b_list != \"\"} {\n";
            print OUT $tab, "flatten_array \$b_list\n";
            print OUT "}\n";
            print OUT "\n";
            print OUT "# inline_function\n";
            print OUT "inline_calls -all\n";
            print OUT "\n";
            print OUT "# loop_unroll\n";
            print OUT "if {[find_combinational_loops]!=\"\"} {\n";
            print OUT $tab, "unroll_loop [find_combinational_loops]\n";
            print OUT "}\n";
            print OUT "\n";

            print OUT "# synthesis\n";
            print OUT "schedule\n";
            print OUT "allocate_registers\n";
            print OUT "\n";

            print OUT "# write files\n";
            print OUT "write_rtl -non_recursive -slec slec_\${NAME}.tcl -file $rtldir\${NAME}.v \$MODULE \n";

            print OUT "\n";
            print OUT "# make reports\n";
            print OUT "file mkdir ./reports_\${NAME}\n";
            print OUT "report_resources -detail > reports_\${NAME}/report_resources.log\n";
            print OUT "report_schedule > reports_\${NAME}/report_schedule.log\n";
            print OUT "report_area -detail > reports_\${NAME}/report_area.log\n";
            print OUT "report_registers -detail > reports_\${NAME}/report_registers.log\n";
            print OUT "report_summary > reports_\${NAME}/report_summary.log\n";
            print OUT "\n";
            print OUT "exit\n";
            close(OUT);

            #$outfile = "run_ctos_$ifnm.sh";
            #&my_open(*OUT, "#!", "ctos", 0, "755");
            #print OUT "source $env_ctos\n";
            #print OUT "bs -M 500 -os RHEL5 ctos ctos_$ifnm.tcl -log ctos_$ifnm.log\n";
            #close(OUT);
        }
    }
}

##
## generate tcl file for ctos of synchronizer module
##
sub gen_ctos_sync {
    return if ($top_mode == 0);
    foreach $mod (@mod_list_sync) {
        next if (@$mod[MOD_DBG] ne "");
        $mod_name = @$mod[MOD_NAME];
        $mod_inst = @$mod[MOD_INST];
        $outfile = "ctos_" . $mod_name . ".tcl";
        my $subdir = $opt_subd ? $opt_ins ? "../src_ins/" : "../src/" : "";
        my $srcfile = $opt_ins ? "_ins.cpp" : ".cpp";
        my $rtldir = $opt_subd ? "../rtl/" : "";
        &my_open(*OUT, "##", "ctos", 0);

        print OUT "# parameters\n";
        print OUT "set PERIOD $ctos_period\n";
        print OUT "set INPUT_DELAY 0\n";
        print OUT "set TARGET_LIB $ctos_target_lib\n";
        print OUT "\n";
        print OUT "# set variables\n";
        print OUT "set NAME $mod_name\n";
        print OUT "set MODULE /designs/\$NAME/modules/\$NAME\n";
        print OUT "set BEHAVIOR \$MODULE/behaviors\n";
        print OUT "set PORT \$MODULE/terms\n";
        print OUT "set ARRAY \$MODULE/arrays\n";

        print OUT "\n";
        print OUT "# preparation\n";
        print OUT "new_design \$NAME\n";
        print OUT "set_attr source_files \"$subdir$mod_name$srcfile\" [get_design]\n";
        print OUT "set_attr compile_flags \" -w";
        print OUT " -D$mem_macro -I$env_ssgen" if (!$opt_standard);
        print OUT " -I../src/" if ($opt_subd && $opt_ins);
        print OUT "\" [get_design]\n";
        print OUT "set_attr top_module_path \$NAME [get_design]\n";
        print OUT "set_attr verilog_rtl_model_suffix \"\" [get_design]\n";
        print OUT "set_attr auto_write_models false [get_design]\n";
        print OUT "set_attr low_power_clock_gating true [get_design]\n";
        print OUT "set_attr reset_registers internal [get_design]\n";
        print OUT "set_attr tech_lib_names \$TARGET_LIB [get_design]\n";
        print OUT "set_attr verilog_pragma_keyword \"synopsys\" [get_design]\n";
        print OUT "#set_attr default_scheduling_effort low [get_design]\n";
        print OUT "#set_attr default_speed_grade 90 [get_design]\n";
        print OUT "\n";
        print OUT "# slec attribute\n";
        print OUT "set_attr enable_var_correspondences true [get_design]\n";
        print OUT "#set_attr enable_slec_verification true [get_design]\n";
        print OUT "#set_attr optimize_enable_propagate_function_args false [get_design]\n";
        print OUT "\n";

        foreach $elm (@clk_list_sync) {
            if (@$elm[T_NAME] ne "" && @$elm[T_INST] eq $mod_inst) {
                print OUT "define_clock -name @$elm[T_NAME] -period \$PERIOD\n";
            }
        }

        print OUT "build\n";
        print OUT "\n";

        print OUT "# flatten_array\n";
        print OUT "set a_list [ls \$ARRAY]\n";
        print OUT "set b_list {}\n";
        print OUT "foreach a \$a_list {\n";
        print OUT $tab, "set readOnly [get_attr read_only \$ARRAY/\$a]\n";
        print OUT $tab, "if {\$readOnly==0} {\n";
        print OUT $tab x2, "lappend b_list \$ARRAY/\$a\n";
        print OUT $tab, "}\n";
        print OUT "}\n";
        print OUT "\n";
        print OUT "if {\$b_list != \"\"} {\n";
        print OUT $tab, "flatten_array \$b_list\n";
        print OUT "}\n";
        print OUT "\n";
        print OUT "# inline_function\n";
        print OUT "inline_calls -all\n";
        print OUT "\n";
        print OUT "# loop_unroll\n";
        print OUT "if {[find_combinational_loops]!=\"\"} {\n";
        print OUT $tab, "unroll_loop [find_combinational_loops]\n";
        print OUT "}\n";
        print OUT "\n";

        print OUT "# input_delay\n";
        print OUT "set port_list  [ls \$PORT]\n";
        print OUT "foreach i_port \$port_list {\n";
        print OUT $tab, "if { [get_attr is_clock \$PORT/\$i_port]==0\n";
        print OUT $tab x2, "&& [regexp [get_attr direction \$PORT/\$i_port] \"in\"]==1 } {\n";
        @ex_rst = ();
        foreach $elm (@rst_list_sync) {
            if (@$elm[T_TYPE] ne "soft_reset" && @$elm[T_INST] eq $mod_inst) {
                push(@ex_rst, @$elm[T_NAME]);
            }
        }
        for ($i = 0; $i < @ex_rst; $i++) {
            if ($i == 0) {
                print OUT $tab x2, "if {";
            }
            else {
                print OUT $tab x3, "&& ";
            }
            print OUT "[regexp \"$ex_rst[$i]\" \$i_port] == 0";
            if ($i == $#ex_rst) {
                print OUT "} {";
            }
            print OUT "\n";
        }
        foreach $elm (@clk_list_sync) {
            if (@$elm[T_INST] eq $mod_inst) {
                $clk_name = @$elm[T_NAME];
            }
        }
        print OUT $tab x3, "external_delay -input \$INPUT_DELAY -clock $clk_name";
        print OUT " -edge rise \$PORT/\$i_port\n";
        print OUT $tab x2, "}\n" if (@ex_rst > 0);
        print OUT $tab, "}\n";
        print OUT "}\n";
        print OUT "\n";

        print OUT "# scheduling effort\n";
        print OUT "#set_attr scheduling_effort low \${BEHAVIOR}/\${NAME}_main_thread\n";
        print OUT "\n";

        print OUT "# synthesis\n";
        print OUT "schedule\n";
        print OUT "allocate_registers\n";
        print OUT "\n";

        print OUT "# write files\n";
        print OUT "write_rtl -non_recursive -slec slec_\${NAME}.tcl -file $rtldir\${NAME}.v \$MODULE \n";

        print OUT "\n";
        print OUT "# make reports\n";
        print OUT "file mkdir ./reports_\${NAME}\n";
        print OUT "report_resources -detail > reports_\${NAME}/report_resources.log\n";
        print OUT "report_schedule > reports_\${NAME}/report_schedule.log\n";
        print OUT "report_timing > reports_\${NAME}/report_timing.log\n";
        print OUT "report_area -detail > reports_\${NAME}/report_area.log\n";
        print OUT "report_registers -detail > reports_\${NAME}/report_registers.log\n";
        print OUT "report_summary > reports_\${NAME}/report_summary.log\n";
        print OUT "\n";
        print OUT "#save_design -dir SAVE_DESIGN\n";
        print OUT "exit\n";
        close(OUT);

        #$outfile = "run_ctos_$mod_name.sh";
        #&my_open(*OUT, "#!", "ctos", 0, "755");
        #print OUT "source $env_ctos\n";
        #print OUT "bs -M 500 -os RHEL5 ctos ctos_$mod_name.tcl -log ctos_$mod_name.log\n";
        #close(OUT);
    }
}

##
## generate script file for Stratus
##
sub gen_stratus_scr {
    my $subdir = $opt_subd ? $opt_ins ? "../src_ins/" : "../src/" : "";
    my $srcfile = $opt_ins ? "_ins.cpp" : ".cpp";
    my $rtldir = $opt_subd ? "../rtl/" : "./";

    &gen_stratus_makefile($module_name);
    &gen_stratus_tcl($module_name);

    if ($top_mode == 1) {
        foreach $elm (@mod_list_sync) {
            next if (@$elm[MOD_DBG] ne "");
            &gen_stratus_makefile(@$elm[MOD_NAME]);
            &gen_stratus_tcl(@$elm[MOD_NAME]);
        }
    }

    $outfile = "run_stratus.csh";
    &my_open(*OUT, "#!", "stratus", 1, 755);
    print OUT "source $env_stratus\n\n" if ($opt_stratus);
    print OUT "set BS = \"bs -M 8000 -os RHEL5 -tool ctos\"\n";
    #print OUT "setenv PATH ${def_get_state_node}:${def_get_state_node}/bin:\${PATH}\n";
    print OUT "set GET_STATE_NODE = \"${def_get_state_node}/bin/collect_state_nodes.tcl\"\n";
    print OUT "\n";
    print OUT "set PRJ_TCL = ()\n";
    print OUT "set SKIP_INS = 0\n";
    print OUT "set USED_GUI = 0\n";
    print OUT "set CFG  = \"BASIC\"\n";
    print OUT "\n";
    print OUT "while (\$#argv > 0)\n";
    print OUT $tab, "switch (\$1)\n";
    print OUT $tab, "case -gui:\n";
    print OUT $tab x2, "set USED_GUI = 1\n";
    print OUT $tab x2, "set BS = \"bs -M 20000 -n 2 -os RHEL5 -tool ctos\"\n";
    print OUT $tab x2, "shift\n";
    print OUT $tab x2, "breaksw\n";
    print OUT $tab, "case -skip_ins:\n";
    print OUT $tab x2, "set SKIP_INS = 1\n";
    print OUT $tab x2, "shift\n";
    print OUT $tab x2, "breaksw\n";
    print OUT $tab, "case -cfg:\n";
    print OUT $tab x2, "set CFG = \$2\n";
    print OUT $tab x2, "shift\n";
    print OUT $tab x2, "shift\n";
    print OUT $tab x2, "breaksw\n";
    print OUT $tab, "default:\n";
    print OUT $tab x2, "set PRJ_TCL = (\$PRJ_TCL \$1)\n";
    print OUT $tab x2, "shift\n";
    print OUT $tab x2, "breaksw\n";
    print OUT $tab, "endsw\n";
    print OUT "end\n";
    if($opt_ins) {
        print OUT "\n";
        print OUT "if ( \$SKIP_INS == 0 ) then\n";
        print OUT $tab, "${subdir}run_cpp2ins.csh\n";
        print OUT $tab, "if ( \$? == 1 ) then\n";
        print OUT $tab x2, "echo \"FAIL ${subdir}run_cpp2ins.csh\"\n";
        print OUT $tab x2, "echo \"Please execute Stratus with -skip_ins first\"\n";
        print OUT $tab x2, "exit 1\n";
        print OUT $tab, "endif\n";
        print OUT "endif\n";
    }
    print OUT "\n";
    print OUT "if(\$#PRJ_TCL == 0) then\n";
    print OUT $tab, "set PRJ_TCL = `find . -name \"project_*.tcl\"`\n";
    print OUT "endif\n";
    print OUT "\n";
    print OUT "foreach a (\$PRJ_TCL)\n";
    print OUT $tab, "if( ! -e \$a ) then\n";
    print OUT $tab x2, "echo \"ERROR: Cannot find \$a !\"\n";
    print OUT $tab x2, "continue\n";
    print OUT $tab, "endif\n";
    if($opt_ins) {
        print OUT "\n";
        print OUT $tab, "cp \$a \${a}.bk\n";
        print OUT $tab, "if ( \$SKIP_INS == 1 ) then\n";
        print OUT $tab x2, "perl -i -pe 's/_ins\>//g' \$a\n";
        print OUT $tab, "endif\n";
    }
    print OUT "\n";
    #print OUT $tab, "set module = `echo \$a | sed -e \"s/.*\\(project_\\)//\" -e \"s/\\.tcl//\"`\n";
    print OUT $tab, "set module = `echo \$a:r:t | sed -e 's/project_//'`\n";
    print OUT "\n";
    print OUT $tab, "if ( \$USED_GUI == 1 ) then\n";
    print OUT $tab x2, "cp \$a project.tcl\n";
    print OUT $tab x2, "\$BS stratus_ide\n";
    print OUT $tab, "else\n";
    print OUT $tab x2, "set GSN = `stratus_hls -v | /bin/grep \"stratus_hls \" | head -1`\n";
    print OUT $tab x2, "if ( -e stratus_version ) then\n";
    print OUT $tab x3, "if ( \"\${GSN}\" != `cat stratus_version` ) then\n";
    print OUT $tab x4, "echo \"Stratus version was changed from previous execution\"\n";
    print OUT $tab x4, "echo \"rm -rf bdw_work cachelib Makefile_*.prj\"\n";
    print OUT $tab x4, "rm -rf bdw_work cachelib Makefile_*.prj\n";
    print OUT $tab x3, "else\n";
    print OUT $tab x4, "rm -rf bdw_work/modules/\${module}/\${CFG}\n";
    print OUT $tab x3, "endif\n";
    print OUT $tab x2, "endif\n";
    print OUT $tab x2, "echo \$GSN > stratus_version\n";
    print OUT $tab x2, "\$BS make -f Makefile_\${module}.stratus hls_\${module}_\${CFG}\n";
    print OUT $tab x2, "if ( `grep \"ERROR \\| FATAL\" bdw_work/modules/\${module}/\${CFG}/stratus_hls.log | wc -l` != 0 ) then\n";
    print OUT $tab x3, "echo \"skipped generating RTL because of an error!\"\n";
    print OUT $tab x2, "else if ( `grep \"WARNING 00408\" bdw_work/modules/\${module}/\${CFG}/stratus_hls.log | wc -l` != 0 ) then\n";
    print OUT $tab x3, "echo \"skipped generating RTL because of CRITICAL WARNING (00408)!\"\n";
    print OUT $tab x2, "else\n";
    print OUT $tab x3, "\$BS bdw_export -proj project_\${module}.tcl -dutmodels RTL_V -libmodels RTL_V -combined_file \${module}.v -lsconfig RC_\${module}_\${CFG} $rtldir\n";
    print OUT $tab x3, "cp \$a project.tcl\n";
    print OUT $tab x3, "\$GET_STATE_NODE -m \${module} -c \${CFG} > \${module}_\${CFG}_state_node.txt\n";
    print OUT $tab x2, "endif\n";
    print OUT $tab, "endif\n";
    print OUT $tab, "mv -f \${a}.bk \$a\n" if ($opt_ins);
    print OUT "end\n";
    close(OUT);
}

##
## generate stratus Makefile
##   $mod    : module name
##
sub gen_stratus_makefile {
    $mod = $_[0];
    $outfile = "Makefile_" . $mod . ".stratus";
    &my_open(*OUT, "##", "stratus", 1);
    print OUT "MAKEFILE_PRJ = Makefile_${mod}.prj\n\n";
    print OUT "\$\(MAKEFILE_PRJ\) : project_${mod}.tcl\n";
    print OUT "\t\@bdw_makegen project_${mod}.tcl -o \$\(MAKEFILE_PRJ\)\n\n";
    print OUT "-include \$\(MAKEFILE_PRJ\)\n";
    close(OUT);
}

##
## generate stratus tcl file
##   $mod    : module name
##
sub gen_stratus_tcl {
    $mod = $_[0];

    my $subdir = $opt_subd ? $opt_ins ? "../src_ins/" : "../src/" : "";
    my $srcfile = $opt_ins ? "_ins.cpp" : ".cpp";

    $outfile = "project_" . $mod . ".tcl";
    &my_open(*OUT, "##", "stratus", 0);
    print OUT "# Libraries\n";
    #print OUT "set LIB_PATH    \"[get_install_path]/share/synth/tutorials/tech\"\n";
    #print OUT "set LIB_NAME    \"tutorial.lbr\"\n";
    #print OUT "use_tech_lib    \"\$LIB_PATH/\$LIB_NAME\"\n";
    if ($stratus_target_lib eq "") {
        print OUT "use_tech_lib [exec find [get_install_path] -name \"fast_vdd1v2_basicCells.lib\"]\n";
    } else {
        print OUT "use_tech_lib \"$stratus_target_lib\"\n";
    }
    print OUT "\n";
    print OUT "# Compiler options\n";
    print OUT "set_attr cc_options         \" -g -DSTRATUS -D$mem_macro -I$env_ssgen\"\n";
    print OUT "set_attr hls_cc_options     \" -DSTRATUS -D$mem_macro -I$env_ssgen\"\n";
    print OUT "\n";
    print OUT "# Stratus-HLS options\n";
    print OUT "set_attr clock_period                $stratus_period           ; # Clock period is required\n";
    print OUT "#set_attr cycle_slack                 1.75            ; # Cycle slack margin to help logic synthesis close timing\n";
    print OUT "set_attr balance_expr                delay           ; # Control expression balancing: off, width, delay  default=off\n";
    print OUT "set_attr default_input_delay         0.1             ; # Prevents registering of inputs\n";
    if ($use_pipe == 0 || $top_mode == 1) {
        print OUT "set_attr default_protocol            yes             ; # Defines protocol regions for all I/O accesses in CA synthesis\n";
    }
    print OUT "set_attr dpopt_auto                  \"op,expr\"       ; # Set automatic DPOPT part creation: off, array, op, expr\n";
    print OUT "set_attr dpopt_with_enable           on              ; # Control if enable pins are on DPOPT parts (default=off)\n";
    print OUT "set_attr flatten_arrays              all             ; # Control array flattening: none, all_const, lhs_const, all default=none\n";
    print OUT "#set_attr global_state_encoding       binary          ; # Control FSM state encoding: binary, one_hot  default=binary\n";
    print OUT "#set_attr ignore_cells               \"XYZ* ABC*\"      ; # Define list of cells to ignore\n";
    print OUT "set_attr inline_partial_constants    off             ; # Remove constant portions of variables\n";
    print OUT "set_attr logic_synthesis_command     bdw_runrc       ; #\n";
    print OUT "set_attr lsb_trimming                off             ; # Remove unused LSBs: default=off\n";
    print OUT "set_attr message_detail              0               ; # Detail level in log file: 0, 1, or 2\n";
    print OUT "set_attr method_processing           synthesize      ; # Control SC_METHOD synthesis: default=translate, recommended=synthesize\n";
    print OUT "set_attr output_style_reset_all      on              ; #\n";
    print OUT "set_attr path_delay_limit            140             ; # Prevents long paths through resource sharing muxes (in % of clock period)\n";
    print OUT "set_attr power                       on              ; #\n";
    print OUT "set_attr sched_aggressive_1          off             ; # Turn control into datapath mux: default=off\n";
    print OUT "set_attr sched_aggressive_2          off             ; # Enable helpful scheduling: default=off, recommended=on\n";
    if ($use_pipe ) {
        print OUT "set_attr sched_asap                  off             ; # Create shortest possible schedule: default=off, recommended=off\n";
    } else {
        print OUT "set_attr sched_asap                  on              ; # Create shortest possible schedule: default=off, recommended=off\n";
    }
    print OUT "set_attr output_style_reset_all      on              ; #\n";
    print OUT "set_attr register_fsm_mux_selects    off             ; #\n";
    print OUT "#set_attr unroll_loops                on              ; # Control loop unrolling: default=off\n";
    print OUT "set_attr wireload                    none            ; # Control wireload model used: default=none\n";
    print OUT "set_attr prints                      off             ; #\n";
    print OUT "#set_attr timing_aggression           -4              ; #\n";
    print OUT "\n";
    print OUT "# Synthesis Module Configurations\n";
    print OUT "define_hls_module            ${mod}      $subdir$mod$srcfile\n";
    print OUT "\n";
    print OUT "define_hls_config            ${mod}      BASIC\n";
    print OUT "define_hls_config            ${mod}      BASIC_ZIPOFF       -XCI_zip_off\n";
    if ($use_pipe == 0) {
        print OUT "\ndefine_uarch_tcl {\n";
        print OUT $tab, "foreach a [find -behavior *] {\n";
        print OUT $tab x2, "puts \"preserve_io_signals \$a\"\n";
        print OUT $tab x2, "preserve_io_signals \$a\n";
        print OUT $tab, "}\n";
        print OUT "}\n";
    }
    print OUT "\n";
    print OUT "# Logic Synthesis Configurations\n";
    print OUT "set_logic_synthesis_options      {BDW_LS_CLK_GATING INSRT}\n";
    print OUT "define_logic_synthesis_config    RC_${mod}   \{$mod -all\}   -command bdw_runrc\n";
    close(OUT);
}

##
## generate script file for SLEC
##
sub gen_slec_scr {
    my $subdir = $opt_subd ? $opt_ins ? "../src_ins/" : "../src/" : "";
    my $srcfile = $opt_ins ? "_ins.cpp" : ".cpp";

    my $num = ($opt_stratus) ? 2 : 1;
    #my $num = 1;
    for ($i = 0; $i < $num; $i++) {
        my $pf = ($i == 0) ? "_sc" : "_st";
        if ($top_mode == 1) {
            #message("I009", "", 0,
            #    "-slec option is ignored for hierarchy generation mode");
            foreach $mod (@mod_list_sync) {
                next if (@$mod[MOD_DBG] ne "");
                $mod_name = @$mod[MOD_NAME];
                $mod_inst = @$mod[MOD_INST];

                #$outfile = "slec_${mod_name}_sc.tcl";
                $outfile = "slec_${mod_name}${pf}.tcl";
                &my_open(*OUT, "##", "slec", 0);
                if ($i == 0) {
                    print OUT "set_verification_mode -system_manual -property_checks\n";
                }
                else {
                    print OUT "set_verification_mode -ctos\n";
                }
                print OUT "set_global exit_on_error 1\n";
                print OUT "set_global solver_cache_location none\n";
                print OUT "set_global flop_checking_at_reset concrete\n";
                print OUT "set_global osci_compliant_initial_value 0\n";
                print OUT "set_global ise_only_neg_check 1\n" if ($i==0);
                print OUT "config_trace_files -simdump -auxsignals -dumpmem\n";
                print OUT "\n";
                print OUT "limit -time 2h\n";
                print OUT "\n";
                print OUT "build_design -spec -w";
                print OUT " -I$env_ssgen -D$mem_macro" if (!$opt_standard);
                print OUT " -I../src/" if($opt_subd && $opt_ins);
                print OUT " -I\$env(STRATUS_HOME)/share/stratus/include" if ($opt_stratus);
                print OUT " -DASYNC_RESET_SUPPORT $subdir$mod_name$srcfile\n";
                print OUT "build_design -impl -w";
                if ($i == 0) {
                    print OUT " -I$env_ssgen -D$mem_macro" if (!$opt_standard);
                    print OUT " -I../src/" if($opt_subd && $opt_ins);
                    print OUT " -I\$env(STRATUS_HOME)/share/stratus/include" if ($opt_stratus);
                    print OUT " -DASYNC_RESET_SUPPORT $subdir$mod_name$srcfile\n";
                }
                else {
                    print OUT " ";
                    print OUT "../rtl/" if ($opt_subd);
                    print OUT "${mod_name}.v\n";
                }
                print OUT "\n";
                print OUT "create_waveform -name ACTIVE_HIGH -bitwidth 1 {1}\n";
                print OUT "create_waveform -name ACTIVE_LOW -bitwidth 1 {0}\n";
                print OUT "create_waveform -name ALWAYS_LOW  -bitwidth 1 {0+}\n";
                print OUT "create_waveform -name ALWAYS_HIGH -bitwidth 1 {1+}\n";
                print OUT "\n";
                foreach $rst (@rst_list_sync) {
                    if (@$rst[T_TYPE] ne "soft_reset" && @$rst[T_NAME] ne "" && @$rst[T_INST] eq $mod_inst) {
                        my $act = @$rst[T_INIT] eq "pos" ? "HIGH" : "LOW";
                        my $nonact = @$rst[T_INIT] eq "pos" ? "LOW" : "HIGH";
                        print OUT "create_constraint -reset -waveform ACTIVE_${act} spec.@$rst[T_NAME]\n";
                        print OUT "create_constraint -reset -waveform ACTIVE_${act} impl.@$rst[T_NAME]\n";
                        print OUT "create_constraint -waveform ALWAYS_${nonact} spec.@$rst[T_NAME]\n";
                        print OUT "create_constraint -waveform ALWAYS_${nonact} impl.@$rst[T_NAME]\n";
                        print OUT "\n";
                    }
                }
                print OUT "create_namemap_rule -default\n";
                print OUT "\n";
                print OUT "foreach io {-input -output} {\n";
                print OUT "    foreach spec_var [find -port -spec \$io -short_name -regexp {.*[[0-9]+].*}] {\n";
                print OUT "        set impl_var [regsub -all {\\]\\[} \$spec_var {_}]\n";
                print OUT "        set impl_var [regsub -all {\\[} \$impl_var {_}]\n";
                print OUT "        set impl_var [regsub -all {\\]} \$impl_var {}]\n";
                print OUT "        if { [find -port -impl \$io -short_name \$impl_var] != \"\" } {\n";
                print OUT "            create_map \$io spec.\$spec_var impl.\$impl_var\n";
                print OUT "        }\n";
                print OUT "    }\n";
                print OUT "}\n";
                print OUT "\n";
                print OUT "foreach spec_var [find -inst -sequential -spec -short_name -regexp {.*\\[[0-9]+\\].*}] {\n";
                print OUT "    set impl_var [regsub -all {\\]\\[} \$spec_var {_}]\n";
                print OUT "    set impl_var [regsub -all {\\[} \$impl_var {_}]\n";
                print OUT "    set impl_var [regsub -all {\\]} \$impl_var {}]\n";
                print OUT "    if { [find -signal -impl -short_name \$impl_var] != \"\" } {\n";
                print OUT "        create_map -flop spec.\$spec_var impl.\$impl_var\n";
                print OUT "    }\n";
                print OUT "}\n";
                print OUT "\n";
                print OUT "foreach var [find -inst -seq -spec -hier -short_name -attr \"local_var_attr\"] {\n";
                print OUT "  if { [find -inst -seq -impl -hier -short_name \$var]!=\"\" } {\n";
                print OUT "    unmap -flop spec.\$var impl.\$var\n";
                print OUT "  }\n";
                print OUT "}\n";
                print OUT "\n";
                print OUT "check_properties -spec -prop -abr\n";
                print OUT "check_properties -spec -prop -abw\n";
                print OUT "check_properties -spec -prop -ise\n";
                print OUT "check_properties -spec -prop -umr\n";
                print OUT "check_properties -spec -prop -cas\n";
                print OUT "check_properties -spec -prop -dbz\n";
                print OUT "#check_properties -spec -prop -asc\n";
                print OUT "\n";
                print OUT "foreach prop [find -inst -spec \"prop_*\"] {\n";
                print OUT "  set_reset_value -list \$prop -value 0\n";
                print OUT "}\n";
                print OUT "\n";
                print OUT "verify -mode full_proof\n";
                print OUT "quit\n";
                close(OUT);
                if ($i==0) {
                    $outfile = "slec_${mod_name}_eq.cfg";
                    &my_open(*OUT, "##", "slec", 0);
                    print OUT "# ctos2slec option\n";
                    print OUT "#-map_state_variables\n";
                    print OUT "#-bbox_functions FUNC_NAME0,FUNC_NAME1,...\n";
                    print OUT "\n";
                    print OUT "# slec option\n";
                    print OUT "#limit -time 8h|30m|etc.\n";
                    print OUT "#set_global bit_level_solver_only 1\n";
                    print OUT "#set_global ignore_intermediate_points 1\n";
                    print OUT "#set_global replace_xz_with_constant 0\n";
                    close(OUT);
                }
            }
        }

        $outfile = "slec_${module_name}${pf}.tcl";
        &my_open(*OUT, "##", "slec", 0);
        if ($i == 0) {
            print OUT "set_verification_mode -system_manual -property_checks\n";
        }
        else {
            print OUT "set_verification_mode -ctos\n";
        }
        print OUT "set_global exit_on_error 1\n";
        print OUT "set_global solver_cache_location none\n";
        print OUT "set_global flop_checking_at_reset concrete\n";
        print OUT "set_global osci_compliant_initial_value 0\n";
        print OUT "set_global ise_only_neg_check 1\n" if ($i == 0);
        print OUT "config_trace_files -simdump -auxsignals -dumpmem\n";
        print OUT "\n";
        print OUT "limit -time 2h\n";
        print OUT "\n";
        if ($top_mode == 1) {
            print OUT "set top_module \"$module_name\"\n";
            print OUT "set build_spec_cmd \"build_design -spec -top $module_name -w -I$env_ssgen -D$mem_macro -DASYNC_RESET_SUPPORT";
            print OUT " -I../src/" if($opt_subd && $opt_ins);
            print OUT " -I\$env(STRATUS_HOME)/share/stratus/include" if ($opt_stratus);
            print OUT "\"\n";
            print OUT "foreach a [glob $subdir*.cpp ] {\n";
            print OUT "  append build_spec_cmd \" \" \$a\n";
            print OUT "  set mod [regsub -all {$subdir} \$a {}]\n" if($opt_subd);
            print OUT "  set mod [regsub -all {$srcfile} \$mod {}]\n";
            print OUT "  if { \$mod != \$top_module } {\n";
            print OUT "    set bbox_spec_cmd \"create_black_box -spec -module \$mod\"\n";
            print OUT "    set bbox_impl_cmd \"create_black_box -impl -module \$mod\"\n" if ($i == 0);
            print OUT "    puts \"\$bbox_spec_cmd\"\n";
            print OUT "    eval \$bbox_spec_cmd\n";
            print OUT "    puts \"\$bbox_impl_cmd\"\n" if ($i == 0);
            print OUT "    eval \$bbox_impl_cmd\n" if ($i == 0);
            print OUT "  }\n";
            print OUT "}\n";
            if ($i == 0) {
                print OUT "set build_impl_cmd [regsub -all {spec} \$build_spec_cmd {impl}]\n";
            }
            else {
                print OUT "set build_impl_cmd \"build_design -impl -top $module_name\"\n";
                if($opt_subd) {
                    print OUT "foreach a [glob ../rtl/*.v ] {\n";
                }
                else {
                    print OUT "foreach a [glob *.v ] {\n";
                }
                print OUT "  append build_impl_cmd \" \" \$a\n";
                print OUT "  set mod [regsub -all {../rtl/} \$a {}]\n" if($opt_subd);
                print OUT "  set mod [regsub -all {\\.v} \$mod {}]\n";
                print OUT "  if { \$mod != \$top_module } {\n";
                print OUT "    set bbox_impl_cmd \"create_black_box -impl -module \$mod\"\n";
                print OUT "    puts \"\$bbox_impl_cmd\"\n";
                print OUT "    eval \$bbox_impl_cmd\n";
                print OUT "  }\n";
                print OUT "}\n";
            }
            print OUT "puts \"\$build_spec_cmd\"\n";
            print OUT "eval \$build_spec_cmd\n";
            print OUT "puts \"\$build_impl_cmd\"\n";
            print OUT "eval \$build_impl_cmd\n";
            print OUT "\n";
        }
        else {
            if ($i == 1 && $slec_bbox > 0) {
                print OUT "set_global enable_hierarchy_synthesis 1\n\n";
                print OUT "foreach func [list";
                foreach $elm (@func_list) {
                    if (@$elm[F_FLG] & FLG_SLECBB) {
                        print OUT " @$elm[F_NAME]";
                    }
                }
                print OUT "] {\n";
                print OUT "    if { [regexp {\A#} \$func] == 0 } {\n";
                print OUT "        set line [exec grep -n \"::\${func}\" $subdir$module_name$srcfile]\n";
                print OUT "        set line [regsub {:.*} \$line {}]\n";
                print OUT "        mark_hierarchy -spec -file $subdir$module_name$srcfile -line \$line\n";
                print OUT "        set_global __cpt_eval_forbidden_hier_boundaries \"\$func [get_global __cpt_eval_forbidden_hier_boundaries]\"\n";
                print OUT "    }\n";
                print OUT "}\n";
            }
            print OUT "build_design -spec -w";
            print OUT " -top $module_name" if ($use_template == 1);
            print OUT " -I$env_ssgen -D$mem_macro" if (!$opt_standard);
            print OUT " -I../src/" if ($opt_subd && $opt_ins);
            print OUT " -I\$env(STRATUS_HOME)/share/stratus/include" if ($opt_stratus);
            print OUT " -DASYNC_RESET_SUPPORT $subdir$module_name$srcfile";
            print OUT " $subdir$mod_aigen\_apb_func$srcfile" if ($top_mode == 0 && $use_aigen == 1);
            print OUT "\n";
            print OUT "build_design -impl -w";
            if ($i == 0) {
                print OUT " -top $module_name" if ($use_template == 1);
                print OUT " -I$env_ssgen -D$mem_macro" if (!$opt_standard);
                print OUT " -I../src/" if ($opt_subd && $opt_ins);
                print OUT " -I\$env(STRATUS_HOME)/share/stratus/include" if ($opt_stratus);
                print OUT " -DASYNC_RESET_SUPPORT $subdir$module_name$srcfile";
                print OUT " $subdir$mod_aigen\_apb_func$srcfile" if ($top_mode == 0 && $use_aigen == 1);
            }
            else {
                print OUT " "; 
                print OUT "../rtl/" if ($opt_subd);
                print OUT "${module_name}.v";
            }
            print OUT "\n\n";
        }
        print OUT "create_waveform -name ACTIVE_HIGH -bitwidth 1 {1}\n";
        print OUT "create_waveform -name ACTIVE_LOW -bitwidth 1 {0}\n";
        print OUT "create_waveform -name ALWAYS_LOW  -bitwidth 1 {0+}\n";
        print OUT "create_waveform -name ALWAYS_HIGH -bitwidth 1 {1+}\n";
        print OUT "\n";
        foreach $rst (@rst_list) {
            next if (@$rst[T_FLG] & FLG_PART_RST);
            if (@$rst[T_TYPE] ne "soft_reset" && @$rst[T_NAME] ne "") {
                my $act = @$rst[T_INIT] eq "pos" ? "HIGH" : "LOW";
                my $nonact = @$rst[T_INIT] eq "pos" ? "LOW" : "HIGH";
                print OUT "create_constraint -reset -waveform ACTIVE_${act} spec.@$rst[T_NAME]\n";
                print OUT "create_constraint -reset -waveform ACTIVE_${act} impl.@$rst[T_NAME]\n";
                print OUT "create_constraint -waveform ALWAYS_${nonact} spec.@$rst[T_NAME]\n";
                print OUT "create_constraint -waveform ALWAYS_${nonact} impl.@$rst[T_NAME]\n";
                print OUT "\n";
            }
        }
        if ($top_mode == 0 && $i == 1 && $slec_bbox > 0) {
            print OUT "set_global -if_unchanged ldb_bbox_hierarchies 1\n";
            print OUT "set_global -if_unchanged ldb_case_split_on_state_vars 1\n";
            print OUT "set_global ldb_truly_imply_input_maps_with_valid 0\n";
            print OUT "\n";
        }
        print OUT "create_namemap_rule -default\n";
        print OUT "\n";
        print OUT "foreach io {-input -output} {\n";
        if ($use_template) {
            print OUT "    foreach spec_var [find -port -spec \$io -short_name ] {\n";
            print OUT "        set impl_var [regsub -all {.[a-zA-Z0-9_]+<.*>::} \$spec_var {}]\n";

        }
        else {
            print OUT "    foreach spec_var [find -port -spec \$io -short_name -regexp {.*[[0-9]+].*}] {\n";
        }
        print OUT "        set impl_var [regsub -all {\\]\\[} \$spec_var {_}]\n";
        print OUT "        set impl_var [regsub -all {\\[} \$impl_var {_}]\n";
        print OUT "        set impl_var [regsub -all {\\]} \$impl_var {}]\n";
        print OUT "        if { [find -port -impl \$io -short_name \$impl_var] != \"\" } {\n";
        print OUT "            create_map \$io spec.\$spec_var impl.\$impl_var\n";
        print OUT "        }\n";
        print OUT "    }\n";
        print OUT "}\n";
        print OUT "\n";
        if ($use_template) {
            print OUT "foreach spec_var [find -inst -sequential -spec -short_name ] {\n";
            print OUT "    set impl_var [regsub -all {.[a-zA-Z0-9_]+<.*>::} \$spec_var {}]\n";
        }
        else {
            print OUT "foreach spec_var [find -inst -sequential -spec -short_name -regexp {.*\\[[0-9]+\\].*}] {\n";
        }
        print OUT "    set impl_var [regsub -all {\\]\\[} \$spec_var {_}]\n";
        print OUT "    set impl_var [regsub -all {\\[} \$impl_var {_}]\n";
        print OUT "    set impl_var [regsub -all {\\]} \$impl_var {}]\n";
        print OUT "    if { [find -signal -impl -short_name \$impl_var] != \"\" } {\n";
        print OUT "        create_map -flop spec.\$spec_var impl.\$impl_var\n";
        print OUT "    }\n";
        print OUT "}\n";
        print OUT "\n";
        if ($i == 0) {
            print OUT "foreach var [find -inst -seq -spec -hier -short_name -attr \"local_var_attr\"] {\n";
            print OUT "  if { [find -inst -seq -impl -hier -short_name \$var]!=\"\" } {\n";
            print OUT "    unmap -flop spec.\$var impl.\$var\n";
            print OUT "  }\n";
            print OUT "}\n";
            print OUT "\n";
            print OUT "check_properties -spec -prop -abr\n";
            print OUT "check_properties -spec -prop -abw\n";
            print OUT "check_properties -spec -prop -ise\n";
            print OUT "check_properties -spec -prop -umr\n";
            print OUT "check_properties -spec -prop -cas\n";
            print OUT "check_properties -spec -prop -dbz\n";
            print OUT "#check_properties -spec -prop -asc\n";
            print OUT "\n";
            print OUT "foreach prop [find -inst -spec \"prop_*\"] {\n";
            print OUT "  set_reset_value -list \$prop -value 0\n";
            print OUT "}\n";
            print OUT "\n";
        }
        elsif ($top_mode == 0) {
            if ($slec_bbox > 0) {
                print OUT "set GEN_BBOX_MAP ${def_gen_bbox_map}/gen_bbox_map.pl\n";
                print OUT "exec \${GEN_BBOX_MAP} -m ${module_name} -c \$env(CFG)\n";
                print OUT "\n";
                print OUT "if { [file exists slec_bbox_mapping_${module_name}_\$env(CFG).tcl] == 1 } {\n";
                print OUT $tab, "source slec_bbox_mapping_${module_name}_\$env(CFG).tcl\n";
                print OUT "}\n";
                print OUT "\n";
            }
            print OUT "set GEN_STATE_MAP ${def_gen_state_map}/gen_state_map.pl\n";
            print OUT "exec \${GEN_STATE_MAP}";
            print OUT " slec_output/spec_process_state_controller.xml";
            print OUT " slec_output/spec_trace_record.xml";
            print OUT " ${module_name}_BASIC_state_node.txt\n";
            print OUT "\n";
            print OUT "if { [file exists slec_encoder.tcl] == 1 && [file size slec_encoder.v] != 0 } {\n";
            print OUT $tab, "source slec_encoder.tcl\n";
            print OUT "}\n";
            print OUT "\n";
        }
        print OUT "verify -mode full_proof\n";
        print OUT "quit\n";
        close(OUT);

        $outfile = "run_slec${pf}.csh";
        &my_open(*OUT, "#!", "slec", 1, "755");
        #print OUT "${subdir}run_cpp2ins.csh\n\n" if($opt_ins);
        print OUT "source $env_slec\n";
        print OUT "source $env_stratus\n" if ($opt_stratus);
        print OUT "bs -os RHEL5 -M 500 -tool slec slec${pf}_lsfsh \${*}\n";
        close(OUT);

        $outfile = "slec${pf}_lsfsh";
        &my_open(*OUT, "#!", "slec", 1, "755");
        #print OUT "set SLEC_TCL = (\$argv)\n";
        print OUT "set SLEC_TCL = ()\n";
        print OUT "set SKIP_INS = 0\n";
        print OUT "setenv CFG \"BASIC\"\n" if ($i == 1);
        print OUT "while (\$#argv > 0)\n";
        print OUT $tab, "switch (\$1)\n";
        print OUT $tab, "case -skip_ins:\n";
        print OUT $tab x2, "set SKIP_INS = 1\n";
        print OUT $tab x2, "shift\n";
        print OUT $tab x2, "breaksw\n";
        if ($i == 1) {
            print OUT $tab, "case -cfg:\n";
            print OUT $tab x2, "setenv CFG \$2\n"; 
            print OUT $tab x2, "shift\n";
            print OUT $tab x2, "shift\n";
            print OUT $tab x2, "breaksw\n";
        }
        print OUT $tab, "default:\n";
        print OUT $tab x2, "set SLEC_TCL = (\$SLEC_TCL \$1)\n";
        print OUT $tab x2, "shift\n";
        print OUT $tab x2, "breaksw\n";
        print OUT $tab, "endsw\n";
        print OUT "end\n";
        if($opt_ins) {
            print OUT "if ( \$SKIP_INS == 0 ) then\n";
            print OUT $tab, "${subdir}run_cpp2ins.csh\n";
            print OUT $tab, "if ( \$? == 1 ) then\n";
            print OUT $tab x2, "echo \"FAIL ${subdir}run_cpp2ins.csh\"\n";
            print OUT $tab x2, "echo \"Please execute SLEC with -skip_ins first\"\n";
            print OUT $tab x2, "exit 1\n";
            print OUT $tab, "endif\n";
            print OUT "endif\n\n";
        }
        print OUT "if(\$#SLEC_TCL == 0) then\n";
        print OUT $tab, "set SLEC_TCL = `find . -name \"slec_*${pf}.tcl\"`\n";
        print OUT "endif\n";
        print OUT "\n";
        print OUT "foreach a (\$SLEC_TCL)\n";
        print OUT $tab, "if( ! -e \$a ) then\n";
        print OUT $tab x2, "echo \"ERROR: Cannot find \$a !\"\n";
        print OUT $tab x2, "continue\n";
        print OUT $tab, "endif\n\n";
        if($opt_ins) {
            print OUT $tab, "cp \$a \${a}.bk\n";
            print OUT $tab, "if ( \$SKIP_INS == 1 ) then\n";
            print OUT $tab x2, "perl -i -pe 's/_ins\>//g' \$a\n";
            print OUT $tab, "endif\n\n";
        }
        print OUT $tab, "set module = `echo \$a | sed -e \"s/.*\\(slec_\\)//\" -e \"s/${pf}\\.tcl//\"`\n";
        if ($i == 1) {
            if ($opt_subd) {
                print OUT $tab, "if (-l \${module}_\${CFG}_state_node.txt) then\n";
                print OUT $tab x2, "rm -f \${module}_\${CFG}_state_node.txt\n";
                print OUT $tab, "endif\n";
                print OUT $tab, "ln -s ../stratus/\${module}_\${CFG}_state_node.txt\n";
            }
            print OUT $tab, "if (\$CFG != \"BASIC\") then\n";
            print OUT $tab x2, "cp \$a \${a}.bk\n" if ($opt_ins == 0);
            print OUT $tab x2, "sed -i 's/BASIC/'\$CFG'/' slec_\${module}_st.tcl\n";
            print OUT $tab, "endif\n";
        }
        print OUT $tab, "slec \$a -w calypto_\${module}${pf} -l slec_\${module}${pf}.log -queuelic\n";
        if ($opt_ins) {
            print OUT $tab, "mv -f \${a}.bk \$a\n";
        }
        elsif ($i==1) {
            print OUT $tab, "if (\$CFG != \"BASIC\") then\n";
            print OUT $tab x2, "mv -f \${a}.bk \$a\n";
            print OUT $tab, "endif\n";
        }
        print OUT "end\n";
        print OUT "unsetenv CFG\n" if ($i == 1);
        close(OUT);
    }

    if ($opt_stratus && $slec_bbox > 0) {
        $outfile = "slec_bbox_${module_name}_BASIC.list";
        &my_open(*OUT, "##", "slec", 0);
        foreach $elm (@func_list) {
            if (@$elm[F_FLG] & FLG_SLECBB) {
                print OUT "@$elm[F_NAME]\n";
            }
        }
        close(OUT);
    }

    if ($top_mode == 1) {
        $outfile = "slec_${module_name}_eq.tcl";
        &my_open(*OUT, "##", "slec", 0);
        print OUT "set_verification_mode -ctos\n";
        print OUT "set_global exit_on_error 1\n";
        print OUT "set_global solver_cache_location none\n";
        print OUT "set_global flop_checking_at_reset concrete\n";
        print OUT "set_global osci_compliant_initial_value 0\n";
        print OUT "config_trace_files -simdump -auxsignals -dumpmem\n";
        print OUT "\n";
        print OUT "limit -time 2h\n";
        print OUT "\n";
        print OUT "set top_module \"$module_name\"\n";
        &my_open(*OUT, "##", "slec", 0);
        print OUT "set_verification_mode -ctos\n";
        print OUT "set_global exit_on_error 1\n";
        print OUT "set_global solver_cache_location none\n";
        print OUT "set_global flop_checking_at_reset concrete\n";
        print OUT "set_global osci_compliant_initial_value 0\n";
        print OUT "config_trace_files -simdump -auxsignals -dumpmem\n";
        print OUT "\n";
        print OUT "limit -time 2h\n";
        print OUT "\n";
        print OUT "set top_module \"$module_name\"\n";
        print OUT "set build_spec_cmd \"build_design -spec -top $module_name -w -I$env_ssgen -D$mem_macro -DASYNC_RESET_SUPPORT";
        print OUT " -I../src/" if($opt_subd && $opt_ins);
        print OUT "\"\n";
        print OUT "foreach a [glob $subdir*.cpp ] {\n";
        print OUT "  append build_spec_cmd \" \" \$a\n";
        print OUT "  set mod [regsub -all {$subdir} \$a {}]\n" if($opt_subd);
        print OUT "  set mod [regsub -all {$srcfile} \$mod {}]\n";
        print OUT "  if { \$mod != \$top_module } {\n";
        print OUT "    set bbox_spec_cmd \"create_black_box -spec -module \$mod\"\n";
        print OUT "    puts \"\$bbox_spec_cmd\"\n";
        print OUT "    eval \$bbox_spec_cmd\n";
        print OUT "  }\n";
        print OUT "}\n";
        print OUT "set build_impl_cmd \"build_design -impl -top $module_name\"\n";
        if($opt_subd) {
            print OUT "foreach a [glob ../rtl/*.v ] {\n";
        }
        else {
            print OUT "foreach a [glob *.v ] {\n";
        }
        print OUT "  append build_impl_cmd \" \" \$a\n";
        print OUT "  set mod [regsub -all {../rtl/} \$a {}]\n" if($opt_subd);
        print OUT "  set mod [regsub -all {\\.v} \$mod {}]\n";
        print OUT "  if { \$mod != \$top_module } {\n";
        print OUT "    set bbox_impl_cmd \"create_black_box -impl -module \$mod\"\n";
        print OUT "    puts \"\$bbox_impl_cmd\"\n";
        print OUT "    eval \$bbox_impl_cmd\n";
        print OUT "  }\n";
        print OUT "}\n";
        print OUT "puts \"\$build_spec_cmd\"\n";
        print OUT "eval \$build_spec_cmd\n";
        print OUT "puts \"\$build_impl_cmd\"\n";
        print OUT "eval \$build_impl_cmd\n";
        print OUT "\n";
        print OUT "create_waveform -name ACTIVE_HIGH -bitwidth 1 {1}\n";
        print OUT "create_waveform -name ACTIVE_LOW -bitwidth 1 {0}\n";
        print OUT "create_waveform -name ALWAYS_LOW  -bitwidth 1 {0+}\n";
        print OUT "create_waveform -name ALWAYS_HIGH -bitwidth 1 {1+}\n";
        print OUT "\n";
        foreach $rst (@rst_list) {
            if (@$rst[T_TYPE] ne "soft_reset" && @$rst[T_NAME] ne "") {
                my $act = @$rst[T_INIT] eq "pos" ? "HIGH" : "LOW";
                my $nonact = @$rst[T_INIT] eq "pos" ? "LOW" : "HIGH";
                print OUT "create_constraint -reset -waveform ACTIVE_${act} spec.@$rst[T_NAME]\n";
                print OUT "create_constraint -reset -waveform ACTIVE_${act} impl.@$rst[T_NAME]\n";
                print OUT "create_constraint -waveform ALWAYS_${nonact} spec.@$rst[T_NAME]\n";
                print OUT "create_constraint -waveform ALWAYS_${nonact} impl.@$rst[T_NAME]\n";
                print OUT "\n";
            }
        }
        print OUT "create_namemap_rule -default\n";
        print OUT "\n";
        my $reg_1d_i = 0;
        my $reg_2d_i = 0;
        my $reg_3d_i = 0;
        my $reg_1d_o = 0;
        my $reg_2d_o = 0;
        my $reg_3d_o = 0;
        foreach $elm (@in_list, @out_list, @reg_list) {
            my $array = @$elm[T_ARRAY];
            if (@$elm[T_NAME] ne "" && $array ne "") {
                my @dim = ();
                while ($array =~ /\w+/g) {
                    push(@dim, $&);
                }
                if(@$elm[T_TYPE] =~ /in/ || @$elm[T_TYPE] =~ /out/) {
                    print OUT "create_map ";
                    print OUT (@$elm[T_TYPE] =~ /out/)? "-output": "-input";
                    print OUT " spec.@$elm[T_NAME]";
                    for ($i = 0; $i < @dim; $i++) {
                        print OUT "\\[*\\]";
                    }
                    print OUT " impl.@$elm[T_NAME]";
                    for ($i = 1; $i <= @dim; $i++) {
                        print OUT "_%$i";
                    }
                    print OUT "\n";
                    $reg_1d_i = 1 if($#dim == 0 && @$elm[T_TYPE] =~ /out/);
                    $reg_2d_i = 1 if($#dim == 1 && @$elm[T_TYPE] =~ /out/);
                    $reg_3d_i = 1 if($#dim == 2 && @$elm[T_TYPE] =~ /out/);
                    $reg_1d_o = 1 if($#dim == 0 && @$elm[T_TYPE] =~ /in/);
                    $reg_2d_o = 1 if($#dim == 1 && @$elm[T_TYPE] =~ /in/);
                    $reg_3d_o = 1 if($#dim == 2 && @$elm[T_TYPE] =~ /in/);
                } else {
                    $reg_1d_i = 1 if($#dim == 0);
                    $reg_2d_i = 1 if($#dim == 1);
                    $reg_3d_i = 1 if($#dim == 2);
                    $reg_1d_o = 1 if($#dim == 0);
                    $reg_2d_o = 1 if($#dim == 1);
                    $reg_3d_o = 1 if($#dim == 2);
                }
            }
        }
        if($reg_1d_i == 1) {
            print OUT "create_map -input  spec.*.*\\[*\\] impl.%1.%2_%3\n";
        }
        if($reg_1d_o == 1) {
            print OUT "create_map -output spec.*.*\\[*\\] impl.%1.%2_%3\n";
        }
        if($reg_2d_i == 1) {
            print OUT "create_map -input  spec.*.*\\[*\\]\\[*\\] impl.%1.%2_%3_%4\n";
        }
        if($reg_2d_o == 1) {
            print OUT "create_map -output spec.*.*\\[*\\]\\[*\\] impl.%1.%2_%3_%4\n";
        }
        if($reg_3d_i == 1) {
            print OUT "create_map -input  spec.*.*\\[*\\]\\[*\\]\\[*\\] impl.%1.%2_%3_%4_%5\n";
        }
        if($reg_3d_o == 1) {
            print OUT "create_map -output spec.*.*\\[*\\]\\[*\\]\\[*\\] impl.%1.%2_%3_%4_%5\n";
        }
        print OUT "\n";
        print OUT "verify -mode full_proof\n";
        print OUT "quit\n";
        close(OUT);
    }
    else {
        $outfile = "slec_${module_name}_eq.cfg";
        &my_open(*OUT, "##", "slec", 0);
        print OUT "# ctos2slec option\n";
        print OUT "#-map_state_variables\n";
        print OUT "#-bbox_functions FUNC_NAME0,FUNC_NAME1,...\n";
        print OUT "\n";
        print OUT "# slec option\n";
        print OUT "#limit -time 8h|30m|etc.\n";
        print OUT "#set_global bit_level_solver_only 1\n";
        print OUT "#set_global ignore_intermediate_points 1\n";
        print OUT "#set_global replace_xz_with_constant 0\n";
        print OUT "set_global ldb_gen_maps 0\n" if ($use_template == 1);
        foreach $rst (@rst_list) {
            if (@$rst[T_FLG] & FLG_PART_RST) {
                print OUT "partial_reset @$rst[T_NAME]\n";
            }
        }
        close(OUT);
    }

    $outfile = "run_slec_eq.csh";
    &my_open(*OUT, "#!", "slec", 1, "755");
    print OUT "source $env_slec\n";
    print OUT "bs -os RHEL5 -M 500 -tool slec slec_eq_lsfsh \${*}\n";
    close(OUT);

    $outfile = "slec_eq_lsfsh";
    &my_open(*OUT, "#!", "slec", 1, "755");
    print OUT "set SLEC_CFG = (\$argv)\n";
    print OUT "if(\$#SLEC_CFG == 0) then\n";
    print OUT $tab, "set SLEC_CFG = `find . -name \"slec_*_eq.cfg\"`\n";
    print OUT $tab, "\#\# Add top module _eq.tcl to list\n";
    print OUT $tab, "set SLEC_TCL = `find . -name \"slec_*_eq.tcl\"`\n";
    print OUT $tab, "foreach a (\$SLEC_TCL)\n";
    print OUT $tab x2, "set module_a = `echo \$a | sed -e \"s/.*\\(slec_\\)//\" -e \"s/_eq\\.tcl//\"`\n";
    print OUT $tab x2, "set TOP_FLG = 0\n";
    print OUT $tab x2, "foreach b (\$SLEC_CFG)\n";
    print OUT $tab x3, "set module_b = `echo \$b | sed -e \"s/.*\\(slec_\\)//\" -e \"s/_eq\\.cfg//\"`\n";
    print OUT $tab x3, "if ( \$module_a == \$module_b ) then\n";
    print OUT $tab x4, "set TOP_FLG = 1\n";
    print OUT $tab x4, "break\n";
    print OUT $tab x3, "endif\n";
    print OUT $tab x2, "end\n";
    print OUT $tab x2, "if ( \$TOP_FLG == 0 ) then\n";
    print OUT $tab x3, "set SLEC_CFG = \"\$SLEC_CFG \$a\"\n";
    print OUT $tab x2, "endif\n";
    print OUT $tab, "end\n";
    print OUT "endif\n";
    print OUT "\n";
    print OUT "set EX_CFG = `find . -name \"slec_*_eq.cfg\"`\n";
    print OUT "set EX_TCL = `find . -name \"slec_*_eq.tcl\"`\n";
    print OUT "\n";
    print OUT "foreach a (\$SLEC_CFG)\n\n";
    print OUT $tab, "if( ! -e \$a ) then\n";
    print OUT $tab x2, "echo \"ERROR: Cannot find \$a !\"\n";
    print OUT $tab x2, "continue\n";
    print OUT $tab, "endif\n\n";
    print OUT $tab, "set a = `echo \$a | sed -e \"s/^\\.\\///\"`\n\n";
    print OUT $tab, "\#\# .tcl or .cfg ?\n";
    print OUT $tab, "set TCL_FLG = 0\n";
    print OUT $tab, "foreach b (\$EX_TCL)\n";
    print OUT $tab x2, "set b = `echo \$b | sed -e \"s/^\\.\\///\"`\n";
    print OUT $tab x2, "if ( \$b == \$a ) then\n";
    print OUT $tab x3, "set TCL_FLG = 1\n";
    print OUT $tab x2, "endif\n";
    print OUT $tab, "end\n\n";
    print OUT $tab, "\#\# top module .tcl or logic module .tcl ?\n";
    print OUT $tab, "if (\$TCL_FLG == 1) then\n";
    print OUT $tab x2, "set b = `echo \$a | sed -e \"s/_eq\\.tcl/_eq\\.cfg/\"`\n";
    print OUT $tab x2, "if ( -e \$b ) then\n";
    print OUT $tab x3, "set a = `echo \$a | sed -e \"s/_eq\\.tcl/_eq\\.cfg/\"`\n";
    print OUT $tab x2, "else\n";
    print OUT $tab x3, "\#\# top module .tcl with no ctos2slec\n";
    print OUT $tab x3, "set module = `echo \$a | sed -e \"s/.*\\(slec_\\)//\" -e \"s/_eq\\.tcl//\"`\n";
    print OUT $tab x3, "slec slec_\${module}_eq.tcl -w calypto_\${module}_eq -l slec_\${module}_eq.log -queuelic\n";
    print OUT $tab x3, "continue\n";
    print OUT $tab x2, "endif\n";
    print OUT $tab, "endif\n\n";
    print OUT $tab, "set module = `echo \$a | sed -e \"s/.*\\(slec_\\)//\" -e \"s/_eq\\.cfg//\"`\n\n";
    my $ctosdir = $opt_subd ? "../ctos/" : "";
    print OUT $tab, "if( ! -e ${ctosdir}slec_\${module}.tcl.xml ) then\n";
    print OUT $tab x2, "echo \"ERROR: Cannot find SLEC slec_\${module}.tcl.xml file. Please RUN CtoS !\"\n";
    print OUT $tab x2, "continue\n";
    print OUT $tab, "endif\n\n";
    print OUT $tab, "rm -rf SLEC_*.tcl slec_output\n";
    print OUT $tab, "set CTS2SLC_OPT = \"\"\n";
    print OUT $tab, "set SLEC_OPT = ()\n";
    print OUT $tab, "tr -s ' ' < \$a > tmp0\n";
    print OUT $tab, "tr ' ' ':' < tmp0 > tmp1\n";
    print OUT $tab, "foreach b (`cat tmp1`)\n";
    print OUT $tab x2, "set d = `echo \$b | cut -c 1-1`\n";
    print OUT $tab x2, "switch (\$d)\n";
    print OUT $tab x2, "case \\#:\n";
    print OUT $tab x3, "breaksw\n";
    print OUT $tab x2, "case -:\n";
    print OUT $tab x3, "set c = `echo \$b | sed -e \"s/:/ /g\"`\n";
    print OUT $tab x3, "set CTS2SLC_OPT = \"\$CTS2SLC_OPT \$c\"\n";
    print OUT $tab x3, "breaksw\n";
    print OUT $tab x2, "default:\n";
    print OUT $tab x3, "set SLEC_OPT = (\$SLEC_OPT \$b)\n";
    print OUT $tab x3, "breaksw\n";
    print OUT $tab x2, "endsw\n";
    print OUT $tab, "end\n";
    print OUT $tab, "rm tmp0 tmp1\n";
    print OUT $tab, "\n";
    print OUT $tab, "cp ../ctos/slec_\${module}.tcl.xml .\n" if ($opt_subd);
    print OUT $tab, "ctos2slec -min_latency_maps \$CTS2SLC_OPT slec_\${module}.tcl.xml slec_\${module}_eq.tcl\n";
    print OUT $tab, "\n";
    print OUT $tab, "perl -i -pe 's/^(set_verification_mode .*)/\$1\\nlimit -time 2h/' slec_\${module}_eq.tcl\n";
    print OUT $tab, "perl -i -pe 's/^(set_verification_mode .*)/\$1\\nset_global flop_checking_at_reset concrete/' slec_\${module}_eq.tcl\n";
    print OUT $tab, "perl -i -pe 's/^(set_verification_mode .*)/\$1\\nset_global osci_compliant_initial_value 0/' slec_\${module}_eq.tcl\n";
    print OUT $tab, "perl -i -pe 's/^(set_verification_mode .*)/\$1\\nset_global solver_cache_location none/' slec_\${module}_eq.tcl\n";
    print OUT $tab, "perl -i -pe 's/-D_MEM_MODEL/-D_MEM_MODEL -D__CTOS__/' slec_\${module}_eq.tcl\n";
    print OUT $tab, "perl -i -pe 's/<sc_/<sc_dt::sc_/' SLEC_maps.tcl\n";
    print OUT $tab, "perl -i -pe 's/,\\s+/,/g' SLEC_maps.tcl\n";
    print OUT $tab, "\n";
    print OUT $tab, "foreach b (\$SLEC_OPT)\n";
    print OUT $tab x2, "set c = `echo \$b | sed -e \"s/:/ /g\"`\n";
    print OUT $tab x2, "set rst = `echo \$c | grep \"partial_reset\" | sed -e \"s/partial_reset//\"`\n";
    print OUT $tab x2, "if ( \$rst == \"\" ) then\n";
    print OUT $tab x3, "echo \$c >> SLEC_pre_build.tcl\n";
    print OUT $tab x2, "else\n";
    print OUT $tab x3, "perl -i -pe \"s/^(create_constraint)(.+)(\$rst)/\\# delete \$rst constraint/g\" slec_\${module}_eq.tcl\n";
    print OUT $tab x2, "endif\n";
    print OUT $tab, "end\n";
    print OUT $tab, "\n";
    print OUT $tab, "slec slec_\${module}_eq.tcl -w calypto_\${module}_eq -l slec_\${module}_eq.log -queuelic\n";
    print OUT "end\n";
    close(OUT);
}

##
## generate script file for STACheck
##
sub gen_sta_scr {
    my $subdir = $opt_subd ? "../rtl/" : "";

    $outfile = "run_stacheck_${module_name}.csh";
    &my_open(*OUT, "#!", "stacheck", 0, "755");
    print OUT "source /common/lsftool/RBS/dotfiles/lsf_cshrc_cbs\n";
    print OUT "bs -M 2000 -os RHEL5 -source $def_opencad \\\n";
    print OUT "STAcheck \\\n";
    print OUT "  -RENEW \\\n";
    print OUT "  -TOP $module_name \\\n";
    print OUT "  -PTSHELL stacheck_${module_name}.config \\\n";
    if (@sync_list > 0 && $top_mode == 1) {
        print OUT "#  -PTSHELL stacheck_${module_name}_D005.config \\\n";
    }
    print OUT "  -FILE stacheck_${module_name}.control \\\n";
    print OUT "  -WORK work_stacheck \\\n";
    print OUT "#  -veriWrite veri_top.v \\\n";
    print OUT "#  -PRT_INFO_D005_03 stacheck_top_D005_03.control \\\n";
    print OUT "  -CHECK_S002_PORT \\\n";
    print OUT "  -CANCEL_S002_03 \\\n";
    print OUT "  -LANG VERIRTL \\\n";
    if ($top_mode == 1) {
        print OUT "  ${subdir}*.v\n\n";
    }
    else {
        print OUT "  ${subdir}${module_name}.v\n\n";
    }
    print OUT "if ( \$status ) exit 1\n";
    print OUT "rm -rf work_stacheck\n";
    print OUT "mv log.stacheck run_stacheck_${module_name}.log\n";
    close(OUT);

    $outfile = "stacheck_${module_name}.config";
    &my_open(*OUT, "##", "stacheck", 0);
    print OUT "\n# set parameters\n";
    print OUT "set PERIOD 10\n";
    print OUT "set INPUT_DELAY 0\n";
    print OUT "set OUTPUT_DELAY 0\n";

    # create clock
    my %used_clk = ();
    print OUT "\n# create_clock\n";
    foreach $elm (@clk_list) {
        next if (@$elm[T_NAME] eq "");
        print OUT "create_clock -name ";
        print OUT uc (@$elm[T_NAME]);
        print OUT " {@$elm[T_NAME]} -period \${PERIOD}\n";
        $used_clk{@$elm[T_NAME]} = 0;
    }
    print OUT "create_clock -name async\n";

    # input delay
    print OUT "\n# set_input_delay\n";
    foreach $elm (@clk_list) {
        foreach $tap (@tap_list) {
            next if (@$tap[TAP_SIG] ne @$elm[T_ONAME]);
            next if (@$tap[TAP_INST] ne @$elm[T_INST] && @$tap[T_INST] ne "");
            @$elm[T_ONAME] = @$tap[TAP_OUT];
            last;
        }
        next if (!(exists $used_clk{@$elm[T_ONAME]}));
        foreach $in (@in_list) {
            next if ((@$in[T_NAME] eq "") || (@$in[T_INST] ne @$elm[T_INST]));
            if (!(@$in[T_FLG] & FLG_USED)) {
                print OUT "set_input_delay \${INPUT_DELAY} -clock ";
                print OUT uc (@$elm[T_ONAME]);
                print OUT " [get_ports @$in[T_NAME]";
                print OUT "*" if (@$in[T_ARRAY] ne "" || @$in[T_WID] ne "b");
                print OUT "]\n";
                @$in[T_FLG] |= FLG_USED;
            }
        }
        foreach $rst (@rst_list) {
            next if ((@$rst[T_NAME] eq "") || (@$rst[T_INST] ne @$elm[T_INST]));
            next if (@$rst[T_TYPE] ne "sreset");
            print OUT "set_input_delay \${INPUT_DELAY} -clock ";
            print OUT uc (@$elm[T_ONAME]);
            print OUT " [get_ports @$rst[T_NAME]]\n";
        }
    }
    foreach $in (@in_list) {
        next if ((@$in[T_NAME] eq "") || (@$in[T_FLG] & FLG_USED));
        print OUT "set_input_delay \${INPUT_DELAY} -clock async";
        print OUT " [get_ports @$in[T_NAME]";
        print OUT "*" if (@$in[T_ARRAY] ne "" || @$in[T_WID] ne "b");
        print OUT "]\n";
        @$in[T_FLG] |= FLG_USED;
    }

    # output delay
    print OUT "\n# set_output_delay\n";
    foreach $elm (@clk_list) {
        next if (!(exists $used_clk{@$elm[T_ONAME]}));
        foreach $out (@out_list) {
            next if ((@$out[T_NAME] eq "") || (@$out[T_INST] ne @$elm[T_INST]));
            if (!(@$out[T_FLG] & FLG_USED)) {
                print OUT "set_output_delay \${OUTPUT_DELAY} -clock ";
                print OUT uc (@$elm[T_ONAME]);
                print OUT " [get_ports @$out[T_NAME]";
                print OUT "*" if (@$out[T_ARRAY] ne "" || @$out[T_WID] ne "b");
                print OUT "]\n";
                @$out[T_FLG] |= FLG_USED;
            }
        }
    }
    foreach $out (@out_list) {
        next if ((@$out[T_NAME] eq "") || (@$out[T_FLG] & FLG_USED));
        print OUT "set_output_delay \${OUTPUT_DELAY} -clock async";
        print OUT " [get_ports @$out[T_NAME]";
        print OUT "*" if (@$out[T_ARRAY] ne "" || @$out[T_WID] ne "b");
        print OUT "]\n";
        @$out[T_FLG] |= FLG_USED;
    }

    # handling asynchronous reset
    $init = 0;
    foreach $elm (@rst_list) {
        next if ((@$elm[T_NAME] eq "") || (@$elm[T_TYPE] ne "areset"));
        print OUT "\n# asynchronous reset\n" if ($init == 0);
        print OUT "set_input_delay \${INPUT_DELAY} -clock async [get_ports @$elm[T_NAME]]\n";
        print OUT "set_false_path -from [get_ports @$elm[T_NAME]]\n";
        $init = 1;
    }
    close(OUT);

    if (@sync_list > 0 && $top_mode == 1) {
        $outfile = "stacheck_${module_name}_D005.config";
        &my_open(*OUT, "##", "stacheck", 0);
        print OUT "\n# asynchronous transfer\n";
        my $cnt = 0;
        foreach $elm (@bind_list) {
            next if (!(@$elm[B_FLG_E] & FLG_SYNC));
            if (@$elm[B_FLG_E] & FLG_SYNC_EN) {
                foreach $elm2 (@sync_list) {
                    next if (@$elm2[S_INST] ne @$elm[B_INST_E]);
                    next if (@$elm2[S_INVAL] ne @$elm[B_PORT_E]);
                    if ((@$elm2[S_FLG] & FLG_SYNC_POS) || (@$elm2[S_FLG] & FLG_SYNC_NEG) || (@$elm2[S_FLG] & FLG_SYNC_TOG)){
                        print OUT "set_false_path";
                        print OUT " -from [get_pins @$elm[B_INST_S]/@$elm2[S_INVAL]*]";
                        print OUT " -to [get_pins @$elm[B_INST_E]/@$elm2[S_NAME]*]\n";
                    }
                    else {
                        print OUT "set_strings GROUP_REG @$elm[B_INST_S]/@$elm[B_PORT_S]* {ASYNC$cnt}\n";
                        $cnt++;
                    }
                }
            }
            else {
                &get_port_data(@$elm[B_INST_S], @$elm[B_PORT_S], \$port_s);
                print OUT "set_strings GROUP_REG @$elm[B_INST_S]/@$elm[B_PORT_S]";
                print OUT "_*" if (@$port_s[T_ARRAY] ne "");
                print OUT " {}\n";
            }
        }
        close(OUT);
    }

    $outfile = "stacheck_${module_name}.control";
    &my_open(*OUT, "//", "stacheck", 0);
    print OUT "//string POWERON_sig[] = {\"\"};\n";
    print OUT "string POWERON_sig[] = {";
    for ($i = 0; $i < @rst_list; $i++) {
        $elm = $rst_list[$i];
        next if ((@$elm[T_NAME] eq "") || (@$elm[T_TYPE] ne "areset"));
        print OUT "\"@$elm[T_NAME]\", ";
        print OUT (@$elm[T_INIT] eq "pos") ? "\"H\"" : "\"L\"";
        print OUT ", " if ($i != (@rst_list - 1));
    }
    print OUT "};\n\n";
    print OUT "//string async_signal[] = {\"\"};\n\n";
    print OUT "//string Cancel_C001_instance[] = {\"\"};\n";
    print OUT "//string Cancel_C002_instance[] = {\"\"};\n";
    print OUT "//string Cancel_C003_instance[] = {\"\"};\n";
    print OUT "//string Cancel_S001_instance[] = {\"\"};\n";
    print OUT "//string Cancel_S002_instance[] = {\"\"};\n";
    print OUT "//string Cancel_S003_instance[] = {\"\"};\n";
    print OUT "//string Cancel_D004_instance[] = {\"\"};\n";
    print OUT "//string Cancel_D005_instance[] = {\"\"};\n";
    print OUT "//string Cancel_D006_instance[] = {\"\"};\n";
    print OUT "//string C005_gated_clock_cells[] = {\"\"};\n\n";
    print OUT "//`define GATED_CLOCK_NUMBER 2\n";
    close(OUT);
}

##
## generate module define file for top module
##
sub gen_top_moddef {
    if ($need_moddef == 0) {
       return;
    }

    $outfile = "mod_" . $module_name . ".in";
    &my_open(*OUT, "//", ".", 0);
    if ($top_keep_ssgen_define == 1) {
        print OUT "keep_ssgen_define on\n";
    }
    &print_preprocessor(*OUT);
    print OUT "\n" if (@prepro_list > 0);
    &print_kept_ssgen_define(*OUT, $infile, 1);

    print OUT "module $module_name\n";
    foreach $elm (@clk_list) {
        if (@$elm[T_NAME] ne "") {
            print OUT "clock @$elm[T_NAME]\n";
        }
    }
    foreach $elm (@rst_list) {
        if (@$elm[T_NAME] ne "") {
            print OUT "@$elm[T_TYPE] @$elm[T_NAME] @$elm[T_INIT]\n";
        }
    }
    foreach $elm (@in_list) {
        if (@$elm[T_NAME] ne "") {
            if (&is_template_parameter(@$elm[T_WID], \$tmp) == 1) {
                @$tmp[G_SUBS] =~ /(u)?int<(\d+)>$/;
                $wid = $2;
                $type = $1 . "in";
            }
            else {
                $wid = @$elm[T_WID];
                $type = @$elm[T_TYPE];
            }
            $arr = "";
            if (@$elm[T_ARRAY] ne "") {
                while (@$elm[T_ARRAY] =~ /\w+/g) {
                    $i = $&;
                    if (&is_template_parameter($i, \$tmp) == 1) {
                        $arr .= "[@$tmp[G_VALUE]]";
                    }
                    else {
                        $arr .= "[$i]";
                    }
                }
            }
            #print OUT "@$elm[T_TYPE]@$elm[T_WID] @$elm[T_NAME]@$elm[T_ARRAY]\n";
            print OUT "$type$wid @$elm[T_NAME]$arr\n";
        }
    }
    foreach $elm (@out_list) {
        if (@$elm[T_NAME] ne "") {
            if (&is_template_parameter(@$elm[T_WID], \$tmp) == 1) {
                @$tmp[G_SUBS] =~ /(u)?int<(\d+)>$/;
                $wid = $2;
                $type = $1 . "out";
            }
            else {
                $wid = @$elm[T_WID];
                $type = @$elm[T_TYPE];
            }
            $arr = "";
            if (@$elm[T_ARRAY] ne "") {
                while (@$elm[T_ARRAY] =~ /\w+/g) {
                    $i = $&;
                    if (&is_template_parameter($i, \$tmp) == 1) {
                        $arr .= "[@$tmp[G_VALUE]]";
                    }
                    else {
                        $arr .= "[$i]";
                    }
                }
            }
            #print OUT "@$elm[T_TYPE]@$elm[T_WID] @$elm[T_NAME]@$elm[T_ARRAY]\n";
            print OUT "$type$wid @$elm[T_NAME]$arr\n";
        }
    }
    # insert_port
    foreach $elm (@in_list_insert) {
        if (@$elm[T_NAME] ne "") {
            print OUT "@$elm[T_TYPE]@$elm[T_WID] @$elm[T_NAME]@$elm[T_ARRAY]\n";
        }
    }
    foreach $elm (@out_list_insert) {
        if (@$elm[T_NAME] ne "") {
            print OUT "@$elm[T_TYPE]@$elm[T_WID] @$elm[T_NAME]@$elm[T_ARRAY]\n";
        }
    }
    @mem_used = ();
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        my $skip = 0;
        if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
            foreach $used (@mem_used) {
                if ($used eq @$elm[M_NAME]) {
                    $skip = 1;
                    last;
                }
            }
            push(@mem_used, @$elm[M_NAME]);
        }
        if ($skip == 0) {
            print OUT (@$elm[M_SIGN] == 1) ? "s" : "u";
            print OUT "mem @$elm[M_WID] @$elm[M_SIZE] @$elm[M_NAME] ",
                          &get_memkind_string(@$elm[M_RW], @$elm[M_SHARE]),
                          " @$elm[M_LAT]";
            if (@$elm[M_IPRE] eq @$elm[M_OPRE]) {
                if (@$elm[M_IPRE] ne "") {
                    print OUT " -prefix=@$elm[M_IPRE]";
                }
            }
            else {
                if (@$elm[M_IPRE] ne "") {
                    print OUT " -iprefix=@$elm[M_IPRE]";
                }
                if (@$elm[M_OPRE] ne "") {
                    print OUT " -oprefix=@$elm[M_OPRE]";
                }
            }
            if (@$elm[M_PONLY] == 1) {
                print OUT " -ponly";
            }
            if ((@$elm[M_RW] & MA_DPORT)
              || (@$elm[M_RW] & MA_W)
              || (@$elm[M_RW] == MA_RW1_R && @$elm[M_SHARE] > 0)) {
                if (@$elm[M_WE] > 0) {
                    print OUT " -we=", (@$elm[M_WE] == 1 ? "high" : "low");
                }
                if (@$elm[M_CS] > 0) {
                    print OUT " -cs=", (@$elm[M_CS] == 1 ? "high" : "low");
                }
                if (@$elm[M_BE] > 0) {
                    print OUT " -be=", (@$elm[M_BE] == 1 ? "high" : "low");
                }
                print OUT " -clk=", @$elm[M_CLKW];
            }
            else {
                if (@$elm[M_RE] > 0) {
                    print OUT " -re=", (@$elm[M_RE] == 1 ? "high" : "low");
                }
                print OUT " -clk=", @$elm[M_CLKR];
            }
            if (@$elm[M_INIT] ne "") {
                print OUT " -init=@$elm[M_INIT]";
            }
            if (@$elm[M_SUF] ne "") {
                print OUT " -suffix=@$elm[M_SUF]";
            }
            print OUT "\n";
        }
    }
    close(OUT);
}

##
## generate sva module template and binding file
##
sub gen_sva {
    my @port_list = ();
    if ($top_mode == 0) {
        @port_list = (@clk_list, @rst_list, @in_list, @out_list);
    }
    else {
        @port_list = (@clk_list, @rst_list, @in_list, @out_list, @in_list_insert, @out_list_insert);
    }

    if ($top_mode == 0 && $use_template == 1) {
        $module_name = @{$tmpl_inst_list[0]}[MOD_NAME];
    }
    $outfile = "${module_name}_sva.v";
    &my_open(*OUT, "//", "sva", 0);
    print OUT "module ${module_name}_sva (\n";
    $init = 1;
    foreach $elm (@port_list) {
        next if (@$elm[T_NAME] eq "");
        next if (@$elm[T_TYPE] eq "soft_reset");
        next if (@$elm[T_FLG] & FLG_STR_TYPE);
        $max = 1;
        if (@$elm[T_ARRAY] ne "") {
            @dim = ();
            while (@$elm[T_ARRAY] =~ /\w+/g) {
                &get_array_info(\@dim, $&);
            }
            foreach $i (@dim) {
                $max *= $i;
            }
            @mod = ();
            $val = $max;
            foreach $i (@dim) {
                $val /= $i;
                push(@mod, $val);
            }
        }
        for ($i = 0; $i < $max; $i++) {
            $name = @$elm[T_NAME];
            if (@$elm[T_ARRAY] ne "") {
                for ($j = 0; $j < @mod; $j++) {
                    $name = $name . "_" . int($i / $mod[$j]) % $dim[$j];
                }
            }
            print OUT $tab, ($init == 1) ? "  " : ", ", $name, "\n";
            $init = 0;
        }
    }
    print OUT ");\n";

    foreach $elm (@port_list) {
        next if (@$elm[T_NAME] eq "");
        next if (@$elm[T_TYPE] eq "soft_reset");
        next if (@$elm[T_FLG] & FLG_STR_TYPE);
        $max = 1;
        if (@$elm[T_ARRAY] ne "") {
            @dim = ();
            while (@$elm[T_ARRAY] =~ /\w+/g) {
                &get_array_info(\@dim, $&);
            }
            foreach $i (@dim) {
                $max *= $i;
            }
            @mod = ();
            $val = $max;
            foreach $i (@dim) {
                $val /= $i;
                push(@mod, $val);
            }
        }
        for ($i = 0; $i < $max; $i++) {
            $name = @$elm[T_NAME];
            if (@$elm[T_ARRAY] ne "") {
                for ($j = 0; $j < @mod; $j++) {
                    $name = $name . "_" . int($i / $mod[$j]) % $dim[$j];
                }
            }
            print OUT $tab, "input ";
            print OUT "[" . eval(@$elm[T_WID]-1) . ":0] " if (@$elm[T_WID] ne "b");
            print OUT "$name;\n";
        }
    }
    print OUT "\n";
    print OUT $tab, "// Please write your assertions here\n";
    print OUT "\n";
    print OUT "\n";
    print OUT "endmodule\n";
    close(OUT);

    $outfile = "${module_name}_sva_bind.sv";
    &my_open(*OUT, "//", "sva", 0);
    print OUT "bind $module_name ${module_name}_sva ${module_name}_sva_b(\n";
    $init = 1;
    foreach $elm (@port_list) {
        next if (@$elm[T_NAME] eq "");
        next if (@$elm[T_TYPE] eq "soft_reset");
        next if (@$elm[T_FLG] & FLG_STR_TYPE);
        $max = 1;
        if (@$elm[T_ARRAY] ne "") {
            @dim = ();
            while (@$elm[T_ARRAY] =~ /\w+/g) {
                &get_array_info(\@dim, $&);
            }
            foreach $i (@dim) {
                $max *= $i;
            }
            @mod = ();
            $val = $max;
            foreach $i (@dim) {
                $val /= $i;
                push(@mod, $val);
            }
        }
        for ($i = 0; $i < $max; $i++) {
            $name = @$elm[T_NAME];
            if (@$elm[T_ARRAY] ne "") {
                for ($j = 0; $j < @mod; $j++) {
                    $name = $name . "_" . int($i / $mod[$j]) % $dim[$j];
                }
            }
            print OUT $tab, ($init == 1) ? "  " : ", ", $name, "\n";
            $init = 0;
        }
    }

    print OUT ");\n";
    close(OUT);
    $module_name = $org_module_name;
}

##
## generate Makefile for OSCI-Sim
##
sub gen_osci_scr {
    my $subdir = $opt_subd ? $opt_ins ? "../src_ins/" : "../src/" : "";
    my $srcfile = $opt_ins ? "_ins.cpp" : ".cpp";

    $outfile = "Makefile";
    &my_open(*OUT, "##", "gcc", 0);

    print OUT "TARGET_ARCH = linux\n";
    print OUT "CC     = g++\n";
    print OUT "OPT    = -m32 -Wall \n";
    print OUT "## please add your include header path to USRDIR, if any\n";
    print OUT "VPATH  = ../src" if ($opt_subd);
    print OUT " ../src_ins" if ($opt_subd && $opt_ins);
    print OUT " ../tb\n" if ($opt_subd);
    print OUT "USRDIR = ";
    print OUT "-I../src -I../tb" if ($opt_subd);
    print OUT " -I$env_ssgen" if (!$opt_standard);
    print OUT " -I\${STRATUS_HOME}/share/stratus/include" if (!$opt_standard && $opt_stratus);
    print OUT " -I\${CTS_DIR}/share/ctos/include/ctos_clock_gating" if (!$opt_standard && $use_ctos_cg);
    print OUT "\n";
    print OUT "MACRO  = -D$dbg_macro -D$osci_macro";
    print OUT " -D$mem_macro" if (!$opt_standard);
    print OUT "\n";
    print OUT "#GCOV   = -fprofile-arcs -ftest-coverage -fno-elide-constructors\n";
    print OUT "CFLAGS = \$(OPT) \$(MACRO) \$(GCOV)\n";
    print OUT "\n";
    print OUT "MODULE = run\n";
    if ($opt_subd) {
        print OUT "SRCS := \$(wildcard $subdir*$srcfile ../tb/*.cpp)\n";
    }
    else {
        print OUT ($opt_sim_eq) ? "SRCS := \$(filter-out %_eq.cpp, \$(wildcard *.cpp))\n"
                                : "SRCS := \$(wildcard *.cpp)\n";
    }
    print OUT "\n";
    print OUT "include ./Makefile.defs\n";
    close(OUT);

    $outfile = "Makefile.defs";
    &my_open(*OUT, "##", "gcc", 0);

    print OUT "SYSTEMC = $env_systemc\n";
    print OUT "\n";
    print OUT "INCDIR = -I. -I\$(SYSTEMC)/include\n";
    print OUT "LIBDIR = -L. -L\$(SYSTEMC)/lib-\$(TARGET_ARCH)\n";
    print OUT "\n";
    print OUT "LIBS   = -lm \$(EXTRA_LIBS) -lsystemc\n";
    print OUT "OBJDIR = obj\n";
    print OUT "\n";
    print OUT "OBJS := \$(SRCS:.cpp=.o)\n";
    print OUT "OBJS := \$(addprefix obj/, \$(notdir \$(OBJS)))\n";
    print OUT "\n";
    print OUT "EXE    = \$(MODULE).exe\n";
    print OUT "\n";
    print OUT ".SUFFIXES: .cpp .o .x .exe\n";
    print OUT "\n";
    print OUT "default : \$(OBJDIR) \$(EXE)\n";
    print OUT "\n";
    print OUT "\$(OBJDIR):\n";
    print OUT "\t\@mkdir -p \$@\n";
    print OUT "\n";
    print OUT "\$(EXE): \$(OBJS)\n";
    print OUT "\t\$(CC) \$(CFLAGS) \$(INCDIR) \$(USRDIR) \$(LIBDIR) -o \$@ \$(OBJS) \$(LIBS) 2>&1 | c++filt\n";
    print OUT "\n";
    print OUT "\$(OBJDIR)/%.o: %.cpp\n";
    print OUT "\t\$(CC) \$(CFLAGS) \$(INCDIR) \$(USRDIR) -c \$< -o \$@\n";
    print OUT "\n";
    print OUT "clean::\n";
    print OUT "\trm -rf \$(OBJDIR)\n";
    print OUT "\trm -f *~ \$(EXE) core\n";
    print OUT "\n";
    print OUT "ultraclean: clean\n";
    print OUT "\trm -f Makefile.deps\n";
    print OUT "\n";
    print OUT "Makefile.deps:\n";
    print OUT "\t\@for X in \$(SRCS); do \\\n";
    if ($opt_subd) {
        print OUT "\t\tY=`echo \$\$X | awk -F\"/\" '{print \$\$NF}' | sed 's/.cpp/.o/'`; \\\n";
    }
    else {
        print OUT "\t\tY=`echo \$\$X | sed 's/.cpp/.o/'`; \\\n";
    }
    print OUT "\t\t\$(CC) \$(CFLAGS) \$(INCDIR) \$(USRDIR) -M \$\$X -MT \$(OBJDIR)/\$\$Y >> Makefile.deps; \\\n";
    print OUT "\tdone\n";
    #print OUT "\t\$(CC) \$(CFLAGS) \$(INCDIR) \$(USRDIR) -M \$(SRCS) >> Makefile.deps\n";
    print OUT "\n";
    print OUT "-include Makefile.deps\n";
    close(OUT);

    $outfile = "run_gcc.csh";
    &my_open(*OUT, "#!", "gcc", 1, "755");
    if($opt_ins) {
        print OUT "${subdir}run_cpp2ins.csh\n\n";
        print OUT "if ( \$? == 1 ) then\n";
        print OUT $tab, "echo \"FAIL ${subdir}run_cpp2ins.csh\"\n";
        print OUT $tab, "echo \"Please execute gcc with -skip_ins first\"\n";
        print OUT $tab, "exit 1\n";
        print OUT "endif\n";
    }
    print OUT "source $env_ctos\n" if (!$opt_standard && $use_ctos_cg);
    print OUT "source $env_stratus\n" if (!$opt_standard && $opt_stratus);
    print OUT "make\n";
    print OUT "run.exe \${*}\n";
    close(OUT);
}

##
## generate script file for VCS-Sim
##
sub gen_vcs_scr {
    my $subscdir = $opt_subd ? $opt_ins ? "../src_ins/" : "../src/" : "";
    my $srcfile = $opt_ins ? "_ins.cpp" : ".cpp";

    if ($top_mode == 0 && $use_template == 1) {
        $module_name = @{$tmpl_inst_list[0]}[MOD_NAME];
    }
    $outfile = "vcs_lsfsh_sc";
    &my_open(*OUT, "#!", "vcs", 0, "755");
    $env_vcs_gcc =~ /(.*)\/(.*)/;
    print OUT "set VG_GNU_PACKAGE = $1\n";
    print OUT "source \${VG_GNU_PACKAGE}/$2\n";
    print OUT "\n";
    print OUT "rm -rf AN.DB DVEfiles csrc simv.daidir simv.vdb simv .X_dummy2.v\n";
    print OUT "\n";
    if ($use_aigen == 1) {
        &print_vcs_aip;
    }
    if ($opt_sva == 1) {
        &print_vcs_sva;
    }
    print OUT "## please add your include header path to \"-I\", if any\n";
    print OUT "## please add sub module file, if any\n";
    print OUT "syscan -sysc=2.2 -cpp g++ -cc gcc \\\n";
    print OUT "  -cflags \"";
    print OUT "-I../src -I../tb " if ($opt_subd);
    print OUT "-I\${STRATUS_HOME}/share/stratus/include " if ($opt_stratus);
    print OUT "-I$env_ssgen -D$mem_macro " if (!$opt_standard);
    print OUT "-D_VCS_AIP " if ($use_aigen);
    print OUT "-D_USE_SVA " if ($opt_sva);
    print OUT "-D$dbg_macro\" \\\n";
    print OUT "#  -cflags \"-fprofile-arcs -ftest-coverage -fno-elide-constructors\" \\\n";
    print OUT $opt_subd ? "  $subscdir*$srcfile ../tb/*.cpp" : "  *.cpp";
    print OUT "\n";
    print OUT "\n";
    print OUT "vcs -sysc=2.2 -timescale=1ns/1ps -cpp g++ -cc gcc \\\n";
    print OUT "  -ldflags \"\" \\\n";
    print OUT "#  -cm assert \\\n";
    print OUT "#  -ldflags \"-fprofile-arcs -ftest-coverage -fno-elide-constructors\" \\\n";
    print OUT "#  -debug_access+all\n";
    print OUT "\n";
    print OUT "simv \\\n";
    print OUT "# -ucli -ucli2Proc -do vpd.ucli -systemcrun arg\n";
    print OUT "\n";
    print OUT "#gcov -o csrc/sysc XXX$srcfile > XXX_gcov.log\n";
    print OUT "#urg -dir *.vdb -format text -metric assert\n";
    close(OUT);

    $outfile = "vcs_lsfsh_rtl";
    &my_open(*OUT, "#!", "vcs", 0, "755");
    $env_vcs_gcc =~ /(.*)\/(.*)/;
    print OUT "set VG_GNU_PACKAGE = $1\n";
    print OUT "source \${VG_GNU_PACKAGE}/$2\n";
    print OUT "\n";
    print OUT "rm -rf AN.DB DVEfiles csrc simv.daidir simv.vdb simv .X_dummy2.v\n";
    if (!$opt_subd) {
        print OUT "\n";
        print OUT "if ( -e $module_name.h ) mv $module_name.h $module_name.h.t\n";
        print OUT "if ( -e $module_name.cpp ) mv $module_name.cpp $module_name.cpp.t\n";
    }
    print OUT "\n";
    if ($use_aigen == 1) {
        &print_vcs_aip;
    }
    if ($opt_sva == 1) {
        &print_vcs_sva;
    }
    #$subdir = $opt_subd ? "../ctos/" : "";
    $subdir = $opt_subd ? "../rtl/" : "";
    print OUT "vlogan -sysc=2.2 +v2k $subdir$module_name.v -sc_model $module_name -sc_portmap ${module_name}_vcs.map\n";
    print OUT "## please add sub module file, if any\n";
    if ($top_mode == 1) {
        print OUT "vlogan +v2k";
        foreach $elm (@mod_list) {
            next if (@$elm[MOD_FLG] & FLG_MULTI || @$elm[MOD_DBG] ne "");
            print OUT " $subdir@$elm[MOD_NAME].v";
        }
        @mem_used = ();
        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 1);
            my $skip = 0;
            foreach $used (@mem_used) {
                if ($used eq @$elm[M_NAME]) {
                    $skip = 1;
                    last;
                }
            }
            push(@mem_used, @$elm[M_NAME]);
            if ($skip == 0) {
                if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                    if (@$elm[M_SHARE] > 0) {
                        $ifnm = &get_mem_ifnm(\@$elm);
                        print OUT " $subdir$ifnm.v";
                    }
                }
            }
        }
    }
    print OUT "\n";
    print OUT "## please add your include header path to \"-I\", if any\n";
    print OUT "syscan -sysc=2.2 -cpp g++ -cc gcc \\\n";
    print OUT "  -cflags \"";
    print OUT "-I$env_ssgen -D$mem_macro " if (!$opt_standard);
    print OUT "-I\${STRATUS_HOME}/share/stratus/include " if ($opt_stratus);
    print OUT "-D_VCS_AIP " if ($use_aigen);
    print OUT "-D_USE_SVA " if ($opt_sva);
    print OUT "-D$rtl_macro\" \\\n";
    print OUT $opt_subd ? "  ../tb/*.cpp\n" : "  *.cpp\n";
    print OUT "\n";
    print OUT "vcs -sysc=2.2 -timescale=1ns/1ps -cpp g++ -cc gcc \\\n";
    print OUT "  +warn=noSC-TCMM-V5 \\\n";
    print OUT "  -ldflags \"\" \\\n";
    print OUT "#  -cm assert \\\n";
    print OUT "#  -debug_access+all\n";
    print OUT "\n";
    print OUT "simv \\\n";
    print OUT "#  -ucli -ucli2Proc -do vpd.ucli -systemcrun arg\n";
    print OUT "\n";
    print OUT "#urg -dir *.vdb -format text -metric assert\n";
    if (!$opt_subd) {
        print OUT "\n";
        print OUT "if ( -e $module_name.h.t ) mv $module_name.h.t $module_name.h\n";
        print OUT "if ( -e $module_name.cpp.t ) mv $module_name.cpp.t $module_name.cpp\n";
    }
    close(OUT);

    $outfile = "vpd.ucli";
    &my_open(*OUT, "##", "vcs", 1);
    print OUT "synopsys::scope .\n";
    print OUT "set filename dump.vpd\n";
    print OUT "set fid [synopsys::dump -file \$filename -type VPD]\n";
    print OUT "synopsys::dump -add \".\" -depth 0 -fid \$fid\n";
    print OUT "puts \"==== Waveform file generation is enabled ( \$filename ) ====\"\n";
    print OUT "synopsys::run\n";
    close(OUT);

    $outfile = "run_vcs.csh";
    &my_open(*OUT, "#!", "vcs", 0, "755");
    if($opt_ins) {
        print OUT "${subscdir}run_cpp2ins.csh\n\n";
        print OUT "if ( \$? == 1 ) then\n";
        print OUT $tab, "echo \"FAIL ${subscdir}run_cpp2ins.csh\"\n";
        print OUT $tab, "echo \"Please execute VCS with -skip_ins first\"\n";
        print OUT $tab, "exit 1\n";
        print OUT "endif\n";
    }
    print OUT "source $env_stratus\n" if ($opt_stratus);
    print OUT "source $env_vcs\n";
    print OUT "bs -M $bs_vcs_mem -os $bs_vcs_os vcs_lsfsh\n";
    close(OUT);
    $module_name = $org_module_name;
}

##
## print setup for AIP in VCS
##
sub print_vcs_aip {
    print OUT "set APB_AIP = \${VCS_HOME}/packages/aip/APB_AIP\n";
    print OUT "\n";
    print OUT "vlogan -sysc=2.2 +v2k \\\n";
    print OUT "  -sc_model " . $module_name . "_vcs_apb_monitor \\\n";
    print OUT "  -sc_portmap " . $module_name . "_vcs_apb_monitor.map \\\n";
    print OUT "  +incdir+\${APB_AIP}/src \\\n";
    print OUT "  " . $module_name . "_vcs_apb_monitor.v\n";
    print OUT "\n";
    print OUT "vlogan -sverilog +incdir+\${APB_AIP}/src \${APB_AIP}/src/SnpsApbSlave.sv\n";
    print OUT "vlogan -sverilog +incdir+\${APB_AIP}/src \${APB_AIP}/src/SnpsApbBridge.sv\n";
    print OUT "\n";
}

##
## print setup for sva module in VCS
##
sub print_vcs_sva {
    $sva_dir = $opt_subd ? "../sva/" : "";
    print OUT "vlogan -sysc=2.2 +v2k -sverilog \\\n";
    print OUT "  -sc_model ${module_name}_sva -sc_portmap ${module_name}_vcs.map \\\n";
    print OUT "  $sva_dir${module_name}_sva.v\n";
    print OUT "\n";
}

##
## generate script file for IES-Sim
##
sub gen_ies_scr {
    my $subscdir = $opt_subd ? $opt_ins ? "../src_ins/" : "../src/" : "";
    my $srcfile = $opt_ins ? "_ins.cpp" : ".cpp";

    if ($top_mode == 0 && $use_template == 1) {
        $module_name = @{$tmpl_inst_list[0]}[MOD_NAME];
    }
    $outfile = "ncverilog_lsfsh_sc";
    &my_open(*OUT, "#!", "ies", 0, "755");
    print OUT "rm -rf INCA_libs irun.log ncsc.log waves.shm\n";
    print OUT "\n";
    print OUT "setenv CDNS_GCOV `ncroot`/tools/systemc/gcc/install/bin/gcov\n";
    print OUT "\n";
    if ($use_aigen == 1) {
        &print_ies_abvip;
    }
    if ($opt_sva == 1) {
        &print_ies_sva;
    }
    print OUT "## please add your include header path to \"-I\", if any\n";
    print OUT "## please add sub module file, if any\n";
    print OUT "irun \\\n";
    print OUT "  -64bit \\\n";
    print OUT $opt_subd ? "  $subscdir*$srcfile ../tb/*.cpp \\\n" : "  *.cpp \\\n";
    print OUT $opt_subd ? "  ../sva/*.sv \\\n" : "  *.sv \\\n" if($opt_sva || $hdl_ies_on);
    print OUT "  -sysc \\\n";
    print OUT "  -sctop sc_main \\\n";
    print OUT "  -I../src -I../tb \\\n" if ($opt_subd);
    print OUT "  -I\${STRATUS_HOME}/share/stratus/include \\\n" if ($opt_stratus);
    print OUT "  -I$env_ssgen \\\n" if (!$opt_standard);
    print OUT "  -I. \\\n";
    print OUT "  -I\${CTS_DIR}/share/ctos/include/ctos_clock_gating \\\n" if (!$opt_standard && $use_ctos_cg);
    print OUT "  -D$dbg_macro \\\n";
    print OUT "  -D$mem_macro \\\n" if (!$opt_standard);
    print OUT "  -D_IES_ABVIP \\\n" if ($use_aigen);
    print OUT "  -D_USE_SVA \\\n" if ($opt_sva);
    print OUT "  -incdir ../sva \\\n" if ($opt_subd && ($opt_sva || $hdl_ies_on));
    print OUT "  -loadpli1 \${VIPCAT_HOME}/tools/lib/libviputil.so:cdsVip_PLIPtr\\\n" if ($use_aigen);
    print OUT "#  -coverage all \\\n";
    print OUT "#  -covoverwrite \\\n";
    print OUT "#  -covfile cov.ccf \\\n";
    print OUT "#  -covtest test \\\n";
    print OUT "#  -Wcxx,-fprofile-arcs,-ftest-coverage,-fno-elide-constructors \\\n";
    print OUT "#  -Wld,-fprofile-arcs,-ftest-coverage,-fno-elide-constructors \\\n";
    print OUT "#  +systemc_args+\"\" \\\n";
    print OUT "#  -access r -input probe.tcl\n";
    print OUT "\n";
    print OUT "#setenv VMANAGER_JAVA_OPTIONS -Djava.io.tmpdir=INCA_libs\n";
    print OUT "#imc -batch -init ./imc.cmd -licqueue -logfile ./imc.log -nostdout\n";
    #print OUT "#\${CDNS_GCOV} -o INCA_libs/irun.nc/ncsc_run/ncsc_obj XXX$srcfile > XXX_gcov.log\n";
    if ( 1 ) { ## IES 14.20 issue, it will be fixed in 15.20
        my $srcfile = $opt_ins ? "_ins_0.cpp" : "_0.cpp";
        print OUT "#\${CDNS_GCOV} -o INCA_libs/irun.nc/ncsc_run/ncsc_obj XXX$srcfile > XXX_gcov.log\n";
    }
    close(OUT);

    $outfile = "ncverilog_lsfsh_rtl";
    &my_open(*OUT, "#!", "ies", 0, "755");
    print OUT "rm -rf INCA_libs irun.log ncsc.log waves.shm\n";
    print OUT "\n";
    if ($use_aigen == 1) {
        &print_ies_abvip;
    }
    if ($opt_sva == 1) {
        &print_ies_sva;
    }
    if (!$opt_subd) {
        print OUT "if ( -e $module_name.h ) mv $module_name.h $module_name.h.t\n";
        print OUT "if ( -e $module_name.cpp ) mv $module_name.cpp $module_name.cpp.t\n";
    }
    print OUT "\n";

    $subdir = $opt_subd ? "../rtl/" : "";
    print OUT "## please add sub module file, if any\n";
    print OUT "ncverilog -64bit -c $subdir$module_name.v";
    if ($top_mode == 1) {
        foreach $elm (@mod_list) {
            next if (@$elm[MOD_FLG] & FLG_MULTI || @$elm[MOD_DBG] ne "");
            next if (@$elm[MOD_NAME] eq "ctos_clock_gating");
            print OUT " $subdir@$elm[MOD_NAME].v";
        }
        @mem_used = ();
        foreach $elm (@mem_list) {
            next if(@$elm[M_FIX] == 1);
            my $skip = 0;
            foreach $used (@mem_used) {
                if ($used eq @$elm[M_NAME]) {
                    $skip = 1;
                    last;
                }
            }
            push(@mem_used, @$elm[M_NAME]);
            if ($skip == 0) {
                if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
                    if (@$elm[M_SHARE] > 0) {
                        $ifnm = &get_mem_ifnm(\@$elm);
                        print OUT " $subdir$ifnm.v";
                    }
                }
            }
        }
    }
    print OUT "\n";
    print OUT "\n";
    print OUT "ncshell -64bit -NOCOMPILE \\\n";
    print OUT "  -import verilog -into systemc $module_name -file ${module_name}_ies.map\n";
    print OUT "\n";
    print OUT "## please add your include header path to \"-I\", if any\n";
    print OUT "irun \\\n";
    print OUT "  -64bit \\\n";
    print OUT $opt_subd ? "  ../tb/*.cpp \\\n" : "  *.cpp \\\n";
    print OUT $opt_subd ? "  ../sva/*.sv \\\n" : "  *.sv \\\n" if($opt_sva || $hdl_ies_on);
    print OUT "  -sysc \\\n";
    print OUT "  -sctop sc_main \\\n";
    print OUT "  -timescale 1ps/1ps \\\n";
    print OUT "  -I\${STRATUS_HOME}/share/stratus/include \\\n" if ($opt_stratus);
    print OUT "  -I$env_ssgen \\\n" if (!$opt_standard);
    print OUT "  -I. \\\n";
    print OUT "  -I\${CTS_DIR}/share/ctos/include/ctos_clock_gating \\\n" if (!$opt_standard && $use_ctos_cg);
    print OUT "  -D$rtl_macro \\\n";
    print OUT "  -D$mem_macro \\\n" if (!$opt_standard);
    print OUT "  -D_IES_ABVIP \\\n" if ($use_aigen);
    print OUT "  -D_USE_SVA \\\n" if ($opt_sva);
    print OUT "  -incdir ../sva \\\n" if ($opt_subd && ($opt_sva || $hdl_ies_on));
    print OUT "  -loadpli1 \${VIPCAT_HOME}/tools/lib/libviputil.so:cdsVip_PLIPtr \\\n" if ($use_aigen);
    print OUT "#  -coverage all \\\n";
    print OUT "#  -covoverwrite \\\n";
    print OUT "#  -covfile cov.ccf \\\n";
    print OUT "#  -covtest test \\\n";
    print OUT "#  +systemc_args+\"\" \\\n";
    print OUT "#  -access r -input probe.tcl\n";
    print OUT "\n";
    print OUT "#setenv VMANAGER_JAVA_OPTIONS -Djava.io.tmpdir=INCA_libs\n";
    print OUT "#imc -64bit -batch -init ./imc.cmd -licqueue -logfile ./imc.log -nostdout\n";
    if (!$opt_subd) {
        print OUT "\n";
        print OUT "if ( -e $module_name.h.t ) mv $module_name.h.t $module_name.h\n";
        print OUT "if ( -e $module_name.cpp.t ) mv $module_name.cpp.t $module_name.cpp\n";
    }
    close(OUT);

    $outfile = "probe.tcl";
    &my_open(*OUT, "##", "ies", 1);
    print OUT "database -open waves -default\n";
    #print OUT "probe -create -all -depth all\n";
    print OUT "probe -create [regsub {\\\$[^ ]+} [scope -tops] {}] -all -depth all\n";
    print OUT "run\n";
    print OUT "exit\n";
    close(OUT);

    $outfile = "imc.cmd";
    &my_open(*OUT, "##", "ies", 1);
    #print OUT "load test\n";
    #print OUT "report -detail -metrics assertion -all\n";
    print OUT "merge -out ./cov_work/scope/all -metrics all -initial_model union_all -message 1 -overwrite ./cov_work/scope/*\n";
    print OUT "load ./cov_work/scope/all\n";
    print OUT "foreach type {summary detail} {\n";
    print OUT $tab,  "report -\$type -metrics block:expression:toggle:fsm:assertion:covergroup -both\n";
    print OUT "}\n";
    print OUT "file delete -force ./cov_work/scope/all\n";
    print OUT "exit\n";
    close(OUT);

    $outfile = "cov.ccf";
    &my_open(*OUT, "##", "ies", 1);
    print OUT "set_assign_scoring\n";
    print OUT "set_branch_scoring\n";
    print OUT "set_statement_scoring\n";
    print OUT "set_expr_scoring -control -all\n";
    close(OUT);

    $outfile = "run_ies.csh";
    &my_open(*OUT, "#!", "ies", 0, "755");
    if($opt_ins) {
        print OUT "${subscdir}run_cpp2ins.csh\n\n";
        print OUT "if ( \$? == 1 ) then\n";
        print OUT $tab, "echo \"FAIL ${subscdir}run_cpp2ins.csh\"\n";
        print OUT $tab, "echo \"Please execute IES with -skip_ins first\"\n";
        print OUT $tab, "exit 1\n";
        print OUT "endif\n";
    }
    print OUT "source $env_ctos\n" if (!$opt_standard && $use_ctos_cg);
    print OUT "source $env_stratus\n" if ($opt_stratus);
    print OUT "source $env_ies\n";
    print OUT "bs -M $bs_ies_mem -os $bs_ies_os ncverilog_lsfsh\n";
    close(OUT);
    $module_name = $org_module_name;
}

##
## print setup for ABVIP in IES
##
sub print_ies_abvip {
    print OUT "set VIPCAT_HOME = $env_vipcat\n";
    print OUT "set APB_ABVIP   = \${VIPCAT_HOME}/tools/abvip/apb4\n";
    print OUT "\n";
    print OUT "ncverilog -64bit\\\n";
    print OUT "  -c \${APB_ABVIP}/rtl/apb4_monitor.svp \\\n";
    print OUT "  +incdir+\${APB_ABVIP}/rtl \\\n";
    print OUT "  +incdir+\${VIPCAT_HOME}/utils/cdn_v_utils \\\n";
    print OUT "  -loadpli1 \${VIPCAT_HOME}/tools/lib/libviputil.so:cdsVip_PLIPtr\n";
    print OUT "\n";
    print OUT "ncverilog -64bit \\\n";
    print OUT "  -c ${module_name}_ies_apb_monitor.v \\\n";
    print OUT "  +incdir+\${APB_ABVIP}/rtl \\\n";
    print OUT "  +incdir+\${VIPCAT_HOME}/utils/cdn_v_utils \\\n";
    print OUT "  -loadpli1 \${VIPCAT_HOME}/tools/lib/libviputil.so:cdsVip_PLIPtr\n";
    print OUT "\n";
    print OUT "ncshell -64bit -NOCOMPILE -import verilog -into systemc \\\n";
    print OUT "  ${module_name}_ies_apb_monitor -file ${module_name}_ies_apb_monitor.map\n";
    print OUT "\n";
}

##
## print setup for sva module in IES
##
sub print_ies_sva {
    $sva_dir = $opt_subd ? "../sva/" : "";
    print OUT "ncverilog -64bit -c -sv $sva_dir${module_name}_sva.v\n";
    print OUT "\n";
    print OUT "ncshell -64bit -NOCOMPILE -import verilog -into systemc \\\n";
    print OUT "  ${module_name}_sva -file ${module_name}_ies.map\n";
    print OUT "\n";
}

##
## generate script file for formal verification
##
sub gen_ifv_scr {
    if ($top_mode == 0 && $use_template == 1) {
        $module_name = @{$tmpl_inst_list[0]}[MOD_NAME];
    }
    $outfile = "ifv_" . $module_name . ".tcl";
    my $subdir = $opt_subd ? "../src/" : "";
    my $rtldir = $opt_subd ? "../rtl/" : "";
    &my_open(*OUT, "##", "ifv", 0);

    print OUT "# Parameters\n";
    print OUT "set PERIOD 10\n\n";

    if (@clk_list > 0) {
        print OUT "# Clock specification\n";
        print OUT "clock -add";
        foreach $elm (@clk_list) {
            next if (@$elm[T_NAME] eq "");
            print OUT " @$elm[T_NAME]";
        }
        print OUT "\n\n";
    }

    print OUT "# Initialization\n";
    foreach $elm (@rst_list) {
        next if (@$elm[T_NAME] eq "");
        next if (@$elm[T_TYPE] eq "soft_reset");
        print OUT "force @$elm[T_NAME] ";
        print OUT (@$elm[T_INIT] eq "pos") ? "1" : "0";
    }
    print OUT "\n";
    print OUT "run \${PERIOD}\n";
    print OUT "init -load -current\n";
    print OUT "init -show\n\n";

    print OUT "# Deactivate reset for formal analysis\n";
    foreach $elm (@rst_list) {
        next if (@$elm[T_NAME] eq "");
        next if (@$elm[T_TYPE] eq "soft_reset");
        print OUT "constraint -add -pin @$elm[T_NAME] ";
        print OUT (@$elm[T_INIT] eq "pos") ? "0" : "1", "\n";
    }

    print OUT "\n";
    print OUT "# Please add your defined interactive assertions, if any\n\n";

    print OUT "# Define variables\n";
    print OUT "define effort 10s\n";
    print OUT "#define cpu_sharing on\n";
    print OUT "#define witness_check off\n\n";

    print OUT "# Start the verification\n";
    print OUT "prove\n";
    print OUT "assertion -show -verbose -time -all -list\n\n";

    print OUT "# Generate fail data base\n";
    print OUT "source utils.tcl\n";
    print OUT "genFailedDataBase cex\n";

    print OUT "# Show the constraints\n";
    print OUT "constraint -show\n\n";
    print OUT "# Exit IFV\n";
    print OUT "exit\n";
    close(OUT);

    $outfile = "utils.tcl";
    &my_open(*OUT, "##", "ifv", 0);

    print OUT "proc getFailedAssertionName {} {\n";
    print OUT $tab x1, "set tmp [assertion -show -status Fail]\n";
    print OUT $tab x1, "set lst [split \$tmp \\n]\n";
    print OUT $tab x1, "set nms {}\n";
    print OUT $tab x1, "set cover [assertion -show -cover -status Fail]\n";
    print OUT $tab x1, "foreach {a} \$lst {\n";
    print OUT $tab x2, "if {\$a=={}} { continue }\n";
    print OUT $tab x2, "regexp {(\\S.*) :} \$a m1 m2\n";
    print OUT $tab x2, "if { [lsearch \$cover \$m2] < 0 } {\n";
    print OUT $tab x3, "lappend nms \$m2\n";
    print OUT $tab x2, "}\n";
    print OUT $tab x1, "}\n";
    print OUT $tab x1, "return \$nms\n";
    print OUT "}\n";
    print OUT "\n";
    print OUT "proc genFailedAssertionSSTExport {dir nms} {\n";
    print OUT $tab x1, "if {[file exists \$dir] == 0} {\n";
    print OUT $tab x2, "puts \"Generating \${dir} Directory ...\"\n";
    print OUT $tab x2, "mkdir \$dir\n";
    print OUT $tab x1, "}\n";
    print OUT $tab x1, "foreach {nm} \$nms {\n";
    print OUT $tab x2, "eval debug \$nm -sstexport \$dir/\$nm -overwrite\n";
    print OUT $tab x1, "}\n";
    print OUT "}\n";
    print OUT "\n";
    print OUT "proc genFailedAssertionVCDExport {dir nms} {\n";
    print OUT $tab x1, "if {[file exists \$dir] == 0} {\n";
    print OUT $tab x2, "puts \"Generating \${dir} Directory ...\"\n";
    print OUT $tab x2, "mkdir \$dir\n";
    print OUT $tab x1, "}\n";
    print OUT $tab x1, "foreach {nm} \$nms {\n";
    print OUT $tab x2, "eval simvisdbutil \$dir/\$nm -output \$dir/\$nm/cex.vcd -vcd -overwrite  2> /dev/null\n";
    print OUT $tab x1, "}\n";
    print OUT "}\n";
    print OUT "\n";
    print OUT "proc genFailedDataBase {dir} {\n";
    print OUT $tab x1, "set nms [getFailedAssertionName]\n";
    print OUT $tab x1, "if {\$nms=={}} {\n";
    print OUT $tab x2, "puts \"genFailedDataBase: Failed assertion not found. This procedure is ignored.\"\n";
    print OUT $tab x1, "} else {\n";
    print OUT $tab x2, "genFailedAssertionSSTExport \$dir \$nms\n";
    print OUT $tab x2, "genFailedAssertionVCDExport \$dir \$nms\n";
    print OUT $tab x1, "}\n";
    print OUT "}\n";

    close(OUT);

    $outfile = "run_ifv_$module_name.csh";
    $subdir = $opt_subd ? "../rtl/" : "";
    &my_open(*OUT, "#!", "ifv", 0, "755");

    if ($use_aigen == 1) {
        print OUT "set VIPCAT_HOME = $env_vipcat\n";
        print OUT "set APB_ABVIP   = \${VIPCAT_HOME}/tools/abvip/apb4\n\n";
    }
    print OUT "source $env_ies\n\n";
    print OUT "# Please add assertion modules, if any\n";
    print OUT "bs -M $bs_ifv_mem -os $bs_ifv_os iev \\\n";
    print OUT "  +noassert_synth_pragma \\\n";
    if ($use_aigen == 1) {
        print OUT "  +nohal -y \${APB_ABVIP}/rtl \\\n";
        print OUT "  +libext+.sv +incdir+\${APB_ABVIP}/rtl \\\n";
        print OUT "  +incdir+\${VIPCAT_HOME}/utils/cdn_v_utils \\\n";
        print OUT "  +irunargs+\"-loadpli1 \${VIPCAT_HOME}/tools/lib/libviputil.so:cdsVip_PLIPtr\" \\\n";
        print OUT "  ${module_name}_ifv_apb4_bind.sv \\\n";
    }
    print OUT "  +tcl+\"ifv_$module_name.tcl\" \\\n";
    if ($opt_sva == 1) {
        $sva_dir = $opt_subd ? "../sva/" : "";
        print OUT "  $sva_dir${module_name}_sva.v +extbind+$sva_dir${module_name}_sva_bind.sv \\\n";
    }
    if ($top_mode == 0) {
        print OUT "  $subdir$module_name.v\n";
    }
    else {
        print OUT "  $subdir\*.v\n";
    }
    close(OUT);

    if ($use_aigen == 1) {
        my $awid = "";
        my $dwid = "";
        my $swid = "";
        foreach $port (@in_list) {
            if (@$port[T_NAME] eq "PADDR") {
                $awid = @$port[T_WID];
            }
            if (@$port[T_NAME] eq "PWDATA") {
                $dwid = @$port[T_WID];
            }
        }
        $outfile = $module_name."_ifv_apb4_bind.sv";
        &my_open(*OUT, "//", "ifv", 0);
        print OUT "bind $module_name apb4_master #(\n";
        print OUT $tab, ".ABUS_WIDTH($awid),\n";
        print OUT $tab, ".DBUS_WIDTH($dwid),\n";
        print OUT $tab, ".COVERAGE_ON(1),\n";
        print OUT $tab, ".RST_CHECKS_ON(1),\n";
        print OUT $tab, ".RECM_CHECKS_ON(1),\n";
        print OUT $tab, ".XCHECKS_ON(0)\n";
        print OUT ") apb_master_i (\n";
        print OUT $tab, ".pclk(PCLK),\n";
        print OUT $tab, ".presetn(PRESETn),\n";
        print OUT $tab, ".psel(PSEL),\n";
        print OUT $tab, ".penable(PENABLE),\n";
        print OUT $tab, ".paddr(PADDR),\n";
        print OUT $tab, ".pwrite(PWRITE),\n";
        print OUT $tab, ".pwdata(PWDATA),\n";
        print OUT $tab, ".pstrb(PSTRB),\n";
        print OUT $tab, ".pprot(3'h0),\n";
        print OUT $tab, ".pready(PREADY),\n";
        print OUT $tab, ".prdata(PRDATA),\n";
        print OUT $tab, ".pslverr(1'h0)\n";
        print OUT ");\n";
        close(OUT);
    }
    $module_name = $org_module_name;
}

##
## generate random pattern file for sc-rtl simulation based equivalence checker
##
sub gen_sim_eq_random {
    if ($top_mode == 0 && $use_template == 1) {
        $module_name = @{$tmpl_inst_list[0]}[MOD_NAME];
    }
    $outfile = "${module_name}_stimulus.h";
    &my_open(*OUT_RAND, "//", "sim_eq/$module_name", 0);

    # calculate number of input ports (including array)
    $used_reg = 0;
    $num = 0;
    foreach $elm (@in_list, @in_list_insert) {
        next if (@$elm[T_NAME] eq "");
        if (@$elm[T_ARRAY] eq "") {
            $num++;
        }
        else {
            my @dim = ();
            while (@$elm[T_ARRAY] =~ /\w+/g) {
                &get_array_info(\@dim, $&);
            }
            my $a = 1;
            for (my $i=0; $i<@dim; $i++) {
                $a *= $dim[$i];
            }
            $num += $a;
        }
        if (@$elm[T_FLG] & FLG_CATG_REG) {
            $used_reg = 1;
        }
    }

    # calculate value for modular in loop
    $max_cnt = 100;
    my $define_list = ($top_mode != 0) ? \@define_in_top_list : \@define_in_list;
    foreach $elm (@$define_list) {
        if (@$elm[G_NAME] eq "SIM_EQ_MAX_CNT") {
            @$elm[G_FLAG] |= FLG_USED;
            $max_cnt = &get_macro_value("SIM_EQ_MAX_CNT", "", 0);
            last;
        }
    }

    # calculate max_cnt pipeline latency
    $max_lat = 3;
    foreach my $elm (@thread_list) {
        next if (@$elm[TH_NAME] eq "");
        if (@$elm[TH_LAT] > $max_lat) {
            $max_lat = @$elm[TH_LAT];
        }
    }

    print OUT_RAND "// \"${module_name}_stimulus.h\"\n";
    print OUT_RAND "\n";
    print OUT_RAND $tab, "wait(4);\n";

    # loop - 1st
    print OUT_RAND "\n";
    print OUT_RAND $tab, "for (int i=0; i<";
    print OUT_RAND ((4000>($max_cnt*100)) ? 4000 : ($max_cnt*100));
    print OUT_RAND "; i++) {\n";
    foreach $elm (@in_list, @in_list_insert) {
        next if (@$elm[T_NAME] eq "");
        if (@$elm[T_FLG] & FLG_CATG_DATA) {
            &print_data_random(@$elm[T_NAME], @$elm[T_TYPE], @$elm[T_ARRAY], @$elm[T_WID], $tab x2);
        }
    }
    if ($used_reg == 1) {
        print OUT_RAND $tab x2, "if (i%$max_cnt==0) {\n";
        foreach $elm (@in_list, @in_list_insert) {
            next if (@$elm[T_NAME] eq "");
            if (@$elm[T_FLG] & FLG_CATG_REG) {
                &print_data_random(@$elm[T_NAME], @$elm[T_TYPE], @$elm[T_ARRAY], @$elm[T_WID], $tab x3);
            }
        }
        print OUT_RAND $tab x2, "}\n";
    }
    print OUT_RAND $tab x2, "wait();\n";
    print OUT_RAND $tab, "}\n";

    # enable - 2nd
    print OUT_RAND "\n";
    foreach $elm (@in_list, @in_list_insert) {
        next if (@$elm[T_NAME] eq "");
        if (@$elm[T_FLG] & FLG_CATG_EN) {
            print OUT_RAND $tab, "@$elm[T_NAME].write(";
            print OUT_RAND ((@$elm[T_FLG] & FLG_ACTV_LOW) ? "0" : "1") . ");\n";
        }
    }

    # stall - 2nd
    foreach $elm (@in_list, @in_list_insert) {
        next if (@$elm[T_NAME] eq "");
        if (@$elm[T_FLG] & FLG_CATG_STALL) {
            print OUT_RAND $tab, "@$elm[T_NAME].write(";
            print OUT_RAND ((@$elm[T_FLG] & FLG_ACTV_LOW) ? "0" : "1") . ");\n";
        }
    }
    print OUT_RAND "\n";
    print OUT_RAND $tab, "wait($max_lat);\n";

    # loop - 2nd
    my $f = ($num < 10) ? 0.5 :
            ($num < 20) ? 1   :
            ($num < 50) ? 100 : 1000;

    print OUT_RAND "\n";
    print OUT_RAND $tab   , "for (int i=0; i<";
    print OUT_RAND (((8000*$f) > ($max_cnt*500)) ? (8000*$f) : ($max_cnt*500));
    print OUT_RAND "; i++) {\n";
    print OUT_RAND $tab x2, "if (i%$max_cnt==0) {\n";
    foreach $elm (@in_list, @in_list_insert) {
        next if (@$elm[T_NAME] eq "");
        next if (@$elm[T_FLG] & FLG_DONT_TOUCH);
        if (@$elm[T_FLG] & FLG_CATG_EN) {
            print OUT_RAND $tab x3, "@$elm[T_NAME].write(";
            print OUT_RAND (@$elm[T_FLG] & FLG_ACTV_LOW) ? "1" : "0";
            print OUT_RAND ");\n";
        }
    }
    print OUT_RAND $tab x3, "wait(rand()%4+1);\n";
    foreach $elm (@in_list, @in_list_insert) {
        next if (@$elm[T_NAME] eq "");
        if (@$elm[T_FLG] & FLG_RANDOM) {
            print OUT_RAND $tab x3, "@$elm[T_NAME].write(rand()%2);\n";
        }
        elsif (@$elm[T_FLG] & FLG_DONT_TOUCH) {
            next;
        }
        elsif (@$elm[T_FLG] & FLG_CATG_STALL) {
            print OUT_RAND $tab x3, "@$elm[T_NAME].write(rand()%2);\n";
        }
        elsif (@$elm[T_FLG] & FLG_CATG_EN) {
            print OUT_RAND $tab x3, "@$elm[T_NAME].write(";
            print OUT_RAND (@$elm[T_FLG] & FLG_ACTV_LOW) ? "0" : "1";
            print OUT_RAND ");\n";
        }
    }
    print OUT_RAND $tab x2, "}\n";
    foreach $elm (@in_list, @in_list_insert) {
        next if (@$elm[T_NAME] eq "");
        if (@$elm[T_FLG] & FLG_CATG_DATA) {
            &print_data_random(@$elm[T_NAME], @$elm[T_TYPE], @$elm[T_ARRAY], @$elm[T_WID], $tab x2);
        }
    }
    if ($used_reg == 1) {
        print OUT_RAND $tab x2, "if (i%$max_cnt==0) {\n";
        foreach $elm (@in_list, @in_list_insert) {
            next if (@$elm[T_NAME] eq "");
            if (@$elm[T_FLG] & FLG_CATG_REG) {
                &print_data_random(@$elm[T_NAME], @$elm[T_TYPE], @$elm[T_ARRAY], @$elm[T_WID], $tab x3);
            }
        }
        print OUT_RAND $tab x2, "}\n";
    }
    print OUT_RAND $tab x2, "wait();\n";
    print OUT_RAND $tab , "}\n";

    print OUT_RAND "\n";
    print OUT_RAND "// end \"${module_name}_stimulus.h\"\n";
    close(OUT_RAND);
    $module_name = $org_module_name;
}

##
## generate script files for sc-rtl simulation based equivalence checker
##
sub gen_sim_eq_scr {
    if ($top_mode == 0 && $use_template == 1) {
        $module_name = @{$tmpl_inst_list[0]}[MOD_NAME];
    }
    my $srcdir = $opt_subd ? "../../src/" : "";
    my $rtldir = $opt_subd ? "../../rtl/" : "";
    my $scrdir = $opt_subd ? "../" : "";

    &gen_sim_eq_jg_tcl(0);  # JG-SEC
    &gen_sim_eq_jg_tcl(1);  # JG-SPV

    $outfile = ($opt_subd) ? "ncverilog_lsfsh" :"ncverilog_lsfsh_eq";
    &my_open(*OUT, "#!", "sim_eq/${module_name}", 0, "755");
    print OUT "setenv CDNS_GCOV `ncroot`/tools/systemc/gcc/install/bin/gcov\n";
    print OUT "\n";
    print OUT "rm -rf INCA_libs irun.log ncsc.log waves.shm cov_work jgproject trace\n";
    print OUT "if ( -e ${module_name}_stimulus.h.T ) mv ${module_name}_stimulus.h.T ${module_name}_stimulus.h\n";
    print OUT "mkdir trace\n";
    print OUT "date > result.log\n";
    print OUT "\n";

    # create systemc clone
    print OUT "if ( -e ${module_name}_eq.h ) rm -f ${module_name}_eq.h\n";
    print OUT "if ( -e ${module_name}_eq.cpp ) rm -f ${module_name}_eq.cpp\n";
    print OUT "\n";
    print OUT "if ( -e $srcdir$module_name.h ) then\n";
    print OUT $tab, "cp $srcdir$module_name.h ${module_name}_eq.h\n";
    print OUT $tab, "sed -i -e 's/\\<$module_name\\>/${module_name}_eq/' ${module_name}_eq.h\n";
    print OUT $tab, "sed -i -e 's/\\<${MODULE_NAME}_H\\>/${MODULE_NAME}_EQ_H/' ${module_name}_eq.h\n";
    print OUT "endif\n";
    print OUT "if ( -e $srcdir$module_name.cpp ) then\n";
    print OUT $tab, "cp $srcdir$module_name.cpp ${module_name}_eq.cpp\n";
    print OUT $tab, "sed -i -e 's/\\<$module_name\\>/${module_name}_eq/' ${module_name}_eq.cpp\n";
    print OUT "endif\n";

    if ($opt_subd == 0) {
        print OUT "\n";
        print OUT "if ( -e $module_name.h ) mv $module_name.h $module_name.h.t\n";
        print OUT "if ( -e $module_name.cpp ) mv $module_name.cpp $module_name.cpp.t\n";
    }
    elsif ($top_mode == 1) {
        print OUT "\n";
        print OUT "# Please add sub modules for lower hierarchy if any\n";
        foreach $mod (@mod_list, @mod_list_sync) {
            next if (@$elm[MOD_FLG] & FLG_MULTI || @$elm[MOD_DBG] ne "");
            print OUT "if ( -e @$mod[MOD_NAME].h ) rm -f @$mod[MOD_NAME]\n";
            print OUT "if ( -e @$mod[MOD_NAME].cpp ) rm -f @$mod[MOD_NAME]\n";
            print OUT "ln -s $srcdir@$mod[MOD_NAME].h\n";
            print OUT "ln -s $srcdir@$mod[MOD_NAME].cpp\n";
        }
    }

    print OUT "\n";
    if ($top_mode == 1) {
        print OUT "## please add sub modules for lower hierarchy if any\n";
        print OUT "ncverilog -c -64bit \\\n";
        foreach $mod (@mod_list, @mod_list_sync) {
            next if (@$elm[MOD_FLG] & FLG_MULTI || @$elm[MOD_DBG] ne "");
            print OUT "  @$mod[MOD_NAME]$postfix.v \\\n";
        }
        print OUT "\n";
    }
    print OUT "\n";
    print OUT "ncverilog -c -64bit $rtldir$module_name.v\n";
    print OUT "\n";
    print OUT "ncshell -NOCOMPILE -64bit \\\n";
    print OUT "  -import verilog -into systemc $module_name -file ${module_name}_sim_eq.map\n";
    print OUT "\n";

    # random simulation
    print OUT "irun \\\n";
    print OUT "  -64bit \\\n";
    print OUT "  -licqueue \\\n";
    print OUT "  *.cpp \\\n";
    print OUT "  -sysc \\\n";
    print OUT "  -sctop sc_main \\\n";
    print OUT "  -timescale 1ps/1ps \\\n";
    print OUT "  -I\${STRATUS_HOME}/share/stratus/include \\\n" if ($opt_stratus);
    print OUT "  -I$env_ssgen \\\n" if (!$opt_standard);
    print OUT "  -I. \\\n";
    print OUT "  -I$srcdir \\\n" if ($opt_subd);
    print OUT "  -coverage all \\\n";
    print OUT "  -covfile ${scrdir}cov.ccf \\\n";
    print OUT "  -access +C\n";
    print OUT "\n";

    # compare results b/w SC & HLS-RTL
    for (my $i=0; $i<@out_list_enable; $i++) {
        print OUT "diff sc$i.log rtl$i.log > /dev/null && echo \"No mismatch $i @ Random\" >> result.log || echo \"Mismatch $i @ Random\" >> result.log\n"
    }

    # JG-UNR & JG-SPV/JG-SEC
    print OUT "\n";
    print OUT "######\n";
    print OUT "######\n";
    print OUT "irun \\\n";
    print OUT "  -64bit \\\n";
    print OUT "  -licqueue \\\n";
    print OUT "  -R -jgsynthesis -unr -jg -jgargs \"-enable_license_option\" \\\n";
    print OUT "  -elab_options_jg \" -disable_auto_bbox\" \\\n";
    print OUT "  -inst_top sc_main.${module_name}0 \\\n";
    print OUT "  -covdb ./cov_work/scope/test -covfile ${scrdir}cov.ccf -coverage all \\\n";
    print OUT "  -input jg_${module_name}_\$1.tcl \\\n";
    print OUT "  |& tee jg_${module_name}_\$1.log\n";
    print OUT "\n";
    print OUT "rm -f jgproject/traces/*_precondition.vcd >& /dev/null\n";
    print OUT "rm -f jgproject/traces.bak/*_precondition.vcd >& /dev/null\n";

    # direct patterns simulation
    print OUT "\n";
    print OUT "######\n";
    print OUT "######\n";
    print OUT "set find = \`find ./ -name \"*.vcd*\" | wc -l\`\n";
    print OUT "if ( \$find != 0 ) then\n";
    print OUT $tab x1, "find ./ -name \"*.vcd*\" > trace_list.txt\n";
    print OUT $tab x1, "set sc = \"$srcdir$module_name.h\"\n";
    print OUT $tab x1, "mv -f ${module_name}_stimulus.h ${module_name}_stimulus.h.T\n";
    print OUT $tab x1, "set n = 0\n";
    print OUT $tab x1, "foreach vcd ( \`cat trace_list.txt\` )\n";
    print OUT $tab x2, "if ( \$vcd:e == \"vcd\" ) then\n";
    print OUT $tab x3, "${scrdir}vcd2tb.pl \$sc \"\$vcd\" > ${module_name}_stimulus.h\n";
    print OUT $tab x2, "else\n";
    print OUT $tab x3, "set file = `basename \$vcd .vcd.gz`\n";
    print OUT $tab x3, "gzip -dc \"\$vcd\" > \$file\n";
    print OUT $tab x3, "${scrdir}vcd2tb.pl \$sc \"\$file\" > ${module_name}_stimulus.h\n";
    print OUT $tab x3, "rm -f \"\$file\"\n";
    print OUT $tab x2, "endif\n";
    print OUT "\n";
    print OUT $tab x2, "irun -64bit \\\n";
    print OUT $tab x2, "  -licqueue \\\n";
    print OUT $tab x2, "  *.cpp \\\n";
    print OUT $tab x2, "  -sysc \\\n";
    print OUT $tab x2, "  -sctop sc_main \\\n";
    print OUT $tab x2, "  -timescale 1ps/1ps \\\n";
    print OUT $tab x2, "  -I$env_ssgen \\\n" if (!$opt_standard);
    print OUT $tab x2, "  -I. \\\n";
    print OUT $tab x2, "  -I$srcdir \\\n" if ($opt_subd);
    print OUT $tab x2, "  -coverage all \\\n";
    print OUT $tab x2, "  -covfile ${scrdir}cov.ccf \\\n";
    print OUT $tab x2, "  -covtest test\${n} \\\n";
    print OUT $tab x2, "  -covoverwrite \\\n";
    print OUT $tab x2, "  -access +C \\\n";
    print OUT "#";
    print OUT $tab x2, "  -input ${scrdir}probe.tcl\n";
    print OUT "\n";
    for (my $i=0; $i<@out_list_enable; $i++) {
        print OUT $tab x2, "diff sc$i.log rtl$i.log > /dev/null && echo \"No mismatch $i @ \$vcd\" >> result.log || echo \"Mismatch $i @ \$vcd\" >> result.log\n";
        print OUT $tab x2, "wc -l sc$i.log >> result.log\n";
    }
    print OUT $tab x2, "@ n = \$n + 1\n";
    print OUT "\n";
    print OUT $tab x1, "end\n";
    print OUT $tab x1, "rm -f trace_list.txt\n";
    print OUT $tab x1, "mv -f ${module_name}_stimulus.h.T ${module_name}_stimulus.h\n";
    print OUT "endif\n";

    # update coverage
    print OUT "\n";
    print OUT "######\n";
    print OUT "######\n";
    print OUT "setenv VMANAGER_JAVA_OPTIONS -Djava.io.tmpdir=INCA_libs\n";
    print OUT "imc -batch -init ${scrdir}imc_eq.cmd\n";
    print OUT "\n";
    print OUT "date >> result.log\n";
    print OUT "\n";
    print OUT "mv result.log result_\$1.log\n";
    print OUT "mv imc_cov_eq.log imc_cov_eq_\$1.log\n";
    print OUT "mv imc_cov_ref.log imc_cov_ref_\$1.log\n";
    close(OUT);

    $outfile = "probe.tcl";
    &my_open(*OUT, "##", "sim_eq", 1);
    print OUT "database -open waves -default\n";
    print OUT "probe -create [regsub {\\\$[^ ]+} [scope -tops] {}] -all -depth all\n";
    print OUT "run\n";
    print OUT "exit\n";
    close(OUT);

    $outfile = "imc_eq.cmd";
    &my_open(*OUT, "##", "sim_eq", 1);
    print OUT "merge -out all -metrics all -initial_model union_all -message 1 -overwrite *\n";
    print OUT "load all\n";
    print OUT "\n";
    print OUT "report -summary -text -metrics block:expression:toggle:fsm -out imc_cov_ref.log -all\n";
    print OUT "report -detail -text -metrics all -out imc_cov_ref.log -uncovered -append on\n";
    print OUT "report -detail -text -metrics all -out imc_cov_ref.log -covered -append on\n";
    print OUT "\n";
    print OUT "exclude -inst *... -metrics block:expression:toggle -unr\n";
    print OUT "\n";
    print OUT "report -summary -text -metrics block:expression:toggle:fsm -out imc_cov_eq.log -all\n";
    print OUT "report -detail -text -metrics all -out imc_cov_eq.log -uncovered -append on\n";
    print OUT "\n";
    print OUT "exit\n";
    close(OUT);

    $outfile = "cov.ccf";
    &my_open(*OUT, "##", "sim_eq", 1);
    print OUT "set_assign_scoring\n";
    print OUT "set_branch_scoring\n";
    print OUT "set_statement_scoring\n";
    print OUT "set_expr_scoring -control -all\n";
    close(OUT);

    $outfile = "run_sim_eq.csh";
    &my_open(*OUT, "#!", "sim_eq", 0, "755");
    print OUT "source $env_ctos\n" if (!$opt_standard && $use_ctos_cg);
    print OUT "source $env_stratus\n" if ($opt_stratus);
    print OUT "source $env_ies_eq\n";
    print OUT "source $env_jg_eq\n";
    print OUT "set BS = \"bs -M $bs_sim_eq_mem -os $bs_ies_os\"\n";
    print OUT "\n";
    print OUT "set JG_OPT = \"sec\"\n";
    print OUT "set JG_TCL = ()\n";
    print OUT "while (\$#argv > 0)\n";
    print OUT $tab, "switch (\$1)\n";
    print OUT $tab, "case -spv:\n";
    print OUT $tab x2, "set JG_OPT = \"spv\"\n";
    print OUT $tab x2, "shift\n";
    print OUT $tab x2, "breaksw\n";
    print OUT $tab, "default:\n";
    print OUT $tab x2, "set JG_TCL = (\$JG_TCL \$1)\n";
    print OUT $tab x2, "shift\n";
    print OUT $tab x2, "breaksw\n";
    print OUT $tab, "endsw\n";
    print OUT "end\n";
    print OUT "\n";
    print OUT "if(\$#JG_TCL == 0) then\n";
    print OUT $tab, "set JG_TCL = `find . -name \"jg_*_\$JG_OPT.tcl\" | grep -v \"INCA_libs\"`\n";
    print OUT "endif\n";
    print OUT "\n";
    print OUT "foreach a (\$JG_TCL)\n";
    print OUT $tab, "if( ! -e \$a ) then\n";
    print OUT $tab x2, "echo \"ERROR: Cannot find \$a !\"\n";
    print OUT $tab x2, "continue\n";
    print OUT $tab, "endif\n";
    print OUT $tab, "if ( \"\$a\" !~ \"*_\$JG_OPT.tcl\" ) then\n";
    print OUT $tab x2, "set JG_OPT = `echo \$a:r:t | awk -F\"_\" '{print \$NF}'`\n";
    print OUT $tab, "endif\n";
    print OUT "\n";
    print OUT $tab, "set module = `echo \$a:r:t | sed -e 's/jg_//' | sed -e 's/_'\$JG_OPT'//'`\n";
    print OUT $tab, "cd \$module\n" if ($opt_subd);
    print OUT $tab, "\$BS ncverilog_lsfsh \$JG_OPT\n";
    print OUT $tab, "cd ..\n" if ($opt_subd);
    print OUT "end\n";

    close(OUT);

    $outfile = "vcd2tb.pl";
    &my_open(*OUT, "#!", "sim_eq", 1, "755", 1);
    print OUT "\n";
    print OUT "open(IN,\$ARGV[0]);\n";
    print OUT "\@input = ();\n";
    print OUT "while (<IN>) {\n";
    print OUT "    my \$l = \$_;\n";
    print OUT "    \$l =~ s/^\\s*//g;\n";
    print OUT "    if(\$l =~ /(sc_in)(\\s*)(<)/ && \$l !~ /^\\/\\//) {\n";
    print OUT "        my \$name = substr(\$l,rindex(\$l,\">\")+1);\n";
    print OUT "        my \$name = substr(\$name,0,index(\$name,\";\"));\n";
    print OUT "        \$name =~ s/(\\s*|\\n)//g;\n";
    print OUT "        if(\$name !~ /clk/) {\n";
    print OUT "            push(\@input,\$name);\n";
    print OUT "        }\n";
    print OUT "    }\n";
    print OUT "}\n";
    print OUT "close(IN);\n";
    print OUT "\n";
    print OUT "print \"// \$ARGV[1]\\n\";\n";
    print OUT "foreach \$i (\@input) {\n";
    print OUT "    if(\$i !~ /rst/) {\n";
    print OUT "        print \"\$i\\.write(0);\\n\";\n";
    print OUT "    }\n";
    print OUT "}\n";
    print OUT "\n";
    print OUT "\$vcd_area = 0;\n";
    print OUT "%hash = ();\n";
    print OUT "\@declared = ();\n";
    print OUT "\@hashed_input = ();\n";
    print OUT "open(IN,\$ARGV[1]);\n";
    print OUT "while (<IN>) {\n";
    print OUT "    my \$l = \$_;\n";
    print OUT "    if(\$vcd_area==0) {\n";
    print OUT "        if(\$l =~ /\\\$enddefinitions/) {\n";
    print OUT "            \$vcd_area = 1;\n";
    print OUT "        }\n";
    print OUT "        elsif(\$l=~/^(\\\$var)(\\s+)(reg|wire)(\\s+)([0-9]+)(\\s+)(.+?)(\\s+)(.+?)(\\s+)(.+)/) {\n";
    print OUT "            my \$symbol = \$7;\n";
    print OUT "            my \$name   = \$9;\n";
    print OUT "            if(&comp_str(\\\@input, \$name)==1 && &comp_str(\\\@hashed_input, \$name)==0) {\n";
    print OUT "                %hash = (%hash, \$symbol => \$name);\n";
    print OUT "                push(\@hashed_input,\$name);\n";
    print OUT "            }\n";
    print OUT "        }\n";
    print OUT "    } else {\n";
    print OUT "        if(\$l=~/^(\\#)([0-9]+)/) {\n";
    print OUT "            my \$c = \$2;\n";
    print OUT "            if(\$c > 0 && \$c%10==0) {\n";
    print OUT "                print \"wait();\\n\";\n";
    print OUT "            }\n";
    print OUT "        }\n";
    print OUT "        elsif (\$l =~ /^(b)((0|1)+)(\\s+)(.+)/) {\n";
    print OUT "            my \$val = \$2;\n";
    print OUT "            my \$symbol = \$5;\n";
    print OUT "            if (exists(\$hash{\$symbol})) {\n";
    print OUT "                if (length(\$val) > 32) {\n";
    print OUT "                    my \$wid = length(\$val);\n";
    print OUT "                    my \$con = \"(\";\n";
    print OUT "                    while (length(\$val) != 0) {\n";
    print OUT "                        my \$v = substr(\$val,0,32);\n";
    print OUT "                        my \$dec = oct \"0b\" . \$v;\n";
    print OUT "                        my \$hex = sprintf \"%X\", \$dec;\n";
    print OUT "                        my \$w = length(\$v);\n";
    print OUT "                        my \$var = int(rand(10000));\n";
    print OUT "                        \$var++ if(&comp_str(\\\@declared,\$var)==1);\n";
    print OUT "                        push(\@declared,\$var);\n";
    print OUT "                        \$var = \"v\" . \$var;\n";
    print OUT "                        print \"sc_uint<\$w> \$var = 0x\$hex;\\n\";\n";
    print OUT "                        if(\$wid > 64) {\n";
    print OUT "                            \$con = \$con . \"(sc_biguint<\$w>)\$var,\";\n";
    print OUT "                        } else {\n";
    print OUT "                            \$con = \$con . \"\$var,\";\n";
    print OUT "                        }\n";
    print OUT "                        \$val = substr(\$val,32);\n";
    print OUT "                    }\n";
    print OUT "                    \$con =~ s/\\,\$/\\)/;\n";
    print OUT "                    print \"\$hash{\$symbol}\\.write(\$con);\\n\";\n";
    print OUT "                } else {\n";
    print OUT "                    my \$dec = oct \"0b\" . \$val;\n";
    print OUT "                    my \$hex = sprintf \"%X\", \$dec;\n";
    print OUT "                    print \"\$hash{\$symbol}\\.write(0x\$hex);\\n\";\n";
    print OUT "                }\n";
    print OUT "            }\n";
    print OUT "        }\n";
    print OUT "        elsif (\$l =~ /^(0|1)(.+)/) {\n";
    print OUT "            my \$val = \$1;\n";
    print OUT "            my \$symbol = \$2;\n";
    print OUT "            if (exists(\$hash{\$symbol})) {\n";
    print OUT "                print \"\$hash{\$symbol}\\.write(\$val);\\n\";\n";
    print OUT "            }\n";
    print OUT "        }\n";
    print OUT "    }\n";
    print OUT "}\n";
    print OUT "close(IN);\n";
    print OUT "print \"\\n\";\n";
    print OUT "\n";
    print OUT "sub comp_str {\n";
    print OUT "    my (\$array, \$str) = \@_;\n";
    print OUT "    foreach my \$elm (\@\$array) {\n";
    print OUT "        if (\$elm eq \$str) {\n";
    print OUT "            return 1;\n";
    print OUT "        }\n";
    print OUT "    }\n";
    print OUT "    return 0;\n";
    print OUT "}\n";
    print OUT "\n";
    close(OUT);

    $outfile = "get_fanout.pl";
    &my_open(*OUT, "#!", "sim_eq", 1, "755", 1);
    print OUT "\n";
    print OUT "\$key = \$ARGV[0];\n";
    print OUT "\$line = \$key;\n";
    print OUT "\$line =~ s/(.+)(_line_)([0-9]+)(_)([0-9]+)/\$3/;\n";
    print OUT "\$path = \$key;\n";
    print OUT "\$path =~ s/(.+)(\\.)(.+)/\$1/;\n";
    print OUT "\n";
    print OUT "open(IN,\$ARGV[1]);\n";
    print OUT "\@rtl = <IN>;\n";
    print OUT "close(IN);\n";
    print OUT "my \$i = \$line - 1;\n";
    print OUT "\n";
    print OUT "my \$l = \"\";\n";
    print OUT "my \$dir = 0; # 0: decr, 1:incr\n";
    print OUT "do {\n";
    print OUT "    \$l = \$rtl[\$i];\n";
    print OUT "    \$l =~ s/^\\s*//g;\n";
    print OUT "    \$l =~ s/^assign //g;\n";
    print OUT "    \$dir = 1 if(\$l =~ /if /);\n";
    print OUT "    if (\$dir == 1) {\n";
    print OUT "        \$i++;\n";
    print OUT "    } else {\n";
    print OUT "        \$i--;\n";
    print OUT "    }\n";
    print OUT "\n";
    print OUT "    \$cond = substr(\$l,index(\$l,\" \")+1);\n";
    print OUT "    \$cond = substr(\$cond,0,2);\n";
    print OUT "} while ( (\$cond eq \"= \" || \$cond eq \"<=\")==0 );\n";
    print OUT "\n";
    print OUT "\$reg = substr(\$l,0,index(\$l,\" \"));\n";
    print OUT "print \"set sig_list \\\"\$path.\$reg\\\"\\n\";\n";
    print OUT "if(\$cond eq \"<=\") {\n";
    print OUT "      print \"set nonblock 1\\n\";\n";
    print OUT "} else {\n";
    print OUT "      print \"set nonblock 0\\n\";\n";
    print OUT "}\n";
    print OUT "\n";
    print OUT "exit;\n";
    print OUT "\n";
    print OUT "sub comp_str {\n";
    print OUT "    my (\$array, \$str) = \@_;\n";
    print OUT "    foreach my \$elm (\@\$array) {\n";
    print OUT "        if (\$elm eq \$str) {\n";
    print OUT "            return 1;\n";
    print OUT "        }\n";
    print OUT "    }\n";
    print OUT "    return 0;\n";
    print OUT "}\n";
    close(OUT);
    $module_name = $org_module_name;
}

##
## generate tcl script for JasperGold
##   $mode : JG feature (0: JG-SEC, 1: JG-SPV)
##
sub gen_sim_eq_jg_tcl {
    my $mode = $_[0];
    my $srcdir = $opt_subd ? "../../src/" : "";
    my $rtldir = $opt_subd ? "../../rtl/" : "";
    my $scrdir = $opt_subd ? "../" : "";
    $outfile = "jg_${module_name}_" . ($mode == 0 ? "sec" : "spv") . ".tcl";
    &my_open(*OUT, "##", "sim_eq/${module_name}", 0);
    &get_valid_clock(\$clk_data);
    print OUT "\n";
    print OUT "set_prove_time_limit 2h\n";
    print OUT "\n";
    print OUT "check_unr -setup -coverage all\n";
    print OUT "\n";
    print OUT "clock ${module_name}0.@$clk_data[T_NAME]\n";

    $constrain_num = 0;
    &print_jg_reset(1, 1, 0);
    &print_jg_constrains;

    print OUT "#set_proofgrid_mode shell\n";
    print OUT "#set_proofgrid_shell {/common/N1GEtool/RBS/bin/bs -J %jg_session_id -M $bs_sim_eq_mem}\n";
    print OUT "#set_proofgrid_shell_stop {/common/lsf/bin/bkill -J %jg_session_id}\n";
    print OUT "\n";
    print OUT "set_engine_mode {Hp Ht J N I L B Tri}\n";
    print OUT "prove -all\n";
    print OUT "\n";
    print OUT "set_command_license_wait_interval 5m\n";
    print OUT "set_command_license_wait_retries 1000\n";
    print OUT "\n";
    if ($mode == 0) {
        print OUT "database -export_unicov\n";
        print OUT "\n";
        print OUT "set cov_list [check_unr -list -type reachable]\n";
        print OUT "\n";
        print OUT "report\n";
        print OUT "\n";
        print OUT "set elaborate_opts {";
        print OUT " -load_cpi worklib.${module_name}:v";
        print OUT " -cdslib ./INCA_libs/irun.nc/cds.lib";
        print OUT " -hdlvar ./INCA_libs/irun.nc/hdl.var";
        print OUT " -disable_auto_bbox }\n";
        print OUT "check_sec -setup \\\n";
        print OUT "  -spec_dut ${module_name}0 -spec_analyze_opts -clear \\\n";
        print OUT "  -spec_elaborate_opts \$elaborate_opts \\\n";
        print OUT "  -imp_dut ${module_name}0 -imp_analyze_opts -clear \\\n";
        print OUT "  -imp_elaborate_opts \$elaborate_opts \\\n";
        print OUT "  -auto_map_reset_x_values\n";
        print OUT "\n";
        print OUT "clock ${module_name}0.@$clk_data[T_NAME]\n";

        &print_jg_reset(0, 1, 0);
        &print_jg_constrains;

        for (my $i=0; $i<@out_list_enable; $i++) {
            $en = $out_list_enable[$i];
            print OUT "check_sec -map -spec {";
            foreach $elm (@out_list, @out_list_insert) {
                next if (@$elm[T_NAME] eq "");
                next if (@$elm[T_FLG] & FLG_CATG_EN);
                next if (@$elm[T_ENAME] ne @$en[T_NAME]);
                if (@$elm[T_ARRAY] eq "") {
                    print OUT " ${module_name}0.@$elm[T_NAME]";
                }
                else {
                    @dim = ();
                    while (@$elm[T_ARRAY] =~ /\w+/g) {
                        &get_array_info(\@dim, $&);
                    }
                    $max = 1;
                    foreach $i (@dim) {
                        $max *= $i;
                    }
                    @mod = ();
                    $val = $max;
                    foreach $i (@dim) {
                        $val /= $i;
                        push(@mod, $val);
                    }
                    for ($i=0; $i<$max; $i++) {
                        print OUT " ${module_name}0.@$elm[T_NAME]";
                        for ($j = 0; $j < @mod; $j++) {
                            print OUT "_", int($i / $mod[$j]) % $dim[$j];
                        }
                    }
                }
            }
            print OUT " }";
            if (@$en[T_NAME] ne "") {
                print OUT " -spec_condition { ${module_name}0.@$en[T_NAME]==";
                print OUT (@$en[T_FLG] & FLG_ACTV_LOW) ? "0" : "1";
                print OUT " }";
            }
            print OUT " -global\n";
        }
        print OUT "\n";
        print OUT "for {set x 0} {\$x < 2} {incr x} {\n";
        print OUT $tab, "set n 1\n";
        print OUT $tab, "foreach b \$cov_list {\n";
        print OUT $tab x2, "if {[string match \"*precondition*\" \$b]==0} {\n";
        print OUT $tab x3, "if {[string match \"*toggle*\" \$b]==1} {\n";
        print OUT $tab x4, "if {\$x == 1} {\n";
        print OUT $tab x5, "puts \"\$b\"\n";
        print OUT $tab x5, "set sig_list [get_fanin \$b]\n";
        print OUT $tab x5, "task -create spv_\${n}\n";
        print OUT $tab x5, "set sec_cmd \"check_sec -map -spec \$sig_list -spec_condition {!\$b} -stopat imp -task spv_\${n}\"\n";
        print OUT $tab x5, "puts \"\$sec_cmd\"\n";
        print OUT $tab x5, "eval \$sec_cmd\n";
        print OUT $tab x5, "check_sec -generate_verification -task spv_\${n}\n";
        print OUT $tab x5, "check_sec -prove -task spv_\${n} -prove_opts {-dump_vcd -effort user -engines {EC H L B N K I AM Tri}} -cex_threshold 1\n";
        print OUT $tab x4, "}\n";
        print OUT $tab x3, "} else {\n";
        print OUT $tab x4, "if {\$x == 0} {\n";
        print OUT $tab x5, "puts \"\$b\"\n";
        print OUT $tab x5, "exec ${scrdir}get_fanout.pl \$b $rtldir$module_name.v > fanout.tcl\n";
        print OUT $tab x5, "source fanout.tcl\n";
        print OUT $tab x5, "task -create spv_\${n}\n";
        print OUT $tab x5, "if {\$nonblock == 1} {\n";
        print OUT $tab x6, "set sec_cmd \"check_sec -map -spec \$sig_list -spec_condition {!\\\$past(\$b)} -stopat imp -task spv_\${n}\"\n";
        print OUT $tab x5, "} else {\n";
        print OUT $tab x6, "set sec_cmd \"check_sec -map -spec \$sig_list -spec_condition {!\$b} -stopat imp -task spv_\${n}\"\n";
        print OUT $tab x5, "}\n";
        print OUT $tab x5, "puts \"\$sec_cmd\"\n";
        print OUT $tab x5, "eval \$sec_cmd\n";
        print OUT $tab x5, "check_sec -generate_verification -task spv_\${n}\n";
        print OUT $tab x5, "check_assumptions -show -all\n";
        print OUT $tab x5, "check_sec -prove -task spv_\${n} -prove_opts {-dump_vcd -effort user -engines {EC H L B N K I AM Tri}} -cex_threshold 1\n";
        print OUT $tab x4, "}\n";
        print OUT $tab x3, "}\n";
        print OUT $tab x3, "incr n\n";
        print OUT $tab x2, "}\n";
        print OUT $tab, "}\n";
        print OUT "}\n";
        print OUT "\n";
        print OUT "report\n";
        print OUT "\n";
        print OUT "set prv_list \"\"\n";
        print OUT "set n 1\n";
        print OUT "foreach b \$cov_list {\n";
        print OUT $tab, "if { [string match \"*precondition*\" \$b]==0 } {\n";
        my $k=0;
        foreach $elm (@out_list, @out_list_insert) {
            next if (@$elm[T_NAME] eq "");
            next if (@$elm[T_FLG] & FLG_CATG_EN);
            if (@$elm[T_ARRAY] eq "") {
                print OUT $tab x(2+$k), "set spv_status [get_property_info";
                print OUT " -list status spv_\${n}::${module_name}0.@$elm[T_NAME]";
                print OUT "\\[" . (@$elm[T_WID]-1) .":0" . "\\]" if (@$elm[T_WID] ne "b");
                print OUT " ]\n";
                print OUT $tab x(2+$k), "puts \"spv_\$n \$spv_status\"\n";
                print OUT $tab x(2+$k), "if {[string match \"proven\" \$spv_status]==1} {\n";
                $k++;
            }
            else {
                @dim = ();
                while (@$elm[T_ARRAY] =~ /\w+/g) {
                    &get_array_info(\@dim, $&);
                }
                $max = 1;
                foreach $i (@dim) {
                    $max *= $i;
                }
                @mod = ();
                $val = $max;
                foreach $i (@dim) {
                    $val /= $i;
                    push(@mod, $val);
                }
                for ($i=0; $i<$max; $i++) {
                    print OUT $tab x(2+$k), "set spv_status [get_property_info";
                    print OUT " -list status spv_\${n}::${module_name}0.@$elm[T_NAME]";
                    for ($j = 0; $j < @mod; $j++) {
                        print OUT "_", int($i / $mod[$j]) % $dim[$j];
                    }
                    print OUT "\\[" . (@$elm[T_WID]-1) .":0" . "\\]" if (@$elm[T_WID] ne "b");
                    print OUT " ]\n";
                    print OUT $tab x(2+$k), "puts \"spv_\$n \$spv_status\"\n";
                    print OUT $tab x(2+$k), "if {[string match \"proven\" \$spv_status]==1} {\n";
                    $k++;
                }
            }
        }
        print OUT $tab x(2+$k), "append prv_list \" \$b\"\n";
        while ($k > 0) {
            print OUT $tab x(1+$k), "}\n";
            $k--;
        }
        print OUT $tab x2, "incr n\n";
        print OUT $tab, "}\n";
        print OUT "}\n";
        print OUT "\n";
        print OUT "elaborate";
        print OUT " -load_cpi worklib.${module_name}:v";
        print OUT " -cdslib ./INCA_libs/irun.nc/cds.lib";
        print OUT " -hdlvar ./INCA_libs/irun.nc/hdl.var";
        print OUT " -disable_auto_bbox\n";
        print OUT "check_unr -setup -coverage all\n";
        print OUT "\n";

        if (@rst_list > 0) {
            print OUT "clock ${module_name}0.@$clk_data[T_NAME]\n";
            &print_jg_reset(1, 0, 1);
            print OUT "\n";
        }

        print OUT "check_sec -generate_verification\n";
        print OUT "autoprove -property \"\$prv_list\"\n";
        print OUT "\n";
        print OUT "database -init_unicov -work_dir cov_work -scope scope -test unreachable_gen -overwrite -app unr\n";
        print OUT "database -export_unicov\n";
        print OUT "\n";
        print OUT "report\n";
        print OUT "\n";
    }
    else {
        print OUT "set n 1\n";
        print OUT "set cov_list [check_unr -list -type reachable]\n";
        print OUT "foreach a \$cov_list {\n";
        print OUT $tab x1, "if {[string match \"*precondition*\" \$a]==0} {\n";
        print OUT $tab x2, "set b [cover -show \$a]\n";
        print OUT "\n";
        print OUT $tab x2, "if {[string match \"*toggle*\" \$a]==1} {\n";
        print OUT $tab x3, "set sig_list [get_fanin \$b]\n";
        print OUT $tab x2, "} else {\n";
        print OUT $tab x3, "exec ${scrdir}get_fanout.pl \$b $rtldir$module_name.v > fanout.tcl\n";
        print OUT $tab x3, "source fanout.tcl\n";
        print OUT $tab x2, "}\n";
        print OUT "\n";
        for (my $i=0; $i<@out_list_enable; $i++) {
            $en = $out_list_enable[$i];
            print OUT $tab x2, "set spv_cmd_$i \"check_spv -create -name spv_\${n}_$i";
            print OUT " -from \${sig_list} -from_precond {\$b==1} -to {";
            foreach $elm (@out_list, @out_list_insert) {
                next if (@$elm[T_NAME] eq "");
                next if (@$elm[T_FLG] & FLG_CATG_EN);
                next if (@$elm[T_ENAME] ne @$en[T_NAME]);
                if (@$elm[T_ARRAY] eq "") {
                    print OUT " ${module_name}0.@$elm[T_NAME]";
                }
                else {
                    @dim = ();
                    while (@$elm[T_ARRAY] =~ /\w+/g) {
                        &get_array_info(\@dim, $&);
                    }
                    $max = 1;
                    foreach $i (@dim) {
                        $max *= $i;
                    }
                    @mod = ();
                    $val = $max;
                    foreach $i (@dim) {
                        $val /= $i;
                        push(@mod, $val);
                    }
                    for ($i=0; $i<$max; $i++) {
                        print OUT " ${module_name}0.@$elm[T_NAME]";
                        for ($j = 0; $j < @mod; $j++) {
                            print OUT "_", int($i / $mod[$j]) % $dim[$j];
                        }
                    }
                }
            }
            print OUT " }";
            if (@$en[T_NAME] ne "") {
                print OUT " -to_precond { ${module_name}0.@$en[T_NAME]==";
                print OUT (@$en[T_FLG] & FLG_ACTV_LOW) ? "0" : "1";
                print OUT " }";
            }
            print OUT "\"\n";
            print OUT $tab x2, "puts \"\$spv_cmd_$i\"\n";
            print OUT $tab x2, "eval \$spv_cmd_$i\n";
            print OUT $tab x2, "set spv_list_$i [list spv_\${n}_$i spv_\${n}_$i:from_precondition";
            print OUT " spv_\${n}_$i:to_precondition" if (@$en[T_NAME] ne "");
            print OUT "]\n";
            print OUT $tab x2, "set prv_cmd_$i \"autoprove -property \\\"\$spv_list_$i\\\" -effort user -engines {M N B K L Ht Hp Tri C I}\"\n";
            print OUT $tab x2, "eval \$prv_cmd_$i\n";
            print OUT "\n";
        }
        print OUT $tab x2, "incr n\n";
        print OUT $tab x1, "}\n";
        print OUT "}\n";
        print OUT "\n";
        print OUT "#autoprove -all -effort user -engines {M N B K L Ht Hp Tri C I}\n";
        print OUT "\n";
        print OUT "set n 1\n";
        print OUT "set cov_list [check_unr -list -type reachable]\n";
        print OUT "foreach a \$cov_list {\n";
        print OUT $tab x1, "if {[string match \"*precondition*\" \$a]==0} {\n";
        print OUT $tab x2, "set b [cover -show \$a]\n";
        print OUT $tab x2, "if {[string match \"*toggle*\" \$a]==1} {\n";
        print OUT $tab x3, "set sig_list [get_fanin \$b]\n";
        print OUT $tab x2, "} else {\n";
        print OUT $tab x3, "exec ${scrdir}get_fanout.pl \$b $rtldir$module_name.v > fanout.tcl\n";
        print OUT $tab x3, "source fanout.tcl\n";
        print OUT $tab x2, "}\n";
        print OUT "\n";
        for (my $i=0; $i<@out_list_enable; $i++) {
            $en = $out_list_enable[$i];
            print OUT $tab x2, "set spv_status_$i [get_property_info -list status spv_\${n}_$i]\n";
            print OUT $tab x2, "if {[string match \"cex\" \$spv_status_$i]==1} {\n";
            print OUT $tab x3, "puts \"Visualize spv_\${n}_$i\"\n";
            print OUT $tab x3, "set cex_cmd_$i \"check_spv -create -name spv_\${n}_${i}_cex";
            print OUT " -from \${sig_list} -from_precond {\$b==1} -to {";
            foreach $elm (@out_list, @out_list_insert) {
                next if (@$elm[T_NAME] eq "");
                next if (@$elm[T_FLG] & FLG_CATG_EN);
                next if (@$elm[T_ENAME] ne @$en[T_NAME]);
                if (@$elm[T_ARRAY] eq "") {
                    print OUT " ${module_name}0.@$elm[T_NAME]";
                }
                else {
                    @dim = ();
                    while (@$elm[T_ARRAY] =~ /\w+/g) {
                        &get_array_info(\@dim, $&);
                    }
                    $max = 1;
                    foreach $i (@dim) {
                        $max *= $i;
                    }
                    @mod = ();
                    $val = $max;
                    foreach $i (@dim) {
                        $val /= $i;
                        push(@mod, $val);
                    }
                    for ($i=0; $i<$max; $i++) {
                        print OUT " ${module_name}0.@$elm[T_NAME]";
                        for ($j = 0; $j < @mod; $j++) {
                            print OUT "_", int($i / $mod[$j]) % $dim[$j];
                        }
                    }
                }
            }
            print OUT " }";
            if (@$en[T_NAME] ne "") {
                print OUT " -to_precond { ${module_name}0.@$en[T_NAME]==";
                print OUT (@$en[T_FLG] & FLG_ACTV_LOW) ? "0" : "1";
                print OUT " }";
            }
            print OUT "\"\n";
            print OUT $tab x3, "puts \"\$cex_cmd_$i\"\n";
            print OUT $tab x3, "eval \$cex_cmd_$i\n";
            print OUT $tab x3, "set vis_status_$i [visualize -violation -property spv_\${n}_${i}_cex -batch -engine {M N B K L Ht Hp Tri C I}]\n";
            print OUT $tab x3, "if {[string match \"cex\" \$vis_status_$i]==1} {\n";
            print OUT $tab x4, "visualize -save -vcd trace/spv_\${n}_${i}_cex.vcd\n";
            print OUT $tab x3, "} else {\n";
            print OUT $tab x4, "puts \"Not Found cex\"\n";
            print OUT $tab x3, "}\n";
            print OUT $tab x2, "}\n";
            print OUT "\n";
        }
        print OUT $tab x2, "incr n\n";
        print OUT $tab x1, "}\n";
        print OUT "}\n";
        print OUT "\n";
        print OUT "database -export_unicov\n";
        print OUT "\n";
        print OUT "### New Task for unreachable ###\n";
        print OUT "task -create unrechable_gen -set -source_task unr -copy_all\n";
        print OUT "\n";
        print OUT "### assume command ###\n";
        print OUT "set n 1\n";
        print OUT "set cov_list [check_unr -list -type reachable -task unr]\n";
        print OUT "set pr_list \"\"\n";
        print OUT "foreach a \$cov_list {\n";
        print OUT $tab x1, "if {[string match \"*precondition*\" \$a]==0} {\n";
        for (my $i=0; $i<@out_list_enable; $i++) {
            $en = $out_list_enable[$i];
            print OUT $tab x2, "set spv_status_$i [get_property_info -list status unr::spv_\${n}_$i]\n";
            print OUT $tab x2, "puts \"spv_\${n}_$i \$spv_status_$i\"\n";
            print OUT $tab x2, "if {[string match \"proven\" \$spv_status_$i]==1} {\n";
            print OUT $tab x3, "set b [cover -show \$a]\n";
            print OUT $tab x3, "append pr_list \" \$b\"\n";
            print OUT $tab x2, "}\n";
            print OUT "\n";
        }
        print OUT $tab x2, "incr n\n";
        print OUT $tab x1, "}\n";
        print OUT "}\n";
        print OUT "\n";
        if (@rst_list > 0) {
            print OUT "clock ${module_name}0.@$clk_data[T_NAME]\n";
            &print_jg_reset(1, 0, 1);
        }
        print OUT "\n";
        print OUT "### prove command ###\n";
        print OUT "autoprove -property \"\$pr_list\"\n";
        print OUT "\n";
        print OUT "database -init_unicov -work_dir cov_work -scope scope -test unreachable_gen -overwrite -app unr\n";
        print OUT "database -export_unicov\n";
        print OUT "\n";
        print OUT "report\n";
    }
    print OUT "exit\n";
    print OUT "\n";
    close(OUT);
}

##
## print JG constrains
##
sub print_jg_constrains {
    #$constrain_num = 0;
    foreach $elm (@in_list, @in_list_insert) {
        next if (@$elm[T_NAME] eq "" || @$elm[T_ENAME] eq "");
        if ((@$elm[T_FLG] & FLG_CATG_EN) || (@$elm[T_FLG] & FLG_CATG_STALL)) {
            foreach $en (@in_list, @in_list_insert) {
                if (@$en[T_NAME] eq @$elm[T_ENAME]) {
                    print OUT "assume -env -name C$constrain_num { ";
                    print OUT "${module_name}0.@$en[T_NAME]==";
                    print OUT (@$en[T_FLG] & FLG_ACTV_LOW) ? "0" : "1";
                    print OUT " |-> ${module_name}0.@$elm[T_NAME]==";
                    print OUT (@$elm[T_FLG] & FLG_DISABLE) ? ((@$elm[T_FLG] & FLG_ACTV_LOW) ? "1" : "0")
                                                           : ((@$elm[T_FLG] & FLG_ACTV_LOW) ? "0" : "1");
                    print OUT " }\n";
                    $constrain_num++;
                    last;
                }
            }
        }
    }
    foreach $elm (@in_list, @in_list_insert) {
        next if (@$elm[T_NAME] eq "" || @$elm[T_ENAME] eq "");
        if (@$elm[T_FLG] & FLG_CATG_REG) {
            foreach $en (@in_list, @in_list_insert) {
                if (@$en[T_NAME] eq @$elm[T_ENAME]) {
                    $max = 1;
                    @dim = ();
                    if (@$elm[T_ARRAY] ne "") {
                        while (@$elm[T_ARRAY] =~ /\w+/g) {
                            &get_array_info(\@dim, $&);
                        }
                        foreach my $i (@dim) {
                            $max *= $i;
                        }
                        @mod = ();
                        $val = $max;
                        foreach my $i (@dim) {
                            $val /= $i;
                            push(@mod, $val);
                        }
                        for (my $i = 0; $i < $max; $i++) {
                            $name = @$elm[T_NAME];
                            for (my $j = 0; $j < @mod; $j++) {
                                $name = $name . "_" . int($i / $mod[$j]) % $dim[$j];
                            }
                            print OUT "assume -env -name C$constrain_num { ";
                            print OUT "${module_name}0.@$en[T_NAME]==";
                            print OUT (@$en[T_FLG] & FLG_ACTV_LOW) ? "0" : "1";
                            print OUT " |-> ";
                            print OUT (@$elm[T_FLG] & FLG_DISABLE) ? "${module_name}0.$name==0"
                                : "\$stable(${module_name}0.$name)";
                            print OUT " }\n";
                            $constrain_num++;
                        }
                    }
                    else {
                        print OUT "assume -env -name C$constrain_num { ";
                        print OUT "${module_name}0.@$en[T_NAME]==";
                        print OUT (@$en[T_FLG] & FLG_ACTV_LOW) ? "0" : "1";
                        print OUT " |-> ";
                        print OUT (@$elm[T_FLG] & FLG_DISABLE) ? "${module_name}0.$name==0"
                            : "\$stable(${module_name}0.$name)";
                        print OUT " }\n";
                        $constrain_num++;
                    }
                    last;
                }
            }
        }
    }
    print OUT "\n";
}

##
## print reset setting in JG
##   $reg_flag : setting non_resettable_regs attribute to 0 (1: yes, 0: no)
##   $con_flag : print constrain for reset (1: yes, 0: no)
##   $inv_flag : invert reset (1: yes, 0: no)
##
sub print_jg_reset {
    my ($reg_flag, $con_flag, $inv_flag) = @_;
    if (@rst_list > 0) {
        foreach $elm (@rst_list) {
            next if (@$elm[T_NAME] eq "" || @$elm[T_TYPE] eq "soft_reset");
            print OUT "reset ";
            print OUT ($inv_flag == 1) ? (@$elm[T_INIT] eq "pos") ? "-expression ~" : ""
                                       : (@$elm[T_INIT] eq "neg") ? "-expression ~" : "";
            print OUT "${module_name}0.@$elm[T_NAME]";
            print OUT " -non_resettable_regs 0" if ($reg_flag == 1);
            print OUT "\n";
        }
        if ($con_flag == 1) {
            print OUT "\n";
            foreach $elm (@in_list, @in_list_insert) {
                next if (@$elm[T_NAME] eq "" || @$elm[T_ENAME] ne "");
                if ((@$elm[T_FLG] & FLG_CATG_EN) || (@$elm[T_FLG] & FLG_CATG_STALL)) {
                    foreach $rst (@rst_list) {
                        if (@$rst[T_NAME] ne "" && @$rst[T_TYPE] ne "soft_reset") {
                            print OUT "assume -env -name C$constrain_num { ";
                            print OUT (@$rst[T_INIT] eq "pos") ? "\$fell" : "\$rose";
                            print OUT "(${module_name}0.@$rst[T_NAME]) |-> ${module_name}0.@$elm[T_NAME]==";
                            print OUT (@$elm[T_FLG] & FLG_ACTV_LOW) ? "1" : "0";
                            print OUT " }\n";
                            $constrain_num++;
                            last;
                        }
                    }
                }
            }
        }
    }
    else {
        print OUT "reset -none\n";
        print OUT "\n";
    }
}

##
## print one line of map file
##   OUT       : file pointer
##   $mode : sim type (0:VCS, 1:IES, 2:sim_eq)
##   $name : name  of data
##   $sign : sign  of data
##   $wid  : width of data
##
sub print_map_line {
    local(*OUT) = $_[0];
    my $mode = $_[1];
    my $name = $_[2];
    my $sign = $_[3];
    my $wid  = ($_[4] ne "b") ? &get_macro_value($_[4], "", 0) : $_[4];
    $name =~ s/://g;

    print OUT "-sctype \"" if ($mode != 0);
    print OUT $name;
    if ($mode == 0) {
        print OUT "  ";
        print OUT $wid eq "b" ? "1" : $wid;
        print OUT "  ";
        if ($wid eq "b") {
            print OUT "bit";
        }
        else {
            print OUT ($sign == 0) ? "bitvector" : "signed";
        }
        print OUT "  ", &get_sctype($sign, $wid, 1);
    }
    else {
        print OUT ":", &get_sctype($sign, $wid), "\"";
    }
    print OUT "\n";
}

##
## generate map file for VCS-CoSim & IES-CoSim
##   $mode : sim type (0:VCS, 1:IES, 2: sim_eq)
##
sub gen_map_file {
    my $mode = $_[0];
    if ($top_mode == 0 && $use_template == 1) {
        $module_name = @{$tmpl_inst_list[0]}[MOD_NAME];
    }
    my $subd = ($mode == 0) ? "vcs" :
               ($mode == 1) ? "ies" : "sim_eq/${module_name}";
    $outfile = ($mode == 2) ? "${module_name}_sim_eq.map"
                            : "${module_name}_${subd}.map";
    &my_open(*OUT, "##", $subd, 0);

    foreach $elm (@clk_list) {
        if (@$elm[T_NAME] ne "") {
            print OUT "-sctype \"" if ($mode != 0);
            print OUT @$elm[T_NAME];
            if ($mode == 0) {
                print OUT "  1  bit  sc_clock";
            }
            else {
                print OUT ":bool\"";
            }
            print OUT "\n";
        }
    }

    # reset
    foreach $elm (@rst_list) {
        if (@$elm[T_TYPE] ne "soft_reset" && @$elm[T_NAME] ne "") {
            &print_map_line(*OUT, $mode, @$elm[T_NAME], 0, "b");
        }
    }

    # in & out
    my @inout_list = ();
    if ($top_mode == 0) {
        @inout_list = (@in_list, @out_list);
    }
    else {
        @inout_list = (@in_list, @out_list, @in_list_insert, @out_list_insert);
    }
    foreach $elm (@inout_list) {
        next if (@$elm[T_NAME] eq "");
        if (@$elm[T_FLG] & FLG_STR_TYPE) {
            my @rtl_port;
            &get_rtl_port(\@rtl_port, $elm);
            foreach my $e (@rtl_port) {
                $name = @$e[T_NAME];
                $name =~ s/://g;
                &print_map_line(*OUT, $mode, $name, $sign, @$e[T_WID]);
            }
        } else {
            $sign  = (@$elm[T_TYPE] =~ /^s/) ? 1 : 0;
            $max = 1;
            if (@$elm[T_ARRAY] ne "") {
                @dim = ();
                while (@$elm[T_ARRAY] =~ /\w+/g) {
                    &get_array_info(\@dim, $&);
                }
                foreach $i (@dim) {
                    $max *= $i;
                }
                @mod = ();
                $val = $max;
                foreach $i (@dim) {
                    $val /= $i;
                    push(@mod, $val);
                }
            }
            for ($i = 0; $i < $max; $i++) {
                $name = @$elm[T_NAME];
                if (@$elm[T_ARRAY] ne "") {
                    for ($j = 0; $j < @mod; $j++) {
                        $name = $name . "_" . int($i / $mod[$j]) % $dim[$j];
                    }
                }
                &print_map_line(*OUT, $mode, $name, $sign, @$elm[T_WID]);
            }
        }
    }

    # memory
    @mem_used = ();
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        my $skip = 0;
        if (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W) {
            foreach $used (@mem_used) {
                if ($used eq @$elm[M_NAME]) {
                    $skip = 1;
                    last;
                }
            }
            push(@mem_used, @$elm[M_NAME]);
        }
        if ($skip == 0) {
            $size = &log2(&get_macro_value(@$elm[M_SIZE], "", 0));
            if ((@$elm[M_RW] == MA_RW1) || ((@$elm[M_RW] & MA_1PORT) && @$elm[M_SHARE] > 0)) {
                $port_nm = &get_mem_portnm(\@$elm, MP1_AD);
                &print_map_line(*OUT, $mode, $port_nm, 0, $size);
                $port_nm = &get_mem_portnm(\@$elm, MP1_WD);
                &print_map_line(*OUT, $mode, $port_nm, @$elm[M_SIGN], @$elm[M_WID]);
                $port_nm = &get_mem_portnm(\@$elm, MP1_RD);
                &print_map_line(*OUT, $mode, $port_nm, @$elm[M_SIGN], @$elm[M_WID]);
                $port_nm = &get_mem_portnm(\@$elm, MP1_WE);
                &print_map_line(*OUT, $mode, $port_nm, 0, "b");
                if (@$elm[M_CS] > 0) {
                    $port_nm = &get_mem_portnm(\@$elm, MP1_CS);
                    &print_map_line(*OUT, $mode, $port_nm, 0, "b");
                }
            }
            elsif (@$elm[M_RW] == MA_RW1_W) {
                $port_nm = &get_mem_portnm(\@$elm, MP1_WA);
                &print_map_line(*OUT, $mode, $port_nm, 0, $size);
                $port_nm = &get_mem_portnm(\@$elm, MP1_WD);
                &print_map_line(*OUT, $mode, $port_nm, @$elm[M_SIGN], @$elm[M_WID]);
                $port_nm = &get_mem_portnm(\@$elm, MP1_WE);
                &print_map_line(*OUT, $mode, $port_nm, 0, "b");
            }
            elsif (@$elm[M_RW] == MA_RW1_R) {
                $port_nm = &get_mem_portnm(\@$elm, MP1_RA);
                &print_map_line(*OUT, $mode, $port_nm, 0, $size);
                $port_nm = &get_mem_portnm(\@$elm, MP1_RD);
                &print_map_line(*OUT, $mode, $port_nm, @$elm[M_SIGN], @$elm[M_WID]);
                if (@$elm[M_RE] > 0) {
                    $port_nm = &get_mem_portnm(\@$elm, MP1_RE);
                    &print_map_line(*OUT, $mode, $port_nm, 0, "b");
                }
            }
            elsif (@$elm[M_RW] == MA_R1W1_W) {
                $port_nm = &get_mem_portnm(\@$elm, MP2_WA);
                &print_map_line(*OUT, $mode, $port_nm, 0, $size);
                $port_nm = &get_mem_portnm(\@$elm, MP2_WD);
                &print_map_line(*OUT, $mode, $port_nm, @$elm[M_SIGN], @$elm[M_WID]);
                $port_nm = &get_mem_portnm(\@$elm, MP2_WE);
                &print_map_line(*OUT, $mode, $port_nm, 0, "b");
                if (@$elm[M_CS] > 0) {
                    $port_nm = &get_mem_portnm(\@$elm, MP2_CS);
                    &print_map_line(*OUT, $mode, $port_nm, 0, "b");
                }
            }
            elsif (@$elm[M_RW] == MA_R1W1_R) {
                $port_nm = &get_mem_portnm(\@$elm, MP2_RA);
                &print_map_line(*OUT, $mode, $port_nm, 0, $size);
                $port_nm = &get_mem_portnm(\@$elm, MP2_RD);
                &print_map_line(*OUT, $mode, $port_nm, @$elm[M_SIGN], @$elm[M_WID]);
                if (@$elm[M_RE] > 0) {
                    $port_nm = &get_mem_portnm(\@$elm, MP2_RE);
                    &print_map_line(*OUT, $mode, $port_nm, 0, "b");
                }
            }
            elsif (@$elm[M_RW] & MA_DPORT) {
                $port_nm = &get_mem_portnm(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_AD : MPB_AD);
                &print_map_line(*OUT, $mode, $port_nm, 0, $size);
                $port_nm = &get_mem_portnm(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_WD : MPB_WD);
                &print_map_line(*OUT, $mode, $port_nm, @$elm[M_SIGN], @$elm[M_WID]);
                $port_nm = &get_mem_portnm(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_RD : MPB_RD);
                &print_map_line(*OUT, $mode, $port_nm, @$elm[M_SIGN], @$elm[M_WID]);;
                $port_nm = &get_mem_portnm(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_WE : MPB_WE);
                &print_map_line(*OUT, $mode, $port_nm, 0, "b");
                if (@$elm[M_CS] > 0) {
                    $port_nm = &get_mem_portnm(\@$elm, @$elm[M_RW] == MA_RW2_A ? MPA_CS : MPB_CS);
                    &print_map_line(*OUT, $mode, $port_nm, 0, "b");
                }
            }
        }
    }
    $module_name = $org_module_name;
}

##
## generate vip files for VCS/IES
##
sub gen_vip_file {
    my $mode = $_[0];
    my $subd = ($mode == 0) ? "vcs" : "ies";

    if ($use_aigen == 1) {
        my $awid = "";
        my $dwid = "";
        my $swid = "";
        foreach $port (@in_list) {
            if (@$port[T_NAME] eq "PADDR") {
                $awid = @$port[T_WID];
            }
            if (@$port[T_NAME] eq "PWDATA") {
                $dwid = @$port[T_WID];
            }
            if (@$port[T_NAME] eq "PSTRB") {
                $swid = @$port[T_WID];
            }
        }

        $outfile = "${module_name}_${subd}_apb_monitor.v";
        &my_open(*OUT, "//", $subd, 0);

        print OUT "module ${module_name}_${subd}_apb_monitor (\n";
        print OUT $tab, "  PCLK\n";
        print OUT $tab, ", PRESETn\n";
        print OUT $tab, ", PADDR\n";
        print OUT $tab, ", PSEL\n";
        print OUT $tab, ", PENABLE\n";
        print OUT $tab, ", PWRITE\n";
        print OUT $tab, ", PSTRB\n" if ($mode == 1);
        print OUT $tab, ", PWDATA\n" if ($mode == 1);
        print OUT $tab, ", PREADY\n";
        print OUT $tab, ", PRDATA\n";
        print OUT ");\n";
        print OUT $tab, "input PCLK;\n";
        print OUT $tab, "input PRESETn;\n";
        print OUT $tab, "input [" . eval($awid-1) . ":0] PADDR;\n";
        print OUT $tab, "input PSEL;\n";
        print OUT $tab, "input PENABLE;\n";
        print OUT $tab, "input PWRITE;\n";
        print OUT $tab, "input [" . eval($swid-1) . ":0] PSTRB;\n" if ($mode == 1);
        print OUT $tab, "input [" . eval($dwid-1) . ":0] PWDATA;\n" if ($mode == 1);
        print OUT $tab, "input PREADY;\n";
        print OUT $tab, "input [" . eval($dwid-1) . ":0] PRDATA;\n";
        print OUT "\n";

        print OUT $tab, ($mode == 0) ? "SnpsApbSlaveUnit" : "apb4_monitor", " #(\n";
        if ($mode == 0) {
            print OUT $tab x2, ".ADDRSIZE($awid),\n";
            print OUT $tab x2, ".RDATASIZE($dwid),\n";
            print OUT $tab x2, ".COVER_EN(1),\n";
            print OUT $tab x2, ".PSLVERR_CH_EN(0),\n";
            print OUT $tab x2, ".PSLVERR_SUPPORTED(0)\n";
        }
        else {
            print OUT $tab x2, ".ABUS_WIDTH($awid),\n";
            print OUT $tab x2, ".DBUS_WIDTH($dwid),\n";
            print OUT $tab x2, ".PROT_WIDTH(2),\n";
            print OUT $tab x2, ".COVERAGE_ON(1),\n";
            print OUT $tab x2, ".RST_CHECKS_ON(1),\n";
            print OUT $tab x2, ".XCHECKS_ON(1),\n";
            print OUT $tab x2, ".RECM_CHECKS_ON(1)\n";
        }
        print OUT $tab, ") apb_monitor_i (\n";
        print OUT $tab x2, ".addr_lo(" . $awid . "\'d0),\n" if ($mode == 0);
        print OUT $tab x2, ".addr_hi(" . $awid . "\'d" . eval((1<<$awid)-1) . "),\n" if ($mode == 0);
        print OUT $tab x2, ".pclk(PCLK),\n";
        print OUT $tab x2, ".presetn(PRESETn),\n";
        print OUT $tab x2, ".pselx(PSEL),\n" if ($mode == 0);
        print OUT $tab x2, ".psel(PSEL),\n" if ($mode == 1);
        print OUT $tab x2, ".penable(PENABLE),\n";
        print OUT $tab x2, ".pwrite(PWRITE),\n";
        print OUT $tab x2, ".paddr(PADDR),\n";
        print OUT $tab x2, ".pwdata(PWDATA),\n" if ($mode == 1);
        print OUT $tab x2, ".pstrb(PSTRB),\n" if ($mode == 1);
        print OUT $tab x2, ".pprot(3'd0),\n" if ($mode == 1);
        print OUT $tab x2, ".pready(PREADY),\n";
        print OUT $tab x2, ".prdata(PRDATA),\n";
        print OUT $tab x2, ".pslverr(1'd0)\n";
        print OUT $tab, ");\n";
        print OUT "endmodule\n";
        close(OUT);

        $outfile = "${module_name}_${subd}_apb_monitor.map";
        &my_open(*OUT, "##", $subd, 0);
        if ($mode == 0) {
            print OUT "PCLK  1  bit  sc_clock\n";
        }
        else {
            print OUT "-sctype \"PCLK:bool\"\n";
        }
        &print_map_line(*OUT, $mode, "PRESETn", 0, "b");
        &print_map_line(*OUT, $mode, "PADDR", 0, $awid);
        &print_map_line(*OUT, $mode, "PSEL", 0, "b");
        &print_map_line(*OUT, $mode, "PENABLE", 0, "b");
        &print_map_line(*OUT, $mode, "PWRITE", 0, "b");
        &print_map_line(*OUT, $mode, "PSTRB", 0, $swid) if ($mode == 1);
        &print_map_line(*OUT, $mode, "PWDATA", 0, $dwid) if ($mode == 1);
        &print_map_line(*OUT, $mode, "PREADY", 0, "b");
        &print_map_line(*OUT, $mode, "PRDATA", 0, $dwid);
        close(OUT);
    }
}

##
## generate script file for 1team:System
##
sub gen_1team_scr {
    $outfile = "run_1team.csh";
    my $subdir = $opt_subd ? $opt_ins ? "../src_ins/" : "../src/" : "";
    my $srcfile = $opt_ins ? "_ins.cpp" : ".cpp";
    &my_open(*OUT, "#!", "1team", 1, "755");
    print OUT "source $env_stratus\n\n" if ($opt_stratus);
    print OUT "set SRC = \"$subdir*$srcfile\"\n";
    if($opt_ins) {
        print OUT "set SKIP_INS = 0\n";
        print OUT "while (\$#argv > 0)\n";
        print OUT $tab, "switch (\$1)\n";
        print OUT $tab, "case -skip_ins:\n";
        print OUT $tab x2, "set SKIP_INS = 1\n";
        my $srcdir = "";
        $srcdir = "../src/" if($opt_subd);
        print OUT $tab x2, "set SRC = \"$srcdir*.cpp\"\n";
        print OUT $tab x2, "shift\n";
        print OUT $tab x2, "breaksw\n";
        print OUT $tab, "default:\n";
        print OUT $tab x2, "shift\n";
        print OUT $tab x2, "breaksw\n";
        print OUT $tab, "endsw\n";
        print OUT "end\n";
        print OUT "if ( \$SKIP_INS == 0 ) then\n";
        print OUT $tab, "${subdir}run_cpp2ins.csh\n";
        print OUT $tab, "if ( \$? == 1 ) then\n";
        print OUT $tab x2, "echo \"FAIL ${subdir}run_cpp2ins.csh\"\n";
        print OUT $tab x2, "echo \"Please execute 1team with -skip_ins first\"\n";
        print OUT $tab x2, "exit 1\n";
        print OUT $tab, "endif\n";
        print OUT "endif\n\n";
    }
    print OUT "source $env_1team\n";
    print OUT "bs -M 500 -os RHEL5 spyglass -template=Renesas/Synth \\\n";
    print OUT "   -I$env_ssgen \\\n" if (!$opt_standard);
    print OUT "   -I\${STRATUS_HOME}/share/stratus/include \\\n" if ($opt_stratus);
    print OUT "   -I../src/ \\\n" if ($opt_subd && $opt_ins);
    print OUT "   -D$mem_macro \\\n" if (!$opt_standard);
    print OUT "   -sgdc ./user_waive.sgdc \\\n" if (!$opt_standard);
    print OUT "   \${SRC}\n";
    print OUT "\n";
    print OUT "\${SPYGLASS_HOME}/../scripts/chk_known_bug.pl ./moresimple.rpt\n";
    close(OUT);

    $outfile = "user_waive.sgdc";
    &my_open(*OUT, "##", "1team", 0);
    print OUT "\n";
    print OUT "## please write your waiver rule\n";
    print OUT "## sample:\n";
    print OUT "##   /common/appl/Atrenta/1teamsystem/1.16.7/SPYGLASS_HOME/waiver/hls_design_waiver.sgdc\n";
    print OUT "## template:\n";
    print OUT "##   waive-case -regexp -file \".*\" -rule RuleName [-msg \"Message\"]\n";
    close(OUT);
}

##
## generate script file for SSChecker
##
sub gen_sschecker_scr {
    #$outfile = "run_sschecker_$module_name.sh";
    #my $subdir = $opt_subd ? "../src/" : "";
    #&my_open(*OUT, "#!", "sschecker", 0, "755");
    #print OUT "set SSCHECKER = $env_sschk/SSChecker.pl\n";
    #print OUT "\$SSCHECKER ${subdir}$module_name.cpp -rpt $module_name.rpt\n";
    #close(OUT);
    #if ($top_mode == 1 && @mod_list_sync > 0) {
    #    foreach $mod (@mod_list_sync) {
    #        next if (@$mod[MOD_DBG] ne "");
    #        $outfile = "run_sschecker_@$mod[MOD_NAME].sh";
    #        &my_open(*OUT, "#!", "sschecker", 0, "755");
    #        print OUT "set SSCHECKER = $env_sschk/SSChecker.pl\n";
    #        print OUT "\$SSCHECKER ${subdir}@$mod[MOD_NAME].cpp -rpt @$mod[MOD_NAME].rpt\n";
    #        close(OUT);
    #    }
    #}

    $outfile = "run_sschecker.csh";
    my $subdir = $opt_subd ? $opt_ins ? "../src_ins/" : "../src/" : "./";
    my $srcfile = $opt_ins ? "_ins.cpp" : ".cpp";
    &my_open(*OUT, "#!", "sschecker", 1, "755");
    print OUT "set SRCDIR  = \"$subdir\"\n";
    print OUT "set SRCFILE = \"$srcfile\"\n";
    if($opt_ins) {
        print OUT "set SKIP_INS = 0\n";
        print OUT "while (\$#argv > 0)\n";
        print OUT $tab, "switch (\$1)\n";
        print OUT $tab, "case -skip_ins:\n";
        print OUT $tab x2, "set SKIP_INS = 1\n";
        print OUT $tab x2, "set SRCDIR  = \"../src/\"\n" if($opt_subd);
        print OUT $tab x2, "set SRCFILE = \".cpp\"\n";
        print OUT $tab x2, "shift\n";
        print OUT $tab x2, "breaksw\n";
        print OUT $tab, "default:\n";
        print OUT $tab x2, "shift\n";
        print OUT $tab x2, "breaksw\n";
        print OUT $tab, "endsw\n";
        print OUT "end\n";
        print OUT "if ( \$SKIP_INS == 0 ) then\n";
        print OUT $tab, "${subdir}run_cpp2ins.csh\n";
        print OUT $tab, "if ( \$? == 1 ) then\n";
        print OUT $tab x2, "echo \"FAIL ${subdir}run_cpp2ins.csh\"\n";
        print OUT $tab x2, "echo \"Please execute SSChecker with -skip_ins first\"\n";
        print OUT $tab x2, "exit 1\n";
        print OUT $tab, "endif\n";
        print OUT "endif\n\n";
    }
    print OUT "set SSCHECKER = $env_sschk/SSChecker.pl\n";
    print OUT "\n";
    print OUT "rm All.rpt\n";
    print OUT "\n";
    #print OUT "set SRC = (\$argv)\n";
    #print OUT "if(\$#SRC == 0) then\n";
    #print OUT $tab, "set SRC = `find \${SRCDIR} -name \"*\${SRCFILE}\"`\n";
    #print OUT "endif\n";
    print OUT "set SRC = `find \${SRCDIR} -name \"*\${SRCFILE}\"`\n";
    print OUT "\n";
    print OUT "foreach a (\$SRC)\n";
    print OUT $tab, "if( ! -e \$a ) then\n";
    print OUT $tab x2, "echo \"ERROR: Cannot find \$a !\"\n";
    print OUT $tab x2, "continue\n";
    print OUT $tab, "endif\n\n";
    #print OUT $tab, "set module = `echo \$a | sed -e \"s/.*\\(\\/\\)//g\" -e \"s/\${SRCFILE}//\" -e \"s/\\.h//\"`\n";
    print OUT $tab, "set module = `basename \$a \$SRCFILE`\n";
    print OUT $tab, "\$SSCHECKER \$a -rpt \${module}.rpt";
    print OUT " -I../src" if ($opt_subd);
    print OUT " -stratus" if ($opt_stratus);
    print OUT "\n";
    print OUT $tab, "cat \${module}.rpt >> All.rpt\n";
    print OUT $tab, "echo >> All.rpt\n";
    print OUT "end\n";
    close(OUT);
}

##
## generate script file for overflow check
##
sub gen_overflow {
    $outfile = "overflow_" . $module_name . ".tcl";
    my $subdir = $opt_subd ? $opt_ins ? "../src_ins/" : "../src/" : "";
    my $srcfile = $opt_ins ? "_ins.cpp" : ".cpp";
    &my_open(*OUT, "##", "overflow", 0);

    print OUT "# parameters\n";
    print OUT "set PERIOD $ctos_period\n";

    if ($top_mode == 0) {
        print OUT "set INPUT_DELAY 0\n";
        print OUT "set TARGET_LIB $ctos_target_lib\n";
    }
    print OUT "\n";

    print OUT "# set variables\n";
    print OUT "set NAME $module_name\n";
    print OUT "set MODULE /designs/\$NAME/modules/\$NAME\n";
    print OUT "set ARRAY \$MODULE/arrays\n";

    if ($top_mode == 0) {
        print OUT "set BEHAVIOR \$MODULE/behaviors\n";
        print OUT "set PORT \$MODULE/terms\n";
    }

    print OUT "\n";
    print OUT "# preparation\n";
    print OUT "new_design \$NAME\n";
    if ($top_mode == 0 && $use_aigen == 1) {
        print OUT "set_attr source_files ";
        print OUT "\"$subdir$module_name.cpp $subdir$mod_aigen\_apb_func$srcfile\"";
        print OUT " [get_design]\n";
    }
    else {
        print OUT "set_attr source_files \"$subdir$module_name$srcfile\" [get_design]\n";
    }
    print OUT "set_attr compile_flags \" -w";
    print OUT " -D$mem_macro -I$env_ssgen" if (!$opt_standard);
    print OUT " -I../src/" if($opt_subd && $opt_ins);
    print OUT " -D_CTOS_TOP" if ($top_mode == 1);
    print OUT "\" [get_design]\n";
    print OUT "set_attr top_module_path \$NAME [get_design]\n";
    print OUT "set_attr auto_write_models false [get_design]\n";
    if ($top_mode == 0) {
        if (@thread_list != 0 && $use_valid_thread == 1) {
            print OUT "set_attr low_power_clock_gating true [get_design]\n";
            print OUT "set_attr reset_registers internal [get_design]\n";
        }
        print OUT "set_attr tech_lib_names \$TARGET_LIB [get_design]\n";
        print OUT "set_attr verilog_pragma_keyword \"synopsys\" [get_design]\n";
    }

    if (@thread_list != 0 && $top_mode == 0 && $use_valid_thread == 1) {
        foreach $elm (@clk_list) {
            if (@$elm[T_NAME] ne "") {
                print OUT "define_clock -name @$elm[T_NAME] -period \$PERIOD\n";
            }
        }
    }

    print OUT "build\n";
    print OUT "\n";

    print OUT "# overflow check\n";
    print OUT "source $env_ovrflw/check_overflow.tcl\n";
    print OUT "check_overflow\n";
    print OUT "file delete -force ./model\n";
    print OUT "exit\n";
    close(OUT);

    $outfile = "run_overflow.csh";
    &my_open(*OUT, "#!", "overflow", 1, "755");
    #print OUT "${subdir}run_cpp2ins.csh\n" if($opt_ins);
    print OUT "source $env_ies\n";
    print OUT "source $env_ctos\n";
    print OUT "bs -M 500 -os RHEL5 -tool ctos overflow_lsfsh \${*}\n";
    close(OUT);

    $outfile = "overflow_lsfsh";
    &my_open(*OUT, "#!", "overflow", 1, "755");
    #print OUT "set OVR_TCL = (\$argv)\n";
    print OUT "set OVR_TCL = ()\n";
    print OUT "set SKIP_INS = 0\n";
    print OUT "while (\$#argv > 0)\n";
    print OUT $tab, "switch (\$1)\n";
    print OUT $tab, "case -skip_ins:\n";
    print OUT $tab x2, "set SKIP_INS = 1\n";
    print OUT $tab x2, "shift\n";
    print OUT $tab x2, "breaksw\n";
    print OUT $tab, "default:\n";
    print OUT $tab x2, "set OVR_TCL = (\$OVR_TCL \$1)\n";
    print OUT $tab x2, "shift\n";
    print OUT $tab x2, "breaksw\n";
    print OUT $tab, "endsw\n";
    print OUT "end\n";
    if($opt_ins) {
        print OUT "if ( \$SKIP_INS == 0 ) then\n";
        print OUT $tab, "${subdir}run_cpp2ins.csh\n";
        print OUT $tab, "if ( \$? == 1 ) then\n";
        print OUT $tab x2, "echo \"FAIL ${subdir}run_cpp2ins.csh\"\n";
        print OUT $tab x2, "echo \"Please execute overflow check with -skip_ins first\"\n";
        print OUT $tab x2, "exit 1\n";
        print OUT $tab, "endif\n";
        print OUT "endif\n\n";
    }
    print OUT "if(\$#OVR_TCL == 0) then\n";
    print OUT $tab, "set OVR_TCL = `find . -name \"overflow_*.tcl\"`\n";
    print OUT "endif\n";
    print OUT "\n";
    print OUT "foreach a (\$OVR_TCL)\n";
    print OUT $tab, "if( ! -e \$a ) then\n";
    print OUT $tab x2, "echo \"ERROR: Cannot find \$a !\"\n";
    print OUT $tab x2, "continue\n";
    print OUT $tab, "endif\n\n";
    if($opt_ins) {
        print OUT $tab, "cp \$a \${a}.bk\n";
        print OUT $tab, "if ( \$SKIP_INS == 1 ) then\n";
        print OUT $tab x2, "perl -i -pe 's/_ins\>//g' \$a\n";
        print OUT $tab, "endif\n\n";
    }
    print OUT $tab, "set module = `echo \$a | sed -e \"s/.*\\(overflow_\\)//\" -e \"s/\\.tcl//\"`\n";
    print OUT $tab, "ctos \$a -log overflow_\${module}.log\n\n";
    print OUT $tab, "mv -f \${a}.bk \$a\n" if($opt_ins);
    print OUT "end\n\n";
    print OUT "${def_rpt_ovr} overflow_*.log > report_overflow.log\n";
    close(OUT);
}

##
## generate tcl file for overflow check of memory interface module
##
sub gen_overflow_memif {
    return if ($top_mode == 0);
    @mem_used = ();
    foreach $elm (@mem_list) {
        next if(@$elm[M_FIX] == 1);
        my $skip = 0;
        foreach $used (@mem_used) {
            if ($used eq @$elm[M_NAME]) {
                $skip = 1;
                last;
            }
        }
        push(@mem_used, @$elm[M_NAME]);
        if ($skip == 0 && @$elm[M_SHARE] > 0
          && (@$elm[M_RW] == MA_RW1_R || @$elm[M_RW] == MA_RW1_W)) {
            $ifnm = &get_mem_ifnm(\@$elm);
            $outfile = "overflow_" . $ifnm . ".tcl";
            my $subdir = $opt_subd ? $opt_ins ? "../src_ins/" : "../src/" : "";
            my $srcfile = $opt_ins ? "_ins.cpp" : ".cpp";
            &my_open(*OUT, "##", "overflow", 0);

            print OUT "# parameters\n";
            print OUT "set PERIOD $ctos_period\n";
            print OUT "set TARGET_LIB $ctos_target_lib\n";
            print OUT "\n";

            print OUT "# set variables\n";
            print OUT "set NAME $ifnm\n";
            print OUT "set MODULE /designs/\$NAME/modules/\$NAME\n";
            print OUT "set ARRAY \$MODULE/arrays\n";
            print OUT "\n";

            print OUT "# preparation\n";
            print OUT "new_design \$NAME\n";
            print OUT "set_attr source_files \"$subdir$ifnm$srcfile\" [get_design]\n";
            print OUT "set_attr compile_flags \" -w -I$env_ssgen";
            print OUT " -I../src/" if($opt_subd && $opt_ins);
            print OUT "\" [get_design]\n";
            print OUT "set_attr top_module_path \$NAME [get_design]\n";
            print OUT "set_attr auto_write_models false [get_design]\n";
            print OUT "set_attr low_power_clock_gating true [get_design]\n";
            print OUT "set_attr tech_lib_names \$TARGET_LIB [get_design]\n";
            print OUT "set_attr reset_registers internal [get_design]\n";
            print OUT "set_attr verilog_pragma_keyword \"synopsys\" [get_design]\n";
            print OUT "build\n";
            print OUT "\n";

            print OUT "# overflow check\n";
            print OUT "source $env_ovrflw/check_overflow.tcl\n";
            print OUT "check_overflow\n";
            print OUT "file delete -force ./model\n";
            print OUT "exit\n";
            close(OUT);
        }
    }
}

##
## generate tcl file for overflow check of synchronizer module
##
sub gen_overflow_sync {
    return if ($top_mode == 0);
    foreach $mod (@mod_list_sync) {
        next if (@$mod[MOD_DBG] ne "");
        $mod_name = @$mod[MOD_NAME];
        $mod_inst = @$mod[MOD_INST];
        $outfile = "overflow_" . $mod_name . ".tcl";
        my $subdir = $opt_subd ? $opt_ins ? "../src_ins/" : "../src/" : "";
        my $srcfile = $opt_ins ? "_ins.cpp" : ".cpp";
        &my_open(*OUT, "##", "overflow", 0);

        print OUT "# parameters\n";
        print OUT "set PERIOD $ctos_period\n";
        print OUT "set INPUT_DELAY 0\n";
        print OUT "set TARGET_LIB $ctos_target_lib\n";
        print OUT "\n";
        print OUT "# set variables\n";
        print OUT "set NAME $mod_name\n";
        print OUT "set MODULE /designs/\$NAME/modules/\$NAME\n";
        print OUT "set BEHAVIOR \$MODULE/behaviors\n";
        print OUT "set PORT \$MODULE/terms\n";
        print OUT "set ARRAY \$MODULE/arrays\n";

        print OUT "\n";
        print OUT "# preparation\n";
        print OUT "new_design \$NAME\n";
        print OUT "set_attr source_files \"$subdir$mod_name$srcfile\" [get_design]\n";
        print OUT "set_attr compile_flags \" -w";
        print OUT " -D$mem_macro -I$env_ssgen" if (!$opt_standard);
        print OUT " -I../src/" if($opt_subd && $opt_ins);
        print OUT "\" [get_design]\n";
        print OUT "set_attr top_module_path \$NAME [get_design]\n";
        print OUT "set_attr auto_write_models false [get_design]\n";
        print OUT "set_attr low_power_clock_gating true [get_design]\n";
        print OUT "set_attr reset_registers internal [get_design]\n";
        print OUT "set_attr tech_lib_names \$TARGET_LIB [get_design]\n";
        print OUT "set_attr verilog_pragma_keyword \"synopsys\" [get_design]\n";
        print OUT "\n";

        foreach $elm (@clk_list_sync) {
            if (@$elm[T_NAME] ne "" && @$elm[T_INST] eq $mod_inst) {
                print OUT "define_clock -name @$elm[T_NAME] -period \$PERIOD\n";
            }
        }

        print OUT "build\n";
        print OUT "\n";

        print OUT "# overflow check\n";
        print OUT "source $env_ovrflw/check_overflow.tcl\n";
        print OUT "check_overflow\n";
        print OUT "file delete -force ./model\n";
        print OUT "exit\n";
        close(OUT);
    }
}

##
## generate script file for cpp2ins
##
sub gen_cpp2ins_scr {

    $outfile = "run_cpp2ins.csh";
    my $subdir = $opt_subd ? "../src/" : "";
    &my_open(*OUT, "#!", "src_ins", 1, "755");
    print OUT "cd `dirname \$0`\n";
    print OUT "\n";
    print OUT "setenv PATH \"$env_cpp2ins:\${PATH}\"\n";
    print OUT "\n";
    print OUT "rm -f dummy.log mcpp.log\n";
    print OUT "rm -f ${subdir}*_mcpp.cpp\n";
    print OUT "\n";
    print OUT "set SRC = (\$argv)\n";
    print OUT "if(\$#SRC == 0) then\n";
    print OUT $tab, "set SRC = `find $subdir -name \"*.cpp\"`\n";
    print OUT "endif\n";
    print OUT "\n";
    print OUT "foreach a (\$SRC)\n";
    print OUT $tab, "if( ! -e \$a ) then\n";
    print OUT $tab x2, "echo \"ERROR: Cannot find \$a !\"\n";
    print OUT $tab x2, "continue\n";
    print OUT $tab, "endif\n\n";
    #print OUT $tab, "set module = `echo \$a | sed -e \"s/.*\\(\\/\\)//g\" -e \"s/\\.cpp//\" -e \"s/\\.h//\"`\n";
    print OUT $tab, "set module = `basename \$a .cpp`\n";
    print OUT $tab, "cpp2ins.pl -src \$a \\\n";
    print OUT $tab x2, "-m -b -c \\\n";
    print OUT $tab x2, "-cflags \"-I$subdir -I$env_ssgen\" \\\n";
    print OUT $tab x2, "-stratus \\\n" if ($opt_stratus);
    print OUT $tab x2, "-outdir .\n";
    print OUT "\n";
    print OUT $tab, "if ( \$? == 1 ) then\n";
    print OUT $tab x2, "exit 1\n";
    print OUT $tab, "endif\n";
    print OUT "\n";
    print OUT $tab, "touch -r \$a \${module}_ins.cpp\n";
    print OUT "end\n";
    close(OUT);
}

##
## get the value of the macro
##   return : the value of the macro
##   $macro_name: name of macro
##   $file      : current file
##   $line_num  : current line number
##   $flag      : flag to use non-exist macro
##   @parent_list: list of parents of the macro
##
sub get_macro_value {
    my ($macro_name, $file, $line_num, $flag, @parent_list) = @_;
    my $error_return = "";

    if ($macro_name eq "") {
        return $macro_name;
    }
    if (&is_struct($macro_name)) {
        return $macro_name;
    }
    if (&is_template_parameter($macro_name, \$tmp)) {
        return $macro_name;
    }
    if (&use_float($macro_name)) {
        message("E211", $file, $line_num, "Floating point should not be used in macro definition");
    }
    if (&is_number($macro_name)) {
        $macro_name =~ s/u?l*$//i;
        return $macro_name;
    }

    # check the existence of the macro
    my $exist = 0;
    my $macro_substance = "";
    my $define_list = ($top_mode != 0) ? \@define_in_top_list : \@define_in_list;
    foreach $elm (@$define_list) {
        if(@$elm[G_NAME] eq $macro_name) {
            @$elm[G_FLAG] |= FLG_USED;
            $macro_substance = @$elm[G_VALUE];
            $exist = 1;
        }
    }
    if ($exist == 0) {
        # check the existence of struct
        #return $macro_name if (&is_struct($macro_name) == 1);
        if ($flag == 1) {
            return 0;
        }
        message("E209", $file, $line_num, "\"$macro_name\" is not defined");
        return $error_return;
    }
    if (&is_number($macro_substance)) {
        $macro_substance =~ s/u?l*$//i;
        return $macro_substance;
    }

    # check the recursive of the macro
    $exist = 0;
    foreach $elm (@parent_list) {
        if($elm eq $macro_name) {
            $exist = 1;
        }
    }
    if ($exist == 1 || $macro_substance =~ /^\s*$/) {
        message("E210", $file, $line_num, "It is impossible to calculate constant value in macroname \"$macro_name\"");
        return $error_return;
    }

    # get the value of each inside macro if exist
    push(@parent_list, $macro_name);
    my @macro_list = split(/[\+\-\*\/\(\)]|\<\<|\>\>|log2\(/, $macro_substance);
    my $macro_value;
    foreach $elm (@macro_list) {
        if ($elm !~ /^\s*$/) {
            $macro_value = &get_macro_value($elm, $file, $line_num, 0, @parent_list);
            if ($macro_value ne "") {
                $macro_substance =~ s/\b$elm\b/$macro_value/g;
            }
            else {
                return $error_return;
            }
        }
    }
    $macro_value = int(eval(&add_int_to_division($macro_substance)));
    if ($@) {
        message("E210", $file, $line_num, "It is impossible to calculate constant value in macroname \"$macro_name\"");
        return $error_return;
    }

    return $macro_value;
}

##
## get the min/max value of datatype
##   $elm    : type element
##   $min(O) : min value
##   $max(O) : max value
##
sub get_minmax_value {
    my ($elm, $min, $max) = @_;
    my $sign = &is_signed($elm);
    my $type = @$elm[T_TYPE];
    my $wid  = @$elm[T_WID];
    $wid = 1 if ($wid eq "b");

    $wid = &get_macro_value($wid, "", 0);
    if ($type eq "uchar" || $type eq "char") {
        $wid = 8;
    }
    elsif ($type eq "ushort" || $type eq "short") {
        $wid = 16;
    }
    elsif ($type eq "uint" || $type eq "int") {
        $wid = 32;
    }

    if (@$elm[T_WID] eq "b") {
        $type = "bool";
    }
    elsif ($type =~ /(uchar|ushort|uint)/) {
        $type = "unsigned " . substr($type, 1);
    }
    elsif ($type =~ /(in|out|reg|var|ev)$/) {
        $type = &get_sctype($sign, $wid);
    }

    $t_wid = $wid > 32 ? $wid - 32 : $wid;
    if ($sign == 1) {
        $t_min = (0xffffffff << ($t_wid - 1)) & 0xffffffff;
        $t_max = (1 << ($t_wid - 1)) - 1;
    }
    else {
        $t_min = 0;
        $t_max = $t_wid == 32 ? 0xffffffff : (1 << $t_wid) - 1;
    }

    $$min = "(" . $type . ")";
    $$max = "(" . $type . ")";
    if ($wid > 32) {
        $$min = $$min . sprintf("0x%08x00000000LL", $t_min);
        $$max = $$max . sprintf("0x%08xffffffffLL", $t_max);
    }
    else {
        $$min = $$min . sprintf("0x%08x", $t_min);
        $$max = $$max . sprintf("0x%08x", $t_max);
    }
}

##
## get array infor for non-number elements
##
sub get_array_info {
    my $dim = $_[0];
    my $i = $_[1];
    if (&is_number($i) == 0) {
        if (&is_template_parameter($i, \$tmp)) {
            if ($top_mode == 0) {
                $tmpl_list = @{$tmpl_inst_list[0]}[MOD_TMPL];
                foreach $elm (@$tmpl_list) {
                    if ($i eq @$elm[0]) {
                        $i = @$elm[1];
                        last;
                    }
                }
            }
            else {
                $i = @$tmp[G_VALUE];
            }
        }
        else {
            $i = &get_macro_value($i, "", 0);
        }
    }
    push(@$dim, $i);
}

##
## add dummy clock for test-bench of SC_METHOD only module
##
sub add_dummy_clk {
    $comment = "dummy clock";
    $name = "ssgen_clk";
    @elm = ($comment, $name, "", "clock", "", "", "b", $name, "", "", "", "", $top_dbg, "", "", "", "SC_NS", 10);
    push(@clk_list, [@elm]);
}

##
## add casting to int to division for macro calculation.
## Ex: 14/18 => int(14/18) or (12+1) / 13 => int((12+1) / 13)
##  return: modified expression
##   $exp : input expression
##
sub add_int_to_division {
    my $exp = $_[0];
    #my $rtn = $exp;

    while ($exp =~ /\//) {
        my @char = split (//,$exp);
        my $prev = substr($exp, 0, index($exp, "\/"));
        my $post = substr($exp, index($exp, "\/") + 1);

        if ($prev =~ /\)\s*$/) {
            my $prev_start = 0;
            my $prev_end   = 0;
            my $prev_para  = 0;
            for (my $i = index($exp, "\/"); $i >= 0; $i--) {
                if ($char[$i] =~ /\)/ && $prev_para == 0) {
                    $prev_end = $i;
                }
                $prev_para-- if ($char[$i] =~ /\(/);
                $prev_para++ if ($char[$i] =~ /\)/);
                if ($char[$i] =~ /\(/ && $prev_para == 0) {
                    $prev_start = $i;
                    last;
                }
            }
            $prev = substr($exp, $prev_start, $prev_end - $prev_start + 1);
        }
        else {
            $prev =~ s/(.*\W)?(\w+\s*)$/$2/;
        }

        if ($post =~ /^\s*\(/) {
            my $post_start = 0;
            my $post_end   = 0;
            my $post_para  = 0;
            for (my $i = index($exp, "\/"); $i < length($exp); $i++) {
                if ($char[$i] =~ /\(/ && $post_para == 0) {
                    $post_start = $i;
                }
                $post_para++ if ($char[$i] =~ /\(/);
                $post_para-- if ($char[$i] =~ /\)/);
                if ($char[$i] =~ /\)/ && $post_para == 0) {
                    $post_end = $i;
                    last;
                }
            }
            $post = substr($exp, $post_start, $post_end - $post_start + 1);
        }
        else {
            $post =~ s/^(\s*\w+)(\W.*)?/$1/;
        }
        $exp =~ s/((\s*int\s*)?\Q$prev\E\s*)\/\s*(\Q$post\E)/int($1\\$3)/;
    }
    $exp =~ s/\\/\//g;
    return $exp;
}

##
## print each constructor for struct or reset function to initialize value
##  return: print output code to OUT_H
##   $struct_name : struct name
##   $struct_mem_list : reference to struct member list
##   $func_name   : function name (reset or constructor)
##   $arg_num     : number of function argument
##                  -1: argument is 'struct'
##                   0: no argument (reset function or default constructor)
##                   1: one argument is integer
##                   2: number arguments of arguments are corresponding to all members of struct
##
sub print_struct_init_elm {
    my $struct_name = $_[0];
    my $struct_mem_list = $_[1];
    my $func_name = $_[2];
    my $arg_num = $_[3];
    my $arg_list = "";
    my $ret_type = "";
    if ($arg_num == -1) {
        $arg_list = "const $struct_name& v";
    }
    elsif ($arg_num == 1) {
        $arg_list = "int v";
    } 
    elsif ($arg_num > 1) {
        my $var_id = 0;
        foreach $var (@$struct_mem_list) {
            my $var_name = @$var[T_NAME];
            my $var_array = @$var[T_ARRAY];
            my $type = &get_type(@$var[T_TYPE], @$var[T_WID]);
            if ($var_array ne "") {
                my $match = () = $var_array =~ /\[\w+\]/g; # Get dimension of arrray
                $arg_list = $arg_list."$type ".'*'x($match)." arg$var_id,\n$tab$tab$tab";
            } else {
                $arg_list = $arg_list."$type arg$var_id, \n$tab$tab$tab";
            }
            $var_id = $var_id + 1;
        }
        $arg_list =~ s/,\s*$//;
    }

    if ($func_name ne $struct_name) {
        $ret_type = "void ";
    }

    print OUT_H "$tab$ret_type$func_name($arg_list) {\n";
    &print_init_data(*OUT_H, "$tab", $func_name, $struct_mem_list, $arg_num);
    print OUT_H "$tab}\n";
}

##
## print constructor for struct or reset function
##  return: print constructor or reset code to OUT_H
##   $struct_name : struct name
##   $struct_mem_list : reference to struct member list
##
##
sub print_struct_constructor {
    my $struct_name = $_[0];
    my $struct_mem_list = $_[1];

    # print constructor
    print OUT_H "\n$tab//constructor\n";
    &print_struct_init_elm($struct_name, $struct_mem_list, $struct_name, 0);

    # print copy constructor (arg is struct)
    print OUT_H "\n$tab//copy constructor (arg is struct)\n";
    &print_struct_init_elm($struct_name, $struct_mem_list, $struct_name, -1);

    # print copy constructor (arg is integer)
    print OUT_H "\n$tab//copy constructor (arg is integer)\n";
    &print_struct_init_elm($struct_name, $struct_mem_list, $struct_name, 1);

    # print copy constructor (arg is member list)
    print OUT_H "\n$tab//copy constructor (arg is member list)\n";
    &print_struct_init_elm($struct_name, $struct_mem_list, $struct_name, 2);

    # print reset function
    print OUT_H "\n$tab//reset\n";
    &print_struct_init_elm($struct_name, $struct_mem_list, "reset", 0);
}

##
## print each operator assignment code for struct
##  return: print constructor or reset code to OUT_H
##   $op       : operator
##   $ptr_list : pointer of list
##   $arg_num  : argument ID for operator prototype
##              -1 - argument is 'struct' datatype
##               0 - argument is number
##               1 - argument is 'int' datatype
##               2 - arguments are corresponding to each 'struct' member data
##
sub print_struct_one_op_elm {
    my $op       = $_[0];
    my $ptr_list = $_[1];
    my $arg_num  = $_[2];
    my $var_ret  = $_[3];
    my $arg_id   = 0;
    my $out_str  = "";

    $indent = "$tab$tab";
    if ($op eq "!=") {
        print OUT_H  "${tab}${tab}return !(*this == v);\n";
        return;
    }
    
    if ($var_ret ne "") {
        if ($var_ret eq "bool") {
            print OUT_H "${indent}$var_ret ret = true;\n" 
        } else {
            print OUT_H "${indent}$var_ret ret;\n" 
        }
    }
    foreach $elm (@$ptr_list) {
        next if (@$elm[T_INST] ne $mod_inst &&
                ((@$elm[T_FLG] & FLG_SYNC) || (@$elm[T_FLG] & FLG_SYNC_CHK)));
        if (@$elm[T_NAME] eq "" || (@$elm[T_FLG] & FLG_CONST) || lc @$elm[T_INIT] eq "n") {
            next;
        }
        $sig   = @$elm[T_TYPE] =~ /(in|out|reg)$/ ? 1 : 0;
        $ev    = @$elm[T_TYPE] =~ /ev$/ ? 1 : 0;
        $name  = @$elm[T_NAME];
        $array = @$elm[T_ARRAY];
        $init  = @$elm[T_INIT];
        $left_var  = @$elm[T_INIT];
        if ($arg_num == 1) {   # one init value for all struct members
            $left_var = "v";
        } elsif ($arg_num > 1) {    # init values corresponding to struct members
            $left_var = "arg$arg_id";
            $arg_id = $arg_id + 1;
        } elsif ($arg_num == -1) {  # init value get from existed struct data
            $left_var = "v.$name";
        }
        my @dim = ();
        my @num = ();

        if ($array eq "") {
            if ($op =~ /^(\+|-|\*|\^|&|\||>>|<<|&&|\|\|)$/) {   # arithmetic operators
                $out_str = $out_str."${tab}${tab}ret.$name = $name $op $left_var;\n";
            } elsif ($op eq "++") {
                $out_str = $out_str."${tab}${tab}$name = $name + 1;\n";
            } elsif ($op eq "--") {
                $out_str = $out_str."${tab}${tab}$name = $name - 1;\n";
            } elsif ($op =~ /^(>|<|>=|<=|==)$/) {   # logical opertors
                $out_str = $out_str."${tab}${tab}ret = ret && ($name $op $left_var);\n";
            } elsif ($op eq "!" || $op eq "~") { # unary operators
                $out_str = $out_str."${tab}${tab}$name = $op$name;\n";
            } elsif ($op eq "=") {
                $out_str = $out_str."${tab}${tab}$name $op $left_var;\n";
            }
#            if (@$elm[T_FLG] & FLG_VAR2REG) {
#                $out_str = $out_str.$indent, "r_$name.write($init);\n";
#            }
        }
        else {
            my $str_tmp = "";   # array index to init value get from existed struct data
            while ($init =~ /[^\s\{\}\,]+/g) {
                push(@num, $&);
            }

            if (@num == 1) {
                while ($array =~ /\w+/g) {
                    push(@dim, $&);
                }
                for ($i = 0; $i < @dim; $i++) {
                    $out_str = $out_str.$indent. $tab x$i. "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
                    $str_tmp = "$str_tmp\[i$i\]";
                }
                my $left_var_elm = "$num[0]";
                if ($arg_num == -1 || $arg_num > 1 ) {
                    $left_var_elm = "$left_var$str_tmp";
                } elsif ($arg_num == 1) {
                    $left_var_elm = "v";
                }
                if ($op =~ /^(\+|-|\*|\^|&|\||>>|<<|&&|\|\|)$/) {   # arithmetic operators
                    $out_str = $out_str.$indent.$tab x$i."ret.$name$str_tmp = $name $op $left_var_elm;\n";
                } elsif ($op eq "++") {
                    $out_str = $out_str.$indent.$tab x$i."$name$str_tmp = $name + 1;\n";
                } elsif ($op eq "--") {
                    $out_str = $out_str.$indent.$tab x$i."$name$str_tmp = $name - 1;\n";
                } elsif ($op =~ /^(>|<|>=|<=|==)$/) {   # logical opertors
                    $out_str = $out_str.$indent.$tab x$i."ret = ret && ($name$str_tmp $op $left_var_elm);\n";
                } elsif ($op eq "!" || $op eq "~") { # unary operators
                    $out_str = $out_str.$indent.$tab x$i."$name$str_tmp = $op$name;\n";
                } elsif ($op eq "=") {
                    $out_str = $out_str.$indent.$tab x$i."$name$str_tmp $op $left_var_elm;\n";
                }
                for ($i = @dim - 1; $i >= 0; $i--) {
                    $out_str = $out_str.$indent. $tab x$i. "}\n";
                }
            }
            elsif (@num > 1) {
                while ($array =~ /\w+/g) {
                    &get_array_info(\@dim, $&);
                }
                $max = 1;
                foreach $i (@dim) {
                    $out_str = $out_str.$indent. $tab x$i. "for (int i$i = 0; i$i < $dim[$i]; i$i++) {\n";
                    $max *= $i;
                }
                @mod = ();
                $val = $max;
                foreach $i (@dim) {
                    $val /= $i;
                    push(@mod, $val);
                }
                for ($i = 0; $i < $max; $i++) {
                    for ($j = 0; $j < @mod; $j++) {
                        $str_tmp = "$str_tmp\[", int($i / $mod[$j]) % $dim[$j], "\]";
                    }
                    $pos = ($i < @num) ? $i : $#num;
                    my $left_var_elm = "$num[$pos]";
                    if ($arg_num == -1 || $arg_num > 1 ) {
                        $left_var_elm = "$left_var$str_tmp";
                    } elsif ($arg_num == 1) {
                        $left_var_elm = "v";
                    }
                    if ($op =~ /^(\+|-|\*|\^|&|\||>>|<<|&&|\|\|)$/) {   # arithmetic operators
                        $out_str = $out_str.$indent.$tab x$#dim."$name$str_tmp = $name $op $left_var_elm;\n";
                    } elsif ($op eq "++") {
                        $out_str = $out_str.$indent.$tab x$#dim."$name$str_tmp = $name + 1;\n";
                    } elsif ($op eq "--") {
                        $out_str = $out_str.$indent.$tab x$#dim."$name$str_tmp = $name - 1;\n";
                    } elsif ($op =~ /^(>|<|>=|<=|==)$/) {   # logical opertors
                        $out_str = $out_str.$indent.$tab x$#dim."${tab}($name$str_tmp $op $left_var_elm) && \n";
                    } elsif ($op eq "!" || $op eq "~") { # unary operators
                        $out_str = $out_str.$indent.$tab x$#dim."$name$str_tmp = $op$name;\n";
                    } elsif ($op eq "=") {
                        $out_str = $out_str.$indent.$tab x$#dim."$name$str_tmp $op $left_var_elm;\n";
                    }
                }
                for ($i = @dim - 1; $i >= 0; $i--) {
                    $out_str = $out_str.$indent. $tab x$i. "}\n";
                }
            }
        }
    }
    if ($var_ret ne "") {
        print OUT_H $out_str;
        print OUT_H "${indent}return ret;\n";
    } 
    else {
        $out_str = $out_str."${tab}${tab}return *this;\n";
        print OUT_H $out_str;
    }
}

##
## print operators for struct
##   $struct_name    : name of struct
##   $var_list : members of struct
##
sub print_struct_one_op {
    my $struct_name = $_[0];
    my $op = $_[1];
    my $struct_mem_list = $_[2];
    my $str = "";
    my $ret_type = "$struct_name&";
    my $const = "const ";
    my $arg_str = "const $struct_name& v";

    if ($op =~ /^(>|<|>=|<=|==|!=)$/) {
        $ret_type = "bool";
    } 
    if ($op =~ /^(\+\+|--|!|~)$/) {
        $arg_str  = "void";
    }
    $const = "" if ($op =~ /^(\+|-|~|!|\*|\^|&|\||>>|<<|&&|\|\||=|\+\+|--)$/);  # arithmetic operators

    my $use_tmp_var = "";
    if ($op =~ /^(>|<|>=|<=|==|!=)$/) {
        $use_tmp_var = "bool";
    }
    elsif ($op =~ /^(\+|-|\*|\^|&|\||>>|<<|&&|\|\|)$/) {
        $ret_type = "$struct_name";
        $use_tmp_var = "$struct_name";
    }

    # print operator with left side is 'struct' data
    print OUT_H "\n$tab// operator $op\n";
    print OUT_H $tab."inline $ret_type operator $op ($arg_str) $const\{ \n";
    &print_struct_one_op_elm($op, $struct_mem_list, -1, $use_tmp_var); # left side is struct data, not integer
    print OUT_H "$tab}\n";

    if ($op !~ /^(!|~)$/) {
        print OUT_H "\n";
        print OUT_H $tab."inline $ret_type operator $op (int v) $const\{ \n";
        &print_struct_one_op_elm($op, $struct_mem_list, 1, $use_tmp_var); # left side is integer
        print OUT_H "$tab}\n";
    }
}

##
## check if memeber exist in array
##  $pattern : find string 
##  $array   : input array
## return: 0: not found, 1 found
##
sub find_elm {
    my $pattern = $_[0];
    my @array   = @{$_[1]};

    foreach my $a (@array) {
        return 1 if ("$pattern" eq "$a");
    }
    return 0;
}

##
## print operators for struct
##   $struct_name    : name of struct
##   $var_list : members of struct
##
sub print_struct_operator {
    my $struct_name = $_[0];
    my $struct_mem_list = $_[1];
    my $op_list = $_[2];

    foreach my $op (("==", "!=", "=", @$op_list)) {
        &print_struct_one_op($struct_name, $op, $struct_mem_list);
    }

    # merge operators of struct members
    my @var_op_list = ();
    foreach $var (@$struct_mem_list) {
        my $var_name = @$var[T_NAME];
        my @var_op = split /\s*,\s*/, @$var[T_OPTOR];
        foreach my $op(@var_op) {
            if (&find_elm($op, \@var_op_list) == 0) {
                if (&find_elm($op, \@$op_list) == 0 ) {
                    push(@var_op_list, $op);
                } else {
                    message("W007", $file, $line_num, "operator \"$op\" is redefined because it is defined as struct operator");
                }
            }
        }
    }
    my @add_op  = ();
    foreach $op (@var_op_list) {
        my @var_tmp = ();
        foreach $var (@$struct_mem_list) {
            my $var_type = @$var[T_TYPE];
            my $var_name = @$var[T_NAME];
            my @var_op = split /\s*,\s*/, @$var[T_OPTOR];
            foreach $tmp (@var_op) {
                if ("$tmp" eq "$op") {
                    push(@var_tmp, $var);
                }
            }
        }
        push(@add_op,[$op, [@var_tmp]]);
        &print_struct_one_op($struct_name, $op, \@var_tmp);
    }

}

##
## print functions implementation for struct tracing
##  return: print tracing code for struct to OUT_H
##   $struct_name : struct name
##   $mem_list : reference to struct member list
##
sub print_struct_tracing {
    my $struct_name = $_[0];
    my $mem_list = $_[1];
    my $str = "";

    # print sc_trace
    print OUT_H "\n$tab// sc_trace\n";
    print OUT_H $tab."inline friend void sc_trace (sc_trace_file *tf, const $struct_name& v, const std::string& NAME) {\n";
    foreach $var (@$mem_list) {
        my $var_name = @$var[T_NAME];
        $str = $str.$tab.$tab."sc_trace (tf, v.$var_name, NAME + \"\.$var_name\");\n";
    }
    print OUT_H $str;
    print OUT_H "$tab\}\n";
    
    # print ostream
    $str = "";
    print OUT_H "\n$tab// ostream\n";
    print OUT_H $tab."inline friend std::ostream& operator << (std::ostream& os, const $struct_name& v) {\n";
    foreach $var (@$mem_list) {
        my $var_name = @$var[T_NAME];
        $str = $str.$tab.$tab."os << \"\.\" << v.$var_name\;\n";
    }
    $str = $str.$tab.$tab."return os;\n";
    print OUT_H $str;
    print OUT_H "$tab\}\n";

    # print ofstream
    $str = "";
    print OUT_H "\n$tab// ofstream\n";
    print OUT_H $tab."inline friend std::ofstream& operator << (std::ofstream& ofs, const $struct_name& v) {\n";
    foreach $var (@$mem_list) {
        my $var_name = @$var[T_NAME];
        $str = $str.$tab.$tab."ofs << \"\.\" << v.$var_name\;\n";
    }
    $str = $str.$tab.$tab."return ofs;\n";
    print OUT_H $str;
    print OUT_H "$tab\}\n";
}

##
## check struct operators 
##  return: 1 (struct), 0 (not struct)
##   $name   : bitwidth information
##
sub is_struct {
    my $name = $_[0];
    my $st_flag = 0;
    return 0 if ($name =~ /^\d/ || @struct_list == 0);
    foreach my $st (@struct_list) {
        if ($name eq @$st[STR_NAME]) {
            return 1;
        }
    }
    return 0;
}

##
## check if input string is a template parameter
##  $word : input string
##   $ptn : pointer of hit element
##
sub is_template_parameter {
    my $word = $_[0];
    my $ptn  = $_[1];
    if ($use_template == 1 && &name_exist(\@template_list, $word, $ptn)) {
        return 1;
    }
    return 0;
}

##
## check struct operators 
##   $line     : string
##   $file     : file name
##   $line_num : line number
##   $op       : operator of struct
##
sub check_struct_operator {
    my ($file, $line_num, $op) = @_;
    if ($op =~ /^[^\+\-\*\^&\|\!\~\<\>=, ]$/) {
        message("E701", $file, $line_num, "not support operator \"$op\" in struct");
    }
}

##
## generate struct header
##
sub gen_struct_h {
    foreach my $struct_header (@struct_list) {
        my @struct          = @$struct_header;
        my $struct_name     = $struct[STR_NAME];
        my $STRUCT_NAME     = uc $struct_name;
        my $op_list         = $struct[STR_OPTOR];
        my $struct_mem_list = $struct[STR_VAR];
        my @change_log      = @{$struct[STR_CH_LOG]};
        my @free_area_st    = @{$struct[STR_FREE_AREA]};
        my @prepro_list_st  = @{$struct[STR_MACRO]};
        $outfile            = $struct_name.".h";
        &my_open(*OUT_H, "//", "src", 0);
        print OUT_H "#ifndef ${STRUCT_NAME}_H\n";
        print OUT_H "#define ${STRUCT_NAME}_H\n";

        # change log
        print OUT_H "\n" if (@change_log > 0);
        foreach $elm (@change_log) {
            print OUT_H "// $elm\n";
        }

        # #include & #define
        print OUT_H "\n" if (@prepro_list_st > 0);
        &print_preprocessor(*OUT_H);
        &print_kept_ssgen_define(*OUT_H, $infile, 0);
        if (@prepro_list_st > 0) {
            foreach $elm (@prepro_list_st) {
                if (@$elm[G_FLAG] eq "#include") {
                    print OUT_H "#include @$elm[G_NAME]";
                }
                else {
                    print OUT_H "#define @$elm[G_NAME]";
                }
                print OUT_H " // @$elm[G_COM]" if (@$elm[G_COM] ne "");
                print OUT_H "\n";
            }
        }
#        if (@def_file_list != 0) {
#            foreach $def_file (@def_file_list) {
#                my $def_h = $def_file;
#                $def_h =~ s/\.in/.h/;
#                $def_h =~ s/^.*\///;
#                print OUT_H "#include \"$def_h\"\n";
#            }
#        }

        # print struct declaration
        print OUT_H &comment($struct[STR_COM]);
        print OUT_H "struct $struct_name \{\n";
        print OUT_H "public:\n";

        # reg, var, ctype
        print_decl_data_one(*OUT_H, $struct_mem_list);
        &print_struct_constructor($struct_name, $struct_mem_list);
        &print_struct_operator($struct_name, $struct_mem_list, $op_list);
        &print_struct_tracing($struct_name, $struct_mem_list);

        # free area
        if (@free_area_st > 0) {
            print OUT_H "\n";
            foreach $elm (@free_area_st) {
                print OUT_H $tab, "$elm\n";
            }
        }

        print OUT_H "};\n";
        print OUT_H "\n";
        print OUT_H "#endif\n";
        close(OUT_H);
    }
}

## 
## get struct from struct list
## return struct
## $sname: struct name
##
sub get_struct {
    my $sname = $_[0];

    foreach $st (@struct_list) {
        my $name = @$st[STR_NAME];
        return $st if ($name eq $sname);
    }
    return 0;
}


## 
## get rtl port list for test bench
## $elm: module member
## $port_list: port list to push
##
sub get_rtl_port {
    my $port_list = $_[0];
    my $elm = $_[1];
    my $sign  = (@$elm[T_TYPE] =~ /^s/) ? 1 : 0;
    my $max = 1;
    my @mod = ();
    my @dim = ();
    if (@$elm[T_ARRAY] ne "") {
        while (@$elm[T_ARRAY] =~ /\w+/g) {
            &get_array_info(\@dim, $&);
        }
        foreach $i (@dim) {
            $max *= $i;
        }
        $val = $max;
        foreach $i (@dim) {
            $val /= $i;
            push(@mod, $val);
        }
    }
    for ($i = 0; $i < $max; $i++) {
        $name = @$elm[T_NAME];
        my $id = "";
        if (@$elm[T_ARRAY] ne "") {
            for ($j = 0; $j < @mod; $j++) {
                $id = $id . "_" . int($i / $mod[$j]) % $dim[$j];
            }
        }
        my $struct = &get_struct(@$elm[T_WID]);
        my $var_list = @$struct[STR_VAR];
        foreach my $e (@$var_list) {
            my $imax = 1;
            if (@$e[T_ARRAY] ne "") {
                @idim = ();
                while (@$e[T_ARRAY] =~ /\w+/g) {
                    &get_array_info(\@idim, $&);
                }
                foreach $i (@idim) {
                    $imax *= $i;
                }
                @imod = ();
                $ival = $imax;
                foreach $i (@idim) {
                    $ival /= $i;
                    push(@imod, $ival);
                }
            }
            for ($m = 0; $m < $imax; $m++) {
                $iname = @$e[T_NAME];
                my $iid = "";
                if (@$e[T_ARRAY] ne "") {
                    for ($n = 0; $n < @imod; $n++) {
                        $iid = $iid . "_" . int($m / $imod[$n]) % $idim[$n];
                    }
                }
                my @st_var = @{$e};
                $st_var[T_NAME] = "$name:_$iname:$id:$iid";
                if (@$elm[T_TYPE] =~ /^(uin|sin|uout|sout)$/) {
                    $st_var[T_TYPE] = @$elm[T_TYPE];
                    $st_var[T_WID]  = &get_bitwidth($e);
                }
                $st_var[T_ARRAY] = "";
                push (@{$port_list}, [@st_var]);
            }
        }
    }
}

## 
## get bitwidth
## $type
## 
sub get_bitwidth {
    my $elm = $_[0];
    return "b" if (@$elm[T_TYPE] =~ /varb/);
    return "8" if (@$elm[T_TYPE] =~ /char/);
    return "16" if (@$elm[T_TYPE] =~ /short/);
    return "32" if (@$elm[T_TYPE] =~ /int/);
    return @$elm[T_WID] if (@$elm[T_TYPE] =~ /var/);
}
