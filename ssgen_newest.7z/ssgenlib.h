// ssgenlib.h (library header for ssgen)
// Created by Front-End Design Technology Development Department
// Renesas Group Confidential
//
// History
// - 2011/09/29 v1.0   FEDT(Y.Oshima & S.Imamura) New created
// - 2011/10/28 v1.0.2 changed the spec of memory port
// - 2012/03/26 v1.1   supported memory port suffix customization feature
// - 2012/05/30 v1.1.3 added "MEM_INIVAL_XXX_NOWD" and "MEM_WR_XXX_NOWD" macros
// - 2013/01/18 v1.3   added "MEM_{DEF|ININM|INIVAL|NEG|REQ|RD}_1R_XXX" macros
//                     added "MEM_{DEF|ININM|INIVAL|NEG}_1W_XXX" macros
// - 2013/02/01 v1.3.1 added "VAR2REG" macro
// - 2013/02/22 v1.3.2 added "MEM_{INIVAL|WR|REQ}_XXX_{NOAD|NOAW}" macros
// - 2013/04/17 v1.4   added "EV" class and "EV_XXX" macros
// - 2014/04/07 v1.5.2 supported sc2ac conversion
// - 2016/07/28 v1.8.5 added "MEM_{DEF|ININM|INIVAL|WR}_2W_E_B_{NOAD|NOWD|NOAW}" macros
// - 2016/06/30 v1.9   supported Stratus-HLS directives in compilers other than IES
// - 2017/03/31 v1.9.2 supported more Stratus-HLS directives
// - 2017/06/30 v1.9.3 supported more Stratus-HLS directives
// - 2017/09/29 v1.9.4 removed Stratus directives to fix compile error due to multiple definitions 

#ifndef SSGENLIB_H
#define SSGENLIB_H

#include <systemc.h>
#ifndef __CTOS__
#include <sstream>
#endif

#ifdef _USE_AC
#include <ac_complex.h>
#include <ac_sc.h>
#define SAC(WID) ac_int<WID,true>
#define UAC(WID) ac_int<WID,false>
#endif

////////////////////////////////////////////////////////////////////////////////
// Macro values
////////////////////////////////////////////////////////////////////////////////
#define T_MAX 1024
#define HIER_MAX 1000

////////////////////////////////////////////////////////////////////////////////
// Memory Access Macro
////////////////////////////////////////////////////////////////////////////////
#define CTOR_NM(nm) nm(#nm)

//////////////////////////////////////////
// (1) Memory port definition
//////////////////////////////////////////
//-- for port only access
#ifndef _USE_AC
// single port memory
#define MEM_DEF_1_P(NAME, DTYPE, AWID, LAT, IPRE, OPRE, AD1, WD1, WE1, RD1) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## AD1; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD1; \
    sc_out < bool > OPRE ## NAME ## _ ## WE1; \
    sc_in < DTYPE > IPRE ##NAME ## _ ## RD1;
#define MEM_DEF_1_E_P(NAME, DTYPE, AWID, LAT, IPRE, OPRE, AD1, WD1, WE1, RD1, CS1) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## AD1; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD1; \
    sc_out < bool > OPRE ## NAME ## _ ## WE1; \
    sc_in < DTYPE > IPRE ##NAME ## _ ## RD1; \
    sc_out < bool > OPRE ## NAME ## _ ## CS1;
// 2port memory read
#define MEM_DEF_2R_P(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## RA2; \
    sc_in < DTYPE > IPRE ## NAME ## _ ## RD2;
#define MEM_DEF_2R_E_P(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2, RE2) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## RA2; \
    sc_in < DTYPE > IPRE ## NAME ## _ ## RD2; \
    sc_out < bool > OPRE ## NAME ## _ ## RE2;
#define MEM_DEF_1R_P(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## RA2; \
    sc_in < DTYPE > IPRE ## NAME ## _ ## RD2;
#define MEM_DEF_1R_E_P(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2, RE2) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## RA2; \
    sc_in < DTYPE > IPRE ## NAME ## _ ## RD2; \
    sc_out < bool > OPRE ## NAME ## _ ## RE2;
// 2port memory write
#define MEM_DEF_2W_P(NAME, DTYPE, AWID, LAT, OPRE, WA2, WD2, WE2) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## WA2; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD2; \
    sc_out < bool > OPRE ## NAME ## _ ## WE2;
#define MEM_DEF_2W_E_P(NAME, DTYPE, AWID, LAT, OPRE, WA2, WD2, WE2, CS2) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## WA2; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD2; \
    sc_out < bool > OPRE ## NAME ## _ ## WE2; \
    sc_out < bool > OPRE ## NAME ## _ ## CS2;
#define MEM_DEF_2W_E_B_P(NAME, DTYPE, AWID, BWID, LAT, OPRE, WA2, WD2, WE2, CS2, BE2) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## WA2; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD2; \
    sc_out < bool > OPRE ## NAME ## _ ## WE2; \
    sc_out < bool > OPRE ## NAME ## _ ## CS2; \
    sc_out < sc_uint<BWID> > OPRE ## NAME ## _ ## BE2;
#define MEM_DEF_1W_P(NAME, DTYPE, AWID, LAT, OPRE, WA2, WD2, WE2) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## WA2; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD2; \
    sc_out < bool > OPRE ## NAME ## _ ## WE2;
#else // _USE_AC
// single port memory
#define MEM_DEF_1_P(NAME, DTYPE, AWID, LAT, IPRE, OPRE, AD1, WD1, WE1, RD1) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## AD1; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD1; \
    sc_out < bool > OPRE ## NAME ## _ ## WE1; \
    sc_in < DTYPE > IPRE ##NAME ## _ ## RD1;
#define MEM_DEF_1_E_P(NAME, DTYPE, AWID, LAT, IPRE, OPRE, AD1, WD1, WE1, RD1, CS1) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## AD1; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD1; \
    sc_out < bool > OPRE ## NAME ## _ ## WE1; \
    sc_in < DTYPE > IPRE ##NAME ## _ ## RD1; \
    sc_out < bool > OPRE ## NAME ## _ ## CS1;
// 2port memory read
#define MEM_DEF_2R_P(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## RA2; \
    sc_in < DTYPE > IPRE ## NAME ## _ ## RD2;
#define MEM_DEF_2R_E_P(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2, RE2) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## RA2; \
    sc_in < DTYPE > IPRE ## NAME ## _ ## RD2; \
    sc_out < bool > OPRE ## NAME ## _ ## RE2;
#define MEM_DEF_1R_P(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## RA2; \
    sc_in < DTYPE > IPRE ## NAME ## _ ## RD2;
#define MEM_DEF_1R_E_P(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2, RE2) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## RA2; \
    sc_in < DTYPE > IPRE ## NAME ## _ ## RD2; \
    sc_out < bool > OPRE ## NAME ## _ ## RE2;
// 2port memory write
#define MEM_DEF_2W_P(NAME, DTYPE, AWID, LAT, OPRE, WA2, WD2, WE2) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## WA2; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD2; \
    sc_out < bool > OPRE ## NAME ## _ ## WE2;
#define MEM_DEF_2W_E_P(NAME, DTYPE, AWID, LAT, OPRE, WA2, WD2, WE2, CS2) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## WA2; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD2; \
    sc_out < bool > OPRE ## NAME ## _ ## WE2; \
    sc_out < bool > OPRE ## NAME ## _ ## CS2;
#define MEM_DEF_2W_E_B_P(NAME, DTYPE, AWID, BWID, LAT, OPRE, WA2, WD2, WE2, CS2, BE2) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## WA2; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD2; \
    sc_out < bool > OPRE ## NAME ## _ ## WE2; \
    sc_out < bool > OPRE ## NAME ## _ ## CS2; \
    sc_out < ac_int<BWID,false> > OPRE ## NAME ## _ ## BE2;
#define MEM_DEF_1W_P(NAME, DTYPE, AWID, LAT, OPRE, WA2, WD2, WE2) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## WA2; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD2; \
    sc_out < bool > OPRE ## NAME ## _ ## WE2;
#endif // _USE_AC

//-- for switching access
#ifdef _MEM_MODEL

#ifndef _USE_AC
// single port memory
#define MEM_DEF_1(NAME, DTYPE, AWID, LAT, IPRE, OPRE, AD1, WD1, WE1, RD1) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## AD1; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD1; \
    sc_out < bool > OPRE ## NAME ## _ ## WE1; \
    sc_in < DTYPE > IPRE ##NAME ## _ ## RD1;
#define MEM_DEF_1_E(NAME, DTYPE, AWID, LAT, IPRE, OPRE, AD1, WD1, WE1, RD1, CS1) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## AD1; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD1; \
    sc_out < bool > OPRE ## NAME ## _ ## WE1; \
    sc_in < DTYPE > IPRE ##NAME ## _ ## RD1; \
    sc_out < bool > OPRE ## NAME ## _ ## CS1;
// 2port memory read
#define MEM_DEF_2R(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## RA2; \
    sc_in < DTYPE > IPRE ## NAME ## _ ## RD2;
#define MEM_DEF_2R_E(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2, RE2) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## RA2; \
    sc_in < DTYPE > IPRE ## NAME ## _ ## RD2; \
    sc_out < bool > OPRE ## NAME ## _ ## RE2;
#define MEM_DEF_1R(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## RA2; \
    sc_in < DTYPE > IPRE ## NAME ## _ ## RD2;
#define MEM_DEF_1R_E(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2, RE2) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## RA2; \
    sc_in < DTYPE > IPRE ## NAME ## _ ## RD2; \
    sc_out < bool > OPRE ## NAME ## _ ## RE2;
// 2port memory write
#define MEM_DEF_2W(NAME, DTYPE, AWID, LAT, OPRE, WA2, WD2, WE2) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## WA2; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD2; \
    sc_out < bool > OPRE ## NAME ## _ ## WE2;
#define MEM_DEF_2W_E(NAME, DTYPE, AWID, LAT, OPRE, WA2, WD2, WE2, CS2) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## WA2; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD2; \
    sc_out < bool > OPRE ## NAME ## _ ## WE2; \
    sc_out < bool > OPRE ## NAME ## _ ## CS2;
#define MEM_DEF_2W_E_B(NAME, DTYPE, AWID, BWID, LAT, OPRE, WA2, WD2, WE2, CS2, BE2) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## WA2; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD2; \
    sc_out < bool > OPRE ## NAME ## _ ## WE2; \
    sc_out < bool > OPRE ## NAME ## _ ## CS2; \
    sc_out < sc_uint<BWID> > OPRE ## NAME ## _ ## BE2;
#define MEM_DEF_1W(NAME, DTYPE, AWID, LAT, OPRE, WA2, WD2, WE2) \
    sc_out < sc_uint<AWID> > OPRE ## NAME ## _ ## WA2; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD2; \
    sc_out < bool > OPRE ## NAME ## _ ## WE2;
#else // _USE_AC
// single port memory
#define MEM_DEF_1(NAME, DTYPE, AWID, LAT, IPRE, OPRE, AD1, WD1, WE1, RD1) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## AD1; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD1; \
    sc_out < bool > OPRE ## NAME ## _ ## WE1; \
    sc_in < DTYPE > IPRE ##NAME ## _ ## RD1;
#define MEM_DEF_1_E(NAME, DTYPE, AWID, LAT, IPRE, OPRE, AD1, WD1, WE1, RD1, CS1) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## AD1; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD1; \
    sc_out < bool > OPRE ## NAME ## _ ## WE1; \
    sc_in < DTYPE > IPRE ##NAME ## _ ## RD1; \
    sc_out < bool > OPRE ## NAME ## _ ## CS1;
// 2port memory read
#define MEM_DEF_2R(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## RA2; \
    sc_in < DTYPE > IPRE ## NAME ## _ ## RD2;
#define MEM_DEF_2R_E(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2, RE2) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## RA2; \
    sc_in < DTYPE > IPRE ## NAME ## _ ## RD2; \
    sc_out < bool > OPRE ## NAME ## _ ## RE2;
#define MEM_DEF_1R(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## RA2; \
    sc_in < DTYPE > IPRE ## NAME ## _ ## RD2;
#define MEM_DEF_1R_E(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2, RE2) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## RA2; \
    sc_in < DTYPE > IPRE ## NAME ## _ ## RD2; \
    sc_out < bool > OPRE ## NAME ## _ ## RE2;
// 2port memory write
#define MEM_DEF_2W(NAME, DTYPE, AWID, LAT, OPRE, WA2, WD2, WE2) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## WA2; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD2; \
    sc_out < bool > OPRE ## NAME ## _ ## WE2;
#define MEM_DEF_2W_E(NAME, DTYPE, AWID, LAT, OPRE, WA2, WD2, WE2, CS2) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## WA2; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD2; \
    sc_out < bool > OPRE ## NAME ## _ ## WE2; \
    sc_out < bool > OPRE ## NAME ## _ ## CS2;
#define MEM_DEF_2W_E_B(NAME, DTYPE, AWID, BWID, LAT, OPRE, WA2, WD2, WE2, CS2, BE2) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## WA2; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD2; \
    sc_out < bool > OPRE ## NAME ## _ ## WE2; \
    sc_out < bool > OPRE ## NAME ## _ ## CS2; \
    sc_out < ac_int<BWID,false> > OPRE ## NAME ## _ ## BE2;
#define MEM_DEF_1W(NAME, DTYPE, AWID, LAT, OPRE, WA2, WD2, WE2) \
    sc_out < ac_int<AWID,false> > OPRE ## NAME ## _ ## WA2; \
    sc_out < DTYPE > OPRE ## NAME ## _ ## WD2; \
    sc_out < bool > OPRE ## NAME ## _ ## WE2;
#endif // _USE_AC

#else // _MEM_MODEL
#define MEM_DEF(NAME, DTYPE, AWID, LAT) \
    sc_signal < sc_uint<AWID> > addr_ ## NAME[LAT+1]; \
    sc_signal < DTYPE > data_ ## NAME[LAT+1]; \
    sc_signal < bool > rw_ ## NAME[LAT+1]; // 0:R, 1:W
// single port memory
#define MEM_DEF_1(NAME, DTYPE, AWID, LAT, IPRE, OPRE, AD1, WD1, WE1, RD1) \
    MEM_DEF(NAME, DTYPE, AWID, LAT)
#define MEM_DEF_1_E(NAME, DTYPE, AWID, LAT, IPRE, OPRE, AD1, WD1, WE1, RD1, CS1) \
    MEM_DEF(NAME, DTYPE, AWID, LAT)
// 2port memory read
#define MEM_DEF_2R(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2) \
    sc_signal< sc_uint<AWID> >  raddr_ ## NAME[LAT+1];
#define MEM_DEF_2R_E(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2, RE2) \
    sc_signal< sc_uint<AWID> >  raddr_ ## NAME[LAT+1];
#define MEM_DEF_1R(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2) \
    MEM_DEF_2R(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2)
#define MEM_DEF_1R_E(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2, RE2) \
    MEM_DEF_2R_E(NAME, DTYPE, AWID, LAT, IPRE, OPRE, RA2, RD2, RE2)
// 2port memory write
#define MEM_DEF_2W(NAME, DTYPE, AWID, LAT, OPRE, WA2, WD2, WE2) \
    MEM_DEF(NAME, DTYPE, AWID, LAT)
#define MEM_DEF_2W_E(NAME, DTYPE, AWID, LAT, OPRE, WA2, WD2, WE2, CS2) \
    MEM_DEF(NAME, DTYPE, AWID, LAT)
#define MEM_DEF_1W(NAME, DTYPE, AWID, LAT, OPRE, WA2, WD2, WE2) \
    MEM_DEF_2W(NAME, DTYPE, AWID, LAT, OPRE, WA2, WD2, WE2)
#endif // _MEM_MODEL

//////////////////////////////////////////
// (2) Memory port name initialization
//////////////////////////////////////////
//-- for port only access
// single port memory
#define MEM_ININM_1_P(NAME, IPRE, OPRE, AD1, WD1, WE1, RD1) \
    ,CTOR_NM(OPRE ## NAME ## _ ## AD1) \
    ,CTOR_NM(OPRE ## NAME ## _ ## WD1) \
    ,CTOR_NM(OPRE ## NAME ## _ ## WE1) \
    ,CTOR_NM(IPRE ## NAME ## _ ## RD1)
#define MEM_ININM_1_E_P(NAME, IPRE, OPRE, AD1, WD1, WE1, RD1, CS1) \
    MEM_ININM_1_P(NAME, IPRE, OPRE, AD1, WD1, WE1, RD1) \
    ,CTOR_NM(OPRE ## NAME ## _ ## CS1)
// 2port memory read
#define MEM_ININM_2R_P(NAME, IPRE, OPRE, RA2, RD2) \
    ,CTOR_NM(OPRE ## NAME ## _ ## RA2) \
    ,CTOR_NM(IPRE ## NAME ## _ ## RD2)
#define MEM_ININM_2R_E_P(NAME, IPRE, OPRE, RA2, RD2, RE2) \
    MEM_ININM_2R_P(NAME, IPRE, OPRE, RA2, RD2) \
    ,CTOR_NM(OPRE ## NAME ## _ ## RE2)
#define MEM_ININM_1R_P(NAME, IPRE, OPRE, RA2, RD2) \
    MEM_ININM_2R_P(NAME, IPRE, OPRE, RA2, RD2)
#define MEM_ININM_1R_E_P(NAME, IPRE, OPRE, RA2, RD2, RE2) \
    MEM_ININM_2R_E_P(NAME, IPRE, OPRE, RA2, RD2, RE2)
// 2port memory write
#define MEM_ININM_2W_P(NAME, OPRE, WA2, WD2, WE2) \
    ,CTOR_NM(OPRE ## NAME ## _ ## WA2) \
    ,CTOR_NM(OPRE ## NAME ## _ ## WD2) \
    ,CTOR_NM(OPRE ## NAME ## _ ## WE2)
#define MEM_ININM_2W_E_P(NAME, OPRE, WA2, WD2, WE2, CS2) \
    MEM_ININM_2W_P(NAME, OPRE, WA2, WD2, WE2) \
    ,CTOR_NM(OPRE ## NAME ## _ ## CS2)
#define MEM_ININM_2W_E_B_P(NAME, OPRE, WA2, WD2, WE2, CS2, BE2) \
    MEM_ININM_2W_E_P(NAME, OPRE, WA2, WD2, WE2, CS2) \
    ,CTOR_NM(OPRE ## NAME ## _ ## BE2)
#define MEM_ININM_1W_P(NAME, OPRE, WA2, WD2, WE2) \
    MEM_ININM_2W_P(NAME, OPRE, WA2, WD2, WE2)
//-- for switching access
#ifdef _MEM_MODEL
// single port memory
#define MEM_ININM_1(NAME, IPRE, OPRE, AD1, WD1, WE1, RD1) \
    ,CTOR_NM(OPRE ## NAME ## _ ## AD1) \
    ,CTOR_NM(OPRE ## NAME ## _ ## WD1) \
    ,CTOR_NM(OPRE ## NAME ## _ ## WE1) \
    ,CTOR_NM(IPRE ## NAME ## _ ## RD1)
#define MEM_ININM_1_E(NAME, IPRE, OPRE, AD1, WD1, WE1, RD1, CS1) \
    MEM_ININM_1(NAME, IPRE, OPRE, AD1, WD1, WE1, RD1) \
    ,CTOR_NM(OPRE ## NAME ## _ ## CS1)
// 2port memory read
#define MEM_ININM_2R(NAME, IPRE, OPRE, RA2, RD2) \
    ,CTOR_NM(OPRE ## NAME ## _ ## RA2) \
    ,CTOR_NM(IPRE ## NAME ## _ ## RD2)
#define MEM_ININM_2R_E(NAME, IPRE, OPRE, RA2, RD2, RE2) \
    MEM_ININM_2R(NAME, IPRE, OPRE, RA2, RD2) \
    ,CTOR_NM(OPRE ## NAME ## _ ## RE2)
#define MEM_ININM_1R(NAME, IPRE, OPRE, RA2, RD2) \
    MEM_ININM_2R(NAME, IPRE, OPRE, RA2, RD2)
#define MEM_ININM_1R_E(NAME, IPRE, OPRE, RA2, RD2, RE2) \
    MEM_ININM_2R_E(NAME, IPRE, OPRE, RA2, RD2, RE2)
// 2port memory write
#define MEM_ININM_2W(NAME, OPRE, WA2, WD2, WE2) \
    ,CTOR_NM(OPRE ## NAME ## _ ## WA2) \
    ,CTOR_NM(OPRE ## NAME ## _ ## WD2) \
    ,CTOR_NM(OPRE ## NAME ## _ ## WE2)
#define MEM_ININM_2W_E(NAME, OPRE, WA2, WD2, WE2, CS2) \
    MEM_ININM_2W(NAME, OPRE, WA2, WD2, WE2) \
    ,CTOR_NM(OPRE ## NAME ## _ ## CS2)
#define MEM_ININM_2W_E_B(NAME, OPRE, WA2, WD2, WE2, CS2, BE2) \
    MEM_ININM_2W_E(NAME, OPRE, WA2, WD2, WE2, CS2) \
    ,CTOR_NM(OPRE ## NAME ## _ ## BE2)
#define MEM_ININM_1W(NAME, OPRE, WA2, WD2, WE2) \
    MEM_ININM_2W(NAME, OPRE, WA2, WD2, WE2)
#else
// single port memory
#define MEM_ININM_1(NAME, IPRE, OPRE, AD1, WD1, WE1, RD1)
#define MEM_ININM_1_E(NAME, IPRE, OPRE, AD1, WD1, WE1, RD1, CS1)
// 2port memory read
#define MEM_ININM_2R(NAME, IPRE, OPRE, RA2, RD2)
#define MEM_ININM_2R_E(NAME, IPRE, OPRE, RA2, RD2, RE2)
#define MEM_ININM_1R(NAME, IPRE, OPRE, RA2, RD2)
#define MEM_ININM_1R_E(NAME, IPRE, OPRE, RA2, RD2, RE2)
// 2port memory write
#define MEM_ININM_2W(NAME, OPRE, WA2, WD2, WE2)
#define MEM_ININM_2W_E(NAME, OPRE, WA2, WD2, WE2, CS2)
#define MEM_ININM_2W_E_B(NAME, OPRE, WA2, WD2, WE2, CS2, BE2)
#define MEM_ININM_1W(NAME, OPRE, WA2, WD2, WE2)
#endif

//////////////////////////////////////////
// (3) Memory port value initialization
//////////////////////////////////////////
//-- for port only access
// single port memory
#define MEM_INIVAL_1_NOAW_P(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_INIVAL_1_NOAD_P(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## WD1 .write(0); \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_INIVAL_1_NOWD_P(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## AD1 .write(0); \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_INIVAL_1_P(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## AD1 .write(0); \
    OPRE ## NAME ## _ ## WD1 .write(0); \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_INIVAL_1_E_NOAW_P(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_INIVAL_1_NOAW_P(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
#define MEM_INIVAL_1_E_NOAD_P(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_INIVAL_1_NOAD_P(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
#define MEM_INIVAL_1_E_NOWD_P(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_INIVAL_1_NOWD_P(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
#define MEM_INIVAL_1_E_P(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_INIVAL_1_P(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
// 2port memory read
#define MEM_INIVAL_2R_P(NAME, OPRE, RA2) \
    OPRE ## NAME ## _ ## RA2 .write(0);
#define MEM_INIVAL_2R_E_NOAD_P(NAME, OPRE, REV, RA2, RE2) \
    OPRE ## NAME ## _ ## RE2 .write(REV);
#define MEM_INIVAL_2R_E_P(NAME, OPRE, REV, RA2, RE2) \
    MEM_INIVAL_2R_P(NAME, OPRE, RA2) \
    OPRE ## NAME ## _ ## RE2 .write(REV);
#define MEM_INIVAL_1R_P(NAME, OPRE, RA2) \
    MEM_INIVAL_2R_P(NAME, OPRE, RA2)
#define MEM_INIVAL_1R_E_P(NAME, OPRE, REV, RA2, RE2) \
    MEM_INIVAL_2R_E_P(NAME, OPRE, REV, RA2, RE2)
// 2port memory write
#define MEM_INIVAL_2W_NOAW_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_INIVAL_2W_NOAD_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## WD2 .write(0); \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_INIVAL_2W_NOWD_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## WA2 .write(0); \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_INIVAL_2W_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## WA2 .write(0); \
    OPRE ## NAME ## _ ## WD2 .write(0); \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_INIVAL_2W_E_NOAW_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_INIVAL_2W_NOAW_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_INIVAL_2W_E_B_NOAW_P(NAME, OPRE, WEV, CSV, BEV, WA2, WD2, WE2, CS2, BE2) \
    MEM_INIVAL_2W_E_NOAW_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    OPRE ## NAME ## _ ## BE2 .write(BEV);
#define MEM_INIVAL_2W_E_NOAD_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_INIVAL_2W_NOAD_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_INIVAL_2W_E_B_NOAD_P(NAME, OPRE, WEV, CSV, BEV, WA2, WD2, WE2, CS2, BE2) \
    MEM_INIVAL_2W_E_NOAD_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    OPRE ## NAME ## _ ## BE2 .write(BEV);
#define MEM_INIVAL_2W_E_NOWD_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_INIVAL_2W_NOWD_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_INIVAL_2W_E_B_NOWD_P(NAME, OPRE, WEV, CSV, BEV, WA2, WD2, WE2, CS2, BE2) \
    MEM_INIVAL_2W_E_NOWD_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    OPRE ## NAME ## _ ## BE2 .write(BEV);
#define MEM_INIVAL_2W_E_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_INIVAL_2W_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_INIVAL_2W_E_B_P(NAME, OPRE, WEV, CSV, BEV, WA2, WD2, WE2, CS2, BE2) \
    MEM_INIVAL_2W_E_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    OPRE ## NAME ## _ ## BE2 .write(BEV);
#define MEM_INIVAL_1W_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    MEM_INIVAL_2W_P(NAME, OPRE, WEV, WA2, WD2, WE2)
//-- for switching access
#ifdef _MEM_MODEL
// single port memory
#define MEM_INIVAL_1_NOAW(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_INIVAL_1_NOAD(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## WD1 .write(0); \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_INIVAL_1_NOWD(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## AD1 .write(0); \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_INIVAL_1(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## AD1 .write(0); \
    OPRE ## NAME ## _ ## WD1 .write(0); \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_INIVAL_1_E_NOAW(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_INIVAL_1_NOAW(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
#define MEM_INIVAL_1_E_NOAD(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_INIVAL_1_NOAD(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
#define MEM_INIVAL_1_E_NOWD(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_INIVAL_1_NOWD(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
#define MEM_INIVAL_1_E(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_INIVAL_1(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
// 2port memory read
#define MEM_INIVAL_2R(NAME, OPRE, RA2) \
    OPRE ## NAME ## _ ## RA2 .write(0);
#define MEM_INIVAL_2R_E_NOAD(NAME, OPRE, REV, RA2, RE2) \
    OPRE ## NAME ## _ ## RE2 .write(REV);
#define MEM_INIVAL_2R_E(NAME, OPRE, REV, RA2, RE2) \
    MEM_INIVAL_2R(NAME, OPRE, RA2) \
    OPRE ## NAME ## _ ## RE2 .write(REV);
#define MEM_INIVAL_1R(NAME, OPRE, RA2) \
    MEM_INIVAL_2R(NAME, OPRE, RA2) 
#define MEM_INIVAL_1R_E(NAME, OPRE, REV, RA2, RE2) \
    MEM_INIVAL_2R_E(NAME, OPRE, REV, RA2, RE2)
// 2port memory write
#define MEM_INIVAL_2W_NOAW(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_INIVAL_2W_NOAD(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## WD2 .write(0); \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_INIVAL_2W_NOWD(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## WA2 .write(0); \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_INIVAL_2W(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## WA2 .write(0); \
    OPRE ## NAME ## _ ## WD2 .write(0); \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_INIVAL_2W_E_NOAW(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_INIVAL_2W_NOAW(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_INIVAL_2W_E_B_NOAW(NAME, OPRE, WEV, CSV, BEV, WA2, WD2, WE2, CS2, BE2) \
    MEM_INIVAL_2W_E_NOAW(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    OPRE ## NAME ## _ ## BE2 .write(BEV);
#define MEM_INIVAL_2W_E_NOAD(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_INIVAL_2W_NOAD(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_INIVAL_2W_E_B_NOAD(NAME, OPRE, WEV, CSV, BEV, WA2, WD2, WE2, CS2, BE2) \
    MEM_INIVAL_2W_E_NOAD(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    OPRE ## NAME ## _ ## BE2 .write(BEV);
#define MEM_INIVAL_2W_E_NOWD(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_INIVAL_2W_NOWD(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_INIVAL_2W_E_B_NOWD(NAME, OPRE, WEV, CSV, BEV, WA2, WD2, WE2, CS2, BE2) \
    MEM_INIVAL_2W_E_NOWD(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    OPRE ## NAME ## _ ## BE2 .write(BEV);
#define MEM_INIVAL_2W_E(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_INIVAL_2W(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_INIVAL_2W_E_B(NAME, OPRE, WEV, CSV, BEV, WA2, WD2, WE2, CS2, BE2) \
    MEM_INIVAL_2W_E(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    OPRE ## NAME ## _ ## BE2 .write(BEV);
#define MEM_INIVAL_1W(NAME, OPRE, WEV, WA2, WD2, WE2) \
    MEM_INIVAL_2W(NAME, OPRE, WEV, WA2, WD2, WE2)
#else
#define MEM_INIVAL(NAME) \
    addr_ ## NAME[0].write(0); \
    data_ ## NAME[0].write(0); \
    rw_ ## NAME[0].write(0);
// single port memory
#define MEM_INIVAL_1_NOAW(NAME, OPRE, WEV, AD1, WD1, WE1) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_1_NOAD(NAME, OPRE, WEV, AD1, WD1, WE1) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_1_NOWD(NAME, OPRE, WEV, AD1, WD1, WE1) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_1(NAME, OPRE, WEV, AD1, WD1, WE1) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_1_E_NOAW(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_1_E_NOAD(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_1_E_NOWD(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_1_E(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_INIVAL(NAME)
// 2port memory read
#define MEM_INIVAL_2R(NAME, OPRE, RA2) \
    raddr_ ## NAME[0].write(0);
#define MEM_INIVAL_2R_E_NOAD(NAME, OPRE, REV, RA2, RE2) \
    MEM_INIVAL_2R(NAME, OPRE, RA2)
#define MEM_INIVAL_2R_E(NAME, OPRE, REV, RA2, RE2) \
    MEM_INIVAL_2R(NAME, OPRE, RA2)
#define MEM_INIVAL_1R(NAME, OPRE, RA2) \
    MEM_INIVAL_2R(NAME, OPRE, RA2)
#define MEM_INIVAL_1R_E(NAME, OPRE, REV, RA2, RE2) \
    MEM_INIVAL_2R_E(NAME, OPRE, REV, RA2, RE2)
// 2port memory write
#define MEM_INIVAL_2W_NOAW(NAME, OPRE, WEV, WA2, WD2, WE2) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_2W_NOAD(NAME, OPRE, WEV, WA2, WD2, WE2) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_2W_NOWD(NAME, OPRE, WEV, WA2, WD2, WE2) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_2W(NAME, OPRE, WEV, WA2, WD2, WE2) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_2W_E_NOAW(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_2W_E_B_NOAW(NAME, OPRE, WEV, CSV, BEV, WA2, WD2, WE2, CS2, BE2) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_2W_E_NOAD(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_2W_E_B_NOAD(NAME, OPRE, WEV, CSV, BEV, WA2, WD2, WE2, CS2, BE2) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_2W_E_NOWD(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_2W_E_B_NOWD(NAME, OPRE, WEV, CSV, BEV, WA2, WD2, WE2, CS2, BE2) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_2W_E(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_2W_E_B(NAME, OPRE, WEV, CSV, BEV, WA2, WD2, WE2, CS2, BE2) \
    MEM_INIVAL(NAME)
#define MEM_INIVAL_1W(NAME, OPRE, WEV, WA2, WD2, WE2) \
    MEM_INIVAL_2W(NAME, OPRE, WEV, WA2, WD2, WE2)
#endif

//////////////////////////////////////////
// (4) Negating memory enable port
//////////////////////////////////////////
//-- for port only access
// single port memory
#define MEM_NEG_1_P(NAME, OPRE, WEV, WE1) \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_NEG_1_E_P(NAME, OPRE, WEV, CSV, WE1, CS1) \
    MEM_NEG_1_P(NAME, OPRE, WEV, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
// 2port memory read
#define MEM_NEG_2R_E_P(NAME, OPRE, REV, RE2) \
    OPRE ## NAME ## _ ## RE2 .write(REV);
#define MEM_NEG_1R_E_P(NAME, OPRE, REV, RE2) \
    MEM_NEG_2R_E_P(NAME, OPRE, REV, RE2)
// 2port memory write
#define MEM_NEG_2W_P(NAME, OPRE, WEV, WE2) \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_NEG_2W_E_P(NAME, OPRE, WEV, CSV, WE2, CS2) \
    MEM_NEG_2W_P(NAME, OPRE, WEV, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_NEG_1W_P(NAME, OPRE, WEV, WE2) \
    MEM_NEG_2W_P(NAME, OPRE, WEV, WE2)
//-- for switching access
#ifdef _MEM_MODEL
// single port memory
#define MEM_NEG_1(NAME, OPRE, WEV, WE1) \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_NEG_1_E(NAME, OPRE, WEV, CSV, WE1, CS1) \
    MEM_NEG_1(NAME, OPRE, WEV, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
// 2port memory read
#define MEM_NEG_2R_E(NAME, OPRE, REV, RE2) \
    OPRE ## NAME ## _ ## RE2 .write(REV);
#define MEM_NEG_1R_E(NAME, OPRE, REV, RE2) \
    MEM_NEG_2R_E(NAME, OPRE, REV, RE2)
// 2port memory write
#define MEM_NEG_2W(NAME, OPRE, WEV, WE2) \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_NEG_2W_E(NAME, OPRE, WEV, CSV, WE2, CS2) \
    MEM_NEG_2W(NAME, OPRE, WEV, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_NEG_1W(NAME, OPRE, WEV, WE2) \
    MEM_NEG_2W(NAME, OPRE, WEV, WE2)
#else
// single port memory
#define MEM_NEG_1(NAME, OPRE, WEV, WE1) \
  rw_ ## NAME[0].write(0);
#define MEM_NEG_1_E(NAME, OPRE, WEV, CSV, WE1, CS1) \
  rw_ ## NAME[0].write(0);
// 2port memory read
#define MEM_NEG_2R_E(NAME, OPRE, REV, RE2)
#define MEM_NEG_1R_E(NAME, OPRE, REV, RE2)
// 2port memory write
#define MEM_NEG_2W(NAME, OPRE, WEV, WE2) \
  rw_ ## NAME[0].write(0);
#define MEM_NEG_2W_E(NAME, OPRE, WEV, CSV, WE2, CS2) \
  rw_ ## NAME[0].write(0);
#define MEM_NEG_1W(NAME, OPRE, WEV, WE2) \
    MEM_NEG_2W(NAME, OPRE, WEV, WE2)
#endif

//////////////////////////////////////////
// (5) Memory array extern definition
//////////////////////////////////////////
//-- for testbench
#define MEM_PTR_A(NAME, DTYPE) \
extern DTYPE *ptr_##NAME;

//-- for model
#ifndef _MEM_MODEL
#define MEM_PTR(NAME, DTYPE) \
extern DTYPE *ptr_##NAME;
#else
#define MEM_PTR(NAME, DTYPE)
#endif

//////////////////////////////////////////
// (6) Memory pipeline function
//////////////////////////////////////////
#ifdef _MEM_MODEL
#define MEM_PIPE_CTOR(NAME, CLK)
#define MEM_PIPE(NAME, LAT)
#define MEM_PIPE_2R_CTOR(NAME, CLK)
#define MEM_PIPE_2R(NAME, LAT)
#else
#define MEM_PIPE_CTOR(NAME, CLK) \
    SC_METHOD(method_ ## NAME ## _pipe); \
    sensitive << (CLK).pos();
#define MEM_PIPE(NAME, LAT) \
  void method_ ## NAME ## _pipe() { \
    if (rw_ ## NAME[LAT].read() == 1) { \
      ptr_ ## NAME[(int)addr_ ## NAME[LAT].read()] = data_ ## NAME[LAT].read(); \
    } \
    for (int i = 0; i < LAT; i++) { \
      addr_ ## NAME[i+1].write(addr_ ## NAME[i].read()); \
      data_ ## NAME[i+1].write(data_ ## NAME[i].read()); \
      rw_ ## NAME[i+1].write(rw_ ## NAME[i].read()); \
    } \
  }
#define MEM_PIPE_2R_CTOR(NAME, CLK) \
    SC_METHOD(method_ ## NAME ## _2r_pipe); \
    sensitive << (CLK).pos();
#define MEM_PIPE_2R(NAME, LAT) \
  void method_ ## NAME ## _2r_pipe() { \
    for (int i = 0; i < LAT; i++) { \
      raddr_ ## NAME[i+1].write(raddr_ ## NAME[i].read()); \
    } \
  }
#endif

//////////////////////////////////////////
// (7-1) Memory read request function
//////////////////////////////////////////
//-- for port only access
// single port memory
#define MEM_REQ_1_P(NAME, OPRE, AD1) \
    OPRE ## NAME ## _ ## AD1 .write(addr);
#define MEM_REQ_1_E_NOAD_P(NAME, OPRE, CSV, AD1, CS1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
#define MEM_REQ_1_E_P(NAME, OPRE, CSV, AD1, CS1) \
    MEM_REQ_1_P(NAME, OPRE, AD1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
// 2port memory
#define MEM_REQ_2_P(NAME, OPRE, RA2) \
    OPRE ## NAME ## _ ## RA2 .write(addr);
#define MEM_REQ_2_E_NOAD_P(NAME, OPRE, REV, RA2, RE2) \
    OPRE ## NAME ## _ ## RE2 .write(REV);
#define MEM_REQ_2_E_P(NAME, OPRE, REV, RA2, RE2) \
    MEM_REQ_2_P(NAME, OPRE, RA2) \
    OPRE ## NAME ## _ ## RE2 .write(REV);
#define MEM_REQ_1R_P(NAME, OPRE, RA2) \
    MEM_REQ_2_P(NAME, OPRE, RA2)
#define MEM_REQ_1R_E_P(NAME, OPRE, REV, RA2, RE2) \
    MEM_REQ_2_E_P(NAME, OPRE, REV, RA2, RE2)
//-- for switching access
#ifdef _MEM_MODEL
// single port memory
#define MEM_REQ_1(NAME, OPRE, AD1) \
    OPRE ## NAME ## _ ## AD1 .write(addr);
#define MEM_REQ_1_E_NOAD(NAME, OPRE, CSV, AD1, CS1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
#define MEM_REQ_1_E(NAME, OPRE, CSV, AD1, CS1) \
    MEM_REQ_1(NAME, OPRE, AD1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
// 2port memory
#define MEM_REQ_2(NAME, OPRE, RA2) \
    OPRE ## NAME ## _ ## RA2 .write(addr);
#define MEM_REQ_2_E_NOAD(NAME, OPRE, REV, RA2, RE2) \
    OPRE ## NAME ## _ ## RE2 .write(REV);
#define MEM_REQ_2_E(NAME, OPRE, REV, RA2, RE2) \
    MEM_REQ_2(NAME, OPRE, RA2) \
    OPRE ## NAME ## _ ## RE2 .write(REV);
#define MEM_REQ_1R(NAME, OPRE, RA2) \
    MEM_REQ_2(NAME, OPRE, RA2)
#define MEM_REQ_1R_E(NAME, OPRE, REV, RA2, RE2) \
    MEM_REQ_2_E(NAME, OPRE, REV, RA2, RE2)
#else
#define MEM_REQ(NAME) \
    addr_ ## NAME[0].write(addr); \
    rw_ ## NAME[0].write(0);
// single port memory
#define MEM_REQ_1(NAME, OPRE, AD1) \
    MEM_REQ(NAME)
#define MEM_REQ_1_E_NOAD(NAME, OPRE, CSV, AD1, CS1) \
    MEM_REQ(NAME)
#define MEM_REQ_1_E(NAME, OPRE, CSV, AD1, CS1) \
    MEM_REQ(NAME)
// 2port memory
#define MEM_REQ_2(NAME, OPRE, RA2) \
    raddr_ ## NAME[0].write(addr);
#define MEM_REQ_2_E_NOAD(NAME, OPRE, REV, RA2, RE2) \
    MEM_REQ_2(NAME, OPRE, RA2)
#define MEM_REQ_2_E(NAME, OPRE, REV, RA2, RE2) \
    MEM_REQ_2(NAME, OPRE, RA2)
#define MEM_REQ_1R(NAME, OPRE, RA2) \
    MEM_REQ_2(NAME, OPRE, RA2)
#define MEM_REQ_1R_E(NAME, OPRE, REV, RA2, RE2) \
    MEM_REQ_2(NAME, OPRE, RA2)
#endif

//////////////////////////////////////////
// (7-2) Memory read function
//////////////////////////////////////////
//-- for port only access
#define MEM_RD_1_P(NAME, LAT, IPRE, RD1) \
    data = IPRE ## NAME ## _ ## RD1 .read();
#define MEM_RD_2_P(NAME, LAT, IPRE, RD2) \
    data = IPRE ## NAME ## _ ## RD2 .read();
#define MEM_RD_1R_P(NAME, LAT, IPRE, RD2) \
    MEM_RD_2_P(NAME, LAT, IPRE, RD2)
//-- for switching access
#ifdef _MEM_MODEL
#define MEM_RD_1(NAME, LAT, IPRE, RD1) \
    data = IPRE ## NAME ## _ ## RD1 .read();
#define MEM_RD_2(NAME, LAT, IPRE, RD2) \
    data = IPRE ## NAME ## _ ## RD2 .read();
#define MEM_RD_1R(NAME, LAT, IPRE, RD2) \
    MEM_RD_2(NAME, LAT, IPRE, RD2)
#else
#define MEM_RD_1(NAME, LAT, IPRE, RD1) \
    data = ptr_ ## NAME[(int)addr_ ## NAME[LAT].read()];
#define MEM_RD_2(NAME, LAT, IPRE, RD2) \
    data = ptr_ ## NAME[(int)raddr_ ## NAME[LAT].read()];
#define MEM_RD_1R(NAME, LAT, IPRE, RD2) \
    MEM_RD_2(NAME, LAT, IPRE, RD2)


#endif

//////////////////////////////////////////
// (7-3) Memory write function
//////////////////////////////////////////
//-- for port only access
// single port memory
#define MEM_WR_1_NOAW_P(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_WR_1_NOAD_P(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## WD1 .write(data); \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_WR_1_NOWD_P(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## AD1 .write(addr); \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_WR_1_P(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## AD1 .write(addr); \
    OPRE ## NAME ## _ ## WD1 .write(data); \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_WR_1_E_NOAW_P(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_WR_1_NOAW_P(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
#define MEM_WR_1_E_NOAD_P(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_WR_1_NOAD_P(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
#define MEM_WR_1_E_NOWD_P(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_WR_1_NOWD_P(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
#define MEM_WR_1_E_P(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_WR_1_P(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
// 2port memory
#define MEM_WR_2_NOAW_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_WR_2_NOAD_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## WD2 .write(data); \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_WR_2_NOWD_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## WA2 .write(addr); \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_WR_2_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## WA2 .write(addr); \
    OPRE ## NAME ## _ ## WD2 .write(data); \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_WR_2_E_NOAW_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_WR_2_NOAW_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_WR_2_E_B_NOAW_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2, BE2) \
    MEM_WR_2_E_NOAW_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    OPRE ## NAME ## _ ## BE2 .write(be);
#define MEM_WR_2_E_NOAD_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_WR_2_NOAD_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_WR_2_E_B_NOAD_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2, BE2) \
    MEM_WR_2_E_NOAD_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    OPRE ## NAME ## _ ## BE2 .write(be);
#define MEM_WR_2_E_NOWD_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_WR_2_NOWD_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_WR_2_E_B_NOWD_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2, BE2) \
    MEM_WR_2_E_NOWD_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    OPRE ## NAME ## _ ## BE2 .write(be);
#define MEM_WR_2_E_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_WR_2_P(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_WR_2_E_B_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2, BE2) \
    MEM_WR_2_E_P(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    OPRE ## NAME ## _ ## BE2 .write(be);
//-- for switching access
#ifdef _MEM_MODEL
// single port memory
#define MEM_WR_1_NOAW(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_WR_1_NOAD(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## WD1 .write(data); \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_WR_1_NOWD(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## AD1 .write(addr); \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_WR_1(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## AD1 .write(addr); \
    OPRE ## NAME ## _ ## WD1 .write(data); \
    OPRE ## NAME ## _ ## WE1 .write(WEV);
#define MEM_WR_1_E_NOAW(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_WR_1_NOAW(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
#define MEM_WR_1_E_NOAD(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_WR_1_NOAD(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
#define MEM_WR_1_E_NOWD(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_WR_1_NOWD(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
#define MEM_WR_1_E(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_WR_1(NAME, OPRE, WEV, AD1, WD1, WE1) \
    OPRE ## NAME ## _ ## CS1 .write(CSV);
// 2port memory
#define MEM_WR_2_NOAW(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_WR_2_NOAD(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## WD2 .write(data); \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_WR_2_NOWD(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## WA2 .write(addr); \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_WR_2(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## WA2 .write(addr); \
    OPRE ## NAME ## _ ## WD2 .write(data); \
    OPRE ## NAME ## _ ## WE2 .write(WEV);
#define MEM_WR_2_E_NOAW(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_WR_2_NOAW(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_WR_2_E_B_NOAW(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2, BE2) \
    MEM_WR_2_E_NOAW(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    OPRE ## NAME ## _ ## BE2 .write(be);
#define MEM_WR_2_E_NOAD(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_WR_2_NOAD(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_WR_2_E_B_NOAD(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2, BE2) \
    MEM_WR_2_E_NOAD(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    OPRE ## NAME ## _ ## BE2 .write(be);
#define MEM_WR_2_E_NOWD(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_WR_2_NOWD(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_WR_2_E_B_NOWD(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2, BE2) \
    MEM_WR_2_E_NOWD(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    OPRE ## NAME ## _ ## BE2 .write(be);
#define MEM_WR_2_E(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_WR_2(NAME, OPRE, WEV, WA2, WD2, WE2) \
    OPRE ## NAME ## _ ## CS2 .write(CSV);
#define MEM_WR_2_E_B(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2, BE2) \
    MEM_WR_2_E(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    OPRE ## NAME ## _ ## BE2 .write(be);
#else
#define MEM_WR(NAME) \
    addr_ ## NAME[0].write(addr); \
    data_ ## NAME[0].write(data); \
    rw_ ## NAME[0].write(1);
// single port memory
#define MEM_WR_1_NOAW(NAME, OPRE, WEV, AD1, WD1, WE1) \
    MEM_WR(NAME)
#define MEM_WR_1_NOAD(NAME, OPRE, WEV, AD1, WD1, WE1) \
    MEM_WR(NAME)
#define MEM_WR_1_NOWD(NAME, OPRE, WEV, AD1, WD1, WE1) \
    MEM_WR(NAME)
#define MEM_WR_1(NAME, OPRE, WEV, AD1, WD1, WE1) \
    MEM_WR(NAME)
#define MEM_WR_1_E_NOAW(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_WR(NAME)
#define MEM_WR_1_E_NOAD(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_WR(NAME)
#define MEM_WR_1_E_NOWD(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_WR(NAME)
#define MEM_WR_1_E(NAME, OPRE, WEV, CSV, AD1, WD1, WE1, CS1) \
    MEM_WR(NAME)
// 2port memory
#define MEM_WR_2_NOAW(NAME, OPRE, WEV, WA2, WD2, WE2) \
    MEM_WR(NAME)
#define MEM_WR_2_NOAD(NAME, OPRE, WEV, WA2, WD2, WE2) \
    MEM_WR(NAME)
#define MEM_WR_2_NOWD(NAME, OPRE, WEV, WA2, WD2, WE2) \
    MEM_WR(NAME)
#define MEM_WR_2(NAME, OPRE, WEV, WA2, WD2, WE2) \
    MEM_WR(NAME)
#define MEM_WR_2_E_NOAW(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_WR(NAME)
#define MEM_WR_2_E_B_NOAW(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2, BE2) \
    MEM_WR(NAME)
#define MEM_WR_2_E_NOAD(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_WR(NAME)
#define MEM_WR_2_E_B_NOAD(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2, BE2)) \
    MEM_WR(NAME)
#define MEM_WR_2_E_NOWD(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_WR(NAME)
#define MEM_WR_2_E_B_NOWD(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2, BE2)) \
    MEM_WR(NAME)
#define MEM_WR_2_E(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2) \
    MEM_WR(NAME)
#define MEM_WR_2_E_B(NAME, OPRE, WEV, CSV, WA2, WD2, WE2, CS2, BE2) \
    MEM_WR(NAME)
#endif

////////////////////////////////////////////////////////////////////////////////
// Assertion Macro
////////////////////////////////////////////////////////////////////////////////
#if !defined(__CTOS__) && !defined(CALYPTO_SYSC) && !defined(STRATUS)
#ifdef _DEBUG_SIM
#define SSGEN_ASSERT(a) \
  if(!(a)) SC_REPORT_WARNING( "assert check", #a );
#else
#define SSGEN_ASSERT(a) assert((a));
#endif

#else
#define SSGEN_ASSERT(a)
#endif

////////////////////////////////////////////////////////////////////////////////
// var2reg Macro
////////////////////////////////////////////////////////////////////////////////
#define VAR2REG(var, dat) \
  (var) = (dat); \
  r_ ## var.write((var))

////////////////////////////////////////////////////////////////////////////////
// EV Class and Macros
////////////////////////////////////////////////////////////////////////////////
template <class TYPE>
struct EV{

    TYPE var;
    bool flg;

    void init(TYPE val) {
        var = val;
        flg = 0;
    }

    void put(TYPE val) {
        var = val;
        flg = 1;
    }

    TYPE get() {
        return var;
    }

};

#define EV_DEF(a, TYPE) \
    EV < TYPE > (a); \
    sc_signal < TYPE > r_ ## a

#define EV_ININM(a) \
    CTOR_NM(r_ ## a)

#define EV_INIT(a, VAL) \
    (a).init(VAL); \
    r_ ## a .write(VAL)

#define EV_WR(a) \
    if(a.flg) \
        r_ ## a .write(a.var)

#define EV_RD(a) \
    a.var = r_ ## a .read(); \
    (a).flg = 0


#if !defined(__CTOS__) && !defined(CALYPTO_SYSC) && !defined(STRATUS)
////////////////////////////////////////////////////////////////////////////////
// Library classes
////////////////////////////////////////////////////////////////////////////////
class ssgen_trace_file : public vcd_trace_file {
public:
    ssgen_trace_file(const char *name)
      : vcd_trace_file(name) {
        outputOn = true;
    }
    bool isOn() { return outputOn; }
    void on() { outputOn = true; }
    void off() { outputOn = false; }

protected:
    void cycle(bool delta_cycle) {
        if (isOn()) {
            vcd_trace_file::cycle(delta_cycle);
        }
    }

private:
    bool outputOn;
};

////////////////////////////////////////////////////////////////////////////////
// Library functions
////////////////////////////////////////////////////////////////////////////////
inline ssgen_trace_file *create_ssgen_trace_file(const char* name) {
    ssgen_trace_file *tf = new ssgen_trace_file(name);
    sc_get_curr_simcontext()->add_trace_file(tf);
    return tf;
}

inline void ssgen_trace_post(const char* vcd_in) {
    const char tmp_file[] = "ssgen_tmp.vcd";
    char token[7][T_MAX]; // token is intialized after
    char name[T_MAX];     // name is intialized after
    char scope_p[T_MAX];  // scope_p is intialized after
    char scope_c[T_MAX];  // scope_c is intialized after
    int pos = 0, pos_in = 0, pos_out = 0;
    bool conv_end = 0;
    int t_num = 0;
    std::ifstream ofs_in(vcd_in);
    std::ofstream ofs_out(tmp_file);
    std::string strline;
    if (ofs_in.fail()) {
        cout << "open error [" << vcd_in << "]" << std::endl;
        return;
    }

    strcpy(scope_p, "\0");
    while (std::getline(ofs_in, strline)) {
        const char* line = strline.c_str();
        if (conv_end == 0) {
            bool next_ok = 0;
            t_num = 0;
            pos_in = 0, pos_out = 0;
            while (1) {
                if (line[pos_in] == ' '
                    || line[pos_in] == '\0'
                    || line[pos_in] == '\r'
                    || line[pos_in] == '\n') {
                    if (next_ok) {
                        token[t_num][pos_out] = '\0';
                        next_ok = 0;
                        pos_out = 0;
                        t_num++;
                        if (t_num == 7) break;
                    }
                    if (line[pos_in] == '\0') break;
                }
                else {
                    next_ok = 1;
                    token[t_num][pos_out++] = line[pos_in];
                }
                pos_in++;
            }
            if (strcmp(token[0], "$var") == 0) {
                strcpy(scope_c, token[4]);
                for (pos = (int)strlen(scope_c)-1; pos >= 0; pos--) {
                    if (scope_c[pos] == '.') {
                        scope_c[pos] = '\0';
                        break;
                    }
                    scope_c[pos] = '\0';
                }
                if (strlen(scope_p) > 0 && strcmp(scope_p, scope_c) != 0) {
                    pos = 0;
                    while (1) {
                        if (scope_p[pos] == '.' || scope_p[pos] == '\0') {
                            ofs_out << "$upscope $end" << std::endl;
                            if (scope_p[pos] == '\0') break;
                        }
                        pos++;
                    }
                }
                pos_in = 0, pos_out = 0;
                while (1) {
                    if (token[4][pos_in] == '.') {
                        name[pos_out] = '\0';
                        pos_out = 0;
                        if (strcmp(scope_p, scope_c) != 0) {
                            ofs_out << "$scope module " << name << " $end" << std::endl;
                        }
                    }
                    else if (token[4][pos_in] == '\0') {
                        name[pos_out] = '\0';
                        strcpy(token[4], name);
                        pos_out = 0;
                        break;
                    }
                    else {
                        name[pos_out++] = token[4][pos_in];
                    }
                    pos_in++;
                }
                pos = 0;
                while (pos < t_num) {
                    ofs_out << token[pos];
                    if (pos == t_num - 1) ofs_out << std::endl;
                    else ofs_out << " ";
                    pos++;
                }
                strcpy(scope_p, scope_c);
            }
            else {
                ofs_out << line << std::endl;
                if (strcmp(token[0], "$upscope") == 0) {
                    conv_end = 1;
                    pos = 0;
                    while (1) {
                        if (scope_p[pos] == '.' || scope_p[pos] == '\0') {
                            ofs_out << "$upscope $end" << std::endl;
                            if (scope_p[pos] == '\0') break;
                        }
                        pos++;
                    }
                }
            }
        }
        else {
            ofs_out << line << std::endl;
        }
    }
    ofs_in.close();
    ofs_out.close();
    remove(vcd_in);
    rename(tmp_file, vcd_in);
}
#endif // !defined(__CTOS__) && !defined(CALYPTO_SYSC) && !defined(STRATUS)

#endif // SSGENLIB_H
